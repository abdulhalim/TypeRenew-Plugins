<?php
declare(strict_types=1);

use TypechoPlugin\PluginsEditor\Plugin;
use Typecho\Common;
use Utils\Session;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$user->pass('administrator');

$settings  = Plugin::settings();
$jsonPath  = Plugin::jsonAbsolutePath();
$panelUrl  = Plugin::panelUrl();
$backupCount = (int) $settings['backupCount'];

$assetUrl = static fn (string $file): string => Common::url(
    'PluginsEditor/assets/' . ltrim($file, '/'),
    (string) $options->pluginUrl
);

// ------------------------------------------------------------------
//  پردازش POST — الگوی POST-Redirect-GET
// ------------------------------------------------------------------
if ($request->isPost()) {
    $security->protect();

    $action = (string) ($_POST['do'] ?? '');
    $name    = trim((string) ($_POST['name'] ?? ''));
    $version = trim((string) ($_POST['version'] ?? ''));
    $oldName = trim((string) ($_POST['old_name'] ?? ''));
    $flash   = ['type' => 'error', 'message' => 'خطای ناشناخته.'];

    try {
        switch ($action) {
            case 'add':
                if ($name === '' || $version === '') {
                    throw new \RuntimeException('نام پلاگین و نسخه نمی‌توانند خالی باشند.');
                }
                PeHelper::backupJson($jsonPath, $backupCount);
                $data = PeHelper::readJson($jsonPath);
                $data[$name] = $version;
                PeHelper::writeJson($jsonPath, $data);
                $flash = ['type' => 'success',
                    'message' => sprintf('پلاگین «%s» با نسخه «%s» به لیست افزوده شد.', $name, $version)];
                break;

            case 'edit':
                if ($name === '' || $version === '' || $oldName === '') {
                    throw new \RuntimeException('نام قدیم، نام جدید و نسخه همگی الزامی هستند.');
                }
                PeHelper::backupJson($jsonPath, $backupCount);
                $data = PeHelper::readJson($jsonPath);
                if (isset($data[$oldName])) {
                    unset($data[$oldName]);
                }
                $data[$name] = $version;
                PeHelper::writeJson($jsonPath, $data);
                $flash = ['type' => 'success',
                    'message' => sprintf('پلاگین «%s» به «%s نسخه %s» تغییر یافت.', $oldName, $name, $version)];
                break;

            case 'delete':
                if ($name === '') {
                    throw new \RuntimeException('نام پلاگین برای حذف الزامی است.');
                }
                PeHelper::backupJson($jsonPath, $backupCount);
                $data = PeHelper::readJson($jsonPath);
                unset($data[$name]);
                PeHelper::writeJson($jsonPath, $data);
                $flash = ['type' => 'success',
                    'message' => sprintf('پلاگین «%s» از لیست حذف شد.', $name)];
                break;

            case 'save_all':
                $rawJson = (string) ($_POST['bulk_json'] ?? '');
                $parsed = json_decode($rawJson, true);
                if (!is_array($parsed)) {
                    throw new \RuntimeException('JSON وارد شده نامعتبر است. لطفاً ساختار را بررسی کنید.');
                }
                PeHelper::backupJson($jsonPath, $backupCount);
                PeHelper::writeJson($jsonPath, $parsed);
                $flash = ['type' => 'success',
                    'message' => sprintf('فایل plugins.json با موفقیت ذخیره شد (%d پلاگین).', count($parsed))];
                break;

            case 'clear_backups':
                $cleared = PeHelper::clearBackups(dirname($jsonPath));
                $flash = ['type' => 'success',
                    'message' => sprintf('تعداد %d فایل بکاپ قدیمی پاک شد.', $cleared)];
                break;

            default:
                throw new \RuntimeException(sprintf('عملیات ناشناخته: %s', $action));
        }
    } catch (\Throwable $e) {
        $flash = ['type' => 'error', 'message' => $e->getMessage()];
    }

    if (Session::start()) {
        $_SESSION[Plugin::SESSION_FLASH_KEY] = $flash;
    }
    $response->redirect($panelUrl);
    return;
}

// ------------------------------------------------------------------
//  خواندن پیام flash از نشست (الگوی PRG)
// ------------------------------------------------------------------
$flash = null;
if (Session::start() && isset($_SESSION[Plugin::SESSION_FLASH_KEY])) {
    $flash = $_SESSION[Plugin::SESSION_FLASH_KEY];
    unset($_SESSION[Plugin::SESSION_FLASH_KEY]);
}

// ------------------------------------------------------------------
//  خواندن داده فعلی
// ------------------------------------------------------------------
$plugins     = PeHelper::readJson($jsonPath);
ksort($plugins);
$totalPlugins = count($plugins);

$jsonExists   = file_exists($jsonPath);
$jsonWritable = $jsonExists && is_writable($jsonPath);
$rootWritable = is_writable(dirname($jsonPath));
$jsonContent  = $jsonExists ? (string) file_get_contents($jsonPath) : '{}';

$backups = PeHelper::listBackups(dirname($jsonPath));

$csrfToken = $security->getToken($request->getRequestUrl());

// محتوای JSON برای دانلود سمت کلاینت (با Blob)
$jsonForJs = json_encode($jsonContent, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

/**
 * کلاس رنگ badge نسخه — پایدار / بتا / قدیمی / آلفا
 */
$badgeClass = static function (string $version): string {
    $v = strtolower($version);
    if (strpos($v, 'alpha') !== false || strpos($v, '-a') !== false) return 'is-alpha';
    if (strpos($v, 'beta') !== false || strpos($v, 'rc') !== false || strpos($v, '-b') !== false) return 'is-beta';
    if (preg_match('/^0\.\d+/', $v) || version_compare($v, '1.0.0', '<')) return 'is-old';
    return 'is-stable';
};

?>
<link rel="stylesheet" href="<?php echo htmlspecialchars($assetUrl('panel.css')); ?>">
<div class="tr-panel tr-panel-pluginseditor" dir="rtl" id="pluginseditor-panel">

    <!-- ===================== هدر پنل ===================== -->
    <section class="tr-card pe-hero">
        <div class="tr-card-b">
            <div class="tr-panel-head">
                <div class="tr-panel-heading">
                    <h2 class="tr-panel-title">ویرایشگر پلاگین‌ها</h2>
                    <p class="tr-panel-desc">
                        بدون ورود به هاست، فایل <code dir="ltr">plugins.json</code> واقع در ریشهٔ سایت را
                        از اینجا مدیریت کنید: افزودن، حذف و ویرایش نام و نسخهٔ پلاگین‌ها، همراه با
                        بکاپ‌گیری خودکار، جستجوی زنده و خروجی JSON.
                    </p>
                </div>
                <div class="tr-panel-pills">
                    <span class="tr-pill tr-pill-accent">نسخهٔ <?php echo htmlspecialchars(Plugin::VERSION); ?></span>
                    <span class="tr-pill"><?php echo htmlspecialchars((string)$totalPlugins); ?> پلاگین</span>
                    <span class="tr-pill"><?php echo htmlspecialchars((string)count($backups)); ?> بکاپ</span>
                </div>
            </div>

            <div class="pe-status-bar">
                <div class="pe-stat <?php echo $jsonExists ? 'is-ok' : 'is-bad'; ?>">
                    <span class="pe-stat-label">فایل:</span>
                    <strong><?php echo $jsonExists ? 'وجود دارد' : 'ایجاد نشده'; ?></strong>
                </div>
                <div class="pe-stat <?php echo $jsonWritable ? 'is-ok' : 'is-warn'; ?>">
                    <span class="pe-stat-label">قابل نوشتن:</span>
                    <strong><?php echo $jsonWritable ? 'بله' : 'خیر'; ?></strong>
                </div>
                <div class="pe-stat <?php echo $rootWritable ? 'is-ok' : 'is-warn'; ?>">
                    <span class="pe-stat-label">ریشه:</span>
                    <strong><?php echo $rootWritable ? 'قابل نوشتن' : 'نیاز به chmod'; ?></strong>
                </div>
            </div>
        </div>
    </section>

    <!-- ===================== پیام flash ===================== -->
    <?php if (is_array($flash) && !empty($flash['message'])): ?>
        <section class="tr-card pe-flash pe-flash-<?php echo htmlspecialchars($flash['type']); ?>">
            <div class="tr-card-b">
                <div class="pe-flash-body">
                    <span class="pe-flash-icon" aria-hidden="true">
                        <?php if ($flash['type'] === 'success'): ?>
                            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                        <?php else: ?>
                            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                        <?php endif; ?>
                    </span>
                    <p><?php echo htmlspecialchars($flash['message']); ?></p>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <!-- ===================== نوار ابزار: جستجو + دکمه‌ها ===================== -->
    <section class="tr-card pe-toolbar-card">
        <div class="tr-card-b">
            <div class="pe-toolbar">
                <div class="pe-search">
                    <svg class="pe-search-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                    </svg>
                    <input type="search" id="pe-search-input" placeholder="جستجوی نام پلاگین..." autocomplete="off">
                </div>
                <div class="pe-actions">
                    <button type="button" class="btn primary" id="pe-download-btn" title="دانلود فایل plugins.json فعلی">
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                        <span>دانلود JSON</span>
                    </button>
                    <button type="button" class="btn" id="pe-bulk-toggle-btn" title="ویرایش گروهی کل JSON">
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                        <span>ویرایش گروهی</span>
                    </button>
                    <button type="button" class="btn pe-btn-danger" id="pe-clear-backups-btn" title="پاک‌سازی همه فایل‌های بکاپ">
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                        <span>پاک‌سازی بکاپ‌ها</span>
                    </button>
                </div>
            </div>
        </div>
    </section>

    <!-- ===================== فرم افزودن پلاگین ===================== -->
    <section class="tr-card pe-add-card" id="pe-add">
        <div class="tr-card-b">
            <h3 class="pe-section-title">افزودن پلاگین جدید</h3>
            <form method="post" action="<?php echo htmlspecialchars($panelUrl); ?>" class="pe-add-form">
                <input type="hidden" name="_" value="<?php echo htmlspecialchars($csrfToken); ?>">
                <input type="hidden" name="do" value="add">
                <div class="pe-form-row">
                    <input type="text" name="name" placeholder="نام پلاگین (مثال: BackupRestore)"
                           pattern="^[A-Za-z][A-Za-z0-9_\-]*$" required>
                    <input type="text" name="version" placeholder="نسخه (مثال: 1.0.0)"
                           pattern="^[0-9]+(\.[0-9a-zA-Z]+)*$" required class="pe-input-version">
                    <button type="submit" class="btn primary">
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                        <span>افزودن</span>
                    </button>
                </div>
            </form>
        </div>
    </section>

    <!-- ===================== جدول پلاگین‌ها ===================== -->
    <section class="tr-card pe-table-card">
        <div class="tr-card-b">
            <h3 class="pe-section-title">فهرست پلاگین‌ها</h3>

            <?php if (empty($plugins)): ?>
                <div class="pe-empty">
                    <svg viewBox="0 0 24 24" width="36" height="36" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
                    <p>هیچ پلاگینی یافت نشد.</p>
                    <small>از فرم بالا افزودن را شروع کنید.</small>
                </div>
            <?php else: ?>
                <table class="pe-table" id="pe-plugins-table">
                    <thead>
                        <tr>
                            <th class="pe-col-name">نام پلاگین</th>
                            <th class="pe-col-ver">نسخه</th>
                            <th class="pe-col-ops">عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($plugins as $pName => $pVersion): ?>
                            <tr class="pe-row" data-name="<?php echo htmlspecialchars($pName); ?>">
                                <td class="pe-name">
                                    <code dir="ltr"><?php echo htmlspecialchars($pName); ?></code>
                                </td>
                                <td>
                                    <span class="pe-badge <?php echo $badgeClass((string)$pVersion); ?>"
                                          title="نسخه: <?php echo htmlspecialchars($pVersion); ?>">
                                        <?php echo htmlspecialchars($pVersion); ?>
                                    </span>
                                </td>
                                <td class="pe-col-ops">
                                    <button type="button" class="btn pe-edit-btn"
                                            data-name="<?php echo htmlspecialchars($pName); ?>"
                                            data-version="<?php echo htmlspecialchars($pVersion); ?>">
                                        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                        <span>ویرایش</span>
                                    </button>
                                    <form method="post" action="<?php echo htmlspecialchars($panelUrl); ?>" style="display:inline;">
                                        <input type="hidden" name="_" value="<?php echo htmlspecialchars($csrfToken); ?>">
                                        <input type="hidden" name="do" value="delete">
                                        <input type="hidden" name="name" value="<?php echo htmlspecialchars($pName); ?>">
                                        <button type="submit" class="btn pe-btn-danger pe-delete-btn"
                                                onclick="return confirm('پلاگین «<?php echo htmlspecialchars($pName, ENT_QUOTES); ?>» حذف شود؟');">
                                            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                                            <span>حذف</span>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <!-- ردیف اسلایدی ویرایش inline (پنهان به‌صورت پیش‌فرض) -->
                            <tr class="pe-edit-row" style="display:none;">
                                <td colspan="3" style="padding:0;border:0;">
                                    <div class="pe-edit-slider">
                                        <form method="post" action="<?php echo htmlspecialchars($panelUrl); ?>" class="pe-inline-edit-form">
                                            <input type="hidden" name="_" value="<?php echo htmlspecialchars($csrfToken); ?>">
                                            <input type="hidden" name="do" value="edit">
                                            <input type="hidden" name="old_name" class="pe-old-name">
                                            <div class="pe-edit-row-form">
                                                <input type="text" name="name" class="pe-new-name"
                                                       placeholder="نام جدید" required>
                                                <input type="text" name="version" class="pe-new-version"
                                                       placeholder="نسخه جدید" required class="pe-input-version">
                                                <button type="submit" class="btn primary">
                                                    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                                                    <span>ذخیره</span>
                                                </button>
                                                <button type="button" class="btn pe-cancel-edit">
                                                    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                                                    <span>لغو</span>
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===================== ویرایش گروهی JSON ===================== -->
    <section class="tr-card pe-bulk-card" id="pe-bulk">
        <div class="tr-card-b">
            <div class="pe-bulk-head" id="pe-bulk-head">
                <h3 class="pe-section-title">
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
                    ویرایش گروهی — ویرایش مستقیم کل JSON
                </h3>
                <svg class="pe-bulk-toggle" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
            </div>
            <div class="pe-bulk-body" id="pe-bulk-body">
                <form method="post" action="<?php echo htmlspecialchars($panelUrl); ?>">
                    <input type="hidden" name="_" value="<?php echo htmlspecialchars($csrfToken); ?>">
                    <input type="hidden" name="do" value="save_all">
                    <textarea name="bulk_json" spellcheck="false" id="pe-bulk-textarea"><?php
                        $decoded = json_decode($jsonContent, true);
                        if (is_array($decoded)) {
                            ksort($decoded);
                            echo htmlspecialchars(json_encode($decoded,
                                JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
                        } else {
                            echo htmlspecialchars($jsonContent);
                        }
                    ?></textarea>
                    <div class="pe-bulk-actions">
                        <button type="submit" class="btn primary"
                                onclick="return confirm('کل فایل plugins.json بازنویسی شود؟ (یک بکاپ خودکار گرفته می‌شود)');">
                            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                            <span>ذخیره کل JSON</span>
                        </button>
                        <button type="button" class="btn" id="pe-bulk-format">
                            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="21" y1="10" x2="3" y2="10"/><line x1="21" y1="6" x2="3" y2="6"/><line x1="21" y1="14" x2="3" y2="14"/><line x1="17" y1="18" x2="3" y2="18"/></svg>
                            <span>مرتب‌سازی (Format)</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </section>

    <!-- ===================== وضعیت محیط + بکاپ‌ها ===================== -->
    <section class="tr-card pe-env-card">
        <div class="tr-card-b">
            <h3 class="pe-section-title">وضعیت فایل و بکاپ‌ها</h3>
            <ul class="pe-checks">
                <li class="<?php echo $jsonExists ? 'is-ok' : 'is-bad'; ?>">
                    فایل <code dir="ltr"><?php echo htmlspecialchars($jsonPath); ?></code>
                    <?php echo $jsonExists ? 'در محل خود قرار دارد.' : 'هنوز ایجاد نشده است.'; ?>
                </li>
                <li class="<?php echo $jsonWritable ? 'is-ok' : 'is-warn'; ?>">
                    وضعیت نوشتن: <?php echo $jsonWritable ? 'قابل نوشتن' : 'نیاز به chmod 644'; ?>
                </li>
                <li class="is-ok">
                    پوشهٔ بکاپ‌ها: <code dir="ltr"><?php echo htmlspecialchars(dirname($jsonPath)); ?>/backups/</code>
                    — تعداد نگه‌داری‌شده: <strong><?php echo (int)$backupCount; ?></strong>
                </li>
            </ul>

            <?php if (!empty($backups)): ?>
                <h4 class="pe-subsection-title">نسخه‌های پشتیبان (<?php echo count($backups); ?> فایل)</h4>
                <ul class="pe-backups-list">
                    <?php foreach ($backups as $backup): ?>
                        <li>
                            <code dir="ltr"><?php echo htmlspecialchars($backup['name']); ?></code>
                            <span class="pe-bak-meta"><?php echo htmlspecialchars($backup['size']); ?> · <?php echo htmlspecialchars($backup['date']); ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p class="pe-backups-empty">هنوز بکاپی ساخته نشده است. پس از اولین تغییر، یک بکاپ خودکار ایجاد می‌شود.</p>
            <?php endif; ?>
        </div>
    </section>

</div>

<script>
window.PE_DATA = {
    jsonContent: <?php echo $jsonForJs; ?>,
    csrfToken: <?php echo json_encode($csrfToken); ?>,
    panelUrl: <?php echo json_encode($panelUrl); ?>
};
</script>
<script src="<?php echo htmlspecialchars($assetUrl('panel.js')); ?>"></script>

<?php

/**
 * کلاس کمکی برای عملیات روی فایل JSON
 */
class PeHelper
{
    public static function readJson(string $path): array
    {
        if (!file_exists($path)) return [];
        $content = @file_get_contents($path);
        if ($content === false) return [];
        $data = json_decode($content, true);
        return is_array($data) ? $data : [];
    }

    public static function writeJson(string $path, array $data): void
    {
        $dir = dirname($path);
        if (!is_dir($dir)) {
            throw new \RuntimeException('پوشهٔ فایل وجود ندارد: ' . $dir);
        }
        if (!is_writable($dir)) {
            throw new \RuntimeException('پوشهٔ قابل نوشتن نیست: ' . $dir);
        }
        ksort($data);
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            throw new \RuntimeException('خطا در تبدیل به JSON: ' . json_last_error_msg());
        }
        $tmp = $path . '.tmp.' . getmypid();
        if (file_put_contents($tmp, $json) === false) {
            throw new \RuntimeException('خطا در ایجاد فایل موقت.');
        }
        if (!@rename($tmp, $path)) {
            @unlink($tmp);
            throw new \RuntimeException('خطا در جایگزینی فایل اصلی.');
        }
        @chmod($path, 0644);
    }

    public static function backupJson(string $path, int $max = 5): void
    {
        if ($max <= 0 || !file_exists($path)) return;
        $backupDir = dirname($path) . '/backups';
        if (!is_dir($backupDir)) {
            @mkdir($backupDir, 0755, true);
            @file_put_contents($backupDir . '/index.html', '');
        }
        if (!is_writable($backupDir)) return;
        $backupFile = $backupDir . '/plugins-' . date('Y-m-d-His') . '.json';
        @copy($path, $backupFile);
        $backups = self::listBackups(dirname($path));
        if (count($backups) > $max) {
            usort($backups, fn($a, $b) => strcmp($b['name'], $a['name']));
            for ($i = $max; $i < count($backups); $i++) {
                @unlink($backupDir . '/' . $backups[$i]['name']);
            }
        }
    }

    public static function listBackups(string $rootDir): array
    {
        $backupDir = $rootDir . '/backups';
        if (!is_dir($backupDir)) return [];
        $files = glob($backupDir . '/plugins-*.json') ?: [];
        rsort($files);
        $list = [];
        foreach ($files as $f) {
            $list[] = [
                'name' => basename($f),
                'size' => self::formatSize((int) filesize($f)),
                'date' => date('Y/m/d H:i', (int) filemtime($f)),
            ];
        }
        return $list;
    }

    public static function clearBackups(string $rootDir): int
    {
        $backupDir = $rootDir . '/backups';
        if (!is_dir($backupDir)) return 0;
        $files = glob($backupDir . '/plugins-*.json') ?: [];
        $count = 0;
        foreach ($files as $f) {
            if (@unlink($f)) $count++;
        }
        return $count;
    }

    public static function formatSize(int $bytes): string
    {
        if ($bytes < 1024) return $bytes . ' B';
        if ($bytes < 1048576) return round($bytes / 1024, 1) . ' KB';
        return round($bytes / 1048576, 1) . ' MB';
    }
}
