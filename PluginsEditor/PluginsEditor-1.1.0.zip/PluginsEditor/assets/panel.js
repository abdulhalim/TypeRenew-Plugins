/**
 * افزونهٔ ویرایشگر پلاگین‌ها — رفتار سمت مرورگر
 * (جستجوی زنده، اسلاید toggle ویرایش inline، ویرایش گروهی،
 *  دانلود JSON با Blob، پاک‌سازی بکاپ‌ها با POST، Escape برای بستن)
 */
(function () {
    'use strict';

    var panel = document.getElementById('pluginseditor-panel');
    if (!panel) return;

    // ============================================================
    // 1) جستجوی زنده روی جدول پلاگین‌ها
    // ============================================================
    var searchInput = document.getElementById('pe-search-input');
    var tableRows = document.querySelectorAll('#pe-plugins-table .pe-row');

    if (searchInput) {
        searchInput.addEventListener('input', function (e) {
            var query = e.target.value.trim().toLowerCase();
            tableRows.forEach(function (row) {
                var name = (row.getAttribute('data-name') || '').toLowerCase();
                var visible = (query === '' || name.indexOf(query) !== -1);
                row.style.display = visible ? '' : 'none';
                if (!visible) {
                    var next = row.nextElementSibling;
                    if (next && next.classList.contains('pe-edit-row')) {
                        next.style.display = 'none';
                        row.classList.remove('editing');
                    }
                }
            });
        });
    }

    // ============================================================
    // 2) اسلاید toggle برای ویرایش inline هر ردیف
    // ============================================================
    document.querySelectorAll('.pe-edit-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var row = btn.closest('tr.pe-row');
            var editRow = row.nextElementSibling;

            // بستن همهٔ ردیف‌های باز
            document.querySelectorAll('.pe-edit-row').forEach(function (er) {
                if (er !== editRow && er.style.display !== 'none') {
                    er.style.display = 'none';
                    var mainRow = er.previousElementSibling;
                    if (mainRow) mainRow.classList.remove('editing');
                }
            });

            var isOpen = editRow.style.display !== 'none';
            if (isOpen) {
                editRow.style.display = 'none';
                row.classList.remove('editing');
                return;
            }

            // مقداردهی اولیه فیلدها
            var name = btn.getAttribute('data-name');
            var version = btn.getAttribute('data-version');
            editRow.querySelector('.pe-old-name').value = name;
            editRow.querySelector('.pe-new-name').value = name;
            editRow.querySelector('.pe-new-version').value = version;
            editRow.style.display = '';
            row.classList.add('editing');
            editRow.querySelector('.pe-new-name').focus();
        });
    });

    // دکمه لغو در ویرایش inline
    document.querySelectorAll('.pe-cancel-edit').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var row = btn.closest('tr.pe-edit-row');
            row.style.display = 'none';
            var mainRow = row.previousElementSibling;
            if (mainRow) mainRow.classList.remove('editing');
        });
    });

    // ============================================================
    // 3) باکس ویرایش گروهی — اسلایدر باز/بسته
    // ============================================================
    var bulkHead = document.getElementById('pe-bulk-head');
    var bulkBody = document.getElementById('pe-bulk-body');
    var bulkToggleBtn = document.getElementById('pe-bulk-toggle-btn');

    function toggleBulk() {
        if (!bulkHead || !bulkBody) return;
        bulkBody.classList.toggle('is-open');
        bulkHead.classList.toggle('is-open');
    }

    if (bulkHead) bulkHead.addEventListener('click', toggleBulk);
    if (bulkToggleBtn) {
        bulkToggleBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            if (bulkHead) bulkHead.scrollIntoView({ behavior: 'smooth', block: 'start' });
            toggleBulk();
        });
    }

    // مرتب‌سازی JSON در باکس ویرایش گروهی
    var formatBtn = document.getElementById('pe-bulk-format');
    if (formatBtn) {
        formatBtn.addEventListener('click', function () {
            var textarea = document.getElementById('pe-bulk-textarea');
            if (!textarea) return;
            try {
                var parsed = JSON.parse(textarea.value);
                var sorted = {};
                Object.keys(parsed).sort().forEach(function (k) {
                    sorted[k] = parsed[k];
                });
                textarea.value = JSON.stringify(sorted, null, 2);
            } catch (err) {
                alert('JSON نامعتبر است. لطفاً ابتدا آن را اصلاح کنید.\n\nخطا: ' + err.message);
            }
        });
    }

    // ============================================================
    // 4) دانلود JSON با Blob (بدون URL navigation → حل مشکل routing)
    // ============================================================
    var downloadBtn = document.getElementById('pe-download-btn');
    if (downloadBtn && window.PE_DATA && window.PE_DATA.jsonContent) {
        downloadBtn.addEventListener('click', function () {
            try {
                var content = window.PE_DATA.jsonContent;
                var blob = new Blob([content], { type: 'application/json;charset=utf-8' });
                var url = URL.createObjectURL(blob);
                var a = document.createElement('a');
                a.href = url;
                var now = new Date();
                var pad = function (n) { return String(n).padStart(2, '0'); };
                var ts = now.getFullYear() + '-' + pad(now.getMonth() + 1) + '-' + pad(now.getDate())
                       + '-' + pad(now.getHours()) + pad(now.getMinutes()) + pad(now.getSeconds());
                a.download = 'plugins-' + ts + '.json';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                setTimeout(function () { URL.revokeObjectURL(url); }, 200);
            } catch (err) {
                alert('خطا در ایجاد فایل دانلود: ' + err.message);
            }
        });
    }

    // ============================================================
    // 5) پاک‌سازی بکاپ‌ها با POST (به‌جای GET که مشکل routing داشت)
    // ============================================================
    var clearBackupsBtn = document.getElementById('pe-clear-backups-btn');
    if (clearBackupsBtn && window.PE_DATA && window.PE_DATA.panelUrl) {
        clearBackupsBtn.addEventListener('click', function () {
            if (!confirm('همهٔ فایل‌های بکاپ پاک شوند؟ این عمل قابل بازگشت نیست.')) return;

            var form = document.createElement('form');
            form.method = 'POST';
            form.action = window.PE_DATA.panelUrl;
            form.style.display = 'none';

            var token = document.createElement('input');
            token.type = 'hidden';
            token.name = '_';
            token.value = window.PE_DATA.csrfToken || '';
            form.appendChild(token);

            var action = document.createElement('input');
            action.type = 'hidden';
            action.name = 'do';
            action.value = 'clear_backups';
            form.appendChild(action);

            document.body.appendChild(form);
            form.submit();
        });
    }

    // ============================================================
    // 6) کلید میانبر Escape برای بستن فرم ویرایش inline
    // ============================================================
    document.addEventListener('keydown', function (e) {
        if (e.key !== 'Escape') return;
        var openEdit = document.querySelector('.pe-edit-row[style*="display: table-row"], .pe-edit-row:not([style*="none"])');
        if (openEdit && openEdit.style.display !== 'none') {
            openEdit.style.display = 'none';
            var mainRow = openEdit.previousElementSibling;
            if (mainRow) mainRow.classList.remove('editing');
        }
    });

})();
