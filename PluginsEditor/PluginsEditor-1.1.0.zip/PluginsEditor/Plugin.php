<?php
declare(strict_types=1);

namespace TypechoPlugin\PluginsEditor;

use Typecho\Plugin\PluginInterface;
use Utils\Helper;
use Utils\NoPersonal;
use Typecho\Widget\Helper\Form;
use Widget\Options;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * مدیریت نسخه افزونه‌ها
 * @package PluginsEditor
 * @link    https://pourdaryaei.ir/
 * @author پوردریایی
 * @version 1.1.0
 * @since   1.6.1
 */
class Plugin implements PluginInterface
{
    use NoPersonal;

    /** نام افزونه */
    public const NAME = 'PluginsEditor';

    /** نسخهٔ افزونه */
    public const VERSION = '1.1.0';

    /** فایل پنل مدیریت */
    public const PANEL_FILE = 'PluginsEditor/Panel.php';

    /** شماره بخش منوی مدیریت (5 = افزونه‌ها) */
    public const PANEL_MENU = 5;

    /** کلید پیام flash در نشست */
    public const SESSION_FLASH_KEY = '__pluginseditor_flash';

    /** کش تنظیمات افزونه */
    private static ?array $settingsCache = null;

    /**
     * فعال‌سازی: ثبت پنل در منوی مدیریت
     */
    public static function activate(): string
    {
        Helper::removePanel(self::PANEL_MENU, self::PANEL_FILE);
        Helper::addPanel(
            self::PANEL_MENU,
            self::PANEL_FILE,
            'ویرایشگر پلاگین‌ها',
            'مدیریت فایل plugins.json',
            'administrator',
            false,
            '',
            ['icon' => 'i-puzzle']
        );

        // ایجاد پوشه backups در ریشه سایت (در صورت عدم وجود)
        $backupDir = rtrim(__TYPECHO_ROOT_DIR__, '/') . '/backups';
        if (!is_dir($backupDir)) {
            @mkdir($backupDir, 0755, true);
            @file_put_contents($backupDir . '/index.html', '');
        }

        // ایجاد فایل plugins.json اولیه در صورت عدم وجود
        $jsonPath = rtrim(__TYPECHO_ROOT_DIR__, '/') . '/plugins.json';
        if (!file_exists($jsonPath)) {
            @file_put_contents($jsonPath, "{\n  \"PluginsEditor\": \"" . self::VERSION . "\"\n}\n");
        }

        return 'افزونهٔ «ویرایشگر پلاگین‌ها» فعال شد؛ از بخش «افزونه‌ها» در پنل مدیریت می‌توانید فایل plugins.json را ویرایش کنید.';
    }

    /**
     * غیرفعال‌سازی: حذف پنل
     */
    public static function deactivate(): string
    {
        Helper::removePanel(self::PANEL_MENU, self::PANEL_FILE);
        return 'افزونهٔ «ویرایشگر پلاگین‌ها» غیرفعال شد. (فایل plugins.json و پوشهٔ backups دست‌نخورده باقی ماند)';
    }

    /**
     * تنظیمات افزونه
     */
    public static function config(Form $form): void
    {
        $jsonPath = new Form\Element\Text(
            'jsonPath',
            null,
            'plugins.json',
            'مسیر فایل plugins.json',
            'مسیر فایل JSON نسبت به ریشهٔ CMS. مثال: <code>plugins.json</code> (پیش‌فرض) یا <code>../plugins.json</code> (یک سطح بالاتر).'
        );
        $form->addInput($jsonPath);

        $backupCount = new Form\Element\Number(
            'backupCount',
            null,
            5,
            'تعداد نسخه‌های پشتیبان',
            'تعداد نسخه‌های قدیمی فایل که در پوشهٔ <code>backups/</code> نگه‌داری می‌شوند. صفر = بدون بکاپ.'
        );
        $backupCount->setAttribute('min', 0);
        $backupCount->setAttribute('max', 100);
        $form->addInput($backupCount);
    }

    /**
     * خواندن تنظیمات با مقادیر پیش‌فرض امن
     */
    public static function settings(): array
    {
        if (self::$settingsCache !== null) {
            return self::$settingsCache;
        }

        $settings = [
            'jsonPath'    => 'plugins.json',
            'backupCount' => 5,
        ];

        try {
            $config = Options::alloc()->plugin(self::NAME);
            $stored = method_exists($config, 'toArray') ? (array) $config->toArray() : [];
        } catch (\Throwable) {
            $stored = [];
        }

        if (isset($stored['jsonPath']) && is_string($stored['jsonPath']) && $stored['jsonPath'] !== '') {
            $settings['jsonPath'] = $stored['jsonPath'];
        }

        if (isset($stored['backupCount'])) {
            $val = is_scalar($stored['backupCount']) ? (int) $stored['backupCount'] : 5;
            $settings['backupCount'] = max(0, min(100, $val));
        }

        return self::$settingsCache = $settings;
    }

    /** نشانی صفحهٔ پنل مدیریت */
    public static function panelUrl(): string
    {
        return Helper::url(self::PANEL_FILE);
    }

    /** مسیر مطلق فایل JSON */
    public static function jsonAbsolutePath(): string
    {
        $settings = self::settings();
        $path = trim($settings['jsonPath']);
        if ($path === '') {
            $path = 'plugins.json';
        }
        // مسیر مطلق
        if (preg_match('#^/|^[A-Za-z]:#', $path)) {
            return $path;
        }
        return rtrim(__TYPECHO_ROOT_DIR__, '/') . '/' . ltrim($path, '/');
    }
}
