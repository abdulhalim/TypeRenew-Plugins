<?php
declare(strict_types=1);

namespace TypechoPlugin\BluditMigrator;

use Typecho\Db;
use Widget\Plugins\Edit as PluginsEdit;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * منبع واحد برای پیکربندی پلاگین.
 *
 * پیکربندی پلاگین به‌صورت JSON در جدول typecho_options با نام plugin:BluditMigrator
 * ذخیره می‌شود (مشابه سایر پلاگین‌های TypeRenew).
 */
class Settings
{
    public static function defaults(): array
    {
        return [
            'bluditPath'      => '',
            'defaultGroup'    => 'contributor',
            'importImages'    => '1',
            'resetPasswords'  => '1',
            'lastReport'      => null,
            'lastRunAt'       => 0,
        ];
    }

    public static function load(): array
    {
        try {
            $options = \Widget\Options::alloc();
            $config  = $options->plugin(Plugin::NAME);
            $data    = [];
            foreach (self::defaults() as $key => $value) {
                if (isset($config->{$key})) {
                    $data[$key] = $config->{$key};
                }
            }
            return array_merge(self::defaults(), $data);
        } catch (\Throwable $e) {
            return self::defaults();
        }
    }

    public static function store(array $settings): void
    {
        $normalized = self::normalize($settings);
        PluginsEdit::configPlugin(Plugin::NAME, $normalized);
    }

    public static function normalize(array $settings): array
    {
        $defaults = self::defaults();
        $result   = array_merge($defaults, $settings);

        $result['bluditPath']     = self::normalizePath($result['bluditPath']);
        $result['importImages']   = $result['importImages'] === '0' ? '0' : '1';
        $result['resetPasswords'] = $result['resetPasswords'] === '0' ? '0' : '1';

        $allowedGroups = ['administrator', 'editor', 'contributor', 'subscriber', 'visitor'];
        if (!in_array($result['defaultGroup'], $allowedGroups, true)) {
            $result['defaultGroup'] = 'contributor';
        }

        $result['lastRunAt'] = isset($result['lastRunAt']) ? (int) $result['lastRunAt'] : 0;

        return $result;
    }

    private static function normalizePath($path): string
    {
        if (!is_string($path)) {
            return '';
        }
        $path = trim($path);
        if ($path === '') {
            return '';
        }
        // strip trailing slash
        return rtrim(str_replace('\\', '/', $path), '/');
    }
}
