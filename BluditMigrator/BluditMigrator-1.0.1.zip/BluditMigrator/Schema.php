<?php
declare(strict_types=1);

namespace TypechoPlugin\BluditMigrator;

use Typecho\Db;
use Utils\Schema as CoreSchema;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * نگه‌دارنده ساختار جدول نگاشت Bludit -> TypeRenew.
 *
 * جدول typecho_bludit_map برای سه هدف استفاده می‌شود:
 *  1) جلوگیری از وارد کردن دوباره همان رکورد در صورت اجرای مجدد پلاگین (Idempotency).
 *  2) حفظ رابطه شناسه بلودیت (uuid) با شناسه تایپ‌رینیو (cid/uid/mid) برای گزارش و دیباگ.
 *  3) ذخیره مسیر اصلی فایل‌های رسانه‌ای Bludit تا بتوان URL های داخل متن نوشته‌ها را بازنویسی کرد.
 */
class Schema
{
    public const TABLE = 'bludit_map';

    public static function ensure(Db $db): void
    {
        $dialect = CoreSchema::dialect($db);
        $table   = $db->getPrefix() . self::TABLE;

        $db->query(self::tableSql($db, $dialect, $table), Db::WRITE);

        foreach (self::columns($dialect) as $column => $definition) {
            if (!CoreSchema::columnExists($db, $table, $column)) {
                $db->query(
                    'ALTER TABLE ' . CoreSchema::quote($table, $dialect) . ' ADD COLUMN ' . $definition,
                    Db::WRITE
                );
            }
        }

        $idxName = static fn(string $mysql, string $other): string =>
            $dialect === 'mysql' ? $mysql : $table . '_' . $other;

        CoreSchema::ensureIndex($db, $table, $idxName('idx_kind_source', 'kind_source'), ['kind', 'source']);
        CoreSchema::ensureIndex($db, $table, $idxName('idx_kind_target', 'kind_target'), ['kind', 'target_id']);
    }

    private static function tableSql(Db $db, string $dialect, string $table): string
    {
        $name = CoreSchema::quote($table, $dialect);

        return match ($dialect) {
            'sqlite' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" INTEGER PRIMARY KEY AUTOINCREMENT,'
                . '"kind" VARCHAR(16) NOT NULL,'
                . '"source" VARCHAR(128) NOT NULL,'
                . '"target_id" INTEGER NOT NULL DEFAULT 0,'
                . '"source_meta" TEXT,'
                . '"created_at" INTEGER NOT NULL DEFAULT 0'
                . ')',
            'pgsql' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" BIGSERIAL PRIMARY KEY,'
                . '"kind" VARCHAR(16) NOT NULL,'
                . '"source" VARCHAR(128) NOT NULL,'
                . '"target_id" BIGINT NOT NULL DEFAULT 0,'
                . '"source_meta" TEXT,'
                . '"created_at" INTEGER NOT NULL DEFAULT 0'
                . ')',
            default => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '`id` bigint unsigned NOT NULL auto_increment,'
                . '`kind` varchar(16) NOT NULL,'
                . '`source` varchar(128) NOT NULL,'
                . '`target_id` bigint unsigned NOT NULL default 0,'
                . '`source_meta` text,'
                . '`created_at` int unsigned NOT NULL default 0,'
                . 'PRIMARY KEY (`id`)'
                . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=' . CoreSchema::detectMysqlCollation($db),
        };
    }

    private static function columns(string $dialect): array
    {
        if ($dialect === 'mysql') {
            return [
                'kind'       => '`kind` varchar(16) NOT NULL default \'\'',
                'source'     => '`source` varchar(128) NOT NULL default \'\'',
                'target_id'  => '`target_id` bigint unsigned NOT NULL default 0',
                'source_meta' => '`source_meta` text',
                'created_at' => '`created_at` int unsigned NOT NULL default 0',
            ];
        }

        return [
            'kind'       => '"kind" VARCHAR(16) NOT NULL DEFAULT \'\'',
            'source'     => '"source" VARCHAR(128) NOT NULL DEFAULT \'\'',
            'target_id'  => '"target_id" BIGINT NOT NULL DEFAULT 0',
            'source_meta' => '"source_meta" TEXT',
            'created_at' => '"created_at" INT NOT NULL DEFAULT 0',
        ];
    }
}
