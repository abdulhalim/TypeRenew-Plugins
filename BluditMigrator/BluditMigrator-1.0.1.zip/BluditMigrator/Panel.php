<?php
if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/** @var \Widget\User $user */
/** @var \Widget\Options $options */
/** @var \Widget\Security $security */
/** @var \Widget\Request $request */

$user->pass('administrator');

$settings = \TypechoPlugin\BluditMigrator\Settings::load();
$pluginUrl = \Typecho\Common::url('BluditMigrator/', $options->pluginUrl);

$actionPreview = \Widget\Security::alloc()->getTokenUrl(
    \Typecho\Common::url('action/bludit-migrator?do=preview', $options->index),
    'bludit-migrator-admin'
);
$actionRun = \Widget\Security::alloc()->getTokenUrl(
    \Typecho\Common::url('action/bludit-migrator?do=run', $options->index),
    'bludit-migrator-admin'
);
$actionClear = \Widget\Security::alloc()->getTokenUrl(
    \Typecho\Common::url('action/bludit-migrator?do=clear', $options->index),
    'bludit-migrator-admin'
);

$lastReport = $settings['lastReport'] ?? null;
$lastRunAt  = (int) ($settings['lastRunAt'] ?? 0);
$lastRunDate = $lastRunAt > 0
    ? (new \Typecho\Date($lastRunAt))->format('Y-m-d H:i:s')
    : '';

?>
<link rel="stylesheet" href="<?php echo htmlspecialchars($pluginUrl . 'assets/panel.css', ENT_QUOTES, 'UTF-8'); ?>">

<div class="tr-panel bludit-migrator-panel" dir="rtl">

    <section class="tr-card bm-card bm-hero">
        <div class="tr-card-b">
            <div class="bm-hero-row">
                <div class="bm-hero-text">
                    <h2><?php _e('مهاجرت از Bludit به TypeRenew'); ?></h2>
                    <p class="bm-hero-desc">
                        <?php _e('این افزونه محتوای کامل یک نصب Bludit شامل صفحات، نوشته‌ها، دسته‌ها، برچسب‌ها، کاربران و تصاویر را به پایگاه داده TypeRenew منتقل می‌کند.'); ?>
                    </p>
                    <p class="bm-hero-note">
                        <?php _e('پیش از اجرا، حتماً از پایگاه داده TypeRenew پشتیبان بگیرید. این عملیات قابل بازگشت نیست.'); ?>
                    </p>
                </div>
                <div class="bm-hero-pill">
                    <span class="tr-pill tr-pill-accent">v1.0.0</span>
                </div>
            </div>
        </div>
    </section>

    <?php if (!empty($lastReport) && is_array($lastReport)): ?>
        <section class="tr-card bm-card">
            <div class="tr-card-h">
                <h3><?php _e('گزارش آخرین مهاجرت'); ?>
                    <?php if ($lastRunDate !== ''): ?>
                        <span class="bm-last-date"><?php echo htmlspecialchars($lastRunDate, ENT_QUOTES, 'UTF-8'); ?></span>
                    <?php endif; ?>
                </h3>
            </div>
            <div class="tr-card-b">
                <div class="bm-stats-grid">
                    <div class="bm-stat"><strong><?php echo (int) ($lastReport['stats']['users'] ?? 0); ?></strong><span><?php _e('کاربران جدید'); ?></span></div>
                    <div class="bm-stat"><strong><?php echo (int) ($lastReport['stats']['users_skipped'] ?? 0); ?></strong><span><?php _e('کاربران رد شده'); ?></span></div>
                    <div class="bm-stat"><strong><?php echo (int) ($lastReport['stats']['categories'] ?? 0); ?></strong><span><?php _e('دسته‌های جدید'); ?></span></div>
                    <div class="bm-stat"><strong><?php echo (int) ($lastReport['stats']['posts'] ?? 0); ?></strong><span><?php _e('نوشته‌های جدید'); ?></span></div>
                    <div class="bm-stat"><strong><?php echo (int) ($lastReport['stats']['pages'] ?? 0); ?></strong><span><?php _e('صفحات جدید'); ?></span></div>
                    <div class="bm-stat"><strong><?php echo (int) ($lastReport['stats']['media'] ?? 0); ?></strong><span><?php _e('فایل‌های رسانه‌ای'); ?></span></div>
                    <div class="bm-stat"><strong><?php echo (int) ($lastReport['stats']['tags'] ?? 0); ?></strong><span><?php _e('تخصیص برچسب‌ها'); ?></span></div>
                    <div class="bm-stat bm-stat-error"><strong><?php echo (int) ($lastReport['stats']['errors'] ?? 0); ?></strong><span><?php _e('خطاها'); ?></span></div>
                </div>

                <?php if (!empty($lastReport['errors'])): ?>
                    <details class="bm-error-details">
                        <summary><?php _e('نمایش خطاها'); ?> (<?php echo count($lastReport['errors']); ?>)</summary>
                        <ul class="bm-error-list">
                            <?php foreach (array_slice($lastReport['errors'], 0, 50) as $err): ?>
                                <li><?php echo htmlspecialchars((string) $err, ENT_QUOTES, 'UTF-8'); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </details>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <section class="tr-card bm-card">
        <div class="tr-card-h">
            <h3><?php _e('تنظیم مهاجرت'); ?></h3>
        </div>
        <div class="tr-card-b">
            <form id="bludit-migrator-form" class="bm-form" autocomplete="off">
                <div class="bm-field">
                    <label for="bm-bludit-path"><?php _e('مسیر ریشه نصب Bludit'); ?></label>
                    <input type="text" id="bm-bludit-path" name="bluditPath" class="tr-panel-input w-100"
                           value="<?php echo htmlspecialchars((string) $settings['bluditPath'], ENT_QUOTES, 'UTF-8'); ?>"
                           placeholder="/var/www/bludit">
                    <p class="bm-hint"><?php _e('مسیر مطلق پوشه‌ای که فایل‌های Bludit در آن نصب است (همان پوشه که شامل bl-content/ و bl-kernel/ است).'); ?></p>
                </div>

                <div class="bm-row">
                    <div class="bm-field">
                        <label for="bm-default-group"><?php _e('گروه پیش‌فرض کاربران'); ?></label>
                        <select id="bm-default-group" name="defaultGroup" class="tr-panel-input">
                            <?php
                            $groups = [
                                'administrator' => _t('مدیر'),
                                'editor'        => _t('ویراستار'),
                                'contributor'   => _t('مشارکت‌کننده'),
                                'subscriber'    => _t('مشترک'),
                                'visitor'       => _t('بازدیدکننده'),
                            ];
                            $currentGroup = $settings['defaultGroup'] ?? 'contributor';
                            foreach ($groups as $g => $label):
                                ?>
                                <option value="<?php echo $g; ?>" <?php echo $currentGroup === $g ? 'selected' : ''; ?>>
                                    <?php echo $label; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="bm-field">
                        <label><?php _e('انتقال تصاویر'); ?></label>
                        <label class="bm-radio"><input type="radio" name="importImages" value="1"
                                <?php echo ($settings['importImages'] ?? '1') === '1' ? 'checked' : ''; ?>>
                            <?php _e('بله، تصاویر را کپی کن'); ?>
                        </label>
                        <label class="bm-radio"><input type="radio" name="importImages" value="0"
                                <?php echo ($settings['importImages'] ?? '1') === '0' ? 'checked' : ''; ?>>
                            <?php _e('خیر، فقط URL ها را بازنویسی کن'); ?>
                        </label>
                    </div>

                    <div class="bm-field">
                        <label><?php _e('رمز عبور کاربران'); ?></label>
                        <label class="bm-radio"><input type="radio" name="resetPasswords" value="1"
                                <?php echo ($settings['resetPasswords'] ?? '1') === '1' ? 'checked' : ''; ?>>
                            <?php _e('رمز جدید تصادفی'); ?>
                        </label>
                        <label class="bm-radio"><input type="radio" name="resetPasswords" value="0"
                                <?php echo ($settings['resetPasswords'] ?? '1') === '0' ? 'checked' : ''; ?>>
                            <?php _e('سعی با رمز قدیمی'); ?> *
                        </label>
                        <p class="bm-hint">* <?php _e('Bludit از SHA1 استفاده می‌کند که در TypeRenew قابل استفاده نیست؛ این گزینه معمولاً کار نمی‌کند.'); ?></p>
                    </div>
                </div>

                <div class="bm-actions">
                    <button type="button" id="bm-preview-btn" class="btn primary">
                        <?php _e('پیش‌نمایش'); ?>
                    </button>
                    <button type="button" id="bm-run-btn" class="btn btn-warn">
                        <?php _e('اجرای مهاجرت'); ?>
                    </button>
                </div>
            </form>
        </div>
    </section>

    <section class="tr-card bm-card">
        <div class="tr-card-h">
            <h3><?php _e('پیش‌نمایش منبع'); ?></h3>
        </div>
        <div class="tr-card-b">
            <div id="bm-preview-area" class="bm-preview-area">
                <div class="bm-preview-empty"><?php _e('هنوز پیش‌نمایشی گرفته نشده است. روی دکمه «پیش‌نمایش» بزنید.'); ?></div>
            </div>
        </div>
    </section>

    <section class="tr-card bm-card">
        <div class="tr-card-h">
            <h3><?php _e('مدیریت نگاشت‌ها'); ?></h3>
        </div>
        <div class="tr-card-b">
            <p class="bm-hint"><?php _e('اگر می‌خواهید مهاجرت را از ابتدا اجرا کنید، نگاشت‌های قبلی را پاک کنید. توجه: رکوردهای وارد شده در TypeRenew حذف نمی‌شوند.'); ?></p>
            <button type="button" id="bm-clear-btn" class="btn btn-s btn-danger">
                <?php _e('پاک‌سازی جدول نگاشت'); ?>
            </button>
        </div>
    </section>

</div>

<script>
window.BluditMigratorPanel = <?php echo json_encode([
    'preview' => $actionPreview,
    'run'     => $actionRun,
    'clear'   => $actionClear,
    'i18n' => [
        'confirmRun'    => _t('آیا مطمئن هستید؟ این عملیات محتوای Bludit را در TypeRenew وارد می‌کند. از پایگاه داده TypeRenew پشتیبان گرفته‌اید؟'),
        'confirmClear'  => _t('آیا از پاک‌سازی جدول نگاشت مطمئن هستید؟'),
        'previewFailed' => _t('پیش‌نمایش ناموفق بود'),
        'running'       => _t('در حال اجرای مهاجرت...'),
        'done'          => _t('مهاجرت کامل شد'),
        'users'         => _t('کاربران'),
        'categories'    => _t('دسته‌ها'),
        'tags'          => _t('برچسب‌ها'),
        'posts'         => _t('نوشته‌ها'),
        'pages'         => _t('صفحات'),
        'drafts'        => _t('پیش‌نویس‌ها'),
        'media'         => _t('رسانه‌ها'),
        'existing'      => _t('نگاشت‌های موجود'),
        'siteTitle'      => _t('عنوان سایت'),
        'siteUrl'        => _t('URL سایت'),
        'siteLang'       => _t('زبان'),
        'siteTimezone'   => _t('منطقه زمانی'),
    ]
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;
</script>
<script src="<?php echo htmlspecialchars($pluginUrl . 'assets/panel.js', ENT_QUOTES, 'UTF-8'); ?>"></script>
