<?php
declare(strict_types=1);

namespace TypechoPlugin\BluditMigrator;

use Typecho\Common;
use Typecho\Db;
use Utils\Helper;
use Utils\Password;
use Widget\Base\Contents;
use Widget\Base\Metas;
use Widget\Base\Users;
use Widget\Upload;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * موتور اصلی مهاجرت Bludit -> TypeRenew.
 *
 * این کلاس وظیفه نگاشت هر موجودیت Bludit به مدل داده TypeRenew را بر عهده دارد.
 * همه نوشتن‌ها در یک transaction پیچیده می‌شود تا در صورت بروز خطا،
 * چرخش کامل به عقب (rollback) انجام شود. برای جلوگیری از وارد کردن مجدد،
 * از فیلد سفارشی bludit_uuid و جدول typecho_bludit_map استفاده می‌شود.
 */
class Importer
{
    private Db $db;
    private Reader $reader;
    private array $settings;

    /** نگاشت username -> uid */
    private array $userMap = [];
    /** نگاشت bludit_category_key -> mid */
    private array $categoryMap = [];
    /** نگاشت bludit_page_uuid -> cid */
    private array $contentMap = [];
    /** نگاشت bludit_page_key -> cid (برای parent/child) */
    private array $contentKeyMap = [];
    /** نگاشت مسیر قدیمی آپلود -> URL جدید TypeRenew */
    private array $mediaUrlMap = [];

    private array $stats = [
        'users'       => 0, 'users_skipped' => 0,
        'categories'  => 0, 'categories_skipped' => 0,
        'posts'       => 0, 'posts_skipped' => 0,
        'pages'       => 0, 'pages_skipped' => 0,
        'tags'        => 0,
        'media'       => 0, 'media_skipped' => 0,
        'errors'      => 0,
    ];

    private array $errors = [];

    public function __construct(Reader $reader, array $settings)
    {
        $this->db       = Db::get();
        $this->reader   = $reader;
        $this->settings = $settings;
    }

    /**
     * پیش‌نمایش بدون اعمال: فقط آمار می‌دهد.
     */
    public function preview(): array
    {
        $site       = $this->reader->readSite();
        $users      = $this->reader->readUsers();
        $categories = $this->reader->readCategories();
        $pagesIndex = $this->reader->readPagesIndex();

        $posts  = 0;
        $static = 0;
        $drafts = 0;
        foreach ($pagesIndex as $row) {
            $type = $row['type'] ?? 'published';
            if ($type === 'static') {
                $static++;
            } elseif ($type === 'draft' || $type === 'autosave') {
                $drafts++;
            } else {
                $posts++;
            }
        }

        return [
            'valid'       => $this->reader->isValid(),
            'site'         => [
                'title'       => $site['title'] ?? '',
                'slogan'      => $site['slogan'] ?? '',
                'description' => $site['description'] ?? '',
                'url'         => $site['url'] ?? '',
                'language'    => $site['language'] ?? '',
                'timezone'    => $site['timezone'] ?? '',
            ],
            'users'        => count($users),
            'categories'   => count($categories),
            'tags'         => count($this->reader->readTags()),
            'posts'        => $posts,
            'pages'        => $static,
            'drafts'       => $drafts,
            'media_total' => $this->countMediaFiles(),
            'existing'     => $this->countExistingImports(),
        ];
    }

    /**
     * اجرای کامل مهاجرت با transaction.
     */
    public function run(): array
    {
        $this->stats = [
            'users' => 0, 'users_skipped' => 0,
            'categories' => 0, 'categories_skipped' => 0,
            'posts' => 0, 'posts_skipped' => 0,
            'pages' => 0, 'pages_skipped' => 0,
            'tags' => 0,
            'media' => 0, 'media_skipped' => 0,
            'errors' => 0,
        ];
        $this->errors = [];

        if (!$this->reader->isValid()) {
            $this->errors[] = _t('مسیر Bludit معتبر نیست؛ فایل‌های دیتابیس یافت نشدند');
            return $this->result();
        }

        $supportsTxn = $this->supportsTransaction();
        if ($supportsTxn) {
            $this->db->query('BEGIN', Db::READ);
        }

        try {
            $this->importUsers();
            $this->importCategories();
            $this->importContent();
            $this->recountMetas();
            $this->recountCommentsNum();

            if ($supportsTxn) {
                $this->db->query('COMMIT', Db::READ);
            }
        } catch (\Throwable $e) {
            if ($supportsTxn) {
                try { $this->db->query('ROLLBACK', Db::READ); } catch (\Throwable $_) {}
            }
            $this->errors[] = $e->getMessage();
            $this->stats['errors']++;
            throw $e;
        }

        return $this->result();
    }

    private function supportsTransaction(): bool
    {
        try {
            $adapter = $this->db->getAdapter();
            $driver  = strtolower((string) $adapter::class);
            if (str_contains($driver, 'sqlite') || str_contains($driver, 'pgsql')) {
                return true;
            }
            if (str_contains($driver, 'mysql')) {
                // فقط InnoDB transaction را پشتیبانی می‌کند
                return true; // اکثر نصب‌ها InnoDB دارند؛ اگر خطا شد rollback می‌کنیم
            }
        } catch (\Throwable $_) {}
        return false;
    }

    /**
     * مهاجرت کاربران.
     */
    private function importUsers(): void
    {
        $users = $this->reader->readUsers();
        $defaultGroup = $this->settings['defaultGroup'] ?? 'contributor';
        $resetPasswords = ($this->settings['resetPasswords'] ?? '1') === '1';

        foreach ($users as $username => $row) {
            try {
                $existing = $this->findMapped('user', $username);
                if ($existing !== null) {
                    $this->userMap[$username] = (int) $existing;
                    $this->stats['users_skipped']++;
                    continue;
                }

                $group = $this->mapRole($row['role'] ?? 'author', $defaultGroup);
                $email = (string) ($row['email'] ?? '');
                if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    // اگر ایمیل معتبر نبود یک ایمیل placeholder می‌سازیم
                    $email = strtolower(preg_replace('/[^a-zA-Z0-9._-]/', '', $username)) . '@bludit-migrated.local';
                }

                // اگر کاربر با این username یا email قبلا در TypeRenew وجود داشت، همان را نگاشت می‌کنیم
                $existingUid = $this->findUserByNameOrEmail($username, $email);
                if ($existingUid !== null) {
                    $this->userMap[$username] = $existingUid;
                    $this->recordMapping('user', $username, $existingUid);
                    $this->stats['users_skipped']++;
                    continue;
                }

                $password = $resetPasswords
                    ? Password::hash(bin2hex(random_bytes(16)))
                    : Password::hash(bin2hex(random_bytes(16))); // همیشه reset می‌کنیم چون SHA1 قابل استفاده نیست

                $nickname = (string) ($row['nickname'] ?? '');
                if ($nickname === '') {
                    $first = (string) ($row['firstName'] ?? '');
                    $last  = (string) ($row['lastName'] ?? '');
                    $nickname = trim($first . ' ' . $last);
                    if ($nickname === '') {
                        $nickname = $username;
                    }
                }

                $uid = Users::alloc()->insert([
                    'name'       => $username,
                    'mail'       => $email,
                    'screenName' => $nickname,
                    'password'   => $password,
                    'url'        => '',
                    'created'    => $this->parseDate($row['registered'] ?? ''),
                    'group'      => $group,
                    'authCode'   => bin2hex(Common::secureRandomBytes(16)),
                ]);

                $this->userMap[$username] = $uid;
                $this->recordMapping('user', $username, $uid);
                $this->stats['users']++;

                // کپی تصویر پروفایل (اختیاری)
                if (($this->settings['importImages'] ?? '1') === '1') {
                    $picPath = $this->reader->findProfilePicture($username);
                    if ($picPath !== null) {
                        try {
                            $this->importProfilePicture($uid, $picPath, $username);
                        } catch (\Throwable $e) {
                            $this->errors[] = _t('خطای کپی تصویر پروفایل %s: %s', $username, $e->getMessage());
                        }
                    }
                }
            } catch (\Throwable $e) {
                $this->errors[] = _t('خطای مهاجرت کاربر %s: %s', $username, $e->getMessage());
                $this->stats['errors']++;
            }
        }
    }

    private function mapRole(string $bluditRole, string $default): string
    {
        return match (strtolower($bluditRole)) {
            'admin'      => 'administrator',
            'editor'     => 'editor',
            'author'     => 'contributor',
            default      => $default,
        };
    }

    private function findUserByNameOrEmail(string $username, string $email): ?int
    {
        try {
            $row = $this->db->fetchRow(
                $this->db->select('uid')->from('table.users')
                    ->where('name = ? OR mail = ?', $username, $email)
                    ->limit(1)
            );
            return $row ? (int) ($row['uid'] ?? 0) : null;
        } catch (\Throwable $_) {
            return null;
        }
    }

    /**
     * مهاجرت دسته‌ها (به همراه سلسله مراتب).
     */
    private function importCategories(): void
    {
        $categories = $this->reader->readCategories();
        // ابتدا دسته‌های بدون والد را وارد می‌کنیم و بعد فرزندان را
        $pending = $categories;
        $maxPasses = 5;
        while (!empty($pending) && $maxPasses-- > 0) {
            $deferred = [];
            foreach ($pending as $key => $row) {
                $parentKey = $this->extractParentCategoryKey($key, $categories);
                $parentMid = 0;
                if ($parentKey !== '' && $parentKey !== $key) {
                    $parentMid = $this->categoryMap[$parentKey] ?? null;
                    if ($parentMid === null) {
                        $deferred[$key] = $row;
                        continue;
                    }
                }

                try {
                    $existing = $this->findMapped('category', $key);
                    if ($existing !== null) {
                        $this->categoryMap[$key] = (int) $existing;
                        $this->stats['categories_skipped']++;
                        continue;
                    }

                    $name        = (string) ($row['name'] ?? $key);
                    $description = (string) ($row['description'] ?? '');
                    $slug        = $this->extractSlugFromKey($key, $name);

                    $mid = Metas::alloc()->insert([
                        'name'        => $name,
                        'slug'        => Common::slugName($slug, $name),
                        'type'        => 'category',
                        'description' => $description,
                        'parent'      => (int) $parentMid,
                        'order'       => 0,
                        'count'       => 0,
                    ]);

                    $this->categoryMap[$key] = $mid;
                    $this->recordMapping('category', $key, $mid);
                    $this->stats['categories']++;
                } catch (\Throwable $e) {
                    $this->errors[] = _t('خطای مهاجرت دسته %s: %s', $key, $e->getMessage());
                    $this->stats['errors']++;
                }
            }
            if (count($deferred) === count($pending)) {
                // هیچ پیشرفتی نشد؛ باقی مانده‌ها را به‌صورت flat وارد کن
                foreach ($deferred as $key => $row) {
                    try {
                        $name = (string) ($row['name'] ?? $key);
                        $slug = $this->extractSlugFromKey($key, $name);
                        $mid = Metas::alloc()->insert([
                            'name'  => $name,
                            'slug'  => Common::slugName($slug, $name),
                            'type'  => 'category',
                            'parent' => 0,
                            'count' => 0,
                            'order' => 0,
                            'description' => (string) ($row['description'] ?? ''),
                        ]);
                        $this->categoryMap[$key] = $mid;
                        $this->recordMapping('category', $key, $mid);
                        $this->stats['categories']++;
                    } catch (\Throwable $e) {
                        $this->errors[] = _t('خطای مهاجرت دسته %s: %s', $key, $e->getMessage());
                        $this->stats['errors']++;
                    }
                }
                break;
            }
            $pending = $deferred;
        }
    }

    /**
     * اگر کلید دسته به‌صورت parent/child است، کلید والد را برمی‌گرداند.
     */
    private function extractParentCategoryKey(string $key, array $all): string
    {
        $slashPos = strrpos($key, '/');
        if ($slashPos === false) {
            return '';
        }
        $parent = substr($key, 0, $slashPos);
        return isset($all[$parent]) ? $parent : '';
    }

    private function extractSlugFromKey(string $key, string $fallback): string
    {
        $slashPos = strrpos($key, '/');
        $slug = $slashPos === false ? $key : substr($key, $slashPos + 1);
        return $slug !== '' ? $slug : $fallback;
    }

    /**
     * مهاجرت محتوا (صفحات + نوشته‌ها + پیوست‌ها + برچسب‌ها).
     */
    private function importContent(): void
    {
        $pagesIndex = $this->reader->readPagesIndex();
        $site       = $this->reader->readSite();

        // نکته مهم ترتیب درج:
        // Bludit فایل pages.php را «جدیدترین-اول» ذخیره می‌کند (پس از هر ثبت/ویرایش
        // sortByDate(HighToLow) اجرا می‌شود). اگر مطالب با همین ترتیب وارد شوند،
        // جدیدترین مطلب کمترین cid و قدیمی‌ترین مطلب بیشترین cid می‌گیرد؛ در نتیجه
        // لیست «مدیریت نوشته‌ها» در TypeRenew (که بر اساس cid نزولی مرتب می‌شود)
        // معکوس نمایش داده می‌شود: قدیمی‌ترین مطالب بالا و جدیدترین‌ها پایین.
        // برای اینکه تخصیص cid ها همانند انتشار طبیعی مطالب در طول زمان باشد،
        // ابتدا بر اساس تاریخ صعودی (قدیمی‌ترین اول) مرتب می‌کنیم و سپس ترتیب
        // سلسله‌مراتبی والد/فرزند را با topologicalSort برقرار می‌کنیم.
        $ordered = $this->topologicalSort($this->sortByDateAsc($pagesIndex));

        foreach ($ordered as $key => $row) {
            try {
                $uuid = (string) ($row['uuid'] ?? '');
                $existing = $uuid !== '' ? $this->findMapped('content', $uuid) : null;
                if ($existing !== null) {
                    $this->contentMap[$uuid]     = (int) $existing;
                    $this->contentKeyMap[$key]   = (int) $existing;
                    if (($row['type'] ?? 'published') === 'static') {
                        $this->stats['pages_skipped']++;
                    } else {
                        $this->stats['posts_skipped']++;
                    }
                    continue;
                }

                $cid = $this->importOnePage($key, $row, $site);
                if ($uuid !== '') {
                    $this->contentMap[$uuid] = $cid;
                }
                $this->contentKeyMap[$key] = $cid;

                if (($row['type'] ?? 'published') === 'static') {
                    $this->stats['pages']++;
                } else {
                    $this->stats['posts']++;
                }
            } catch (\Throwable $e) {
                $this->errors[] = _t('خطای مهاجرت صفحه %s: %s', $key, $e->getMessage());
                $this->stats['errors']++;
            }
        }
    }

    /**
     * صفحات را بر اساس تاریخ صعودی (قدیمی‌ترین اول) مرتب می‌کند.
     *
     * Bludit دیتابیس pages.php را به‌صورت جدیدترین-اول ذخیره می‌کند، اما برای
     * تخصیص صحیح cid در TypeRenew (و نمایش درست لیست مدیریت که بر اساس cid
     * نزولی مرتب می‌شود) باید مطالب از قدیمی به جدید وارد شوند؛ همان‌طور که
     * اگر در طول زمان به‌صورت طبیعی منتشر شده بودند.
     *
     * مرتب‌سازی پایدار است: ردیف‌های هم‌تاریخ ترتیب خود را در فایل منبع حفظ می‌کنند.
     */
    private function sortByDateAsc(array $pages): array
    {
        $stamped = [];
        foreach ($pages as $key => $row) {
            $stamped[$key] = [
                'ts'  => $this->parseDate((string) ($row['date'] ?? '')),
                'row' => $row,
            ];
        }

        // uasort در PHP 8+ پایدار است (این افزونه PHP 8 به بالا لازم دارد)
        uasort($stamped, static fn (array $a, array $b): int => $a['ts'] <=> $b['ts']);

        $sorted = [];
        foreach ($stamped as $key => $item) {
            $sorted[$key] = $item['row'];
        }
        return $sorted;
    }

    /**
     * صفحات را به‌صورت Topological بر اساس parent مرتب می‌کند تا والد قبل از فرزند وارد شود.
     */
    private function topologicalSort(array $pages): array
    {
        // تشخیص والد از کلید: parent/child
        $result  = [];
        $pending = $pages;
        $maxPasses = 8;
        while (!empty($pending) && $maxPasses-- > 0) {
            $deferred = [];
            foreach ($pending as $key => $row) {
                $parentKey = '';
                $slashPos = strrpos($key, '/');
                if ($slashPos !== false) {
                    $parentKey = substr($key, 0, $slashPos);
                }
                if ($parentKey !== '' && !isset($result[$parentKey]) && isset($pending[$parentKey])) {
                    $deferred[$key] = $row;
                    continue;
                }
                $result[$key] = $row;
            }
            if (count($deferred) === count($pending)) {
                // والد گم شده یا چرخه؛ باقی‌مانده را بدون parent وارد کن
                foreach ($deferred as $key => $row) {
                    $result[$key] = $row;
                }
                break;
            }
            $pending = array_diff_key($pending, $result);
        }
        return $result;
    }

    /**
     * وارد کردن یک صفحه/نوشته واحد.
     */
    private function importOnePage(string $key, array $row, array $site): int
    {
        $body = $this->reader->readPageBody($key);
        $isMarkdown = (bool) ($site['markdownParser'] ?? true);
        $text = $isMarkdown ? '<!--markdown-->' . $body : $body;

        // parent از کلید استخراج می‌شود
        $parentCid = 0;
        $slug      = $key;
        $slashPos  = strrpos($key, '/');
        if ($slashPos !== false) {
            $parentKey = substr($key, 0, $slashPos);
            $slug      = substr($key, $slashPos + 1);
            $parentCid = $this->contentKeyMap[$parentKey] ?? 0;
        }

        $type = (string) ($row['type'] ?? 'published');
        $isStatic = $type === 'static';

        [$trType, $trStatus] = $this->mapTypeStatus($type);

        $username = (string) ($row['username'] ?? '');
        $authorId = $this->userMap[$username] ?? 1;
        if ($authorId === 0) {
            $authorId = 1;
        }

        $title = html_entity_decode((string) ($row['title'] ?? ''), ENT_QUOTES, 'UTF-8');
        if ($title === '') {
            $title = $slug;
        }
        $description = html_entity_decode((string) ($row['description'] ?? ''), ENT_QUOTES, 'UTF-8');

        $cid = Contents::alloc()->insert([
            'title'        => $title,
            'slug'         => Common::slugName($slug, $title),
            'text'         => $text,
            'created'      => $this->parseDate($row['date'] ?? ''),
            'authorId'     => $authorId,
            'type'         => $trType,
            'status'       => $trStatus,
            'allowComment' => ($row['allowComments'] ?? true) ? 1 : 0,
            'allowPing'    => 1,
            'allowFeed'    => 1,
            'commentsNum'  => 0,
            'order'        => (int) ($row['position'] ?? 0),
            'parent'       => (int) $parentCid,
            'template'     => (string) ($row['template'] ?? ''),
        ]);

        // تنظیم تاریخ modified به dateModified بلودیت
        $modified = (string) ($row['dateModified'] ?? '');
        if ($modified !== '') {
            $modTs = $this->parseDate($modified);
            if ($modTs > 0) {
                $this->db->query(
                    $this->db->update('table.contents')
                        ->rows(['modified' => $modTs])
                        ->where('cid = ?', $cid),
                    Db::WRITE
                );
            }
        }

        // فیلد سفارشی: bludit_uuid برای Idempotency و دیباگ
        $uuid = (string) ($row['uuid'] ?? '');
        if ($uuid !== '') {
            $this->setCustomField($cid, 'bludit_uuid', 'str', $uuid);
        }
        $this->setCustomField($cid, 'bludit_slug', 'str', $key);
        $this->setCustomField($cid, 'bludit_source', 'str', 'bludit');

        if ($description !== '') {
            $this->setCustomField($cid, 'bludit_description', 'str', $description);
        }
        // فیلدهای SEO
        if (($row['noindex'] ?? false) || ($row['nofollow'] ?? false) || ($row['noarchive'] ?? false)) {
            $robots = [];
            if ($row['noindex'] ?? false)   { $robots[] = 'noindex'; }
            if ($row['nofollow'] ?? false)  { $robots[] = 'nofollow'; }
            if ($row['noarchive'] ?? false) { $robots[] = 'noarchive'; }
            $this->setCustomField($cid, 'bludit_robots', 'str', implode(',', $robots));
        }

        // فیلدهای سفارشی Bludit
        $custom = $row['custom'] ?? [];
        if (is_array($custom)) {
            foreach ($custom as $ck => $cv) {
                if (!is_array($cv)) {
                    $this->setCustomField($cid, 'bludit_custom_' . $ck, 'str', (string) $cv);
                } elseif (isset($cv['value'])) {
                    $this->setCustomField($cid, 'bludit_custom_' . $ck, 'str', (string) $cv['value']);
                }
            }
        }

        // برچسب‌ها
        $tagsAssoc = $row['tags'] ?? [];
        if (is_array($tagsAssoc) && !empty($tagsAssoc)) {
            $tagNames = array_values($tagsAssoc);
            $tagMids  = Metas::alloc()->scanTags($tagNames);
            foreach ($tagMids as $mid) {
                $this->linkContentMeta($cid, $mid);
            }
            $this->stats['tags'] += count($tagMids);
        }

        // دسته‌بندی
        $categoryKey = (string) ($row['category'] ?? '');
        if ($categoryKey !== '') {
            $mid = $this->categoryMap[$categoryKey] ?? null;
            if ($mid !== null) {
                $this->linkContentMeta($cid, $mid);
            } else {
                // اگر دسته مطابقت نداشت، یک دسته جدید بساز
                try {
                    $mid = Metas::alloc()->insert([
                        'name'  => ucfirst($categoryKey),
                        'slug'  => Common::slugName($categoryKey),
                        'type'  => 'category',
                        'parent' => 0,
                        'order' => 0,
                        'count' => 0,
                    ]);
                    $this->categoryMap[$categoryKey] = $mid;
                    $this->recordMapping('category', $categoryKey, $mid);
                    $this->linkContentMeta($cid, $mid);
                } catch (\Throwable $e) {
                    $this->errors[] = _t('خطای ساخت دسته %s: %s', $categoryKey, $e->getMessage());
                }
            }
        }

        // تصویر کاور
        $coverImage = (string) ($row['coverImage'] ?? '');
        if ($coverImage !== '') {
            $this->importCoverImage($cid, $coverImage, $uuid, $key, $site);
        }

        // مهاجرت تصاویر داخل متن و بازنویسی URL ها
        if (($this->settings['importImages'] ?? '1') === '1' && $body !== '') {
            $this->importEmbeddedImages($cid, $body, $uuid, $key, $site, $isMarkdown);
        }

        $this->recordMapping('content', $uuid !== '' ? $uuid : $key, $cid);
        return $cid;
    }

    private function mapTypeStatus(string $bluditType): array
    {
        return match ($bluditType) {
            'static'    => ['page', 'publish'],
            'draft'     => ['post_draft', 'publish'],
            'autosave'  => ['post_draft', 'publish'],
            'sticky'    => ['post', 'publish'],
            'scheduled' => ['post', 'publish'],
            'published' => ['post', 'publish'],
            default     => ['post', 'publish'],
        };
    }

    /**
     * وارد کردن و پیوست کردن تصویر کاور به نوشته.
     */
    private function importCoverImage(int $cid, string $coverImage, string $uuid, string $pageKey, array $site): void
    {
        try {
            // اگر URL خارجی است، فقط به‌عنوان فیلد سفارشی ذخیره می‌کنیم
            if (filter_var($coverImage, FILTER_VALIDATE_URL)) {
                $this->setCustomField($cid, 'bludit_cover_image', 'str', $coverImage);
                return;
            }

            $localPath = $this->resolveBluditImagePath($coverImage, $uuid, $pageKey);
            if ($localPath === null || !is_file($localPath)) {
                $this->errors[] = _t('تصویر کاور یافت نشد: %s', $coverImage);
                return;
            }

            $attachCid = $this->importAttachment($localPath, $cid);
            if ($attachCid > 0) {
                $this->setCustomField($cid, 'bludit_cover_image', 'str', $this->attachmentUrl($attachCid));
                $this->stats['media']++;
            }
        } catch (\Throwable $e) {
            $this->errors[] = _t('خطای کپی تصویر کاور %s: %s', $coverImage, $e->getMessage());
        }
    }

    /**
     * یافتن مسیر فیزیکی فایل آپلودی Bludit.
     */
    private function resolveBluditImagePath(string $filename, string $uuid, string $pageKey): ?string
    {
        $uploads = $this->reader->getUploadsDir();

        // حالت imageRestrict=true: آپلودها در uploads/pages/{uuid}/ یا symlink uploads/pages/{key}/
        $candidates = [];
        if ($uuid !== '') {
            $candidates[] = $uploads . '/pages/' . $uuid . '/' . $filename;
        }
        if ($pageKey !== '') {
            $candidates[] = $uploads . '/pages/' . $pageKey . '/' . $filename;
        }
        // حالت imageRestrict=false: آپلودها در uploads/
        $candidates[] = $uploads . '/' . $filename;

        foreach ($candidates as $path) {
            if (is_file($path)) {
                return realpath($path);
            }
        }
        return null;
    }

    /**
     * مهاجرت تصاویر داخل متن نوشته و بازنویسی URL ها.
     */
    private function importEmbeddedImages(int $cid, string $body, string $uuid, string $pageKey, array $site, bool $isMarkdown): void
    {
        $baseUrl = $this->reader->getBluditBaseUrl($site);
        $patterns = [];

        // Markdown: ![alt](url)
        if ($isMarkdown) {
            $patterns[] = '/!\[[^\]]*\]\(([^)\s]+)(?:\s+["\'][^"\']*["\'])?\)/';
            $patterns[] = '/\[[^\]]*\]\(([^)\s]+)\)/';  // لینک‌ها
        }

        // HTML img tag
        $patterns[] = '/<img[^>]+src=["\']([^"\']+)["\']/i';
        // HTML a tag
        $patterns[] = '/<a[^>]+href=["\']([^"\']+)["\']/i';

        $urls = [];
        foreach ($patterns as $pattern) {
            if (preg_match_all($pattern, $body, $matches) && !empty($matches[1])) {
                foreach ($matches[1] as $url) {
                    $urls[] = $url;
                }
            }
        }
        $urls = array_unique($urls);

        $rewrites = [];
        foreach ($urls as $url) {
            // فقط URL های داخل دامنه Bludit را مهاجرت می‌کنیم
            $localPath = $this->resolveBluditEmbeddedPath($url, $uuid, $pageKey, $baseUrl, $site);
            if ($localPath === null) {
                continue;
            }
            if (isset($this->mediaUrlMap[$localPath])) {
                $rewrites[$url] = $this->mediaUrlMap[$localPath];
                continue;
            }
            try {
                $attachCid = $this->importAttachment($localPath, $cid);
                if ($attachCid > 0) {
                    $newUrl = $this->attachmentUrl($attachCid);
                    $this->mediaUrlMap[$localPath] = $newUrl;
                    $rewrites[$url] = $newUrl;
                    $this->stats['media']++;
                }
            } catch (\Throwable $e) {
                $this->errors[] = _t('خطای کپی تصویر متن %s: %s', $url, $e->getMessage());
            }
        }

        if (!empty($rewrites)) {
            $newBody = strtr($body, $rewrites);
            if ($newBody !== $body) {
                $prefix = $isMarkdown ? '<!--markdown-->' : '';
                $this->db->query(
                    $this->db->update('table.contents')
                        ->rows(['text' => $prefix . $newBody])
                        ->where('cid = ?', $cid),
                    Db::WRITE
                );
            }
        }
    }

    /**
     * URL داخل متن را تحلیل و مسیر فیزیکی فایل را برمی‌گرداند.
     */
    private function resolveBluditEmbeddedPath(string $url, string $uuid, string $pageKey, string $baseUrl, array $site): ?string
    {
        $url = html_entity_decode($url, ENT_QUOTES, 'UTF-8');

        // URL خارجی - رد شو
        if (preg_match('#^https?://#', $url)) {
            // اگر هم‌دامنه با Bludit بود، مسیر محلی را پیدا کن
            if ($baseUrl !== '' && strpos($url, $baseUrl) === 0) {
                $relative = substr($url, strlen($baseUrl));
                $path = $this->reader->getUploadsDir() . '/' . ltrim($relative, '/');
                return is_file($path) ? realpath($path) : null;
            }
            return null;
        }

        // مسیر relative شروع‌شده با /bl-content/uploads
        if (strpos($url, '/bl-content/uploads/') === 0) {
            $relative = substr($url, strlen('/bl-content/uploads/'));
            $path = $this->reader->getUploadsDir() . '/' . $relative;
            return is_file($path) ? realpath($path) : null;
        }

        // مسیر relative بدون /bl-content/uploads
        if (strpos($url, 'bl-content/uploads/') === 0) {
            $relative = substr($url, strlen('bl-content/uploads/'));
            $path = $this->reader->getUploadsDir() . '/' . $relative;
            return is_file($path) ? realpath($path) : null;
        }

        // فقط نام فایل - در پوشه page uuid بگرد
        if (!preg_match('#^[/.]#', $url) && !preg_match('#^https?://#', $url)) {
            return $this->resolveBluditImagePath($url, $uuid, $pageKey);
        }

        return null;
    }

    /**
     * وارد کردن یک فایل به‌عنوان attachment در TypeRenew.
     * از کلید bytes استفاده می‌کنیم چون move_uploaded_file فقط برای فایل‌های
     * آپلودی از طریق HTTP POST کار می‌کند و ما فایل‌ها را از روی دیسک کپی می‌کنیم.
     */
    private function importAttachment(string $localPath, int $parentId): int
    {
        if (!is_file($localPath)) {
            return 0;
        }
        $filename = basename($localPath);
        $contents = file_get_contents($localPath);
        if ($contents === false) {
            return 0;
        }
        $result = Upload::uploadHandle([
            'name'  => $filename,
            'bytes' => $contents,
            'size'  => filesize($localPath) ?: strlen($contents),
        ]);
        if (!is_array($result) || !isset($result['path'])) {
            return 0;
        }

        return Upload::alloc()->insert([
            'title'        => $filename,
            'slug'         => $filename,
            'type'         => 'attachment',
            'status'       => 'publish',
            'text'         => Common::jsonEncode($result, 0, '{}'),
            'allowComment' => 0,
            'allowPing'    => 0,
            'allowFeed'    => 1,
            'parent'       => $parentId,
        ]);
    }

    /**
     * URL عمومی attachment را برمی‌گرداند.
     */
    private function attachmentUrl(int $attachCid): string
    {
        try {
            $row = $this->db->fetchRow(
                $this->db->select('text')->from('table.contents')->where('cid = ?', $attachCid)
            );
            if (!$row) {
                return '';
            }
            $data = json_decode((string) $row['text'], true);
            if (!is_array($data) || empty($data['path'])) {
                return '';
            }
            $path = (string) $data['path'];
            $options = \Widget\Options::alloc();
            return Common::url($path, (string) $options->siteUrl);
        } catch (\Throwable $_) {
            return '';
        }
    }

    /**
     * کپی تصویر پروفایل کاربر.
     */
    private function importProfilePicture(int $uid, string $localPath, string $username): void
    {
        if (!is_file($localPath)) {
            return;
        }
        $ext    = strtolower(pathinfo($localPath, PATHINFO_EXTENSION));
        $contents = file_get_contents($localPath);
        if ($contents === false) {
            return;
        }
        $result = Upload::uploadHandle([
            'name'  => $username . '.' . $ext,
            'bytes' => $contents,
            'size'  => filesize($localPath) ?: strlen($contents),
        ]);
        if (!is_array($result) || !isset($result['path'])) {
            return;
        }
        // به‌عنوان attachment وارد کن و به کاربر پیوند بزن (parent = 0)
        $attachCid = Upload::alloc()->insert([
            'title'        => $username . '.' . $ext,
            'slug'         => 'avatar-' . $username,
            'type'         => 'attachment',
            'status'       => 'publish',
            'text'         => Common::jsonEncode($result, 0, '{}'),
            'allowComment' => 0,
            'allowPing'    => 0,
            'allowFeed'    => 1,
            'parent'       => 0,
            'authorId'     => $uid,
        ]);
        if ($attachCid > 0) {
            // URL را در فیلد url کاربر ذخیره کن
            $url = $this->attachmentUrl($attachCid);
            if ($url !== '') {
                $this->db->query(
                    $this->db->update('table.users')
                        ->rows(['url' => $url])
                        ->where('uid = ?', $uid),
                    Db::WRITE
                );
            }
        }
    }

    /**
     * ثبت نگاشت در جدول bludit_map.
     */
    private function recordMapping(string $kind, string $source, int $targetId): void
    {
        try {
            $this->db->query(
                $this->db->insert('table.' . Schema::TABLE)->rows([
                    'kind'        => $kind,
                    'source'      => mb_substr($source, 0, 128),
                    'target_id'   => $targetId,
                    'source_meta' => '',
                    'created_at'  => time(),
                ]),
                Db::WRITE
            );
        } catch (\Throwable $_) {}
    }

    private function findMapped(string $kind, string $source): ?int
    {
        try {
            $row = $this->db->fetchRow(
                $this->db->select('target_id')->from('table.' . Schema::TABLE)
                    ->where('kind = ? AND source = ?', $kind, $source)
                    ->limit(1)
            );
            return $row ? (int) $row['target_id'] : null;
        } catch (\Throwable $_) {
            return null;
        }
    }

    private function setCustomField(int $cid, string $name, string $type, $value): void
    {
        try {
            $this->db->query(
                $this->db->insert('table.fields')->rows([
                    'cid'          => $cid,
                    'name'         => $name,
                    'type'         => $type,
                    'str_value'    => $type === 'str' || $type === 'json' ? (string) $value : null,
                    'int_value'    => $type === 'int' ? (int) $value : 0,
                    'float_value'  => $type === 'float' ? (float) $value : 0,
                ]),
                Db::WRITE
            );
        } catch (\Throwable $e) {
            // تکراری بودن (cid+name) را نادیده می‌گیریم
        }
    }

    private function linkContentMeta(int $cid, int $mid): void
    {
        try {
            $exists = $this->db->fetchRow(
                $this->db->select('cid')->from('table.relationships')
                    ->where('cid = ? AND mid = ?', $cid, $mid)
                    ->limit(1)
            );
            if ($exists) {
                return;
            }
            $this->db->query(
                $this->db->insert('table.relationships')->rows(['cid' => $cid, 'mid' => $mid]),
                Db::WRITE
            );
            $this->db->query(
                $this->db->update('table.metas')
                    ->expression('count', 'count + 1')
                    ->where('mid = ?', $mid),
                Db::WRITE
            );
        } catch (\Throwable $_) {}
    }

    /**
     * بازمحاسبه count در typecho_metas.
     */
    private function recountMetas(): void
    {
        try {
            $rows = $this->db->fetchAll(
                $this->db->select('mid', ['COUNT(cid)' => 'num'])
                    ->from('table.relationships')
                    ->group('mid')
            );
            foreach ($rows as $row) {
                $this->db->query(
                    $this->db->update('table.metas')
                        ->rows(['count' => (int) $row['num']])
                        ->where('mid = ?', (int) $row['mid']),
                    Db::WRITE
                );
            }
        } catch (\Throwable $e) {
            $this->errors[] = _t('خطای بازمحاسبه شمارش دسته/برچسب: %s', $e->getMessage());
        }
    }

    private function recountCommentsNum(): void
    {
        // Bludit در فایل دیتابیس جدا نظرات را نگه نمی‌دارد (افزونه disqus استفاده می‌کند)؛
        // صرفا برای اطمینان از ناهماهنگی، count را صفر می‌کنیم.
        try {
            $this->db->query(
                $this->db->update('table.contents')->rows(['commentsNum' => 0]),
                Db::WRITE
            );
        } catch (\Throwable $_) {}
    }

    private function parseDate(string $date): int
    {
        $date = trim($date);
        if ($date === '') {
            return time();
        }
        $ts = strtotime($date);
        return $ts === false ? time() : $ts;
    }

    private function countMediaFiles(): int
    {
        $total = 0;
        try {
            $uploads = $this->reader->getUploadsDir();
            if (!is_dir($uploads)) {
                return 0;
            }
            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($uploads, \FilesystemIterator::SKIP_DOTS)
            );
            foreach ($iterator as $file) {
                if ($file->isFile() && strpos($file->getPathname(), '/thumbnails/') === false) {
                    $total++;
                }
            }
        } catch (\Throwable $_) {}
        return $total;
    }

    private function countExistingImports(): int
    {
        try {
            $row = $this->db->fetchRow(
                $this->db->select(['COUNT(*)' => 'num'])->from('table.' . Schema::TABLE)
            );
            return $row ? (int) ($row['num'] ?? 0) : 0;
        } catch (\Throwable $_) {
            return 0;
        }
    }

    private function result(): array
    {
        return [
            'stats'    => $this->stats,
            'errors'    => array_slice($this->errors, 0, 100),
            'errorCount' => count($this->errors),
            'mappings' => [
                'users'      => count($this->userMap),
                'categories' => count($this->categoryMap),
                'contents'   => count($this->contentMap),
                'media'      => count($this->mediaUrlMap),
            ],
        ];
    }
}
