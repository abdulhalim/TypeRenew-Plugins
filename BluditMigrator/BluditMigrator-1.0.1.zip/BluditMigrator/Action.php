<?php
declare(strict_types=1);

namespace TypechoPlugin\BluditMigrator;

use Typecho\Widget;
use Widget\User;
use Widget\Security;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * کنترلر عملیات پلاگین.
 *
 * این کلاس درخواست‌های POST به /action/bludit-migrator را پردازش می‌کند.
 * دو عملیات اصلی:
 *  - do=preview : پیش‌نمایش بدون اعمال
 *  - do=run    : اجرای مهاجرت
 */
class Action extends Widget
{
    public function action()
    {
        $this->guard();

        $do = (string) $this->request->get('do');
        switch ($do) {
            case 'preview':
                $this->requirePost();
                $this->preview();
                return;
            case 'run':
                $this->requirePost();
                $this->run();
                return;
            case 'clear':
                $this->requirePost();
                $this->clearMappings();
                return;
            default:
                $this->jsonError(_t('عملیات نامعتبر'), 400, 'invalid_action');
        }
    }

    private function guard(): void
    {
        User::alloc()->pass('administrator');
        $token = (string) $this->request->get('_');
        $expect = Security::alloc()->getToken('bludit-migrator-admin');
        if (!hash_equals($expect, $token)) {
            $this->jsonError(_t('اعتبارسنجی درخواست ناموفق بود'), 403, 'forbidden');
        }
    }

    private function requirePost(): void
    {
        if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
            $this->jsonError(_t('این روش درخواست مجاز نیست'), 405, 'method_not_allowed');
        }
    }

    private function preview(): void
    {
        $settings = $this->resolveSettings();
        if ($settings['bluditPath'] === '') {
            $this->jsonError(_t('مسیر Bludit تنظیم نشده است'), 400, 'missing_path');
        }

        try {
            $reader   = new Reader($settings['bluditPath']);
            $importer = new Importer($reader, $settings);
            $preview  = $importer->preview();
            $this->jsonSuccess(['success' => 1, 'preview' => $preview]);
        } catch (\Throwable $e) {
            $this->jsonError(_t('خطای پیش‌نمایش: %s', $e->getMessage()), 400, 'preview_failed');
        }
    }

    private function run(): void
    {
        $settings = $this->resolveSettings();
        if ($settings['bluditPath'] === '') {
            $this->jsonError(_t('مسیر Bludit تنظیم نشده است'), 400, 'missing_path');
        }

        try {
            $reader   = new Reader($settings['bluditPath']);
            $importer = new Importer($reader, $settings);
            $result   = $importer->run();

            // ذخیره گزارش و زمان آخرین اجرا
            $settings['lastReport'] = $result;
            $settings['lastRunAt']  = time();
            Settings::store($settings);

            $this->jsonSuccess(['success' => 1, 'result' => $result]);
        } catch (\Throwable $e) {
            $this->jsonError(_t('خطای مهاجرت: %s', $e->getMessage()), 500, 'migration_failed');
        }
    }

    private function clearMappings(): void
    {
        try {
            \Typecho\Db::get()->query(
                \Typecho\Db::get()->delete('table.' . Schema::TABLE),
                \Typecho\Db::WRITE
            );
            $this->jsonSuccess(['success' => 1, 'cleared' => 1]);
        } catch (\Throwable $e) {
            $this->jsonError(_t('خطای پاک‌سازی: %s', $e->getMessage()), 500, 'clear_failed');
        }
    }

    private function resolveSettings(): array
    {
        $settings = Settings::load();
        // اجازه‌ی override از پارامترهای POST
        $path = (string) $this->request->get('bluditPath', '');
        if ($path !== '') {
            $settings['bluditPath'] = $path;
        }
        $group = (string) $this->request->get('defaultGroup', '');
        if ($group !== '') {
            $settings['defaultGroup'] = $group;
        }
        $import = (string) $this->request->get('importImages', '');
        if ($import !== '') {
            $settings['importImages'] = $import === '0' ? '0' : '1';
        }
        $reset = (string) $this->request->get('resetPasswords', '');
        if ($reset !== '') {
            $settings['resetPasswords'] = $reset === '0' ? '0' : '1';
        }
        return Settings::normalize($settings);
    }

    private function jsonError(string $message, int $status, string $code): void
    {
        $this->response->setStatus($status);
        $this->response->throwJson([
            'success' => 0,
            'error'   => $message,
            'code'    => $code,
        ]);
    }

    private function jsonSuccess(array $data): void
    {
        if (!isset($data['success'])) {
            $data['success'] = 1;
        }
        $this->response->throwJson($data);
    }
}
