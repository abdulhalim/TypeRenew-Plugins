<?php
declare(strict_types=1);

namespace TypechoPlugin\BluditMigrator;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * خواننده فایل‌های Bludit.
 *
 * این کلاس مستقیماً از دیسک فایل‌های JSON دیتابیس Bludit و فایل‌های index.txt
 * محتوای صفحات را می‌خواند. مزیت این روش نسبت به API این است که همه فیلدها
 * (از جمله position، template، custom، dateModified و کلید دسته) قابل دسترسی هستند.
 */
class Reader
{
    public const DS = '/';

    private string $root;
    private string $contentDir;
    private string $dbDir;
    private string $pagesDir;
    private string $uploadsDir;
    private string $profilesDir;

    public function __construct(string $bluditRoot)
    {
        $root = rtrim(str_replace('\\', '/', $bluditRoot), '/');
        if ($root === '' || !is_dir($root)) {
            throw new \InvalidArgumentException(
                _t('مسیر ریشه Bludit وجود ندارد یا قابل دسترسی نیست: %s', $bluditRoot)
            );
        }
        $this->root        = $root;
        $this->contentDir  = $root . '/bl-content';
        $this->dbDir       = $this->contentDir . '/databases';
        $this->pagesDir    = $this->contentDir . '/pages';
        $this->uploadsDir  = $this->contentDir . '/uploads';
        $this->profilesDir = $this->contentDir . '/uploads/profiles';
    }

    public function isValid(): bool
    {
        return is_dir($this->dbDir) && is_dir($this->pagesDir);
    }

    public function getRoot(): string
    {
        return $this->root;
    }

    public function getPagesDir(): string
    {
        return $this->pagesDir;
    }

    public function getUploadsDir(): string
    {
        return $this->uploadsDir;
    }

    public function getProfilesDir(): string
    {
        return $this->profilesDir;
    }

    /**
     * یک فایل JSON دیتابیس Bludit را می‌خواند.
     * فایل‌ها با یک خط هدر امنیتی PHP شروع می‌شوند که باید حذف شود.
     */
    public function readDbFile(string $name): array
    {
        $path = $this->dbDir . '/' . $name;
        if (!is_file($path)) {
            return [];
        }
        $contents = file_get_contents($path);
        if ($contents === false) {
            return [];
        }
        $firstNewline = strpos($contents, "\n");
        if ($firstNewline !== false) {
            $json = substr($contents, $firstNewline + 1);
        } else {
            $json = $contents;
        }
        $data = json_decode($json, true);
        if (!is_array($data)) {
            return [];
        }
        return $data;
    }

    public function readSite(): array
    {
        return $this->readDbFile('site.php');
    }

    public function readUsers(): array
    {
        return $this->readDbFile('users.php');
    }

    public function readCategories(): array
    {
        return $this->readDbFile('categories.php');
    }

    public function readTags(): array
    {
        return $this->readDbFile('tags.php');
    }

    public function readPagesIndex(): array
    {
        return $this->readDbFile('pages.php');
    }

    /**
     * متن خام صفحه (index.txt) را می‌خواند.
     */
    public function readPageBody(string $key): string
    {
        $path = $this->pagesDir . '/' . $key . '/index.txt';
        if (!is_file($path)) {
            return '';
        }
        $body = file_get_contents($path);
        return $body === false ? '' : $body;
    }

    /**
     * لیست فایل‌های رسانه‌ای یک صفحه را برمی‌گرداند.
     */
    public function listPageMedia(string $uuid, ?string $pageKey = null): array
    {
        $files  = [];
        $real   = $this->uploadsDir . '/pages/' . $uuid;
        $linked = $pageKey !== null ? $this->uploadsDir . '/pages/' . $pageKey : null;

        // اگر symlink از pageKey به uuid وجود داشت آن را resolve کن
        if ($linked !== null && is_link($linked)) {
            try {
                $real = realpath($linked);
            } catch (\Throwable $e) {
                $real = $this->uploadsDir . '/pages/' . $uuid;
            }
        }

        if (!is_dir($real)) {
            return [];
        }

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($real, \FilesystemIterator::SKIP_DOTS)
        );

        foreach ($iterator as $file) {
            if (!$file->isFile()) {
                continue;
            }
            // thumbnails را skip می‌کنیم (نسخه اصلی کافی است)
            if (strpos($file->getPathname(), '/thumbnails/') !== false) {
                continue;
            }
            $files[] = $file->getPathname();
        }
        return $files;
    }

    /**
     * مسیر فیزیکی فایل آپلودی مشترک (حالت imageRestrict=false) را برمی‌گرداند.
     */
    public function findSharedUpload(string $filename): ?string
    {
        $path = $this->uploadsDir . '/' . $filename;
        return is_file($path) ? $path : null;
    }

    /**
     * مسیر تصویر پروفایل کاربر را برمی‌گرداند.
     */
    public function findProfilePicture(string $username): ?string
    {
        $candidates = [
            $this->profilesDir . '/' . $username . '.png',
            $this->profilesDir . '/' . $username . '.jpg',
            $this->profilesDir . '/' . $username . '.jpeg',
            $this->profilesDir . '/' . $username . '.webp',
        ];
        foreach ($candidates as $path) {
            if (is_file($path)) {
                return $path;
            }
        }
        return null;
    }

    /**
     * URL عمومی آپلود‌های Bludit را برمی‌گرداند (برای rewrite کردن URL های داخل متن).
     */
    public function getBluditBaseUrl(array $siteSettings): string
    {
        $url = (string) ($siteSettings['url'] ?? '');
        if ($url === '') {
            // fallback: از مسیر relative استفاده می‌کنیم
            return '/bl-content/uploads';
        }
        return rtrim($url, '/') . '/bl-content/uploads';
    }
}
