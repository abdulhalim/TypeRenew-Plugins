<?php
declare(strict_types=1);

namespace TypechoPlugin\BluditMigrator;

use Typecho\Db;
use Typecho\Plugin as Hook;
use Typecho\Plugin\PluginInterface;
use Typecho\Widget\Helper\Form;
use Utils\Helper;
use Utils\NoPersonal;
use RuntimeException;
use Throwable;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * افزونه مهاجرت از بلودیت به TypeRenew
 *
 * @package BluditMigrator
 * @author پوردریایی
 * @link https://pourdaryaei.ir
 * @version 1.0.1
 * @since 1.6.0
 */
class Plugin implements PluginInterface
{
    use NoPersonal;

    public const NAME = 'BluditMigrator';
    public const OPTION_KEY = 'plugin:BluditMigrator';
    public const ROUTE_NAME = 'bludit_migrator_action';
    public const ROUTE_URL = '/action/bludit-migrator';
    public const PANEL_FILE = 'BluditMigrator/Panel.php';

    public static function activate(): string
    {
        self::createTables();
        self::registerHooks();

        Helper::removeRoute(self::ROUTE_NAME);
        Helper::addRoute(self::ROUTE_NAME, self::ROUTE_URL, Action::class, 'action');

        Helper::removePanel(3, self::PANEL_FILE);
        Helper::addPanel(
            3,
            self::PANEL_FILE,
            _t('مهاجرت از Bludit'),
            _t('انتقال کامل محتوای Bludit به TypeRenew'),
            'administrator',
            false,
            '',
            ['icon' => 'i-transfer']
        );

        self::ensureConfigStored();

        return _t('افزونه مهاجرت Bludit فعال شد. از پنل «مهاجرت از Bludit» استفاده کنید.');
    }

    public static function deactivate(): string
    {
        Helper::removeRoute(self::ROUTE_NAME);
        Helper::removePanel(3, self::PANEL_FILE);
        return _t('افزونه مهاجرت Bludit غیرفعال شد.');
    }

    public static function config(Form $form): void
    {
        $settings = Settings::load();

        $bluditPath = new Form\Element\Text(
            'bluditPath',
            null,
            $settings['bluditPath'] ?? '',
            _t('مسیر ریشه نصب Bludit'),
            _t('مسیر مطلق پوشه نصب Bludit روی همین سرور؛ مثال: /var/www/bludit')
        );
        $bluditPath->input->setAttribute('class', 'w-100');
        $form->addInput($bluditPath);

        $defaultGroup = new Form\Element\Select(
            'defaultGroup',
            [
                'administrator' => _t('مدیر'),
                'editor'        => _t('ویراستار'),
                'contributor'   => _t('مشارکت‌کننده'),
                'subscriber'    => _t('مشترک'),
                'visitor'       => _t('بازدیدکننده'),
            ],
            $settings['defaultGroup'] ?? 'contributor',
            _t('گروه پیش‌فرض کاربران وارد شده'),
            _t('کاربران Bludit که نقش admin/editor/author ندارند به این گروه منتقل می‌شوند')
        );
        $form->addInput($defaultGroup);

        $importImages = new Form\Element\Radio(
            'importImages',
            ['1' => _t('بله، تصاویر را هم منتقل کن'), '0' => _t('خیر، فقط URL ها را بازنویسی کن')],
            $settings['importImages'] ?? '1',
            _t('انتقال تصاویر')
        );
        $form->addInput($importImages);

        $resetPasswords = new Form\Element\Radio(
            'resetPasswords',
            ['1' => _t('بله، رمز عبور تصادفی بده'), '0' => _t('خیر، از همان رمز قبلی استفاده کن')],
            $settings['resetPasswords'] ?? '1',
            _t('بازنشانی رمز کاربران'),
            _t('Bludit از SHA1 استفاده می‌کند که در TypeRenew قابل استفاده نیست؛ رمزهای عبور کاربران باید بازنشانی شوند')
        );
        $form->addInput($resetPasswords);
    }

    public static function configHandle(array $settings, bool $isInit): void
    {
        $current = Settings::load();
        $merged  = array_merge($current, $settings);
        Settings::store($merged);
    }

    private static function createTables(): void
    {
        try {
            Schema::ensure(Db::get());
        } catch (Throwable $e) {
            throw new RuntimeException(
                _t('ساخت جدول نگاشت مهاجرت ناموفق بود؛ افزونه فعال نشد'),
                0,
                $e
            );
        }
    }

    private static function registerHooks(): void
    {
        Hook::factory('Utils\\Migration\\SchemaManager')->syncSchema = [Schema::class, 'ensure'];
    }

    private static function ensureConfigStored(): void
    {
        $current = Settings::load();
        if (empty($current)) {
            Settings::store(Settings::defaults());
        }
    }
}
