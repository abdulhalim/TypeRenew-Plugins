/* BluditMigrator panel — client logic */
(function () {
    'use strict';

    if (!window.BluditMigratorPanel) {
        return;
    }

    var cfg = window.BluditMigratorPanel;
    var i18n = cfg.i18n || {};

    function $(sel, root) { return (root || document).querySelector(sel); }
    function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

    function getFormData() {
        var form = $('#bludit-migrator-form');
        var data = {};
        $all('input, select, textarea', form).forEach(function (el) {
            if (!el.name) return;
            if (el.type === 'radio') {
                if (el.checked) data[el.name] = el.value;
            } else {
                data[el.name] = el.value;
            }
        });
        return data;
    }

    function buildUrl(baseUrl, params) {
        var url = new URL(baseUrl, window.location.origin);
        Object.keys(params).forEach(function (k) {
            if (params[k] !== '' && params[k] !== null && params[k] !== undefined) {
                url.searchParams.set(k, params[k]);
            }
        });
        return url.toString();
    }

    function showArea(html) {
        var area = $('#bm-preview-area');
        if (!area) return;
        area.innerHTML = html;
    }

    function showLoading(msg) {
        showArea('<div class="bm-loading">' + escapeHtml(msg || '') +
                 '<span class="bm-spinner" style="border-color:rgba(79,70,229,0.2);border-top-color:#4f46e5"></span></div>');
    }

    function showError(msg) {
        showArea('<div class="bm-error-msg">' + escapeHtml(msg) + '</div>');
    }

    function showSuccess(msg, stats) {
        var html = '<div class="bm-success-msg">' + escapeHtml(msg) + '</div>';
        if (stats) {
            html += renderStats(stats);
        }
        showArea(html);
    }

    function renderStats(stats) {
        if (!stats) return '';
        var s = stats.stats || stats;
        var out = '<table class="bm-preview-table"><tbody>';
        out += row(i18n.users || 'Users', s.users, 'num', false);
        out += row('Users skipped', s.users_skipped, 'num', false);
        out += row(i18n.categories || 'Categories', s.categories, 'num', false);
        out += row('Categories skipped', s.categories_skipped, 'num', false);
        out += row(i18n.posts || 'Posts', s.posts, 'num', false);
        out += row('Posts skipped', s.posts_skipped, 'num', false);
        out += row(i18n.pages || 'Pages', s.pages, 'num', false);
        out += row('Pages skipped', s.pages_skipped, 'num', false);
        out += row('Tags assigned', s.tags, 'num', false);
        out += row(i18n.media || 'Media', s.media, 'num', false);
        out += row('Media skipped', s.media_skipped, 'num', false);
        out += row('Errors', s.errors, s.errors > 0 ? 'warn' : 'num', s.errors > 0);
        out += '</tbody></table>';
        return out;
    }

    function row(label, val, cls, warn) {
        return '<tr><td>' + escapeHtml(label || '') + '</td><td class="bm-' + (warn ? 'warn' : 'num') + '">' + (val || 0) + '</td></tr>';
    }

    function renderPreview(p) {
        if (!p || !p.valid) {
            showError(p && p.error ? p.error : 'مسیر Bludit معتبر نیست');
            return;
        }
        var site = p.site || {};
        var html = '<table class="bm-preview-table"><tbody>' +
            row(i18n.siteTitle || 'Site title', site.title || '-', 'num', false) +
            row(i18n.siteUrl || 'Site URL', site.url || '-', 'num', false) +
            row(i18n.siteLang || 'Language', site.language || '-', 'num', false) +
            row(i18n.siteTimezone || 'Timezone', site.timezone || '-', 'num', false) +
            row(i18n.users || 'Users', p.users, 'num', false) +
            row(i18n.categories || 'Categories', p.categories, 'num', false) +
            row(i18n.tags || 'Tags', p.tags, 'num', false) +
            row(i18n.posts || 'Posts', p.posts, 'num', false) +
            row(i18n.pages || 'Pages', p.pages, 'num', false) +
            row(i18n.drafts || 'Drafts', p.drafts, 'num', false) +
            row(i18n.media || 'Media files', p.media_total, 'num', false) +
            row(i18n.existing || 'Existing mappings', p.existing, 'num', p.existing > 0) +
            '</tbody></table>';
        showArea(html);
    }

    function escapeHtml(s) {
        if (s === null || s === undefined) return '';
        return String(s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    function postJson(url, data) {
        return fetch(url, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: encodeForm(data)
        }).then(function (r) {
            if (!r.ok) {
                return r.json().catch(function () { return { error: 'HTTP ' + r.status }; })
                    .then(function (j) { throw new Error(j.error || ('HTTP ' + r.status)); });
            }
            return r.json();
        });
    }

    function encodeForm(data) {
        var parts = [];
        Object.keys(data).forEach(function (k) {
            if (data[k] !== null && data[k] !== undefined) {
                parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(data[k]));
            }
        });
        return parts.join('&');
    }

    function runPreview() {
        var data = getFormData();
        var btn = $('#bm-preview-btn');
        if (!btn) return;
        if (!data.bluditPath || !data.bluditPath.trim()) {
            showError('لطفاً مسیر Bludit را وارد کنید');
            return;
        }
        btn.disabled = true;
        var original = btn.innerHTML;
        btn.innerHTML = escapeHtml(i18n.running || 'Loading') + '<span class="bm-spinner"></span>';
        showLoading('در حال خواندن داده‌های Bludit...');
        postJson(cfg.preview, data).then(function (j) {
            if (j && j.success && j.preview) {
                renderPreview(j.preview);
            } else {
                showError((j && j.error) || 'پیش‌نمایش ناموفق بود');
            }
        }).catch(function (err) {
            showError(err.message || err);
        }).finally(function () {
            btn.disabled = false;
            btn.innerHTML = original;
        });
    }

    function runMigration() {
        var data = getFormData();
        var btn = $('#bm-run-btn');
        if (!btn) return;
        if (!data.bluditPath || !data.bluditPath.trim()) {
            showError('لطفاً مسیر Bludit را وارد کنید');
            return;
        }
        if (!window.confirm(i18n.confirmRun || 'Confirm migration?')) {
            return;
        }
        btn.disabled = true;
        var original = btn.innerHTML;
        btn.innerHTML = escapeHtml(i18n.running || 'Running') + '<span class="bm-spinner"></span>';
        showLoading('در حال مهاجرت... ممکن است چند دقیقه طول بکشد');
        postJson(cfg.run, data).then(function (j) {
            if (j && j.success && j.result) {
                showSuccess(i18n.done || 'Migration complete', j.result);
                setTimeout(function () { window.location.reload(); }, 2000);
            } else {
                showError((j && j.error) || 'مهاجرت ناموفق بود');
            }
        }).catch(function (err) {
            showError(err.message || err);
        }).finally(function () {
            btn.disabled = false;
            btn.innerHTML = original;
        });
    }

    function clearMappings() {
        if (!window.confirm(i18n.confirmClear || 'Clear mappings?')) {
            return;
        }
        var btn = $('#bm-clear-btn');
        if (!btn) return;
        btn.disabled = true;
        postJson(cfg.clear, {}).then(function (j) {
            if (j && j.success) {
                showSuccess('جدول نگاشت پاک شد');
            } else {
                showError((j && j.error) || 'پاک‌سازی ناموفق بود');
            }
        }).catch(function (err) {
            showError(err.message || err);
        }).finally(function () {
            btn.disabled = false;
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        var previewBtn = $('#bm-preview-btn');
        var runBtn = $('#bm-run-btn');
        var clearBtn = $('#bm-clear-btn');
        if (previewBtn) previewBtn.addEventListener('click', runPreview);
        if (runBtn) runBtn.addEventListener('click', runMigration);
        if (clearBtn) clearBtn.addEventListener('click', clearMappings);
    });
})();
