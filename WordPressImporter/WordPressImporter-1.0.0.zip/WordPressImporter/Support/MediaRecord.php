<?php
/**
 * Media attachment record.
 *
 * @package WordPressImporter\Support
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Support;

final readonly class MediaRecord
{
    public function __construct(
        public int $sourceId,
        public int $sourceParentId,
        public string $title,
        public string $slug,
        public string $mime,
        public string $url,               // absolute URL or local path on WP
        public string $filePath,          // server-side path (when local)
        public int $size,
        public int $uploadedAt,
        public ?string $description = null,
        public ?string $altText = null,
    ) {
    }
}
