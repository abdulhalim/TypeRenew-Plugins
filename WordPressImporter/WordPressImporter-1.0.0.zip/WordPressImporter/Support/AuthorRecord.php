<?php
/**
 * User / author record from the WordPress source.
 *
 * @package WordPressImporter\Support
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Support;

final readonly class AuthorRecord
{
    public function __construct(
        public int $sourceId,
        public string $username,
        public string $email,
        public string $displayName,
        public string $nickname,
        public string $firstName,
        public string $lastName,
        public string $url,
        public string $role,        // 'administrator' | 'editor' | 'author' | 'contributor' | 'subscriber'
        public int $registeredAt,
        public ?string $passwordHash = null, // WP hash; we reset and mark placeholder
    ) {
    }
}
