<?php
/**
 * Post / page record.
 *
 * Note: `type` carries the WordPress post_type as-is. The PostImporter only
 * accepts 'post' and 'page' — any other value is logged as ignored and skipped.
 *
 * @package WordPressImporter\Support
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Support;

final readonly class PostRecord
{
    public function __construct(
        public int $sourceId,
        public int $sourceAuthorId,
        public string $title,
        public string $slug,
        public string $content,           // raw WordPress content (with shortcodes / blocks)
        public string $excerpt,
        public string $status,            // 'publish' | 'draft' | 'pending' | 'private' | 'future' | 'trash'
        public string $type,              // 'post' | 'page' (other values are ignored by the importer)
        public string $password,
        public int $createdAt,
        public int $modifiedAt,
        public bool $allowComments,
        public bool $allowPings,
        public ?int $featuredImageId = null,
        public ?string $commentCount = null,
        /** @var list<int> */
        public array $categoryIds = [],
        /** @var list<int> */
        public array $tagIds = [],
    ) {
    }
}
