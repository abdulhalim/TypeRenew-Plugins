<?php
/**
 * StateManager — persistent key/value store for the importer.
 *
 * Lives in its own table (`<prefix>wp_importer_state`) so that:
 *   - Settings survive across AJAX requests
 *   - Progress survives across page reloads (resumable imports)
 *   - Rollback snapshots survive accidental plugin deactivation
 *
 * The table is created LAZILY on first read/write — this is essential because
 * SQLite (a popular TypeRenew adapter) doesn't support CREATE TABLE inside
 * the activate() hook reliably, and because some hosts run activation in a
 * context where the Db adapter isn't fully initialized yet.
 *
 * @package WordPressImporter\Support
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Support;

use Typecho\Db;

final class StateManager
{
    public const TABLE = 'wp_importer_state';

    /** @var array<string, array<string, mixed>> In-process cache. */
    private static array $cache = [];

    /** @var bool|null Whether the state table has been verified to exist. */
    private static ?bool $installed = null;

    /**
     * Create the state table if it does not exist. Called from Plugin::activate()
     * AND lazily from ensureInstalled() on first read/write.
     *
     * Detects the active Db adapter via Db::getAdapterName() and uses the
     * appropriate CREATE TABLE syntax. Supports MySQL/MariaDB, PostgreSQL,
     * and SQLite (the three adapters shipped with TypeRenew).
     */
    public static function install(): void
    {
        $db = Db::get();
        $prefix = $db->getPrefix();
        $table = $prefix . self::TABLE;
        $adapter = self::adapterName($db);

        $sql = self::buildCreateTableSql($adapter, $table);
        $db->query($sql);

        self::$installed = true;
    }

    /**
     * Build the CREATE TABLE statement for the given adapter.
     *
     * Returned as a string so callers can wrap it in try/catch and the
     * query builder doesn't need to know about adapter-specific syntax.
     */
    private static function buildCreateTableSql(string $adapter, string $table): string
    {
        // Normalize adapter name to a dialect identifier.
        // Possible inputs: 'Mysqli', 'Mysql', 'Pdo_Mysql', 'Pdo\Mysql',
        //                  'Pgsql', 'Pdo_Pgsql', 'Pdo\Pgsql',
        //                  'SQLite', 'Pdo_SQLite', 'Pdo\SQLite'
        $adapter = str_replace(['\\', '/'], '_', $adapter);

        $dialect = match (true) {
            in_array($adapter, ['Mysqli', 'Mysql', 'Pdo_Mysql'], true) => 'Mysql',
            in_array($adapter, ['Pgsql', 'Pdo_Pgsql'], true) => 'Pgsql',
            in_array($adapter, ['SQLite', 'Pdo_SQLite'], true) => 'SQLite',
            default => 'Mysql', // safe default — most TypeRenew installs use MySQL
        };

        return match ($dialect) {
            'Mysql' => "CREATE TABLE IF NOT EXISTS `{$table}` (
                `skey` VARCHAR(100) NOT NULL,
                `svalue` LONGTEXT NULL,
                `updated` BIGINT UNSIGNED NOT NULL DEFAULT 0,
                PRIMARY KEY (`skey`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            'Pgsql' => "CREATE TABLE IF NOT EXISTS \"{$table}\" (
                \"skey\" VARCHAR(100) PRIMARY KEY,
                \"svalue\" TEXT,
                \"updated\" BIGINT DEFAULT 0
            )",
            'SQLite' => "CREATE TABLE IF NOT EXISTS \"{$table}\" (
                \"skey\" VARCHAR(100) PRIMARY KEY,
                \"svalue\" TEXT,
                \"updated\" INTEGER DEFAULT 0
            )",
            default => "CREATE TABLE IF NOT EXISTS `{$table}` (
                `skey` VARCHAR(100) NOT NULL,
                `svalue` LONGTEXT NULL,
                `updated` BIGINT UNSIGNED NOT NULL DEFAULT 0,
                PRIMARY KEY (`skey`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        };
    }

    /**
     * Detect the adapter short name and normalize to one of:
     *   'Mysqli', 'Pdo_Mysql', 'Pgsql', 'Pdo_Pgsql', 'SQLite', 'Pdo_SQLite'
     *
     * Uses Db::getAdapterName() first, then falls back to inspecting the
     * adapter class name. This is important because users may configure
     * TypeRenew with adapterName='Pdo' (generic) — in that case we MUST
     * inspect the actual adapter class to determine the SQL dialect.
     */
    private static function adapterName(Db $db): string
    {
        try {
            // Preferred API (TypeRenew 1.3+).
            if (method_exists($db, 'getAdapterName')) {
                $name = (string) $db->getAdapterName();
                if ($name !== '' && $name !== 'Pdo') {
                    return $name;
                }
            }
            // Fall back to adapter class name inspection.
            // This catches the case where adapterName is 'Pdo' (generic)
            // but the actual adapter is Pdo\SQLite or Pdo\Mysql.
            $adapter = $db->getAdapter();
            $class = (string) (get_class($adapter) ?: '');
            // Examples:
            //   Typecho\Db\Adapter\Pdo\SQLite → 'Pdo\SQLite' → 'Pdo_SQLite'
            //   Typecho\Db\Adapter\SQLite     → 'SQLite'
            //   Typecho\Db\Adapter\Pdo\Mysql  → 'Pdo\Mysql'  → 'Pdo_Mysql'
            //   Typecho\Db\Adapter\Mysqli     → 'Mysqli'
            $short = substr($class, (int) strrpos($class, '\\') + 1) ?: $class;
            // Normalize 'Pdo\SQLite' → 'Pdo_SQLite', 'Pdo\Mysql' → 'Pdo_Mysql'
            $short = str_replace('\\', '_', $short);
            return $short;
        } catch (\Throwable) {
            return 'Mysqli'; // safe default — MySQL is the most common
        }
    }

    /**
     * Ensure the state table exists before any read/write. Called from get/set/delete.
     *
     * The static guard is per-request only — if install() failed in a previous
     * request, this request will retry. This handles the case where activate()
     * ran in a context where Db wasn't ready, but a later AJAX call has full
     * Db access.
     */
    private static function ensureInstalled(): void
    {
        if (self::$installed === true) {
            return;
        }
        try {
            self::install();
        } catch (\Throwable $e) {
            // Don't set $installed=true so subsequent calls in THIS request
            // will retry. But log so the failure is visible.
            error_log('[WordPressImporter] StateManager::ensureInstalled failed: ' . $e->getMessage());
        }
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        if (array_key_exists($key, self::$cache)) {
            $cached = self::$cache[$key];
            return $cached['set'] ? $cached['value'] : $default;
        }

        try {
            self::ensureInstalled();
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('svalue')->from('table.' . self::TABLE)->where('skey = ?', $key)
            );

            if ($row === null) {
                self::$cache[$key] = ['set' => false, 'value' => null];
                return $default;
            }

            $value = json_decode((string) $row['svalue'], true);
            self::$cache[$key] = ['set' => true, 'value' => $value];
            return $value;
        } catch (\Throwable $e) {
            // Surface the error so the wizard can show it; but don't crash the
            // whole request — return the default instead.
            error_log('[WordPressImporter] StateManager::get failed: ' . $e->getMessage());
            return $default;
        }
    }

    public static function set(string $key, mixed $value): void
    {
        try {
            self::ensureInstalled();
            $db = Db::get();
            $encoded = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $now = time();

            $existing = $db->fetchRow(
                $db->select('skey')->from('table.' . self::TABLE)->where('skey = ?', $key)
            );

            if ($existing) {
                $db->query(
                    $db->update('table.' . self::TABLE)
                        ->rows(['svalue' => $encoded, 'updated' => $now])
                        ->where('skey = ?', $key)
                );
            } else {
                $db->query(
                    $db->insert('table.' . self::TABLE)
                        ->rows(['skey' => $key, 'svalue' => $encoded, 'updated' => $now])
                );
            }

            self::$cache[$key] = ['set' => true, 'value' => $value];
        } catch (\Throwable $e) {
            // Log and rethrow — callers MUST know when persistence fails so they
            // can degrade gracefully (e.g. fall back to in-memory state).
            error_log('[WordPressImporter] StateManager::set failed: ' . $e->getMessage());
            throw $e;
        }
    }

    public static function delete(string $key): void
    {
        try {
            self::ensureInstalled();
            $db = Db::get();
            $db->query(
                $db->delete('table.' . self::TABLE)->where('skey = ?', $key)
            );
            unset(self::$cache[$key]);
        } catch (\Throwable $e) {
            error_log('[WordPressImporter] StateManager::delete failed: ' . $e->getMessage());
        }
    }

    /**
     * Wipe everything. Used by the "Reset State" button on the wizard.
     */
    public static function purge(): void
    {
        try {
            self::ensureInstalled();
            $db = Db::get();
            $db->query($db->delete('table.' . self::TABLE));
            self::$cache = [];
        } catch (\Throwable $e) {
            error_log('[WordPressImporter] StateManager::purge failed: ' . $e->getMessage());
        }
    }
}
