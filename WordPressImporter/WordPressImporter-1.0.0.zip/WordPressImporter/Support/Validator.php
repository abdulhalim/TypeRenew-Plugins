<?php
/**
 * Validator — pre-flight environment and source checks.
 *
 * Runs before any import starts. Returns a list of warnings and throws
 * ValidationException on hard failures.
 *
 * @package WordPressImporter\Support
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Support;

use Typecho\Db;
use TypechoPlugin\WordPressImporter\Exception\ValidationException;

final class Validator
{
    /** Minimum PHP version (matches TypeRenew requirement). */
    public const MIN_PHP = '8.0.0';

    /** Minimum WordPress version supported by the WXR reader. */
    public const MIN_WORDPRESS = '4.0';

    /** Minimum MySQL version (matches TypeRenew requirement). */
    public const MIN_MYSQL = '5.7.7';

    /** Tables that MUST exist in the WordPress DB (with the configured prefix). */
    public const REQUIRED_WP_TABLES = [
        'posts',
        'postmeta',
        'comments',
        'users',
        'usermeta',
        'terms',
        'term_taxonomy',
        'term_relationships',
        'options',
    ];

    /** @var list<string> */
    private array $warnings = [];

    /** @var list<string> */
    private array $errors = [];

    /**
     * Environment pre-flight checks.
     *
     * IMPORTANT: requirements are CONDITIONAL on the selected source kind.
     * The old version hard-required mysqli + pdo_mysql + openssl + xmlreader
     * regardless of source, which made WXR/ZIP imports impossible on hosts
     * without the MySQL drivers (e.g. SQLite-based installs) — a false
     * failure, since a WXR import never touches MySQL.
     *
     * @param string|null $sourceKind 'mysql'|'wxr'|'zip' (null = check everything, warnings only)
     */
    public function validateEnvironment(?string $sourceKind = null): self
    {
        // PHP version
        if (version_compare(PHP_VERSION, self::MIN_PHP, '<')) {
            $this->errors[] = sprintf(
                'نسخهٔ PHP شما (%s) قدیمی است. ایمپورتر وردپرس حداقل به %s+ نیاز دارد (الزام TypeRenew).',
                PHP_VERSION,
                self::MIN_PHP
            );
        }

        // Always required: mbstring (string handling) + dom/xml (WXR parsing
        // and XMLReader-based streaming). Without these nothing works.
        $alwaysRequired = ['mbstring', 'dom'];
        foreach ($alwaysRequired as $ext) {
            if (!extension_loaded($ext)) {
                $this->errors[] = "افزونهٔ PHP لازم موجود نیست: {$ext}";
            }
        }

        // Conditionally required per source kind.
        if ($sourceKind === 'mysql') {
            // Either mysqli OR pdo_mysql is enough — the source uses PDO, so
            // pdo_mysql is the one that really matters.
            if (!extension_loaded('pdo_mysql')) {
                $this->errors[] = 'افزونهٔ PHP لازم موجود نیست: pdo_mysql (برای منبع MySQL)';
            }
        }
        if ($sourceKind === 'zip' && !class_exists(\ZipArchive::class)) {
            $this->errors[] = 'افزونهٔ PHP لازم موجود نیست: zip / ZipArchive (برای منبع ZIP)';
        }
        if ($sourceKind === null) {
            // Unspecified context — degrade driver checks to warnings.
            if (!extension_loaded('pdo_mysql')) {
                $this->warnings[] = 'افزونهٔ pdo_mysql بارگذاری نشده — منبع MySQL در دسترس نخواهد بود (روش‌های WXR و ZIP همچنان کار می‌کنند).';
            }
            if (!class_exists(\ZipArchive::class)) {
                $this->warnings[] = 'ZipArchive در دسترس نیست — منبع ZIP در دسترس نخواهد بود (روش WXR همچنان کار می‌کند).';
            }
            if (!extension_loaded('xmlreader')) {
                $this->warnings[] = 'افزونهٔ xmlreader بارگذاری نشده — پارس فایل WXR ممکن است روی این هاست با خطا مواجه شود.';
            }
        }
        if ($sourceKind === 'wxr' && !extension_loaded('xmlreader')) {
            // XMLReader is the streaming parser; without it WXR import fails.
            $this->errors[] = 'افزونهٔ PHP لازم موجود نیست: xmlreader (برای پارس WXR)';
        }

        // openssl is a nice-to-have (used for remote media downloads over https).
        if (!extension_loaded('openssl')) {
            $this->warnings[] = 'افزونهٔ openssl بارگذاری نشده — دانلود رسانه‌ها از طریق HTTPS ممکن است با خطا مواجه شود.';
        }

        // Memory limit
        $limit = $this->parseBytes((string) ini_get('memory_limit'));
        if ($limit > 0 && $limit < 128 * 1024 * 1024) {
            $this->warnings[] = sprintf(
                'محدودیت حافظهٔ PHP (memory_limit) روی %s است. برای سایت‌های بزرگ حداقل ۲۵۶M توصیه می‌شود.',
                (string) ini_get('memory_limit')
            );
        }

        // Max execution time
        $maxExec = (int) ini_get('max_execution_time');
        if ($maxExec > 0 && $maxExec < 30) {
            $this->warnings[] = "محدودیت زمان اجرای PHP (max_execution_time) روی {$maxExec} ثانیه است؛ اجرای ایمپورت ممکن است نیمه‌کاره قطع شود.";
        }

        // Upload permissions
        $uploadDir = dirname(__DIR__, 2) . '/uploads';
        if (!is_dir($uploadDir) && !@mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) {
            $this->errors[] = "پوشهٔ آپلود قابل نوشتن نیست یا ساخته نمی‌شود: {$uploadDir}";
        } elseif (is_dir($uploadDir) && !is_writable($uploadDir)) {
            $this->errors[] = "پوشهٔ آپلود قابل نوشتن نیست: {$uploadDir}";
        }

        return $this;
    }

    /**
     * Validate a MySQL source configuration.
     *
     * @param array{host:string,port:int,user:string,password:string,database:string,prefix:string} $cfg
     */
    public function validateMysql(array $cfg): self
    {
        $requiredKeys = ['host' => 'میزبان', 'port' => 'پورت', 'user' => 'نام کاربری', 'database' => 'نام دیتابیس', 'prefix' => 'پیشوند جداول'];
        foreach ($requiredKeys as $k => $label) {
            if (empty($cfg[$k])) {
                $this->errors[] = "فیلد «{$label}» در تنظیمات MySQL خالی است.";
            }
        }
        if ($this->errors !== []) {
            return $this;
        }

        try {
            $dsn = sprintf(
                'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
                $cfg['host'],
                (int) $cfg['port'],
                $cfg['database']
            );
            $pdo = new \PDO($dsn, $cfg['user'], $cfg['password'], [
                \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
                \PDO::ATTR_TIMEOUT => 10,
            ]);

            // Server version
            $version = (string) $pdo->getAttribute(\PDO::ATTR_SERVER_VERSION);
            if (preg_match('/^(\d+\.\d+\.\d+)/', $version, $m)) {
                if (version_compare($m[1], self::MIN_MYSQL, '<')) {
                    $this->warnings[] = "نسخهٔ سرور MySQL ({$m[1]}) قدیمی‌تر از نسخهٔ توصیه‌شده (" . self::MIN_MYSQL . ") است.";
                }
            }

            // Required tables
            foreach (self::REQUIRED_WP_TABLES as $t) {
                $full = $cfg['prefix'] . $t;
                $stmt = $pdo->prepare("SHOW TABLES LIKE ?");
                $stmt->execute([$full]);
                if (!$stmt->fetchColumn()) {
                    $this->errors[] = "جدول الزامی وردپرس پیدا نشد: {$full}";
                }
            }

            // Character encoding check (wp_options blogname should decode cleanly)
            $charset = $pdo->query("SELECT default_character_set_name FROM information_schema.SCHEMATA WHERE schema_name = DATABASE()")->fetchColumn();
            if ($charset && !in_array($charset, ['utf8', 'utf8mb4'], true)) {
                $this->warnings[] = "کدگذاری دیتابیس وردپرس «{$charset}» است؛ ایمپورتر انتظار utf8 یا utf8mb4 دارد.";
            }
        } catch (\Throwable $e) {
            $this->errors[] = 'اتصال به MySQL ناموفق بود: ' . $e->getMessage();
        }

        return $this;
    }

    /**
     * Validate a WXR XML file.
     */
    public function validateWxr(string $path): self
    {
        if (!file_exists($path)) {
            $this->errors[] = "فایل WXR پیدا نشد: {$path}";
            return $this;
        }
        if (!is_readable($path)) {
            $this->errors[] = "فایل WXR قابل خواندن نیست (مشکل سطح دسترسی): {$path}";
            return $this;
        }

        $size = filesize($path);
        if ($size === 0) {
            $this->errors[] = "فایل WXR خالی است: {$path}";
            return $this;
        }
        if ($size < 200) {
            $this->warnings[] = 'حجم فایل WXR به‌طرز مشکوکی کم است (' . number_format($size) . ' بایت) — احتمالاً فایل ناقص یا خراب است.';
        }

        // Try opening as XML with XMLReader (streaming)
        $reader = new \XMLReader();
        if (!@$reader->open($path)) {
            $this->errors[] = 'فایل WXR یک XML معتبر نیست.';
            return $this;
        }

        // Read a small slice to confirm this looks like a WXR.
        $wpNamespace = 'http://wordpress.org/export/1.2/';
        $foundWpNs = false;
        $reads = 0;
        while (@$reader->read() && $reads < 50) {
            $reads++;
            if ($reader->nodeType === \XMLReader::ELEMENT && $reader->namespaceURI === $wpNamespace) {
                $foundWpNs = true;
                break;
            }
        }
        $reader->close();

        if (!$foundWpNs) {
            $this->warnings[] = "فایل WXR فضای‌نام (namespace) خروجی وردپرس ({$wpNamespace}) را اعلام نکرده است. ممکن است همچنان قابل پارس باشد، اما سازگاری تضمین نمی‌شود.";
        }

        return $this;
    }

    /**
     * Validate a ZIP package (must contain at least one WXR file).
     */
    public function validateZip(string $path): self
    {
        if (!file_exists($path)) {
            $this->errors[] = "فایل ZIP پیدا نشد: {$path}";
            return $this;
        }
        if (!class_exists(\ZipArchive::class)) {
            $this->errors[] = 'افزونهٔ ZipArchive در دسترس نیست — امکان پردازش بسته‌های ZIP وجود ندارد.';
            return $this;
        }

        $zip = new \ZipArchive();
        $code = $zip->open($path);
        if ($code !== true) {
            $this->errors[] = "باز کردن فایل ZIP ناموفق بود (کد خطا: {$code})";
            return $this;
        }

        $wxrFile = null;
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = $zip->getNameIndex($i);
            if ($name && preg_match('/\.(xml|wxr)$/i', $name)) {
                $wxrFile = $name;
                break;
            }
        }
        $zip->close();

        if ($wxrFile === null) {
            $this->errors[] = 'بستهٔ ZIP شامل هیچ فایل WXR (‎.xml) نیست.';
        }

        return $this;
    }

    /**
     * @return list<string>
     */
    public function warnings(): array
    {
        return $this->warnings;
    }

    /**
     * @return list<string>
     */
    public function errors(): array
    {
        return $this->errors;
    }

    /**
     * @return array{ok:bool, warnings:list<string>, errors:list<string>}
     */
    public function result(): array
    {
        return [
            'ok' => $this->errors === [],
            'warnings' => $this->warnings,
            'errors' => $this->errors,
        ];
    }

    /**
     * Throw if there are hard errors.
     *
     * @throws ValidationException
     */
    public function assertOk(): void
    {
        if ($this->errors !== []) {
            throw new ValidationException(implode(' | ', $this->errors));
        }
    }

    private function parseBytes(string $value): int
    {
        $value = trim($value);
        if ($value === '' || $value === '-1') {
            return -1;
        }
        $unit = strtolower(substr($value, -1));
        $num = (int) $value;
        return match ($unit) {
            'g' => $num * 1024 * 1024 * 1024,
            'm' => $num * 1024 * 1024,
            'k' => $num * 1024,
            default => $num,
        };
    }
}
