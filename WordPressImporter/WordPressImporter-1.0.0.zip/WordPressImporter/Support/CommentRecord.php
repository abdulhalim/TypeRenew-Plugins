<?php
/**
 * Comment record.
 *
 * @package WordPressImporter\Support
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Support;

final readonly class CommentRecord
{
    public function __construct(
        public int $sourceId,
        public int $sourcePostId,
        public ?int $sourceParentId,
        public int $sourceUserId,
        public string $author,
        public string $email,
        public string $url,
        public string $ip,
        public string $agent,
        public string $content,
        public string $status,           // 'approved' | 'pending' | 'spam' | 'trash'
        public string $type,             // 'comment' | 'pingback' | 'trackback'
        public int $createdAt,
    ) {
    }
}
