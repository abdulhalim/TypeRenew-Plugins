<?php
/**
 * Category or tag (taxonomy term).
 *
 * @package WordPressImporter\Support
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Support;

final readonly class CategoryRecord
{
    public function __construct(
        public int $sourceId,
        public string $name,
        public string $slug,
        public string $description,
        public int $parentId,
        public string $taxonomy,   // 'category' | 'post_tag' | 'nav_menu' | custom taxonomy
    ) {
    }
}
