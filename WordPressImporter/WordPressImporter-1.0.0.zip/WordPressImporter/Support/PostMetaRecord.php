<?php
/**
 * Post meta / custom field record.
 *
 * @package WordPressImporter\Support
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Support;

final readonly class PostMetaRecord
{
    public function __construct(
        public int $sourceId,
        public int $sourcePostId,
        public string $key,
        public string $value,           // serialized WP value (we keep raw, importer will unserialize if needed)
    ) {
    }
}
