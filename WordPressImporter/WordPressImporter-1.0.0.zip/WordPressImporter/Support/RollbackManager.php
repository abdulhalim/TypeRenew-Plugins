<?php
/**
 * RollbackManager — pre-import DB snapshot + undo.
 *
 * Strategy:
 *   - For each TypeRenew content table, copy all rows into a shadow table
 *     carrying an extra `_run_id` column (created once per import run).
 *   - On rollback, empty the live table and INSERT … SELECT from the shadow
 *     using an EXPLICIT column list (the previous implementation used
 *     `SELECT *`, which wrongly included `_run_id` and never matched the
 *     live table's column count — rollback always failed).
 *   - Snapshot rows are tagged with run_id so multiple snapshots can coexist.
 *
 * Compatibility (IMPORTANT):
 *   The original implementation used MySQL-only syntax (`CREATE TABLE … LIKE`,
 *   `SHOW TABLES LIKE`, backtick quoting, `TRUNCATE`) which crashed on the
 *   SQLite and PostgreSQL adapters that TypeRenew ships with. This version
 *   detects the active adapter and builds dialect-appropriate SQL. Where a
 *   truly portable statement is possible (`CREATE TABLE … AS SELECT`), it is
 *   preferred. Any snapshot failure is reported to the caller, which now
 *   treats it as NON-FATAL (the import continues without a rollback point —
 *   see Importer::run()).
 *
 * Shadow tables are dropped after a successful post-import verification, but
 * the user can opt to keep them for a configurable number of days.
 *
 * @package WordPressImporter\Support
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Support;

use Typecho\Db;
use TypechoPlugin\WordPressImporter\Exception\RollbackException;

final class RollbackManager
{
    /** Tables to snapshot. */
    public const SNAPSHOTTED = [
        'contents',
        'comments',
        'metas',
        'relationships',
        'fields',
        'users',
    ];

    private string $runId;
    private Db $db;
    private string $prefix;
    /** @var 'Mysql'|'Pgsql'|'SQLite' */
    private string $dialect;

    public function __construct(string $runId)
    {
        $this->runId = $runId;
        $this->db = Db::get();
        $this->prefix = $this->db->getPrefix();
        $this->dialect = self::detectDialect($this->db);
    }

    /**
     * Detect the SQL dialect of the active adapter.
     *
     * Adapter names seen in the wild: 'Mysqli', 'Mysql', 'Pdo_Mysql',
     * 'Pdo\Mysql', 'Pgsql', 'Pdo_Pgsql', 'Pdo\Pgsql', 'SQLite', 'Pdo_SQLite',
     * 'Pdo\SQLite' (the generic 'Pdo' name is resolved by inspecting the
     * adapter class).
     */
    public static function detectDialect(Db $db): string
    {
        $name = '';
        try {
            if (method_exists($db, 'getAdapterName')) {
                $name = (string) $db->getAdapterName();
            }
        } catch (\Throwable) {
            $name = '';
        }

        if ($name === '' || $name === 'Pdo') {
            try {
                $class = get_class($db->getAdapter());
                $name = substr($class, (int) strrpos($class, '\\') + 1) ?: $class;
            } catch (\Throwable) {
                $name = 'Mysql';
            }
        }

        $name = str_replace(['\\', '/'], '_', $name);

        return match (true) {
            in_array($name, ['Pgsql', 'Pdo_Pgsql'], true)   => 'Pgsql',
            in_array($name, ['SQLite', 'Pdo_SQLite'], true) => 'SQLite',
            default                                          => 'Mysql',
        };
    }

    /**
     * Create shadow tables and snapshot all current data.
     *
     * @return int Total rows snapshotted.
     *
     * @throws RollbackException
     */
    public function snapshot(): int
    {
        $total = 0;
        foreach (self::SNAPSHOTTED as $table) {
            $live = $this->prefix . $table;
            $shadow = $this->shadowName($table);

            try {
                $this->db->query("DROP TABLE IF EXISTS " . $this->quoteIdentifier($shadow));

                // Portable schema+data copy in one statement. Works on MySQL,
                // PostgreSQL and SQLite. Indexes/PK are not needed on the
                // shadow — restore inserts explicit values back into the
                // live table which keeps its own keys.
                $this->db->query(sprintf(
                    'CREATE TABLE %s AS SELECT *, %s AS _run_id FROM %s',
                    $this->quoteIdentifier($shadow),
                    $this->quoteString($this->runId),
                    $this->quoteIdentifier($live)
                ));

                $count = (int) $this->db->fetchObject(
                    'SELECT COUNT(*) AS c FROM ' . $this->quoteIdentifier($shadow)
                )->c ?? 0;
                $total += $count;
            } catch (\Throwable $e) {
                throw new RollbackException(
                    "اسنپ‌شات از جدول `{$live}` ناموفق بود: " . $e->getMessage(),
                    0,
                    $e
                );
            }
        }
        return $total;
    }

    /**
     * Roll back to the snapshot: empty live tables, restore from shadow.
     *
     * @throws RollbackException
     */
    public function rollback(): void
    {
        foreach (self::SNAPSHOTTED as $table) {
            $live = $this->prefix . $table;
            $shadow = $this->shadowName($table);

            try {
                if (!$this->tableExists($shadow)) {
                    continue;
                }

                // Explicit column list — `_run_id` must NOT be copied back.
                $columns = $this->tableColumns($live);
                if ($columns === []) {
                    throw new RollbackException("ستون‌های جدول `{$live}` قابل تشخیص نیستند.");
                }
                $colList = implode(', ', array_map(
                    fn (string $c) => $this->quoteIdentifier($c),
                    $columns
                ));

                // TRUNCATE resets auto-increment on MySQL/PgSQL; SQLite (and
                // any adapter without TRUNCATE) falls back to DELETE FROM.
                if ($this->dialect === 'Mysql' || $this->dialect === 'Pgsql') {
                    $this->db->query('TRUNCATE TABLE ' . $this->quoteIdentifier($live));
                } else {
                    $this->db->query('DELETE FROM ' . $this->quoteIdentifier($live));
                }

                $this->db->query(sprintf(
                    'INSERT INTO %1$s (%2$s) SELECT %2$s FROM %3$s WHERE _run_id = %4$s',
                    $this->quoteIdentifier($live),
                    $colList,
                    $this->quoteIdentifier($shadow),
                    $this->quoteString($this->runId)
                ));
            } catch (RollbackException $e) {
                throw $e;
            } catch (\Throwable $e) {
                throw new RollbackException(
                    "برگشت جدول `{$live}` ناموفق بود: " . $e->getMessage(),
                    0,
                    $e
                );
            }
        }
    }

    /**
     * Drop shadow tables for this run.
     */
    public function discard(): void
    {
        foreach (self::SNAPSHOTTED as $table) {
            $shadow = $this->shadowName($table);
            try {
                $this->db->query("DROP TABLE IF EXISTS " . $this->quoteIdentifier($shadow));
            } catch (\Throwable) {
                // best-effort
            }
        }
    }

    public function snapshotExists(): bool
    {
        foreach (self::SNAPSHOTTED as $table) {
            if ($this->tableExists($this->shadowName($table))) {
                return true;
            }
        }
        return false;
    }

    public function runId(): string
    {
        return $this->runId;
    }

    /* ----- internals ----- */

    private function shadowName(string $table): string
    {
        return $this->prefix . 'wp_importer_snap_' . $table . '_' . substr(md5($this->runId), 0, 8);
    }

    /**
     * Adapter-safe identifier quoting (MySQL: backticks, others: double quotes).
     */
    private function quoteIdentifier(string $name): string
    {
        $name = str_replace($this->dialect === 'Mysql' ? '`' : '"', '', $name);
        return $this->dialect === 'Mysql'
            ? '`' . $name . '`'
            : '"' . $name . '"';
    }

    /**
     * Quote a literal string value using the active adapter.
     */
    private function quoteString(string $value): string
    {
        return $this->db->getAdapter()->quoteValue($value);
    }

    /**
     * Adapter-aware table existence check.
     */
    private function tableExists(string $table): bool
    {
        try {
            $dialect = $this->dialect;
            if ($dialect === 'Mysql') {
                $row = $this->db->fetchRow(
                    'SHOW TABLES LIKE ' . $this->quoteString($table)
                );
                return !empty($row);
            }
            if ($dialect === 'SQLite') {
                $row = $this->db->fetchRow(
                    'SELECT name FROM sqlite_master WHERE type = ' . $this->quoteString('table')
                    . ' AND name = ' . $this->quoteString($table) . ' LIMIT 1'
                );
                return !empty($row);
            }
            // Pgsql
            $row = $this->db->fetchRow(
                'SELECT tablename FROM pg_tables WHERE tablename = '
                . $this->quoteString($table) . ' LIMIT 1'
            );
            return !empty($row);
        } catch (\Throwable) {
            return false;
        }
    }

    /**
     * Adapter-aware column introspection for a table.
     *
     * @return list<string>
     */
    private function tableColumns(string $table): array
    {
        try {
            if ($this->dialect === 'Mysql') {
                $rows = $this->db->fetchAll('SHOW COLUMNS FROM ' . $this->quoteIdentifier($table));
                return array_values(array_filter(array_map(
                    static fn (array $r) => (string) ($r['Field'] ?? ''),
                    is_array($rows) ? $rows : []
                )));
            }
            if ($this->dialect === 'SQLite') {
                $rows = $this->db->fetchAll('PRAGMA table_info(' . $this->quoteIdentifier($table) . ')');
                return array_values(array_filter(array_map(
                    static fn (array $r) => (string) ($r['name'] ?? ''),
                    is_array($rows) ? $rows : []
                )));
            }
            // Pgsql
            $rows = $this->db->fetchAll(
                'SELECT column_name FROM information_schema.columns WHERE table_name = '
                . $this->quoteString($table)
                . ' ORDER BY ordinal_position'
            );
            return array_values(array_filter(array_map(
                static fn (array $r) => (string) ($r['column_name'] ?? ''),
                is_array($rows) ? $rows : []
            )));
        } catch (\Throwable) {
            return [];
        }
    }
}
