<?php
/**
 * SettingsManager — typed accessor over the per-run importer configuration.
 *
 * Settings live in the importer's own state table (see StateManager) so a run
 * can be paused / resumed across AJAX requests. The PHP session is avoided on
 * purpose: sessions break on long-running chunked jobs.
 *
 * @package WordPressImporter\Support
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Support;

use TypechoPlugin\WordPressImporter\Exception\ConfigException;

/**
 * @psalm-type Mode = 'keep'|'merge'|'clean'
 * @psalm-type SourceKind = 'mysql'|'wxr'|'zip'
 * @psalm-type MediaStrategy = 'copy'|'download'|'skip'
 */
final class SettingsManager
{
    public const VALID_MODES = ['keep', 'merge', 'clean'];
    public const VALID_SOURCES = ['mysql', 'wxr', 'zip'];
    public const VALID_MEDIA = ['copy', 'download', 'skip'];

    /** @var array<string, mixed> */
    private array $data;

    public function __construct()
    {
        $this->data = StateManager::get('settings', []);
    }

    /**
     * Replace the entire settings array. Validates keys and types.
     *
     * @param array<string, mixed> $data
     *
     * @throws ConfigException
     */
    public function replace(array $data): void
    {
        $clean = $this->validate($data);
        $this->data = $clean;
        StateManager::set('settings', $clean);
    }

    public function all(): array
    {
        return $this->data;
    }

    /* ----- Source settings ----- */

    /** @return SourceKind */
    public function sourceKind(): string
    {
        return $this->data['source_kind'] ?? 'mysql';
    }

    public function mysqlConfig(): array
    {
        return $this->data['mysql'] ?? [
            'host' => 'localhost',
            'port' => 3306,
            'user' => '',
            'password' => '',
            'database' => '',
            'prefix' => 'wp_',
        ];
    }

    public function wxrPath(): ?string
    {
        return $this->data['wxr_path'] ?? null;
    }

    public function zipPath(): ?string
    {
        return $this->data['zip_path'] ?? null;
    }

    /* ----- Mode + features ----- */

    /** @return Mode */
    public function mode(): string
    {
        return $this->data['mode'] ?? 'keep';
    }

    public function dryRun(): bool
    {
        return (bool) ($this->data['dry_run'] ?? false);
    }

    public function chunkSize(): int
    {
        $size = (int) ($this->data['chunk_size'] ?? 100);
        return max(10, min(1000, $size));
    }

    /** @return MediaStrategy */
    public function mediaStrategy(): string
    {
        return $this->data['media_strategy'] ?? 'download';
    }

    public function importUsers(): bool
    {
        return (bool) ($this->data['features']['authors'] ?? true);
    }

    public function importMedia(): bool
    {
        return (bool) ($this->data['features']['media'] ?? true);
    }

    public function importComments(): bool
    {
        return (bool) ($this->data['features']['comments'] ?? true);
    }

    public function importMenus(): bool
    {
        return (bool) ($this->data['features']['menus'] ?? false);
    }

    public function importFields(): bool
    {
        return (bool) ($this->data['features']['fields'] ?? true);
    }

    public function convertShortcodes(): bool
    {
        return (bool) ($this->data['features']['shortcode'] ?? true);
    }

    public function convertGutenberg(): bool
    {
        return (bool) ($this->data['features']['gutenberg'] ?? true);
    }

    public function rollbackEnabled(): bool
    {
        return (bool) ($this->data['features']['rollback'] ?? true);
    }

    /* ----- Validation ----- */

    /**
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     *
     * @throws ConfigException
     */
    private function validate(array $data): array
    {
        $mode = $data['mode'] ?? 'keep';
        if (!in_array($mode, self::VALID_MODES, true)) {
            throw new ConfigException("حالت ایمپورت نامعتبر است: {$mode}");
        }

        $kind = $data['source_kind'] ?? 'mysql';
        if (!in_array($kind, self::VALID_SOURCES, true)) {
            throw new ConfigException("نوع منبع نامعتبر است: {$kind}");
        }

        $media = $data['media_strategy'] ?? 'download';
        if (!in_array($media, self::VALID_MEDIA, true)) {
            throw new ConfigException("استراتژی رسانه نامعتبر است: {$media}");
        }

        $chunk = (int) ($data['chunk_size'] ?? 100);
        if ($chunk < 10 || $chunk > 1000) {
            throw new ConfigException("اندازه دسته باید بین ۱۰ تا ۱۰۰۰ باشد، مقدار فعلی: {$chunk}");
        }

        // Clean mode requires explicit double-confirmation flag.
        if ($mode === 'clean' && empty($data['clean_confirmed'])) {
            throw new ConfigException('حالت ایمپورت تمیز نیاز به تأیید صریح دارد.');
        }

        return $data;
    }
}
