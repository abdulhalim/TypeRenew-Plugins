<?php
/**
 * ProgressManager — tracks per-phase progress across AJAX requests.
 *
 * State is persisted in StateManager so an interrupted import can resume.
 *
 * @package WordPressImporter\Support
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Support;

final class ProgressManager
{
    public const STATE_PENDING = 'pending';
    public const STATE_RUNNING = 'running';
    public const STATE_PAUSED = 'paused';
    public const STATE_COMPLETED = 'completed';
    public const STATE_FAILED = 'failed';
    public const STATE_ROLLED_BACK = 'rolled_back';

    /** @var array<string, mixed> */
    private array $state;

    public function __construct()
    {
        $this->state = StateManager::get('progress', $this->defaultState());
    }

    /**
     * @return array{
     *     state:string, run_id:string, started_at:int, updated_at:int, finished_at:int,
     *     phases:array<string, array{total:int, done:int, started:bool, finished:bool}>,
     *     current_phase:string, memory_peak:int, last_error:?string
     * }
     */
    private function defaultState(): array
    {
        return [
            'state' => self::STATE_PENDING,
            'run_id' => '',
            'started_at' => 0,
            'updated_at' => 0,
            'finished_at' => 0,
            'phases' => [],
            'current_phase' => '',
            'memory_peak' => 0,
            'last_error' => null,
        ];
    }

    public function startRun(string $runId): void
    {
        $this->state = $this->defaultState();
        $this->state['run_id'] = $runId;
        $this->state['started_at'] = time();
        $this->state['state'] = self::STATE_RUNNING;
        $this->save();
    }

    public function registerPhase(string $phase, int $total): void
    {
        $this->state['phases'][$phase] = [
            'total' => $total,
            'done' => 0,
            'started' => false,
            'finished' => false,
        ];
        $this->save();
    }

    public function startPhase(string $phase): void
    {
        if (!isset($this->state['phases'][$phase])) {
            $this->state['phases'][$phase] = ['total' => 0, 'done' => 0, 'started' => false, 'finished' => false];
        }
        $this->state['phases'][$phase]['started'] = true;
        $this->state['current_phase'] = $phase;
        $this->touch();
    }

    public function advance(string $phase, int $by = 1): void
    {
        if (!isset($this->state['phases'][$phase])) {
            return;
        }
        $this->state['phases'][$phase]['done'] += $by;
        $this->touch();
    }

    public function finishPhase(string $phase): void
    {
        if (!isset($this->state['phases'][$phase])) {
            return;
        }
        $this->state['phases'][$phase]['finished'] = true;
        $this->touch();
    }

    public function completeRun(): void
    {
        $this->state['state'] = self::STATE_COMPLETED;
        $this->state['finished_at'] = time();
        $this->touch();
    }

    public function failRun(string $error): void
    {
        $this->state['state'] = self::STATE_FAILED;
        $this->state['last_error'] = $error;
        $this->state['finished_at'] = time();
        $this->touch();
    }

    public function markRolledBack(): void
    {
        $this->state['state'] = self::STATE_ROLLED_BACK;
        $this->state['finished_at'] = time();
        $this->touch();
    }

    public function isRunning(): bool
    {
        return $this->state['state'] === self::STATE_RUNNING;
    }

    public function canResume(): bool
    {
        return in_array($this->state['state'], [self::STATE_PAUSED, self::STATE_FAILED], true)
            && !empty($this->state['run_id']);
    }

    public function pauseRun(): void
    {
        if ($this->state['state'] === self::STATE_RUNNING) {
            $this->state['state'] = self::STATE_PAUSED;
            $this->touch();
        }
    }

    public function resumeRun(): void
    {
        if ($this->state['state'] === self::STATE_PAUSED) {
            $this->state['state'] = self::STATE_RUNNING;
            $this->touch();
        }
    }

    public function reset(): void
    {
        $this->state = $this->defaultState();
        $this->save();
    }

    /**
     * Snapshot for the AJAX poll endpoint.
     *
     * @return array{
     *     state:string, run_id:string, current_phase:string,
     *     overall_percent:float, phase_percent:float,
     *     processed:int, total:int,
     *     elapsed:int, eta:int,
     *     speed:float, memory_peak:int, last_error:?string
     * }
     */
    public function snapshot(): array
    {
        $phases = $this->state['phases'];
        $processed = 0;
        $total = 0;
        foreach ($phases as $p) {
            $processed += $p['done'];
            $total += $p['total'];
        }

        $current = $this->state['current_phase'];
        $currentPhase = $phases[$current] ?? null;
        $phasePercent = $currentPhase && $currentPhase['total'] > 0
            ? round(100 * $currentPhase['done'] / $currentPhase['total'], 1)
            : 0.0;

        $overallPercent = $total > 0 ? round(100 * $processed / $total, 1) : 0.0;

        $elapsed = max(1, time() - (int) $this->state['started_at']);
        $speed = $processed / $elapsed; // records per second
        $remaining = max(0, $total - $processed);
        $eta = $speed > 0 ? (int) ceil($remaining / $speed) : 0;

        return [
            'state' => $this->state['state'],
            'run_id' => $this->state['run_id'],
            'current_phase' => $current,
            'overall_percent' => $overallPercent,
            'phase_percent' => $phasePercent,
            'processed' => $processed,
            'total' => $total,
            'elapsed' => $elapsed,
            'eta' => $eta,
            'speed' => round($speed, 2),
            'memory_peak' => memory_get_peak_usage(true),
            'last_error' => $this->state['last_error'],
        ];
    }

    private function touch(): void
    {
        $this->state['updated_at'] = time();
        $this->state['memory_peak'] = max((int) $this->state['memory_peak'], memory_get_peak_usage(true));
        $this->save();
    }

    private function save(): void
    {
        StateManager::set('progress', $this->state);
    }
}
