<?php
/**
 * ImportContext: the runtime bag passed to every Importer.
 *
 * Carries the active Source, the active Configuration, the live ProgressManager,
 * Logger, ConflictDetector, and the source→target ID maps that importers must
 * populate as they run (e.g. sourcePostId → typechoCid for later use by comments).
 *
 * @package WordPressImporter\Support
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Support;

use TypechoPlugin\WordPressImporter\Contract\SourceInterface;
use TypechoPlugin\WordPressImporter\Converter\GutenbergConverter;
use TypechoPlugin\WordPressImporter\Converter\ShortcodeConverter;
use TypechoPlugin\WordPressImporter\Support\ConflictDetector;
use TypechoPlugin\WordPressImporter\Support\Logger;
use TypechoPlugin\WordPressImporter\Support\ProgressManager;
use TypechoPlugin\WordPressImporter\Support\SettingsManager;

/**
 * @psalm-type Mode = 'keep'|'merge'|'clean'
 * @psalm-type SourceKind = 'mysql'|'wxr'|'zip'
 */
final class ImportContext
{
    /** @var array<int, int> sourceUserId → typechoUid */
    public array $userMap = [];

    /** @var array<int, int> sourceTermId → typechoMid */
    public array $termMap = [];

    /** @var array<int, int> sourcePostId → typechoCid */
    public array $postMap = [];

    /** @var array<int, int> sourcePostId → typechoCid (media only) */
    public array $mediaMap = [];

    /** @var array<int, int> sourceCommentId → typechoCoid */
    public array $commentMap = [];

    /** @var array<string, int> slug → typechoCid (for collision detection) */
    public array $slugIndex = [];

    /** Whether this run is a dry-run (no DB writes). */
    public bool $dryRun = false;

    /** Chunk size in rows per iteration. */
    public int $chunkSize = 100;

    public function __construct(
        public SourceInterface $source,
        public SettingsManager $settings,
        public ProgressManager $progress,
        public Logger $logger,
        public ConflictDetector $conflicts,
        public ShortcodeConverter $shortcodes,
        public GutenbergConverter $gutenberg,
    ) {
        $this->chunkSize = $settings->chunkSize();
        $this->dryRun = $settings->dryRun();
    }
}
