<?php
/**
 * ConflictDetector — detects and resolves duplicate entities.
 *
 * Duplicates can occur:
 *   - Before import: the user runs Clean mode but data already exists in TypeRenew
 *     with the same slug/email — only relevant in 'keep' / 'merge' modes.
 *   - During import: same slug from WP source itself, or WP slug already in TypeRenew.
 *
 * Resolution policies (per Settings):
 *   - 'skip'    → keep the existing TypeRenew record, ignore the WP record
 *   - 'rename'  → append -2, -3 etc. to the incoming slug
 *   - 'replace' → overwrite the existing TypeRenew record with WP data (merge mode only)
 *   - 'ask'     → record the conflict for later user resolution (interactive mode)
 *
 * @package WordPressImporter\Support
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Support;

use Typecho\Db;
use TypechoPlugin\WordPressImporter\Exception\ConflictException;

final class ConflictDetector
{
    /** @var array<string, array{kind:string, source:string, target:string, message:string}> */
    private array $conflicts = [];

    /** @var array<string, string> Slug → resolution policy. */
    private array $slugPolicy = [];

    /** @var array<string, string> Email → resolution policy. */
    private array $emailPolicy = [];

    public function __construct(
        private Db $db,
        private string $prefix,
    ) {
    }

    /**
     * Load existing TypeRenew slug → cid index for the slug namespace.
     * Called once at the start of the import.
     */
    public function primeSlugIndex(): void
    {
        $rows = $this->db->fetchAll(
            $this->db->select('cid', 'slug')->from('table.contents')->where('slug IS NOT NULL')
        );
        foreach ($rows as $row) {
            $this->slugIndex[(string) $row['slug']] = (int) $row['cid'];
        }
    }

    /** @var array<string, int> */
    private array $slugIndex = [];

    /** @var array<string, int> */
    private array $emailIndex = [];

    public function primeEmailIndex(): void
    {
        $rows = $this->db->fetchAll(
            $this->db->select('uid', 'mail')->from('table.users')->where('mail IS NOT NULL AND mail <> ""')
        );
        foreach ($rows as $row) {
            $this->emailIndex[strtolower((string) $row['mail'])] = (int) $row['uid'];
        }
    }

    /**
     * Reserve a slug for an incoming record.
     *
     * @param string   $slug     Desired slug.
     * @param int|null $sourceId Source-side ID (for logging).
     *
     * @return array{slug:string, conflict:bool, target_id:?int}
     */
    public function reserveSlug(string $slug, ?int $sourceId = null): array
    {
        $slug = trim($slug);
        if ($slug === '') {
            $slug = 'post-' . ($sourceId ?? 'x');
        }
        // contents.slug is varchar(150) with a UNIQUE key — leave room for
        // the "-N" suffixes generated on collision.
        $slug = mb_substr($slug, 0, 140);

        if (!isset($this->slugIndex[$slug])) {
            $this->slugIndex[$slug] = -1; // reserve
            return ['slug' => $slug, 'conflict' => false, 'target_id' => null];
        }

        // Conflict.
        $policy = $this->slugPolicy[$slug] ?? 'rename';
        $this->conflicts[] = [
            'kind' => 'slug',
            'source' => $slug,
            'target' => (string) ($this->slugIndex[$slug] ?? ''),
            'message' => "Slug collision on '{$slug}'",
        ];

        if ($policy === 'skip') {
            return ['slug' => $slug, 'conflict' => true, 'target_id' => $this->slugIndex[$slug] ?? null];
        }

        // Rename: append -2, -3, ...
        $i = 2;
        $candidate = "{$slug}-{$i}";
        while (isset($this->slugIndex[$candidate])) {
            $i++;
            $candidate = "{$slug}-{$i}";
        }
        $this->slugIndex[$candidate] = -1;
        return ['slug' => $candidate, 'conflict' => true, 'target_id' => null];
    }

    /**
     * Check whether an email already exists in TypeRenew (or has been already
     * reserved during this import run).
     *
     * @return array{exists:bool, target_id:?int}
     */
    public function checkEmail(string $email): array
    {
        $email = strtolower(trim($email));
        if ($email === '') {
            return ['exists' => false, 'target_id' => null];
        }
        if (isset($this->emailIndex[$email])) {
            return ['exists' => true, 'target_id' => $this->emailIndex[$email]];
        }
        return ['exists' => false, 'target_id' => null];
    }

    /**
     * Mark an email as reserved (i.e. we just inserted a user with this email).
     */
    public function reserveEmail(string $email, int $uid): void
    {
        $this->emailIndex[strtolower(trim($email))] = $uid;
    }

    /**
     * Register a category slug → mid mapping for term deduplication.
     */
    public function reserveTermSlug(string $slug, int $mid): void
    {
        // Term slugs live in the metas table; reuse slugIndex namespace but with a
        // separate prefix to avoid collisions with content slugs.
        $key = 'term:' . $slug;
        $this->slugIndex[$key] = $mid;
    }

    public function checkTermSlug(string $slug): ?int
    {
        $key = 'term:' . $slug;
        return $this->slugIndex[$key] ?? null;
    }

    /**
     * @return list<array{kind:string, source:string, target:string, message:string}>
     */
    public function conflicts(): array
    {
        return array_values($this->conflicts);
    }

    public function setSlugPolicy(string $slug, string $policy): void
    {
        $this->slugPolicy[$slug] = $policy;
    }

    public function setEmailPolicy(string $email, string $policy): void
    {
        $this->emailPolicy[strtolower($email)] = $policy;
    }

    public function reset(): void
    {
        $this->conflicts = [];
        $this->slugIndex = [];
        $this->emailIndex = [];
        $this->slugPolicy = [];
        $this->emailPolicy = [];
    }
}
