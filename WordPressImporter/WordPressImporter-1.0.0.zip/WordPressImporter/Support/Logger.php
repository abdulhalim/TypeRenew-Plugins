<?php
/**
 * Logger — structured import log with severity levels.
 *
 * Persists every event to the state table so it survives across AJAX requests.
 * Also keeps an in-process ring buffer for the live log tail.
 *
 * @package WordPressImporter\Support
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Support;

final class Logger
{
    public const DEBUG = 'debug';
    public const INFO = 'info';
    public const NOTICE = 'notice';
    public const WARNING = 'warning';
    public const ERROR = 'error';
    public const CRITICAL = 'critical';

    /** @var list<array{ts:int, level:string, phase:string, message:string, context:array}> */
    private array $buffer = [];

    /** Max events kept in the ring buffer (older events still readable from state).
     *
     * Lowered from 200 to 50: the live-log panel polls a SEPARATE request
     * every ~1.5s and can only see flushed events — with 200 buffered events
     * the wizard's log tail appeared frozen during long phases.
     */
    public const BUFFER_LIMIT = 50;

    /** Max events persisted to state. */
    public const STATE_LIMIT = 5000;

    public function __construct(
        private string $phase = 'system',
    ) {
    }

    public function setPhase(string $phase): void
    {
        $this->phase = $phase;
    }

    public function debug(string $message, array $context = []): void
    {
        $this->record(self::DEBUG, $message, $context);
    }

    public function info(string $message, array $context = []): void
    {
        $this->record(self::INFO, $message, $context);
    }

    public function notice(string $message, array $context = []): void
    {
        $this->record(self::NOTICE, $message, $context);
    }

    public function warning(string $message, array $context = []): void
    {
        $this->record(self::WARNING, $message, $context);
    }

    public function error(string $message, array $context = []): void
    {
        $this->record(self::ERROR, $message, $context);
        // Errors are interesting immediately — don't leave them in the
        // in-process buffer where the polling UI can't see them yet.
        $this->flush();
    }

    public function critical(string $message, array $context = []): void
    {
        $this->record(self::CRITICAL, $message, $context);
        $this->flush();
    }

    /**
     * @return list<array{ts:int, level:string, phase:string, message:string, context:array}>
     */
    public function tail(int $limit = 100): array
    {
        $all = StateManager::get('logs', []);
        if (!is_array($all)) {
            return [];
        }
        return array_slice($all, -$limit);
    }

    /**
     * @return array{debug:int,info:int,notice:int,warning:int,error:int,critical:int,total:int}
     */
    public function counts(): array
    {
        $all = StateManager::get('logs', []);
        $counts = ['debug' => 0, 'info' => 0, 'notice' => 0, 'warning' => 0, 'error' => 0, 'critical' => 0, 'total' => 0];
        foreach ($all as $entry) {
            $level = $entry['level'] ?? 'info';
            $counts[$level] = ($counts[$level] ?? 0) + 1;
            $counts['total']++;
        }
        return $counts;
    }

    /**
     * Export logs as a downloadable plain-text report.
     */
    public function exportText(): string
    {
        $all = StateManager::get('logs', []);
        $lines = [];
        $lines[] = 'گزارش ایمپورتر وردپرس — WordPress Importer';
        $lines[] = 'تاریخ تولید: ' . date('Y-m-d H:i:s');
        $lines[] = str_repeat('-', 60);

        foreach ($all as $entry) {
            $ts = date('Y-m-d H:i:s', (int) $entry['ts']);
            $level = strtoupper(str_pad((string) $entry['level'], 8));
            $phase = (string) $entry['phase'];
            $message = (string) $entry['message'];
            $context = $entry['context'] ?? [];
            $ctx = $context === [] ? '' : ' ' . json_encode($context, JSON_UNESCAPED_UNICODE);
            $lines[] = "[{$ts}] {$level} [{$phase}] {$message}{$ctx}";
        }

        $counts = $this->counts();
        $lines[] = str_repeat('-', 60);
        $lines[] = sprintf(
            'جمع‌بندی: مجموع=%s هشدار=%s خطا=%s بحرانی=%s',
            (string) $counts['total'],
            (string) $counts['warning'],
            (string) $counts['error'],
            (string) $counts['critical']
        );

        return implode("\n", $lines);
    }

    public function clear(): void
    {
        $this->buffer = [];
        StateManager::delete('logs');
    }

    private function record(string $level, string $message, array $context): void
    {
        $entry = [
            'ts' => time(),
            'level' => $level,
            'phase' => $this->phase,
            'message' => $message,
            'context' => $context,
        ];

        $this->buffer[] = $entry;
        if (count($this->buffer) > self::BUFFER_LIMIT) {
            $this->flush();
        }
    }

    /**
     * Flush in-memory buffer to persistent state.
     */
    public function flush(): void
    {
        if ($this->buffer === []) {
            return;
        }

        $existing = StateManager::get('logs', []);
        if (!is_array($existing)) {
            $existing = [];
        }

        $merged = array_merge($existing, $this->buffer);

        // Cap to state limit — drop oldest entries.
        if (count($merged) > self::STATE_LIMIT) {
            $merged = array_slice($merged, -self::STATE_LIMIT);
        }

        StateManager::set('logs', $merged);
        $this->buffer = [];
    }
}
