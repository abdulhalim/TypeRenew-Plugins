<?php
/**
 * Navigation menu item.
 *
 * @package WordPressImporter\Support
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Support;

final readonly class MenuItemRecord
{
    public function __construct(
        public int $sourceId,
        public int $sourceMenuId,
        public string $menuName,        // logical menu name (e.g. "Main Menu")
        public string $menuSlug,
        public int $order,
        public ?int $sourceParentId,
        public string $title,
        public string $url,
        public string $objectType,      // 'custom' | 'post_type' | 'taxonomy'
        public ?string $objectSlug,
    ) {
    }
}
