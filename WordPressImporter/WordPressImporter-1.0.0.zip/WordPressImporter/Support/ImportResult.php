<?php
/**
 * ImportResult: summary returned by each Importer after a phase completes.
 *
 * @package WordPressImporter\Support
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Support;

final class ImportResult
{
    public int $total = 0;
    public int $imported = 0;
    public int $skipped = 0;
    public int $failed = 0;
    public int $duplicates = 0;

    /** @var list<string> */
    public array $warnings = [];

    public function addImported(int $n = 1): void
    {
        $this->imported += $n;
        $this->total += $n;
    }

    public function addSkipped(int $n = 1, ?string $reason = null): void
    {
        $this->skipped += $n;
        $this->total += $n;
        if ($reason !== null) {
            $this->warnings[] = $reason;
        }
    }

    public function addFailed(int $n = 1, ?string $reason = null): void
    {
        $this->failed += $n;
        $this->total += $n;
        if ($reason !== null) {
            $this->warnings[] = $reason;
        }
    }

    public function addDuplicate(int $n = 1): void
    {
        $this->duplicates += $n;
    }

    /**
     * Merge another result into this one.
     */
    public function merge(self $other): void
    {
        $this->total += $other->total;
        $this->imported += $other->imported;
        $this->skipped += $other->skipped;
        $this->failed += $other->failed;
        $this->duplicates += $other->duplicates;
        foreach ($other->warnings as $w) {
            $this->warnings[] = $w;
        }
    }

    public function toArray(): array
    {
        return [
            'total' => $this->total,
            'imported' => $this->imported,
            'skipped' => $this->skipped,
            'failed' => $this->failed,
            'duplicates' => $this->duplicates,
            'warnings' => $this->warnings,
        ];
    }
}
