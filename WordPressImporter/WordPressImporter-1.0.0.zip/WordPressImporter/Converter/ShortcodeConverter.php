<?php
/**
 * ShortcodeConverter — converts WordPress shortcodes to HTML.
 *
 * Supported shortcodes:
 *   - gallery          → <figure> with thumbnails
 *   - caption          → <figure><figcaption>
 *   - embed / youtube  → responsive iframe (YouTube / Vimeo)
 *
 * Unknown shortcodes are wrapped in an HTML comment so they remain visible
 * to the editor but are not rendered as raw text on the front-end.
 *
 * @package WordPressImporter\Converter
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Converter;

use TypechoPlugin\WordPressImporter\Contract\ConverterInterface;

final class ShortcodeConverter implements ConverterInterface
{
    public function __construct(
        private bool $enabled = true,
    ) {
    }

    public function enabled(): bool
    {
        return $this->enabled;
    }

    public function convert(string $content): string
    {
        if (!$this->enabled) {
            return $content;
        }

        // Register handlers. We use a simple regex-based parser because
        // WordPress's own shortcode API isn't available inside TypeRenew.
        $handlers = [
            'gallery'     => $this->gallery(...),
            'caption'     => $this->caption(...),
            'wp_caption'  => $this->caption(...),
            'embed'       => $this->embed(...),
            'youtube'     => $this->embed(...),
            'aligncenter' => $this->passthrough(...),
            'alignleft'   => $this->passthrough(...),
            'alignright'  => $this->passthrough(...),
        ];

        // Allow extensions to register custom handlers.
        $custom = $this->applyFilter('wordpress_importer_shortcodes', []);
        if (is_array($custom)) {
            $handlers = array_merge($handlers, $custom);
        }

        // Apply handlers in order. Each handler receives (attrs array, inner content).
        foreach ($handlers as $tag => $handler) {
            $content = $this->replaceShortcode($content, $tag, $handler);
        }

        // Any remaining shortcodes → wrap in HTML comment for visibility.
        $content = preg_replace_callback(
            '/\[([a-z0-9_-]+)([^\]]*)\](?:(.*?)\[\/\1\])?/is',
            static function (array $m): string {
                $tag = $m[1] ?? '';
                $attrs = $m[2] ?? '';
                $inner = $m[3] ?? '';
                if ($tag === '') {
                    return $m[0];
                }
                if ($inner !== '') {
                    return "<!-- unknown shortcode [{$tag}{$attrs}]{$inner}[/{$tag}] -->";
                }
                return "<!-- unknown shortcode [{$tag}{$attrs}] -->";
            },
            $content
        ) ?? $content;

        return $content;
    }

    /**
     * Replace all instances of a single shortcode tag using a callable.
     *
     * @param callable(array<string,string>, string): string $handler
     */
    private function replaceShortcode(string $content, string $tag, callable $handler): string
    {
        // Self-closing form: [tag attrs] or [tag attrs /]
        $selfClosing = '/\[' . preg_quote($tag, '/') . '([^\]]*?)\/?\]/is';
        // Wrapped form: [tag attrs]inner[/tag]
        $wrapped = '/\[' . preg_quote($tag, '/') . '([^\]]*?)\](.*?)\[\/' . preg_quote($tag, '/') . '\]/is';

        // Run wrapped first (greedy) so the self-closing regex doesn't break it.
        $content = preg_replace_callback($wrapped, function (array $m) use ($handler) {
            return $handler($this->parseAttrs($m[1] ?? ''), $m[2] ?? '');
        }, $content) ?? $content;

        $content = preg_replace_callback($selfClosing, function (array $m) use ($handler) {
            return $handler($this->parseAttrs($m[1] ?? ''), '');
        }, $content) ?? $content;

        return $content;
    }

    /**
     * Parse WordPress shortcode attributes string into an associative array.
     */
    private function parseAttrs(string $attrString): array
    {
        $attrs = [];
        // Match key="value" or key='value' or key=value or just bare value (becomes [0])
        preg_match_all('/(\w+)\s*=\s*"([^"]*)"|(\w+)\s*=\s*\'([^\']*)\'|(\w+)\s*=\s*(\S+)|^(\S+)/', trim($attrString), $matches, PREG_SET_ORDER);
        foreach ($matches as $m) {
            if (!empty($m[1])) {
                $attrs[$m[1]] = $m[2];
            } elseif (!empty($m[3])) {
                $attrs[$m[3]] = $m[4];
            } elseif (!empty($m[5])) {
                $attrs[$m[5]] = $m[6];
            } elseif (!empty($m[7])) {
                $attrs[0] = $m[7];
            }
        }
        return $attrs;
    }

    /* ----- handlers ----- */

    /**
     * [gallery ids="1,2,3" columns="3" size="thumbnail"]
     */
    private function gallery(array $attrs, string $inner): string
    {
        $ids = $attrs['ids'] ?? $attrs[0] ?? '';
        if ($ids === '') {
            return '<!-- empty gallery -->';
        }
        $list = array_filter(array_map('trim', explode(',', (string) $ids)));
        $columns = (int) ($attrs['columns'] ?? 3);
        $items = array_map(static fn (string $id) => "<li><img src=\"attachment:{$id}\" alt=\"attachment-{$id}\" /></li>", $list);
        return sprintf(
            '<figure class="wp-gallery" data-columns="%d"><ul>%s</ul></figure>',
            $columns,
            implode('', $items)
        );
    }

    /**
     * [caption id="attachment_42" align="aligncenter" width="640"]<img .../>Caption text[/caption]
     */
    private function caption(array $attrs, string $inner): string
    {
        $align = $attrs['align'] ?? 'alignnone';
        $width = $attrs['width'] ?? '';
        $id = $attrs['id'] ?? '';

        // Split inner into HTML + caption text: WP convention is `<img ...>Caption text`.
        $caption = '';
        $html = $inner;
        if (preg_match('/^(.*?)([^<>\s][^<>]*)$/s', $inner, $m)) {
            $html = $m[1] ?? '';
            $caption = trim($m[2] ?? '');
        }

        $styleAttr = $width !== '' ? sprintf(' style="width:%dpx"', (int) $width) : '';
        $idAttr = $id !== '' ? sprintf(' id="%s"', htmlspecialchars($id)) : '';

        return sprintf(
            '<figure class="wp-caption %s"%s%s>%s<figcaption class="wp-caption-text">%s</figcaption></figure>',
            htmlspecialchars($align),
            $idAttr,
            $styleAttr,
            $html,
            htmlspecialchars($caption)
        );
    }

    /**
     * [embed]https://www.youtube.com/watch?v=...[/embed]
     * [youtube url="..."] or [youtube]id[/youtube]
     */
    private function embed(array $attrs, string $inner): string
    {
        $url = $attrs['src'] ?? $attrs['url'] ?? trim(strip_tags($inner));
        if ($url === '') {
            return '<!-- empty embed -->';
        }

        // YouTube / Vimeo iframe embedding
        if (preg_match('#(?:youtube\.com/watch\?v=|youtu\.be/)([A-Za-z0-9_-]{6,})#', $url, $m)) {
            $id = $m[1];
            return sprintf(
                '<div class="wp-embed-youtube" style="position:relative;padding-bottom:56.25%%;height:0;overflow:hidden;"><iframe src="https://www.youtube.com/embed/%s" frameborder="0" allowfullscreen style="position:absolute;top:0;left:0;width:100%%;height:100%%;"></iframe></div>',
                htmlspecialchars($id)
            );
        }
        if (preg_match('#vimeo\.com/(\d+)#', $url, $m)) {
            $id = $m[1];
            return sprintf(
                '<div class="wp-embed-vimeo" style="position:relative;padding-bottom:56.25%%;height:0;overflow:hidden;"><iframe src="https://player.vimeo.com/video/%s" frameborder="0" allowfullscreen style="position:absolute;top:0;left:0;width:100%%;height:100%%;"></iframe></div>',
                htmlspecialchars($id)
            );
        }
        return sprintf('<p><a href="%s" rel="nofollow">%s</a></p>', htmlspecialchars($url), htmlspecialchars($url));
    }

    /**
     * Pass-through for styling-only shortcodes.
     */
    private function passthrough(array $attrs, string $inner): string
    {
        return $inner;
    }

    /**
     * Tiny filter shim — TypeRenew's plugin system can replace this with
     * Plugin::factory()->filter() if needed.
     */
    private function applyFilter(string $name, mixed $value): mixed
    {
        if (class_exists(\Typecho\Plugin::class)) {
            try {
                return \Typecho\Plugin::factory()->filter($name, $value);
            } catch (\Throwable) {
                return $value;
            }
        }
        return $value;
    }
}
