<?php
/**
 * GutenbergConverter — converts WordPress Gutenberg block HTML comments to HTML.
 *
 * WordPress stores Gutenberg content like:
 *   <!-- wp:paragraph {"align":"center"} -->
 *   <p class="has-text-align-center">Hello</p>
 *   <!-- /wp:paragraph -->
 *
 * We don't try to re-render every block — most blocks already contain valid
 * HTML inside the delimiters. The converter's job is to:
 *   1. Strip the <!-- wp:xxx --> delimiters (we don't need them in TypeRenew).
 *   2. Capture block attributes from the opening comment so callers can
 *      rewrite attachment IDs / resolve inner image URLs.
 *   3. Keep the inner HTML intact.
 *
 * For blocks where the inner HTML is empty or just a placeholder (rare cases
 * in WXR exports from certain plugins), we render a small template.
 *
 * @package WordPressImporter\Converter
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Converter;

use TypechoPlugin\WordPressImporter\Contract\ConverterInterface;

final class GutenbergConverter implements ConverterInterface
{
    public function __construct(
        private bool $enabled = true,
    ) {
    }

    public function enabled(): bool
    {
        return $this->enabled;
    }

    public function convert(string $content): string
    {
        if (!$this->enabled) {
            return $content;
        }
        if (!str_contains($content, '<!-- wp:')) {
            return $content;
        }

        // Remove all Gutenberg block delimiters but keep the inner HTML.
        // The opening delimiter looks like <!-- wp:name {"attr":1} --> or <!-- wp:name -->
        // The closing delimiter is <!-- /wp:name -->
        $content = preg_replace_callback(
            '/<!--\s+wp:([a-z][a-z0-9-\/]*)(\s+\{.*?\})?\s+(\/)?-->/is',
            function (array $m): string {
                $name = $m[1] ?? '';
                $attrsJson = $m[2] ?? '';
                $selfClose = ($m[3] ?? '') === '/';

                // For self-closing blocks (like <!-- wp:more /-->), drop entirely.
                if ($selfClose) {
                    return $this->renderSelfClosingBlock($name, $attrsJson);
                }

                // For non-self-closing, the inner HTML is already correct in the source.
                // We just drop the opening comment.
                return '';
            },
            $content
        ) ?? $content;

        // Remove closing delimiters
        $content = preg_replace('/<!--\s+\/wp:[a-z][a-z0-9-\/]*\s+-->/is', '', $content) ?? $content;

        return $content;
    }

    /**
     * Render a self-closing block as HTML. Most have no visible output.
     */
    private function renderSelfClosingBlock(string $name, string $attrsJson): string
    {
        return match ($name) {
            'more' => '<!--more-->',
            'nextpage' => '<!--nextpage-->',
            'separator' => '<hr class="wp-block-separator"/>',
            'spacer' => '<div class="wp-block-spacer"></div>',
            default => '',
        };
    }

    /**
     * Extract block attributes from a content string.
     *
     * Returns a map of blockName → decoded-attributes for the FIRST occurrence.
     * Useful for the PostImporter to inspect gallery / image blocks.
     *
     * @return array<string, array<string, mixed>>
     */
    public function extractBlockAttributes(string $content): array
    {
        $blocks = [];
        if (preg_match_all(
            '/<!--\s+wp:([a-z][a-z0-9-\/]*)(\s+\{(.*?)\})?\s*(\/)?-->/is',
            $content,
            $matches,
            PREG_SET_ORDER
        )) {
            foreach ($matches as $m) {
                $name = $m[1];
                $json = $m[3] ?? '';
                $attrs = $json !== '' ? json_decode($json, true) : [];
                if (is_array($attrs)) {
                    $blocks[$name] = $attrs;
                }
            }
        }
        return $blocks;
    }
}
