<?php
/**
 * ZIPSource — adapter for a ZIP package containing a WXR file + media folder.
 *
 * On construction:
 *   - Extracts the ZIP to a temp dir under the plugin's uploads directory.
 *   - Locates the WXR (.xml) file inside.
 *   - Delegates record streaming to an inner WXRSource.
 *   - Overrides WXRSource's media handling so URLs are rewritten to the
 *     extracted media folder.
 *
 * @package WordPressImporter\Source
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Source;

use Generator;
use TypechoPlugin\WordPressImporter\Contract\SourceInterface;
use TypechoPlugin\WordPressImporter\Exception\SourceException;
use TypechoPlugin\WordPressImporter\Support\AuthorRecord;
use TypechoPlugin\WordPressImporter\Support\CategoryRecord;
use TypechoPlugin\WordPressImporter\Support\CommentRecord;
use TypechoPlugin\WordPressImporter\Support\MediaRecord;
use TypechoPlugin\WordPressImporter\Support\MenuItemRecord;
use TypechoPlugin\WordPressImporter\Support\PostMetaRecord;
use TypechoPlugin\WordPressImporter\Support\PostRecord;
use ZipArchive;

final class ZIPSource implements SourceInterface
{
    private WXRSource $inner;
    private string $extractDir;

    public function __construct(
        private string $zipPath,
    ) {
        if (!class_exists(ZipArchive::class)) {
            throw new SourceException('افزونهٔ ZipArchive برای پردازش بسته‌های ZIP لازم است.');
        }

        $extractDir = dirname(__DIR__, 2) . '/uploads/' . bin2hex(random_bytes(8));
        if (!@mkdir($extractDir, 0775, true) && !is_dir($extractDir)) {
            throw new SourceException("ساخت پوشهٔ موقت برای استخراج ناموفق بود: {$extractDir}");
        }
        $this->extractDir = $extractDir;

        $zip = new ZipArchive();
        $code = $zip->open($this->zipPath);
        if ($code !== true) {
            throw new SourceException("باز کردن ZIP ناموفق بود (کد {$code})");
        }

        // FIXED: ZipArchive::extractTo() historically does NOT guard against
        // path-traversal entries ("../../evil.php" — a.k.a. Zip Slip), so the
        // archive is extracted entry-by-entry with an explicit realpath check.
        $extractRoot = (string) realpath($extractDir);
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $entry = (string) $zip->getNameIndex($i);
            if ($entry === '' || str_ends_with($entry, '/')) {
                continue; // directories are created implicitly below
            }

            $target = $extractDir . '/' . $entry;
            // Create parent dirs FIRST so realpath() can resolve them for
            // the containment check that follows.
            @mkdir(dirname($target), 0775, true);

            $realTarget = realpath(dirname($target));
            if (
                $realTarget === false
                || !str_starts_with($realTarget . DIRECTORY_SEPARATOR, $extractRoot . DIRECTORY_SEPARATOR)
            ) {
                $zip->close();
                throw new SourceException("مدخل ZIP مسیر نامعتبر دارد و به دلایل امنیتی نادیده گرفته نمی‌شود: {$entry}");
            }

            $stream = $zip->getStream($entry);
            if ($stream === false) {
                $zip->close();
                throw new SourceException("خواندن مدخل ZIP ناموفق بود: {$entry}");
            }
            $out = @fopen($target, 'wb');
            if ($out === false) {
                fclose($stream);
                $zip->close();
                throw new SourceException("نوشتن فایل استخراج‌شده ناموفق بود: {$target}");
            }
            try {
                while (!feof($stream)) {
                    $chunk = fread($stream, 64 * 1024);
                    if ($chunk === false) {
                        break;
                    }
                    fwrite($out, $chunk);
                }
            } finally {
                fclose($stream);
                fclose($out);
            }
        }
        $zip->close();

        // Find WXR
        $wxr = $this->findWxr($extractDir);
        if ($wxr === null) {
            throw new SourceException('بستهٔ ZIP شامل فایل WXR (.xml) نیست.');
        }
        $this->inner = new WXRSource($wxr);
    }

    public function validate(): array
    {
        return $this->inner->validate();
    }

    public function streamUsers(): Generator
    {
        yield from $this->inner->streamUsers();
    }

    public function streamTerms(): Generator
    {
        yield from $this->inner->streamTerms();
    }

    public function streamPosts(array $types = ['post', 'page']): Generator
    {
        yield from $this->inner->streamPosts($types);
    }

    public function streamMedia(): Generator
    {
        foreach ($this->inner->streamMedia() as $id => $media) {
            // Resolve URL against extracted media folder if the WXR only contains a relative path.
            $url = $media->url;
            $filePath = $media->filePath;

            if ($filePath === '' && $url !== '') {
                // Try to find the file inside the extract dir.
                $basename = basename(parse_url($url, PHP_URL_PATH) ?: '');
                if ($basename !== '') {
                    $candidate = $this->extractDir . '/uploads/' . $basename;
                    if (is_file($candidate)) {
                        $filePath = $candidate;
                    } else {
                        // Search recursively.
                        $candidate = $this->findFile($this->extractDir, $basename);
                        if ($candidate !== null) {
                            $filePath = $candidate;
                        }
                    }
                }
            }

            yield $id => new MediaRecord(
                sourceId: $media->sourceId,
                sourceParentId: $media->sourceParentId,
                title: $media->title,
                slug: $media->slug,
                mime: $media->mime,
                url: $url,
                filePath: $filePath,
                size: $filePath !== '' && is_file($filePath) ? (int) filesize($filePath) : 0,
                uploadedAt: $media->uploadedAt,
                description: $media->description,
                altText: $media->altText,
            );
        }
    }

    public function streamComments(array $sourcePostIds): Generator
    {
        yield from $this->inner->streamComments($sourcePostIds);
    }

    public function streamPostMeta(array $sourcePostIds): Generator
    {
        yield from $this->inner->streamPostMeta($sourcePostIds);
    }

    public function streamMenuItems(): Generator
    {
        yield from $this->inner->streamMenuItems();
    }

    public function statistics(): array
    {
        return $this->inner->statistics();
    }

    public function close(): void
    {
        $this->inner->close();
        // FIXED: best-effort cleanup — the old glob('*') + rmdir only removed
        // top-level files, leaving extracted subdirectories behind forever.
        $this->recursiveRmdir($this->extractDir);
    }

    /**
     * Recursively delete a directory tree (best-effort).
     */
    private function recursiveRmdir(string $dir): void
    {
        if (!is_dir($dir)) {
            return;
        }
        $items = scandir($dir);
        foreach ($items === false ? [] : $items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            $path = $dir . '/' . $item;
            if (is_dir($path) && !is_link($path)) {
                $this->recursiveRmdir($path);
            } else {
                @unlink($path);
            }
        }
        @rmdir($dir);
    }

    public function extractDir(): string
    {
        return $this->extractDir;
    }

    /* ----- internals ----- */

    private function findWxr(string $dir): ?string
    {
        $rii = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS));
        foreach ($rii as $file) {
            if ($file->isFile() && preg_match('/\.(xml|wxr)$/i', $file->getFilename())) {
                return $file->getPathname();
            }
        }
        return null;
    }

    private function findFile(string $dir, string $basename): ?string
    {
        $rii = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS));
        foreach ($rii as $file) {
            if ($file->isFile() && $file->getFilename() === $basename) {
                return $file->getPathname();
            }
        }
        return null;
    }
}
