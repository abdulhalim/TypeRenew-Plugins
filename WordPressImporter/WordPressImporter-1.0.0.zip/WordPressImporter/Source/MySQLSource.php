<?php
/**
 * MySQLSource — reads directly from a WordPress MySQL database.
 *
 * Uses a separate PDO connection (read-only) so we don't interfere with the
 * TypeRenew Db adapter. All stream* methods use unbuffered queries and yield
 * records one at a time to keep memory flat regardless of dataset size.
 *
 * @package WordPressImporter\Source
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Source;

use Generator;
use PDO;
use PDOStatement;
use TypechoPlugin\WordPressImporter\Contract\SourceInterface;
use TypechoPlugin\WordPressImporter\Exception\SourceException;
use TypechoPlugin\WordPressImporter\Support\AuthorRecord;
use TypechoPlugin\WordPressImporter\Support\CategoryRecord;
use TypechoPlugin\WordPressImporter\Support\CommentRecord;
use TypechoPlugin\WordPressImporter\Support\MediaRecord;
use TypechoPlugin\WordPressImporter\Support\MenuItemRecord;
use TypechoPlugin\WordPressImporter\Support\PostMetaRecord;
use TypechoPlugin\WordPressImporter\Support\PostRecord;

final class MySQLSource implements SourceInterface
{
    private ?PDO $pdo = null;

    /**
     * Second, BUFFERED connection used for the small per-post lookups that
     * run INSIDE the loop of an unbuffered stream.
     *
     * With PDO::MYSQL_ATTR_USE_BUFFERED_QUERY = false, MySQL allows only ONE
     * active statement per connection — executing a nested query on the same
     * handle raises "Cannot execute queries while other unbuffered queries
     * are active" (HY000 / 2014). The previous implementation did exactly
     * that inside streamPosts(), so the very first post crashed the import.
     */
    private ?PDO $lookupPdo = null;

    private string $prefix;

    /**
     * @param array{host:string,port:int,user:string,password:string,database:string,prefix:string} $cfg
     */
    public function __construct(
        private array $cfg,
    ) {
        $this->prefix = $cfg['prefix'];
    }

    public function validate(): array
    {
        $warnings = [];

        try {
            $pdo = $this->pdo();
            $version = (string) $pdo->getAttribute(PDO::ATTR_SERVER_VERSION);
            if (version_compare($version, '5.7.7', '<')) {
                $warnings[] = "نسخهٔ MySQL وردپرس ({$version}) قدیمی‌تر از نسخهٔ توصیه‌شده است.";
            }

            // Encoding check
            $charset = $pdo->query("SELECT default_character_set_name FROM information_schema.SCHEMATA WHERE schema_name = DATABASE()")->fetchColumn();
            if ($charset && !in_array($charset, ['utf8', 'utf8mb4'], true)) {
                $warnings[] = "کدگذاری دیتابیس وردپرس {$charset} است؛ مورد انتظار utf8 یا utf8mb4 بود.";
            }
        } catch (\Throwable $e) {
            throw new SourceException('بررسی MySQL ناموفق بود: ' . $e->getMessage(), 0, $e);
        }

        return $warnings;
    }

    public function streamUsers(): Generator
    {
        // FIXED: use u.display_name (a real users-table column) for the
        // display name; the old query aliased the `nickname` usermeta row.
        $sql = "SELECT u.ID, u.user_login, u.user_email, u.user_url, u.user_registered,
                       u.display_name,
                       um_first.meta_value    AS first_name,
                       um_last.meta_value     AS last_name,
                       um_nick.meta_value     AS nickname,
                       um_role.meta_value     AS role,
                       u.user_pass
                FROM {$this->prefix}users u
                LEFT JOIN {$this->prefix}usermeta um_first    ON um_first.user_id    = u.ID AND um_first.meta_key    = 'first_name'
                LEFT JOIN {$this->prefix}usermeta um_last     ON um_last.user_id     = u.ID AND um_last.meta_key     = 'last_name'
                LEFT JOIN {$this->prefix}usermeta um_nick     ON um_nick.user_id     = u.ID AND um_nick.meta_key     = 'nickname'
                LEFT JOIN {$this->prefix}usermeta um_role     ON um_role.user_id     = u.ID AND um_role.meta_key     = '{$this->prefix}capabilities'
                ORDER BY u.ID";

        foreach ($this->unbuffered($sql) as $row) {
            $caps = maybe_unserialize($row['role'] ?? '');
            $role = is_array($caps) && $caps !== []
                ? (string) array_key_first($caps)
                : 'subscriber';

            yield (int) $row['ID'] => new AuthorRecord(
                sourceId: (int) $row['ID'],
                username: (string) $row['user_login'],
                email: (string) $row['user_email'],
                displayName: (string) (($row['display_name'] ?? '') !== '' ? $row['display_name'] : $row['user_login']),
                nickname: (string) ($row['nickname'] ?? $row['user_login']),
                firstName: (string) ($row['first_name'] ?? ''),
                lastName: (string) ($row['last_name'] ?? ''),
                url: (string) $row['user_url'],
                role: $role,
                registeredAt: $this->toTimestamp($row['user_registered']),
                passwordHash: (string) $row['user_pass'],
            );
        }
    }

    public function streamTerms(): Generator
    {
        // FIXED: `description` lives in wp_term_taxonomy (tt), NOT in wp_terms (t).
        // The old query selected t.description which crashed every direct-DB
        // import in the categories phase with "Unknown column 't.description'".
        $sql = "SELECT t.term_id, t.name, t.slug, tt.description, tt.taxonomy, tt.parent
                FROM {$this->prefix}terms t
                INNER JOIN {$this->prefix}term_taxonomy tt ON tt.term_id = t.term_id
                WHERE tt.taxonomy IN ('category', 'post_tag')
                ORDER BY t.term_id";

        foreach ($this->unbuffered($sql) as $row) {
            yield (int) $row['term_id'] => new CategoryRecord(
                sourceId: (int) $row['term_id'],
                name: (string) $row['name'],
                slug: (string) $row['slug'],
                description: (string) $row['description'],
                parentId: (int) $row['parent'],
                taxonomy: (string) $row['taxonomy'],
            );
        }
    }

    public function streamPosts(array $types = ['post', 'page']): Generator
    {
        $types = array_values(array_filter($types, fn ($t) => $t !== 'attachment'));
        if ($types === []) {
            return;
        }
        $inList = implode(',', array_fill(0, count($types), '?'));

        $sql = "SELECT p.ID, p.post_author, p.post_title, p.post_name, p.post_content, p.post_excerpt,
                       p.post_status, p.post_type, p.post_password, p.post_date_gmt, p.post_modified_gmt,
                       p.comment_status, p.ping_status, p.comment_count,
                       (
                           SELECT pm.meta_value FROM {$this->prefix}postmeta pm
                           WHERE pm.post_id = p.ID AND pm.meta_key = '_thumbnail_id' LIMIT 1
                       ) AS thumb_id
                FROM {$this->prefix}posts p
                WHERE p.post_type IN ({$inList})
                  AND p.post_status NOT IN ('auto-draft', 'inherit', 'trash')
                ORDER BY p.ID";

        foreach ($this->unbuffered($sql, $types) as $row) {
            $categoryIds = [];
            $tagIds = [];
            // FIXED (two bugs):
            //  1. this lookup now runs on the separate buffered connection —
            //     see $lookupPdo (nested queries on the unbuffered stream
            //     connection fail with PDO error 2014);
            //  2. we select tt.term_id (NOT tr.term_taxonomy_id) — the
            //     termMap is keyed by terms.term_id, and the two diverge on
            //     WordPress installs that have split shared terms.
            $rels = $this->lookupPdo()->prepare(
                "SELECT tt.term_id, tt.taxonomy
                 FROM {$this->prefix}term_relationships tr
                 INNER JOIN {$this->prefix}term_taxonomy tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
                 WHERE tr.object_id = ?"
            );
            $rels->execute([(int) $row['ID']]);
            foreach ($rels->fetchAll(PDO::FETCH_ASSOC) as $r) {
                if ($r['taxonomy'] === 'category') {
                    $categoryIds[] = (int) $r['term_id'];
                } elseif ($r['taxonomy'] === 'post_tag') {
                    $tagIds[] = (int) $r['term_id'];
                }
            }

            yield (int) $row['ID'] => new PostRecord(
                sourceId: (int) $row['ID'],
                sourceAuthorId: (int) $row['post_author'],
                title: (string) $row['post_title'],
                slug: (string) $row['post_name'],
                content: (string) $row['post_content'],
                excerpt: (string) $row['post_excerpt'],
                status: (string) $row['post_status'],
                type: (string) $row['post_type'],
                password: (string) $row['post_password'],
                createdAt: $this->toTimestamp($row['post_date_gmt']),
                modifiedAt: $this->toTimestamp($row['post_modified_gmt']),
                allowComments: $row['comment_status'] === 'open',
                allowPings: $row['ping_status'] === 'open',
                featuredImageId: $row['thumb_id'] !== null ? (int) $row['thumb_id'] : null,
                commentCount: (string) $row['comment_count'],
                categoryIds: $categoryIds,
                tagIds: $tagIds,
            );
        }
    }

    public function streamMedia(): Generator
    {
        $sql = "SELECT p.ID, p.post_parent, p.post_title, p.post_name, p.post_mime_type,
                       p.post_date_gmt, p.post_content, p.post_excerpt,
                       pm.meta_value AS attached_file,
                       pm_alt.meta_value AS alt_text
                FROM {$this->prefix}posts p
                LEFT JOIN {$this->prefix}postmeta pm     ON pm.post_id = p.ID AND pm.meta_key = '_wp_attached_file'
                LEFT JOIN {$this->prefix}postmeta pm_alt ON pm_alt.post_id = p.ID AND pm_alt.meta_key = '_wp_attachment_image_alt'
                WHERE p.post_type = 'attachment'
                ORDER BY p.ID";

        foreach ($this->unbuffered($sql) as $row) {
            $attachedFile = (string) ($row['attached_file'] ?? '');
            $url = $attachedFile !== '' ? $this->mediaUrl($attachedFile) : '';
            $path = $attachedFile !== '' ? $this->mediaPath($attachedFile) : '';

            yield (int) $row['ID'] => new MediaRecord(
                sourceId: (int) $row['ID'],
                sourceParentId: (int) $row['post_parent'],
                title: (string) $row['post_title'],
                slug: (string) $row['post_name'],
                mime: (string) $row['post_mime_type'],
                url: $url,
                filePath: $path,
                size: $path !== '' && is_file($path) ? (int) filesize($path) : 0,
                uploadedAt: $this->toTimestamp($row['post_date_gmt']),
                description: (string) $row['post_content'],
                altText: (string) ($row['alt_text'] ?? ''),
            );
        }
    }

    public function streamComments(array $sourcePostIds): Generator
    {
        if ($sourcePostIds === []) {
            return;
        }
        // Chunk to avoid MySQL packet size limits
        foreach (array_chunk($sourcePostIds, 1000) as $chunk) {
            $inList = implode(',', array_fill(0, count($chunk), '?'));
            $sql = "SELECT comment_ID, comment_post_ID, comment_parent,
                           user_id AS comment_user_id,
                           comment_author, comment_author_email, comment_author_url,
                           comment_author_IP, comment_agent, comment_content, comment_approved,
                           comment_type, comment_date_gmt
                    FROM {$this->prefix}comments
                    WHERE comment_post_ID IN ({$inList})
                    ORDER BY comment_ID";

            foreach ($this->unbuffered($sql, $chunk) as $row) {
                $status = match ($row['comment_approved']) {
                    '1', 'approve' => 'approved',
                    '0', 'pending', 'hold' => 'pending',
                    'spam' => 'spam',
                    'trash' => 'trash',
                    default => 'approved',
                };
                $type = in_array($row['comment_type'], ['comment', 'pingback', 'trackback'], true)
                    ? (string) $row['comment_type']
                    : 'comment';

                yield (int) $row['comment_ID'] => new CommentRecord(
                    sourceId: (int) $row['comment_ID'],
                    sourcePostId: (int) $row['comment_post_ID'],
                    sourceParentId: $row['comment_parent'] ? (int) $row['comment_parent'] : null,
                    sourceUserId: (int) $row['comment_user_id'],
                    author: (string) $row['comment_author'],
                    email: (string) $row['comment_author_email'],
                    url: (string) $row['comment_author_url'],
                    ip: (string) $row['comment_author_IP'],
                    agent: (string) ($row['comment_agent'] ?? ''),
                    content: (string) $row['comment_content'],
                    status: $status,
                    type: $type,
                    createdAt: $this->toTimestamp($row['comment_date_gmt']),
                );
            }
        }
    }

    public function streamPostMeta(array $sourcePostIds): Generator
    {
        if ($sourcePostIds === []) {
            return;
        }
        // Skip internal WP meta keys (they begin with _ and are not user-facing)
        $skipKeys = ['_edit_lock', '_edit_last', '_wp_old_slug', '_wp_old_date',
                     '_thumbnail_id', '_wp_attached_file', '_wp_attachment_metadata',
                     '_wp_page_template', '_wp_trash_meta_status', '_wp_trash_meta_time'];

        foreach (array_chunk($sourcePostIds, 1000) as $chunk) {
            $inList = implode(',', array_fill(0, count($chunk), '?'));
            $sql = "SELECT meta_id, post_id, meta_key, meta_value
                    FROM {$this->prefix}postmeta
                    WHERE post_id IN ({$inList})
                      AND meta_key NOT LIKE '\_%'
                    ORDER BY meta_id";

            foreach ($this->unbuffered($sql, $chunk) as $row) {
                if (in_array($row['meta_key'], $skipKeys, true)) {
                    continue;
                }
                yield (int) $row['meta_id'] => new PostMetaRecord(
                    sourceId: (int) $row['meta_id'],
                    sourcePostId: (int) $row['post_id'],
                    key: (string) $row['meta_key'],
                    value: (string) $row['meta_value'],
                );
            }
        }
    }

    public function streamMenuItems(): Generator
    {
        $sql = "SELECT tr.object_id, tr.term_taxonomy_id, tt.term_id, t.name, t.slug,
                       p.menu_order, p.post_parent, p.post_title,
                       pm_url.meta_value  AS url,
                       pm_obj.meta_value   AS object,
                       pm_type.meta_value  AS type,
                       pm_xfn.meta_value   AS xfn
                FROM {$this->prefix}term_relationships tr
                INNER JOIN {$this->prefix}term_taxonomy tt ON tt.term_taxonomy_id = tr.term_taxonomy_id AND tt.taxonomy = 'nav_menu'
                INNER JOIN {$this->prefix}terms t           ON t.term_id = tt.term_id
                INNER JOIN {$this->prefix}posts p           ON p.ID = tr.object_id AND p.post_type = 'nav_menu_item'
                LEFT JOIN {$this->prefix}postmeta pm_url  ON pm_url.post_id  = p.ID AND pm_url.meta_key  = '_menu_item_url'
                LEFT JOIN {$this->prefix}postmeta pm_obj  ON pm_obj.post_id  = p.ID AND pm_obj.meta_key  = '_menu_item_object'
                LEFT JOIN {$this->prefix}postmeta pm_type ON pm_type.post_id = p.ID AND pm_type.meta_key = '_menu_item_type'
                LEFT JOIN {$this->prefix}postmeta pm_xfn  ON pm_xfn.post_id  = p.ID AND pm_xfn.meta_key  = '_menu_item_xfn'
                ORDER BY t.term_id, p.menu_order";

        foreach ($this->unbuffered($sql) as $row) {
            yield (int) $row['object_id'] => new MenuItemRecord(
                sourceId: (int) $row['object_id'],
                sourceMenuId: (int) $row['term_id'],
                menuName: (string) $row['name'],
                menuSlug: (string) $row['slug'],
                order: (int) $row['menu_order'],
                sourceParentId: $row['post_parent'] ? (int) $row['post_parent'] : null,
                title: (string) $row['post_title'],
                url: (string) ($row['url'] ?? ''),
                objectType: (string) ($row['type'] ?? 'custom'),
                objectSlug: $row['object'] !== null ? (string) $row['object'] : null,
            );
        }
    }

    public function statistics(): array
    {
        $pdo = $this->pdo();
        $count = fn (string $sql) => (int) $pdo->query($sql)->fetchColumn();

        $posts = $count("SELECT COUNT(*) FROM {$this->prefix}posts WHERE post_type='post' AND post_status NOT IN ('auto-draft','trash','inherit')");
        $pages = $count("SELECT COUNT(*) FROM {$this->prefix}posts WHERE post_type='page' AND post_status NOT IN ('auto-draft','trash','inherit')");
        $media = $count("SELECT COUNT(*) FROM {$this->prefix}posts WHERE post_type='attachment'");
        $comments = $count("SELECT COUNT(*) FROM {$this->prefix}comments");
        $users = $count("SELECT COUNT(*) FROM {$this->prefix}users");
        $categories = $count("SELECT COUNT(*) FROM {$this->prefix}term_taxonomy WHERE taxonomy='category'");
        $tags = $count("SELECT COUNT(*) FROM {$this->prefix}term_taxonomy WHERE taxonomy='post_tag'");
        $menus = $count("SELECT COUNT(*) FROM {$this->prefix}term_taxonomy WHERE taxonomy='nav_menu'");
        $fields = $count("SELECT COUNT(*) FROM {$this->prefix}postmeta WHERE meta_key NOT LIKE '\_%'");

        return [
            'posts' => $posts,
            'pages' => $pages,
            'media' => $media,
            'comments' => $comments,
            'users' => $users,
            'categories' => $categories,
            'tags' => $tags,
            'menus' => $menus,
            'custom_fields' => $fields,
        ];
    }

    public function close(): void
    {
        $this->pdo = null;
        $this->lookupPdo = null;
    }

    /* ----- internals ----- */

    /**
     * Buffered connection for nested lookups (separate from the unbuffered
     * streaming connection — see the class-level note).
     */
    private function lookupPdo(): PDO
    {
        if ($this->lookupPdo instanceof PDO) {
            return $this->lookupPdo;
        }
        try {
            $dsn = sprintf(
                'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
                $this->cfg['host'],
                (int) $this->cfg['port'],
                $this->cfg['database']
            );
            $this->lookupPdo = new PDO($dsn, $this->cfg['user'], $this->cfg['password'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::MYSQL_ATTR_USE_BUFFERED_QUERY => true,
                PDO::ATTR_TIMEOUT => 30,
            ]);
        } catch (\Throwable $e) {
            throw new SourceException('اتصال کمکی به دیتابیس وردپرس ناموفق بود: ' . $e->getMessage(), 0, $e);
        }
        return $this->lookupPdo;
    }

    private function pdo(): PDO
    {
        if ($this->pdo instanceof PDO) {
            return $this->pdo;
        }
        try {
            $dsn = sprintf(
                'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
                $this->cfg['host'],
                (int) $this->cfg['port'],
                $this->cfg['database']
            );
            $this->pdo = new PDO($dsn, $this->cfg['user'], $this->cfg['password'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::MYSQL_ATTR_USE_BUFFERED_QUERY => false,
                PDO::ATTR_TIMEOUT => 30,
            ]);
        } catch (\Throwable $e) {
            throw new SourceException('اتصال به دیتابیس وردپرس ناموفق بود: ' . $e->getMessage(), 0, $e);
        }
        return $this->pdo;
    }

    /**
     * Run an unbuffered query and yield rows one at a time.
     *
     * @param list<mixed> $params
     *
     * @return Generator<int, array>
     */
    private function unbuffered(string $sql, array $params = []): Generator
    {
        $pdo = $this->pdo();

        // With PDO::MYSQL_ATTR_USE_BUFFERED_QUERY = false, only ONE statement
        // can be active per connection at a time. We rely on the generator's
        // finally block to closeCursor() before the next stream call.
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        try {
            while (($row = $stmt->fetch(PDO::FETCH_ASSOC)) !== false) {
                yield $row;
            }
        } finally {
            $stmt->closeCursor();
        }
    }

    private function toTimestamp(?string $mysqlGmt): int
    {
        if ($mysqlGmt === null || $mysqlGmt === '' || $mysqlGmt === '0000-00-00 00:00:00') {
            return time();
        }
        $ts = strtotime($mysqlGmt . ' UTC');
        return $ts !== false ? $ts : time();
    }

    private function mediaUrl(string $attachedFile): string
    {
        $uploads = $this->uploadsBaseUrl();
        return $uploads . '/' . ltrim($attachedFile, '/');
    }

    private function mediaPath(string $attachedFile): string
    {
        $uploads = $this->uploadsBasePath();
        return $uploads . '/' . ltrim($attachedFile, '/');
    }

    /** @var string|null Cached uploads base URL (resolved once per source). */
    private ?string $uploadsBaseUrlCache = null;

    private function uploadsBaseUrl(): string
    {
        // FIXED: this used to run a query on the main UNBUFFERED connection —
        // while streamMedia() was actively iterating on it — which fails with
        // PDO error 2014 ("queries while other unbuffered queries are active").
        // It now uses the separate buffered lookup connection and caches the
        // result so the options table is read at most once per source.
        if ($this->uploadsBaseUrlCache !== null) {
            return $this->uploadsBaseUrlCache;
        }
        try {
            $row = $this->lookupPdo()->query("SELECT option_value FROM {$this->prefix}options WHERE option_name = 'siteurl' LIMIT 1")->fetchColumn();
            $this->uploadsBaseUrlCache = rtrim((string) $row, '/') . '/wp-content/uploads';
        } catch (\Throwable) {
            $this->uploadsBaseUrlCache = '';
        }
        return $this->uploadsBaseUrlCache;
    }

    private function uploadsBasePath(): string
    {
        // Best-effort: WP's ABSPATH/wp-content/uploads. We can't know ABSPATH
        // for sure from outside, so we expose it as a tunable via cfg['abspath'].
        $abspath = $this->cfg['abspath'] ?? '';
        if ($abspath !== '') {
            return rtrim($abspath, '/') . '/wp-content/uploads';
        }
        return '';
    }
}

/**
 * WordPress's maybe_unserialize — safely unserialize any value.
 */
function maybe_unserialize(mixed $value): mixed
{
    if (!is_string($value)) {
        return $value;
    }
    if (preg_match('/^[aOs]:/', $value)) {
        $unserialized = @unserialize($value, ['allowed_classes' => false]);
        if ($unserialized !== false) {
            return $unserialized;
        }
    }
    return $value;
}
