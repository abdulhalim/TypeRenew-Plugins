<?php
/**
 * WXRSource — streaming WordPress WXR (XML) reader.
 *
 * Uses XMLReader so memory stays flat regardless of file size. The reader
 * walks the document once; on each <item> it builds a small DOMNode for that
 * subtree (using DOMDocument::loadXML on a single item's outerXML), which is
 * the standard pattern recommended in the PHP manual for "stream + DOM" parsing.
 *
 * IMPORTANT — WXR term formats (fixed):
 *   WordPress exports terms in TWO different shapes depending on version:
 *
 *   1. LEGACY (WXR 1.0/1.1 and WordPress.com exports):
 *        <wp:category>
 *          <wp:term_id>…</wp:term_id>
 *          <wp:category_nicename>…</wp:category_nicename>   ← slug
 *          <wp:category_parent>…</wp:category_parent>       ← parent SLUG
 *          <wp:cat_name>…</wp:cat_name>                     ← name
 *          <wp:category_description>…</wp:category_description>
 *        </wp:category>
 *        <wp:tag>
 *          <wp:term_id>…</wp:term_id>
 *          <wp:tag_slug>…</wp:tag_slug>
 *          <wp:tag_name>…</wp:tag_name>
 *          <wp:tag_description>…</wp:tag_description>
 *        </wp:tag>
 *
 *   2. MODERN (WXR 1.2, WordPress 3.5+):
 *        <wp:term>
 *          <wp:term_id>…</wp:term_id>
 *          <wp:term_taxonomy>category|post_tag|nav_menu|…</wp:term_taxonomy>
 *          <wp:term_slug>…</wp:term_slug>
 *          <wp:term_parent>…</wp:term_parent>               ← parent SLUG
 *          <wp:term_name>…</wp:term_name>
 *          <wp:term_description>…</wp:term_description>
 *        </wp:term>
 *
 *   The previous implementation only looked for `wp:term_name` /
 *   `wp:term_nicename` (which don't exist in either shape) and never scanned
 *   `<wp:term>` at all, so every category/tag name and slug was imported
 *   empty. Both shapes are now parsed, with parent slugs resolved to IDs.
 *
 *   Post-to-term links inside <item> are PLAIN <category domain="…"
 *   nicename="…"> elements (no namespace) — also fixed.
 *
 * @package WordPressImporter\Source
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Source;

use DOMDocument;
use DOMElement;
use DOMNode;
use Generator;
use XMLReader;
use TypechoPlugin\WordPressImporter\Contract\SourceInterface;
use TypechoPlugin\WordPressImporter\Exception\SourceException;
use TypechoPlugin\WordPressImporter\Support\AuthorRecord;
use TypechoPlugin\WordPressImporter\Support\CategoryRecord;
use TypechoPlugin\WordPressImporter\Support\CommentRecord;
use TypechoPlugin\WordPressImporter\Support\MediaRecord;
use TypechoPlugin\WordPressImporter\Support\MenuItemRecord;
use TypechoPlugin\WordPressImporter\Support\PostMetaRecord;
use TypechoPlugin\WordPressImporter\Support\PostRecord;

final class WXRSource implements SourceInterface
{
    private const WP_NS = 'http://wordpress.org/export/1.2/';

    /** @var array<int, AuthorRecord> Indexed by sourceId for fast lookup. */
    private array $userCache = [];

    /** @var array<int, CategoryRecord> */
    private array $termCache = [];

    /** Whether the author/term index pass has run (separate from cache state). */
    private bool $authorsTermsIndexed = false;

    private ?array $cachedStats = null;

    /** @var string|null Temp-cleaned copy of the source file (deleted on shutdown). */
    private ?string $tempPath = null;

    public function __construct(
        private string $path,
    ) {
        // Some real-world WXR files (edited exports, WordPress.com dumps
        // transferred through forums/gists) carry a UTF-8 BOM or blank lines
        // before the XML declaration. libxml refuses to parse those
        // ("XML declaration allowed only at the start of the document"),
        // which made the reader silently yield ZERO items. Normalize to a
        // cleaned temp copy whenever leading junk is detected.
        $this->path = $this->normalizeLeadingJunk($this->path);
    }

    public function __destruct()
    {
        if ($this->tempPath !== null && is_file($this->tempPath)) {
            @unlink($this->tempPath);
        }
    }

    /**
     * Strip a leading UTF-8 BOM / whitespace before the XML declaration by
     * copying the file (only when needed). Returns the path to parse.
     */
    private function normalizeLeadingJunk(string $path): string
    {
        $fp = @fopen($path, 'rb');
        if ($fp === false) {
            return $path;
        }

        try {
            $head = (string) fread($fp, 512);
            if ($head === '') {
                return $path;
            }

            // Remove leading whitespace and/or UTF-8 BOM bytes (BOM is optional —
            // some files only carry blank lines before the XML declaration).
            $clean = (string) preg_replace('/^[\s\xEF\xBB\xBF]+/', '', $head);
            if ($clean === $head || !str_starts_with($clean, "<" . "?xml")) {
                return $path; // file starts correctly (or isn't fixable here)
            }

            // Write a cleaned copy next to the original (needs a writable dir).
            $temp = $path . '.cleaned-' . bin2hex(random_bytes(4)) . '.xml';
            $out = @fopen($temp, 'wb');
            if ($out === false) {
                return $path;
            }

            try {
                fwrite($out, $clean);
                while (!feof($fp)) {
                    $chunk = fread($fp, 64 * 1024);
                    if ($chunk === false) {
                        break;
                    }
                    fwrite($out, $chunk);
                }
            } finally {
                fclose($out);
            }

            $this->tempPath = $temp;
            return $temp;
        } finally {
            fclose($fp);
        }
    }

    public function validate(): array
    {
        $warnings = [];
        if (!file_exists($this->path) || !is_readable($this->path)) {
            throw new SourceException("فایل WXR قابل خواندن نیست: {$this->path}");
        }
        $reader = new XMLReader();
        if (!@$reader->open($this->path)) {
            throw new SourceException("باز کردن فایل WXR XML ناموفق بود.");
        }
        $reader->close();
        return $warnings;
    }

    public function streamUsers(): Generator
    {
        $this->indexAuthorsTerms();
        foreach ($this->userCache as $id => $user) {
            yield $id => $user;
        }
    }

    public function streamTerms(): Generator
    {
        $this->indexAuthorsTerms();
        foreach ($this->termCache as $id => $term) {
            yield $id => $term;
        }
    }

    public function streamPosts(array $types = ['post', 'page']): Generator
    {
        $this->indexAuthorsTerms();
        foreach ($this->streamAllItems() as $item) {
            $type = (string) $this->xpath($item, 'wp:post_type');
            if (!in_array($type, $types, true)) {
                continue;
            }
            $status = (string) $this->xpath($item, 'wp:status');
            if (in_array($status, ['auto-draft', 'trash', 'inherit'], true)) {
                continue;
            }

            $categoryIds = [];
            $tagIds = [];
            // FIXED: item-level categories are PLAIN <category domain="…"
            // nicename="…"> elements with NO wp: namespace. The previous
            // getElementsByTagNameNS(WP_NS, 'category') call matched nothing,
            // so every imported post silently lost its category/tag links.
            foreach ($item->getElementsByTagName('category') as $catNode) {
                if (!$catNode instanceof DOMElement || $catNode->namespaceURI !== null) {
                    continue;
                }
                $domain = trim($catNode->getAttribute('domain'));
                $nicename = trim($catNode->getAttribute('nicename'));
                $label = trim((string) $catNode->textContent);
                $key = $nicename !== '' ? $nicename : $label;
                if ($key === '') {
                    continue;
                }
                if ($domain === 'category' || $domain === '') {
                    $id = $this->lookupTermId($key, 'category');
                    if ($id !== 0) {
                        $categoryIds[] = $id;
                    }
                } elseif ($domain === 'post_tag') {
                    $id = $this->lookupTermId($key, 'post_tag');
                    if ($id !== 0) {
                        $tagIds[] = $id;
                    }
                }
            }

            $sourceId = (int) $this->xpath($item, 'wp:post_id');
            $thumbId = null;
            foreach ($item->getElementsByTagNameNS(self::WP_NS, 'postmeta') as $metaNode) {
                $key = $this->xpath($metaNode, 'wp:meta_key');
                $val = $this->xpath($metaNode, 'wp:meta_value');
                if ($key === '_thumbnail_id') {
                    $thumbId = (int) $val;
                    break;
                }
            }

            yield $sourceId => new PostRecord(
                sourceId: $sourceId,
                // FIXED: WXR items carry the author LOGIN in <dc:creator>, not
                // a numeric ID — casting the login to int always produced 0.
                // authorIdForItem() maps the login back to the author index.
                sourceAuthorId: $this->authorIdForItem($item),
                title: (string) $this->xpath($item, 'title'),
                slug: (string) $this->xpath($item, 'wp:post_name'),
                content: (string) $this->xpath($item, 'content:encoded'),
                excerpt: (string) $this->xpath($item, 'excerpt:encoded'),
                status: $status,
                type: $type,
                password: (string) $this->xpath($item, 'wp:post_password'),
                createdAt: $this->parseDate((string) $this->xpath($item, 'wp:post_date_gmt')),
                modifiedAt: $this->parseDate((string) $this->xpath($item, 'wp:post_modified_gmt')),
                allowComments: $this->xpath($item, 'wp:comment_status') === 'open',
                allowPings: $this->xpath($item, 'wp:ping_status') === 'open',
                featuredImageId: $thumbId,
                commentCount: (string) $this->xpath($item, 'wp:comment_count'),
                categoryIds: $categoryIds,
                tagIds: $tagIds,
            );
        }
    }

    public function streamMedia(): Generator
    {
        foreach ($this->streamAllItems() as $item) {
            $type = (string) $this->xpath($item, 'wp:post_type');
            if ($type !== 'attachment') {
                continue;
            }
            $sourceId = (int) $this->xpath($item, 'wp:post_id');
            $attachedFile = '';
            $altText = '';
            foreach ($item->getElementsByTagNameNS(self::WP_NS, 'postmeta') as $metaNode) {
                $key = $this->xpath($metaNode, 'wp:meta_key');
                if ($key === '_wp_attached_file') {
                    $attachedFile = (string) $this->xpath($metaNode, 'wp:meta_value');
                } elseif ($key === '_wp_attachment_image_alt') {
                    $altText = (string) $this->xpath($metaNode, 'wp:meta_value');
                }
            }
            $url = (string) $this->xpath($item, 'wp:attachment_url');
            if ($url === '' && $attachedFile !== '') {
                $url = $attachedFile;
            }

            yield $sourceId => new MediaRecord(
                sourceId: $sourceId,
                sourceParentId: (int) $this->xpath($item, 'wp:post_parent'),
                title: (string) $this->xpath($item, 'title'),
                slug: (string) $this->xpath($item, 'wp:post_name'),
                mime: (string) $this->xpath($item, 'wp:post_mime_type'),
                url: $url,
                filePath: '',
                size: 0,
                uploadedAt: $this->parseDate((string) $this->xpath($item, 'wp:post_date_gmt')),
                description: (string) $this->xpath($item, 'content:encoded'),
                altText: $altText,
            );
        }
    }

    public function streamComments(array $sourcePostIds): Generator
    {
        if ($sourcePostIds === []) {
            return;
        }
        $set = array_flip($sourcePostIds);

        foreach ($this->streamAllItems() as $item) {
            $sourceId = (int) $this->xpath($item, 'wp:post_id');
            if (!isset($set[$sourceId])) {
                continue;
            }
            foreach ($item->getElementsByTagNameNS(self::WP_NS, 'comment') as $commentNode) {
                $cid = (int) $this->xpath($commentNode, 'wp:comment_id');
                $approved = (string) $this->xpath($commentNode, 'wp:comment_approved');
                $status = match ($approved) {
                    '1', 'approve' => 'approved',
                    '0', 'pending', 'hold' => 'pending',
                    'spam' => 'spam',
                    'trash' => 'trash',
                    default => 'approved',
                };
                $type = (string) $this->xpath($commentNode, 'wp:comment_type');
                $type = in_array($type, ['comment', 'pingback', 'trackback'], true) ? $type : 'comment';

                yield $cid => new CommentRecord(
                    sourceId: $cid,
                    sourcePostId: $sourceId,
                    sourceParentId: ($p = $this->xpath($commentNode, 'wp:comment_parent')) !== '' ? (int) $p : null,
                    sourceUserId: 0,
                    author: (string) $this->xpath($commentNode, 'wp:comment_author'),
                    email: (string) $this->xpath($commentNode, 'wp:comment_author_email'),
                    url: (string) $this->xpath($commentNode, 'wp:comment_author_url'),
                    ip: (string) $this->xpath($commentNode, 'wp:comment_author_IP'),
                    agent: (string) $this->xpath($commentNode, 'wp:comment_agent'),
                    content: (string) $this->xpath($commentNode, 'wp:comment_content'),
                    status: $status,
                    type: $type,
                    createdAt: $this->parseDate((string) $this->xpath($commentNode, 'wp:comment_date_gmt')),
                );
            }
        }
    }

    public function streamPostMeta(array $sourcePostIds): Generator
    {
        if ($sourcePostIds === []) {
            return;
        }
        $set = array_flip($sourcePostIds);

        foreach ($this->streamAllItems() as $item) {
            $sourceId = (int) $this->xpath($item, 'wp:post_id');
            if (!isset($set[$sourceId])) {
                continue;
            }
            $mid = 0;
            foreach ($item->getElementsByTagNameNS(self::WP_NS, 'postmeta') as $metaNode) {
                $mid++;
                $key = (string) $this->xpath($metaNode, 'wp:meta_key');
                $val = (string) $this->xpath($metaNode, 'wp:meta_value');
                if (str_starts_with($key, '_')) {
                    continue;
                }
                yield $mid => new PostMetaRecord(
                    sourceId: $mid,
                    sourcePostId: $sourceId,
                    key: $key,
                    value: $val,
                );
            }
        }
    }

    public function streamMenuItems(): Generator
    {
        // WXR 1.2 exports nav_menu_item as a regular <item> with post_type=nav_menu_item.
        // Building MenuItemRecords from them requires reading the term taxonomy too —
        // this implementation provides a best-effort pass; full menu import is
        // available via the MySQL source.
        // Empty generator: explicit return with no yield.
        if (false) {
            yield; // makes this a Generator
        }
    }

    public function statistics(): array
    {
        if ($this->cachedStats !== null) {
            return $this->cachedStats;
        }

        $posts = $pages = $media = $comments = $users = $categories = $tags = $menus = $fields = 0;

        foreach ($this->streamAllItems() as $item) {
            $type = (string) $this->xpath($item, 'wp:post_type');
            // FIXED: the status element inside <item> is <wp:status> —
            // `wp:post_status` does not exist in WXR, so the previous check
            // never filtered anything.
            // NOTE: attachments carry status "inherit" in WordPress and must
            // NOT be filtered out — they are counted before the status check.
            $status = (string) $this->xpath($item, 'wp:status');
            $skip = in_array($status, ['auto-draft', 'trash', 'inherit'], true);

            if ($type === 'attachment') {
                $media++;
                continue;
            }

            if (!$skip) {
                match (true) {
                    $type === 'post'          => $posts++,
                    $type === 'page'          => $pages++,
                    $type === 'nav_menu_item' => $menus++,
                    default                   => null, // unknown post_type — ignored (not counted)
                };

                // Comments
                $comments += $item->getElementsByTagNameNS(self::WP_NS, 'comment')->length;

                // Custom fields
                foreach ($item->getElementsByTagNameNS(self::WP_NS, 'postmeta') as $metaNode) {
                    $key = (string) $this->xpath($metaNode, 'wp:meta_key');
                    if (!str_starts_with($key, '_')) {
                        $fields++;
                    }
                }
            }
        }

        // Terms
        $this->indexAuthorsTerms();
        foreach ($this->termCache as $term) {
            if ($term->taxonomy === 'category') {
                $categories++;
            } elseif ($term->taxonomy === 'post_tag') {
                $tags++;
            }
        }
        $users = count($this->userCache);

        return $this->cachedStats = [
            'posts' => $posts,
            'pages' => $pages,
            'media' => $media,
            'comments' => $comments,
            'users' => $users,
            'categories' => $categories,
            'tags' => $tags,
            'menus' => $menus,
            'custom_fields' => $fields,
        ];
    }

    public function close(): void
    {
        // XMLReader closes itself per-iteration
    }

    /* ----- internals ----- */

    /**
     * Stream every <item> in the WXR file as a DOMNode (one at a time).
     *
     * @return Generator<int, DOMNode>
     */
    private function streamAllItems(): Generator
    {
        $reader = new XMLReader();
        if (!@$reader->open($this->path)) {
            throw new SourceException("باز کردن فایل WXR XML ناموفق بود.");
        }

        try {
            while (@$reader->read()) {
                if ($reader->nodeType === XMLReader::ELEMENT && $reader->name === 'item') {
                    $doc = new DOMDocument();
                    $node = @$doc->importNode(@$reader->expand(), true);
                    if ($node === null) {
                        continue;
                    }
                    $doc->appendChild($node);
                    yield $node;
                }
            }
        } finally {
            $reader->close();
        }
    }

    /**
     * Walk <wp:author>, legacy <wp:category>/<wp:tag> AND modern <wp:term>
     * top-level elements once and cache them. WXR places these OUTSIDE the
     * <item> stream.
     */
    private function indexAuthorsTerms(): void
    {
        if ($this->authorsTermsIndexed) {
            return;
        }
        $this->authorsTermsIndexed = true;

        // Raw term rows; parent slugs are resolved in a second pass.
        // KEYED BY "taxonomy:termId" — the same term_id can legitimately
        // appear in TWO taxonomies (shared terms, e.g. a word that is both a
        // category and a tag on WordPress.com exports). Keying by term_id
        // alone silently dropped one of the two.
        $rawTerms = [];

        $reader = new XMLReader();
        if (!@$reader->open($this->path)) {
            throw new SourceException("باز کردن فایل WXR XML ناموفق بود.");
        }

        try {
            while (@$reader->read()) {
                if ($reader->nodeType !== XMLReader::ELEMENT) {
                    continue;
                }
                if ($reader->name === 'wp:author') {
                    $doc = new DOMDocument();
                    $node = @$doc->importNode(@$reader->expand(), true);
                    if ($node === null) {
                        continue;
                    }
                    $doc->appendChild($node);
                    $author = $this->parseAuthorNode($node);
                    $this->userCache[$author->sourceId] = $author;
                } elseif (in_array($reader->name, ['wp:category', 'wp:tag', 'wp:term'], true)) {
                    $doc = new DOMDocument();
                    $node = @$doc->importNode(@$reader->expand(), true);
                    if ($node === null) {
                        continue;
                    }
                    $doc->appendChild($node);
                    $row = match ($reader->name) {
                        'wp:category' => $this->parseLegacyTermNode($node, 'category'),
                        'wp:tag'      => $this->parseLegacyTermNode($node, 'post_tag'),
                        default       => $this->parseModernTermNode($node),
                    };
                    if ($row !== null && $row['taxonomy'] !== '') {
                        $rawTerms[$row['taxonomy'] . ':' . $row['id']] = $row;
                    }
                }
            }
        } finally {
            $reader->close();
        }

        // Second pass: resolve parent slugs to source IDs, then build records.
        $slugToId = [];
        foreach ($rawTerms as $id => $row) {
            if ($row['slug'] !== '') {
                $slugToId[$row['slug']] = $id;
            }
        }

        foreach ($rawTerms as $key => $row) {
            // Only category/tag taxonomies are imported as metas.
            if (!in_array($row['taxonomy'], ['category', 'post_tag'], true)) {
                continue;
            }
            $parentId = 0;
            if ($row['parentSlug'] !== '' && isset($slugToId[$row['parentSlug']])) {
                // Cross-taxonomy parents make no sense — only resolve within
                // the same taxonomy.
                $parentKey = $slugToId[$row['parentSlug']];
                if (str_starts_with((string) $parentKey, $row['taxonomy'] . ':')) {
                    $parentId = (int) substr((string) $parentKey, strlen($row['taxonomy']) + 1);
                }
            }
            $this->termCache[$key] = new CategoryRecord(
                sourceId: (int) $row['id'],
                name: $row['name'],
                slug: $row['slug'],
                description: $row['description'],
                parentId: $parentId,
                taxonomy: $row['taxonomy'],
            );
        }
    }

    /**
     * Parse a legacy <wp:category> or <wp:tag> node (WXR 1.0/1.1).
     *
     * @return array{id:int, name:string, slug:string, description:string, parentSlug:string, taxonomy:string}|null
     */
    private function parseLegacyTermNode(DOMNode $node, string $taxonomy): ?array
    {
        $id = (int) $this->xpath($node, 'wp:term_id');
        if ($id === 0) {
            return null;
        }

        if ($taxonomy === 'category') {
            $name = $this->firstNonEmpty(
                $this->xpath($node, 'wp:cat_name'),
                $this->xpath($node, 'wp:term_name')
            );
            $slug = $this->firstNonEmpty(
                $this->xpath($node, 'wp:category_nicename'),
                $this->xpath($node, 'wp:term_nicename'),
                $this->xpath($node, 'wp:term_slug')
            );
            $description = $this->xpath($node, 'wp:category_description');
            $parentSlug = $this->xpath($node, 'wp:category_parent');
        } else {
            $name = $this->firstNonEmpty(
                $this->xpath($node, 'wp:tag_name'),
                $this->xpath($node, 'wp:term_name')
            );
            $slug = $this->firstNonEmpty(
                $this->xpath($node, 'wp:tag_slug'),
                $this->xpath($node, 'wp:term_nicename'),
                $this->xpath($node, 'wp:term_slug')
            );
            $description = $this->firstNonEmpty(
                $this->xpath($node, 'wp:tag_description'),
                $this->xpath($node, 'wp:category_description'),
                $this->xpath($node, 'wp:term_description')
            );
            $parentSlug = $this->firstNonEmpty(
                $this->xpath($node, 'wp:tag_parent'),
                $this->xpath($node, 'wp:term_parent')
            );
        }

        return [
            'id' => $id,
            'name' => $name,
            'slug' => $slug,
            'description' => $description,
            'parentSlug' => $parentSlug,
            'taxonomy' => $taxonomy,
        ];
    }

    /**
     * Parse a modern <wp:term> node (WXR 1.2, WordPress 3.5+).
     *
     * @return array{id:int, name:string, slug:string, description:string, parentSlug:string, taxonomy:string}|null
     */
    private function parseModernTermNode(DOMNode $node): ?array
    {
        $id = (int) $this->xpath($node, 'wp:term_id');
        if ($id === 0) {
            return null;
        }

        $taxonomy = $this->xpath($node, 'wp:term_taxonomy');
        // Some exporters omit the taxonomy for categories/tags.
        if ($taxonomy === '') {
            $taxonomy = 'category';
        }

        return [
            'id' => $id,
            'name' => $this->xpath($node, 'wp:term_name'),
            'slug' => $this->firstNonEmpty(
                $this->xpath($node, 'wp:term_slug'),
                $this->xpath($node, 'wp:term_nicename')
            ),
            'description' => $this->xpath($node, 'wp:term_description'),
            'parentSlug' => $this->xpath($node, 'wp:term_parent'),
            'taxonomy' => $taxonomy,
        ];
    }

    private function parseAuthorNode(DOMNode $node): AuthorRecord
    {
        $id = (int) $this->xpath($node, 'wp:author_id');
        return new AuthorRecord(
            sourceId: $id,
            username: (string) $this->xpath($node, 'wp:author_login'),
            email: (string) $this->xpath($node, 'wp:author_email'),
            displayName: (string) $this->xpath($node, 'wp:author_display_name'),
            nickname: (string) $this->xpath($node, 'wp:author_display_name'),
            firstName: (string) $this->xpath($node, 'wp:author_first_name'),
            lastName: (string) $this->xpath($node, 'wp:author_last_name'),
            url: '',
            role: $this->mapAuthorRole($id),
            registeredAt: $this->parseDate((string) $this->xpath($node, 'wp:author_registered')),
        );
    }

    /**
     * Resolve the author of an item. WXR items reference their author by
     * login name (<dc:creator>), not by ID — map it back to the author index.
     */
    private function authorIdForItem(DOMNode $item): int
    {
        $login = trim((string) $this->xpath($item, 'dc:creator'));
        if ($login !== '') {
            foreach ($this->userCache as $id => $author) {
                if ($author->username === $login) {
                    return $id;
                }
            }
        }
        return 0; // PostImporter falls back to the first administrator
    }

    /**
     * XPath-ish lookup by prefixed name. We use getElementsByTagNameNS because
     * PHP's DOMXPath is heavier for our one-shot read pattern.
     */
    private function xpath(DOMNode $node, string $name): string
    {
        // Try as namespaced tag
        [$ns, $local] = explode(':', $name, 2) + ['', ''];
        if ($local !== '') {
            $nsMap = [
                'wp' => self::WP_NS,
                'dc' => 'http://purl.org/dc/elements/1.1/',
                'content' => 'http://purl.org/rss/1.0/modules/content/',
                'excerpt' => 'http://wordpress.org/export/1.2/excerpt/',
            ];
            $nsUri = $nsMap[$ns] ?? '';
            if ($nsUri !== '') {
                $list = $node instanceof DOMDocument
                    ? $node->getElementsByTagNameNS($nsUri, $local)
                    : $node->getElementsByTagNameNS($nsUri, $local);
                if ($list->length > 0) {
                    return trim((string) $list->item(0)->textContent);
                }
            }
        }
        // Try as plain tag
        $list = $node instanceof DOMDocument
            ? $node->getElementsByTagName($name)
            : $node->getElementsByTagName($name);
        return $list->length > 0 ? trim((string) $list->item(0)->textContent) : '';
    }

    private function firstNonEmpty(string ...$values): string
    {
        foreach ($values as $v) {
            if ($v !== '') {
                return $v;
            }
        }
        return '';
    }

    /**
     * Find a cached term by slug first (item categories carry the term
     * nicename in their `nicename` attribute), falling back to name match.
     *
     * Returns the term's SOURCE ID (the cache key is "taxonomy:id").
     */
    private function lookupTermId(string $slugOrName, string $taxonomy): int
    {
        if ($slugOrName === '') {
            return 0;
        }
        foreach ($this->termCache as $key => $term) {
            if ($term->taxonomy === $taxonomy && strcasecmp($term->slug, $slugOrName) === 0) {
                return $this->termIdFromKey($key);
            }
        }
        foreach ($this->termCache as $key => $term) {
            if ($term->taxonomy === $taxonomy && strcasecmp($term->name, $slugOrName) === 0) {
                return $this->termIdFromKey($key);
            }
        }
        return 0;
    }

    /**
     * Extract the numeric source ID from a termCache key ("taxonomy:id").
     */
    private function termIdFromKey(int|string $key): int
    {
        if (is_int($key)) {
            return $key;
        }
        $pos = strrpos($key, ':');

        return $pos === false ? (int) $key : (int) substr($key, $pos + 1);
    }

    private function mapAuthorRole(int $authorId): string
    {
        // WXR 1.2 doesn't expose role directly. Default to author.
        return 'author';
    }

    private function parseDate(string $gmtString): int
    {
        if ($gmtString === '' || $gmtString === '0000-00-00 00:00:00') {
            return time();
        }
        $ts = strtotime($gmtString . ' UTC');
        return $ts !== false ? $ts : time();
    }
}
