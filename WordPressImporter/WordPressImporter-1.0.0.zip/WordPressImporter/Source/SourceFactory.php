<?php
/**
 * SourceFactory — picks the right Source adapter for the configured source kind.
 *
 * @package WordPressImporter\Source
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Source;

use TypechoPlugin\WordPressImporter\Contract\SourceInterface;
use TypechoPlugin\WordPressImporter\Exception\ConfigException;
use TypechoPlugin\WordPressImporter\Support\SettingsManager;

final class SourceFactory
{
    public static function make(SettingsManager $settings): SourceInterface
    {
        return match ($settings->sourceKind()) {
            'mysql' => new MySQLSource($settings->mysqlConfig()),
            'wxr' => new WXRSource((string) $settings->wxrPath()),
            'zip' => new ZIPSource((string) $settings->zipPath()),
            default => throw new ConfigException("نوع منبع ناشناخته است: " . $settings->sourceKind()),
        };
    }
}
