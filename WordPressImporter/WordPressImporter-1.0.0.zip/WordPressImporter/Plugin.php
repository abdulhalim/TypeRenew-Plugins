<?php
/**
 * WordPress Importer for TypeRenew
 *
 * افزونه‌ای سبک و قابل اتکا برای مهاجرت محتوای وردپرس به TypeRenew.
 * هدف: انتقال امن نوشته‌ها، برگه‌ها، کاربران، دسته‌ها، برچسب‌ها، دیدگاه‌ها،
 * رسانه‌ها، تصاویر شاخص، منوها و فیلدهای سفارشی عمومی.
 *
 * @package   WordPressImporter
 * @author    پوردریایی
 * @link      https://pourdaryaei.ir
 * @version   1.0.0
 * @since     1.3.0
 * @license   GPL-2.0-or-later
 *
 * Coding standard: PSR-12, PHP 8.2+, strict types, SOLID.
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter;

use Typecho\Plugin\PluginInterface;
use Typecho\Widget\Helper\Form;
use Typecho\Widget\Helper\Form\Element\Text;
use Typecho\Widget\Helper\Form\Element\Radio;
use Typecho\Widget\Helper\Form\Element\Checkbox;
use Typecho\Plugin\Exception as PluginException;
use Widget\Options;
use Widget\User;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * Plugin entry point.
 *
 * Registers the admin panel, the AJAX action endpoint and a small set of
 * configuration defaults. All heavy lifting is delegated to dedicated service
 * classes inside the plugin root (TypeRenew's autoloader resolves namespaces
 * directly against the plugin directory structure).
 */
final class Plugin implements PluginInterface
{
    /** @var string Plugin version (semver). */
    public const VERSION = '1.0.0';

    /** @var string Action route used by the AJAX endpoint. */
    public const ACTION = 'wordpress-importer';

    /** @var string Admin panel file path (relative to plugin root, no leading slash). */
    public const PANEL_FILE = 'WordPressImporter/panel.php';

    /** @var string Default database port for the WordPress MySQL source. */
    public const DEFAULT_DB_PORT = 3306;

    /** @var string Plugin action: validate source. */
    public const ACTION_VALIDATE = 'validate';

    /** @var string Plugin action: preview source. */
    public const ACTION_PREVIEW = 'preview';

    /** @var string Plugin action: run import (chunked). */
    public const ACTION_IMPORT = 'import';

    /** @var string Plugin action: poll progress. */
    public const ACTION_PROGRESS = 'progress';

    /** @var string Plugin action: rollback last import. */
    public const ACTION_ROLLBACK = 'rollback';

    /** @var string Plugin action: download report. */
    public const ACTION_REPORT = 'report';

    /**
     * Activate the plugin.
     *
     * Registers the AJAX action endpoint and the admin panel. The panel is
     * attached to menu index 5 (the standard "Add-ons / Plugins" menu slot in
     * TypeRenew) — the same slot used by other first-party TypeRenew plugins
     * like BackupRestore. This makes the importer appear inside the standard
     * admin layout (with top bar, sidebar, footer) rather than as a
     * standalone page.
     *
     * Before adding, we defensively remove any stale panel registrations from
     * indices 1, 3, 4, 5 to handle repeated activate/deactivate cycles.
     *
     * @return string Activation message (Typecho convention).
     *
     * @throws PluginException
     */
    public static function activate(): string
    {
        // 1) Register the AJAX action endpoint (used by the wizard UI).
        \Utils\Helper::addAction(self::ACTION, Action::class);

        // 2) Clean up any stale panel registrations from previous activations.
        //    We check several common indices because the panel may have been
        //    registered under different ones in earlier plugin versions.
        foreach ([1, 3, 4, 5, 10] as $idx) {
            try {
                \Utils\Helper::removePanel($idx, self::PANEL_FILE);
            } catch (\Throwable $e) {
                error_log('[WordPressImporter] removePanel(' . $idx . ') during activate: ' . $e->getMessage());
            }
        }

        // 3) Register the panel under menu index 5 ("Add-ons / Plugins").
        //    This is the same slot BackupRestore and other first-party
        //    TypeRenew plugins use, so the importer opens inside the standard
        //    admin layout (header + sidebar + footer) instead of a standalone page.
        \Utils\Helper::addPanel(
            5,
            self::PANEL_FILE,
            _t('واردکنندهٔ وردپرس'),
            _t('مهاجرت محتوای وردپرس به TypeRenew'),
            'administrator',
            false,
            '',
            ['icon' => 'i-download']
        );

        // 4) Install persistent state table for progress / rollback metadata.
        //    Wrapped defensively — if this fails, the plugin still activates so the
        //    user can see the panel and read the error in the wizard.
        //    The state table is ALSO created lazily on first read/write, so even if
        //    install() fails here it will be retried automatically.
        try {
            StateManager::install();
        } catch (\Throwable $e) {
            // Defer — StateManager will retry on first read/write.
            error_log('[WordPressImporter] State table install deferred: ' . $e->getMessage());
        }

        return _t('افزونهٔ واردکنندهٔ وردپرس فعال شد؛ پنل مدیریت از منوی «افزونه‌ها» در دسترس است.');
    }

    /**
     * Deactivate the plugin.
     *
     * Removes the AJAX action endpoint and the admin panel from all common
     * menu indices. The StateManager table is intentionally kept so that an
     * in-flight import can still be rolled back after re-activation.
     *
     * @return string Deactivation message (Typecho convention).
     *
     * @throws PluginException
     */
    public static function deactivate(): string
    {
        // 1) Remove the AJAX action.
        \Utils\Helper::removeAction(self::ACTION);

        // 2) Remove the panel from all common menu indices.
        foreach ([1, 3, 4, 5, 10] as $idx) {
            try {
                \Utils\Helper::removePanel($idx, self::PANEL_FILE);
            } catch (\Throwable $e) {
                error_log('[WordPressImporter] removePanel(' . $idx . ') during deactivate: ' . $e->getMessage());
            }
        }

        // Keep StateManager table intact so rollback is still possible after disable.

        return _t('افزونهٔ واردکنندهٔ وردپرس غیرفعال شد؛ داده‌های state برای امکان برگشت نگه داشته شدند.');
    }

    /**
     * Admin configuration form. Exposed under TypeRenew "Manage Plugins → Configure".
     *
     * فرم تنظیمات پیش‌فرض پلاگین. بیشتر گزینه‌ها هنگام اجرای هر ایمپورت
     * از داخل ویزارد قابل تغییر هستند؛ این فرم فقط مقادیر پیش‌فرض را ذخیره می‌کند.
     *
     * @param Form $form
     */
    public static function config(Form $form): void
    {
        $notice = new \Typecho\Widget\Helper\Form\Element\Text(
            'notice',
            null,
            null,
            _t('یادداشت تنظیمات'),
            _t('بیشتر گزینه‌های ایمپورت از داخل ویزارد تنظیم می‌شوند («کنسول → WordPress Importer»). این فرم فقط مقادیر پیش‌فرض را نگه می‌دارد.')
        );
        $form->addInput($notice);

        $defaultMode = new Radio(
            'default_mode',
            [
                'keep'  => _t('حفظ داده‌های موجود (امن‌ترین)'),
                'merge' => _t('ادغام داده‌ها'),
                'clean' => _t('ایمپورت تمیز (حذفی، نیاز به تأیید مضاعف دارد)'),
            ],
            'keep',
            _t('حالت پیش‌فرض ایمپورت'),
            _t('به‌عنوان گزینهٔ از پیش انتخاب‌شده در ویزارد استفاده می‌شود.')
        );
        $form->addInput($defaultMode);

        $defaultSource = new Radio(
            'default_source',
            [
                'mysql' => _t('اتصال مستقیم MySQL'),
                'wxr'   => _t('فایل XML خروجی WXR وردپرس'),
                'zip'   => _t('بستهٔ ZIP شامل WXR + رسانه'),
            ],
            'mysql',
            _t('منبع پیش‌فرض ایمپورت'),
            null
        );
        $form->addInput($defaultSource);

        $chunkSize = new Text(
            'chunk_size',
            null,
            '100',
            _t('اندازهٔ دستهٔ پیش‌فرض'),
            _t('تعداد ردیف پردازش‌شده در هر درخواست AJAX (۱۰ تا ۱۰۰۰). مقادیر کمتر برای max_execution_time ملایم‌تر هستند.')
        );
        $form->addInput($chunkSize);

        $features = new Checkbox(
            'features',
            [
                'media'     => _t('ایمپورت رسانه'),
                'authors'   => _t('ایمپورت نویسندگان'),
                'menus'     => _t('ایمپورت منوها'),
                'comments'  => _t('ایمپورت دیدگاه‌ها'),
                'fields'    => _t('ایمپورت فیلدهای سفارشی'),
                'gutenberg' => _t('تبدیل بلوک‌های گوتنبرگ'),
                'shortcode' => _t('تبدیل شورت‌کدها'),
                'rollback'  => _t('اسنپ‌شات پیش از ایمپورت'),
            ],
            ['media', 'authors', 'comments', 'fields', 'gutenberg', 'shortcode', 'rollback'],
            _t('قابلیت‌های پیش‌فرض'),
            _t('چک‌باکس‌های از قبل انتخاب‌شده در مرحلهٔ «ایمپورت انتخابی».')
        );
        $form->addInput($features);
    }

    /**
     * Personal config (currently unused — importer is admin-only).
     *
     * @param Form $form
     */
    public static function personalConfig(Form $form): void
    {
        // no-op
    }

    /**
     * Resolve a runtime option from plugin config with a fallback default.
     *
     * @param string $key     Config key.
     * @param mixed  $default Fallback when key is missing or empty.
     *
     * @return mixed
     */
    public static function option(string $key, mixed $default = null): mixed
    {
        /** @var Options $options */
        $options = \Widget\Options::alloc();
        $config = $options->plugin('WordPressImporter');

        if ($config === null) {
            return $default;
        }

        $value = $config->{$key} ?? null;

        return ($value === null || $value === '') ? $default : $value;
    }

    /**
     * Absolute URL to the plugin's admin panel.
     *
     * @return string
     */
    public static function panelUrl(): string
    {
        $options = \Widget\Options::alloc();
        // TypeRenew builds panel URLs as: extending.php?panel=<urlencoded file path>
        return \Typecho\Common::url('extending.php?panel=' . rawurlencode(self::PANEL_FILE), $options->adminUrl);
    }

    /**
     * Absolute filesystem path to the plugin root.
     *
     * @return string
     */
    public static function path(): string
    {
        return dirname(__DIR__);
    }

    /**
     * Absolute URL to the plugin's assets directory.
     *
     * @return string
     */
    public static function assetsUrl(): string
    {
        $options = \Widget\Options::alloc();
        return \Typecho\Common::url('WordPressImporter/assets', $options->pluginUrl);
    }

    /**
     * Ensure the current user is an administrator. Throws on failure.
     *
     * @throws \Typecho\Plugin\Exception
     */
    public static function guardAdministrator(): void
    {
        $user = User::alloc();
        if (!$user->pass('administrator', true)) {
            throw new \Typecho\Plugin\Exception(_t('دسترسی ممنوع: نقش مدیر لازم است.'), 403);
        }
    }
}
