<?php
/**
 * Admin panel — inline view that integrates with TypeRenew's admin layout.
 *
 * TypeRenew's extending.php includes common.php before requiring this file,
 * so $user, $options, $request, $security and $menu are already available.
 * It also checks if the panel output starts with <doctype html> or <html>;
 * if NOT, it wraps the panel inside the standard admin layout
 * (header.php + menu.php + main + footer.php). This file therefore emits
 * only the inline content — TypeRenew provides the chrome.
 *
 * The CSS classes used here (tr-card, tr-btn, tr-panel, etc.) come from
 * TypeRenew's renew-ui.css and automatically inherit the active admin theme
 * (light or dark) via the `html.tr-theme-dark` selector.
 *
 * @package WordPressImporter
 */

declare(strict_types=1);

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

use TypechoPlugin\WordPressImporter\Action;
use TypechoPlugin\WordPressImporter\Plugin;
use TypechoPlugin\WordPressImporter\Support\SettingsManager;
use TypechoPlugin\WordPressImporter\Support\StateManager;

// $user, $options, $request, $security are provided by admin/common.php
// (which extending.php includes before requiring this file).
$user->pass('administrator');

$settings    = new SettingsManager();
$nonce       = Action::issueNonce();
$ajaxUrl     = \Typecho\Common::url('action/' . Plugin::ACTION, $options->index);
$assetsUrl   = Plugin::assetsUrl();
$panelUrl    = Plugin::panelUrl();

$lastRun = [
    'status'        => StateManager::get('last_run_status'),
    'id'            => StateManager::get('last_run_id'),
    'dry_run'       => (bool) StateManager::get('last_run_dry_run', false),
    'started_at'    => StateManager::get('last_run_started_at'),
    'finished_at'   => StateManager::get('last_run_finished_at'),
    'snapshot_taken'=> StateManager::get('last_snapshot_taken', false),
    'result'        => StateManager::get('last_run_result'),
    'error'         => StateManager::get('last_run_error'),
];

$config = Plugin::option('default_mode', 'keep');
$defaultFeatures = Plugin::option('features', []);
if (!is_array($defaultFeatures)) {
    $defaultFeatures = [];
}

// Bootstrap the JS app with a single JSON blob.
$boot = [
    'nonce'     => $nonce,
    'ajaxUrl'   => $ajaxUrl,
    'panelUrl'  => $panelUrl,
    'assetsUrl' => $assetsUrl,
    'defaults'  => [
        'mode'        => $config,
        'source_kind' => Plugin::option('default_source', 'mysql'),
        'chunk_size'  => (int) Plugin::option('chunk_size', 100),
        'features'    => $defaultFeatures,
    ],
    'saved'     => $settings->all(),
    'last_run'  => $lastRun,
    // PHP upload limits — exposed so the JS can pre-validate file size
    'limits'    => [
        'upload_max_filesize' => ini_get('upload_max_filesize') ?: '',
        'post_max_size'       => ini_get('post_max_size') ?: '',
        'max_execution_time'  => (int) ini_get('max_execution_time'),
        'memory_limit'        => ini_get('memory_limit') ?: '',
    ],
];
$bootJson = htmlspecialchars(
    json_encode($boot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
    ENT_QUOTES
);
?>
<!-- WordPressImporter panel v1.0 (inline) — wrapped by TypeRenew admin layout -->
<link rel="stylesheet" href="<?php echo htmlspecialchars($assetsUrl); ?>/css/wizard.css">

<div class="wp-i-panel-head" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:18px;">
    <div>
        <h2 style="margin:0;font-size:20px;font-weight:700;color:var(--tr-text);"><?php _e('واردکنندهٔ وردپرس'); ?></h2>
        <p style="margin:4px 0 0;color:var(--tr-text-3);font-size:13px;">
            <?php _e('برای TypeRenew — مهاجرت امن محتوای وردپرس'); ?>
        </p>
    </div>
</div>

<div id="wp-importer-app" data-boot="<?php echo $bootJson; ?>"></div>

<script>
    window.WP_IMPORTER_BOOT = <?php echo json_encode($boot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;
</script>
<script src="<?php echo htmlspecialchars($assetsUrl); ?>/js/wizard.js" defer></script>
