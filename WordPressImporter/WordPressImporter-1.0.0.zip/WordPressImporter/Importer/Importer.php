<?php
/**
 * Importer — orchestrator that runs all registered domain importers in order.
 *
 * Responsibilities:
 *   - Decide which importers to run based on SettingsManager + ImportContext.
 *   - Pre-create the RollbackManager snapshot before any writes (in 'clean' mode
 *     OR when rollback feature is enabled).
 *   - Register every phase's estimated count with ProgressManager.
 *   - Run importers in the correct dependency order:
 *       authors → categories → media → posts → comments → fields → menus
 *     (posts depend on authors/categories/media; comments/fields depend on posts)
 *   - Aggregate per-importer results into one ImportResult summary.
 *   - Mark the run as completed/failed in ProgressManager.
 *   - Persist the run summary into StateManager so the Report step can show it.
 *
 * @package WordPressImporter\Importer
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Importer;

use Throwable;
use TypechoPlugin\WordPressImporter\Contract\ImporterInterface;
use TypechoPlugin\WordPressImporter\Contract\SourceInterface;
use TypechoPlugin\WordPressImporter\Converter\GutenbergConverter;
use TypechoPlugin\WordPressImporter\Converter\ShortcodeConverter;
use TypechoPlugin\WordPressImporter\Exception\ImporterException;
use TypechoPlugin\WordPressImporter\Source\SourceFactory;
use TypechoPlugin\WordPressImporter\Support\ConflictDetector;
use TypechoPlugin\WordPressImporter\Support\ImportContext;
use TypechoPlugin\WordPressImporter\Support\ImportResult;
use TypechoPlugin\WordPressImporter\Support\Logger;
use TypechoPlugin\WordPressImporter\Support\ProgressManager;
use TypechoPlugin\WordPressImporter\Support\RollbackManager;
use TypechoPlugin\WordPressImporter\Support\SettingsManager;
use TypechoPlugin\WordPressImporter\Support\StateManager;

final class Importer
{
    private SourceInterface $source;
    private ImportContext $context;
    private RollbackManager $rollback;

    /** @var list<ImporterInterface> */
    private array $importers;

    public function __construct(
        private SettingsManager $settings,
        private Logger $logger,
        private ProgressManager $progress,
    ) {
        $this->source = SourceFactory::make($settings);
        $conflicts = new ConflictDetector(\Typecho\Db::get(), \Typecho\Db::get()->getPrefix());

        $this->context = new ImportContext(
            source: $this->source,
            settings: $settings,
            progress: $progress,
            logger: $logger,
            conflicts: $conflicts,
            shortcodes: new ShortcodeConverter($settings->convertShortcodes()),
            gutenberg: new GutenbergConverter($settings->convertGutenberg()),
        );

        // Register importers in dependency order.
        $this->importers = [
            new AuthorImporter($this->context),
            new CategoryImporter($this->context),
            new MediaImporter($this->context),
            new PostImporter($this->context),
            new CommentImporter($this->context),
            new FieldImporter($this->context),
            new MenuImporter($this->context),
        ];
    }

    /**
     * Execute the full import. Returns the aggregate ImportResult.
     *
     * @throws ImporterException
     */
    public function run(string $runId): ImportResult
    {
        $this->logger->setPhase('orchestrator');
        $dryRun = $this->settings->dryRun();
        $this->logger->info("شروع اجرای ایمپورت", [
            'run_id'  => $runId,
            'mode'    => $this->settings->mode(),
            'dry_run' => $dryRun,
        ]);
        StateManager::set('last_run_dry_run', $dryRun);
        if ($dryRun) {
            $this->logger->warning(
                "حالت آزمایشی (Dry-Run) فعال است — هیچ داده‌ای در دیتابیس نوشته نخواهد شد. "
                . 'این اجرا فقط برای بررسی و شمارش است.',
                ['run_id' => $runId]
            );
        }

        $this->progress->startRun($runId);

        // Pre-register phases with their estimates so the progress bar has totals.
        foreach ($this->importers as $importer) {
            if (!$importer->enabled($this->context)) {
                continue;
            }
            $this->progress->registerPhase($importer->name(), $importer->estimate($this->context));
        }

        // Rollback snapshot
        //
        // NOTE: a snapshot failure is NON-FATAL by design. Some environments
        // (restricted DB users, unusual adapters) cannot create the shadow
        // tables — cancelling the whole import because of that would make the
        // plugin unusable there. Instead we log a prominent warning and
        // continue WITHOUT a rollback point; the user can still enable a
        // mysqldump-style backup beforehand.
        $this->rollback = new RollbackManager($runId);
        $snapshotTaken = false;
        if ($this->settings->rollbackEnabled() && !$this->settings->dryRun()) {
            try {
                $rows = $this->rollback->snapshot();
                $snapshotTaken = true;
                $this->logger->info("اسنپ‌شات پیش از ایمپورت گرفته شد", ['rows' => $rows]);
                StateManager::set('last_snapshot_run_id', $runId);
                StateManager::set('last_snapshot_at', time());
            } catch (\Throwable $e) {
                $snapshotTaken = false;
                $this->logger->warning(
                    "اسنپ‌شات پیش از ایمپورت ناموفق بود — ایمپورت بدون امکان برگشت ادامه می‌یابد",
                    ['error' => $e->getMessage()]
                );
                StateManager::delete('last_snapshot_run_id');
                StateManager::delete('last_snapshot_at');
            }
        }
        StateManager::set('last_run_id', $runId);
        StateManager::set('last_run_started_at', time());
        StateManager::set('last_snapshot_taken', $snapshotTaken);

        // Run importers in order
        $aggregate = new ImportResult();
        try {
            foreach ($this->importers as $importer) {
                if (!$importer->enabled($this->context)) {
                    $this->logger->info("رد کردن ایمپورتر غیرفعال", ['importer' => $importer->name()]);
                    continue;
                }
                $this->logger->info("شروع ایمپورتر", ['importer' => $importer->name()]);
                $phase = $importer->import($this->context);
                $aggregate->merge($phase);
                StateManager::set("phase_result_{$importer->name()}", $phase->toArray());
            }

            $this->progress->completeRun();
            $this->logger->setPhase('orchestrator');
            $this->logger->info("اجرای ایمپورت کامل شد", [
                'total' => $aggregate->total,
                'imported' => $aggregate->imported,
                'failed' => $aggregate->failed,
                'skipped' => $aggregate->skipped,
            ]);
            if ($this->settings->dryRun()) {
                $this->logger->warning(
                    "اجرای آزمایشی کامل شد — هیچ داده‌ای در دیتابیس نوشته نشد. "
                    . 'برای ایمپورت واقعی، گزینهٔ «حالت Dry-Run» را در مرحلهٔ ۱ غیرفعال کنید و دوباره اجرا کنید.'
                );
            }
            $this->logger->flush();

            StateManager::set('last_run_result', $aggregate->toArray());
            StateManager::set('last_run_finished_at', time());
            StateManager::set('last_run_status', 'completed');
        } catch (Throwable $e) {
            $this->progress->failRun($e->getMessage());
            $this->logger->critical("اجرای ایمپورت ناموفق شد", ['error' => $e->getMessage()]);
            $this->logger->flush();
            StateManager::set('last_run_status', 'failed');
            StateManager::set('last_run_error', $e->getMessage());
            throw new ImporterException('ایمپورت ناموفق بود: ' . $e->getMessage(), 0, $e);
        }

        return $aggregate;
    }

    /**
     * Rollback the last import using the snapshot.
     *
     * @throws ImporterException
     */
    public function rollback(): void
    {
        $runId = (string) (StateManager::get('last_snapshot_run_id') ?? '');
        if ($runId === '') {
            throw new ImporterException('هیچ اسنپ‌شاتی برای برگشت وجود ندارد.');
        }
        $this->rollback = new RollbackManager($runId);
        try {
            $this->rollback->rollback();
            $this->rollback->discard();
            $this->progress->markRolledBack();
            $this->logger->setPhase('rollback');
            $this->logger->info("برگشت کامل شد", ['run_id' => $runId]);
            $this->logger->flush();
            StateManager::set('last_run_status', 'rolled_back');
        } catch (\Throwable $e) {
            throw new ImporterException('برگشت ناموفق بود: ' . $e->getMessage(), 0, $e);
        }
    }

    public function discardSnapshot(): void
    {
        $runId = (string) (StateManager::get('last_snapshot_run_id') ?? '');
        if ($runId === '') {
            return;
        }
        $this->rollback = new RollbackManager($runId);
        $this->rollback->discard();
        StateManager::delete('last_snapshot_run_id');
        StateManager::delete('last_snapshot_at');
    }

    public function context(): ImportContext
    {
        return $this->context;
    }

    public function source(): SourceInterface
    {
        return $this->source;
    }
}
