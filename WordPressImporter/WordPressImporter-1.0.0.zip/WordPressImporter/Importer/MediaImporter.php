<?php
/**
 * MediaImporter — imports WordPress attachments into TypeRenew contents (type='attachment').
 *
 * Three strategies (per Settings):
 *   - 'copy'     : Source file is on the same server (local path reachable).
 *                  Copy to TypeRenew's upload dir.
 *   - 'download' : Source file is a URL. Stream-download to TypeRenew's upload dir.
 *   - 'skip'     : Don't download. Just register an attachment row pointing at
 *                  the original URL (useful when the WP site will stay online).
 *
 * After import, $context->mediaMap[sourceId] = typechoCid is populated so the
 * PostImporter can rewrite _thumbnail_id references into TypeRenew attachment cids.
 *
 * @package WordPressImporter\Importer
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Importer;

use TypechoPlugin\WordPressImporter\Exception\MediaException;
use TypechoPlugin\WordPressImporter\Support\ImportContext;
use TypechoPlugin\WordPressImporter\Support\ImportResult;
use TypechoPlugin\WordPressImporter\Support\MediaRecord;

final class MediaImporter extends BaseImporter
{
    /** Max bytes per chunk when downloading. */
    private const DOWNLOAD_CHUNK = 64 * 1024;

    public function name(): string
    {
        return 'media';
    }

    public function enabled(ImportContext $context): bool
    {
        return $context->settings->importMedia();
    }

    public function estimate(ImportContext $context): int
    {
        $stats = $context->source->statistics();
        return $stats['media'] ?? 0;
    }

    public function import(ImportContext $context): ImportResult
    {
        $result = new ImportResult();
        $context->progress->startPhase($this->name());
        $context->logger->setPhase($this->name());

        $count = 0;
        foreach ($context->source->streamMedia() as $sourceId => $record) {
            try {
                $this->importOne($record, $result);
                $result->addImported();
            } catch (\Throwable $e) {
                $result->addFailed(1, "رسانه شمارهٔ {$sourceId}: " . $e->getMessage());
                $context->logger->error("ایمپورت رسانه ناموفق بود", [
                    'source_id' => $sourceId,
                    'title' => $record->title,
                    'error' => $e->getMessage(),
                ]);
            }

            $count++;
            if ($count % $context->chunkSize === 0) {
                $context->progress->advance($this->name(), $context->chunkSize);
            }
        }

        $context->progress->advance($this->name(), $count % $context->chunkSize);
        $context->progress->finishPhase($this->name());
        $context->logger->info("ایمپورت رسانه‌ها تمام شد", ['imported' => $result->imported]);
        $context->logger->flush();

        return $result;
    }

    private function importOne(MediaRecord $record, ImportResult $result): void
    {
        $strategy = $this->context->settings->mediaStrategy();
        $localPath = '';
        $url = $record->url;

        try {
            if ($this->context->dryRun) {
                // Dry-run: perform NO network / filesystem I/O — simulate only.
                // Real download results are reported on the real run.
                $this->context->logger->debug("شبیه‌سازی رسانه (حالت آزمایشی — بدون دانلود)", [
                    'source_id' => $record->sourceId,
                    'strategy' => $strategy,
                ]);
            } elseif ($strategy === 'copy') {
                if ($record->filePath === '' || !is_file($record->filePath)) {
                    throw new MediaException("فایل منبع برای کپی محلی یافت نشد");
                }
                $localPath = $this->copyToUploads($record->filePath, $record->slug);
            } elseif ($strategy === 'download') {
                if ($url === '') {
                    throw new MediaException("هیچ URLی برای دانلود موجود نیست");
                }
                $localPath = $this->downloadToUploads($url, $record->slug);
            }
            // skip → leave $localPath empty, $url stays as the WP URL
        } catch (MediaException $e) {
            // Skip-but-register: insert the attachment row but mark as failed download
            $result->addSkipped(1, "دانلود رسانه شمارهٔ {$record->sourceId} ناموفق بود: " . $e->getMessage());
            $this->context->logger->warning("دانلود رسانه ناموفق بود — ثبت به‌عنوان placeholder", [
                'source_id' => $record->sourceId,
                'url' => $url,
                'error' => $e->getMessage(),
            ]);
        }

        // Resolve author
        $authorId = $this->context->userMap[$record->sourceParentId]
            ?? $this->fallbackAuthorId();

        $slug = $this->context->conflicts->reserveSlug($record->slug ?: 'media-' . $record->sourceId, $record->sourceId)['slug'];

        $row = [
            // varchar(150) — truncate defensively for strict mode.
            'title'          => mb_substr($record->title, 0, 150),
            'slug'           => $slug,
            'created'        => $record->uploadedAt,
            'modified'       => $record->uploadedAt,
            'text'           => $record->description ?? '',
            'order'          => 0,
            'authorId'       => $authorId,
            'type'           => 'attachment',
            'status'         => 'publish',
            'password'       => '',
            'commentsNum'    => 0,
            'allowComment'   => 0,
            'allowPing'      => 0,
            'allowFeed'      => 1,
            'parent'         => 0,
        ];

        $cid = $this->insertRow('table.contents', $row);
        if ($cid === 0) {
            return;
        }

        // Store attachment metadata as a custom field on the content.
        $attachmentUrl = $localPath !== '' ? $this->uploadsUrl(basename($localPath)) : $url;
        if (!$this->context->dryRun) {
            $this->db->query(
                $this->db->insert('table.fields')->rows([
                    'cid'    => $cid,
                    'name'   => 'attachment',
                    'type'   => 'str',
                    'str_value' => $attachmentUrl,
                    'int_value' => 0,
                    'float_value' => 0,
                ])
            );
            $this->db->query(
                $this->db->insert('table.fields')->rows([
                    'cid'    => $cid,
                    'name'   => 'mime',
                    'type'   => 'str',
                    'str_value' => $record->mime,
                    'int_value' => 0,
                    'float_value' => 0,
                ])
            );
            if ($record->altText !== '') {
                $this->db->query(
                    $this->db->insert('table.fields')->rows([
                        'cid'    => $cid,
                        'name'   => 'alt',
                        'type'   => 'str',
                        'str_value' => $record->altText,
                        'int_value' => 0,
                        'float_value' => 0,
                    ])
                );
            }
        }

        $this->context->mediaMap[$record->sourceId] = $cid;
    }

    /* ----- file strategies ----- */

    private function copyToUploads(string $sourcePath, string $slug): string
    {
        $target = $this->uploadsDir() . '/' . $this->safeFilename($slug, $sourcePath);
        if (!@copy($sourcePath, $target)) {
            throw new MediaException("کپی فایل از {$sourcePath} به {$target} ناموفق بود");
        }
        return $target;
    }

    private function downloadToUploads(string $url, string $slug): string
    {
        $target = $this->uploadsDir() . '/' . $this->safeFilename($slug, $url);

        if (function_exists('curl_init')) {
            $localPath = $this->curlDownload($url, $target);
        } else {
            $localPath = $this->streamDownload($url, $target);
        }

        return $localPath;
    }

    /**
     * cURL-based download — works on hosts where allow_url_fopen is OFF
     * (very common on shared hosting). Follows redirects, fails on HTTP
     * errors, enforces timeouts and the 100 MB safety cap.
     */
    private function curlDownload(string $url, string $target): string
    {
        $out = @fopen($target, 'wb');
        if (!$out) {
            throw new MediaException("باز کردن فایل مقصد برای نوشتن ناموفق بود: {$target}");
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_FILE          => $out,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS     => 5,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT       => 120,
            CURLOPT_FAILONERROR   => true,
            CURLOPT_USERAGENT     => 'TypeRenew-WordPressImporter/1.0',
            CURLOPT_SSL_VERIFYPEER => false, // legacy WP files often live on certs shared hosts reject
        ]);

        try {
            if (curl_exec($ch) === false) {
                throw new MediaException('دانلود cURL ناموفق بود: ' . curl_error($ch));
            }
            $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if ($httpCode >= 400) {
                throw new MediaException("کد HTTP {$httpCode} هنگام دانلود دریافت شد");
            }
        } finally {
            curl_close($ch);
            fclose($out);
        }

        $size = (int) @filesize($target);
        if ($size === 0) {
            @unlink($target);
            throw new MediaException("فایل دانلودشده خالی است");
        }
        if ($size > 100 * 1024 * 1024) {
            @unlink($target);
            throw new MediaException("دانلود از حد مجاز ۱۰۰ مگابایت فراتر رفت");
        }

        return $target;
    }

    /**
     * Stream-based download (allow_url_fopen path) with a timeout context.
     */
    private function streamDownload(string $url, string $target): string
    {
        $ctx = stream_context_create([
            'http' => ['timeout' => 120, 'follow_location' => 1, 'max_redirects' => 5],
        ]);

        $in = @fopen($url, 'rb', false, $ctx);
        if (!$in) {
            $hint = (bool) ini_get('allow_url_fopen')
                ? 'آدرس URL پاسخ نداد یا وجود ندارد'
                : 'گزینهٔ allow_url_fopen در PHP خاموش است و افزونهٔ cURL هم در دسترس نیست';
            throw new MediaException("باز کردن URL برای خواندن ناموفق بود ({$hint}): {$url}");
        }
        $out = @fopen($target, 'wb');
        if (!$out) {
            fclose($in);
            throw new MediaException("باز کردن فایل مقصد برای نوشتن ناموفق بود: {$target}");
        }

        try {
            $total = 0;
            while (!feof($in)) {
                $chunk = fread($in, self::DOWNLOAD_CHUNK);
                if ($chunk === false) {
                    break;
                }
                fwrite($out, $chunk);
                $total += strlen($chunk);
                if ($total > 100 * 1024 * 1024) { // 100 MB per-file safety cap
                    throw new MediaException("دانلود از حد مجاز ۱۰۰ مگابایت فراتر رفت");
                }
            }
        } finally {
            fclose($in);
            fclose($out);
        }

        if ($total === 0) {
            @unlink($target);
            throw new MediaException("فایل دانلودشده خالی است");
        }

        return $target;
    }

    private function uploadsDir(): string
    {
        $dir = dirname(__DIR__, 2) . '/uploads';
        if (!is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }
        return $dir;
    }

    private function uploadsUrl(string $filename): string
    {
        $options = \Widget\Options::alloc();
        return \Typecho\Common::url('WordPressImporter/uploads/' . rawurlencode($filename), $options->pluginUrl);
    }

    private function safeFilename(string $slug, string $sourcePathOrUrl): string
    {
        $ext = pathinfo(parse_url($sourcePathOrUrl, PHP_URL_PATH) ?: '', PATHINFO_EXTENSION);
        $ext = $ext !== '' ? '.' . preg_replace('/[^a-z0-9]/i', '', $ext) : '';
        $slug = preg_replace('/[^a-z0-9\-_]/i', '-', $slug) ?? 'media';
        $slug = trim($slug, '-');
        if ($slug === '') {
            $slug = 'media-' . bin2hex(random_bytes(4));
        }
        // Avoid collisions in filesystem
        $candidate = $slug . $ext;
        $i = 2;
        while (is_file($this->uploadsDir() . '/' . $candidate)) {
            $candidate = "{$slug}-{$i}{$ext}";
            $i++;
        }
        return $candidate;
    }

    private function fallbackAuthorId(): int
    {
        $row = $this->db->fetchRow(
            $this->db->select('uid')->from('table.users')->where('group = ?', 'administrator')->order('uid', 'ASC')->limit(1)
        );
        return $row ? (int) $row['uid'] : 1;
    }
}
