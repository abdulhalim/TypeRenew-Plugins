<?php
/**
 * BaseImporter — shared infrastructure for all domain importers.
 *
 * @package WordPressImporter\Importer
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Importer;

use Typecho\Db;
use TypechoPlugin\WordPressImporter\Contract\ImporterInterface;
use TypechoPlugin\WordPressImporter\Support\ImportContext;
use TypechoPlugin\WordPressImporter\Support\ImportResult;

abstract class BaseImporter implements ImporterInterface
{
    protected Db $db;
    protected string $prefix;

    /**
     * Monotonic counter for simulated (dry-run) insert IDs.
     *
     * In dry-run mode insertRow() must return a NON-ZERO id so that the
     * context maps (postMap, commentMap, userMap, termMap, mediaMap) get
     * populated — otherwise downstream phases (comments, fields) silently
     * skip everything and the dry-run report under-counts. Simulated ids
     * are NEGATIVE so they can never collide with real auto-increment ids,
     * and any accidental use in a WHERE clause simply matches nothing.
     */
    private int $dryRunSeq = 0;

    public function __construct(
        protected ImportContext $context,
    ) {
        $this->db = Db::get();
        $this->prefix = $this->db->getPrefix();
    }

    /**
     * Bulk insert rows into a table. Uses TypeRenew's query builder for
     * the first row, then appends additional ON DUPLICATE KEY handling
     * explicitly so we control conflict policy per-importer.
     *
     * @param string               $table  Table name WITHOUT prefix (use 'table.contents').
     * @param list<array<string, mixed>> $rows
     */
    protected function bulkInsert(string $table, array $rows): int
    {
        if ($rows === []) {
            return 0;
        }
        $count = 0;
        foreach ($rows as $row) {
            try {
                $this->db->query($this->db->insert($table)->rows($row));
                $count++;
            } catch (\Throwable $e) {
                // Truncate string values for logging safety.
                $safeRow = [];
                foreach ($row as $k => $v) {
                    $safeRow[$k] = is_string($v) ? mb_substr($v, 0, 80) : $v;
                }
                $this->context->logger->error('درج رکورد در دیتابیس ناموفق بود', [
                    'table' => $table,
                    'row' => $safeRow,
                    'error' => $e->getMessage(),
                ]);
            }
        }
        return $count;
    }

    /**
     * In dry-run mode, do not write — just advance progress.
     */
    protected function wouldInsert(string $table, array $row): void
    {
        // no-op
    }

    /**
     * Insert a single row, returning the new auto-increment ID.
     *
     * IMPORTANT: TypeRenew's `Typecho\Db` has NO `lastInsertId()` method.
     * Instead, `Db::query()` inspects the Query object's action and, for
     * INSERT statements, returns the adapter's last-insert-id directly:
     *
     *     $cid = $db->query($db->insert('table.contents')->rows($row));
     *
     * (see Typecho/Db.php ::query() — `case self::INSERT: return
     * $this->adapter->lastInsertId($resource, $handle);`)
     */
    protected function insertRow(string $table, array $row): int
    {
        if ($this->context->dryRun) {
            // Simulated insert — see $dryRunSeq docs above.
            return --$this->dryRunSeq;
        }
        return (int) $this->db->query($this->db->insert($table)->rows($row));
    }

    /**
     * Update an existing row by primary key.
     */
    protected function updateRow(string $table, array $row, string $pk, int $id): int
    {
        if ($this->context->dryRun) {
            return 0;
        }
        $this->db->query(
            $this->db->update($table)->rows($row)->where("{$pk} = ?", $id)
        );
        return $id;
    }

    /**
     * Fetch a single scalar from a query.
     *
     * NOTE: TypeRenew's `Db::query($query, int $op, string $action)` does NOT
     * accept a bound-params array — raw `?` placeholders cannot be passed
     * separately. Values are therefore inlined using the adapter's
     * quoteValue() (the same mechanism the Query builder itself uses).
     *
     * @param string $sql    SQL with no placeholders — values must already be quoted.
     */
    protected function scalar(string $sql): mixed
    {
        $row = $this->db->fetchRow($sql);
        if (!$row) {
            return null;
        }
        return reset($row) ?: null;
    }

    /**
     * Quote a literal value for use in raw SQL (adapter-aware).
     */
    protected function quoteValue(mixed $value): string
    {
        return $this->db->getAdapter()->quoteValue($value);
    }
}
