<?php
/**
 * AuthorImporter — imports WordPress users into TypeRenew users table.
 *
 * Conflict policy:
 *   - If email already exists in TypeRenew: re-use existing uid, populate
 *     $context->userMap[sourceId] = existingUid, log as duplicate.
 *   - If username already exists (different email): append -2, -3 etc.
 *   - Otherwise: insert new user with a placeholder password hash. The
 *     user must reset their password after import (we mark them with
 *     authCode = 'wp-imported' as a flag).
 *
 * @package WordPressImporter\Importer
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Importer;

use TypechoPlugin\WordPressImporter\Support\AuthorRecord;
use TypechoPlugin\WordPressImporter\Support\ImportContext;
use TypechoPlugin\WordPressImporter\Support\ImportResult;

final class AuthorImporter extends BaseImporter
{
    public function name(): string
    {
        return 'authors';
    }

    public function enabled(ImportContext $context): bool
    {
        return $context->settings->importUsers();
    }

    public function estimate(ImportContext $context): int
    {
        $stats = $context->source->statistics();
        return $stats['users'] ?? 0;
    }

    public function import(ImportContext $context): ImportResult
    {
        $result = new ImportResult();
        $context->progress->startPhase($this->name());
        $context->logger->setPhase($this->name());
        $context->conflicts->primeEmailIndex();

        $count = 0;
        foreach ($context->source->streamUsers() as $sourceId => $record) {
            try {
                $this->importOne($record, $result);
                $result->addImported();
            } catch (\Throwable $e) {
                $result->addFailed(1, "کاربر شمارهٔ {$sourceId}: " . $e->getMessage());
                $context->logger->error("ایمپورت کاربر ناموفق بود", [
                    'source_id' => $sourceId,
                    'username' => $record->username,
                    'error' => $e->getMessage(),
                ]);
            }

            $count++;
            if ($count % $context->chunkSize === 0) {
                $context->progress->advance($this->name(), $context->chunkSize);
            }
        }

        $context->progress->advance($this->name(), $count % $context->chunkSize);
        $context->progress->finishPhase($this->name());
        $context->logger->info("ایمپورت نویسندگان تمام شد", ['imported' => $result->imported, 'failed' => $result->failed]);
        $context->logger->flush();

        return $result;
    }

    private function importOne(AuthorRecord $record, ImportResult $result): void
    {
        $this->context->logger->debug("در حال ایمپورت کاربر", ['source_id' => $record->sourceId, 'username' => $record->username]);

        // Email conflict?
        $check = $this->context->conflicts->checkEmail($record->email);
        if ($check['exists']) {
            $this->context->userMap[$record->sourceId] = $check['target_id'];
            $result->addDuplicate();
            $this->context->logger->notice("ایمیل کاربر از قبل وجود دارد — نگاشت می‌شود", [
                'source_id' => $record->sourceId,
                'email' => $record->email,
                'target_uid' => $check['target_id'],
            ]);
            return;
        }

        // Username conflict?
        $username = $this->uniqueUsername($record->username);

        $group = $this->mapRole($record->role);
        $row = [
            // varchar(32/150) — truncate defensively so MySQL strict mode
            // never rejects an over-length WordPress value.
            'name'       => mb_substr($username, 0, 32),
            // Random unguessable hash — imported users cannot log in until
            // they reset their password (empty '' is avoided on purpose so
            // no accidental empty-password login path can ever match).
            'password'   => password_hash(bin2hex(random_bytes(16)), PASSWORD_DEFAULT),
            'mail'       => mb_substr($record->email, 0, 150),
            'url'        => mb_substr($record->url, 0, 150),
            'screenName' => mb_substr($record->displayName !== '' ? $record->displayName : $username, 0, 32),
            'created'    => $record->registeredAt,
            'activated'  => $record->registeredAt,
            'logged'     => 0,
            'group'      => $group,
            'authCode'   => 'wp-imported',
        ];

        $uid = $this->insertRow('table.users', $row);
        if ($uid === 0) {
            return;
        }
        $this->context->userMap[$record->sourceId] = $uid;
        $this->context->conflicts->reserveEmail($record->email, $uid);
    }

    private function mapRole(string $role): string
    {
        return match ($role) {
            'administrator' => 'administrator',
            'editor'        => 'editor',
            'author'        => 'contributor',
            'contributor'   => 'contributor',
            'subscriber'    => 'subscriber',
            default         => 'subscriber',
        };
    }

    /**
     * Generate a unique username if the desired one is taken.
     */
    private function uniqueUsername(string $username): string
    {
        $username = trim($username);
        if ($username === '') {
            $username = 'user-' . bin2hex(random_bytes(4));
        }
        // users.name is varchar(32) — leave room for the "-N" suffix.
        $username = mb_substr($username, 0, 28);

        $candidate = $username;
        $i = 2;
        while (true) {
            $existing = $this->db->fetchRow(
                $this->db->select('uid')->from('table.users')->where('name = ?', $candidate)->limit(1)
            );
            if (!$existing) {
                return $candidate;
            }
            $candidate = "{$username}-{$i}";
            $i++;
            if ($i > 1000) {
                return $username . '-' . bin2hex(random_bytes(4));
            }
        }
    }
}
