<?php
/**
 * MenuImporter — imports WordPress nav menus into TypeRenew as a special
 * category of metadata.
 *
 * TypeRenew does not have a dedicated menu table. We store each menu as a
 * `metas` row of type='menu' (a custom meta type), and each menu item as a
 * `fields` row on that meta with serialized details. Themes can opt into
 * reading menus from this structure.
 *
 * @package WordPressImporter\Importer
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Importer;

use TypechoPlugin\WordPressImporter\Support\ImportContext;
use TypechoPlugin\WordPressImporter\Support\ImportResult;
use TypechoPlugin\WordPressImporter\Support\MenuItemRecord;

final class MenuImporter extends BaseImporter
{
    /** @var array<int, int> source menu id → typecho mid */
    private array $menuMetaMap = [];

    /** @var array<int, list<MenuItemRecord>> source menu id → items */
    private array $byMenu = [];

    public function name(): string
    {
        return 'menus';
    }

    public function enabled(ImportContext $context): bool
    {
        return $context->settings->importMenus();
    }

    public function estimate(ImportContext $context): int
    {
        $stats = $context->source->statistics();
        return $stats['menus'] ?? 0;
    }

    public function import(ImportContext $context): ImportResult
    {
        $result = new ImportResult();
        $context->progress->startPhase($this->name());
        $context->logger->setPhase($this->name());

        // Pass 1: collect items by menu
        foreach ($context->source->streamMenuItems() as $item) {
            $this->byMenu[$item->sourceMenuId][] = $item;
        }
        $context->progress->registerPhase($this->name(), count($this->byMenu));

        // Pass 2: create a meta row per menu, then store items as fields
        foreach ($this->byMenu as $menuId => $items) {
            try {
                $first = $items[0];
                $mid = $this->ensureMenuMeta($first->menuName, $first->menuSlug);
                $this->storeItems($mid, $items);
                $result->addImported();
            } catch (\Throwable $e) {
                $result->addFailed(1, "منوی شمارهٔ {$menuId}: " . $e->getMessage());
                $context->logger->error("ایمپورت منو ناموفق بود", [
                    'source_menu_id' => $menuId,
                    'error' => $e->getMessage(),
                ]);
            }
            $context->progress->advance($this->name(), 1);
        }

        $context->progress->finishPhase($this->name());
        $context->logger->info("ایمپورت منوها تمام شد", ['imported' => $result->imported]);
        $context->logger->flush();

        return $result;
    }

    private function ensureMenuMeta(string $name, string $slug): int
    {
        $existing = $this->db->fetchRow(
            $this->db->select('mid')->from('table.metas')
                ->where('slug = ?', $slug)->where('type = ?', 'menu')->limit(1)
        );
        if ($existing) {
            return (int) $existing['mid'];
        }

        $row = [
            'name'        => $name,
            'slug'        => $slug,
            'type'        => 'menu',
            'description' => '',
            'count'       => 0,
            'order'       => 0,
            'parent'      => 0,
        ];
        return $this->insertRow('table.metas', $row);
    }

    /**
     * @param list<MenuItemRecord> $items
     */
    private function storeItems(int $mid, array $items): void
    {
        if ($this->context->dryRun) {
            return;
        }

        // Sort by order
        usort($items, fn (MenuItemRecord $a, MenuItemRecord $b) => $a->order <=> $b->order);

        $serialized = json_encode(array_map(fn (MenuItemRecord $i) => [
            'title' => $i->title,
            'url' => $i->url,
            'type' => $i->objectType,
            'object_slug' => $i->objectSlug,
            'order' => $i->order,
        ], $items), JSON_UNESCAPED_UNICODE);

        // fields' primary key is (cid, name) — storing every menu under
        // (0, 'menu_items') would collide as soon as a second menu is
        // imported, so the field name is suffixed with the menu's mid.
        $this->db->query(
            $this->db->insert('table.fields')->rows([
                'cid'         => 0, // menus aren't attached to a content
                'name'        => 'menu_items_' . $mid,
                'type'        => 'str',
                'str_value'   => $serialized,
                'int_value'   => $mid,
                'float_value' => 0,
            ])
        );

        // Bump count — raw `?` params can't be passed to Db::query(),
        // use the query builder (TypeRenew core pattern).
        $this->db->query(
            $this->db->update('table.metas')
                ->expression('count', 'count + 1')
                ->where('mid = ?', $mid)
        );
    }
}
