<?php
/**
 * PostImporter — imports WordPress posts/pages into TypeRenew contents.
 *
 * Pipeline:
 *   1. Stream posts from source.
 *   2. Resolve author via $context->userMap (fallback: first admin).
 *   3. Convert content via ShortcodeConverter + GutenbergConverter.
 *   4. Reserve slug via ConflictDetector.
 *   5. Map post_type — only 'post' and 'page' are imported. Unknown post
 *      types are skipped and logged as "ignored".
 *   6. Insert row → capture cid.
 *   7. Insert relationships (post ↔ category/tag) into `relationships` table.
 *   8. Capture cid in $context->postMap for later use by comments & meta.
 *   9. If featuredImageId is set, store as `fields` row named 'thumb' with
 *      the resolved TypeRenew attachment cid.
 *
 * @package WordPressImporter\Importer
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Importer;

use TypechoPlugin\WordPressImporter\Support\ImportContext;
use TypechoPlugin\WordPressImporter\Support\ImportResult;
use TypechoPlugin\WordPressImporter\Support\PostRecord;

final class PostImporter extends BaseImporter
{
    /** Post types we accept from the WordPress source. */
    private const ACCEPTED_TYPES = ['post', 'page'];

    public function name(): string
    {
        return 'posts';
    }

    public function enabled(ImportContext $context): bool
    {
        return true;
    }

    public function estimate(ImportContext $context): int
    {
        $stats = $context->source->statistics();
        return ($stats['posts'] ?? 0) + ($stats['pages'] ?? 0);
    }

    public function import(ImportContext $context): ImportResult
    {
        $result = new ImportResult();
        $context->progress->startPhase($this->name());
        $context->logger->setPhase($this->name());
        $context->conflicts->primeSlugIndex();

        $count = 0;
        foreach ($context->source->streamPosts(self::ACCEPTED_TYPES) as $sourceId => $record) {
            try {
                $this->importOne($record, $result);
                $result->addImported();
            } catch (\Throwable $e) {
                $result->addFailed(1, "پست شمارهٔ {$sourceId}: " . $e->getMessage());
                $context->logger->error("ایمپورت پست ناموفق بود", [
                    'source_id' => $sourceId,
                    'title' => mb_substr($record->title, 0, 80),
                    'error' => $e->getMessage(),
                ]);
            }

            $count++;
            if ($count % $context->chunkSize === 0) {
                $context->progress->advance($this->name(), $context->chunkSize);
            }
        }

        $context->progress->advance($this->name(), $count % $context->chunkSize);
        $context->progress->finishPhase($this->name());
        $context->logger->info("ایمپورت پست‌ها تمام شد", [
            'imported' => $result->imported,
            'failed' => $result->failed,
            'skipped' => $result->skipped,
        ]);
        $context->logger->flush();

        return $result;
    }

    private function importOne(PostRecord $record, ImportResult $result): void
    {
        // Reject unknown post types — TypeRenew only supports 'post' and 'page'.
        // (Source adapters already filter on accepted types, but this is a
        // defensive belt-and-suspenders check.)
        if (!in_array($record->type, self::ACCEPTED_TYPES, true)) {
            $result->addSkipped(1, "پست شمارهٔ {$record->sourceId} رد شد — نوع پست «{$record->type}» پشتیبانی نمی‌شود");
            $this->context->logger->notice("نوع پست پشتیبانی‌نشده نادیده گرفته شد", [
                'source_id' => $record->sourceId,
                'post_type' => $record->type,
                'title' => mb_substr($record->title, 0, 80),
            ]);
            return;
        }

        // Resolve author
        $authorId = $this->context->userMap[$record->sourceAuthorId]
            ?? $this->fallbackAuthorId();

        // Convert content
        $content = $record->content;
        if ($this->context->settings->convertGutenberg()) {
            $content = $this->context->gutenberg->convert($content);
        }
        if ($this->context->settings->convertShortcodes()) {
            $content = $this->context->shortcodes->convert($content);
        }

        // Rewrite attachment URLs from WP URLs to TypeRenew URLs
        $content = $this->rewriteAttachmentUrls($content);

        // Reserve slug
        $reservation = $this->context->conflicts->reserveSlug($record->slug, $record->sourceId);
        $slug = $reservation['slug'];
        if ($reservation['conflict'] && $this->context->settings->mode() === 'keep') {
            // In keep mode, skip duplicate.
            $result->addSkipped(1, "پست شمارهٔ {$record->sourceId} رد شد — نامک (slug) «{$record->slug}» از قبل وجود دارد");
            $this->context->postMap[$record->sourceId] = $reservation['target_id'] ?? 0;
            return;
        }

        // Map post_type (already validated above; only 'post' or 'page').
        $type = $record->type;

        // Map status
        $status = $this->mapStatus($record->status);

        $row = [
            // varchar(150) — truncate defensively so MySQL strict mode
            // never rejects an over-length WordPress title.
            'title'          => mb_substr($record->title, 0, 150),
            'slug'           => mb_substr($slug, 0, 150),
            'created'        => $record->createdAt,
            'modified'       => $record->modifiedAt,
            'text'           => $content,
            'order'          => 0,
            'authorId'       => $authorId,
            'type'           => $type,
            'status'         => $status,
            'password'       => mb_substr($record->password, 0, 32),
            'commentsNum'    => (int) ($record->commentCount ?? 0),
            'allowComment'   => $record->allowComments ? 1 : 0,
            'allowPing'      => $record->allowPings ? 1 : 0,
            'allowFeed'      => 1,
            'parent'         => 0,
        ];

        $cid = $this->insertRow('table.contents', $row);
        if ($cid === 0) {
            return;
        }
        $this->context->postMap[$record->sourceId] = $cid;
        $this->context->slugIndex[$slug] = $cid;

        // Insert relationships (post ↔ categories/tags)
        $this->linkRelationships($cid, $record);

        // Store featured image as a `fields` row
        if ($record->featuredImageId !== null && isset($this->context->mediaMap[$record->featuredImageId])) {
            $this->setFeaturedImage($cid, $this->context->mediaMap[$record->featuredImageId]);
        }

        // Store excerpt as a field if present
        if ($record->excerpt !== '') {
            $this->setExcerpt($cid, $record->excerpt);
        }
    }

    private function linkRelationships(int $cid, PostRecord $record): void
    {
        // Taxonomy-qualified lookup (supports SHARED term IDs — the same
        // term_id as both a category and a tag) with a plain-id fallback for
        // sources that map plain IDs (MySQL).
        $mids = [];
        foreach ($record->categoryIds as $termId) {
            $mid = $this->context->termMap['category:' . $termId]
                ?? $this->context->termMap[$termId]
                ?? null;
            if ($mid !== null) {
                $mids[] = $mid;
            }
        }
        foreach ($record->tagIds as $termId) {
            $mid = $this->context->termMap['post_tag:' . $termId]
                ?? $this->context->termMap[$termId]
                ?? null;
            if ($mid !== null) {
                $mids[] = $mid;
            }
        }
        $mids = array_values(array_unique($mids));
        if ($mids === [] || $this->context->dryRun) {
            return;
        }
        foreach ($mids as $mid) {
            try {
                $this->db->query(
                    $this->db->insert('table.relationships')->rows([
                        'cid' => $cid,
                        'mid' => $mid,
                    ])
                );
                // Update meta count
                // NOTE: Db::query() takes (Query|sql, int $op, string $action) —
                // it does NOT accept a bound-params array, so we use the
                // query builder; ->expression() is TypeRenew's way of writing
                // `count = count + 1` (see Widget/Contents/EditTrait.php).
                $this->db->query(
                    $this->db->update('table.metas')
                        ->expression('count', 'count + 1')
                        ->where('mid = ?', $mid)
                );
            } catch (\Throwable $e) {
                $this->context->logger->warning("اتصال رابطه ناموفق بود", [
                    'cid' => $cid, 'mid' => $mid, 'error' => $e->getMessage(),
                ]);
            }
        }
    }

    private function setFeaturedImage(int $cid, int $attachmentCid): void
    {
        if ($this->context->dryRun) {
            return;
        }
        try {
            $this->db->query(
                $this->db->insert('table.fields')->rows([
                    'cid'         => $cid,
                    'name'        => 'thumb',
                    'type'        => 'int',
                    'str_value'   => '',
                    'int_value'   => $attachmentCid,
                    'float_value' => 0,
                ])
            );
        } catch (\Throwable $e) {
            $this->context->logger->warning("تنظیم تصویر شاخص ناموفق بود", [
                'cid' => $cid, 'attachment_cid' => $attachmentCid, 'error' => $e->getMessage(),
            ]);
        }
    }

    private function setExcerpt(int $cid, string $excerpt): void
    {
        if ($this->context->dryRun) {
            return;
        }
        try {
            $this->db->query(
                $this->db->insert('table.fields')->rows([
                    'cid'         => $cid,
                    'name'        => 'excerpt',
                    'type'        => 'str',
                    'str_value'   => $excerpt,
                    'int_value'   => 0,
                    'float_value' => 0,
                ])
            );
        } catch (\Throwable $e) {
            $this->context->logger->warning("تنظیم چکیده ناموفق بود", ['cid' => $cid, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Replace WordPress upload URLs inside content with the corresponding
     * TypeRenew attachment URLs.
     */
    private function rewriteAttachmentUrls(string $content): string
    {
        if ($this->context->mediaMap === []) {
            return $content;
        }
        foreach ($this->context->mediaMap as $sourceMediaId => $typechoCid) {
            // Look up the attachment URL stored on the TypeRenew attachment
            $row = $this->db->fetchRow(
                $this->db->select('str_value')->from('table.fields')
                    ->where('cid = ?', $typechoCid)->where('name = ?', 'attachment')->limit(1)
            );
            if (!$row) {
                continue;
            }
            $newUrl = (string) $row['str_value'];
            // Replace any placeholder reference to this attachment id
            $content = str_replace("attachment:{$sourceMediaId}", $newUrl, $content);
        }
        return $content;
    }

    private function mapStatus(string $wpStatus): string
    {
        return match ($wpStatus) {
            'publish'  => 'publish',
            'private'  => 'private',
            'pending'  => 'waiting',
            'draft'    => 'draft',
            'future'   => 'publish', // future posts become published with future timestamp
            default    => 'draft',
        };
    }

    private function fallbackAuthorId(): int
    {
        $row = $this->db->fetchRow(
            $this->db->select('uid')->from('table.users')->where('group = ?', 'administrator')->order('uid', 'ASC')->limit(1)
        );
        return $row ? (int) $row['uid'] : 1;
    }
}
