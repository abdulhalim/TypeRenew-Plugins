<?php
/**
 * CategoryImporter — imports WordPress categories & tags into TypeRenew metas.
 *
 * TypeRenew stores both categories and tags in the same `metas` table,
 * distinguished by `type` ('category' vs 'tag'). Slug uniqueness is enforced
 * at the metas-table level (slug is unique across all metas).
 *
 * @package WordPressImporter\Importer
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Importer;

use TypechoPlugin\WordPressImporter\Support\CategoryRecord;
use TypechoPlugin\WordPressImporter\Support\ImportContext;
use TypechoPlugin\WordPressImporter\Support\ImportResult;

final class CategoryImporter extends BaseImporter
{
    public function name(): string
    {
        return 'categories';
    }

    public function enabled(ImportContext $context): bool
    {
        return true; // always imported
    }

    public function estimate(ImportContext $context): int
    {
        $stats = $context->source->statistics();
        return ($stats['categories'] ?? 0) + ($stats['tags'] ?? 0);
    }

    public function import(ImportContext $context): ImportResult
    {
        $result = new ImportResult();
        $context->progress->startPhase($this->name());
        $context->logger->setPhase($this->name());

        $count = 0;
        foreach ($context->source->streamTerms() as $sourceId => $record) {
            try {
                $this->importOne($record, $result);
                $result->addImported();
            } catch (\Throwable $e) {
                $result->addFailed(1, "دسته/برچسب شمارهٔ {$sourceId}: " . $e->getMessage());
                $context->logger->error("ایمپورت دسته/برچسب ناموفق بود", [
                    'source_id' => $sourceId,
                    'name' => $record->name,
                    'error' => $e->getMessage(),
                ]);
            }

            $count++;
            if ($count % $context->chunkSize === 0) {
                $context->progress->advance($this->name(), $context->chunkSize);
            }
        }

        $context->progress->advance($this->name(), $count % $context->chunkSize);
        $context->progress->finishPhase($this->name());
        $context->logger->info("ایمپورت دسته‌ها تمام شد", ['imported' => $result->imported]);
        $context->logger->flush();

        return $result;
    }

    private function importOne(CategoryRecord $record, ImportResult $result): void
    {
        // Check if a term with this slug already exists in metas
        $existing = $this->context->conflicts->checkTermSlug($record->slug);
        if ($existing !== null) {
            $this->context->termMap[$this->termMapKey($record)] = $existing;
            $result->addDuplicate();
            return;
        }

        // Resolve parent — taxonomy-qualified lookup first, plain-id fallback
        // (the MySQL source maps plain term IDs; the WXR source can produce
        // shared IDs across taxonomies).
        $parentMid = 0;
        if ($record->parentId > 0) {
            $parentKey = $record->taxonomy . ':' . $record->parentId;
            if (isset($this->context->termMap[$parentKey])) {
                $parentMid = $this->context->termMap[$parentKey];
            } elseif (isset($this->context->termMap[$record->parentId])) {
                $parentMid = $this->context->termMap[$record->parentId];
            }
        }

        $type = $record->taxonomy === 'post_tag' ? 'tag' : 'category';
        $row = [
            // varchar(150) columns — truncate defensively for strict mode.
            'name'        => mb_substr($record->name, 0, 150),
            'slug'        => $this->uniqueMetaSlug($record->slug),
            'type'        => $type,
            'description' => mb_substr($record->description, 0, 150),
            'count'       => 0,
            'order'       => 0,
            'parent'      => $parentMid,
        ];

        $mid = $this->insertRow('table.metas', $row);
        if ($mid === 0) {
            return;
        }
        // Taxonomy-qualified key supports SHARED term IDs (the same
        // term_id existing as both a category and a tag); a plain-id key is
        // also kept for sources that don't share IDs (MySQL).
        $this->context->termMap[$this->termMapKey($record)] = $mid;
        $this->context->termMap[$record->sourceId] ??= $mid;
        $this->context->conflicts->reserveTermSlug($row['slug'], $mid);
    }

    /**
     * Key used for the taxonomy-qualified termMap entry.
     */
    private function termMapKey(CategoryRecord $record): string
    {
        return $record->taxonomy . ':' . $record->sourceId;
    }

    private function uniqueMetaSlug(string $slug): string
    {
        $slug = trim($slug);
        if ($slug === '') {
            $slug = 'term-' . bin2hex(random_bytes(4));
        }
        // metas.slug is varchar(150) — leave room for the "-N" suffix.
        $slug = mb_substr($slug, 0, 145);
        $candidate = $slug;
        $i = 2;
        while (true) {
            $existing = $this->db->fetchRow(
                $this->db->select('mid')->from('table.metas')->where('slug = ?', $candidate)->limit(1)
            );
            if (!$existing) {
                return $candidate;
            }
            $candidate = "{$slug}-{$i}";
            $i++;
            if ($i > 1000) {
                return $slug . '-' . bin2hex(random_bytes(4));
            }
        }
    }
}
