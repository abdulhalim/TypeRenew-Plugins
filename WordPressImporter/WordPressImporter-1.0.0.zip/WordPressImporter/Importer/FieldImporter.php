<?php
/**
 * FieldImporter — imports wp_postmeta into TypeRenew `fields` table.
 *
 * Generic mechanism: every non-internal postmeta key (those that don't start
 * with `_`) is imported verbatim. No plugin-specific handling — TypeRenew
 * themes and plugins are free to interpret the field names as they wish.
 *
 * @package WordPressImporter\Importer
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Importer;

use TypechoPlugin\WordPressImporter\Support\ImportContext;
use TypechoPlugin\WordPressImporter\Support\ImportResult;
use TypechoPlugin\WordPressImporter\Support\PostMetaRecord;

final class FieldImporter extends BaseImporter
{
    public function name(): string
    {
        return 'fields';
    }

    public function enabled(ImportContext $context): bool
    {
        return $context->settings->importFields();
    }

    public function estimate(ImportContext $context): int
    {
        $stats = $context->source->statistics();
        return $stats['custom_fields'] ?? 0;
    }

    public function import(ImportContext $context): ImportResult
    {
        $result = new ImportResult();
        $context->progress->startPhase($this->name());
        $context->logger->setPhase($this->name());

        $sourcePostIds = array_keys($context->postMap);
        if ($sourcePostIds === []) {
            $context->logger->warning(
                "هیچ پستی برای ایمپورت فیلدهای سفارشی موجود نیست — این فاز رد شد "
                . '(یا هیچ پستی ایمپورت نشده، یا همه رد شده‌اند)'
            );
            $context->progress->finishPhase($this->name());
            return $result;
        }

        $count = 0;
        foreach ($context->source->streamPostMeta($sourcePostIds) as $sourceId => $record) {
            try {
                $this->importOne($record, $result);
                $result->addImported();
            } catch (\Throwable $e) {
                $result->addFailed(1, "فیلد شمارهٔ {$sourceId}: " . $e->getMessage());
                $context->logger->error("ایمپورت فیلد ناموفق بود", [
                    'source_id' => $sourceId,
                    'key' => $record->key,
                    'error' => $e->getMessage(),
                ]);
            }

            $count++;
            if ($count % $context->chunkSize === 0) {
                $context->progress->advance($this->name(), $context->chunkSize);
            }
        }

        $context->progress->advance($this->name(), $count % $context->chunkSize);
        $context->progress->finishPhase($this->name());
        $context->logger->info("ایمپورت فیلدها تمام شد", ['imported' => $result->imported]);
        $context->logger->flush();

        return $result;
    }

    private function importOne(PostMetaRecord $record, ImportResult $result): void
    {
        $cid = $this->context->postMap[$record->sourcePostId] ?? null;
        if ($cid === null) {
            $result->addSkipped(1, "فیلد رد شد — پست والد آن ایمپورت نشده بود");
            return;
        }

        // Store the key verbatim — no plugin-specific namespacing.
        $key = $record->key;

        // Detect value type
        $value = $record->value;
        $decoded = $this->maybeUnserialize($value);
        $typeStr = 'str';
        $intVal = 0;
        $floatVal = 0.0;
        $strVal = $value;

        if (is_int($decoded)) {
            $typeStr = 'int';
            $intVal = $decoded;
            $strVal = (string) $decoded;
        } elseif (is_float($decoded)) {
            $typeStr = 'float';
            $floatVal = $decoded;
            $strVal = (string) $decoded;
        } elseif (is_array($decoded)) {
            $strVal = json_encode($decoded, JSON_UNESCAPED_UNICODE);
        }

        if ($this->context->dryRun) {
            return;
        }

        try {
            $this->db->query(
                $this->db->insert('table.fields')->rows([
                    'cid'         => $cid,
                    'name'        => $key,
                    'type'        => $typeStr,
                    'str_value'   => mb_substr($strVal, 0, 65535),
                    'int_value'   => $intVal,
                    'float_value' => $floatVal,
                ])
            );
        } catch (\Throwable $e) {
            // duplicate (cid, name) → fall back to update
            try {
                $this->db->query(
                    $this->db->update('table.fields')->rows([
                        'type'        => $typeStr,
                        'str_value'   => mb_substr($strVal, 0, 65535),
                        'int_value'   => $intVal,
                        'float_value' => $floatVal,
                    ])->where('cid = ?', $cid)->where('name = ?', $key)
                );
            } catch (\Throwable $e2) {
                throw $e;
            }
        }
    }

    /**
     * WordPress's maybe_unserialize (re-implemented to avoid the global helper).
     */
    private function maybeUnserialize(string $value): mixed
    {
        if (preg_match('/^[aOsibd]:/', $value)) {
            $unserialized = @unserialize($value, ['allowed_classes' => false]);
            if ($unserialized !== false) {
                return $unserialized;
            }
        }
        // Try as JSON
        $json = json_decode($value, true);
        if (is_array($json)) {
            return $json;
        }
        // Numeric?
        if (preg_match('/^-?\d+$/', $value)) {
            return (int) $value;
        }
        if (is_numeric($value) && str_contains($value, '.')) {
            return (float) $value;
        }
        return $value;
    }
}
