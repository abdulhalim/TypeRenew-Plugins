<?php
/**
 * CommentImporter — imports WordPress comments into TypeRenew comments table.
 *
 * Builds a source→target comment ID map so threaded (parent) relationships
 * survive. Skips comments whose source post was not imported.
 *
 * @package WordPressImporter\Importer
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Importer;

use TypechoPlugin\WordPressImporter\Support\CommentRecord;
use TypechoPlugin\WordPressImporter\Support\ImportContext;
use TypechoPlugin\WordPressImporter\Support\ImportResult;

final class CommentImporter extends BaseImporter
{
    public function name(): string
    {
        return 'comments';
    }

    public function enabled(ImportContext $context): bool
    {
        return $context->settings->importComments();
    }

    public function estimate(ImportContext $context): int
    {
        $stats = $context->source->statistics();
        return $stats['comments'] ?? 0;
    }

    public function import(ImportContext $context): ImportResult
    {
        $result = new ImportResult();
        $context->progress->startPhase($this->name());
        $context->logger->setPhase($this->name());

        $sourcePostIds = array_keys($context->postMap);
        if ($sourcePostIds === []) {
            $context->logger->warning(
                "هیچ پستی برای ایمپورت دیدگاه‌ها موجود نیست — این فاز رد شد "
                . '(یا هیچ پستی ایمپورت نشده، یا همه رد شده‌اند)'
            );
            $context->progress->finishPhase($this->name());
            return $result;
        }

        $count = 0;
        foreach ($context->source->streamComments($sourcePostIds) as $sourceId => $record) {
            try {
                $this->importOne($record, $result);
                $result->addImported();
            } catch (\Throwable $e) {
                $result->addFailed(1, "دیدگاه شمارهٔ {$sourceId}: " . $e->getMessage());
                $context->logger->error("ایمپورت دیدگاه ناموفق بود", [
                    'source_id' => $sourceId,
                    'post_id' => $record->sourcePostId,
                    'error' => $e->getMessage(),
                ]);
            }

            $count++;
            if ($count % $context->chunkSize === 0) {
                $context->progress->advance($this->name(), $context->chunkSize);
            }
        }

        $context->progress->advance($this->name(), $count % $context->chunkSize);
        $context->progress->finishPhase($this->name());
        $context->logger->info("ایمپورت دیدگاه‌ها تمام شد", ['imported' => $result->imported]);
        $context->logger->flush();

        return $result;
    }

    private function importOne(CommentRecord $record, ImportResult $result): void
    {
        // Resolve post cid
        $cid = $this->context->postMap[$record->sourcePostId] ?? null;
        if ($cid === null) {
            $result->addSkipped(1, "دیدگاه شمارهٔ {$record->sourceId} رد شد — پست والد آن ایمپورت نشده بود");
            return;
        }

        // Resolve parent comment
        $parentCoid = 0;
        if ($record->sourceParentId !== null && isset($this->context->commentMap[$record->sourceParentId])) {
            $parentCoid = $this->context->commentMap[$record->sourceParentId];
        }

        // Resolve owner (if comment was by a registered user)
        $ownerId = $this->context->userMap[$record->sourceUserId] ?? 0;

        $status = $this->mapStatus($record->status);
        $type = $record->type;

        $row = [
            'cid'       => $cid,
            'created'   => $record->createdAt,
            'author'    => mb_substr($record->author, 0, 150),
            'ownerId'   => $ownerId,
            'mail'      => mb_substr($record->email, 0, 150),
            'url'       => mb_substr($record->url, 0, 255),
            'ip'        => mb_substr($record->ip, 0, 64),
            'agent'     => mb_substr($record->agent, 0, 200),
            'text'      => $record->content,
            'type'      => $type,
            'status'    => $status,
            'parent'    => $parentCoid,
        ];

        $coid = $this->insertRow('table.comments', $row);
        if ($coid === 0) {
            return;
        }
        $this->context->commentMap[$record->sourceId] = $coid;

        // Bump comment count on post (only if approved)
        // NOTE: raw `?` params can't be passed to Db::query() — use the
        // query builder with ->expression() (TypeRenew core pattern).
        if ($status === 'approved' && !$this->context->dryRun) {
            $this->db->query(
                $this->db->update('table.contents')
                    ->expression('commentsNum', 'commentsNum + 1')
                    ->where('cid = ?', $cid)
            );
        }
    }

    private function mapStatus(string $wpStatus): string
    {
        return match ($wpStatus) {
            'approved' => 'approved',
            'pending'  => 'waiting',
            'spam'     => 'spam',
            'trash'    => 'spam', // map trash to spam — TypeRenew has no trash
            default    => 'approved',
        };
    }
}
