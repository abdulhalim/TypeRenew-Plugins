<?php
/**
 * Importer contract — each domain importer (Author, Category, Post, ...) must
 * implement this so the orchestrator can treat them uniformly.
 *
 * @package WordPressImporter\Contract
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Contract;

use TypechoPlugin\WordPressImporter\Support\ImportContext;
use TypechoPlugin\WordPressImporter\Support\ImportResult;

interface ImporterInterface
{
    /**
     * Unique machine name for this importer (e.g. "authors", "posts").
     */
    public function name(): string;

    /**
     * Whether this importer is enabled for the current run.
     *
     * The orchestrator passes the ImportContext which contains the user's
     * selected checkboxes (Selective Import).
     */
    public function enabled(ImportContext $context): bool;

    /**
     * Estimate total records to process (used by ProgressManager for ETA).
     *
     * May return 0 if the count cannot be cheaply computed.
     */
    public function estimate(ImportContext $context): int;

    /**
     * Run the importer. The source yields records; the importer persists them.
     *
     * Implementations MUST:
     *   - Use chunked inserts via TypeRenew Db API
     *   - Honour the chunk size in $context
     *   - Update ProgressManager after each chunk
     *   - Catch per-record exceptions and forward them to Logger
     *   - Never let one record abort the whole phase
     *
     * @return ImportResult Summary counts for this phase.
     */
    public function import(ImportContext $context): ImportResult;
}
