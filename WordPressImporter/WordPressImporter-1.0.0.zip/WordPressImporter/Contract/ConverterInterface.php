<?php
/**
 * Converter contract — used by ShortcodeConverter and GutenbergConverter.
 *
 * @package WordPressImporter\Contract
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Contract;

interface ConverterInterface
{
    /**
     * Convert a single content string and return the converted version.
     *
     * @param string $content Raw content from WordPress.
     *
     * @return string Converted content (HTML / Markdown / mixed).
     */
    public function convert(string $content): string;

    /**
     * Whether this converter is enabled for the current run.
     */
    public function enabled(): bool;
}
