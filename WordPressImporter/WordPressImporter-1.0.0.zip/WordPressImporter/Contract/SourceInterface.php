<?php
/**
 * Source contract — every importer source (MySQL, WXR, ZIP) must implement this.
 *
 * The contract is split into small methods so that memory can be controlled
 * per-iteration. Sources must NEVER load the entire dataset into memory.
 *
 * @package WordPressImporter\Contract
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Contract;

use Generator;
use TypechoPlugin\WordPressImporter\Support\AuthorRecord;
use TypechoPlugin\WordPressImporter\Support\CategoryRecord;
use TypechoPlugin\WordPressImporter\Support\CommentRecord;
use TypechoPlugin\WordPressImporter\Support\MediaRecord;
use TypechoPlugin\WordPressImporter\Support\MenuItemRecord;
use TypechoPlugin\WordPressImporter\Support\PostRecord;
use TypechoPlugin\WordPressImporter\Support\PostMetaRecord;

interface SourceInterface
{
    /**
     * Validate that the source can be read. Called during the Validation step.
     *
     * @return list<string> List of warning messages (empty when fully healthy).
     *
     * @throws \TypechoPlugin\WordPressImporter\Exception\SourceException When the source is unreachable / unreadable.
     */
    public function validate(): array;

    /**
     * Stream users/authors from the source, one at a time.
     *
     * @return Generator<int, AuthorRecord>
     */
    public function streamUsers(): Generator;

    /**
     * Stream categories and tags (taxonomy terms) from the source.
     *
     * @return Generator<int, CategoryRecord>
     */
    public function streamTerms(): Generator;

    /**
     * Stream posts and pages. `$type` may be 'post', 'page', or a custom
     * post type slug.
     *
     * @param list<string> $types
     *
     * @return Generator<int, PostRecord>
     */
    public function streamPosts(array $types = ['post', 'page']): Generator;

    /**
     * Stream media attachments. Implementations should be lazy — only fetch
     * rows for posts that are actually going to be imported.
     *
     * @return Generator<int, MediaRecord>
     */
    public function streamMedia(): Generator;

    /**
     * Stream comments for posts that have been imported.
     *
     * @param list<int> $sourcePostIds Source-side post IDs to filter by.
     *
     * @return Generator<int, CommentRecord>
     */
    public function streamComments(array $sourcePostIds): Generator;

    /**
     * Stream post meta for posts that have been imported.
     *
     * @param list<int> $sourcePostIds
     *
     * @return Generator<int, PostMetaRecord>
     */
    public function streamPostMeta(array $sourcePostIds): Generator;

    /**
     * Stream navigation menu items.
     *
     * @return Generator<int, MenuItemRecord>
     */
    public function streamMenuItems(): Generator;

    /**
     * Aggregate statistics for the Preview step, without actually importing.
     *
     * @return array{
     *     posts:int,
     *     pages:int,
     *     media:int,
     *     comments:int,
     *     users:int,
     *     categories:int,
     *     tags:int,
     *     menus:int,
     *     custom_fields:int
     * }
     */
    public function statistics(): array;

    /**
     * Release any open resources (DB handle, file pointers, XMLReader).
     */
    public function close(): void;
}
