<?php
/**
 * Action — AJAX endpoint dispatcher for the WordPress Importer wizard.
 *
 * Routed via TypeRenew's `/action/wordpress-importer` URL.
 *
 * In TypeRenew, registered action widgets must extend `Typecho\Widget` and
 * implement `Widget\ActionInterface` (the dispatcher instantiates the widget
 * and calls its `action()` method). This class therefore extends Widget and
 * exposes the public entry point as `action()` (which delegates to
 * `execute()` for backwards-compatibility with internal callers).
 *
 * Every request MUST:
 *   - Be made by an administrator (Plugin::guardAdministrator)
 *   - Carry a valid nonce (CSRF protection)
 *   - Specify an `op` parameter
 *
 * Response shape (JSON):
 *   { ok: bool, data?: mixed, error?: string, logs?: array }
 *
 * @package WordPressImporter
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter;

use Typecho\Widget;
use Widget\ActionInterface;
use Widget\Options;
use TypechoPlugin\WordPressImporter\Exception\ImporterException;
use TypechoPlugin\WordPressImporter\Importer\Importer;
use TypechoPlugin\WordPressImporter\Source\SourceFactory;
use TypechoPlugin\WordPressImporter\Support\Logger;
use TypechoPlugin\WordPressImporter\Support\ProgressManager;
use TypechoPlugin\WordPressImporter\Support\SettingsManager;
use TypechoPlugin\WordPressImporter\Support\StateManager;
use TypechoPlugin\WordPressImporter\Support\Validator;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * Handles incoming AJAX requests and emits a JSON response.
 */
final class Action extends Widget implements ActionInterface
{
    /**
     * Canonical nonce field name carried by every request.
     *
     * NOTE: the JS wizard sends the nonce under the short key `nonce` (see
     * assets/js/wizard.js — api() and apiUpload()). verifyNonce() therefore
     * accepts BOTH the canonical long name and the short `nonce` key, so the
     * front-end and any external integration keep working regardless of
     * which name they use.
     */
    private const NONCE_NAME = 'wordpress_importer_nonce';
    private const NONCE_NAME_SHORT = 'nonce';

    /** @var array<string, mixed> */
    private array $params;

    /**
     * Entry point required by TypeRenew's action dispatcher.
     *
     * The dispatcher in Widget\Action::action() does:
     *   $widget = self::widget($widgetName);
     *   if ($widget instanceof ActionInterface) { $widget->action(); }
     *
     * So we MUST expose the entry point as `action()` — not `execute()`.
     *
     * Note: parent ActionInterface::action() has no return type declaration,
     * so we omit it here too for compatibility.
     */
    public function action()
    {
        $this->execute();
    }

    /**
     * Internal dispatch. Originally called `execute()`; kept as-is so existing
     * test/integration code that calls `$action->execute()` still works.
     *
     * Note: parent Widget::execute() has no return type declaration (mixed
     * covariance). We declare `: void` here which is a valid narrowing.
     */
    public function execute(): void
    {
        try {
            Plugin::guardAdministrator();

            // Detect the silent "post too large" failure BEFORE nonce check,
            // but ONLY for form submissions (multipart/form-data or
            // application/x-www-form-urlencoded). JSON requests send their
            // body via php://input, so $_POST and $_FILES are legitimately
            // empty for those — that's not an error.
            $contentType = (string) ($_SERVER['CONTENT_TYPE'] ?? '');
            $isFormPost  = str_starts_with($contentType, 'multipart/form-data')
                        || str_starts_with($contentType, 'application/x-www-form-urlencoded');
            $contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
            if ($isFormPost && $contentLength > 0 && empty($_POST) && empty($_FILES)) {
                $postMax = ini_get('post_max_size') ?: 'unknown';
                $uploadMax = ini_get('upload_max_filesize') ?: 'unknown';
                throw new ImporterException(sprintf(
                    'حجم درخواست بیشتر از حد مجاز PHP است (post_max_size = %s). '
                    . 'فایل شما احتمالاً بیش از %s است. '
                    . 'لطفاً فایل کوچک‌تری آپلود کنید یا مقادیر زیر را در php.ini افزایش دهید: '
                    . 'post_max_size و upload_max_filesize (currently %s).',
                    $postMax,
                    $postMax,
                    $uploadMax
                ));
            }

            $this->params = $this->collectParams();
            $this->verifyNonce();

            $op = (string) ($this->params['op'] ?? '');
            $response = match ($op) {
                'save_settings'    => $this->handleSaveSettings(),
                'validate'         => $this->handleValidate(),
                'preview'          => $this->handlePreview(),
                'start_import'     => $this->handleStartImport(),
                'continue_import'  => $this->handleContinueImport(),
                'progress'         => $this->handleProgress(),
                'rollback'         => $this->handleRollback(),
                'discard_snapshot' => $this->handleDiscardSnapshot(),
                'report'           => $this->handleReport(),
                'reset_state'      => $this->handleResetState(),
                'upload_wxr'       => $this->handleUploadWxr(),
                'upload_zip'       => $this->handleUploadZip(),
                default            => throw new ImporterException("عملیات ناشناخته: {$op}"),
            };

            $this->json($response);
        } catch (\Throwable $e) {
            $this->json([
                'ok' => false,
                'error' => $e->getMessage(),
                'code' => $e->getCode(),
            ], 500);
        }
    }

    /* ----- handlers ----- */

    /**
     * Persist per-run settings into StateManager.
     */
    private function handleSaveSettings(): array
    {
        $settings = new SettingsManager();
        $payload = (array) ($this->params['settings'] ?? []);
        // Whitelist keys (only what's relevant to the minimal importer).
        $clean = [
            'source_kind'      => (string) ($payload['source_kind'] ?? 'mysql'),
            'mode'             => (string) ($payload['mode'] ?? 'keep'),
            'dry_run'          => (bool) ($payload['dry_run'] ?? false),
            'chunk_size'       => (int) ($payload['chunk_size'] ?? 100),
            'media_strategy'   => (string) ($payload['media_strategy'] ?? 'download'),
            'features'         => (array) ($payload['features'] ?? []),
            'clean_confirmed'  => (bool) ($payload['clean_confirmed'] ?? false),
            'mysql'            => $this->sanitizeMysql((array) ($payload['mysql'] ?? [])),
            'wxr_path'         => (string) ($payload['wxr_path'] ?? ''),
            'zip_path'         => (string) ($payload['zip_path'] ?? ''),
        ];
        $settings->replace($clean);

        return ['ok' => true, 'data' => $settings->all()];
    }

    private function handleValidate(): array
    {
        $settings = new SettingsManager();
        $validator = new Validator();

        // Requirements are conditional on the selected source kind (e.g. a
        // WXR import must not fail because pdo_mysql is missing).
        $validator->validateEnvironment($settings->sourceKind());
        match ($settings->sourceKind()) {
            'mysql' => $validator->validateMysql($settings->mysqlConfig()),
            'wxr'   => $validator->validateWxr((string) $settings->wxrPath()),
            'zip'   => $validator->validateZip((string) $settings->zipPath()),
            default => null,
        };

        $result = $validator->result();
        return ['ok' => $result['ok'], 'data' => $result];
    }

    private function handlePreview(): array
    {
        $settings = new SettingsManager();
        $source = SourceFactory::make($settings);
        try {
            $stats = $source->statistics();
            return ['ok' => true, 'data' => $stats];
        } finally {
            $source->close();
        }
    }

    /**
     * Start a new import run. Generates run_id, then runs the orchestrator
     * synchronously — in a real chunked environment, the JS wizard would
     * call start_import once, then poll `progress` repeatedly until done.
     *
     * For very large sites, start_import returns immediately after creating
     * the run state, and a background continue_import mechanism (cron or
     * a queue worker) advances the import.
     *
     * In this implementation, we run the import inline within the same
     * request, but chunked internally by source generators. Browsers
     * see it as one long request; progress() polls the persisted state
     * table which is updated continuously.
     */
    private function handleStartImport(): array
    {
        $runId = date('Ymd-His') . '-' . bin2hex(random_bytes(4));
        $settings = new SettingsManager();
        $logger = new Logger('orchestrator');
        $progress = new ProgressManager();
        $progress->reset();
        $logger->clear();

        $importer = new Importer($settings, $logger, $progress);
        $result = $importer->run($runId);
        $logger->flush();

        return [
            'ok' => true,
            'data' => [
                'run_id' => $runId,
                'result' => $result->toArray(),
                'dry_run' => $settings->dryRun(),
                'snapshot_taken' => StateManager::get('last_snapshot_taken', false),
            ],
        ];
    }

    /**
     * Resume an interrupted import (placeholder — full implementation requires
     * a job queue. The current architecture already persists progress across
     * requests, so this endpoint can be wired to a cron job later.)
     */
    private function handleContinueImport(): array
    {
        return ['ok' => true, 'data' => ['message' => 'ادامهٔ ایمپورت از طریق پردازش تکه‌ای درون همان درخواست مدیریت می‌شود.']];
    }

    private function handleProgress(): array
    {
        $progress = new ProgressManager();
        $logger = new Logger();
        $counts = $logger->counts();
        $tail = $logger->tail(20);

        return [
            'ok' => true,
            'data' => [
                'progress' => $progress->snapshot(),
                'log_counts' => $counts,
                'log_tail' => $tail,
                'last_run' => [
                    'id' => StateManager::get('last_run_id'),
                    'status' => StateManager::get('last_run_status'),
                    'dry_run' => (bool) StateManager::get('last_run_dry_run', false),
                    'started_at' => StateManager::get('last_run_started_at'),
                    'finished_at' => StateManager::get('last_run_finished_at'),
                    'snapshot_taken' => StateManager::get('last_snapshot_taken', false),
                    'result' => StateManager::get('last_run_result'),
                    'error' => StateManager::get('last_run_error'),
                ],
            ],
        ];
    }

    private function handleRollback(): array
    {
        $settings = new SettingsManager();
        $logger = new Logger('rollback');
        $progress = new ProgressManager();
        $importer = new Importer($settings, $logger, $progress);
        $importer->rollback();
        return ['ok' => true];
    }

    private function handleDiscardSnapshot(): array
    {
        $settings = new SettingsManager();
        $logger = new Logger('rollback');
        $progress = new ProgressManager();
        $importer = new Importer($settings, $logger, $progress);
        $importer->discardSnapshot();
        return ['ok' => true];
    }

    private function handleReport(): array
    {
        $logger = new Logger();
        $text = $logger->exportText();

        // A dry-run report MUST be unmistakable — prepend a banner so the
        // user never mistakes a simulation for a real import.
        if ((bool) StateManager::get('last_run_dry_run', false)) {
            $banner = PHP_EOL
                . '⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠' . PHP_EOL
                . '⚠️  توجه: آخرین اجرا در «حالت آزمایشی (Dry-Run)» انجام شده است.' . PHP_EOL
                . '⚠️  هیچ داده‌ای در دیتابیس نوشته نشده و سایت تغییر نکرده است!' . PHP_EOL
                . '⚠️  برای ایمپورت واقعی: در مرحلهٔ ۱ ویزارد گزینهٔ «حالت Dry-Run» را' . PHP_EOL
                . '⚠️  غیرفعال کنید و ایمپورت را دوباره اجرا کنید.' . PHP_EOL
                . '⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠⚠' . PHP_EOL;
            $text = $banner . $text;
        }

        // Stream as a downloadable .log file
        $options = Options::alloc();
        $filename = 'wordpress-importer-report-' . date('Ymd-His') . '.log';

        header('Content-Type: text/plain; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($text));
        echo $text;
        exit;
    }

    private function handleResetState(): array
    {
        StateManager::purge();
        return ['ok' => true];
    }

    private function handleUploadWxr(): array
    {
        return $this->handleUpload(['xml', 'wxr']);
    }

    private function handleUploadZip(): array
    {
        return $this->handleUpload(['zip']);
    }

    /* ----- helpers ----- */

    /**
     * Collect request parameters from either POST body JSON or form data.
     *
     * @return array<string, mixed>
     */
    private function collectParams(): array
    {
        // Some SAPIs expose the header only as HTTP_CONTENT_TYPE.
        $contentType = (string) ($_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? '');
        $raw = file_get_contents('php://input');
        if ($raw && str_starts_with($contentType, 'application/json')) {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                return array_merge($_GET, $_POST, $decoded);
            }
        }
        return array_merge($_GET, $_POST);
    }

    private function verifyNonce(): void
    {
        // Accept both the canonical long key and the short `nonce` key used
        // by the wizard's fetch()/XHR payloads. GET parameters are merged
        // into $this->params too, so the report download link works as well.
        $nonce = (string) ($this->params[self::NONCE_NAME] ?? $this->params[self::NONCE_NAME_SHORT] ?? '');
        $expected = $this->sessionNonce();
        if ($nonce === '' || !hash_equals($expected, $nonce)) {
            throw new ImporterException(
                'Nonce نامعتبر یا گم‌شده است. صفحه را رفرش کنید و دوباره تلاش کنید. '
                . 'اگر خطا تکرار شد، احتمالاً جدول state افزونه در دسترس نیست — افزونه را یک بار غیرفعال و دوباره فعال کنید.'
            );
        }
    }

    /**
     * Generate (and persist) a per-session nonce. Stored in StateManager so
     * it survives across AJAX requests.
     */
    public static function issueNonce(): string
    {
        $existing = (string) (StateManager::get('nonce') ?? '');
        $issuedAt = (int) (StateManager::get('nonce_issued_at') ?? 0);
        // Refresh nonce every hour
        if ($existing !== '' && (time() - $issuedAt) < 3600) {
            return $existing;
        }
        $new = bin2hex(random_bytes(16));
        StateManager::set('nonce', $new);
        StateManager::set('nonce_issued_at', time());
        return $new;
    }

    private function sessionNonce(): string
    {
        return (string) (StateManager::get('nonce') ?? '');
    }

    private function sanitizeMysql(array $cfg): array
    {
        return [
            'host'     => (string) ($cfg['host'] ?? 'localhost'),
            'port'     => (int) ($cfg['port'] ?? 3306),
            'user'     => (string) ($cfg['user'] ?? ''),
            'password' => (string) ($cfg['password'] ?? ''),
            'database' => (string) ($cfg['database'] ?? ''),
            'prefix'   => (string) ($cfg['prefix'] ?? 'wp_'),
            'abspath'  => (string) ($cfg['abspath'] ?? ''),
        ];
    }

    /**
     * Handle a multipart file upload and move it to the plugin's uploads dir.
     *
     * Detects common PHP upload failure modes and returns human-readable
     * Persian error messages. Specifically handles the silent "post too large"
     * case where PHP discards the entire request body when Content-Length
     * exceeds post_max_size — in that case $_POST and $_FILES are both empty
     * but CONTENT_LENGTH is non-zero.
     *
     * @param list<string> $allowedExts
     */
    private function handleUpload(array $allowedExts): array
    {
        // Detect the "post too large" silent failure BEFORE nonce check.
        // When post_max_size is exceeded, PHP empties $_POST and $_FILES,
        // which would cause the nonce check above to fail with a confusing
        // "Invalid nonce" error. Catch the real cause here.
        $contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
        if ($contentLength > 0 && empty($_POST) && empty($_FILES)) {
            $postMax = ini_get('post_max_size') ?: 'unknown';
            $uploadMax = ini_get('upload_max_filesize') ?: 'unknown';
            throw new ImporterException(sprintf(
                'حجم درخواست بیشتر از حد مجاز PHP است (post_max_size = %s). فایل شما احتمالاً بیش از %s است. لطفاً فایل کوچک‌تری آپلود کنید یا php.ini را افزایش دهید (همچنین upload_max_filesize = %s).',
                $postMax,
                $postMax,
                $uploadMax
            ));
        }

        if (empty($_FILES['file'])) {
            throw new ImporterException('هیچ فایلی آپلود نشد. لطفاً یک فایل انتخاب کنید.');
        }

        $file = $_FILES['file'];
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new ImporterException($this->uploadErrorMessage((int) $file['error']));
        }

        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowedExts, true)) {
            throw new ImporterException(sprintf(
                'پسوند فایل مجاز نیست: %s. فقط فایل‌های %s پذیرفته می‌شوند.',
                htmlspecialchars($ext),
                implode(' یا ', $allowedExts)
            ));
        }

        $uploadsDir = Plugin::path() . '/uploads';
        if (!is_dir($uploadsDir)) {
            @mkdir($uploadsDir, 0775, true);
        }
        $target = $uploadsDir . '/' . bin2hex(random_bytes(8)) . '.' . $ext;
        if (!move_uploaded_file($file['tmp_name'], $target)) {
            throw new ImporterException('انتقال فایل آپلودشده به مسیر نهایی ناموفق بود. مجوز پوشهٔ uploads را بررسی کنید.');
        }

        return ['ok' => true, 'data' => ['path' => $target, 'size' => filesize($target)]];
    }

    /**
     * Translate PHP upload error codes to human-readable Persian messages.
     */
    private function uploadErrorMessage(int $code): string
    {
        $uploadMax = ini_get('upload_max_filesize') ?: 'نامشخص';
        $postMax = ini_get('post_max_size') ?: 'نامشخص';
        $memoryLimit = ini_get('memory_limit') ?: 'نامشخص';

        return match ($code) {
            UPLOAD_ERR_INI_SIZE   => sprintf(
                'حجم فایل بیشتر از upload_max_filesize (= %s) در php.ini است. فایل کوچک‌تر آپلود کنید یا php.ini را ویرایش کنید.',
                $uploadMax
            ),
            UPLOAD_ERR_FORM_SIZE  => 'حجم فایل بیشتر از حد تعیین‌شده در فرم است.',
            UPLOAD_ERR_PARTIAL    => 'فایل فقط به‌صورت جزئی آپلود شد. لطفاً دوباره تلاش کنید (احتمالاً قطعی شبکه).',
            UPLOAD_ERR_NO_FILE    => 'هیچ فایلی آپلود نشد.',
            UPLOAD_ERR_NO_TMP_DIR => 'پوشهٔ موقت PHP موجود نیست. با مدیر سرور تماس بگیرید.',
            UPLOAD_ERR_CANT_WRITE => 'PHP نتوانست فایل را روی دیسک بنویسد. مجوز پوشهٔ موقت را بررسی کنید.',
            UPLOAD_ERR_EXTENSION  => 'یک افزونهٔ PHP آپلود را متوقف کرد.',
            default               => sprintf(
                'خطای ناشناختهٔ آپلود (کد %d). post_max_size = %s، memory_limit = %s.',
                $code,
                $postMax,
                $memoryLimit
            ),
        };
    }

    /**
     * Emit a JSON response.
     *
     * @param array<string, mixed> $data
     */
    private function json(array $data, int $status = 200): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
}
