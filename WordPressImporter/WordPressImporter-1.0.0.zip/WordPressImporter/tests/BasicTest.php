<?php
/**
 * Unit test stub.
 *
 * This file bootstraps a test environment for the WordPress Importer plugin.
 * It does NOT contain full PHPUnit tests yet — the architecture is unit-test
 * ready (every dependency is injected, every class has a single responsibility),
 * but writing tests requires either:
 *   - A real TypeRenew install with a test database, OR
 *   - A mock of Typecho\Db and Typecho\Widget that doesn't exist yet.
 *
 * To run:
 *   composer install
 *   vendor/bin/phpunit
 *
 * @package WordPressImporter\Test
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Test;

use PHPUnit\Framework\TestCase;
use TypechoPlugin\WordPressImporter\Converter\ShortcodeConverter;
use TypechoPlugin\WordPressImporter\Converter\GutenbergConverter;
use TypechoPlugin\WordPressImporter\Support\ImportResult;

final class BasicTest extends TestCase
{
    public function test_short_code_gallery(): void
    {
        $conv = new ShortcodeConverter(true);
        $out = $conv->convert('[gallery ids="1,2,3" columns="2"]');
        $this->assertStringContainsString('<figure class="wp-gallery"', $out);
        $this->assertStringContainsString('data-columns="2"', $out);
        $this->assertStringContainsString('attachment:1', $out);
    }

    public function test_short_code_caption(): void
    {
        $conv = new ShortcodeConverter(true);
        $out = $conv->convert('[caption id="attachment_42" align="aligncenter" width="640"]<img src="x.jpg"/>My Caption[/caption]');
        $this->assertStringContainsString('<figure class="wp-caption aligncenter"', $out);
        $this->assertStringContainsString('My Caption</figcaption>', $out);
    }

    public function test_short_code_youtube(): void
    {
        $conv = new ShortcodeConverter(true);
        $out = $conv->convert('[embed]https://www.youtube.com/watch?v=dQw4w9WgXcQ[/embed]');
        $this->assertStringContainsString('youtube.com/embed/dQw4w9WgXcQ', $out);
        $this->assertStringContainsString('<iframe', $out);
    }

    public function test_short_code_unknown_preserved_in_comment(): void
    {
        $conv = new ShortcodeConverter(true);
        $out = $conv->convert('[my_custom_shortcode foo="bar"]');
        $this->assertStringContainsString('<!-- unknown shortcode', $out);
        $this->assertStringContainsString('my_custom_shortcode', $out);
    }

    public function test_gutenberg_strips_delimiters(): void
    {
        $conv = new GutenbergConverter(true);
        $in = "<!-- wp:paragraph {\"align\":\"center\"} -->\n<p class=\"has-text-align-center\">Hello</p>\n<!-- /wp:paragraph -->";
        $out = $conv->convert($in);
        $this->assertStringNotContainsString('wp:paragraph', $out);
        $this->assertStringContainsString('<p class="has-text-align-center">Hello</p>', $out);
    }

    public function test_gutenberg_self_closing_separator(): void
    {
        $conv = new GutenbergConverter(true);
        $out = $conv->convert('<!-- wp:separator /-->');
        $this->assertStringContainsString('<hr', $out);
    }

    public function test_import_result_merging(): void
    {
        $a = new ImportResult();
        $a->addImported(5);
        $a->addFailed(2, 'oops');

        $b = new ImportResult();
        $b->addImported(3);
        $b->addSkipped(1, 'dup');

        $a->merge($b);
        $this->assertSame(8, $a->imported);
        $this->assertSame(2, $a->failed);
        $this->assertSame(1, $a->skipped);
        $this->assertSame(11, $a->total);
    }
}
