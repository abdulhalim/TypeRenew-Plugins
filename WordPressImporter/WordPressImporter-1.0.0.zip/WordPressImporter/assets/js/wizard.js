/**
 * WordPress Importer for TypeRenew — wizard SPA (Persian / RTL)
 *
 * A tiny vanilla-JS single-page-app that drives the 6-step import wizard.
 * No build step, no framework. State is held in `state`; UI is re-rendered
 * from `render()` whenever state changes.
 *
 * All UI strings are in Persian (Farsi). The HTML shell sets dir="rtl".
 *
 * Public API: window.WP_IMPORTER (the boot object).
 */

(function () {
    'use strict';

    const boot = window.WP_IMPORTER_BOOT || {};

    /* ====================================================== */
    /* Translations (Persian)                                 */
    /* ====================================================== */

    const t = {
        // Stepper
        step1: 'اتصال',
        step2: 'بررسی',
        step3: 'پیش‌نمایش',
        step4: 'ایمپورت',
        step5: 'تأیید',
        step6: 'گزارش',

        // Header (panel header is rendered by TypeRenew — no JS title needed)
        pluginTitle: 'واردکنندهٔ وردپرس',
        pluginSubtitle: 'برای TypeRenew',

        // Step 1 — Connection
        step1Title: 'مرحلهٔ ۱ — اتصال',
        step1Desc: 'نحوهٔ دسترسی به داده‌های وردپرس را انتخاب کنید: اتصال مستقیم به MySQL، فایل XML خروجی WXR، یا یک بستهٔ ZIP شامل WXR + رسانه.',
        sourceMysql: 'اتصال مستقیم MySQL',
        sourceMysqlDesc: 'اتصال مستقیم به دیتابیس وردپرس از طریق TCP. نیاز به دسترسی شبکه دارد.',
        sourceWxr: 'فایل WXR (XML)',
        sourceWxrDesc: 'آپلود فایل خروجی XML وردپرس. بدون نیاز به دسترسی DB کار می‌کند.',
        sourceZip: 'بستهٔ ZIP',
        sourceZipDesc: 'آپلود ZIP شامل WXR + پوشهٔ رسانه‌های آپلود شده.',

        // MySQL config
        mysqlTitle: 'اطلاعات اتصال MySQL',
        host: 'میزبان (Host)',
        port: 'پورت',
        user: 'نام کاربری',
        password: 'رمز عبور',
        database: 'پایگاه داده',
        tablePrefix: 'پیشوند جداول',
        wpAbspath: 'مسیر ریشه وردپرس (اختیاری، برای کپی رسانه)',
        wpAbspathHint: 'فقط وقتی استراتژی رسانه «کپی از مسیر محلی» باشد لازم می‌شود.',

        // WXR / ZIP
        wxrTitle: 'فایل WXR',
        zipTitle: 'بستهٔ ZIP',
        selectedFile: 'فایل انتخاب‌شده: ',

        // Mode
        modeTitle: 'حالت ایمپورت',
        modeKeep: 'حفظ داده‌های موجود',
        modeKeepDesc: 'امن‌ترین. رکوردهای وردپرس که slug یا ایمیل تکراری دارند را رد می‌کند.',
        modeMerge: 'ادغام داده‌ها',
        modeMergeDesc: 'به‌روزرسانی رکوردهای موجود با داده‌های وردپرس. رکوردهای موجود در TypeRenew که در وردپرس نیستند را نگه می‌دارد.',
        modeClean: 'ایمپورت تمیز (حذفی)',
        modeCleanDesc: '⚠️ همهٔ محتوای موجود TypeRenew را قبل از ایمپورت حذف می‌کند. نیاز به تأیید مضاعف دارد.',
        modeCleanConfirm: 'تأیید می‌کنم که این کار همهٔ محتوای موجود TypeRenew را حذف خواهد کرد. کلمهٔ «DELETE» را در زیر تایپ کنید تا تأیید شود.',
        modeCleanPlaceholder: 'برای تأیید، DELETE را تایپ کنید',

        // Selective import
        selectiveTitle: 'ایمپورت انتخابی',
        featAuthors: 'نویسندگان / کاربران',
        featMedia: 'رسانه‌ها / پیوست‌ها',
        featComments: 'نظرات',
        featMenus: 'منوهای ناوبری',
        featFields: 'فیلدهای سفارشی',
        featShortcode: 'تبدیل شورت‌کدها',
        featGutenberg: 'تبدیل بلوک‌های گوتنبرگ',
        featRollback: 'اسنپ‌شات پیش از ایمپورت',

        // Other options
        chunkSize: 'اندازهٔ دسته (ردیف در هر batch)',
        mediaStrategy: 'استراتژی رسانه',
        mediaCopy: 'کپی از مسیر محلی وردپرس',
        mediaDownload: 'دانلود از URL',
        mediaSkip: 'رد کردن (حفظ URLهای وردپرس)',
        dryRun: 'حالت Dry-Run (همه چیز را بررسی کن، چیزی ننویس)',
        dryRunWarn: '⚠️ حالت آزمایشی فعال است: با این اجرا هیچ داده‌ای در دیتابیس نوشته نخواهد شد — فقط بررسی و شمارش انجام می‌شود.',
        dryRunDoneTitle: 'این یک اجرای آزمایشی (Dry-Run) بود',
        dryRunDoneDesc: 'هیچ داده‌ای در دیتابیس نوشته نشده و سایت تغییر نکرده است. برای ایمپورت واقعی، دکمهٔ زیر را بزنید:',
        runForReal: 'اجرای واقعی ایمپورت (غیرفعال‌کردن Dry-Run)',
        runForRealBusy: 'در حال ذخیرهٔ تنظیمات و اجرای واقعی…',

        // Buttons
        saveContinue: 'ذخیره و ادامه ←',
        saving: 'در حال ذخیره…',
        saveSettings: 'ذخیره تنظیمات',
        back: '→ بازگشت',
        runValidation: 'اجرای بررسی',
        rerunValidation: 'اجرای مجدد بررسی',
        continueToPreview: 'ادامه به پیش‌نمایش ←',
        runPreview: 'اجرای پیش‌نمایش',
        refreshPreview: 'به‌روزرسانی پیش‌نمایش',
        continueToImport: 'ادامه به ایمپورت ←',
        startDryRun: 'شروع Dry-Run',
        startImport: 'شروع ایمپورت',
        importing: 'در حال ایمپورت…',
        continueToVerification: 'ادامه به تأیید ←',
        continueToReport: 'ادامه به گزارش ←',
        rollback: 'برگشت ایمپورت',
        discardSnapshot: 'حذف اسنپ‌شات',
        downloadReport: 'دانلود گزارش (.log)',
        resetState: 'ریست همهٔ وضعیت',

        // Validation
        step2Title: 'مرحلهٔ ۲ — بررسی',
        step2Desc: 'بررسی محیط و منبع قبل از دست زدن به هیچ داده‌ای.',
        validating: 'در حال بررسی…',
        noValidationYet: 'هنوز بررسی انجام نشده است.',
        allChecksPassed: 'همهٔ بررسی‌های اصلی با موفقیت انجام شد.',

        // Preview
        step3Title: 'مرحلهٔ ۳ — پیش‌نمایش',
        step3Desc: 'خلاصه‌ای از آنچه ایمپورت خواهد شد. هیچ داده‌ای نوشته نمی‌شود.',
        counting: 'در حال شمارش رکوردهای منبع…',
        statPosts: 'نوشته‌ها',
        statPages: 'صفحات',
        statMedia: 'رسانه',
        statComments: 'نظرات',
        statUsers: 'کاربران',
        statCategories: 'دسته‌ها',
        statTags: 'برچسب‌ها',
        statMenus: 'منوها',
        statCustomFields: 'فیلدهای سفارشی',

        // Import
        step4Title: 'مرحلهٔ ۴ — ایمپورت',
        step4Desc: 'آمادهٔ ایمپورت. یک اسنپ‌شات پیش از ایمپورت تهیه می‌شود تا بتوانید بعداً برگردانید.',
        importCompleted: 'ایمپورت کامل شد. مراحل تأیید و گزارش را ببینید.',

        // Progress
        phase: 'مرحله',
        records: 'رکورد',
        speed: 'سرعت',
        eta: 'زمان باقی‌مانده',
        memory: 'حافظه',
        liveLog: 'لاگ زنده',
        noLogsYet: 'هنوز هیچ رویدادی ثبت نشده است.',

        // Verification
        step5Title: 'مرحلهٔ ۵ — تأیید',
        step5Desc: 'داده‌های ایمپورت‌شده را بررسی کنید یا به وضعیت پیش از ایمپورت برگردانید.',
        statImported: 'ایمپورت شد',
        statSkipped: 'رد شد',
        statFailed: 'ناموفق',
        statDuplicates: 'تکراری',
        snapshotWarning: 'یک اسنپ‌شات پیش از ایمپورت تهیه شده است. می‌توانید در هر زمان کل ایمپورت را برگردانید. وقتی اسنپ‌شات را حذف کنید، دیگر امکان برگشت وجود نخواهد داشت.',

        // Report
        step6Title: 'مرحلهٔ ۶ — گزارش',
        step6Desc: 'گزارش کامل لاگ ایمپورت را برای آرشیو خود دانلود کنید.',
        statTotalEvents: 'کل رویدادها',
        statWarnings: 'هشدارها',
        statErrors: 'خطاها',
        statCritical: 'بحرانی',

        // Confirmations
        confirmRollback: 'برگشت کل ایمپورت؟ این کار همهٔ محتوای TypeRenew را به وضعیت پیش از ایمپورت باز می‌گرداند.',
        rollbackDone: 'برگشت با موفقیت انجام شد.',
        confirmDiscard: 'حذف اسنپ‌شات پیش از ایمپورت؟ دیگر امکان برگشت وجود نخواهد داشت.',
        discardDone: 'اسنپ‌شات حذف شد.',
        confirmReset: 'ریست همهٔ وضعیت ایمپورت؟ این کار تنظیمات، پیشرفت و لاگ‌ها را پاک می‌کند. اسنپ‌شات‌ها برای ایمنی نگه داشته می‌شوند.',
        resetDone: 'وضعیت ریست شد.',

        // Errors
        errorInvalidJson: 'پاسخ سرور نامعتبر است (احتمالاً خطای PHP). لاگ خطای سرور را بررسی کنید.',
        errorRequestFailed: 'درخواست ناموفق بود (احتمالاً قطعی شبکه یا timeout).',
        errorNoFile: 'هیچ فایلی آپلود نشد.',
        errorUploadFailed: 'آپلود ناموفق بود',
        uploadingFile: 'در حال آپلود فایل…',
        uploadComplete: 'آپلود کامل شد',
    };

    const state = {
        step: 1,
        busy: false,
        error: null,
        upload: { active: false, progress: 0, fileName: '', size: 0 },
        settings: Object.assign({
            source_kind: 'mysql',
            mode: 'keep',
            dry_run: false,
            chunk_size: 100,
            media_strategy: 'download',
            features: { authors: true, media: true, comments: true, fields: true, menus: false, gutenberg: true, shortcode: true, rollback: true },
            clean_confirmed: false,
            mysql: { host: 'localhost', port: 3306, user: '', password: '', database: '', prefix: 'wp_', abspath: '' },
            wxr_path: '',
            zip_path: '',
        }, boot.saved || {}),
        validation: null,
        preview: null,
        importResult: null,
        importError: false,
        lastRunWasDryRun: !!(boot.last_run && boot.last_run.dry_run),
        progress: null,
        logs: [],
        logCounts: {},
        lastRun: boot.last_run || null,
    };

    const STEPS = [
        { id: 1, label: t.step1 },
        { id: 2, label: t.step2 },
        { id: 3, label: t.step3 },
        { id: 4, label: t.step4 },
        { id: 5, label: t.step5 },
        { id: 6, label: t.step6 },
    ];

    /* ====================================================== */
    /* API                                                    */
    /* ====================================================== */

    /**
     * The nonce field name MUST match Action::NONCE_NAME in PHP
     * ('wordpress_importer_nonce'). The PHP side also accepts the short
     * 'nonce' key for backwards compatibility, but we send the canonical
     * name so the contract is unambiguous.
     */
    const NONCE_KEY = 'wordpress_importer_nonce';

    async function api(op, payload = {}) {
        state.busy = true;
        render();
        try {
            const body = Object.assign({ op, [NONCE_KEY]: boot.nonce }, payload);
            const res = await fetch(boot.ajaxUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
                credentials: 'same-origin',
            });
            const data = await res.json().catch(() => ({ ok: false, error: t.errorInvalidJson }));
            if (!data.ok) {
                throw new Error(data.error || t.errorRequestFailed);
            }
            return data.data;
        } finally {
            state.busy = false;
            render();
        }
    }

    /**
     * Convert PHP size shorthand (e.g. "128M", "1G", "256K") to bytes.
     */
    function phpSizeToBytes(s) {
        if (!s) return 0;
        s = String(s).trim();
        const m = s.match(/^(\d+)([KMG]?)$/i);
        if (!m) return 0;
        const n = parseInt(m[1], 10);
        const u = (m[2] || '').toUpperCase();
        return n * (u === 'G' ? 1024 * 1024 * 1024 : u === 'M' ? 1024 * 1024 : u === 'K' ? 1024 : 1);
    }

    /**
     * Upload a file via XMLHttpRequest so we can show real upload progress.
     * Pre-validates file size against PHP's upload_max_filesize and post_max_size
     * so the user gets a friendly message BEFORE wasting bandwidth.
     */
    function apiUpload(op, file) {
        return new Promise((resolve, reject) => {
            // Pre-flight size check against PHP limits.
            const limits = boot.limits || {};
            const uploadMax = phpSizeToBytes(limits.upload_max_filesize);
            const postMax = phpSizeToBytes(limits.post_max_size);
            const effectiveMax = Math.min(uploadMax, postMax) || uploadMax || postMax;
            if (effectiveMax > 0 && file.size > effectiveMax) {
                reject(new Error(
                    'حجم فایل (' + formatBytes(file.size) + ') بیشتر از حد مجاز PHP است. ' +
                    'upload_max_filesize = ' + (limits.upload_max_filesize || 'نامشخص') +
                    '، post_max_size = ' + (limits.post_max_size || 'نامشخص') + '. ' +
                    'لطفاً فایل کوچک‌تری آپلود کنید یا php.ini را ویرایش کنید.'
                ));
                return;
            }

            state.busy = true;
            state.upload = {
                active: true,
                progress: 0,
                fileName: file.name,
                size: file.size,
            };
            render();

            const fd = new FormData();
            fd.append('file', file);
            fd.append('op', op);
            fd.append(NONCE_KEY, boot.nonce);

            const xhr = new XMLHttpRequest();
            xhr.open('POST', boot.ajaxUrl, true);
            xhr.withCredentials = true;
            // Generous timeout for big ZIPs (10 minutes)
            xhr.timeout = 10 * 60 * 1000;

            // Upload progress events (only available on XHR, not fetch)
            if (xhr.upload) {
                xhr.upload.addEventListener('progress', (e) => {
                    if (e.lengthComputable) {
                        state.upload.progress = Math.round((e.loaded / e.total) * 100);
                        render();
                    }
                });
                xhr.upload.addEventListener('error', () => {
                    reject(new Error(t.errorRequestFailed));
                });
                xhr.upload.addEventListener('timeout', () => {
                    reject(new Error('آپلود timeout شد. فایل خیلی بزرگ است یا اتصال شبکه کند است.'));
                });
            }

            xhr.onload = () => {
                let data;
                try {
                    data = JSON.parse(xhr.responseText);
                } catch (e) {
                    reject(new Error(t.errorInvalidJson + ' (HTTP ' + xhr.status + '): ' + xhr.responseText.slice(0, 200)));
                    return;
                }
                if (!data.ok) {
                    reject(new Error(data.error || t.errorUploadFailed));
                    return;
                }
                resolve(data.data);
            };

            xhr.onerror = () => {
                reject(new Error(t.errorRequestFailed));
            };

            xhr.ontimeout = () => {
                reject(new Error('آپلود timeout شد. فایل خیلی بزرگ است یا اتصال شبکه کند است.'));
            };

            xhr.send(fd);
        }).finally(() => {
            state.busy = false;
            state.upload = { active: false, progress: 0, fileName: '', size: 0 };
            render();
        });
    }

    async function saveSettings() {
        await api('save_settings', { settings: state.settings });
    }

    /* ====================================================== */
    /* Theme                                                  */
    /* ====================================================== */
    /* TypeRenew's admin layout manages the active theme (light/dark) itself,
       via the `html.tr-theme-dark` class. The importer panel inherits that
       theme automatically through CSS variables (--tr-*). We don't toggle
       anything from JS — the user changes theme via TypeRenew's own control. */

    function applyTheme() {
        // No-op: TypeRenew owns the theme. CSS variables do the work.
    }

    /* ====================================================== */
    /* Render                                                 */
    /* ====================================================== */

    function el(tag, attrs, ...children) {
        const node = document.createElement(tag);
        for (const [k, v] of Object.entries(attrs || {})) {
            if (v === null || v === undefined || v === false) continue; // skip false/null attrs entirely
            if (k === 'class') node.className = v;
            else if (k === 'html') node.innerHTML = v;
            else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2), v);
            else if (k === 'dataset') Object.assign(node.dataset, v);
            else if (k === 'checked' || k === 'selected' || k === 'disabled' || k === 'readonly') {
                // Boolean attributes: only set when truthy. setAttribute('checked', false)
                // would render checked="false" which browsers treat as checked!
                if (v === true) node.setAttribute(k, k);
            }
            else if (v === true) node.setAttribute(k, k); // generic boolean attribute
            else node.setAttribute(k, String(v));
        }
        for (const c of children.flat()) {
            if (c == null || c === false) continue;
            node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
        }
        return node;
    }

    function render() {
        applyTheme();
        const root = document.getElementById('wp-importer-app');
        root.innerHTML = '';
        root.appendChild(renderStepper());

        const main = el('div', { class: 'wp-i-main' });
        for (const step of STEPS) {
            main.appendChild(renderStepPanel(step.id));
        }
        root.appendChild(main);
    }

    function renderStepper() {
        const wrap = el('div', { class: 'wp-i-stepper' });
        for (const s of STEPS) {
            const cls = state.step === s.id ? 'active' : (state.step > s.id ? 'done' : '');
            wrap.appendChild(el('div', {
                class: 'wp-i-step ' + cls,
                onclick: () => { state.step = s.id; render(); }
            },
                el('div', { class: 'wp-i-step-num' }, toPersianDigits(String(s.id))),
                el('div', { class: 'wp-i-step-label' }, s.label)
            ));
        }
        return wrap;
    }

    function renderStepPanel(stepId) {
        const isActive = state.step === stepId;
        const panel = el('div', { class: 'wp-i-step-panel' + (isActive ? ' active' : '') });
        if (!isActive) return panel;
        // FIXED: the error banner used to render ONLY on step 1, so any
        // failure that happened on later steps (e.g. start_import) was
        // completely invisible — the user just saw the busy spinner vanish.
        // It is now shown on EVERY step.
        if (state.error) {
            panel.appendChild(renderErrorBanner(state.error));
        }
        switch (stepId) {
            case 1: panel.appendChild(renderConnection()); break;
            case 2: panel.appendChild(renderValidation()); break;
            case 3: panel.appendChild(renderPreview()); break;
            case 4: panel.appendChild(renderImport()); break;
            case 5: panel.appendChild(renderVerification()); break;
            case 6: panel.appendChild(renderReport()); break;
        }
        return panel;
    }

    /* ====================================================== */
    /* Step 1: Connection                                     */
    /* ====================================================== */

    function renderConnection() {
        const card = el('div', { class: 'wp-i-card' });
        card.appendChild(el('h2', { class: 'wp-i-card-title' }, t.step1Title));
        card.appendChild(el('p', { class: 'wp-i-card-desc' }, t.step1Desc));

        // Error banner (also rendered globally at the panel level — see
        // renderStepPanel — so it is never hidden on later steps).
        if (state.error) {
            card.appendChild(renderErrorBanner(state.error));
        }

        // Upload progress (if uploading)
        if (state.upload && state.upload.active) {
            card.appendChild(renderUploadProgress());
        }

        // Source kind radio cards
        const radioGroup = el('div', { class: 'wp-i-radio-group' });
        for (const [kind, title, desc] of [
            ['mysql', t.sourceMysql, t.sourceMysqlDesc],
            ['wxr', t.sourceWxr, t.sourceWxrDesc],
            ['zip', t.sourceZip, t.sourceZipDesc],
        ]) {
            const checked = state.settings.source_kind === kind;
            const radio = el('label', {
                class: 'wp-i-radio' + (checked ? ' checked' : ''),
                onclick: () => {
                    if (state.settings.source_kind === kind) return;
                    state.settings.source_kind = kind;
                    state.error = null;
                    setTimeout(render, 0);
                }
            },
                el('input', { type: 'radio', name: 'source_kind', value: kind, checked: checked }),
                el('div', { class: 'wp-i-radio-title' }, title),
                el('div', { class: 'wp-i-radio-desc' }, desc)
            );
            radioGroup.appendChild(radio);
        }
        card.appendChild(radioGroup);

        // Per-source config
        if (state.settings.source_kind === 'mysql') {
            card.appendChild(renderMysqlConfig());
        } else if (state.settings.source_kind === 'wxr') {
            card.appendChild(renderWxrConfig());
        } else {
            card.appendChild(renderZipConfig());
        }

        // Mode selection (keep / merge / clean)
        card.appendChild(renderModeSelector());

        // Selective import checkboxes
        card.appendChild(renderSelectiveImport());

        // Other options
        card.appendChild(renderOtherOptions());

        // Actions
        card.appendChild(el('div', { class: 'wp-i-actions' },
            el('button', { class: 'wp-i-btn wp-i-btn-primary', onclick: onConnectionNext, disabled: state.busy },
                state.busy ? t.saving : t.saveContinue),
            el('button', { class: 'wp-i-btn', onclick: saveSettings, disabled: state.busy }, t.saveSettings)
        ));

        return card;
    }

    function renderErrorBanner(message) {
        return el('div', { class: 'wp-i-msg error', style: 'margin-bottom: 16px;' },
            el('div', { class: 'wp-i-msg-icon' }, '✕'),
            el('div', {},
                el('strong', {}, 'خطا: '),
                message
            )
        );
    }

    function renderUploadProgress() {
        const u = state.upload;
        return el('div', { class: 'wp-i-progress', style: 'margin-bottom: 16px;' },
            el('div', { style: 'display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 13px;' },
                el('span', {}, t.uploadingFile + ' ' + (u.fileName || '')),
                el('span', {}, toPersianDigits(String(u.progress)) + '٪')
            ),
            el('div', { class: 'wp-i-progress-bar' },
                el('div', { class: 'wp-i-progress-fill', style: 'width: ' + u.progress + '%' })
            ),
            el('div', { class: 'wp-i-hint', style: 'margin-top: 6px;' },
                u.size > 0
                    ? formatBytes(Math.floor(u.size * u.progress / 100)) + ' / ' + formatBytes(u.size)
                    : ''
            )
        );
    }

    function renderMysqlConfig() {
        const m = state.settings.mysql;
        const grid = el('div', { class: 'wp-i-form-grid' });
        grid.appendChild(field(t.host, input('text', m.host, v => m.host = v)));
        grid.appendChild(field(t.port, input('number', m.port, v => m.port = parseInt(v, 10) || 3306)));
        grid.appendChild(field(t.user, input('text', m.user, v => m.user = v)));
        grid.appendChild(field(t.password, input('password', m.password, v => m.password = v)));
        grid.appendChild(field(t.database, input('text', m.database, v => m.database = v)));
        grid.appendChild(field(t.tablePrefix, input('text', m.prefix, v => m.prefix = v)));
        const abspathField = field(t.wpAbspath, input('text', m.abspath, v => m.abspath = v));
        abspathField.appendChild(el('div', { class: 'wp-i-hint' }, t.wpAbspathHint));
        grid.appendChild(abspathField);
        const wrap = el('div', {});
        wrap.appendChild(el('h3', { style: 'margin: 16px 0 8px; font-size: 14px; color: var(--wp-i-text-soft);' }, t.mysqlTitle));
        wrap.appendChild(grid);
        return wrap;
    }

    function renderWxrConfig() {
        const wrap = el('div', {});
        wrap.appendChild(el('h3', { style: 'margin: 16px 0 8px; font-size: 14px; color: var(--wp-i-text-soft);' }, t.wxrTitle));
        if (state.settings.wxr_path) {
            wrap.appendChild(el('p', { class: 'wp-i-hint' }, t.selectedFile + state.settings.wxr_path));
        }
        const fileInput = el('input', { type: 'file', accept: '.xml,.wxr', onchange: async (e) => {
            const f = e.target.files[0];
            if (!f) return;
            state.error = null;
            try {
                const data = await apiUpload('upload_wxr', f);
                state.settings.wxr_path = data.path;
            } catch (err) {
                state.error = err.message;
            }
            render();
        }});
        wrap.appendChild(fileInput);
        return wrap;
    }

    function renderZipConfig() {
        const wrap = el('div', {});
        wrap.appendChild(el('h3', { style: 'margin: 16px 0 8px; font-size: 14px; color: var(--wp-i-text-soft);' }, t.zipTitle));
        if (state.settings.zip_path) {
            wrap.appendChild(el('p', { class: 'wp-i-hint' }, t.selectedFile + state.settings.zip_path));
        }
        const fileInput = el('input', { type: 'file', accept: '.zip', onchange: async (e) => {
            const f = e.target.files[0];
            if (!f) return;
            state.error = null;
            try {
                const data = await apiUpload('upload_zip', f);
                state.settings.zip_path = data.path;
            } catch (err) {
                state.error = err.message;
            }
            render();
        }});
        wrap.appendChild(fileInput);
        return wrap;
    }

    function renderModeSelector() {
        const wrap = el('div', {});
        wrap.appendChild(el('h3', { style: 'margin: 16px 0 8px; font-size: 14px; color: var(--wp-i-text-soft);' }, t.modeTitle));
        const group = el('div', { class: 'wp-i-radio-group' });
        const modes = [
            ['keep', t.modeKeep, t.modeKeepDesc, false],
            ['merge', t.modeMerge, t.modeMergeDesc, false],
            ['clean', t.modeClean, t.modeCleanDesc, true],
        ];
        for (const [mode, title, desc, danger] of modes) {
            const checked = state.settings.mode === mode;
            const cls = 'wp-i-radio' + (checked ? ' checked' : '') + (danger ? ' danger' : '');
            group.appendChild(el('label', {
                class: cls,
                onclick: () => {
                    if (state.settings.mode === mode) return;
                    state.settings.mode = mode;
                    state.settings.clean_confirmed = false;
                    setTimeout(render, 0);
                }
            },
                el('input', { type: 'radio', name: 'mode', value: mode, checked: checked }),
                el('div', { class: 'wp-i-radio-title' }, title),
                el('div', { class: 'wp-i-radio-desc' }, desc)
            ));
        }
        wrap.appendChild(group);
        if (state.settings.mode === 'clean') {
            wrap.appendChild(el('div', { style: 'margin-top: 12px; padding: 12px; background: var(--wp-i-danger-soft); border-radius: 6px;' },
                el('label', { style: 'display:flex;align-items:center;gap:8px;cursor:pointer;flex-direction:row;' },
                    el('input', { type: 'checkbox', checked: state.settings.clean_confirmed, onchange: (e) => {
                        state.settings.clean_confirmed = e.target.checked;
                        setTimeout(render, 0);
                    } }),
                    el('span', {}, t.modeCleanConfirm)
                ),
                el('input', {
                    type: 'text', class: 'wp-i-modal-input', style: 'margin-top:8px;',
                    placeholder: t.modeCleanPlaceholder,
                    value: state.settings.clean_confirmed ? 'DELETE' : '',
                    oninput: (e) => { state.settings.clean_confirmed = e.target.value.trim().toUpperCase() === 'DELETE'; }
                })
            ));
        }
        return wrap;
    }

    function renderSelectiveImport() {
        const wrap = el('div', {});
        wrap.appendChild(el('h3', { style: 'margin: 16px 0 8px; font-size: 14px; color: var(--wp-i-text-soft);' }, t.selectiveTitle));
        const list = el('div', { class: 'wp-i-check-list' });
        for (const [key, label] of [
            ['authors', t.featAuthors],
            ['media', t.featMedia],
            ['comments', t.featComments],
            ['menus', t.featMenus],
            ['fields', t.featFields],
            ['shortcode', t.featShortcode],
            ['gutenberg', t.featGutenberg],
            ['rollback', t.featRollback],
        ]) {
            const checked = !!state.settings.features[key];
            list.appendChild(el('label', { class: 'wp-i-check' },
                el('input', { type: 'checkbox', checked: checked, onchange: (e) => {
                    state.settings.features[key] = e.target.checked;
                    // Note: no render() needed here — checkboxes are already
                    // showing the right state. We just persist the change.
                } }),
                el('span', {}, label)
            ));
        }
        wrap.appendChild(list);
        return wrap;
    }

    function renderOtherOptions() {
        const wrap = el('div', { class: 'wp-i-form-grid', style: 'margin-top: 16px;' });
        wrap.appendChild(field(t.chunkSize, input('number', state.settings.chunk_size, v => state.settings.chunk_size = Math.max(10, Math.min(1000, parseInt(v, 10) || 100)))));
        const stratField = el('div', { class: 'wp-i-field' });
        stratField.appendChild(el('label', {}, t.mediaStrategy));
        const sel = el('select', { onchange: (e) => { state.settings.media_strategy = e.target.value; } },
            el('option', { value: 'copy', selected: state.settings.media_strategy === 'copy' }, t.mediaCopy),
            el('option', { value: 'download', selected: state.settings.media_strategy === 'download' }, t.mediaDownload),
            el('option', { value: 'skip', selected: state.settings.media_strategy === 'skip' }, t.mediaSkip)
        );
        stratField.appendChild(sel);
        wrap.appendChild(stratField);
        wrap.appendChild(el('label', { class: 'wp-i-check', style: 'grid-column: span 2;' + (state.settings.dry_run ? 'color: #b45309; font-weight: 700;' : '') },
            el('input', { type: 'checkbox', checked: state.settings.dry_run, onchange: (e) => { state.settings.dry_run = e.target.checked; render(); } }),
            el('span', {}, t.dryRun)
        ));
        if (state.settings.dry_run) {
            wrap.appendChild(el('div', { class: 'wp-i-msg warning', style: 'grid-column: span 2;' },
                el('div', { class: 'wp-i-msg-icon' }, '!'),
                el('div', {}, t.dryRunWarn)
            ));
        }
        return wrap;
    }

    async function onConnectionNext() {
        try {
            await saveSettings();
            state.error = null;
            state.step = 2;
            render();
            await runValidation();
        } catch (err) {
            state.error = err.message;
            render();
        }
    }

    /* ====================================================== */
    /* Step 2: Validation                                     */
    /* ====================================================== */

    function renderValidation() {
        const card = el('div', { class: 'wp-i-card' });
        card.appendChild(el('h2', { class: 'wp-i-card-title' }, t.step2Title));
        card.appendChild(el('p', { class: 'wp-i-card-desc' }, t.step2Desc));

        if (state.busy) {
            card.appendChild(el('div', { class: 'wp-i-msg info' }, el('div', { class: 'wp-i-spinner' }), el('div', {}, t.validating)));
            return card;
        }
        if (!state.validation) {
            card.appendChild(el('p', { class: 'wp-i-hint' }, t.noValidationYet));
            card.appendChild(el('div', { class: 'wp-i-actions' },
                el('button', { class: 'wp-i-btn wp-i-btn-primary', onclick: runValidation }, t.runValidation)
            ));
            return card;
        }

        const v = state.validation;
        const list = el('ul', { class: 'wp-i-msg-list' });
        if (v.ok) list.appendChild(msg('ok', t.allChecksPassed));
        for (const w of v.warnings) list.appendChild(msg('warning', w));
        for (const e of v.errors) list.appendChild(msg('error', e));
        card.appendChild(list);

        card.appendChild(el('div', { class: 'wp-i-actions' },
            el('button', { class: 'wp-i-btn', onclick: () => { state.step = 1; render(); } }, t.back),
            el('button', { class: 'wp-i-btn', onclick: runValidation }, t.rerunValidation),
            el('button', { class: 'wp-i-btn wp-i-btn-primary', onclick: () => { state.step = 3; render(); runPreview(); }, disabled: !v.ok }, t.continueToPreview)
        ));
        return card;
    }

    async function runValidation() {
        try {
            state.validation = await api('validate');
        } catch (e) {
            state.validation = { ok: false, warnings: [], errors: [e.message] };
        }
        render();
    }

    /* ====================================================== */
    /* Step 3: Preview                                        */
    /* ====================================================== */

    function renderPreview() {
        const card = el('div', { class: 'wp-i-card' });
        card.appendChild(el('h2', { class: 'wp-i-card-title' }, t.step3Title));
        card.appendChild(el('p', { class: 'wp-i-card-desc' }, t.step3Desc));

        if (state.busy) {
            card.appendChild(el('div', { class: 'wp-i-msg info' }, el('div', { class: 'wp-i-spinner' }), el('div', {}, t.counting)));
            return card;
        }
        if (!state.preview) {
            card.appendChild(el('div', { class: 'wp-i-actions' },
                el('button', { class: 'wp-i-btn', onclick: () => { state.step = 2; render(); } }, t.back),
                el('button', { class: 'wp-i-btn wp-i-btn-primary', onclick: runPreview }, t.runPreview)
            ));
            return card;
        }

        const s = state.preview;
        const grid = el('div', { class: 'wp-i-stats' });
        for (const [k, label] of [
            ['posts', t.statPosts], ['pages', t.statPages], ['media', t.statMedia], ['comments', t.statComments],
            ['users', t.statUsers], ['categories', t.statCategories], ['tags', t.statTags], ['menus', t.statMenus],
            ['custom_fields', t.statCustomFields],
        ]) {
            grid.appendChild(stat(s[k] || 0, label));
        }
        card.appendChild(grid);

        card.appendChild(el('div', { class: 'wp-i-actions' },
            el('button', { class: 'wp-i-btn', onclick: () => { state.step = 2; render(); } }, t.back),
            el('button', { class: 'wp-i-btn', onclick: runPreview }, t.refreshPreview),
            el('button', { class: 'wp-i-btn wp-i-btn-primary', onclick: () => { state.step = 4; render(); } }, t.continueToImport)
        ));
        return card;
    }

    async function runPreview() {
        try {
            state.preview = await api('preview');
        } catch (e) {
            state.error = e.message;
        }
        render();
    }

    /* ====================================================== */
    /* Step 4: Import                                         */
    /* ====================================================== */

    function renderImport() {
        const card = el('div', { class: 'wp-i-card' });
        card.appendChild(el('h2', { class: 'wp-i-card-title' }, t.step4Title));
        card.appendChild(el('p', { class: 'wp-i-card-desc' }, t.step4Desc));

        if (state.importResult && state.lastRunWasDryRun) {
            card.appendChild(el('div', { class: 'wp-i-msg warning' },
                el('div', { class: 'wp-i-msg-icon' }, '!'),
                el('div', {},
                    el('div', { style: 'font-weight: 700; margin-bottom: 4px;' }, t.dryRunDoneTitle),
                    el('div', {}, t.dryRunDoneDesc)
                )
            ));
            card.appendChild(el('div', { class: 'wp-i-actions' },
                el('button', { class: 'wp-i-btn wp-i-btn-primary', onclick: onRunForReal, disabled: state.busy },
                    state.busy ? t.runForRealBusy : t.runForReal)
            ));
        } else if (state.importResult) {
            card.appendChild(el('div', { class: 'wp-i-msg ok' }, el('div', { class: 'wp-i-msg-icon' }, '✓'), el('div', {}, t.importCompleted)));
        }

        if (!state.importResult && state.settings.dry_run && !state.busy) {
            card.appendChild(el('div', { class: 'wp-i-msg warning' },
                el('div', { class: 'wp-i-msg-icon' }, '!'),
                el('div', {}, t.dryRunWarn)
            ));
        }

        card.appendChild(el('div', { class: 'wp-i-actions' },
            el('button', { class: 'wp-i-btn', onclick: () => { state.step = 3; render(); } }, t.back),
            el('button', { class: 'wp-i-btn wp-i-btn-primary', onclick: runImport, disabled: state.busy || !!state.importResult },
                state.busy ? t.importing : (state.settings.dry_run ? t.startDryRun : t.startImport)),
            state.importResult ? el('button', { class: 'wp-i-btn wp-i-btn-success', onclick: () => { state.step = 5; render(); } }, t.continueToVerification) : null
        ));

        // Keep the progress bar + live log visible while busy OR after a
        // failed run, so the user can read what went wrong instead of the
        // panel silently reverting (the old "flash and stuck" behaviour).
        if (state.busy || state.importError) {
            card.appendChild(renderProgressBar());
            card.appendChild(renderLogTail());
        }
        return card;
    }

    function renderProgressBar() {
        const p = state.progress || { overall_percent: 0, phase_percent: 0, processed: 0, total: 0, elapsed: 0, eta: 0, speed: 0, current_phase: '', memory_peak: 0 };
        const wrap = el('div', { class: 'wp-i-progress' });
        wrap.appendChild(el('div', { class: 'wp-i-progress-bar' },
            el('div', { class: 'wp-i-progress-fill', style: 'width:' + p.overall_percent + '%' })
        ));
        wrap.appendChild(el('div', { class: 'wp-i-progress-meta' },
            el('span', {}, t.phase + ': ' + (p.current_phase || '—') + ' (' + p.phase_percent + '%)'),
            el('span', {}, toPersianDigits(String(p.processed)) + ' / ' + toPersianDigits(String(p.total)) + ' ' + t.records),
            el('span', {}, t.speed + ': ' + p.speed + ' ر/ث'),
            el('span', {}, t.eta + ': ' + formatDuration(p.eta)),
            el('span', {}, t.memory + ': ' + formatBytes(p.memory_peak))
        ));
        return wrap;
    }

    function renderLogTail() {
        const wrap = el('div', {});
        wrap.appendChild(el('h3', { style: 'margin: 16px 0 8px; font-size: 14px; color: var(--wp-i-text-soft);' }, t.liveLog));
        const log = el('div', { class: 'wp-i-log' });
        const lines = state.logs || [];
        if (lines.length === 0) {
            log.appendChild(el('div', { class: 'wp-i-log-line info' }, t.noLogsYet));
        } else {
            for (const l of lines.slice(-200)) {
                log.appendChild(el('div', { class: 'wp-i-log-line ' + (l.level || 'info') },
                    '[' + new Date(l.ts * 1000).toLocaleTimeString('fa-IR') + '] ' +
                    '[' + (l.level || 'info').toUpperCase() + '] [' + l.phase + '] ' + l.message +
                    (l.context && Object.keys(l.context).length ? ' ' + JSON.stringify(l.context) : '')
                ));
            }
        }
        wrap.appendChild(log);
        return wrap;
    }

    let pollHandle = null;

    async function runImport() {
        try {
            state.importResult = null;
            state.importError = false;
            state.lastRunWasDryRun = !!state.settings.dry_run;
            render();
            // Start polling progress BEFORE the long request starts so the UI updates.
            startPolling();
            // The import runs synchronously server-side; the request will take a while.
            const data = await api('start_import');
            state.importResult = data.result;
            state.lastRunWasDryRun = !!data.dry_run;
            stopPolling();
            // Final fetch
            const p = await api('progress');
            state.progress = p.progress;
            state.logs = p.log_tail;
            state.logCounts = p.log_counts;
            if (p.last_run) state.lastRun = p.last_run;
            render();
        } catch (e) {
            stopPolling();
            state.importError = true;
            state.error = e.message;
            // Pull the server-side progress/log tail so the failure context
            // (phase, last error, log lines) stays visible alongside the banner.
            try {
                const p = await api('progress');
                state.progress = p.progress;
                state.logs = p.log_tail;
                state.logCounts = p.log_counts;
                if (p.last_run) state.lastRun = p.last_run;
            } catch (_) { /* keep the original error */ }
            render();
        }
    }

    /**
     * One-click "run for real": disable dry-run, persist settings, re-import.
     * Shown after a completed dry-run so the user never has to hunt for the
     * checkbox that caused the surprise.
     */
    async function onRunForReal() {
        try {
            state.settings.dry_run = false;
            state.lastRunWasDryRun = false;
            render();
            await saveSettings();
            await runImport();
        } catch (e) {
            state.error = e.message;
            render();
        }
    }

    function startPolling() {
        if (pollHandle) return;
        pollHandle = setInterval(async () => {
            try {
                const p = await api('progress');
                state.progress = p.progress;
                state.logs = p.log_tail;
                state.logCounts = p.log_counts;
                render();
            } catch (e) { /* ignore poll errors */ }
        }, 1500);
    }

    function stopPolling() {
        if (pollHandle) clearInterval(pollHandle);
        pollHandle = null;
    }

    /* ====================================================== */
    /* Step 5: Verification                                   */
    /* ====================================================== */

    function renderVerification() {
        const card = el('div', { class: 'wp-i-card' });
        card.appendChild(el('h2', { class: 'wp-i-card-title' }, t.step5Title));
        card.appendChild(el('p', { class: 'wp-i-card-desc' }, t.step5Desc));

        const wasDryRun = state.lastRunWasDryRun
            || (state.lastRun && state.lastRun.dry_run);
        if (wasDryRun) {
            card.appendChild(el('div', { class: 'wp-i-msg warning' },
                el('div', { class: 'wp-i-msg-icon' }, '!'),
                el('div', {},
                    el('div', { style: 'font-weight: 700; margin-bottom: 4px;' }, t.dryRunDoneTitle),
                    el('div', {}, t.dryRunDoneDesc),
                    el('div', { class: 'wp-i-actions', style: 'margin-top: 10px;' },
                        el('button', { class: 'wp-i-btn wp-i-btn-primary', onclick: () => { state.step = 4; render(); onRunForReal(); }, disabled: state.busy }, t.runForReal)
                    )
                )
            ));
        }

        if (state.lastRun && state.lastRun.result) {
            const r = state.lastRun.result;
            const grid = el('div', { class: 'wp-i-stats' });
            grid.appendChild(stat(r.imported || 0, t.statImported));
            grid.appendChild(stat(r.skipped || 0, t.statSkipped));
            grid.appendChild(stat(r.failed || 0, t.statFailed));
            grid.appendChild(stat(r.duplicates || 0, t.statDuplicates));
            card.appendChild(grid);
        } else if (state.importResult) {
            const r = state.importResult;
            const grid = el('div', { class: 'wp-i-stats' });
            grid.appendChild(stat(r.imported || 0, t.statImported));
            grid.appendChild(stat(r.skipped || 0, t.statSkipped));
            grid.appendChild(stat(r.failed || 0, t.statFailed));
            grid.appendChild(stat(r.duplicates || 0, t.statDuplicates));
            card.appendChild(grid);
        }

        if (state.lastRun && state.lastRun.snapshot_taken) {
            card.appendChild(el('div', { class: 'wp-i-msg warning' },
                el('div', { class: 'wp-i-msg-icon' }, '!'),
                el('div', {}, t.snapshotWarning)
            ));
            card.appendChild(el('div', { class: 'wp-i-actions' },
                el('button', { class: 'wp-i-btn wp-i-btn-danger', onclick: onRollback, disabled: state.busy }, t.rollback),
                el('button', { class: 'wp-i-btn', onclick: onDiscardSnapshot, disabled: state.busy }, t.discardSnapshot)
            ));
        }

        card.appendChild(el('div', { class: 'wp-i-actions' },
            el('button', { class: 'wp-i-btn', onclick: () => { state.step = 4; render(); } }, t.back),
            el('button', { class: 'wp-i-btn wp-i-btn-success', onclick: () => { state.step = 6; render(); } }, t.continueToReport)
        ));
        return card;
    }

    async function onRollback() {
        if (!confirm(t.confirmRollback)) return;
        await api('rollback');
        alert(t.rollbackDone);
        location.reload();
    }

    async function onDiscardSnapshot() {
        if (!confirm(t.confirmDiscard)) return;
        await api('discard_snapshot');
        alert(t.discardDone);
        location.reload();
    }

    /* ====================================================== */
    /* Step 6: Report                                         */
    /* ====================================================== */

    function renderReport() {
        const card = el('div', { class: 'wp-i-card' });
        card.appendChild(el('h2', { class: 'wp-i-card-title' }, t.step6Title));
        card.appendChild(el('p', { class: 'wp-i-card-desc' }, t.step6Desc));

        // Log summary
        if (state.logCounts && state.logCounts.total) {
            const c = state.logCounts;
            const grid = el('div', { class: 'wp-i-stats' });
            grid.appendChild(stat(c.total, t.statTotalEvents));
            grid.appendChild(stat(c.warning, t.statWarnings));
            grid.appendChild(stat(c.error, t.statErrors));
            grid.appendChild(stat(c.critical, t.statCritical));
            card.appendChild(grid);
        }

        card.appendChild(renderLogTail());

        card.appendChild(el('div', { class: 'wp-i-actions' },
            el('button', { class: 'wp-i-btn', onclick: () => { state.step = 5; render(); } }, t.back),
            el('a', { class: 'wp-i-btn wp-i-btn-primary', href: boot.ajaxUrl + '?op=report&' + NONCE_KEY + '=' + encodeURIComponent(boot.nonce), target: '_blank' }, t.downloadReport),
            el('button', { class: 'wp-i-btn wp-i-btn-danger', onclick: onResetState, disabled: state.busy }, t.resetState)
        ));
        return card;
    }

    async function onResetState() {
        if (!confirm(t.confirmReset)) return;
        await api('reset_state');
        alert(t.resetDone);
        location.reload();
    }

    /* ====================================================== */
    /* Helpers                                                */
    /* ====================================================== */

    function field(label, input) {
        const f = el('div', { class: 'wp-i-field' });
        f.appendChild(el('label', {}, label));
        f.appendChild(input);
        return f;
    }

    function input(type, value, oninput) {
        return el('input', { type, value: String(value || ''), oninput: (e) => oninput(e.target.value) });
    }

    function msg(level, text) {
        const icons = { ok: '✓', warning: '!', error: '✕', info: 'i' };
        return el('li', { class: 'wp-i-msg ' + level },
            el('div', { class: 'wp-i-msg-icon' }, icons[level] || 'i'),
            el('div', {}, text)
        );
    }

    function stat(num, label) {
        return el('div', { class: 'wp-i-stat' },
            el('div', { class: 'wp-i-stat-num' }, toPersianDigits(String(num))),
            el('div', { class: 'wp-i-stat-label' }, label)
        );
    }

    /**
     * Convert Latin digits in a string to Persian digits (۰۱۲۳۴۵۶۷۸۹).
     * Keeps the string otherwise intact so paths/URLs survive.
     */
    function toPersianDigits(s) {
        if (typeof s !== 'string') s = String(s);
        const persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return s.replace(/[0-9]/g, d => persian[+d]);
    }

    function formatBytes(b) {
        if (!b) return '۰ بایت';
        const units = ['بایت', 'کیلوبایت', 'مگابایت', 'گیگابایت'];
        let i = 0;
        while (b >= 1024 && i < units.length - 1) { b /= 1024; i++; }
        return toPersianDigits(b.toFixed(1)) + ' ' + units[i];
    }

    function formatDuration(s) {
        if (!s) return '۰ ثانیه';
        if (s < 60) return toPersianDigits(String(s)) + ' ثانیه';
        const m = Math.floor(s / 60);
        const r = s % 60;
        if (m < 60) return toPersianDigits(String(m)) + ' دقیقه ' + toPersianDigits(String(r)) + ' ثانیه';
        const h = Math.floor(m / 60);
        return toPersianDigits(String(h)) + ' ساعت ' + toPersianDigits(String(m % 60)) + ' دقیقه';
    }

    /* ====================================================== */
    /* Boot                                                   */
    /* ====================================================== */

    function boot_() {
        applyTheme();
        render();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot_);
    } else {
        boot_();
    }
})();
