<?php
/**
 * Conflict errors: duplicate slugs, duplicate users, etc.
 *
 * @package   WordPressImporter
 * @category  Exception
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Exception;

class ConflictException extends ImporterException
{
}
