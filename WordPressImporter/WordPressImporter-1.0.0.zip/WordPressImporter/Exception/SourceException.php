<?php
/**
 * Source-related errors: bad credentials, unreachable DB, malformed WXR file.
 *
 * @package   WordPressImporter
 * @category  Exception
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Exception;

class SourceException extends ImporterException
{
}
