<?php
/**
 * Rollback errors: snapshot missing or restore failed.
 *
 * @package   WordPressImporter
 * @category  Exception
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Exception;

class RollbackException extends ImporterException
{
}
