<?php
/**
 * Conversion errors: shortcode / Gutenberg parsing failed for one record.
 *
 * @package   WordPressImporter
 * @category  Exception
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Exception;

class ConversionException extends ImporterException
{
}
