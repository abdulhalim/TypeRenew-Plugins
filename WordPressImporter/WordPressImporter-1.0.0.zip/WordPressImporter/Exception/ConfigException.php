<?php
/**
 * Configuration errors: invalid mode, missing required fields.
 *
 * @package   WordPressImporter
 * @category  Exception
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Exception;

class ConfigException extends ImporterException
{
}
