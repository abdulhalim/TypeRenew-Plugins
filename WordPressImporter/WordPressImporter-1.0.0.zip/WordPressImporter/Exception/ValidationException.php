<?php
/**
 * Validation errors: environment checks that fail before import starts.
 *
 * @package   WordPressImporter
 * @category  Exception
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Exception;

class ValidationException extends ImporterException
{
}
