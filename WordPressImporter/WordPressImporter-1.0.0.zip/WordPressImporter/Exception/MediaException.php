<?php
/**
 * Media-related errors: download failure, copy failure, invalid mime type.
 *
 * @package   WordPressImporter
 * @category  Exception
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Exception;

class MediaException extends ImporterException
{
}
