<?php
/**
 * Base importer exception.
 *
 * All importer exceptions extend from this so callers can catch the whole
 * tree with a single catch block.
 *
 * NOTE: every exception class lives in its OWN file — TypeRenew's plugin
 * autoloader maps `TypechoPlugin\WordPressImporter\Exception\Foo` to
 * `usr/plugins/WordPressImporter/Exception/Foo.php`, so a multi-class file
 * would cause "Class not found" fatals whenever a subclass is thrown first.
 *
 * @package   WordPressImporter
 * @category  Exception
 */

declare(strict_types=1);

namespace TypechoPlugin\WordPressImporter\Exception;

use RuntimeException;

class ImporterException extends RuntimeException
{
}
