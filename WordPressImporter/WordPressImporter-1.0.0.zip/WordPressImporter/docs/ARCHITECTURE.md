# Architecture Reference

This document is a deep-dive into the design decisions of the WordPress Importer
plugin. For installation and usage, see [README.md](../README.md).

## Top-level data flow

```
┌───────────────────────────────────────────────────────────────────────────┐
│                              Admin Wizard UI                              │
│                          (panel.php + wizard.js)                          │
└─────────────┬──────────────────────────────────────────────────┬──────────┘
              │ AJAX                                              │
              ▼                                                  ▼
   ┌──────────────────────┐                          ┌──────────────────────────┐
   │     Action.php       │  save_settings          │     StateManager         │
   │  (endpoint router)   │  validate / preview      │  (wp_importer_state)     │
   │                      │  start_import / progress │  - settings              │
   │                      │  rollback / report       │  - progress              │
   └──────────┬───────────┘                          │  - logs                  │
              │                                      │  - last_run_*            │
              ▼                                      └──────────────────────────┘
   ┌──────────────────────┐
   │   Importer.php       │  (orchestrator)
   │   - builds context   │
   │   - takes snapshot   │
   │   - runs phases      │
   └──────────┬───────────┘
              │
              ▼
   ┌───────────────────────────────────────────────────────────────┐
   │                    Source adapters                            │
   │   MySQLSource  │  WXRSource  │  ZIPSource  (wraps WXRSource)  │
   │   Each yields records via Generator (memory-flat).           │
   └───────────────────────────────────────────────────────────────┘
              │
              ▼
   ┌───────────────────────────────────────────────────────────────┐
   │                  Per-domain Importers                         │
   │  Author → Category → Media → Post → Comment → Field → Menu   │
   │  Each pulls records from Source, persists via TypeRenew Db.  │
   └───────────────────────────────────────────────────────────────┘
              │
              ▼
   ┌───────────────────────────────────────────────────────────────┐
   │          TypeRenew tables (Typecho\Db query builder)         │
   │   contents │ comments │ metas │ relationships │ fields │ users│
   └───────────────────────────────────────────────────────────────┘
```

## State machine

```
                  ┌──────────┐
                  │ pending  │
                  └────┬─────┘
                       │ startRun()
                       ▼
                  ┌──────────┐
                  │ running  │ ◄──── resumeRun() ◄──┐
                  └────┬─────┘                      │
              ┌────────┼────────┐                  │
              │        │        │                  │
              ▼        ▼        ▼                  │
       ┌─────────┐ ┌────────┐ ┌──────────┐         │
       │completed│ │ paused │ │  failed  │─────────┘
       └─────────┘ └────┬───┘ └────┬─────┘
                        │          │
                        │ rollback │
                        ▼          ▼
                  ┌──────────────┐
                  │ rolled_back  │
                  └──────────────┘
```

## Database layout

The plugin adds ONE persistent table:

```sql
CREATE TABLE typecho_wp_importer_state (
    skey VARCHAR(100) PRIMARY KEY,
    svalue LONGTEXT,
    updated BIGINT UNSIGNED
);
```

And one SHADOW table per content table, per run (dropped on discard / rollback):

```sql
CREATE TABLE typecho_wp_importer_snap_contents_<runid> LIKE typecho_contents;
ALTER TABLE typecho_wp_importer_snap_contents_<runid> ADD COLUMN _run_id VARCHAR(64);
INSERT INTO typecho_wp_importer_snap_contents_<runid>
  SELECT *, '<runid>' AS _run_id FROM typecho_contents;
-- (repeat for comments, metas, relationships, fields, users)
```

## Per-run isolation

Each run has a unique `run_id` (e.g. `20260928-143052-a3f1c2`). All state
writes during the run are tagged with this ID so concurrent runs don't
collide (though concurrent runs are not recommended).

## Memory budget

| Source           | Memory use                |
|------------------|---------------------------|
| MySQLSource      | Flat (PDO unbuffered)     |
| WXRSource        | Flat (XMLReader + DOMNode per-item) |
| ZIPSource        | Same as WXRSource + extracted dir on disk |
| Importers        | Flat (one record at a time, plus small maps) |
| Maps             | sourcePostId→cid can grow to ~10MB for 100k posts |

The biggest memory consumer is `$context->postMap` (one int per source post).
For a 1M-post WordPress site this is ~16 MB, well within typical PHP limits.

## Concurrency

The plugin is NOT designed for concurrent imports into the same TypeRenew
instance. Running two imports simultaneously will produce duplicate data and
confuse the progress tracker. The wizard UI disables the Start Import button
while a run is in progress, but the AJAX endpoint itself does not lock —
admins should coordinate.

## Adding a new phase

1. Create a class implementing `ImporterInterface` in the `Importer/` directory at the plugin root.
2. Add it to the `$importers` array in `Importer::__construct()`.
3. The orchestrator handles progress tracking, snapshot, and rollback
   automatically. You only need to implement the four contract methods.
