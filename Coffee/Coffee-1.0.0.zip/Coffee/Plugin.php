<?php
/**
 * افزونه دکمه دونیت قهوه با آیکون متحرک و قابلیت تنظیمات پیشرفته
 * پشتیبانی از سرویس‌های مختلف حمایت مالی
 *
 * @package Coffee
 * @author پوردریایی
 * @link https://pourdaryaei.ir
 * @version 1.0.0
 *
 */

class Coffee_Plugin implements Typecho_Plugin_Interface
{
    /**
     * مقدارهای پیش‌فرض ایمن
     */
    const DEFAULT_TEXT  = 'برامون قهوه بخر';
    const DEFAULT_BG    = '#FFDE8D';
    const DEFAULT_BGH   = '#F9C851';
    const DEFAULT_TXTC  = '#4F2D1A';
    const DEFAULT_TXTH  = '#4F2D1A';
    const DEFAULT_ICNC  = '#4F2D1A';
    const DEFAULT_ICNH  = '#4F2D1A';
    const DEFAULT_USERNAME = 'username';
    const DEFAULT_PLATFORM = 'coffeete';

    /**
     * آیکون‌های رسمی Lucide v1.46.0 (پروانه ISC) — coffee و cup-soda
     * قاعده ضدتاری: هیچ transform پایداری (scale/rotate) در حالت هاور روی آیکون
     * باقی نمی‌ماند؛ حرکت‌ها با کی‌فریم اجرا و در فریم پایانی به identity
     * می‌رسند تا آیکون پس از پایان انیمیشن همیشه وکتوری و شارپ بماند.
     */
    const ICON_COFFEE = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="coffee-icon lucide lucide-coffee" aria-hidden="true" focusable="false"><path d="M10 2v2"/><path d="M14 2v2"/><path d="M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14a4 4 0 1 1 0 8h-1"/><path d="M6 2v2"/></svg>';
    const ICON_CUP    = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="coffee-icon lucide lucide-cup-soda" aria-hidden="true" focusable="false"><path d="m6 8 1.75 12.28a2 2 0 0 0 2 1.72h4.54a2 2 0 0 0 2-1.72L18 8"/><path d="M5 8h14"/><path d="M7 15a6.47 6.47 0 0 1 5 0 6.47 6.47 0 0 0 5 0"/><path d="m12 8 1-6h2"/></svg>';

    /**
     * لیست پلتفرم‌های پشتیبانی‌شده
     */
    const PLATFORMS = [
        'coffeete' => [
            'name' => 'CoffeeTe',
            'url'  => 'https://www.coffeete.ir/'
        ],
        'sibmo' => [
            'name' => 'سیب‌مو',
            'url'  => 'https://sibmo.ir/'
        ],
        'donito' => [
            'name' => 'دونیتو',
            'url'  => 'https://donito.me/'
        ],
        'daramet' => [
            'name' => 'درامت',
            'url'  => 'https://daramet.com/'
        ],
        'reymit' => [
            'name' => 'ریمیت',
            'url'  => 'https://reymit.ir/'
        ],
        'custom' => [
            'name' => 'لینک سفارشی',
            'url'  => ''
        ]
    ];

    /**
     * فعال‌سازی پلاگین
     */
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Archive')->header = array('Coffee_Plugin', 'header');
        Typecho_Plugin::factory('Widget_Archive')->footer = array('Coffee_Plugin', 'footer');
        return _t('پلاگین قهوه با موفقیت فعال شد.');
    }

    /**
     * غیرفعال‌سازی پلاگین
     */
    public static function deactivate()
    {
        return _t('پلاگین قهوه غیرفعال شد.');
    }

    /**
     * اعتبارسنجی رنگ هگزادسیمال
     * فقط قالب‌های استاندارد #RGB و #RRGGBB پذیرفته می‌شوند
     * (قالب‌های #RGBA/#RRGGBBAA با فیلد رنگ فرم ادمین ناسازگارند)
     */
    protected static function sanitizeHexColor($color, $fallback)
    {
        if (!is_string($color)) {
            return $fallback;
        }
        $color = trim($color);
        if (preg_match('/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $color)) {
            return $color;
        }
        return $fallback;
    }

    /**
     * اعتبارسنجی و پاک‌سازی URL
     * پشتیبانی از آدرس‌های یونیکد/فارسی (IDN و مسیر غیرلاتین) که
     * FILTER_VALIDATE_URL آن‌ها را به‌درستی رد می‌کند.
     * خروجی خام برمی‌گردد و escaping در نقطه خروجی انجام می‌شود.
     */
    protected static function sanitizeUrl($url, $fallback)
    {
        if (!is_string($url)) {
            return $fallback;
        }
        $url = trim($url);
        if ($url === '') {
            return $fallback;
        }

        // رد کاراکترهای کنترلی، فاصله و کاراکترهای خطرناک (دفاع لایه‌ای)
        if (preg_match('/[\x00-\x1f\x7f\s"\'<>\\\\]/', $url)) {
            return $fallback;
        }

        $parsed = @parse_url($url);
        if ($parsed === false || empty($parsed['scheme']) || empty($parsed['host'])) {
            return $fallback;
        }

        $scheme = strtolower($parsed['scheme']);
        if (!in_array($scheme, array('http', 'https'), true)) {
            return $fallback;
        }

        return $url;
    }

    /**
     * پاک‌سازی متن برای نمایش امن در HTML
     * نکته: escaping (htmlspecialchars) عمداً اینجا انجام نمی‌شود و
     * به‌صورت متمرکز و یک‌بار در footer انجام می‌گیرد تا از
     * انکود مضاعف (&amp;amp; و ...) جلوگیری شود.
     */
    protected static function sanitizeText($text, $fallback, $maxLen = 100)
    {
        if (!is_string($text)) {
            return $fallback;
        }
        $text = trim($text);
        if ($text === '') {
            return $fallback;
        }
        if (function_exists('mb_substr')) {
            $text = mb_substr($text, 0, $maxLen, 'UTF-8');
        } else {
            $text = substr($text, 0, $maxLen);
        }
        return $text;
    }

    /**
     * پاک‌سازی مقدار انتخابی (enum) بر اساس فهرست مجاز
     */
    protected static function sanitizeEnum($value, array $allowed, $fallback)
    {
        if (in_array($value, $allowed, true)) {
            return $value;
        }
        return $fallback;
    }

    /**
     * دریافت مقدار تنظیمات با پشتیبانی از انواع مختلف ذخیره‌سازی
     */
    protected static function getSafeSetting($value, $default, $allowed = null)
    {
        if (empty($value) && $value !== '0' && $value !== 0) {
            return $default;
        }

        if (is_array($value)) {
            $value = reset($value);
        }

        if (is_object($value) && isset($value->value)) {
            $value = $value->value;
        }

        if (is_object($value) && isset($value->{0})) {
            $value = $value->{0};
        }

        if (!is_string($value) && !is_numeric($value)) {
            return $default;
        }
        $value = (string)$value;

        if (is_array($allowed) && !empty($allowed)) {
            if (!in_array($value, $allowed, true)) {
                return $default;
            }
        }

        return $value;
    }

    /**
     * ساخت لینک نهایی بر اساس پلتفرم و یوزرنیم
     */
    protected static function buildDonationLink($platform, $username, $customUrl = '')
    {
        // اگر پلتفرم سفارشی است و لینک وارد شده
        if ($platform === 'custom' && !empty($customUrl)) {
            return self::sanitizeUrl($customUrl, '');
        }

        // اگر پلتفرم در لیست است و یوزرنیم وارد شده
        if (isset(self::PLATFORMS[$platform]) && !empty($username)) {
            $baseUrl = self::PLATFORMS[$platform]['url'];
            $username = trim($username);

            // حذف اسلش اضافی از انتهای بیس‌یوآر‌ال و ابتدای یوزرنیم
            $baseUrl = rtrim($baseUrl, '/');
            $username = ltrim($username, '/');

            // حذف هرگونه کاراکتر غیرمجاز از یوزرنیم
            $username = preg_replace('/[^a-zA-Z0-9\-_]/', '', $username);

            if (!empty($username)) {
                return $baseUrl . '/' . $username;
            }
        }

        // مقدار پیش‌فرض
        return self::PLATFORMS['coffeete']['url'] . self::DEFAULT_USERNAME;
    }

    /**
     * تنظیمات پلاگین
     * بدون addRule — اعتبارسنجی در زمان رندر توسط توابع sanitize انجام می‌شود
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        // انتخاب پلتفرم
        $platform_options = array();
        foreach (self::PLATFORMS as $key => $platform) {
            $platform_options[$key] = $platform['name'];
        }

        $platform = new Typecho_Widget_Helper_Form_Element_Select(
            'coffee_platform',
            $platform_options,
            'coffeete',
            _t('سرویس حمایت مالی'),
            _t('انتخاب سرویس مورد نظر برای دریافت حمایت مالی')
        );
        $form->addInput($platform);

        // یوزرنیم
        $username = new Typecho_Widget_Helper_Form_Element_Text(
            'coffee_username',
            NULL,
            self::DEFAULT_USERNAME,
            _t('نام کاربری'),
            _t('نام کاربری خود را در سرویس انتخاب‌شده وارد کنید (فقط حروف انگلیسی، اعداد و خط تیره)')
        );
        $form->addInput($username);

        // لینک سفارشی
        $custom_link = new Typecho_Widget_Helper_Form_Element_Text(
            'coffee_custom_link',
            NULL,
            '',
            _t('لینک سفارشی'),
            _t('در صورت انتخاب «لینک سفارشی»، آدرس کامل را وارد کنید (مثال: https://example.com/donate)')
        );
        $form->addInput($custom_link);

        // متن دکمه
        $text = new Typecho_Widget_Helper_Form_Element_Text(
            'coffee_text',
            NULL,
            self::DEFAULT_TEXT,
            _t('متن دکمه'),
            _t('متنی که روی دکمه نمایش داده می‌شود (حداکثر ۱۰۰ نویسه)')
        );
        $form->addInput($text);

        // نوع آیکون
        $icon_type = new Typecho_Widget_Helper_Form_Element_Select(
            'coffee_icon',
            array(
                'solid'   => 'فنجان قهوه داغ (با بخار)',
                'regular' => 'فنجان ساده'
            ),
            'solid',
            _t('نوع آیکون'),
            _t('انتخاب نوع فنجان — آیکون‌های رسمی Lucide به‌صورت SVG داخلی (بدون وابستگی خارجی)')
        );
        $form->addInput($icon_type);

        // افکت هاور
        $effect = new Typecho_Widget_Helper_Form_Element_Select(
            'hover_effect',
            array(
                'slide'  => 'حرکت نرم به راست',
                'bounce' => 'جهش',
                'rotate' => 'چرخش'
            ),
            'slide',
            _t('افکت هاور'),
            _t('نوع انیمیشن هنگام هاور')
        );
        $form->addInput($effect);

        // حالت نمایش
        $display_mode = new Typecho_Widget_Helper_Form_Element_Select(
            'display_mode',
            array(
                'icon_hover_text' => 'آیکون + هاور',
                'always_text'     => 'آیکون + متن',
                'icon_only'       => 'فقط آیکون'
            ),
            'icon_hover_text',
            _t('حالت نمایش'),
            _t('نحوه نمایش متن دکمه')
        );
        $form->addInput($display_mode);

        // رنگ پس زمینه
        $bg_color = new Typecho_Widget_Helper_Form_Element_Text(
            'bg_color',
            NULL,
            self::DEFAULT_BG,
            _t('رنگ پس زمینه'),
            _t('فرمت معتبر: #RRGGBB')
        );
        $bg_color->input->setAttribute('type', 'color');
        $form->addInput($bg_color);

        // رنگ پس زمینه هاور
        $bg_hover = new Typecho_Widget_Helper_Form_Element_Text(
            'bg_hover',
            NULL,
            self::DEFAULT_BGH,
            _t('رنگ پس زمینه (هاور)'),
            NULL
        );
        $bg_hover->input->setAttribute('type', 'color');
        $form->addInput($bg_hover);

        // رنگ متن
        $text_color = new Typecho_Widget_Helper_Form_Element_Text(
            'text_color',
            NULL,
            self::DEFAULT_TXTC,
            _t('رنگ متن'),
            NULL
        );
        $text_color->input->setAttribute('type', 'color');
        $form->addInput($text_color);

        // رنگ متن هاور
        $text_hover = new Typecho_Widget_Helper_Form_Element_Text(
            'text_hover',
            NULL,
            self::DEFAULT_TXTH,
            _t('رنگ متن (هاور)'),
            NULL
        );
        $text_hover->input->setAttribute('type', 'color');
        $form->addInput($text_hover);

        // رنگ آیکون
        $icon_color = new Typecho_Widget_Helper_Form_Element_Text(
            'icon_color',
            NULL,
            self::DEFAULT_ICNC,
            _t('رنگ آیکون'),
            NULL
        );
        $icon_color->input->setAttribute('type', 'color');
        $form->addInput($icon_color);

        // رنگ آیکون هاور
        $icon_hover = new Typecho_Widget_Helper_Form_Element_Text(
            'icon_hover',
            NULL,
            self::DEFAULT_ICNH,
            _t('رنگ آیکون (هاور)'),
            NULL
        );
        $icon_hover->input->setAttribute('type', 'color');
        $form->addInput($icon_hover);
    }

    public static function personalConfig(Typecho_Widget_Helper_Form $form) {}

    /**
     * هدر سایت - استایل‌های CSS
     * امضا سازگار با هوک header($header, $widget) در TypeRenew/Typecho
     */
    public static function header($header = null, $widget = null)
    {
        try {
            $options = Helper::options();
            $plugin = $options->plugin('Coffee');

            // دریافت و پاک‌سازی رنگ‌ها
            $bg_color   = self::sanitizeHexColor(!empty($plugin->bg_color) ? $plugin->bg_color : '', self::DEFAULT_BG);
            $bg_hover   = self::sanitizeHexColor(!empty($plugin->bg_hover) ? $plugin->bg_hover : '', self::DEFAULT_BGH);
            $text_color = self::sanitizeHexColor(!empty($plugin->text_color) ? $plugin->text_color : '', self::DEFAULT_TXTC);
            $text_hover = self::sanitizeHexColor(!empty($plugin->text_hover) ? $plugin->text_hover : '', self::DEFAULT_TXTH);
            $icon_color = self::sanitizeHexColor(!empty($plugin->icon_color) ? $plugin->icon_color : '', self::DEFAULT_ICNC);
            $icon_hover = self::sanitizeHexColor(!empty($plugin->icon_hover) ? $plugin->icon_hover : '', self::DEFAULT_ICNH);
        } catch (\Exception $e) {
            // در صورت بروز هرگونه خطا (مثلاً نبود ردیف تنظیمات در دیتابیس)
            // استایل تزریق نمی‌شود تا سایت از کار نیفتد
            return $header;
        }

        echo <<<HTML
<style>
.coffee-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0px;
    text-decoration: none;
    background-color: {$bg_color};
    padding: 12px 18px;
    border-radius: 80px;
    font-family: inherit;
    font-weight: bold;
    /* فقط پراپرتی‌های امن — بدون transform روی دکمه (باعث تار شدن آیکون می‌شد) */
    transition: background-color 0.3s ease, box-shadow 0.3s ease, padding 0.3s ease, gap 0.3s ease;
    cursor: pointer;
    border: none;
    box-shadow: 0 4px 14px rgba(0,0,0,0.2);
    overflow: hidden;
    direction: ltr;
}

/* حس بلندشدن فقط با عمق سایه — بدون transform */
.coffee-btn:hover {
    background-color: {$bg_hover};
    box-shadow: 0 8px 22px rgba(0,0,0,0.25);
}

/*
 * آیکون Lucide — قواعد ضدتاری:
 * ۱) حالت پایدار هاور هیچ scale/rotate ندارد (فقط رنگ و ضخامت خط)
 * ۲) حرکت‌ها با کی‌فریم اجرا می‌شوند و در فریم پایانی به identity می‌رسند؛
 *    پس پس از پایان انیمیشن آیکون بدون transform رندر می‌شود (شارپ)
 * ۳) اسلاید فقط از translate صحیح پیکسلی استفاده می‌کند (بدون resampling)
 */
.coffee-btn .coffee-icon {
    width: 24px;
    height: 24px;
    flex-shrink: 0;
    color: {$icon_color};
    transition: color 0.25s ease, stroke-width 0.25s ease, transform 0.25s ease;
    display: block;
}

.coffee-btn:hover .coffee-icon {
    color: {$icon_hover};
    stroke-width: 2.4;
}

.coffee-btn .coffee-text {
    display: none;
    font-size: 14px;
    color: {$text_color};
    font-weight: 600;
    white-space: nowrap;
    font-family: inherit;
}

.coffee-btn:hover .coffee-text {
    display: inline-block;
    color: {$text_hover};
}

/* افکت اسلاید — آیکون ۴px به راست می‌لغزد (translate صحیح پیکسلی = بدون تاری) */
.coffee-btn.slide-effect {
    gap: 0px;
}
.coffee-btn.slide-effect .coffee-text {
    opacity: 0;
    transform: translateX(-8px);
    transition: opacity 0.25s ease, transform 0.25s ease, color 0.25s ease;
}
.coffee-btn.slide-effect:hover {
    gap: 10px;
    padding-right: 24px;
}
.coffee-btn.slide-effect:hover .coffee-text {
    opacity: 1;
    transform: translateX(0);
    display: inline-block;
}
.coffee-btn.slide-effect:hover .coffee-icon {
    transform: translateX(4px);
}

/* افکت جهش — پرش دوبل آیکون + پاپ فنری متن */
.coffee-btn.bounce-effect {
    gap: 0px;
}
.coffee-btn.bounce-effect .coffee-text {
    opacity: 0;
    transform: scale(0.7);
    transition: opacity 0.25s cubic-bezier(0.68, -0.55, 0.265, 1.55), transform 0.25s cubic-bezier(0.68, -0.55, 0.265, 1.55), color 0.25s ease;
}
.coffee-btn.bounce-effect:hover {
    gap: 10px;
    padding-right: 24px;
}
.coffee-btn.bounce-effect:hover .coffee-text {
    opacity: 1;
    transform: scale(1);
    display: inline-block;
}
.coffee-btn.bounce-effect:hover .coffee-icon {
    animation: coffeeBounce 0.55s cubic-bezier(0.3, 0.7, 0.4, 1);
}

/* پرش دوبل واقعی — فقط translateY (بدون resampling) و فریم پایانی identity */
@keyframes coffeeBounce {
    0%   { transform: translateY(0); }
    30%  { transform: translateY(-7px); }
    55%  { transform: translateY(0); }
    75%  { transform: translateY(-3px); }
    100% { transform: translateY(0); }
}

/* افکت چرخش — اسپین کامل آیکون + چرخش ظریف متن */
.coffee-btn.rotate-effect {
    gap: 0px;
}
.coffee-btn.rotate-effect .coffee-text {
    opacity: 0;
    transform: rotate(-8deg);
    transition: opacity 0.2s ease, transform 0.2s ease, color 0.25s ease;
}
.coffee-btn.rotate-effect:hover {
    gap: 10px;
    padding-right: 24px;
}
.coffee-btn.rotate-effect:hover .coffee-text {
    opacity: 1;
    transform: rotate(0deg);
    display: inline-block;
}
.coffee-btn.rotate-effect:hover .coffee-icon {
    animation: coffeeSpin 0.5s cubic-bezier(0.35, 0.45, 0.35, 1);
}

/* چرخش کامل ۳۶۰ درجه — فریم پایانی معادل حالت اولیه یعنی شارپ */
@keyframes coffeeSpin {
    from { transform: rotate(0deg); }
    to   { transform: rotate(360deg); }
}

/* حالت همیشه متن */
.coffee-btn.always-text-mode {
    gap: 10px;
}
.coffee-btn.always-text-mode .coffee-text {
    display: inline-block;
    opacity: 1;
    transform: none;
}
.coffee-btn.always-text-mode:hover {
    padding-right: 18px;
}

/* حالت فقط آیکون */
.coffee-btn.icon-only-mode {
    padding: 12px;
    border-radius: 60px;
}
.coffee-btn.icon-only-mode .coffee-text {
    display: none !important;
}
.coffee-btn.icon-only-mode:hover {
    padding: 12px;
    box-shadow: 0 8px 22px rgba(0,0,0,0.25);
}
/* تاکید فقط با ضخامت خط — بدون scale/rotate (عامل تاری آیکون) */
.coffee-btn.icon-only-mode:hover .coffee-icon {
    stroke-width: 2.6;
}

/* احترام به ترجیح «کاهش حرکت» کاربر */
@media (prefers-reduced-motion: reduce) {
    .coffee-btn,
    .coffee-btn .coffee-icon,
    .coffee-btn .coffee-text {
        transition-duration: 0.01ms !important;
        animation-duration: 0.01ms !important;
    }
}

/* دارک‌مود */
@media (prefers-color-scheme: dark) {
    .coffee-btn {
        box-shadow: 0 4px 14px rgba(0,0,0,0.4);
    }
    .coffee-btn:hover {
        box-shadow: 0 8px 22px rgba(0,0,0,0.5);
    }
}

/* واکنش‌گرا */
@media (max-width: 768px) {
    .coffee-btn {
        padding: 10px 14px;
    }
    .coffee-btn .coffee-text {
        font-size: 12px;
    }
    .coffee-btn.icon-only-mode {
        padding: 10px;
    }
}
</style>
HTML;
        return $header;
    }

    /**
     * فوتر سایت - نمایش دکمه
     * امضا سازگار با هوک footer($widget) در TypeRenew/Typecho
     */
    public static function footer($widget = null)
    {
        try {
            $options = Helper::options();
            $plugin = $options->plugin('Coffee');

            // دریافت تنظیمات
            $platform = self::getSafeSetting(
                $plugin->coffee_platform,
                'coffeete',
                array_keys(self::PLATFORMS)
            );

            $username = self::getSafeSetting($plugin->coffee_username, '');
            $customLink = self::getSafeSetting($plugin->coffee_custom_link, '');

            // ساخت لینک نهایی
            $link = self::buildDonationLink($platform, $username, $customLink);

            // اگر لینک ساخته نشد، از پیش‌فرض استفاده کن
            if (empty($link)) {
                $link = self::PLATFORMS['coffeete']['url'] . self::DEFAULT_USERNAME;
            }

            $text = self::sanitizeText(
                self::getSafeSetting($plugin->coffee_text, ''),
                self::DEFAULT_TEXT
            );

            $icon_type = self::getSafeSetting(
                $plugin->coffee_icon,
                'solid',
                array('solid', 'regular')
            );

            $effect = self::getSafeSetting(
                $plugin->hover_effect,
                'slide',
                array('slide', 'bounce', 'rotate')
            );

            $mode = self::getSafeSetting(
                $plugin->display_mode,
                'icon_hover_text',
                array('icon_hover_text', 'always_text', 'icon_only')
            );

            // انتخاب آیکون
            $coffeeIcon = ($icon_type === 'regular') ? self::ICON_CUP : self::ICON_COFFEE;

            // کلاس افکت
            $effectClass = 'slide-effect';
            if ($effect === 'bounce') {
                $effectClass = 'bounce-effect';
            } elseif ($effect === 'rotate') {
                $effectClass = 'rotate-effect';
            }

            // کلاس حالت نمایش
            $modeClass = '';
            if ($mode === 'always_text') {
                $modeClass = 'always-text-mode';
            } elseif ($mode === 'icon_only') {
                $modeClass = 'icon-only-mode';
            }

            // ساخت class تمیز بدون فاصله اضافی
            $classAttr = trim(implode(' ', array_filter(array(
                'coffee-btn', $effectClass, $modeClass
            ))));

            // برچسب دسترس‌پذیری: متن + نام سرویس (فقط aria-label برای صفحه‌خوان‌ها).
            // اتریبیوت title عمداً حذف شده تا تولتیپ بومی مرورگر هنگام هاور نمایش داده نشود.
            $platformName = isset(self::PLATFORMS[$platform]['name']) ? self::PLATFORMS[$platform]['name'] : '';
            $ariaLabel = ($platformName !== '' && $platform !== 'custom')
                ? $text . ' (' . $platformName . ')'
                : $text;

            // خروجی امن — escaping فقط و فقط یک‌بار همین‌جا انجام می‌شود
            $safeLink = htmlspecialchars($link, ENT_QUOTES, 'UTF-8');
            $safeText = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
            $safeAria = htmlspecialchars($ariaLabel, ENT_QUOTES, 'UTF-8');
            $safeClass = htmlspecialchars($classAttr, ENT_QUOTES, 'UTF-8');

            echo '<div style="position: fixed; bottom: 25px; right: 25px; z-index: 9999;">';
            echo '<a href="' . $safeLink . '" target="_blank" rel="noopener noreferrer nofollow" class="' . $safeClass . '"'
                . ' aria-label="' . $safeAria . '">';
            echo $coffeeIcon;
            echo '<span class="coffee-text">' . $safeText . '</span>';
            echo '</a>';
            echo '</div>';
        } catch (\Exception $e) {
            // در صورت بروز هرگونه خطا، دکمه نمایش داده نمی‌شود تا سایت از کار نیفتد
        }
    }
}
