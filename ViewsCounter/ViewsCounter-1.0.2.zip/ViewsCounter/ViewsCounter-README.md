# افزونه شمارنده بازدید (ViewsCounter)

شمارنده‌ی سبک و سریع بازدید مطالب برای TypeRenew / Typecho، با پنل مدیریت، نمودار روند ۱۴ روز اخیر، و ویجت‌های داشبورد اصلی.

---

## فهرست

- [نصب](#نصب)
- [تنظیمات](#تنظیمات)
- [استفاده در پوسته](#استفاده-در-پوسته)
  - [۱. نمایش تعداد بازدید مطلب جاری](#۱-نمایش-تعداد-بازدید-مطلب-جاری)
  - [۲. نمایش تعداد بازدید با cid مشخص](#۲-نمایش-تعداد-بازدید-با-cid-مشخص)
  - [۳. نمایش لیست پربازدیدترین مطالب](#۳-نمایش-لیست-پربازدیدترین-مطالب)
- [متدهای قابل استفاده در پوسته](#متدهای-قابل-استفاده-در-پوسته)
- [سازگاری با پلاگین قدیمی](#سازگاری-با-پلاگین-قدیمی)

---

## نصب

۱. فایل ZIP افزونه را دانلود کنید.
۲. پوشه‌ی `ViewsCounter` را در مسیر `usr/plugins/` قرار دهید.
۳. به پنل مدیریت TypeRenew بروید → **افزونه‌ها** → **ViewsCounter** را **فعال** کنید.

---

## تنظیمات

به مسیر **افزونه‌ها → تنظیمات ViewsCounter** بروید. گزینه‌های زیر در دسترس هستند:

| گزینه | توضیح | پیش‌فرض |
|-------|-------|---------|
| تعداد آیتم‌های لیست پربازدیدترین‌ها | حداکثر تعداد مطالب در لیست | ۱۰ |
| فاصله زمانی شمارش بازدیدهای مکرر (ثانیه) | جلوگیری از شمارش چندباره یک کاربر | ۳۶۰۰ |
| شمارش بازدید کاربران واردشده | آیا بازدید مدیر/نویسنده شمارش شود؟ | خیر |
| شمارش بازدید برای برگه‌ها | آیا برگه‌های مستقل هم شمارش شوند؟ | فقط نوشته‌ها |
| ویجت «آمار بازدید» در داشبورد اصلی | نمایش/مخفی کردن کارت KPI | نمایش |
| ویجت «روند بازدید ۱۴ روز اخیر» در داشبورد | نمایش/مخفی کردن نمودار روند | نمایش |

---

## استفاده در پوسته

برای نمایش تعداد بازدید یا لیست مطالب پربازدید در پوسته، می‌توانید از کدهای زیر استفاده کنید.

### ۱. نمایش تعداد بازدید مطلب جاری

در فایل `post.php` پوسته (داخل حلقه‌ی مطالب)، کد زیر را قرار دهید:

```php
<?php
// بررسی فعال بودن پلاگین
if (class_exists('TypechoPlugin\ViewsCounter\Plugin')) {
    $views = \TypechoPlugin\ViewsCounter\Plugin::getViews();
    echo '<span class="post-views">' . $views . ' بازدید</span>';
}
?>
```

یا به‌صورت خلاصه‌تر:

```php
<?php if (class_exists('TypechoPlugin\ViewsCounter\Plugin')): ?>
    <span class="post-views">
        <?php echo \TypechoPlugin\ViewsCounter\Plugin::getViews(); ?> بازدید
    </span>
<?php endif; ?>
```

**خروجی نمونه:**

```html
<span class="post-views">۱۲۳ بازدید</span>
```

> **نکته:** این متد باید داخل حلقه‌ی مطالب استفاده شود (یعنی بعد از `$this->next()` یا در فایل `post.php`).

---

### ۲. نمایش تعداد بازدید با cid مشخص

اگر cid یک مطلب را دارید و می‌خواهید تعداد بازدید آن را نمایش دهید:

```php
<?php
if (class_exists('TypechoPlugin\ViewsCounter\Plugin')) {
    $cid = 14; // شناسه‌ی مطلب مورد نظر
    $views = \TypechoPlugin\ViewsCounter\Plugin::getViewsById($cid);
    echo 'بازدید مطلب ' . $cid . ': ' . $views;
}
?>
```

**کاربرد:** مناسب برای نمایش بازدید مطالب مرتبط، مطالب تصادفی یا هر جایی که cid مطلب را دارید.

---

### ۳. نمایش لیست پربازدیدترین مطالب

برای نمایش لیست مطالب پربازدید در نوار کناری (sidebar) یا هر بخشی از پوسته:

#### حالت الف) استفاده از تعداد تنظیم‌شده در پنل تنظیمات

```php
<?php
if (class_exists('TypechoPlugin\ViewsCounter\Plugin')) {
    // خواندن تعداد از تنظیمات افزونه (پیش‌فرض: ۱۰)
    $popular = \TypechoPlugin\ViewsCounter\Plugin::getMostViewed();

    if (!empty($popular)) {
        echo '<ul class="popular-posts">';
        foreach ($popular as $post) {
            $title = htmlspecialchars($post['title']);
            $views = $post['views'];
            $permalink = $post['permalink'];
            echo '<li>';
            echo '<a href="' . $permalink . '">' . $title . '</a>';
            echo '<span class="views">' . $views . ' بازدید</span>';
            echo '</li>';
        }
        echo '</ul>';
    }
}
?>
```

#### حالت ب) تعیین تعداد دستی

```php
<?php
if (class_exists('TypechoPlugin\ViewsCounter\Plugin')) {
    // نمایش ۵ مطلب پربازدید
    $popular = \TypechoPlugin\ViewsCounter\Plugin::getMostViewed(5);

    if (!empty($popular)) {
        echo '<ul class="popular-posts">';
        foreach ($popular as $post) {
            $title = htmlspecialchars($post['title']);
            $views = $post['views'];
            $permalink = $post['permalink'];
            echo '<li>';
            echo '<a href="' . $permalink . '">' . $title . '</a>';
            echo '<span class="views">' . $views . ' بازدید</span>';
            echo '</li>';
        }
        echo '</ul>';
    }
}
?>
```

**خروجی نمونه:**

```html
<ul class="popular-posts">
    <li>
        <a href="/archives/15/">عنوان مطلب اول</a>
        <span class="views">۵۴۰ بازدید</span>
    </li>
    <li>
        <a href="/archives/8/">عنوان مطلب دوم</a>
        <span class="views">۳۲۰ بازدید</span>
    </li>
</ul>
```

#### فیلدهای موجود در آرایه‌ی هر مطلب

هر آیتم بازگردانده‌شده از `getMostViewed()` شامل فیلدهای زیر است:

| فیلد | نوع | توضیح |
|------|-----|-------|
| `cid` | int | شناسه‌ی محتوا |
| `title` | string | عنوان مطلب |
| `slug` | string | نامک مطلب |
| `type` | string | نوع محتوا (post / page) |
| `status` | string | وضعیت انتشار (publish) |
| `created` | int | زمان ساخت (timestamp) |
| `modified` | int | زمان آخرین ویرایش (timestamp) |
| `authorId` | int | شناسه‌ی نویسنده |
| `views` | int | تعداد بازدید |
| `permalink` | string | نشانی دائمی مطلب |

---

## متدهای قابل استفاده در پوسته

خلاصه‌ی متدهایی که می‌توانید در پوسته صدا بزنید:

```php
// ۱. تعداد بازدید مطلب جاری (داخل حلقه)
\TypechoPlugin\ViewsCounter\Plugin::getViews(): int

// ۲. تعداد بازدید یک مطلب با cid مشخص
\TypechoPlugin\ViewsCounter\Plugin::getViewsById(int $cid): int

// ۳. لیست پربازدیدترین مطالب
\TypechoPlugin\ViewsCounter\Plugin::getMostViewed(int $limit = 0): array
//     $limit = 0 → از تنظیمات پلاگین (popular_limit) خوانده می‌شود
//     $limit > 0 → تعداد دلخواه
```

> **مهم:** همیشه قبل از فراخوانی، فعال بودن پلاگین را بررسی کنید:
> ```php
> if (class_exists('TypechoPlugin\ViewsCounter\Plugin')) {
>     // کد شما
> }
> ```

---

## سازگاری با پلاگین قدیمی

اگر پوسته‌ی شما برای پلاگین قدیمی `ViewsCounter` (نسخه‌ی ۱.۱.۰ Quarkay) نوشته شده است، نیازی به تغییر کدها نیست. این نسخه لایه‌ی سازگاری کاملی دارد:

| فراخوانی قدیمی | فراخوانی جدید | وضعیت |
|---------------|--------------|-------|
| `ViewsCounter_Plugin::getViewsById($cid)` | `\TypechoPlugin\ViewsCounter\Plugin::getViewsById($cid)` | ✓ پشتیبانی می‌شود |
| `ViewsCounter_Plugin::getViews()` | `\TypechoPlugin\ViewsCounter\Plugin::getViews()` | ✓ پشتیبانی می‌شود |
| `ViewsCounter_Plugin::getMostViewed()` | `\TypechoPlugin\ViewsCounter\Plugin::getMostViewed()` | ✓ پشتیبانی می‌شود |

---

## نمونه‌ی کامل: بلوک مطالب پربازدید در نوار کناری

```php
<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<aside class="widget popular-posts-widget">
    <h3 class="widget-title">پربازدیدترین مطالب</h3>

    <?php if (class_exists('TypechoPlugin\ViewsCounter\Plugin')): ?>
        <?php $popular = \TypechoPlugin\ViewsCounter\Plugin::getMostViewed(5); ?>

        <?php if (!empty($popular)): ?>
            <ul class="popular-list">
                <?php foreach ($popular as $item): ?>
                    <li class="popular-item">
                        <a href="<?php echo $item['permalink']; ?>" class="popular-link">
                            <?php echo htmlspecialchars($item['title']); ?>
                        </a>
                        <span class="popular-views">
                            <?php echo $item['views']; ?> بازدید
                        </span>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p class="popular-empty">هنوز مطلبی ثبت نشده است.</p>
        <?php endif; ?>

    <?php else: ?>
        <p class="popular-empty">افزونه‌ی ViewsCounter فعال نیست.</p>
    <?php endif; ?>
</aside>
```

---

## نمونه‌ی کامل: نمایش بازدید در فایل post.php

```php
<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<article class="post">
    <h1 class="post-title"><?php $this->title(); ?></h1>

    <div class="post-meta">
        <span class="post-date"><?php $this->date(); ?></span>

        <?php if (class_exists('TypechoPlugin\ViewsCounter\Plugin')): ?>
            <span class="post-views">
                <?php echo \TypechoPlugin\ViewsCounter\Plugin::getViews(); ?> بازدید
            </span>
        <?php endif; ?>
    </div>

    <div class="post-content">
        <?php $this->content(); ?>
    </div>
</article>
```

---

## نمونه‌ی کامل: مطالب تصادفی پربازدید

```php
<?php
// نمایش ۳ مطلب از بین ۱۶ مطلب پربازدید (به‌صورت تصادفی)
if (class_exists('TypechoPlugin\ViewsCounter\Plugin')) {
    $top = \TypechoPlugin\ViewsCounter\Plugin::getMostViewed(16);

    if (!empty($top)) {
        // انتخاب ۳ مورد به‌صورت تصادفی
        shuffle($top);
        $selected = array_slice($top, 0, 3);

        echo '<div class="random-popular">';
        foreach ($selected as $post) {
            echo '<a href="' . $post['permalink'] . '" class="random-item">';
            echo htmlspecialchars($post['title']);
            echo '<span class="views">' . $post['views'] . ' بازدید</span>';
            echo '</a>';
        }
        echo '</div>';
    }
}
?>
```

---

## نکات

- پلاگین به‌صورت خودکار ستون `views` را به جدول `contents` اضافه می‌کند (اگر وجود نداشته باشد).
- بازدید کاربران واردشده (مدیر/نویسنده) بر اساس تنظیمات شمارش می‌شود یا خیر.
- برای جلوگیری از شمارش مکرر یک کاربر در مدت زمان کوتاه، از کوکی استفاده می‌شود.
- داده‌های روزانه برای نمودار روند در یک جدول جداگانه ذخیره می‌شوند.
- ویجت‌های داشبورد اصلی (آمار و روند) را می‌توان از تنظیمات پلاگین فعال/غیرفعال کرد.
- تاریخ‌های نمودار روند به‌صورت خودکار به شمسی (تقویم جلالی) تبدیل می‌شوند — مستقل از پلاگین JalaliDate.

---

## نویسنده

**پوردریایی**
- وب‌سایت: https://pourdaryaei.ir
