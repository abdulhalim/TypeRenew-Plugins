(function () {
    'use strict';

    function ajax(url, body, onDone, onError) {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', url, true);
        xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
        xhr.setRequestHeader('Accept', 'application/json');
        xhr.onreadystatechange = function () {
            if (xhr.readyState !== 4) return;
            if (xhr.status >= 200 && xhr.status < 300) {
                var data = null;
                try { data = JSON.parse(xhr.responseText); } catch (e) { data = null; }
                onDone(data, xhr);
            } else {
                if (onError) onError(xhr);
            }
        };
        xhr.send(body);
    }

    function csrfFromForm() {
        // توکن امنیتی از نام فیلد و مقدار آن استخراج می‌شود
        // سیستم Typecho معمولاً از &referrer و یک هدر/کوکی استفاده می‌کند؛ Security::protect خودش آن را تضمین می‌کند.
        return null;
    }

    function confirmMessage(msg) {
        return window.confirm(msg);
    }

    function resetOne(btn) {
        var tr = btn.closest('tr');
        if (!tr) return;
        var cid = tr.getAttribute('data-cid');
        var url = tr.getAttribute('data-reset-url');
        if (!cid || !url) return;
        if (!confirmMessage('آیا مطمئن هستید می‌خواهید بازدید این مطلب را به صفر بازنشانی کنید؟')) return;

        btn.disabled = true;
        var original = btn.textContent;
        btn.textContent = 'در حال…';

        var body = new FormData();
        body.append('do', 'reset');
        body.append('cid', cid);
        body.append('ref', window.location.pathname);

        ajax(url, body, function (data) {
            btn.disabled = false;
            btn.textContent = original;
            if (data && data.ok) {
                var cell = tr.querySelector('.vc-views-num');
                if (cell) cell.textContent = '0';
            } else {
                alert((data && data.message) ? data.message : 'بازنشانی ناموفق بود.');
            }
        }, function () {
            btn.disabled = false;
            btn.textContent = original;
            alert('درخواست ناموفق بود. لطفاً دوباره تلاش کنید.');
        });
    }

    function resetAll(btn) {
        var scope = btn.getAttribute('data-scope') || 'all';
        var url = btn.getAttribute('data-token-url');
        if (!url) return;
        if (!confirmMessage('بازنشانی همه بازدیدها برای «' + scope + '» به صفر؟ این کار قابل بازگشت نیست.')) return;

        btn.disabled = true;
        var original = btn.textContent;
        btn.textContent = 'در حال…';

        var body = new FormData();
        body.append('do', 'reset_all');
        body.append('scope', scope);
        body.append('ref', window.location.pathname);

        ajax(url, body, function (data) {
            btn.disabled = false;
            btn.textContent = original;
            if (data && data.ok) {
                window.location.reload();
            } else {
                alert((data && data.message) ? data.message : 'بازنشانی ناموفق بود.');
            }
        }, function () {
            btn.disabled = false;
            btn.textContent = original;
            alert('درخواست ناموفق بود. لطفاً دوباره تلاش کنید.');
        });
    }

    function init() {
        var panel = document.querySelector('.tr-panel-views');
        if (!panel) return;

        panel.addEventListener('click', function (e) {
            var target = e.target;
            if (!(target instanceof HTMLElement)) return;

            if (target.classList.contains('vc-reset-one')) {
                e.preventDefault();
                resetOne(target);
                return;
            }
            if (target.classList.contains('vc-reset-all')) {
                e.preventDefault();
                resetAll(target);
                return;
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
