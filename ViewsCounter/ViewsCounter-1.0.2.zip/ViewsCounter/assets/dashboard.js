(function () {
    'use strict';

    function ready(fn) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', fn);
        } else {
            fn();
        }
    }

    function fmtNum(n) {
        n = parseInt(n, 10) || 0;
        return n.toLocaleString('en-US');
    }

    function buildWidget(data) {
        var i18n = data.i18n || {};
        var html = '';
        html += '<div class="vc-dash-card" dir="rtl">';
        html += '  <div class="vc-dash-head">';
        html += '    <h3 class="vc-dash-title">' + (i18n.title || 'آمار بازدید') + '</h3>';
        if (data.panelUrl) {
            html += '    <a class="vc-dash-link" href="' + data.panelUrl + '">' + (i18n.viewDetail || 'مشاهده جزئیات') + '</a>';
        }
        html += '  </div>';
        html += '  <div class="vc-dash-num">' + fmtNum(data.total) + '</div>';
        html += '  <div class="vc-dash-num-label">' + (i18n.total || 'مجموع بازدیدها') + '</div>';
        html += '  <div class="vc-dash-rows">';
        html += '    <div class="vc-dash-row"><span class="vc-dash-row-label">' + (i18n.posts || 'بازدید نوشته‌ها') + '</span><span class="vc-dash-row-value accent">' + fmtNum(data.posts) + '</span></div>';
        html += '    <div class="vc-dash-row"><span class="vc-dash-row-label">' + (i18n.pages || 'بازدید برگه‌ها') + '</span><span class="vc-dash-row-value">' + fmtNum(data.pages) + '</span></div>';
        html += '    <div class="vc-dash-row"><span class="vc-dash-row-label">' + (i18n.avgPerPost || 'میانگین به ازای هر نوشته') + '</span><span class="vc-dash-row-value">' + fmtNum(data.avgPerPost) + '</span></div>';
        html += '  </div>';
        html += '</div>';
        return html;
    }

    /**
     * ساخت SVG نمودار میله‌ای عمودی برای روند ۱۴ روز اخیر
     *
     * این نمودار مستقل از Chart.php و در سمت کلاینت ساخته می‌شود تا
     * با هنگار موس تعامل داشته باشد (tooltip). هر میله نماینده‌ی یک روز است.
     */
    function buildTrendWidget(data) {
        var i18n = data.i18n || {};
        var trend = data.trend || {};
        var labels = trend.labels || [];
        var values = trend.values || [];

        var html = '';
        html += '<div class="vc-dash-card vc-dash-trend-card" dir="rtl">';
        html += '  <div class="vc-dash-head">';
        html += '    <h3 class="vc-dash-title">' + (i18n.trendTitle || 'روند بازدید ۱۴ روز اخیر') + '</h3>';
        html += '  </div>';

        // خلاصه آماری بالای نمودار
        html += '  <div class="vc-trend-stats">';
        html += '    <div class="vc-trend-stat">';
        html += '      <span class="vc-trend-stat-label">' + (i18n.trendTotal || 'مجموع این دوره') + '</span>';
        html += '      <span class="vc-trend-stat-value">' + fmtNum(trend.total || 0) + '</span>';
        html += '    </div>';
        html += '    <div class="vc-trend-stat">';
        html += '      <span class="vc-trend-stat-label">' + (i18n.trendAvg || 'میانگین روزانه') + '</span>';
        html += '      <span class="vc-trend-stat-value accent">' + fmtNum(trend.avg || 0) + '</span>';
        html += '    </div>';
        html += '    <div class="vc-trend-stat">';
        html += '      <span class="vc-trend-stat-label">' + (i18n.trendMax || 'بیشترین روز') + '</span>';
        html += '      <span class="vc-trend-stat-value">' + fmtNum(trend.max || 0) + '</span>';
        html += '    </div>';
        html += '  </div>';

        // نمودار میله‌ای
        if (values.length === 0 || (trend.total || 0) === 0) {
            html += '  <div class="vc-trend-empty">' + (i18n.trendNoData || 'داده‌ای ثبت نشده') + '</div>';
        } else {
            html += buildBarsChart(values, labels, i18n);
        }

        html += '</div>';
        return html;
    }

    function buildBarsChart(values, labels, i18n) {
        var max = Math.max.apply(null, values);
        if (max <= 0) max = 1;

        var barCount = values.length;
        var chartWidth = 100; // درصد — کل عرض نمودار
        var gapPct = barCount > 1 ? 1.5 : 0; // فاصله بین میله‌ها (درصد)
        var barWidth = (chartWidth - (gapPct * (barCount - 1))) / barCount;
        var chartHeight = 120; // پیکسل

        var bars = '';
        var labelHtml = '';

        for (var i = 0; i < barCount; i++) {
            var v = values[i];
            var h = (v / max) * chartHeight;
            var y = chartHeight - h;
            var x = i * (barWidth + gapPct);
            var label = labels[i] || '';
            var isLast = (i === barCount - 1);
            var isPeak = (v === max && v > 0);

            // برچسب‌های تاریخ را فقط هر ۲ روز نمایش می‌دهیم تا شلوغ نشود
            var showLabel = (i % 2 === 0) || isLast;

            var cls = 'vc-trend-bar';
            if (isPeak) cls += ' is-peak';
            if (isLast) cls += ' is-last';

            // میله‌های SVG (بدون متن — متن در HTML جداگانه نمایش داده می‌شود)
            bars += '<rect class="' + cls + '" '
                + 'x="' + x.toFixed(2) + '" '
                + 'y="' + y.toFixed(2) + '" '
                + 'width="' + barWidth.toFixed(2) + '" '
                + 'height="' + h.toFixed(2) + '" '
                + 'rx="1.5" '
                + 'data-value="' + v + '" '
                + 'data-label="' + escapeAttr(label) + '" '
                + 'data-index="' + i + '" '
                + '/>';
        }

        // SVG فقط شامل میله‌ها (بدون برچسب متنی)
        var svg = '<svg class="vc-trend-chart" '
            + 'viewBox="0 0 ' + chartWidth + ' ' + chartHeight + '" '
            + 'preserveAspectRatio="none" '
            + 'role="img" aria-label="' + escapeAttr(i18n.trendTitle || 'روند بازدید ۱۴ روز اخیر') + '">';
        svg += '<g class="vc-trend-bars">' + bars + '</g>';
        svg += '</svg>';

        // برچسب‌های تاریخ به‌صورت HTML (نه SVG) تا سایزشان طبیعی بماند
        labelHtml = '<div class="vc-trend-labels">';
        for (var j = 0; j < barCount; j++) {
            var showLabel = (j % 2 === 0) || (j === barCount - 1);
            if (showLabel) {
                var barPct = barWidth;
                var gapPctVal = barCount > 1 ? 1.5 : 0;
                var leftPct = j * (barWidth + gapPctVal) + (barWidth / 2);
                labelHtml += '<span class="vc-trend-label" style="left:' + leftPct.toFixed(2) + '%;">'
                    + escapeHtml(labels[j] || '')
                    + '</span>';
            }
        }
        labelHtml += '</div>';

        // tooltip مخفی که با هاور نمایش داده می‌شود
        var tooltip = '<div class="vc-trend-tooltip" hidden>'
            + '<span class="vc-trend-tooltip-label"></span>'
            + '<span class="vc-trend-tooltip-value"></span>'
            + '</div>';

        return '<div class="vc-trend-chart-wrap">' + svg + labelHtml + tooltip + '</div>';
    }

    function escapeHtml(str) {
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function escapeAttr(str) {
        return escapeHtml(str);
    }

    function findDashboardAnchor() {
        // پنل داشبورد TypeRenew یک گرید دو ستونه با کلاس tr-grid cols-2 دارد.
        // ویجت ما را به‌عنوان فرزند جدید به گرید اضافه می‌کنیم تا در کنار کارت خوش‌آمدگویی بنشیند.
        var grids = document.querySelectorAll('.body.container .tr-grid.cols-2');
        if (grids && grids.length) {
            return grids[0];
        }
        // جایگزین: اضافه‌کردن به انتهای محتوای اصلی
        var main = document.querySelector('main.main .body.container');
        return main || null;
    }

    function inject() {
        var dataScript = document.getElementById('vc-dashboard-data');
        if (!dataScript) return;
        var raw = dataScript.textContent || '';
        if (!raw) return;
        var data;
        try { data = JSON.parse(raw); } catch (e) { return; }
        if (!data || typeof data !== 'object') return;

        var host = findDashboardAnchor();
        if (!host) return;

        // بررسی پرچم‌های نمایش ویجت‌ها (نسخه‌ی 1.0.4)
        var showStats = data.showStats !== false; // پیش‌فرض: true
        var showTrend = data.showTrend !== false; // پیش‌فرض: true

        // ویجت اول: آمار کلی بازدید (اگر فعال باشد)
        if (showStats) {
            var wrapper1 = document.createElement('div');
            wrapper1.className = 'tr-card vc-dash-wrap';
            wrapper1.innerHTML = '<div class="tr-card-b">' + buildWidget(data) + '</div>';

            if (host.classList && host.classList.contains('tr-grid')) {
                host.appendChild(wrapper1);
            } else {
                if (host.firstChild) {
                    host.insertBefore(wrapper1, host.firstChild);
                } else {
                    host.appendChild(wrapper1);
                }
            }
        }

        // ویجت دوم: روند بازدید ۱۴ روز اخیر (اگر فعال باشد)
        if (showTrend) {
            var wrapper2 = document.createElement('div');
            wrapper2.className = 'tr-card vc-dash-wrap vc-dash-trend-wrap';
            wrapper2.innerHTML = '<div class="tr-card-b">' + buildTrendWidget(data) + '</div>';

            if (host.classList && host.classList.contains('tr-grid')) {
                host.appendChild(wrapper2);
            } else {
                if (host.firstChild) {
                    host.insertBefore(wrapper2, host.firstChild);
                } else {
                    host.appendChild(wrapper2);
                }
            }
        }

        // فعال‌سازی tooltip برای میله‌های نمودار (اگر ویجت روند نمایش داده شده)
        if (showTrend) {
            setupBarTooltips();
        }
    }

    /**
     * راه‌اندازی tooltip برای میله‌های نمودار روند
     *
     * با هاور روی هر میله، مقدار بازدید و تاریخ آن روز نمایش داده می‌شود.
     */
    function setupBarTooltips() {
        var chartWrap = document.querySelector('.vc-trend-chart-wrap');
        if (!chartWrap) return;

        var tooltip = chartWrap.querySelector('.vc-trend-tooltip');
        var tooltipLabel = chartWrap.querySelector('.vc-trend-tooltip-label');
        var tooltipValue = chartWrap.querySelector('.vc-trend-tooltip-value');
        var bars = chartWrap.querySelectorAll('.vc-trend-bar');
        var i18n = (window.__vcDashI18n || {});

        if (!tooltip || !bars.length) return;

        function showTip(bar) {
            var value = bar.getAttribute('data-value') || '0';
            var label = bar.getAttribute('data-label') || '';
            if (tooltipLabel) tooltipLabel.textContent = label;
            if (tooltipValue) {
                tooltipValue.textContent = fmtNum(value) + ' ' + (i18n.trendView || 'بازدید');
            }
            tooltip.hidden = false;
            tooltip.classList.add('is-visible');

            // موقعیت tooltip نسبت به میله
            var rect = bar.getBoundingClientRect();
            var wrapRect = chartWrap.getBoundingClientRect();
            var left = rect.left - wrapRect.left + (rect.width / 2);
            var top = rect.top - wrapRect.top - 8;
            tooltip.style.left = left + 'px';
            tooltip.style.top = top + 'px';
            tooltip.style.transform = 'translate(-50%, -100%)';
        }

        function hideTip() {
            tooltip.hidden = true;
            tooltip.classList.remove('is-visible');
        }

        bars.forEach(function (bar) {
            bar.addEventListener('mouseenter', function () { showTip(bar); });
            bar.addEventListener('mouseleave', hideTip);
            bar.addEventListener('focus', function () { showTip(bar); });
            bar.addEventListener('blur', hideTip);
        });
    }

    ready(inject);
})();
