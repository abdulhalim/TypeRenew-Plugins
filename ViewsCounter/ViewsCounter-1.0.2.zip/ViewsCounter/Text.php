<?php
declare(strict_types=1);

namespace TypechoPlugin\ViewsCounter;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * توابع کمکی متن برای escape و برش امن کاراکترها
 */
class Text
{
    /**
     * خروجی امن HTML
     *
     * @param string|null $value
     * @return string
     */
    public static function e(?string $value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }

    /**
     * برش رشته با حفظ کاراکترهای چندبایتی
     *
     * @param string|null $value
     * @param int         $max
     * @return string
     */
    public static function cut(?string $value, int $max): string
    {
        $value = (string) $value;
        if ($max <= 0 || $value === '') {
            return $max <= 0 ? '' : $value;
        }

        return mb_substr($value, 0, $max, 'UTF-8');
    }

    /**
     * قالب‌بندی عدد با جداکننده هزارگان
     *
     * @param int|string|null $value
     * @return string
     */
    public static function num($value): string
    {
        $value = (int) $value;
        return number_format($value, 0, '.', ',');
    }

    /**
     * نمایش تاریخ نسبی به سبک «مدت زمان پیش»
     *
     * @param int|string|null $timestamp
     * @return string
     */
    public static function ago($timestamp): string
    {
        $timestamp = (int) $timestamp;
        if ($timestamp <= 0) {
            return '—';
        }

        $diff = time() - $timestamp;
        if ($diff < 0) {
            $diff = 0;
        }

        if ($diff < 60) {
            return $diff . ' ثانیه پیش';
        }
        if ($diff < 3600) {
            return (int) ($diff / 60) . ' دقیقه پیش';
        }
        if ($diff < 86400) {
            return (int) ($diff / 3600) . ' ساعت پیش';
        }
        if ($diff < 2592000) {
            return (int) ($diff / 86400) . ' روز پیش';
        }
        if ($diff < 31536000) {
            return (int) ($diff / 2592000) . ' ماه پیش';
        }

        return (int) ($diff / 31536000) . ' سال پیش';
    }

    /**
     * تبدیل تاریخ میلادی (YYYY-MM-DD) به شمسی (جلالی)
     *
     * الگوریتم: محاسبه تعداد روز از 1970-01-01 میلادی (= 1348-10-11 شمسی)
     * این متد مستقل از پلاگین JalaliDate کار می‌کند تا حتی اگر آن پلاگین
     * نصب نباشد، تاریخ‌های داشبورد شمسی نمایش داده شوند.
     *
     * @param string $gregorianDate تاریخ میلادی به فرمت YYYY-MM-DD
     * @return array<int> [سال، ماه، روز] شمسی
     */
    public static function toJalali(string $gregorianDate): array
    {
        $parts = explode('-', $gregorianDate);
        if (count($parts) !== 3) {
            return [0, 0, 0];
        }

        $gy = (int) $parts[0];
        $gm = (int) $parts[1];
        $gd = (int) $parts[2];

        if ($gy < 1 || $gm < 1 || $gm > 12 || $gd < 1 || $gd > 31) {
            return [0, 0, 0];
        }

        // محاسبه تعداد روز از 1970-01-01 میلادی
        $date = gmmktime(0, 0, 0, $gm, $gd, $gy);
        $epoch = gmmktime(0, 0, 0, 1, 1, 1970);
        $daysSinceEpoch = (int) round(($date - $epoch) / 86400);

        // 1970-01-01 میلادی = 1348-10-11 شمسی
        $jy = 1348;
        $jm = 10;
        $jd = 11;
        $remaining = $daysSinceEpoch;

        // روزهای هر ماه شمسی
        $jDaysInMonth = function (int $year, int $month) {
            if ($month <= 6) return 31;
            if ($month <= 11) return 30;
            // اسفند: کبیسه؟
            $leapYears = [
                1288, 1292, 1296, 1300, 1304, 1309, 1313, 1317,
                1321, 1325, 1329, 1333, 1337, 1342, 1346, 1350,
                1354, 1358, 1362, 1366, 1370, 1375, 1379, 1383,
                1387, 1391, 1395, 1399, 1403, 1407, 1411, 1415,
                1420, 1424, 1428, 1432, 1436, 1440, 1445, 1449,
                1453, 1457, 1461, 1465, 1469, 1474, 1478, 1482,
                1486, 1490, 1494, 1498, 1503, 1507, 1511, 1515,
                1519, 1523, 1527, 1531, 1536, 1540, 1544, 1548,
                1552, 1556, 1560, 1564, 1569, 1573, 1577, 1581,
                1585, 1589, 1593, 1597, 1602, 1606, 1610, 1614,
            ];
            return in_array($year, $leapYears, true) ? 30 : 29;
        };

        if ($remaining > 0) {
            while ($remaining > 0) {
                $dim = $jDaysInMonth($jy, $jm);
                if ($jd + $remaining <= $dim) {
                    $jd += $remaining;
                    $remaining = 0;
                } else {
                    $remaining -= ($dim - $jd + 1);
                    $jd = 1;
                    if ($jm < 12) {
                        $jm++;
                    } else {
                        $jm = 1;
                        $jy++;
                    }
                }
            }
        } elseif ($remaining < 0) {
            while ($remaining < 0) {
                if ($jd + $remaining >= 1) {
                    $jd += $remaining;
                    $remaining = 0;
                } else {
                    $remaining += $jd;
                    if ($jm > 1) {
                        $jm--;
                    } else {
                        $jm = 12;
                        $jy--;
                    }
                    $jd = $jDaysInMonth($jy, $jm);
                }
            }
        }

        return [$jy, $jm, $jd];
    }

    /**
     * تبدیل تاریخ میلادی به برچسب شمسی کوتاه (مثل ۰۷/۰۳ برای ۳ مهر)
     *
     * @param string $gregorianDate تاریخ میلادی به فرمت YYYY-MM-DD
     * @return string برچسب شمسی با اعداد فارسی (مثل ۰۷/۰۳)
     */
    public static function toJalaliShort(string $gregorianDate): string
    {
        [$jy, $jm, $jd] = self::toJalali($gregorianDate);
        if ($jy === 0) {
            return $gregorianDate;
        }
        return self::faDigits(sprintf('%02d/%02d', $jm, $jd));
    }

    /**
     * تبدیل اعداد انگلیسی به فارسی
     *
     * @param string|int|null $value
     * @return string
     */
    public static function faDigits($value): string
    {
        $faDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return str_replace(range(0, 9), $faDigits, (string) $value);
    }
}
