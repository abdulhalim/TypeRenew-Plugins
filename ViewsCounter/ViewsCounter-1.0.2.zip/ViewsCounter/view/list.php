<?php
declare(strict_types=1);

/**
 * @var array<int,array<string,mixed>> $list
 * @var string                         $kind
 * @var \Widget\Options                $options
 */

use TypechoPlugin\ViewsCounter\Counter;
use TypechoPlugin\ViewsCounter\Settings;
use TypechoPlugin\ViewsCounter\Text;

if (empty($list) || !is_array($list)) {
    echo '<div class="vc-empty"><p>موردی برای نمایش یافت نشد.</p></div>';
    return;
}

$kind = $kind ?? 'post';
$resetUrl = Settings::actionUrl('reset', true);
$adminUrl = (string) $options->adminUrl;

// یک متغیر شمارش برای رتبه‌بندی
$rank = 1;
?>
<table class="vc-table">
    <thead>
        <tr>
            <th class="vc-col-rank">#</th>
            <th class="vc-col-title">عنوان</th>
            <th class="vc-col-views">بازدید</th>
            <th class="vc-col-date">تاریخ انتشار</th>
            <th class="vc-col-actions">عملیات</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($list as $item):
            $cid     = (int) ($item['cid'] ?? 0);
            $title   = (string) ($item['title'] ?? '');
            $views   = (int) ($item[Counter::COLUMN] ?? 0);
            $created = (int) ($item['created'] ?? 0);
            $type    = (string) ($item['type'] ?? $kind);
            $editUrl  = $adminUrl . 'write-' . ($type === 'page' ? 'page' : 'post') . '.php?cid=' . $cid;
            $viewUrl  = (string) $options->index . '?cid=' . $cid;
        ?>
            <tr data-cid="<?php echo Text::e((string) $cid); ?>" data-reset-url="<?php echo Text::e($resetUrl); ?>">
                <td class="vc-col-rank"><?php echo Text::e((string) $rank); ?></td>
                <td class="vc-col-title">
                    <a href="<?php echo Text::e($editUrl); ?>" title="ویرایش در پیشخوان"><?php echo Text::e($title !== '' ? $title : '(بدون عنوان)'); ?></a>
                    <small class="vc-cid">cid: <?php echo Text::e((string) $cid); ?></small>
                </td>
                <td class="vc-col-views"><span class="vc-views-num"><?php echo Text::num($views); ?></span></td>
                <td class="vc-col-date"><?php echo Text::e(Text::ago($created)); ?></td>
                <td class="vc-col-actions">
                    <a class="vc-link" href="<?php echo Text::e($viewUrl); ?>" target="_blank" rel="noopener noreferrer">مشاهده</a>
                    <button type="button" class="btn vc-reset-one" data-cid="<?php echo Text::e((string) $cid); ?>">بازنشانی</button>
                </td>
            </tr>
        <?php $rank++; endforeach; ?>
    </tbody>
</table>
