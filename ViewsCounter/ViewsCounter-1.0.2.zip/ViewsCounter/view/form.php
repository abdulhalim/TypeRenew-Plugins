<?php
declare(strict_types=1);

use TypechoPlugin\ViewsCounter\Settings;
use TypechoPlugin\ViewsCounter\Text;

/**
 * @var array<string,mixed> $settings
 */

$formAction = Settings::actionUrl('save', true);
?>
<section class="tr-card">
    <div class="tr-card-b">
        <div class="tr-panel-head">
            <div class="tr-panel-heading">
                <h3 class="tr-panel-title-sm">تنظیمات</h3>
                <p class="tr-panel-desc">تنظیمات اصلی افزونه. پس از ذخیره، بازدید مطالب از این پس با این تنظیمات شمرده می‌شود.</p>
            </div>
        </div>
        <form id="views-counter-settings" method="post" action="<?php echo Text::e($formAction); ?>" class="vc-form">
            <input type="hidden" name="do" value="save">

            <div class="vc-form-grid">
                <label class="vc-field">
                    <span>تعداد آیتم نمایش در هر لیست</span>
                    <input type="number" name="popular_limit" min="1" max="100" value="<?php echo Text::e((string) $settings['popular_limit']); ?>">
                </label>
                <label class="vc-field">
                    <span>فاصله شمارش بازدید مکرر (ثانیه)</span>
                    <input type="number" name="cookie_time" min="0" max="86400" value="<?php echo Text::e((string) $settings['cookie_time']); ?>">
                    <small>برای شمارش هر بار، روی «0» بگذارید.</small>
                </label>
                <label class="vc-field">
                    <span>شمارش بازدید کاربران واردشده</span>
                    <select name="count_logged_in">
                        <option value="0"<?php echo $settings['count_logged_in'] === '0' ? ' selected' : ''; ?>>خیر (پیش‌فرض)</option>
                        <option value="1"<?php echo $settings['count_logged_in'] === '1' ? ' selected' : ''; ?>>بله</option>
                    </select>
                </label>
                <label class="vc-field">
                    <span>شمارش برای برگه‌ها</span>
                    <select name="count_pages">
                        <option value="0"<?php echo $settings['count_pages'] === '0' ? ' selected' : ''; ?>>فقط نوشته‌ها (post)</option>
                        <option value="1"<?php echo $settings['count_pages'] === '1' ? ' selected' : ''; ?>>نوشته‌ها و برگه‌ها</option>
                    </select>
                </label>
            </div>

            <div class="vc-form-sticky">
                <button type="submit" class="btn primary">ذخیره تنظیمات</button>
            </div>
        </form>
    </div>
</section>
