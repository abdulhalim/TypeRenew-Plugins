<?php
declare(strict_types=1);

namespace TypechoPlugin\ViewsCounter;

use Typecho\Common;
use Utils\Helper;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Dashboard
{
    /**
     * رندر اسکریپت ویجت‌های آمار سریع
     */
    public static function render(): void
    {
        // فقط روی صفحه اصلی داشبورد ادمین کار می‌کنیم
        $script = (string) ($_SERVER['SCRIPT_NAME'] ?? '');
        if ($script === '' || basename($script) !== 'index.php') {
            return;
        }

        // فقط اگر واقعاً داخل پیشخوان ادمین باشیم (نه صفحه‌ی پیش‌نمایش سایت)
        if (!defined('__TYPECHO_ADMIN__')) {
            return;
        }

        // خواندن تنظیمات نمایش ویجت‌ها (نسخه‌ی 1.0.4)
        $settings = Settings::load();
        $showStats = (string) ($settings['dash_stats'] ?? '1') === '1';
        $showTrend = (string) ($settings['dash_trend'] ?? '1') === '1';

        // اگر هیچ‌کدام از ویجت‌ها فعال نبود، کاری نمی‌کنیم
        if (!$showStats && !$showTrend) {
            return;
        }

        $postsViews = Counter::sumViews(['post']);
        $pagesViews = Counter::sumViews(['page']);
        $totalViews = $postsViews + $pagesViews;
        $postsTotal = Counter::countPublished(['post']);
        $avgPerPost = $postsTotal > 0 ? (int) round($postsViews / $postsTotal) : 0;

        // داده‌های روند روزانه ۱۴ روز اخیر (فقط اگر ویجت روند فعال باشد)
        $dailyLabels = [];
        $dailyValues = [];
        $dailyTotal = 0;
        $dailyAvg = 0;
        $dailyMax = 0;

        if ($showTrend) {
            $dailySeries = Counter::dailySeries('post', 14);
            foreach ($dailySeries as $day) {
                $dateKey = (string) ($day['date_key'] ?? '');
                // تبدیل تاریخ میلادی به شمسی (مثل ۰۷/۰۳ برای ۳ مهر)
                // نکته: این تبدیل مستقل از پلاگین JalaliDate انجام می‌شود
                $dailyLabels[] = $dateKey !== '' ? Text::toJalaliShort($dateKey) : '';
                $views = (int) ($day['views'] ?? 0);
                $dailyValues[] = $views;
                $dailyTotal += $views;
            }

            // محاسبه میانگین روزانه
            $dailyAvg = count($dailyValues) > 0 ? (int) round($dailyTotal / count($dailyValues)) : 0;

            // محاسبه بیشترین بازدید روزانه
            $dailyMax = count($dailyValues) > 0 ? max($dailyValues) : 0;
        }

        $panelUrl = Settings::panelUrl();

        // داده‌ها را به JSON تبدیل می‌کنیم تا در اسکریپت استفاده شود
        $payload = [
            'total'      => $totalViews,
            'posts'      => $postsViews,
            'pages'      => $pagesViews,
            'postsCount' => $postsTotal,
            'avgPerPost' => $avgPerPost,
            'panelUrl'   => $panelUrl,
            // پرچم‌های نمایش ویجت‌ها (نسخه‌ی 1.0.4)
            'showStats'  => $showStats,
            'showTrend'  => $showTrend,
            'i18n'       => [
                'total'      => 'مجموع بازدیدها',
                'posts'      => 'بازدید نوشته‌ها',
                'pages'      => 'بازدید برگه‌ها',
                'avgPerPost' => 'میانگین به ازای هر نوشته',
                'viewDetail' => 'مشاهده جزئیات',
                'title'      => 'آمار بازدید',
                // رشته‌های ویجت نمودار روند
                'trendTitle'    => 'روند بازدید ۱۴ روز اخیر',
                'trendTotal'    => 'مجموع این دوره',
                'trendAvg'      => 'میانگین روزانه',
                'trendMax'      => 'بیشترین روز',
                'trendNoData'   => 'داده‌ای ثبت نشده',
                'trendView'     => 'بازدید',
            ],
            // داده‌های نمودار روند روزانه
            'trend'      => [
                'labels' => $dailyLabels,
                'values' => $dailyValues,
                'total'  => $dailyTotal,
                'avg'    => $dailyAvg,
                'max'    => $dailyMax,
            ],
        ];

        $json = Common::jsonEncode(
            $payload,
            JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT,
            '{}'
        );

        $cssUrl = Settings::assetUrl('assets/dashboard.css');
        $jsUrl  = Settings::assetUrl('assets/dashboard.js');
        ?>
<link rel="stylesheet" href="<?php echo Text::e($cssUrl); ?>">
<script id="vc-dashboard-data" type="application/json"><?php echo $json; ?></script>
<script src="<?php echo Text::e($jsUrl); ?>" defer></script>
        <?php
    }
}
