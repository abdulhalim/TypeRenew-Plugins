<?php
declare(strict_types=1);

namespace TypechoPlugin\ViewsCounter;

use Typecho\Db;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Migration
{
    public const DAILY_TABLE = 'viewscounter_daily';

    /**
     * اطمینان از وجود ستون views و جدول viewscounter_daily.
     *
     * @throws \Throwable
     */
    public static function ensure(): void
    {
        // 1) ستون views در جدول contents
        Counter::ensureColumn();

        // 2) جدول viewscounter_daily
        self::ensureDailyTable();
    }

    /**
     * ساخت جدول viewscounter_daily اگر وجود ندارد.
     * سازگار با MySQL / Pgsql / SQLite.
     */
    public static function ensureDailyTable(): void
    {
        $db = Db::get();
        $prefix = $db->getPrefix();
        $adapter = strtolower($db->getAdapterName());
        $table = $prefix . self::DAILY_TABLE;

        // بررسی وجود جدول
        $exists = false;
        try {
            $db->fetchRow($db->select()->from('table.' . self::DAILY_TABLE)->limit(1));
            $exists = true;
        } catch (\Throwable $e) {
            // جدول وجود ندارد
        }
        if ($exists) {
            return;
        }

        if (str_contains($adapter, 'sqlite')) {
            $sql = sprintf(
                'CREATE TABLE IF NOT EXISTS `%s` ('
                . '`id` INTEGER PRIMARY KEY AUTOINCREMENT, '
                . '`type` VARCHAR(16) NOT NULL DEFAULT \'post\', '
                . '`date_key` VARCHAR(10) NOT NULL, '
                . '`views` INTEGER NOT NULL DEFAULT 0, '
                . 'UNIQUE (`type`, `date_key`)'
                . ');',
                $table
            );
        } elseif (str_contains($adapter, 'pgsql')) {
            $sql = sprintf(
                'CREATE TABLE IF NOT EXISTS "%s" ('
                . '"id" SERIAL PRIMARY KEY, '
                . '"type" VARCHAR(16) NOT NULL DEFAULT \'post\', '
                . '"date_key" VARCHAR(10) NOT NULL, '
                . '"views" INTEGER NOT NULL DEFAULT 0, '
                . 'UNIQUE ("type", "date_key")'
                . ');',
                $table
            );
        } else {
            // MySQL / Mysqli
            $sql = sprintf(
                'CREATE TABLE IF NOT EXISTS `%s` ('
                . '`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, '
                . '`type` VARCHAR(16) NOT NULL DEFAULT \'post\', '
                . '`date_key` VARCHAR(10) NOT NULL, '
                . '`views` INT UNSIGNED NOT NULL DEFAULT 0, '
                . 'PRIMARY KEY (`id`), '
                . 'UNIQUE KEY `type_date` (`type`, `date_key`)'
                . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;',
                $table
            );
        }

        try {
            $db->query($sql, Db::WRITE);
        } catch (\Throwable $e) {
            Settings::report('ensureDailyTable', $e);
        }
    }

    /**
     * حذف جدول viewscounter_daily (هنگام غیرفعال‌سازی یا بازنشانی کامل).
     */
    public static function dropDailyTable(): void
    {
        $db = Db::get();
        $prefix = $db->getPrefix();
        $adapter = strtolower($db->getAdapterName());
        $table = $prefix . self::DAILY_TABLE;

        if (str_contains($adapter, 'pgsql')) {
            $sql = sprintf('DROP TABLE IF EXISTS "%s";', $table);
        } else {
            $sql = sprintf('DROP TABLE IF EXISTS `%s`;', $table);
        }

        try {
            $db->query($sql, Db::WRITE);
        } catch (\Throwable $e) {
            Settings::report('dropDailyTable', $e);
        }
    }
}
