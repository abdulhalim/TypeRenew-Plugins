<?php
declare(strict_types=1);

namespace TypechoPlugin\ViewsCounter;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Chart
{
    /**
     * نمودار دونات (دایره‌ای توخالی) برای توزیع نوشته/برگه.
     *
     * @param array<int,array{label:string,value:int,color?:string}> $slices
     * @param int   $size        قطر SVG بر حسب پیکسل
     * @param int   $strokeWidth ضخامت حلقه
     * @return string            SVG markup
     */
    public static function donut(array $slices, int $size = 160, int $strokeWidth = 22): string
    {
        $total = 0;
        foreach ($slices as $s) {
            $total += (int) ($s['value'] ?? 0);
        }

        $cx = $size / 2;
        $cy = $size / 2;
        $r  = ($size - $strokeWidth) / 2;
        if ($r < 1) {
            $r = 1;
        }
        $circumference = 2 * M_PI * $r;

        $offset = 0;
        $paths  = '';

        foreach ($slices as $s) {
            $value = (int) ($s['value'] ?? 0);
            if ($value <= 0 || $total <= 0) {
                continue;
            }

            $fraction = $value / $total;
            $dash     = $fraction * $circumference;
            $gap      = $circumference - $dash;
            $color    = $s['color'] ?? '#2563eb';

            $paths .= '<circle cx="' . $cx . '" cy="' . $cy . '" r="' . $r . '" '
                . 'fill="none" '
                . 'stroke="' . htmlspecialchars($color, ENT_QUOTES, 'UTF-8') . '" '
                . 'stroke-width="' . $strokeWidth . '" '
                . 'stroke-dasharray="' . number_format($dash, 4, '.', '') . ' '
                . number_format($gap, 4, '.', '') . '" '
                . 'stroke-dashoffset="' . number_format(-$offset, 4, '.', '') . '" '
                . 'transform="rotate(-90 ' . $cx . ' ' . $cy . ')" '
                . 'class="vc-donut-seg" />';

            $offset += $dash;
        }

        // اگر هیچ داده‌ای نبود، یک حلقه خاکستری نشان بده
        if ($paths === '') {
            $paths = '<circle cx="' . $cx . '" cy="' . $cy . '" r="' . $r . '" '
                . 'fill="none" stroke="#e2e8f0" stroke-width="' . $strokeWidth . '" />';
        }

        $totalLabel = Text::num($total);
        $numY       = $cy - 6;   // عدد کمی بالاتر از مرکز
        $labelY     = $cy + 14;  // برچسب «بازدید» پایین‌تر از مرکز

        $svg  = '<svg class="vc-donut" '
              . 'viewBox="0 0 ' . $size . ' ' . $size . '" '
              . 'width="' . $size . '" height="' . $size . '" '
              . 'role="img" aria-label="نمودار توزیع بازدید">';
        $svg .= '<g>' . $paths . '</g>';
        $svg .= '<text class="vc-donut-num" '
              . 'x="' . $cx . '" y="' . $numY . '" '
              . 'text-anchor="middle" dominant-baseline="central">'
              . htmlspecialchars($totalLabel, ENT_QUOTES, 'UTF-8')
              . '</text>';
        $svg .= '<text class="vc-donut-label" '
              . 'x="' . $cx . '" y="' . $labelY . '" '
              . 'text-anchor="middle">بازدید</text>';
        $svg .= '</svg>';

        return $svg;
    }

    /**
     * نمودار اسپارک‌لاین (sparkline) برای روند روزانه.
     * یک نمودار خطی کوچک بدون محور، مناسب نمایش روند.
     *
     * @param array<int,int> $values
     * @param int   $width
     * @param int   $height
     * @return string SVG markup
     */
    public static function sparkline(array $values, int $width = 320, int $height = 60): string
    {
        $values = array_values($values);
        $count  = count($values);

        if ($count === 0) {
            $svg  = '<svg class="vc-spark" '
                  . 'viewBox="0 0 ' . $width . ' ' . $height . '" '
                  . 'width="' . $width . '" height="' . $height . '" '
                  . 'role="img" aria-label="روند بازدید">';
            $svg .= '<text x="50%" y="50%" text-anchor="middle" '
                  . 'dominant-baseline="central" fill="#64748b">داده‌ای ثبت نشده</text>';
            $svg .= '</svg>';
            return $svg;
        }

        $max   = max($values);
        $min   = min($values);
        $range = $max - $min;
        if ($range <= 0) {
            $range = 1;
        }

        $padding = 4;
        $w = $width - ($padding * 2);
        $h = $height - ($padding * 2);

        $points = [];
        foreach ($values as $i => $v) {
            $x = $count > 1
                ? $padding + ($i / ($count - 1)) * $w
                : $padding + ($w / 2);
            $y = $padding + $h - (($v - $min) / $range) * $h;

            $points[] = number_format($x, 2, '.', '') . ',' . number_format($y, 2, '.', '');
        }

        $linePath = 'M' . implode(' L', $points);

        $areaPath = $linePath
            . ' L' . number_format($padding + $w, 2, '.', '') . ',' . number_format($padding + $h, 2, '.', '')
            . ' L' . number_format($padding, 2, '.', '') . ',' . number_format($padding + $h, 2, '.', '')
            . ' Z';

        // نقطه نهایی (آخرین مقدار) را با یک دایره متمایز کن
        $lastPoint = end($points);
        [$lastX, $lastY] = explode(',', $lastPoint);

        $svg  = '<svg class="vc-spark" '
              . 'viewBox="0 0 ' . $width . ' ' . $height . '" '
              . 'width="' . $width . '" height="' . $height . '" '
              . 'preserveAspectRatio="none" '
              . 'role="img" aria-label="روند بازدید">';
        $svg .= '<path class="vc-spark-area" d="' . $areaPath . '" />';
        $svg .= '<path class="vc-spark-line" d="' . $linePath . '" />';
        $svg .= '<circle class="vc-spark-dot" cx="' . $lastX . '" cy="' . $lastY . '" r="3" />';
        $svg .= '</svg>';

        return $svg;
    }

    /**
     * میله‌های افقی پیشرفته (Horizontal Progress Bars).
     * برای نمایش توزیع بازدید میان دسته‌ها، برچسب‌ها یا نویسندگان.
     *
     * @param array<int,array{label:string,value:int}> $rows
     * @param int $limit
     * @return string HTML
     */
    public static function horizontalBars(array $rows, int $limit = 8): string
    {
        $rows = array_slice($rows, 0, $limit);

        if (empty($rows)) {
            return '<p class="vc-empty">داده‌ای برای نمایش یافت نشد.</p>';
        }

        $max = 1;
        foreach ($rows as $r) {
            if ((int) $r['value'] > $max) {
                $max = (int) $r['value'];
            }
        }

        $html = '<div class="vc-hbars">';

        foreach ($rows as $r) {
            $value = (int) $r['value'];
            $label = (string) $r['label'];
            $pct   = $max > 0 ? (int) round(($value / $max) * 100) : 0;

            $html .= '<div class="vc-hbar">'
                . '<span class="vc-hbar-label" title="' . Text::e($label) . '">'
                . Text::e(Text::cut($label, 32))
                . '</span>'
                . '<div class="vc-hbar-track">'
                . '<div class="vc-hbar-fill" style="width:' . $pct . '%"></div>'
                . '</div>'
                . '<span class="vc-hbar-value">' . Text::num($value) . '</span>'
                . '</div>';
        }

        $html .= '</div>';

        return $html;
    }
}