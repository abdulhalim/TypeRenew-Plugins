<?php
declare(strict_types=1);

namespace TypechoPlugin\ViewsCounter;

use Typecho\Common;
use Typecho\Plugin\Exception as PluginException;
use Utils\Helper;
use Utils\Pref;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * ذخیره و بازیابی تنظیمات افزونه ViewsCounter
 *
 * از سازوکار Pref برای هماهنگی با کش سیستم استفاده می‌کند.
 */
class Settings
{
    public const NAME = 'ViewsCounter';

    private const CACHE_KEY = 'viewscounter:settings:v1';
    private static ?array $runtime = null;

    /**
     * پیش‌فرض‌های تنظیمات افزونه
     *
     * @return array<string,mixed>
     */
    public static function defaults(): array
    {
        return [
            'popular_limit'    => 10,
            'cookie_time'      => 3600,
            'count_logged_in'  => '0',
            'count_pages'      => '0',
            // تنظیمات نمایش ویجت‌های داشبورد اصلی (نسخه‌ی 1.0.4)
            // ۱ = نمایش داده شود، ۰ = مخفی باشد
            'dash_stats'       => '1',
            'dash_trend'       => '1',
        ];
    }

    /**
     * بارگذاری تنظیمات با کش ران‌تایم
     *
     * @return array<string,mixed>
     */
    public static function load(): array
    {
        return Pref::load(
            self::$runtime,
            self::CACHE_KEY,
            self::defaults(),
            static fn(): array => self::readStored('load.read'),
            [self::class, 'normalize'],
            [self::class, 'ensureStored'],
            [self::class, 'report']
        );
    }

    /**
     * بارگذاری مستقیم از دیتابیس بدون کش ران‌تایم
     *
     * @return array<string,mixed>
     */
    public static function loadFresh(): array
    {
        $raw = self::readStored('fresh.read');
        if ($raw === []) {
            self::ensureStored();
            $raw = self::readStored('fresh.retry');
        }

        return self::normalize(array_merge(self::defaults(), $raw));
    }

    /**
     * نرمال‌سازی مقادیر تنظیمات
     *
     * @param array<string,mixed> $settings
     * @return array<string,mixed>
     */
    public static function normalize(array $settings): array
    {
        unset($settings['cacheVer']);
        $settings = array_merge(self::defaults(), $settings);

        $settings['popular_limit'] = self::int($settings['popular_limit'] ?? 10, 1, 100, 10);
        $settings['cookie_time']   = self::int($settings['cookie_time'] ?? 3600, 0, 86400, 3600);
        $settings['count_logged_in'] = self::bool($settings['count_logged_in'] ?? '0');
        $settings['count_pages']      = self::bool($settings['count_pages'] ?? '0');
        // تنظیمات نمایش ویجت‌های داشبورد (نسخه‌ی 1.0.4)
        $settings['dash_stats'] = self::bool($settings['dash_stats'] ?? '1');
        $settings['dash_trend'] = self::bool($settings['dash_trend'] ?? '1');

        return $settings;
    }

    /**
     * ذخیره تنظیمات در دیتابیس
     *
     * @param array<string,mixed> $settings
     */
    public static function store(array $settings): void
    {
        $settings = self::normalize($settings);
        \Widget\Plugins\Edit::configPlugin(self::NAME, $settings);
        self::clear();
    }

    /**
     * اطمینان از ذخیره بودن تنظیمات (در زمان فعال‌سازی)
     */
    public static function ensureStored(): void
    {
        Pref::sync(
            self::NAME,
            self::defaults(),
            [self::class, 'normalize'],
            [self::class, 'report'],
            null,
            static fn(): array => self::readStored('ensure.read')
        );
        self::clear();
    }

    /**
     * پاک کردن کش تنظیمات
     */
    public static function clear(): void
    {
        Pref::forget(self::$runtime, self::CACHE_KEY, [self::class, 'report']);
    }

    /**
     * آدرس پنل افزونه
     *
     * @return string
     */
    public static function panelUrl(): string
    {
        return Helper::url(self::NAME . '/Panel.php');
    }

    /**
     * آدرس پنل افزونه به همراه کوئری
     *
     * @param array<string,mixed> $query
     * @return string
     */
    public static function panelQueryUrl(array $query = []): string
    {
        $clean = [];
        foreach ($query as $key => $value) {
            $value = trim((string) $value);
            if ($value !== '') {
                $clean[$key] = $value;
            }
        }

        if ($clean === []) {
            return self::panelUrl();
        }

        $url = self::panelUrl();
        return $url . (str_contains($url, '?') ? '&' : '?') . http_build_query($clean);
    }

    /**
     * آدرس اکشن افزونه (برای فرم‌ها یا درخواست‌های AJAX)
     *
     * @param string $do
     * @param bool   $secure آیا توکن امنیتی لازم است
     * @return string
     */
    public static function actionUrl(string $do = '', bool $secure = false): string
    {
        $path = '/action/views-counter';
        if ($do !== '') {
            $path .= '?do=' . rawurlencode($do);
        }

        if ($secure) {
            return \Widget\Security::alloc()->getIndex($path);
        }

        return Common::url($path, (string) Helper::options()->index);
    }

    /**
     * آدرس URL یک دارایی (CSS/JS) افزونه
     *
     * @param string $path
     * @return string
     */
    public static function assetUrl(string $path): string
    {
        $base = (string) (Helper::options()->pluginUrl ?? '');
        if ($base === '') {
            $base = Common::url('usr/plugins/', self::siteUrl());
        }

        return Common::url(self::NAME . '/' . ltrim($path, '/'), $base);
    }

    /**
     * آدرس سایت
     *
     * @return string
     */
    public static function siteUrl(): string
    {
        return rtrim((string) Helper::options()->siteUrl, '/') . '/';
    }

    /**
     * گزارش خطا
     *
     * @param string    $scope
     * @param \Throwable $e
     */
    public static function report(string $scope, \Throwable $e): void
    {
        error_log('ViewsCounter.' . $scope . ': ' . $e->getMessage());
    }

    /**
     * خواندن تنظیمات ذخیره‌شده
     *
     * @param string $scope
     * @return array<string,mixed>
     */
    private static function readStored(string $scope): array
    {
        try {
            $plugin = Helper::options()->plugin(self::NAME);
            return is_array($plugin) ? $plugin : (array) $plugin->toArray();
        } catch (PluginException) {
            return [];
        } catch (\Throwable $e) {
            self::report($scope, $e);
            return [];
        }
    }

    /**
     * تبدیل به بولین استاندارد 0/1
     *
     * @param mixed $value
     * @return string
     */
    private static function bool($value): string
    {
        return in_array((string) $value, ['1', 'true', 'on', 'yes'], true) ? '1' : '0';
    }

    /**
     * نرمال‌سازی عدد صحیح در بازه مشخص
     *
     * @param mixed $value
     * @param int   $min
     * @param int   $max
     * @param int   $default
     * @return int
     */
    private static function int($value, int $min, int $max, int $default): int
    {
        $value = filter_var($value, FILTER_VALIDATE_INT);
        if ($value === false) {
            return $default;
        }

        return max($min, min($max, (int) $value));
    }
}
