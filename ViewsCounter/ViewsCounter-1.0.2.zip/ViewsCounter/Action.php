<?php
declare(strict_types=1);

namespace TypechoPlugin\ViewsCounter;

use Widget\Notice;
use Widget\Security;
use Widget\User;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * اکشن‌های پنل: ذخیره تنظیمات / بازنشانی آمار یک مطلب / بازنشانی کل
 */
class Action extends \Typecho\Widget
{
    public function action(): void
    {
        $this->guard();
        $this->requirePost();

        $do = trim((string) $this->request->get('do'));
        match ($do) {
            'save'    => $this->save(),
            'reset'   => $this->resetOne(),
            'reset_all' => $this->resetAll(),
            default   => $this->error('عملیات ناشناخته'),
        };
    }

    /**
     * ذخیره تنظیمات
     */
    private function save(): void
    {
        $data = [];
        foreach (array_keys(Settings::defaults()) as $key) {
            if (array_key_exists($key, $_POST)) {
                $value = $_POST[$key];
                $data[$key] = is_scalar($value) ? (string) $value : '';
            }
        }

        $current = Settings::loadFresh();
        $next = array_merge($current, $data);
        Settings::store($next);

        $wantJson = $this->request->isAjax();
        if ($wantJson) {
            $this->response->setContentType('application/json');
            echo json_encode(['ok' => true, 'message' => 'تنظیمات ذخیره شد']);
            return;
        }

        Notice::alloc()->set('تنظیمات ذخیره شد', 'success');
        $this->response->redirect(Settings::panelUrl());
    }

    /**
     * بازنشانی آمار یک مطلب/برگه
     */
    private function resetOne(): void
    {
        $cid = (int) $this->request->get('cid', 0);
        if ($cid <= 0) {
            $this->error('cid نامعتبر است');
        }

        $ok = Counter::resetViews($cid);

        if ($this->request->isAjax()) {
            $this->response->setContentType('application/json');
            echo json_encode([
                'ok'      => $ok,
                'cid'     => $cid,
                'views'   => 0,
                'message' => $ok ? 'بازدید این مطلب به صفر بازنشانی شد' : 'بازنشانی ناموفق بود',
            ]);
            return;
        }

        Notice::alloc()->set(
            $ok ? 'بازدید این مطلب به صفر بازنشانی شد' : 'بازنشانی ناموفق بود',
            $ok ? 'success' : 'error'
        );
        $this->response->redirect(Settings::panelUrl());
    }

    /**
     * بازنشانی کل آمار (مطالب و برگه‌ها)
     */
    private function resetAll(): void
    {
        $scope = trim((string) $this->request->get('scope', 'all'));
        $types = match ($scope) {
            'posts'  => ['post'],
            'pages'  => ['page'],
            default  => ['post', 'page'],
        };

        $ok = Counter::resetAllViews($types);
        // همچنین جدول روزانه را هم پاک می‌کنیم تا نمودارها هم از صفر شروع شوند
        if ($ok) {
            Counter::clearDaily();
        }

        if ($this->request->isAjax()) {
            $this->response->setContentType('application/json');
            echo json_encode([
                'ok'      => $ok,
                'scope'   => $scope,
                'message' => $ok ? 'بازنشانی انجام شد' : 'بازنشانی ناموفق بود',
            ]);
            return;
        }

        Notice::alloc()->set(
            $ok ? 'بازنشانی انجام شد' : 'بازنشانی ناموفق بود',
            $ok ? 'success' : 'error'
        );
        $this->response->redirect(Settings::panelUrl());
    }

    /**
     * بررسی دسترسی و توکن امنیتی
     */
    private function guard(): void
    {
        User::alloc()->pass('administrator');
        Security::alloc()->protect();
    }

    /**
     * فقط درخواست POST مجاز است
     */
    private function requirePost(): void
    {
        if ($this->request->isPost()) {
            return;
        }

        $this->response->setStatus(405);
        $this->error('این عملیات باید از طریق درخواست POST ارسال شود');
    }

    /**
     * خطا
     *
     * @param string $message
     */
    private function error(string $message): void
    {
        if ($this->request->isAjax()) {
            $this->response->setContentType('application/json');
            $this->response->setStatus(400);
            echo json_encode(['ok' => false, 'message' => $message]);
            exit;
        }

        Notice::alloc()->set($message, 'error');
        $this->response->redirect(Settings::panelUrl());
        exit;
    }
}
