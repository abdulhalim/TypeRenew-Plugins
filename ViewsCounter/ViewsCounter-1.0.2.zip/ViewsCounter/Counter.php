<?php
declare(strict_types=1);

namespace TypechoPlugin\ViewsCounter;

use Typecho\Cookie;
use Typecho\Db;
use Widget\Archive;
use Widget\User;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Counter
{
    /** نام ستون بازدید در جدول contents */
    public const COLUMN = 'views';

    /** نام کوکی ذخیره‌ی cidهای اخیراً دیده‌شده */
    public const COOKIE_KEY = '__viewsCounter';

    /** ستون از قبل در جدول وجود دارد؟ */
    private static ?bool $columnExists = null;

    /**
     * ستون views را به جدول contents اضافه می‌کند (در صورت نبود).
     * سازگار با MySQL / Pgsql / SQLite.
     *
     * @throws \Throwable
     */
    public static function ensureColumn(): void
    {
        if (self::$columnExists === true) {
            return;
        }

        $db = Db::get();
        $prefix = $db->getPrefix();
        $adapter = strtolower($db->getAdapterName());

        try {
            $row = $db->fetchRow($db->select()->from('table.contents')->limit(1));
        } catch (\Throwable $e) {
            // جدول خالی است؛ می‌توان از information_schema استفاده کرد
            $row = [];
        }

        if (is_array($row) && array_key_exists(self::COLUMN, $row)) {
            self::$columnExists = true;
            return;
        }

        // قطعه ALTER TABLE برای هر دیتابیس
        $table = $prefix . 'contents';
        $column = self::COLUMN;

        if (str_contains($adapter, 'sqlite')) {
            // SQLite از ADD COLUMN با DEFAULT پشتیبانی می‌کند
            $sql = sprintf('ALTER TABLE `%s` ADD COLUMN `%s` INTEGER NOT NULL DEFAULT 0;', $table, $column);
        } elseif (str_contains($adapter, 'pgsql')) {
            // Pgsql از کوتیشن دوتایی برای شناسه‌ها استفاده می‌کند
            $sql = sprintf('ALTER TABLE "%s" ADD COLUMN "%s" INTEGER NOT NULL DEFAULT 0;', $table, $column);
        } else {
            // پیش‌فرض: MySQL / Mysqli (شامل Pdo\Mysql)
            $sql = sprintf('ALTER TABLE `%s` ADD `%s` INT NOT NULL DEFAULT 0;', $table, $column);
        }

        try {
            $db->query($sql, Db::WRITE);
        } catch (\Throwable $e) {
            // شاید ستون از قبل وجود دارد (خطای همزمانی فعال‌سازی)
            Settings::report('ensureColumn', $e);
        }

        self::$columnExists = true;
    }

    /**
     * ثبت یک بازدید برای نوشته/برگه فعلی
     *
     * @param Archive $archive
     */
    public static function record(Archive $archive): void
    {
        // اطمینان از وجود ستون و جدول روزانه
        if (self::$columnExists === null) {
            self::ensureColumn();
        }
        Migration::ensureDailyTable();

        $settings = Settings::load();

        // اگر کاربر واردشده است و شمارش برای آن‌ها غیرفعال است، رد شو
        if ($settings['count_logged_in'] === '0') {
            $user = User::alloc();
            if ($user->hasLogin()) {
                return;
            }
        }

        // فقط صفحات تک‌نوشته
        if (!$archive->is('single')) {
            return;
        }

        // فقط روی نوشته‌ها شمارش شود یا برگه‌ها هم؟
        $type = (string) $archive->type;
        $allowTypes = ['post'];
        if ($settings['count_pages'] === '1') {
            $allowTypes[] = 'page';
        }
        if (!in_array($type, $allowTypes, true)) {
            return;
        }

        // مطالب رمزدار را نشمار
        if (!empty($archive->hidden)) {
            return;
        }

        $cid = (int) $archive->cid;
        if ($cid <= 0) {
            return;
        }

        $cookieTime = (int) $settings['cookie_time'];
        $cids = (string) (Cookie::get(self::COOKIE_KEY) ?? '');

        // اگر cookie_time صفر باشد، یعنی هر بار شمارش شود
        if ($cookieTime > 0) {
            $list = $cids === '' ? [] : explode(',', $cids);
            if (in_array((string) $cid, $list, true)) {
                return;
            }
        }

        // گرفتن تعداد فعلی
        $db = Db::get();
        try {
            $row = $db->fetchRow(
                $db->select(self::COLUMN)->from('table.contents')->where('cid = ?', $cid)
            );
        } catch (\Throwable $e) {
            Settings::report('record.select', $e);
            return;
        }

        $current = isset($row[self::COLUMN]) ? (int) $row[self::COLUMN] : 0;

        try {
            $db->query(
                $db->update('table.contents')
                    ->rows([self::COLUMN => $current + 1])
                    ->where('cid = ?', $cid),
                Db::WRITE
            );
        } catch (\Throwable $e) {
            Settings::report('record.update', $e);
            return;
        }

        // به‌روزرسانی جدول روزانه (برای نمودار روند)
        self::bumpDaily($type);

        // به‌روزرسانی کوکی
        if ($cookieTime > 0) {
            $list = $cids === '' ? [] : explode(',', $cids);
            $list[] = (string) $cid;
            // جلوگیری از رشد بی‌نهایت کوکی
            if (count($list) > 200) {
                $list = array_slice($list, -200);
            }
            Cookie::set(self::COOKIE_KEY, implode(',', $list), time() + $cookieTime);
        }
    }

    /**
     * افزایش شمارنده روزانه برای یک نوع (post/page).
     * اگر ردیف امروز وجود نداشت، ساخته می‌شود.
     *
     * @param string $type 'post' یا 'page'
     */
    private static function bumpDaily(string $type): void
    {
        $dateKey = self::todayKey();
        $db = Db::get();

        try {
            // تلاش برای INSERT و در صورت تکراری بودن، UPDATE.
            $adapter = strtolower($db->getAdapterName());
            $prefix = $db->getPrefix();
            $table = $prefix . Migration::DAILY_TABLE;
            $adapterObj = $db->getAdapter();

            $typeQ = $adapterObj->quoteValue($type);
            $dateQ = $adapterObj->quoteValue($dateKey);

            if (str_contains($adapter, 'sqlite')) {
                $sql = sprintf(
                    'INSERT INTO `%s` (`type`, `date_key`, `views`) VALUES (%s, %s, 1) '
                    . 'ON CONFLICT(`type`, `date_key`) DO UPDATE SET `views` = `views` + 1;',
                    $table, $typeQ, $dateQ
                );
            } elseif (str_contains($adapter, 'pgsql')) {
                $sql = sprintf(
                    'INSERT INTO "%s" ("type", "date_key", "views") VALUES (%s, %s, 1) '
                    . 'ON CONFLICT("type", "date_key") DO UPDATE SET "views" = "views" + 1;',
                    $table, $typeQ, $dateQ
                );
            } else {
                // MySQL
                $sql = sprintf(
                    'INSERT INTO `%s` (`type`, `date_key`, `views`) VALUES (%s, %s, 1) '
                    . 'ON DUPLICATE KEY UPDATE `views` = `views` + 1;',
                    $table, $typeQ, $dateQ
                );
            }
            $db->query($sql, Db::WRITE);
        } catch (\Throwable $e) {
            // اگر ON CONFLICT پشتیبانی نمی‌شود، روش fallback: SELECT + UPDATE/INSERT
            Settings::report('bumpDaily', $e);
            self::bumpDailyFallback($type, $dateKey);
        }
    }

    /**
     * روش جایگزین bumpDaily برای دیتابیس‌های قدیمی.
     */
    private static function bumpDailyFallback(string $type, string $dateKey): void
    {
        $db = Db::get();
        try {
            $row = $db->fetchRow(
                $db->select('views')->from('table.' . Migration::DAILY_TABLE)
                    ->where('type = ?', $type)
                    ->where('date_key = ?', $dateKey)
            );
            if (is_array($row) && isset($row['views'])) {
                $db->query(
                    $db->update('table.' . Migration::DAILY_TABLE)
                        ->rows(['views' => (int) $row['views'] + 1])
                        ->where('type = ?', $type)
                        ->where('date_key = ?', $dateKey),
                    Db::WRITE
                );
            } else {
                $db->query(
                    $db->insert('table.' . Migration::DAILY_TABLE)
                        ->rows([
                            'type'     => $type,
                            'date_key' => $dateKey,
                            'views'    => 1,
                        ]),
                    Db::WRITE
                );
            }
        } catch (\Throwable $e) {
            Settings::report('bumpDailyFallback', $e);
        }
    }

    /**
     * کلید تاریخ امروز به‌فرمت YYYY-MM-DD در منطقه‌ی زمانی تهران.
     *
     * @return string
     */
    private static function todayKey(): string
    {
        try {
            $tz = new \DateTimeZone('Asia/Tehran');
            return (new \DateTime('now', $tz))->format('Y-m-d');
        } catch (\Throwable $e) {
            return date('Y-m-d');
        }
    }

    /**
     * گرفتن تعداد بازدید یک مطلب با cid
     *
     * @param int $cid
     * @return int
     */
    public static function getViewsById(int $cid): int
    {
        if ($cid <= 0) {
            return 0;
        }
        if (self::$columnExists === null) {
            self::ensureColumn();
        }

        $db = Db::get();
        try {
            $row = $db->fetchRow(
                $db->select(self::COLUMN)->from('table.contents')->where('cid = ?', $cid)
            );
        } catch (\Throwable $e) {
            Settings::report('getViewsById', $e);
            return 0;
        }

        return isset($row[self::COLUMN]) ? (int) $row[self::COLUMN] : 0;
    }

    /**
     * گرفتن تعداد بازدید مطلب جاری (در قالب)
     *
     * @return int
     */
    public static function getViews(): int
    {
        $archive = Archive::alloc();
        $cid = (int) ($archive->cid ?? 0);
        return $cid > 0 ? self::getViewsById($cid) : 0;
    }

    /**
     * لیست پربازدیدترین مطالب (post)
     *
     * @param int $limit
     * @return array<int,array<string,mixed>>
     */
    public static function getMostViewedPosts(int $limit = 10): array
    {
        return self::getMostViewed(['post'], $limit);
    }

    /**
     * لیست پربازدیدترین برگه‌ها (page)
     *
     * @param int $limit
     * @return array<int,array<string,mixed>>
     */
    public static function getMostViewedPages(int $limit = 10): array
    {
        return self::getMostViewed(['page'], $limit);
    }

    /**
     * مشترک گرفتن لیست پربازدیدترین‌ها
     *
     * @param array<int,string> $types
     * @param int               $limit
     * @return array<int,array<string,mixed>>
     */
    private static function getMostViewed(array $types, int $limit): array
    {
        if ($limit <= 0) {
            return [];
        }
        if (self::$columnExists === null) {
            self::ensureColumn();
        }

        $db = Db::get();
        $types = array_values($types);
        $placeholders = implode(',', array_fill(0, count($types), '?'));

        try {
            // کوئری دستی برای مرتب‌سازی روی views (سازگار با هر سه دیتابیس)
            $sql = $db->select('cid', 'title', 'slug', 'type', 'status', 'created', 'modified', 'authorId', self::COLUMN)
                ->from('table.contents')
                ->where('type IN (' . $placeholders . ')', ...$types)
                ->where('status = ?', 'publish')
                ->where('password IS NULL')
                ->order(self::COLUMN, Db::SORT_DESC)
                ->order('created', Db::SORT_DESC)
                ->limit($limit);

            return $db->fetchAll($sql);
        } catch (\Throwable $e) {
            Settings::report('getMostViewed', $e);
            return [];
        }
    }

    /**
     * مجموع کل بازدیدها برای نوع مشخص
     *
     * @param array<int,string> $types
     * @return int
     */
    public static function sumViews(array $types): int
    {
        if (self::$columnExists === null) {
            self::ensureColumn();
        }
        if ($types === []) {
            return 0;
        }

        $db = Db::get();
        $placeholders = implode(',', array_fill(0, count($types), '?'));

        try {
            $row = $db->fetchRow(
                $db->select('SUM(' . self::COLUMN . ') AS total')
                    ->from('table.contents')
                    ->where('type IN (' . $placeholders . ')', ...$types)
                    ->where('status = ?', 'publish')
            );
            return isset($row['total']) ? (int) $row['total'] : 0;
        } catch (\Throwable $e) {
            Settings::report('sumViews', $e);
            return 0;
        }
    }

    /**
     * تعداد کل مطالب/برگه‌های منتشرشده
     *
     * @param array<int,string> $types
     * @return int
     */
    public static function countPublished(array $types): int
    {
        if ($types === []) {
            return 0;
        }

        $db = Db::get();
        $placeholders = implode(',', array_fill(0, count($types), '?'));

        try {
            $row = $db->fetchRow(
                $db->select('COUNT(*) AS cnt')
                    ->from('table.contents')
                    ->where('type IN (' . $placeholders . ')', ...$types)
                    ->where('status = ?', 'publish')
            );
            return isset($row['cnt']) ? (int) $row['cnt'] : 0;
        } catch (\Throwable $e) {
            Settings::report('countPublished', $e);
            return 0;
        }
    }

    /**
     * بازنشانی تعداد بازدید یک مطلب به صفر
     *
     * @param int $cid
     * @return bool
     */
    public static function resetViews(int $cid): bool
    {
        if ($cid <= 0) {
            return false;
        }
        if (self::$columnExists === null) {
            self::ensureColumn();
        }

        $db = Db::get();
        try {
            $db->query(
                $db->update('table.contents')
                    ->rows([self::COLUMN => 0])
                    ->where('cid = ?', $cid),
                Db::WRITE
            );
            return true;
        } catch (\Throwable $e) {
            Settings::report('resetViews', $e);
            return false;
        }
    }

    /**
     * بازنشانی کل آمار بازدید برای یک نوع
     *
     * @param array<int,string> $types
     * @return bool
     */
    public static function resetAllViews(array $types): bool
    {
        if ($types === []) {
            return false;
        }
        if (self::$columnExists === null) {
            self::ensureColumn();
        }

        $db = Db::get();

        try {
            $prefix = $db->getPrefix();
            $table = $prefix . 'contents';
            $adapter = $db->getAdapter();
            $adapterName = strtolower($db->getAdapterName());
            $typeList = implode(',', array_map(static fn($t) => $adapter->quoteValue($t), $types));
            $tbl = $adapterName !== '' && str_contains($adapterName, 'pgsql')
                ? '"' . $table . '"'
                : '`' . $table . '`';
            $col = $adapterName !== '' && str_contains($adapterName, 'pgsql')
                ? '"' . self::COLUMN . '"'
                : '`' . self::COLUMN . '`';
            $sql = sprintf(
                'UPDATE %s SET %s = 0 WHERE type IN (%s) AND status = %s;',
                $tbl,
                $col,
                $typeList,
                $adapter->quoteValue('publish')
            );
            $db->query($sql, Db::WRITE);
            return true;
        } catch (\Throwable $e) {
            Settings::report('resetAllViews', $e);
            return false;
        }
    }

    /**
     * سری روزانه بازدید در N روز اخیر برای یک نوع خاص.
     *
     * @param string $type  'post' یا 'page'
     * @param int    $days  تعداد روز (پیش‌فرض ۱۴)
     * @return array<int,array{date_key:string,views:int}>
     */
    public static function dailySeries(string $type, int $days = 14): array
    {
        if ($days <= 0) {
            return [];
        }
        Migration::ensureDailyTable();

        $db = Db::get();
        $rows = [];

        try {
            $rows = $db->fetchAll(
                $db->select('date_key', 'views')
                    ->from('table.' . Migration::DAILY_TABLE)
                    ->where('type = ?', $type)
                    ->where('date_key >= ?', self::relativeDate("-{$days} days"))
                    ->order('date_key', Db::SORT_ASC)
            );
        } catch (\Throwable $e) {
            Settings::report('dailySeries', $e);
            return [];
        }

        // پر کردن روزهای خالی با صفر تا نمودار پیوسته باشد
        $byKey = [];
        foreach ($rows as $r) {
            $byKey[$r['date_key']] = (int) $r['views'];
        }

        $out = [];
        for ($i = $days; $i >= 0; $i--) {
            $key = self::relativeDate("-{$i} days");
            $out[] = [
                'date_key' => $key,
                'views'    => $byKey[$key] ?? 0,
            ];
        }
        return $out;
    }

    /**
     * تاریخ نسبی به‌فرمت YYYY-MM-DD در منطقه‌ی تهران.
     *
     * @param string $modifier
     * @return string
     */
    private static function relativeDate(string $modifier): string
    {
        try {
            $tz = new \DateTimeZone('Asia/Tehran');
            return (new \DateTime($modifier, $tz))->format('Y-m-d');
        } catch (\Throwable $e) {
            return date('Y-m-d', strtotime($modifier));
        }
    }

    /**
     * جمع‌بندی بازدید دسته‌بندی‌ها (Category Breakdown).
     * تعداد بازدید هر دسته = مجموع بازدید نوشته‌های آن دسته.
     *
     * @param int $limit
     * @return array<int,array{label:string,value:int}>
     */
    public static function categoryBreakdown(int $limit = 8): array
    {
        if (self::$columnExists === null) {
            self::ensureColumn();
        }

        $db = Db::get();
        try {
            // پیوند contents + relationships + metas
            $sql = $db->select([
                'm.name' => 'name',
                'SUM(c.' . self::COLUMN . ')' => 'total',
            ])
                ->from('table.contents c')
                ->join('table.relationships r', 'c.cid = r.cid', Db::INNER_JOIN)
                ->join('table.metas m', 'r.mid = m.mid', Db::INNER_JOIN)
                ->where('c.type = ?', 'post')
                ->where('c.status = ?', 'publish')
                ->where('m.type = ?', 'category')
                ->group('m.mid')
                ->order('total', Db::SORT_DESC)
                ->limit($limit);

            $rows = $db->fetchAll($sql);
            $out = [];
            foreach ($rows as $r) {
                $out[] = [
                    'label' => (string) ($r['name'] ?? ''),
                    'value' => (int) ($r['total'] ?? 0),
                ];
            }
            return $out;
        } catch (\Throwable $e) {
            Settings::report('categoryBreakdown', $e);
            return [];
        }
    }

    /**
     * جمع‌بندی بازدید برچسب‌ها (Tag Breakdown).
     *
     * @param int $limit
     * @return array<int,array{label:string,value:int}>
     */
    public static function tagBreakdown(int $limit = 8): array
    {
        if (self::$columnExists === null) {
            self::ensureColumn();
        }

        $db = Db::get();
        try {
            $sql = $db->select([
                'm.name' => 'name',
                'SUM(c.' . self::COLUMN . ')' => 'total',
            ])
                ->from('table.contents c')
                ->join('table.relationships r', 'c.cid = r.cid', Db::INNER_JOIN)
                ->join('table.metas m', 'r.mid = m.mid', Db::INNER_JOIN)
                ->where('c.type = ?', 'post')
                ->where('c.status = ?', 'publish')
                ->where('m.type = ?', 'tag')
                ->group('m.mid')
                ->order('total', Db::SORT_DESC)
                ->limit($limit);

            $rows = $db->fetchAll($sql);
            $out = [];
            foreach ($rows as $r) {
                $out[] = [
                    'label' => (string) ($r['name'] ?? ''),
                    'value' => (int) ($r['total'] ?? 0),
                ];
            }
            return $out;
        } catch (\Throwable $e) {
            Settings::report('tagBreakdown', $e);
            return [];
        }
    }

    /**
     * جمع‌بندی بازدید بر اساس نویسنده (Author Breakdown).
     *
     * @param int $limit
     * @return array<int,array{label:string,value:int}>
     */
    public static function authorBreakdown(int $limit = 8): array
    {
        if (self::$columnExists === null) {
            self::ensureColumn();
        }

        $db = Db::get();
        try {
            $sql = $db->select([
                'u.screenName' => 'name',
                'SUM(c.' . self::COLUMN . ')' => 'total',
            ])
                ->from('table.contents c')
                ->join('table.users u', 'c.authorId = u.uid', Db::LEFT_JOIN)
                ->where('c.type = ?', 'post')
                ->where('c.status = ?', 'publish')
                ->group('c.authorId')
                ->order('total', Db::SORT_DESC)
                ->limit($limit);

            $rows = $db->fetchAll($sql);
            $out = [];
            foreach ($rows as $r) {
                $out[] = [
                    'label' => (string) ($r['name'] ?? 'ناشناس'),
                    'value' => (int) ($r['total'] ?? 0),
                ];
            }
            return $out;
        } catch (\Throwable $e) {
            Settings::report('authorBreakdown', $e);
            return [];
        }
    }

    /**
     * پاکسازی جدول روزانه (هنگام بازنشانی کامل).
     *
     * @return bool
     */
    public static function clearDaily(): bool
    {
        Migration::ensureDailyTable();
        $db = Db::get();
        try {
            $adapterName = strtolower($db->getAdapterName());
            $prefix = $db->getPrefix();
            $table = $prefix . Migration::DAILY_TABLE;
            $tbl = str_contains($adapterName, 'pgsql') ? '"' . $table . '"' : '`' . $table . '`';
            $db->query('DELETE FROM ' . $tbl . ';', Db::WRITE);
            return true;
        } catch (\Throwable $e) {
            Settings::report('clearDaily', $e);
            return false;
        }
    }
}
