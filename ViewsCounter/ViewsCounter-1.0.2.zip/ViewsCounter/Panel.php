<?php
declare(strict_types=1);

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

use TypechoPlugin\ViewsCounter\Chart;
use TypechoPlugin\ViewsCounter\Counter;
use TypechoPlugin\ViewsCounter\Migration;
use TypechoPlugin\ViewsCounter\Settings;
use TypechoPlugin\ViewsCounter\Text;

$user->pass('administrator');
$settings = Settings::loadFresh();
$popularLimit = (int) ($settings['popular_limit'] > 0 ? $settings['popular_limit'] : 10);

// اطمینان از وجود جدول روزانه
try {
    Migration::ensure();
} catch (\Throwable $e) {
    Settings::report('panel.ensure', $e);
}

// آمار کلی
$postsTotal      = Counter::countPublished(['post']);
$pagesTotal      = Counter::countPublished(['page']);
$postsViewsTotal = Counter::sumViews(['post']);
$pagesViewsTotal = Counter::sumViews(['page']);
$allViewsTotal   = $postsViewsTotal + $pagesViewsTotal;

// لیست‌های پربازدیدترین‌ها
$topPosts = Counter::getMostViewedPosts($popularLimit);
$topPages = Counter::getMostViewedPages($popularLimit);

// سری روزانه برای نمودار اسپارک‌لاین (۱۴ روز اخیر)
$dailyPosts = Counter::dailySeries('post', 14);
$dailyPages = Counter::dailySeries('page', 14);
$sparkPosts = array_map(static fn($r) => (int) $r['views'], $dailyPosts);
$sparkPages = array_map(static fn($r) => (int) $r['views'], $dailyPages);

// تفکیک دسته‌بندی، برچسب و نویسنده
$categoryRows = Counter::categoryBreakdown(8);
$tagRows       = Counter::tagBreakdown(8);
$authorRows    = Counter::authorBreakdown(8);

// برچسب‌های ۱۴ روز برای نمایش زیر نمودار اسپارک‌لاین
$sparkLabels = array_map(static function ($r) {
    return $r['date_key'];
}, $dailyPosts);
$firstLabel = $sparkLabels[0] ?? '';
$lastLabel  = $sparkLabels[count($sparkLabels) - 1] ?? '';

// داده‌های دونات (توزیع نوشته/برگه) — رنگ‌ها به‌صورت hex صریح
// تا در attribute stroke مربوط به SVG به‌درستی resolve شوند.
$donutSlices = [];
if ($postsViewsTotal > 0) {
    $donutSlices[] = [
        'label' => 'نوشته‌ها',
        'value' => $postsViewsTotal,
        'color' => '#2563eb', // آبی
    ];
}
if ($pagesViewsTotal > 0) {
    $donutSlices[] = [
        'label' => 'برگه‌ها',
        'value' => $pagesViewsTotal,
        'color' => '#10b981', // سبز
    ];
}
if (empty($donutSlices)) {
    $donutSlices = [
        ['label' => 'بدون داده', 'value' => 0, 'color' => '#e2e8f0'],
    ];
}

// متن راهنمای دستی برای ستون views
$columnOk = true;
try {
    $db = \Typecho\Db::get();
    $row = $db->fetchRow($db->select()->from('table.contents')->limit(1));
    if (!is_array($row) || !array_key_exists(Counter::COLUMN, $row)) {
        $columnOk = false;
    }
} catch (\Throwable $e) {
    $columnOk = false;
}

// آدرس‌ها
$adminUrl = (string) $options->adminUrl;
?>
<link rel="stylesheet" href="<?php echo Text::e(Settings::assetUrl('assets/panel.css')); ?>">
<div class="tr-panel tr-panel-views" dir="rtl">
    <section class="tr-card">
        <div class="tr-card-b">
            <div class="tr-panel-head">
                <div class="tr-panel-heading">
                    <h2 class="tr-panel-title">بازدید مطالب</h2>
                    <p class="tr-panel-desc">نمای سبک از تعداد بازدید نوشته‌ها و برگه‌ها. این افزونه فقط شمارش خام بازدید را نگه می‌دارد (نه IP، نه User-Agent، نه Referrer) تا حریم خصوصی کاربران حفظ شود و دیتابیس سبک بماند.</p>
                </div>
                <div class="tr-panel-pills">
                    <span class="tr-pill<?php echo $columnOk ? ' tr-pill-accent' : ''; ?>"><?php echo $columnOk ? 'آماده' : 'نیاز به فعال‌سازی مجدد'; ?></span>
                    <span class="tr-pill">سقف نمایش: <?php echo Text::e((string) $popularLimit); ?> مورد</span>
                </div>
            </div>
        </div>
    </section>

    <?php if (!$columnOk): ?>
        <section class="tr-card tr-card-warn">
            <div class="tr-card-b">
                <div class="vc-warn">
                    <strong>ستون views در جدول contents یافت نشد.</strong>
                    <p>این اتفاق معمولاً زمانی رخ می‌دهد که افزونه به‌درستی فعال نشده است. لطفاً افزونه ViewsCounter را از بخش «افزونه‌ها» غیرفعال و سپس دوباره فعال کنید تا ستون مربوطه و جدول روزانه به‌صورت خودکار ساخته شوند.</p>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <!-- KPI tiles -->
    <div class="tr-panel-kpis">
        <article class="tr-panel-kpi"><strong><?php echo Text::num($allViewsTotal); ?></strong><span>مجموع کل بازدیدها</span></article>
        <article class="tr-panel-kpi"><strong><?php echo Text::num($postsViewsTotal); ?></strong><span>بازدید نوشته‌ها</span></article>
        <article class="tr-panel-kpi"><strong><?php echo Text::num($pagesViewsTotal); ?></strong><span>بازدید برگه‌ها</span></article>
        <article class="tr-panel-kpi"><strong><?php echo Text::num($postsTotal + $pagesTotal); ?></strong><span>مطالب منتشرشده</span></article>
    </div>

    <!-- Donut + Sparkline row -->
    <section class="tr-card">
        <div class="tr-card-b vc-grid-2">
            <!-- Donut: توزیع نوشته/برگه -->
            <div class="vc-donut-wrap">
                <div class="vc-section-head">
                    <h3>توزیع بازدید</h3>
                    <p>سهم نوشته‌ها و برگه‌ها از کل بازدیدها.</p>
                </div>
                <div class="vc-donut-row">
                    <?php echo Chart::donut($donutSlices, 160, 22); ?>
                    <ul class="vc-donut-legend">
                        <?php foreach ($donutSlices as $slice): ?>
                            <li>
                                <span class="vc-legend-dot" style="background: <?php echo Text::e($slice['color']); ?>"></span>
                                <span class="vc-legend-label"><?php echo Text::e($slice['label']); ?></span>
                                <span class="vc-legend-value"><?php echo Text::num($slice['value']); ?></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>

            <!-- Sparkline: روند ۱۴ روز اخیر -->
            <div class="vc-spark-wrap">
                <div class="vc-section-head">
                    <h3>روند بازدید ۱۴ روز اخیر</h3>
                    <p>روند روزانه بازدید نوشته‌ها (آبی) و برگه‌ها (سبز).</p>
                </div>
                <div class="vc-spark-stack">
                    <div class="vc-spark-item">
                        <div class="vc-spark-head">
                            <span class="vc-spark-label"><span class="vc-legend-dot" style="background: var(--tr-accent, #2563eb);"></span>نوشته‌ها</span>
                            <span class="vc-spark-total"><?php echo Text::num(array_sum($sparkPosts)); ?> بازدید</span>
                        </div>
                        <?php echo Chart::sparkline($sparkPosts, 320, 56); ?>
                    </div>
                    <div class="vc-spark-item">
                        <div class="vc-spark-head">
                            <span class="vc-spark-label"><span class="vc-legend-dot" style="background: #10b981;"></span>برگه‌ها</span>
                            <span class="vc-spark-total"><?php echo Text::num(array_sum($sparkPages)); ?> بازدید</span>
                        </div>
                        <?php echo Chart::sparkline($sparkPages, 320, 56); ?>
                    </div>
                </div>
                <div class="vc-spark-axis">
                    <span><?php echo $firstLabel !== '' ? Text::e(Text::ago((string) strtotime($firstLabel))) . ' · ' . Text::e($firstLabel) : '—'; ?></span>
                    <span><?php echo $lastLabel !== '' ? 'امروز · ' . Text::e($lastLabel) : '—'; ?></span>
                </div>
            </div>
        </div>
    </section>

    <!-- Breakdowns: دسته / برچسب / نویسنده -->
    <section class="tr-card">
        <div class="tr-card-b">
            <div class="tr-panel-head">
                <div class="tr-panel-heading">
                    <h3 class="tr-panel-title-sm">تفکیک بازدید بر اساس</h3>
                    <p class="tr-panel-desc">نمای کلی توزیع بازدید میان دسته‌ها، برچسب‌ها و نویسندگان.</p>
                </div>
            </div>
            <div class="vc-grid-3">
                <div class="vc-breakdown">
                    <h4>دسته‌بندی‌ها</h4>
                    <?php echo Chart::horizontalBars($categoryRows, 8); ?>
                </div>
                <div class="vc-breakdown">
                    <h4>برچسب‌ها</h4>
                    <?php echo Chart::horizontalBars($tagRows, 8); ?>
                </div>
                <div class="vc-breakdown">
                    <h4>نویسندگان</h4>
                    <?php echo Chart::horizontalBars($authorRows, 8); ?>
                </div>
            </div>
        </div>
    </section>

    <!-- Top posts list -->
    <section class="tr-card">
        <div class="tr-card-b">
            <div class="tr-panel-head">
                <div class="tr-panel-heading">
                    <h3 class="tr-panel-title-sm">پربازدیدترین نوشته‌ها</h3>
                    <p class="tr-panel-desc">فهرست <?php echo Text::e((string) $popularLimit); ?> نوشته با بیشترین تعداد بازدید.</p>
                </div>
                <div class="tr-panel-pills">
                    <button type="button" class="btn vc-reset-all" data-scope="posts" data-token-url="<?php echo Text::e(Settings::actionUrl('reset_all', true)); ?>">بازنشانی آمار نوشته‌ها</button>
                </div>
            </div>
            <?php
                $list = $topPosts;
                $kind = 'post';
                require __DIR__ . '/view/list.php';
            ?>
        </div>
    </section>

    <?php if ($settings['count_pages'] === '1'): ?>
        <section class="tr-card">
            <div class="tr-card-b">
                <div class="tr-panel-head">
                    <div class="tr-panel-heading">
                        <h3 class="tr-panel-title-sm">پربازدیدترین برگه‌ها</h3>
                        <p class="tr-panel-desc">فهرست <?php echo Text::e((string) $popularLimit); ?> برگه مستقل با بیشترین تعداد بازدید.</p>
                    </div>
                    <div class="tr-panel-pills">
                        <button type="button" class="btn vc-reset-all" data-scope="pages" data-token-url="<?php echo Text::e(Settings::actionUrl('reset_all', true)); ?>">بازنشانی آمار برگه‌ها</button>
                    </div>
                </div>
                <?php
                    $list = $topPages;
                    $kind = 'page';
                    require __DIR__ . '/view/list.php';
                ?>
            </div>
        </section>
    <?php endif; ?>

    <?php require __DIR__ . '/view/form.php'; ?>
</div>
<script src="<?php echo Text::e(Settings::assetUrl('assets/panel.js')); ?>"></script>