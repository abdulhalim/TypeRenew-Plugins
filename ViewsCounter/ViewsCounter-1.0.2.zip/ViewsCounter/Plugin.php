<?php
declare(strict_types=1);

namespace TypechoPlugin\ViewsCounter;

use Typecho\Plugin as Hook;
use Typecho\Plugin\PluginInterface;
use Typecho\Widget\Helper\Form;
use Typecho\Widget\Helper\Form\Element\Hidden;
use Typecho\Widget\Helper\Form\Element\Radio;
use Typecho\Widget\Helper\Form\Element\Text as FormText;
use Utils\Helper;
use Utils\NoPersonal;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * شمارنده بازدید سبک، سریع و امن
 * 
 * @package ViewsCounter
 * @author  پوردریایی
 * @version 1.0.2
 * @link    https://pourdaryaei.ir
 *
 */
class Plugin implements PluginInterface
{
    use NoPersonal;

    /**
     * فعال‌سازی افزونه
     *
     * @return string
     * @throws \Throwable
     */
    public static function activate(): string
    {
        Settings::ensureStored();
        Migration::ensure();

        // شمارش بازدید پیش از رندر آرشیو
        Hook::factory('Widget\Archive')->beforeRender = [Counter::class, 'record'];

        // تزریق ویجت آمار سریع به داشبورد اصلی (از طریق فوتر ادمین)
        Hook::factory('admin/footer.php')->end = [Dashboard::class, 'render'];

        // ثبت مسیر اکشن برای ذخیره تنظیمات / بازنشانی آمار از طریق پنل
        Helper::removeRoute('views_counter_action');
        Helper::addRoute('views_counter_action', '/action/views-counter', Action::class, 'action');

        // ثبت پنل مدیریت
        Helper::removePanel(3, 'ViewsCounter/Panel.php');
        Helper::addPanel(
            3,
            'ViewsCounter/Panel.php',
            'بازدید مطالب',
            'بازدید مطالب',
            'administrator',
            false,
            '',
            ['icon' => 'i-eye']
        );

        return _t('افزونه ViewsCounter فعال شد.');
    }

    /**
     * غیرفعال‌سازی افزونه
     *
     * @return string
     */
    public static function deactivate(): string
    {
        Helper::removeRoute('views_counter_action');
        Helper::removePanel(3, 'ViewsCounter/Panel.php');
        Settings::clear();
        return _t('افزونه ViewsCounter غیرفعال شد. جداول دیتابیس دست‌نخورده باقی می‌مانند.');
    }

    /**
     * فرم تنظیمات (در صفحه پیکربندی افزونه)
     *
     * @param Form $form
     */
    public static function config(Form $form): void
    {
        $settings = Settings::load();

        $popularLimit = new FormText(
            'popular_limit',
            null,
            (string) ($settings['popular_limit'] ?? 10),
            _t('تعداد آیتم‌های نمایش داده شده در لیست پربازدیدترین‌ها'),
            _t('در پنل مدیریت، چند نوشته/برگه در لیست پربازدیدترین‌ها نمایش داده شود.')
        );
        $popularLimit->input->setAttribute('type', 'number');
        $popularLimit->input->setAttribute('min', '1');
        $popularLimit->input->setAttribute('max', '100');
        $form->addInput($popularLimit);

        $cookieTime = new FormText(
            'cookie_time',
            null,
            (string) ($settings['cookie_time'] ?? 3600),
            _t('فاصله زمانی شمارش بازدیدهای مکرر (ثانیه)'),
            _t('بازدیدهای یک کاربر از یک مطلب در این مدت فقط یک‌بار شمارش می‌شود.')
        );
        $cookieTime->input->setAttribute('type', 'number');
        $cookieTime->input->setAttribute('min', '0');
        $cookieTime->input->setAttribute('max', '86400');
        $form->addInput($cookieTime);

        $countLoggedIn = new Radio(
            'count_logged_in',
            ['0' => _t('خیر (پیش‌فرض)'), '1' => _t('بله')],
            (string) ($settings['count_logged_in'] ?? '0'),
            _t('شمارش بازدید کاربران واردشده'),
            _t('اگر «خیر» باشد، بازدید مدیر و نویسندگان در آمار لحاظ نمی‌شود.')
        );
        $form->addInput($countLoggedIn);

        $countPages = new Radio(
            'count_pages',
            ['0' => _t('فقط نوشته‌ها (post)'), '1' => _t('نوشته‌ها و برگه‌ها')],
            (string) ($settings['count_pages'] ?? '0'),
            _t('شمارش بازدید برای برگه‌ها'),
            _t('تعیین اینکه آیا بازدید برگه‌های مستقل (page) هم شمارش شود یا خیر.')
        );
        $form->addInput($countPages);

        // ------------------------------------------------------------
        // تنظیمات نمایش ویجت‌های داشبورد اصلی (نسخه‌ی 1.0.4)
        // ------------------------------------------------------------
        $dashStats = new Radio(
            'dash_stats',
            ['1' => _t('نمایش داده شود (پیش‌فرض)'), '0' => _t('مخفی باشد')],
            (string) ($settings['dash_stats'] ?? '1'),
            _t('ویجت «آمار بازدید» در داشبورد اصلی'),
            _t('کارت KPI «مجموع بازدیدها» را در داشبورد اصلی (صفحه‌ی نخست پنل مدیریت) نمایش می‌دهد.')
        );
        $form->addInput($dashStats);

        $dashTrend = new Radio(
            'dash_trend',
            ['1' => _t('نمایش داده شود (پیش‌فرض)'), '0' => _t('مخفی باشد')],
            (string) ($settings['dash_trend'] ?? '1'),
            _t('ویجت «روند بازدید ۱۴ روز اخیر» در داشبورد اصلی'),
            _t('کارت نمودار میله‌ای روند بازدید ۱۴ روز اخیر را در داشبورد اصلی نمایش می‌دهد.')
        );
        $form->addInput($dashTrend);

        // ذخیره‌سازی نسخه نهایی تنظیمات در زمان ذخیره از فرم کلاسیک
        foreach (Settings::defaults() as $key => $value) {
            if (in_array($key, ['popular_limit', 'cookie_time', 'count_logged_in', 'count_pages', 'dash_stats', 'dash_trend'], true)) {
                continue;
            }
            $form->addInput(new Hidden($key, null, (string) ($settings[$key] ?? $value)));
        }
    }

    /**
     * ذخیره تنظیمات (هنگام ارسال فرم کلاسیک)
     *
     * @param array $settings
     * @param bool  $isInit
     */
    public static function configHandle(array $settings, bool $isInit): void
    {
        if ($isInit) {
            return;
        }
        $current = Settings::loadFresh();
        Settings::store(array_merge($current, $settings));
    }

    // ================================================================
    // لایه‌ی سازگاری (Compatibility Layer) — نسخه‌ی 1.0.2
    // ================================================================
    // پوسته‌های قدیمی (مثل ساحل) این متدها را به‌صورت مستقیم روی کلاس
    // Plugin صدا می‌زنند. در پلاگین جدید، این متدها در کلاس Counter
    // قرار دارند. اینجا wrapper هایی اضافه می‌کنیم که فراخوانی را به
    // کلاس Counter منتقل می‌دهند تا پوسته‌های قدیمی بدون تغییر کار کنند.
    // ================================================================

    /**
     * دریافت تعداد بازدید یک مطلب با cid
     *
     * این متد به‌عنوان wrapper برای Counter::getViewsById() عمل می‌کند
     * تا پوسته‌هایی که Plugin::getViewsById($cid) را صدا می‌زنند کار کنند.
     *
     * @param int $cid شناسه‌ی محتوا
     * @return int تعداد بازدید
     */
    public static function getViewsById($cid): int
    {
        return Counter::getViewsById((int) $cid);
    }

    /**
     * دریافت تعداد بازدید مطلب جاری (در قالب)
     *
     * این متد به‌عنوان wrapper برای Counter::getViews() عمل می‌کند
     * تا پوسته‌هایی که Plugin::getViews() را صدا می‌زنند کار کنند.
     *
     * @return int تعداد بازدید مطلب جاری
     */
    public static function getViews(): int
    {
        return Counter::getViews();
    }

    /**
     * لیست پربازدیدترین مطالب (post)
     *
     * این متد به‌عنوان wrapper برای Counter::getMostViewedPosts() عمل
     * می‌کند. نام «getMostViewed» برای سازگاری با پلاگین قدیمی نگه
     * داشته شد (پلاگین قدیمی متدی با همین نام داشت).
     *
     * توجه: برخلاف پلاگین قدیمی که تنظیمات popular_limit را به‌صورت
     * خودکار می‌خواند، این متد یک پارامتر $limit اختیاری می‌گیرد. اگر
     * $limit صفر یا منفی باشد، از تنظیمات پلاگین (popular_limit) استفاده
     * می‌شود. این رفتار هم با پلاگین قدیمی سازگار است و هم با پلاگین جدید.
     *
     * @param int $limit حداکثر تعداد مطالب (0 = استفاده از تنظیمات پلاگین)
     * @return array<int,array<string,mixed>> لیست مطالب پربازدید
     */
    public static function getMostViewed($limit = 0): array
    {
        if ($limit <= 0) {
            // خواندن از تنظیمات پلاگین (همان رفتار پلاگین قدیمی)
            try {
                $settings = Settings::load();
                $limit = (int) ($settings['popular_limit'] ?? 10);
            } catch (\Throwable $e) {
                $limit = 10;
            }
        }

        $posts = Counter::getMostViewedPosts($limit);

        // سازگاری با پلاگین قدیمی: پلاگین قدیمی هر post را از طریق
        // Widget_Abstract_Contents->push() می‌گذاشت تا ساختار کامل
        // (شامل permalink، author، categories و...) پر شود. پلاگین جدید
        // فقط ستون‌های خام دیتابیس را برمی‌گرداند. برای سازگاری کامل،
        // ما هم اینجا هر ردیف را از طریق Widget\Base\Contents پرش می‌دهیم.
        $result = [];
        foreach ($posts as $post) {
            $result[] = self::enrichPost($post);
        }

        return $result;
    }

    /**
     * غنی‌سازی ردیف خام دیتابیس با ساختار کامل محتوا
     *
     * این متد برای سازگاری با پلاگین قدیمی اضافه شده است. پلاگین قدیمی
     * از Widget_Abstract_Contents->push() استفاده می‌کرد که ساختار
     * کامل محتوا (شامل permalink، author، categories و...) را پر می‌کرد.
     * ما اینجا از Widget\Base\Contents استفاده می‌کنیم که معادل جدید آن است.
     *
     * @param array $row ردیف خام دیتابیس
     * @return array ردیف غنی‌شده
     */
    private static function enrichPost(array $row): array
    {
        try {
            // تلاش برای استفاده از Widget\Base\Contents (مسیر جدید)
            if (class_exists('\Widget\Base\Contents')) {
                $contents = \Widget\Base\Contents::alloc();
                return $contents->push($row);
            }

            // fallback: اگر کلاس جدید وجود نداشت (نسخه‌های قدیمی Typecho)
            if (class_exists('\Widget_Abstract_Contents')) {
                $contents = new \Widget_Abstract_Contents();
                return $contents->push($row);
            }
        } catch (\Throwable $e) {
            // در صورت خطا، همان ردیف خام را برمی‌گردانیم
        }

        return $row;
    }
}
