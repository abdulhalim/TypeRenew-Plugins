<?php
/**
 * زیباساز صفحهٔ ورود — تصویر، متن و پترن‌های تزئینی برای ستون ورود
 *
 * @package LoginHero
 * @author پوردریایی
 * @link https://pourdaryaei.ir
 * @version 1.2.0
 * @since 1.6.0
 */

namespace TypechoPlugin\LoginHero;

use Typecho\Plugin as Hook;
use Typecho\Plugin\PluginInterface;
use Typecho\Widget\Helper\Form;
use Typecho\Widget\Helper\Form\Element\Radio;
use Typecho\Widget\Helper\Form\Element\Select;
use Typecho\Widget\Helper\Form\Element\Text;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Plugin implements PluginInterface
{
    /** نسخهٔ افزونه */
    const VERSION = '1.2.0';

    /** پسوندهای تصویری مجاز برای تصویر محلی */
    const IMG_EXTS = ['jpg', 'jpeg', 'png', 'webp', 'avif', 'gif'];

    /** حداکثر حجم هر تصویر محلی (۸ مگابایت) */
    const IMG_MAX_BYTES = 8388608;

    /** صفحه‌های مدیریتی که ستون تصویری ورود دارند */
    const AUTH_PAGES = ['login.php', 'register.php', 'forgot.php', 'reset.php'];

    /**
     * فعال‌سازی افزونه
     */
    public static function activate(): string
    {
        Hook::factory('admin/header.php')->header = [__CLASS__, 'filterHeader'];

        return _t('افزونهٔ «زیباساز صفحهٔ ورود» فعال شد. از دکمهٔ «تنظیمات» همین افزونه، تصویر، متن‌ها و پترن‌های تزئینی را شخصی‌سازی کنید؛ نتیجه را پیش‌نمایش زنده همان صفحه هم نشان می‌دهد.');
    }

    /**
     * غیرفعال‌سازی افزونه — هیچ داده‌ای در هسته یا دیتابیس نمی‌نویسیم،
     * پس کافی است هوک حذف شود (Typecho خودش انجام می‌دهد) تا صفحهٔ ورود
     * کاملاً به حالت اصلی بازگردد.
     */
    public static function deactivate(): string
    {
        return _t('افزونهٔ «زیباساز صفحهٔ ورود» غیرفعال شد؛ صفحهٔ ورود به حالت پیش‌فرض بازگشت.');
    }

    /**
     * فرم تنظیمات افزونه
     */
    public static function config(Form $form): void
    {
        $images = self::scanImages();
        $firstImage = '';
        foreach ($images as $file => $label) {
            $firstImage = (string) $file;
            break;
        }

        // ۱) منبع پس‌زمینه
        $imageSource = new Radio(
            'imageSource',
            [
                'none'      => _t('بدون تصویر — همان گرادیانت پیش‌فرض'),
                'local'     => _t('تصویر محلی از پوشهٔ افزونه'),
                'url'       => _t('آدرس تصویر خارجی'),
                'particles' => _t('ذرات متحرک (پارتیکل) به‌جای تصویر'),
                'patterns'  => _t('پترن‌های تزئینی (شامل طرح هاله)'),
            ],
            self::getOption('imageSource', 'none'),
            _t('پس‌زمینه ستون ورود'),
            _t('ستون تصویری صفحهٔ ورود (در صفحه‌های ورود، ثبت‌نام، فراموشی رمز و بازنشانی رمز) می‌تواند به‌جای گرادیانت ساده یک تصویر بگیرد، با «ذرات متحرک» جان بگیرد، یا با یکی از هفت «پترن تزئینی» (شامل طرح «هاله (Aura + Grid)») هماهنگ شود. نتیجه را پیش از ذخیره، در پیش‌نمایش بالای همین صفحه ببینید.')
        );
        $form->addInput($imageSource);

        // ۲) انتخاب تصویر محلی (اسکن پوشه assets/img)
        $localOptions = $images;
        if (empty($localOptions)) {
            $localOptions = ['' => _t('— هنوز تصویری در پوشهٔ افزونه نیست —')];
        }
        $localImage = new Select(
            'localImage',
            $localOptions,
            self::getOption('localImage', $firstImage),
            _t('تصویر محلی'),
            _t('فایل‌های پوشه assets/img داخل همین افزونه. برای افزودن تصویر دلخواه، فایل را در مسیر usr/plugins/LoginHero/assets/img/ کپی کنید و این صفحه را تازه‌سازی کنید؛ بلافاصله در همین فهرست ظاهر می‌شود. فرمت‌های مجاز: JPG، PNG، WebP، AVIF و GIF (حداکثر ۸ مگابایت).')
        );
        $form->addInput($localImage);

        // ۳) آدرس تصویر خارجی
        $imageUrl = new Text(
            'imageUrl',
            null,
            self::getOption('imageUrl', ''),
            _t('آدرس تصویر خارجی'),
            _t('فقط وقتی «آدرس تصویر خارجی» را انتخاب کرده‌اید. مثال: https://example.com/bg.jpg — مسیر نسبت‌ای از ریشهٔ سایت (مانند /usr/uploads/bg.jpg) هم پذیرفته می‌شود. توجه: تصویر خارجی هر بار بارگیری صفحه از سرور دیگری دانلود می‌شود؛ سرعت و در دسترس‌بودن آن سرور را در نظر بگیرید.')
        );
        $form->addInput($imageUrl);

        // ۳-الف) تعداد ذرات
        $particleDensity = new Select(
            'particleDensity',
            [
                '40'  => _t('کم — خلوت و آرام'),
                '70'  => _t('متوسط (پیشنهادی)'),
                '110' => _t('زیاد'),
                '160' => _t('خیلی زیاد — پرحجم'),
            ],
            self::getOption('particleDensity', '70'),
            _t('تعداد ذرات متحرک'),
            _t('فقط وقتی «ذرات متحرک (پارتیکل)» را به‌عنوان پس‌زمینه انتخاب کرده‌اید. تعداد ذرات به‌تناسب مساحت ستون به‌طور خودکار کم‌وزیاد می‌شود؛ مقدارهای بالا روی دستگاه‌های ضعیف کمی سنگین‌ترند.')
        );
        $form->addInput($particleDensity);

        // ۳-ب) رنگ ذرات
        $particleColor = new Select(
            'particleColor',
            [
                'auto'    => _t('هماهنگ با تم صفحه ورود (پیشنهادی)'),
                'white'   => _t('سفید نرم'),
                'sky'     => _t('آبی آسمانی'),
                'emerald' => _t('سبز زمردی'),
                'amber'   => _t('کهربایی گرم'),
                'rose'    => _t('صورتی مرجانی'),
                'violet'  => _t('بنفش کهکشانی'),
                'custom'  => _t('دو رنگ سفارشی (کد HEX)'),
            ],
            self::getOption('particleColor', 'auto'),
            _t('رنگ ذرات'),
            _t('در حالت «هماهنگ با تم»، رنگ ذرات از همان گرادیانت تمِ انتخابی صفحه ورود خوانده می‌شود؛ پس با دکمه تغییر تم و با حالت تاریک هماهنگ می‌ماند. گزینه‌های دیگر جفت‌رنگ آماده‌اند و «دو رنگ سفارشی» جفت‌رنگ دلخواه شما را می‌پذیرد.')
        );
        $form->addInput($particleColor);

        // ۳-پ) رنگ سفارشی ۱
        $particleCustomA = new Text(
            'particleCustomA',
            null,
            self::getOption('particleCustomA', ''),
            _t('رنگ سفارشی ۱ (HEX)'),
            _t('فقط وقتی «دو رنگ سفارشی» را انتخاب کرده‌اید. کد شش‌رقمی مثل #38BDF8 — ذرات طیفی بین این دو رنگ می‌گیرند. هر دو کد باید معتبر باشند وگرنه رنگ هماهنگ با تم به کار می‌رود.')
        );
        $form->addInput($particleCustomA);

        // ۳-ت) رنگ سفارشی ۲
        $particleCustomB = new Text(
            'particleCustomB',
            null,
            self::getOption('particleCustomB', ''),
            _t('رنگ سفارشی ۲ (HEX)'),
            _t('رنگ دوم طیف ذرات؛ مثل #A78BFA.')
        );
        $form->addInput($particleCustomB);

        // ۳-ث) سرعت حرکت
        $particleSpeed = new Select(
            'particleSpeed',
            [
                'slow'   => _t('آهسته و آرام'),
                'normal' => _t('عادی (پیشنهادی)'),
                'fast'   => _t('زنده و پرتحرک'),
            ],
            self::getOption('particleSpeed', 'normal'),
            _t('سرعت حرکت ذرات'),
            _t('سرعت شناورشدن ذرات در ستون ورود.')
        );
        $form->addInput($particleSpeed);

        // ۳-ج) خطوط اتصال
        $particleLines = new Select(
            'particleLines',
            [
                'off'    => _t('بدون خطوط اتصال'),
                'subtle' => _t('ظریف (پیشنهادی)'),
                'bold'   => _t('پررنگ و شبکه‌ای'),
            ],
            self::getOption('particleLines', 'subtle'),
            _t('خطوط اتصال بین ذرات'),
            _t('ذرات نزدیک به هم با خط‌های کم‌رنگ به هم وصل می‌شوند (اثر «شبکه»). «ظریف» برای صفحهٔ ورود توصیه می‌شود.')
        );
        $form->addInput($particleLines);

        // ۳-چ) تعامل با نشانگر موس
        $particleMouse = new Radio(
            'particleMouse',
            [
                '1' => _t('بله — ذرات از نشانگر کمی کنار بروند'),
                '0' => _t('خیر — بدون تعامل'),
            ],
            self::getOption('particleMouse', '1'),
            _t('تعامل با نشانگر موس'),
            _t('نشانگر موس مثل یک ذرهٔ نامرئی عمل می‌کند: ذرات نزدیک کمی کنار می‌روند و به نشانگر خط اتصال می‌گیرند. در صفحه‌های لمسی بی‌اثر است و هیچ فیلدی از فرم ورود را نمی‌پوشاند.')
        );
        $form->addInput($particleMouse);

        // ۴) تیرگی روبالشی
        $overlay = new Select(
            'overlayOpacity',
            [
                '0'  => _t('۰٪ — تصویر خام بدون روبالشی'),
                '20' => _t('۲۰٪ — خیلی ملایم'),
                '35' => _t('۳۵٪ — ملایم (پیشنهادی)'),
                '50' => _t('۵۰٪ — متعادل'),
                '65' => _t('۶۵٪ — پررنگ'),
                '80' => _t('۸۰٪ — خیلی پررنگ'),
            ],
            self::getOption('overlayOpacity', '35'),
            _t('تیرگی روبالشی روی تصویر (فقط حالت تصویر)'),
            _t('این تنظیم فقط وقتی «تصویر محلی» یا «آدرس تصویر خارجی» انتخاب شده باشد اثر دارد. روبالشی، همان گرادیانت رنگی تمِ انتخابی صفحه ورود است که با شدت دلخواه روی تصویر می‌نشیند تا متن سفید خوانا بماند. برای تصاویر روشن یا شلوغ، ۵۰ تا ۸۰ درصد توصیه می‌شود. این لایه با دکمه تغییر تمِ خود صفحه ورود و با حالت تاریک هماهنگ است. در حالت «ذرات متحرک» روبالشی لازم نیست؛ ذرات روی گرادیانت تیره تم خودشان روشنایی کافی دارند.')
        );
        $form->addInput($overlay);

        // ۵-الف) سبک پترن (جدید نسخهٔ ۱.۲)
        $patternStyle = new Select(
            'patternStyle',
            [
                'aura'  => _t('هاله (Aura + Grid)'),
                'dots'       => _t('نقاط منظم (Dot grid)'),
                'grid'       => _t('شبکهٔ ساده (Grid lines)'),
                'diagonal'   => _t('خطوط مورب (Diagonal lines)'),
                'cubes'      => _t('مکعب‌های سه‌بعدی (Isometric cubes)'),
            ],
            self::getOption('patternStyle', 'aura'),
            _t('سبک پترن'),
            _t('فقط وقتی «پترن‌های تزئینی» را به‌عنوان پس‌زمینه انتخاب کرده‌اید. پترنِ «هاله (Aura + Grid)» سه لکهٔ aurora (آبی، سبزآبی، آبی روشن) با انیمیشن drift، روی یک شبکهٔ ۴۴×۴۴ پیکسلی که در بالا ماسک شده. سایر پترن‌ها طرح‌های مینیمال و ساده هستند. توجه: وقتی پترن فعال باشد، علاوه بر ستون hero، بخش tr-auth-panel (ستون راست که فرم ورود در آن است) هم با همان پترن پر می‌شود و کارت فرم روی آن قرار می‌گیرد.')
        );
        $form->addInput($patternStyle);

        // ۵-ب) شفافیت پترن (جدید نسخهٔ ۱.۲)
        $patternOpacity = new Select(
            'patternOpacity',
            [
                '0'   => _t('۰٪ — نامرئی'),
                '30'  => _t('۳۰٪ — ظریف (پیشنهادی)'),
                '50'  => _t('۵۰٪ — متعادل'),
                '70'  => _t('۷۰٪ — مشخص'),
                '100' => _t('۱۰۰٪ — کامل (برای پترن هاله)'),
            ],
            self::getOption('patternOpacity', '30'),
            _t('شفافیت پترن'),
            _t('شدت کلی پترن روی ستون hero. برای پترن «هاله (Aura + Grid)»، مقدار ۱۰۰٪ نتیجهٔ کامل می‌دهد؛ مقادیر کمتر، پترن را ظریف‌تر و ملایم‌تر می‌کنند. برای پترن‌های دیگر (نقاط، شبکه و ...) معمولاً ۳۰ تا ۵۰ درصد کافی است. توجه: وقتی پترن «هاله» انتخاب شده باشد، دکمهٔ تغییر تمِ صفحهٔ ورود (در بالای کارت) مخفی می‌شود چون رنگ‌های این پترن مستقل از تم‌های آماده هستند.')
        );
        $form->addInput($patternOpacity);

        // ۶) عنوان
        $heroTitle = new Text(
            'heroTitle',
            null,
            self::getOption('heroTitle', ''),
            _t('عنوان ستون ورود'),
            _t('متن بزرگ وسط ستون تصویری. پیش‌فرض: عنوان سایت شما. خالی بگذارید تا پیش‌فرض دست‌نخورده بماند.')
        );
        $form->addInput($heroTitle);

        // ۷) زیرعنوان
        $heroSubtitle = new Text(
            'heroSubtitle',
            null,
            self::getOption('heroSubtitle', ''),
            _t('زیرعنوان ستون ورود'),
            _t('متن کوچک زیر عنوان. پیش‌فرض: «پنل مدیریت سبک، ساخته‌شده توسط LoginHero». خالی = همان پیش‌فرض.')
        );
        $form->addInput($heroSubtitle);

        // ۸) پانوشت
        $heroFoot = new Text(
            'heroFoot',
            null,
            self::getOption('heroFoot', ''),
            _t('پانوشت ستون ورود'),
            _t('متن کوچک پایین ستون تصویری. پیش‌فرض: «© سال LoginHero Team». خالی = همان پیش‌فرض.')
        );
        $form->addInput($heroFoot);
    }

    /**
     * تنظیمات شخصی — این افزونه تنظیم شخصی ندارد
     */
    public static function personalConfig(Form $form): void
    {
    }

    /**
     * فیلتر سربرگ صفحات مدیریت (admin/header.php)
     *
     * روی صفحه‌های ورود، استایل و اسکریپت سفارشی‌سازی را به <head> می‌چسباند؛
     * روی صفحه تنظیمات خود افزونه، پیش‌نمایش زنده را تزریق می‌کند. تمام بدنه در
     * try/catch است تا هیچ خطای غیرمنتظره‌ای هرگز صفحه ورود را از کار نیندازد.
     */
    public static function filterHeader($header)
    {
        try {
            $page = strtolower(basename((string) ($_SERVER['SCRIPT_NAME'] ?? '')));

            if (in_array($page, self::AUTH_PAGES, true)) {
                $inject = self::buildAuthInjection();
                if ($inject !== '') {
                    $header .= "\n" . $inject;
                }
            } elseif (
                $page === 'options-plugin.php'
                && 'loginhero' === strtolower(trim((string) ($_GET['config'] ?? '')))
            ) {
                $inject = self::buildPreviewInjection();
                if ($inject !== '') {
                    $header .= "\n" . $inject;
                }
            }
        } catch (\Throwable $e) {
            // سکوت محافظتی: صفحه ورود همیشه باید کار کند
        }

        return $header;
    }

    /**
     * ساخت تکه‌های تزریقی برای صفحه‌های ورود:
     * یک <style> (اگر تصویر فعال باشد) + یک <script> (اگر متنی تنظیم شده باشد)
     */
    private static function buildAuthInjection(): string
    {
        $out = '';
        $source = (string) self::getOption('imageSource', 'none');

        // --- حالت جدید: پترن‌های تزئینی ------------------------------
        if ($source === 'patterns') {
            $pattern = self::buildPatternInjection();
            if ($pattern !== '') {
                $out .= $pattern;
            }

            // متن‌های ستون ورود همچنان قابل‌تنظیم‌اند
            $title = trim((string) self::getOption('heroTitle', ''));
            $subtitle = trim((string) self::getOption('heroSubtitle', ''));
            $foot = trim((string) self::getOption('heroFoot', ''));
            if ($title !== '' || $subtitle !== '' || $foot !== '') {
                $json = \Typecho\Common::jsonEncode(
                    ['title' => $title, 'subtitle' => $subtitle, 'foot' => $foot],
                    JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT,
                    '{}'
                );
                $out .= '<script id="loginhero-js">window.__loginHero=' . $json . ';'
                    . self::textOverrideJs() . '</script>' . "\n";
            }
            return $out;
        }

        // --- بخش پس‌زمینه: تصویر یا ذرات متحرک ------------------------------
        if ($source === 'particles') {
            // بوم canvas روی گرادیانت تم می‌نشیند؛ لایه متن (z-index:1) بالاتر می‌ماند
            $css = 'body.body-100 .tr-auth-hero > canvas.lh-canvas{'
                . 'position:absolute;'
                . 'inset:0;'
                . 'width:100%;'
                . 'height:100%;'
                . 'display:block;'
                . 'pointer-events:none;'
                . '}';
            $out .= '<style id="loginhero-css">' . $css . '</style>' . "\n";

            $pjson = \Typecho\Common::jsonEncode(
                self::resolveParticleConfig(),
                JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT,
                '{}'
            );
            $out .= '<script id="loginhero-particles">window.__loginHeroParticles=' . $pjson . ';'
                . 'window.__lhParticles=' . self::particlesEngineJs() . ';'
                . self::particlesBootJs() . '</script>' . "\n";
        } else {
            $imageUrl = self::resolveImageUrl();
            if ($imageUrl !== null) {
                $opacity = self::overlayOpacity();
                $css = 'body.body-100 .tr-auth-hero::before{'
                    . 'background-image:url("' . self::cssEscape($imageUrl) . '");'
                    . 'background-position:center;'
                    . 'background-size:cover;'
                    . 'background-repeat:no-repeat;'
                    . '}'
                    . 'body.body-100 .tr-auth-hero::after{'
                    . 'content:"";'
                    . 'position:absolute;'
                    . 'inset:0;'
                    . 'background:linear-gradient(135deg,var(--tr-auth-hero-from),var(--tr-auth-hero-to));'
                    . 'opacity:' . $opacity . ';'
                    . '}';
                $out .= '<style id="loginhero-css">' . $css . '</style>' . "\n";
            }
        }

        // --- بخش متن‌ها -----------------------------------------------------
        $title = trim((string) self::getOption('heroTitle', ''));
        $subtitle = trim((string) self::getOption('heroSubtitle', ''));
        $foot = trim((string) self::getOption('heroFoot', ''));

        if ($title !== '' || $subtitle !== '' || $foot !== '') {
            $json = \Typecho\Common::jsonEncode(
                ['title' => $title, 'subtitle' => $subtitle, 'foot' => $foot],
                JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT,
                '{}'
            );
            $out .= '<script id="loginhero-js">window.__loginHero=' . $json . ';'
                . self::textOverrideJs() . '</script>' . "\n";
        }

        return $out;
    }

    /**
     * تزریق حالت «پترن‌های تزئینی» (جدید در نسخهٔ ۱.۲).
     *
     * این متد:
     *   ۱) سبک پترن انتخابی را از فهرست هفت‌گانه می‌خواند؛
     *   ۲) CSS لازم برای آن پترن را به <head> می‌چسباند (شامل keyframes
     *      و دفاعیت‌های حالت تاریک)؛
     *   ۳) اسکریپتی تزریق می‌کند که یک <div class="lh-pattern"> به‌عنوان
     *      نخستین فرزند .tr-auth-hero می‌سازد و درونش، برای پترن‌های پیچیده
     *      (مثل LoginHero) عناصر فرزند (auroraها و grid) را می‌گذارد؛
     *   ۴) شفافیت کلی پترن از اسلایدر تنظیمات کنترل می‌شود.
     */
    private static function buildPatternInjection(): string
    {
        $style = self::getOption('patternStyle', 'aura');
        if (!in_array($style, ['aura', 'dots', 'grid', 'diagonal', 'cubes'], true)) {
            $style = 'aura';
        }
        $opacity = self::patternOpacity();

        $css = self::patternCss();
        if ($css === '') {
            return '';
        }

        // JSON برای پاس‌دادن تنظیمات به اسکریپت تزریق
        $cfg = [
            'style'   => $style,
            'opacity' => $opacity,
        ];
        $json = \Typecho\Common::jsonEncode(
            $cfg,
            JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT,
            '{}'
        );

        return '<style id="loginhero-pattern-css">' . $css . '</style>' . "\n"
            . '<script id="loginhero-pattern-js">window.__loginHeroPattern=' . $json . ';'
            . self::patternBootJs() . '</script>' . "\n";
    }

    /**
     * درصد شفافیت پترن به عدد اعشاری CSS (۰ تا ۱)
     */
    private static function patternOpacity(): string
    {
        $v = (int) self::getOption('patternOpacity', '30');
        if ($v < 0) {
            $v = 0;
        }
        if ($v > 100) {
            $v = 100;
        }
        return number_format($v / 100, 2, '.', '');
    }

    /**
     * تمام CSS لازم برای همهٔ پترن‌ها (شامل keyframes و حالت تاریک).
     * این CSS یک‌بار به <head> تزریق می‌شود و اسکریپت بوت، پترن انتخابی
     * را با کلاس مناسب روی .tr-auth-hero فعال می‌کند.
     */
    private static function patternCss(): string
    {
        return <<<'CSS'
/* ---------- container ---------- */
.lh-pattern{position:absolute;inset:0;overflow:hidden;pointer-events:none;z-index:0;transition:opacity .35s ease}

/* ---------- panel positioning: وقتی پترن فعال است، panel هم پترن را نشان دهد ---------- */
/* panel پس‌زمینهٔ solid خود را از دست می‌دهد تا پترن زیر آن دیده شود */
body.body-100.lh-pattern-on .tr-auth-panel{
  position:relative;
  background:transparent;
}
/* فرم ورود روی پترن قرار گیرد (z-index بالا‌تر) */
body.body-100.lh-pattern-on .tr-auth-box{
  position:relative;
  z-index:1;
}
/* hero هم position:relative بماند تا پترن داخلش درست بنشیند (در CSS اصلی هست) */

/* ---------- 1) Aura (Aurora + Grid) ---------- */
/* پس‌زمینهٔ solid (روشن #F6F8FB / تاریک #05070E) */
.lh-pattern-aura{background:#F6F8FB}
html.tr-theme-dark .lh-pattern-aura,
html[data-theme="dark"] .lh-pattern-aura{background:#05070E}

/* Aurora blobs — همان رنگ‌ها، همان اندازه‌ها، همان blur و انیمیشن drift */
.lh-aurora{position:absolute;border-radius:50%;filter:blur(80px);opacity:.5;transition:opacity .6s ease;will-change:transform}
.lh-aurora-1{
  width:540px;height:540px;top:-180px;inset-inline-start:-100px;
  background:radial-gradient(circle,rgba(11,111,232,.32),transparent 65%);
  animation:lh-drift1 26s ease-in-out infinite alternate;
}
.lh-aurora-2{
  width:460px;height:460px;top:-140px;inset-inline-end:-120px;
  background:radial-gradient(circle,rgba(0,176,155,.30),transparent 65%);
  animation:lh-drift2 32s ease-in-out infinite alternate;
}
.lh-aurora-3{
  width:600px;height:600px;top:42%;inset-inline-start:30%;
  background:radial-gradient(circle,rgba(58,143,240,.14),transparent 62%);
  animation:lh-drift3 38s ease-in-out infinite alternate;
}
@keyframes lh-drift1{to{transform:translate(60px,42px) scale(1.08)}}
@keyframes lh-drift2{to{transform:translate(-50px,56px) scale(1.10)}}
@keyframes lh-drift3{to{transform:translate(-68px,-52px) scale(1.06)}}

/* Grid overlay — همان ۴۴×۴۴ پیکسل، ماسک radial در بالای hero */
.lh-bg-grid{
  position:absolute;inset:0;
  background-image:
    linear-gradient(to right,rgba(11,18,32,0.045) 1px,transparent 1px),
    linear-gradient(to bottom,rgba(11,18,32,0.045) 1px,transparent 1px);
  background-size:44px 44px;
  -webkit-mask-image:radial-gradient(ellipse 90% 60% at 50% 0%,#000 45%,transparent 100%);
  mask-image:radial-gradient(ellipse 90% 60% at 50% 0%,#000 45%,transparent 100%);
}
html.tr-theme-dark .lh-aurora,
html[data-theme="dark"] .lh-aurora{opacity:.62}
html.tr-theme-dark .lh-bg-grid,
html[data-theme="dark"] .lh-bg-grid{
  background-image:
    linear-gradient(to right,rgba(233,238,247,0.05) 1px,transparent 1px),
    linear-gradient(to bottom,rgba(233,238,247,0.05) 1px,transparent 1px);
}

/* فقط در پترنِ «هاله»، گرادیانت پیش‌فرض hero مخفی شود (چون پترن خودش پس‌زمینهٔ solid دارد) */
body.body-100.lh-pattern-on.lh-pattern-aura .tr-auth-hero::before{
  background:transparent !important;
}

/* ---------- 2) Dots — نقاط منظم ---------- */
.lh-pattern-dots{
  background-image:radial-gradient(rgba(15,23,42,0.10) 1.4px,transparent 1.4px);
  background-size:22px 22px;
  background-position:center;
}
html.tr-theme-dark .lh-pattern-dots,
html[data-theme="dark"] .lh-pattern-dots{
  background-image:radial-gradient(rgba(233,238,247,0.10) 1.4px,transparent 1.4px);
}

/* ---------- 3) Grid — شبکهٔ ساده ---------- */
.lh-pattern-grid{
  background-image:
    linear-gradient(to right,rgba(15,23,42,0.07) 1px,transparent 1px),
    linear-gradient(to bottom,rgba(15,23,42,0.07) 1px,transparent 1px);
  background-size:32px 32px;
}
html.tr-theme-dark .lh-pattern-grid,
html[data-theme="dark"] .lh-pattern-grid{
  background-image:
    linear-gradient(to right,rgba(233,238,247,0.07) 1px,transparent 1px),
    linear-gradient(to bottom,rgba(233,238,247,0.07) 1px,transparent 1px);
}

/* ---------- 4) Diagonal — خطوط مورب ---------- */
.lh-pattern-diagonal{
  background-image:repeating-linear-gradient(45deg,rgba(15,23,42,0.06) 0 1px,transparent 1px 14px);
}
html.tr-theme-dark .lh-pattern-diagonal,
html[data-theme="dark"] .lh-pattern-diagonal{
  background-image:repeating-linear-gradient(45deg,rgba(233,238,247,0.06) 0 1px,transparent 1px 14px);
}

/* ---------- 5) Cubes — مکعب‌های سه‌بعدی ---------- */
.lh-pattern-cubes{
  background-color:transparent;
  background-image:
    linear-gradient(30deg,rgba(15,23,42,0.06) 12%,transparent 12.5%,transparent 87%,rgba(15,23,42,0.06) 87.5%,rgba(15,23,42,0.06)),
    linear-gradient(150deg,rgba(15,23,42,0.06) 12%,transparent 12.5%,transparent 87%,rgba(15,23,42,0.06) 87.5%,rgba(15,23,42,0.06)),
    linear-gradient(30deg,rgba(15,23,42,0.06) 12%,transparent 12.5%,transparent 87%,rgba(15,23,42,0.06) 87.5%,rgba(15,23,42,0.06)),
    linear-gradient(150deg,rgba(15,23,42,0.06) 12%,transparent 12.5%,transparent 87%,rgba(15,23,42,0.06) 87.5%,rgba(15,23,42,0.06));
  background-size:40px 70px;
  background-position:0 0,0 0,20px 35px,20px 35px;
}
html.tr-theme-dark .lh-pattern-cubes,
html[data-theme="dark"] .lh-pattern-cubes{
  background-image:
    linear-gradient(30deg,rgba(233,238,247,0.06) 12%,transparent 12.5%,transparent 87%,rgba(233,238,247,0.06) 87.5%,rgba(233,238,247,0.06)),
    linear-gradient(150deg,rgba(233,238,247,0.06) 12%,transparent 12.5%,transparent 87%,rgba(233,238,247,0.06) 87.5%,rgba(233,238,247,0.06)),
    linear-gradient(30deg,rgba(233,238,247,0.06) 12%,transparent 12.5%,transparent 87%,rgba(233,238,247,0.06) 87.5%,rgba(233,238,247,0.06)),
    linear-gradient(150deg,rgba(233,238,247,0.06) 12%,transparent 12.5%,transparent 87%,rgba(233,238,247,0.06) 87.5%,rgba(233,238,247,0.06));
}

/* ---------- reduced motion: انیمیشن‌ها متوقف شوند ---------- */
@media (prefers-reduced-motion: reduce){
  .lh-aurora-1,.lh-aurora-2,.lh-aurora-3{animation:none !important}
}
CSS;
    }

    /**
     * اسکریپت راه‌انداز پترن‌ها (نصب روی .tr-auth-hero و .tr-auth-panel).
     *
     * این اسکریپت در <head> اجرا می‌شود؛ پس روی DOMContentLoaded
     * صبر می‌کند، سپس یک <div class="lh-pattern"> را به‌عنوان نخستین
     * فرزند hero و یک نسخهٔ دیگر به‌عنوان نخستین فرزند panel درج می‌کند
     * تا پترن هر دو ستون را پر کند. کارت فرم ورود با z-index بالاتر روی
     * پترن در panel قرار می‌گیرد. برای پترن «هاله»، سه div فرزند aurora
     * و یک div فرزند grid هم ساخته می‌شود.
     */
    private static function patternBootJs(): string
    {
        return <<<'BOOTJS'
(function () {
    function buildContainer(style, opacity) {
        var container = document.createElement('div');
        container.className = 'lh-pattern lh-pattern-' + style;
        container.style.opacity = String(opacity);
        container.setAttribute('aria-hidden', 'true');

        // برای پترن «هاله»، عناصر فرزند aurora و grid را درج کن
        if (style === 'aura') {
            var a1 = document.createElement('div');
            a1.className = 'lh-aurora lh-aurora-1';
            var a2 = document.createElement('div');
            a2.className = 'lh-aurora lh-aurora-2';
            var a3 = document.createElement('div');
            a3.className = 'lh-aurora lh-aurora-3';
            var grid = document.createElement('div');
            grid.className = 'lh-bg-grid';
            container.appendChild(a1);
            container.appendChild(a2);
            container.appendChild(a3);
            container.appendChild(grid);
        }
        return container;
    }

    function install(target, style, opacity) {
        if (!target) { return; }
        // حذف پترن قبلی اگر هست (هوک دوبار اجرا نشود)
        var existing = target.querySelector(':scope > .lh-pattern');
        if (existing) { existing.parentNode.removeChild(existing); }
        var container = buildContainer(style, opacity);
        target.insertBefore(container, target.firstChild);
    }

    function boot() {
        var cfg = window.__loginHeroPattern || {};
        var style = cfg.style || 'aura';
        var opacity = cfg.opacity != null ? cfg.opacity : 0.30;

        // اضافه‌کردن کلاس‌های body برای هدف‌گیری CSS (مخفی‌کردن گرادیانت hero
        // فقط در پترن «هاله»، position:relative و transparent کردن panel و ...)
        document.body.classList.add('lh-pattern-on');
        document.body.classList.add('lh-pattern-' + style);

        // نصب پترن روی hero (ستون چپ)
        var hero = document.querySelector('.tr-auth-hero');
        install(hero, style, opacity);

        // نصب پترن روی panel (ستون راست، با کارت فرم روی پترن)
        var panel = document.querySelector('.tr-auth-panel');
        install(panel, style, opacity);

        // برای پترنِ «هاله»، دکمهٔ تغییر تمِ صفحهٔ ورود و کل container
        // آن مخفی شود چون رنگ‌های پترن مستقل از تم‌های آماده (forest/slate/...)
        // هستند و سوییچ بین آن‌ها تعارض ایجاد می‌کند.
        if (style === 'aura') {
            var btn = document.getElementById('trAuthThemeBtn');
            var sw = document.querySelector('.tr-auth-switch');
            if (btn) { btn.style.display = 'none'; }
            if (sw) { sw.style.display = 'none'; }
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
BOOTJS;
    }

    /**
     * اسکریپت جایگزینی متن‌های ستون ورود.
     *
     * اسکریپت در <head> اجرا می‌شود و هنوز عناصری وجود ندارد؛ پس یک
     * MutationObserver می‌گذارد و همان لحظه‌ای که هر عنصر در DOM پدید می‌آید
     * (پیش از رنگ‌آمیزی صفحه، بدون چشمک) متنش را با textContent عوض می‌کند.
     * جایگزینی تا وقتی همه متن‌های تنظیم‌شده اعمال نشده‌اند ادامه دارد و پس
     * از بارگیری کامل صفحه، مشاهده‌گر قطع می‌شود.
     */
    private static function textOverrideJs(): string
    {
        return <<<'JS'
(function () {
    var cfg = window.__loginHero || {};
    function needList() {
        var list = [];
        if (cfg.title) { list.push(['.tr-auth-hero-title', cfg.title]); }
        if (cfg.subtitle) { list.push(['.tr-auth-hero-subtitle', cfg.subtitle]); }
        if (cfg.foot) { list.push(['.tr-auth-hero-foot', cfg.foot]); }
        return list;
    }
    function apply() {
        var list = needList(), left = [];
        for (var i = 0; i < list.length; i++) {
            var el = document.querySelector(list[i][0]);
            if (el) { el.textContent = list[i][1]; } else { left.push(list[i]); }
        }
        return left.length === 0;
    }
    if (apply()) { return; }
    if (!window.MutationObserver) { return; }
    var mo = new MutationObserver(function () {
        if (apply()) { mo.disconnect(); }
    });
    mo.observe(document.documentElement, { childList: true, subtree: true });
    document.addEventListener('DOMContentLoaded', function () { apply(); });
    window.addEventListener('load', function () { mo.disconnect(); });
})();
JS;
    }

    /**
     * تعیین آدرس نهایی تصویر بر اساس منبع انتخابی.
     * خروجی null یعنی «تصویری نباید اعمال شود» (منبع none یا نامعتبر).
     */
    private static function resolveImageUrl(): ?string
    {
        $source = (string) self::getOption('imageSource', 'none');

        if ($source === 'local') {
            $file = trim((string) self::getOption('localImage', ''));
            if ($file === '' || !preg_match('/^[A-Za-z0-9._-]+$/', $file)) {
                return null; // نام فایل نامعتبر یا پیمایش مسیر
            }
            $path = __DIR__ . '/assets/img/' . $file;
            if (!is_file($path)) {
                return null; // فایل حذف شده است
            }
            $ext = strtolower((string) pathinfo($path, PATHINFO_EXTENSION));
            if (!in_array($ext, self::IMG_EXTS, true)) {
                return null;
            }
            $url = self::getPluginUrl() . '/assets/img/' . rawurlencode($file);
            // بی‌اعتبارکردن کش مرورگر در صورت جایگزینی فایل هم‌نام
            $mtime = @filemtime($path);
            if ($mtime !== false) {
                $url .= '?v=' . $mtime;
            }
            return $url;
        }

        if ($source === 'url') {
            $url = trim((string) self::getOption('imageUrl', ''));
            // حذف نویسه‌های کنترلی و محدودکردن طول
            $url = preg_replace('/[\x00-\x1f\x7f]+/u', '', $url) ?? '';
            if (strlen($url) < 4 || strlen($url) > 500) {
                return null;
            }
            // فقط http/https یا مسیر نسبت‌ای از ریشهٔ سایت
            // نکته: < و > به‌صورت درصدی‌کدگذاری می‌شوند تا هیچ راهی برای
            // خروج زودهنگام از تگ <style> (توالی </style>) باقی نماند.
            if (preg_match('#^https?://#i', $url) || strpos($url, '/') === 0) {
                return str_replace(['<', '>'], ['%3C', '%3E'], $url);
            }
            return null;
        }

        return null;
    }

    /**
     * درصد تیرگی روبالشی به عدد اعشاری CSS (۰ تا ۰٫۹)
     */
    private static function overlayOpacity(): string
    {
        $v = (int) self::getOption('overlayOpacity', '35');
        if ($v < 0) {
            $v = 0;
        }
        if ($v > 90) {
            $v = 90;
        }
        return number_format($v / 100, 2, '.', '');
    }

    /**
     * پیکربندی حالت «ذرات متحرک» برای تزریق به صفحهٔ ورود.
     * همه مقادیر سمت سرور اعتبارسنجی می‌شوند تا اسکریپت تزریقی
     * هرگز داده خام کاربر را نخواهد دید.
     *
     * @return array<string,mixed>
     */
    private static function resolveParticleConfig(): array
    {
        $density = (int) self::getOption('particleDensity', '70');
        if (!in_array($density, [40, 70, 110, 160], true)) {
            $density = 70;
        }

        $speed = self::getOption('particleSpeed', 'normal');
        if (!in_array($speed, ['slow', 'normal', 'fast'], true)) {
            $speed = 'normal';
        }

        $lines = self::getOption('particleLines', 'subtle');
        if (!in_array($lines, ['off', 'subtle', 'bold'], true)) {
            $lines = 'subtle';
        }

        $mouse = self::getOption('particleMouse', '1') !== '0';

        $colors = 'auto';
        $color = self::getOption('particleColor', 'auto');
        if ($color === 'custom') {
            $a = self::normHex(self::getOption('particleCustomA', ''));
            $b = self::normHex(self::getOption('particleCustomB', ''));
            if ($a !== null && $b !== null) {
                $colors = [$a, $b];
            }
        } elseif (in_array($color, ['white', 'sky', 'emerald', 'amber', 'rose', 'violet'], true)) {
            $colors = 'preset:' . $color;
        }

        return [
            'count'  => $density,
            'speed'  => $speed,
            'lines'  => $lines,
            'mouse'  => $mouse,
            'colors' => $colors,
        ];
    }

    /**
     * اعتبارسنجی و نرمال‌سازی کد رنگ HEX شش‌رقمی (مثل #AABBCC)
     */
    private static function normHex(string $value): ?string
    {
        $value = trim($value);
        if ($value === '') {
            return null;
        }
        if ($value[0] === '#') {
            $value = substr($value, 1);
        }
        if (!preg_match('/^[0-9a-fA-F]{6}$/', $value)) {
            return null;
        }
        return '#' . strtoupper($value);
    }

    /**
     * موتور رندر ذرات (canvas) — تابعی خالص و مستقل از DOMِ خاص؛ هم روی
     * ستون hero صفحه ورود و هم روی کارت پیش‌نمایش صفحه تنظیمات نصب می‌شود.
     * ES5 و بدون وابستگی خارجی تا در هر مرورگری بی‌خطا اجرا شود.
     * خروجی: شیئی با destroy() برای برداشتن کامل بوم و شنونده‌ها.
     */
    private static function particlesEngineJs(): string
    {
        return <<<'ENGINEJS'
function (mount, cfg) {
    cfg = cfg || {};
    var FALLBACK1 = [15, 23, 42];
    var FALLBACK2 = [6, 95, 70];
    var PRESETS = {
        white: ['#f1f5f9', '#cbd5e1'],
        sky: ['#38bdf8', '#818cf8'],
        emerald: ['#34d399', '#2dd4bf'],
        amber: ['#fbbf24', '#fb923c'],
        rose: ['#fb7185', '#f472b6'],
        violet: ['#a78bfa', '#e879f9']
    };
    function hex2rgb(h) {
        return [parseInt(h.substr(0, 2), 16), parseInt(h.substr(2, 2), 16), parseInt(h.substr(4, 2), 16)];
    }
    function parseColor(v) {
        if (!v) { return null; }
        v = String(v).trim();
        var m = v.match(/^#([0-9a-fA-F]{6})$/);
        if (m) { return hex2rgb(m[1]); }
        m = v.match(/^rgba?\(\s*(\d{1,3})[\s,]+(\d{1,3})[\s,]+(\d{1,3})/);
        if (m) { return [parseInt(m[1], 10), parseInt(m[2], 10), parseInt(m[3], 10)]; }
        m = v.match(/^(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})$/);
        if (m) { return [parseInt(m[1], 10), parseInt(m[2], 10), parseInt(m[3], 10)]; }
        return null;
    }
    function resolveColors() {
        var c = cfg.colors, a = null, b = null;
        if (c && typeof c === 'object' && typeof c.length === 'number' && c.length >= 2) {
            a = parseColor(c[0]);
            b = parseColor(c[1]);
            if (a && b) { return [a, b]; }
            return [FALLBACK1, FALLBACK2];
        }
        c = String(c || 'auto');
        if (c.indexOf('preset:') === 0 && PRESETS[c.substr(7)]) {
            var p = PRESETS[c.substr(7)];
            return [hex2rgb(p[0].substr(1)), hex2rgb(p[1].substr(1))];
        }
        if (c !== 'auto') { return [FALLBACK1, FALLBACK2]; }
        var cs = null;
        try { cs = window.getComputedStyle(mount); } catch (e) { cs = null; }
        if (cs) {
            a = parseColor(cs.getPropertyValue('--tr-auth-hero-from'));
            b = parseColor(cs.getPropertyValue('--tr-auth-hero-to'));
            if (a && b) { return [a, b]; }
            if (a) { return [a, a]; }
        }
        return [FALLBACK1, FALLBACK2];
    }
    var SPEEDS = { slow: 0.55, normal: 1, fast: 1.7 };
    var LINES = { off: 0, subtle: 0.30, bold: 0.60 };
    var speedF = SPEEDS[cfg.speed] || 1;
    var lineA = LINES[cfg.lines];
    if (lineA === undefined) { lineA = 0.30; }
    var mouseOn = cfg.mouse !== false;
    var base = parseInt(cfg.count, 10);
    if (isNaN(base) || base < 10) { base = 70; }
    if (base > 400) { base = 400; }

    var canvas = document.createElement('canvas');
    canvas.className = 'lh-canvas';
    var ctx = null;
    try { ctx = canvas.getContext && canvas.getContext('2d'); } catch (e) { ctx = null; }
    if (!ctx) { return { destroy: function () {} }; }
    mount.insertBefore(canvas, mount.firstChild);

    var colors = resolveColors();
    var parts = [];
    var W = 0, H = 0, dpr = 1;
    var mouse = { x: 0, y: 0, on: false };
    var rafId = 0, running = false, lastT = 0, resizeT = 0;
    var reduced = false;
    try {
        reduced = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    } catch (e) { reduced = false; }
    if (!window.requestAnimationFrame) { reduced = true; }

    function rand(a, b) { return a + Math.random() * (b - a); }
    function mixColor(t, alpha) {
        var r = Math.round(colors[0][0] + (colors[1][0] - colors[0][0]) * t);
        var g = Math.round(colors[0][1] + (colors[1][1] - colors[0][1]) * t);
        var b = Math.round(colors[0][2] + (colors[1][2] - colors[0][2]) * t);
        return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
    }
    function makePart() {
        var ang = rand(0, Math.PI * 2);
        var sp = rand(7, 26) * speedF;
        return { x: rand(0, W), y: rand(0, H), vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp, r: rand(0.8, 2.6), t: Math.random(), a: rand(0.45, 1) };
    }
    function rebuild() {
        var n = Math.round(base * (W * H) / 1036800);
        if (n < 6) { n = 6; }
        if (n > 400) { n = 400; }
        parts = [];
        for (var i = 0; i < n; i++) { parts.push(makePart()); }
    }
    function step(dt) {
        for (var i = 0; i < parts.length; i++) {
            var p = parts[i];
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            if (mouseOn && mouse.on) {
                var dx = p.x - mouse.x, dy = p.y - mouse.y;
                var d2 = dx * dx + dy * dy;
                if (d2 > 0.01 && d2 < 12100) {
                    var d = Math.sqrt(d2);
                    var f = (1 - d / 110) * 150 * dt;
                    p.x += (dx / d) * f;
                    p.y += (dy / d) * f;
                }
            }
            if (p.x < -4) { p.x = W + 4; } else if (p.x > W + 4) { p.x = -4; }
            if (p.y < -4) { p.y = H + 4; } else if (p.y > H + 4) { p.y = -4; }
        }
    }
    function draw() {
        ctx.clearRect(0, 0, W, H);
        var i, j, p, q, dx, dy, d2, d, a;
        var maxD = 120, maxD2 = 14400;
        if (lineA > 0) {
            ctx.lineWidth = 1;
            for (i = 0; i < parts.length; i++) {
                p = parts[i];
                for (j = i + 1; j < parts.length; j++) {
                    q = parts[j];
                    dx = p.x - q.x; dy = p.y - q.y;
                    d2 = dx * dx + dy * dy;
                    if (d2 >= maxD2) { continue; }
                    d = Math.sqrt(d2);
                    a = (1 - d / maxD) * lineA * Math.min(p.a, q.a);
                    if (a <= 0.015) { continue; }
                    ctx.strokeStyle = mixColor((p.t + q.t) * 0.5, a);
                    ctx.beginPath();
                    ctx.moveTo(p.x, p.y);
                    ctx.lineTo(q.x, q.y);
                    ctx.stroke();
                }
            }
            if (mouseOn && mouse.on) {
                for (i = 0; i < parts.length; i++) {
                    p = parts[i];
                    dx = p.x - mouse.x; dy = p.y - mouse.y;
                    d2 = dx * dx + dy * dy;
                    if (d2 >= 16900) { continue; }
                    d = Math.sqrt(d2);
                    a = (1 - d / 130) * lineA * 1.2 * p.a;
                    if (a <= 0.015) { continue; }
                    ctx.strokeStyle = mixColor(p.t, a);
                    ctx.beginPath();
                    ctx.moveTo(p.x, p.y);
                    ctx.lineTo(mouse.x, mouse.y);
                    ctx.stroke();
                }
            }
        }
        for (i = 0; i < parts.length; i++) {
            p = parts[i];
            ctx.fillStyle = mixColor(p.t, p.a);
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, 6.2832);
            ctx.fill();
        }
    }
    function loop(ts) {
        if (!running) { return; }
        var dt = lastT ? (ts - lastT) / 1000 : 0.016;
        if (dt < 0) { dt = 0; }
        if (dt > 0.05) { dt = 0.05; }
        lastT = ts;
        step(dt);
        draw();
        rafId = window.requestAnimationFrame(loop);
    }
    function start() {
        if (running || reduced) { return; }
        running = true;
        lastT = 0;
        rafId = window.requestAnimationFrame(loop);
    }
    function stop() {
        running = false;
        if (rafId && window.cancelAnimationFrame) { window.cancelAnimationFrame(rafId); }
        rafId = 0;
    }
    function resize() {
        var w = mount.clientWidth || 0;
        var h = mount.clientHeight || 0;
        if (w <= 0 || h <= 0) { stop(); return; }
        dpr = Math.min(window.devicePixelRatio || 1, 2);
        W = w; H = h;
        canvas.width = Math.round(W * dpr);
        canvas.height = Math.round(H * dpr);
        if (ctx.setTransform) { ctx.setTransform(dpr, 0, 0, dpr, 0, 0); }
        rebuild();
        if (reduced) { draw(); } else { start(); }
    }
    function onResize() {
        if (resizeT) { window.clearTimeout(resizeT); }
        resizeT = window.setTimeout(function () { resizeT = 0; resize(); }, 150);
    }
    function onMove(e) {
        var r = mount.getBoundingClientRect();
        mouse.x = e.clientX - r.left;
        mouse.y = e.clientY - r.top;
        mouse.on = true;
    }
    function onLeave() { mouse.on = false; }
    function onVis() {
        if (document.hidden) { stop(); } else { resize(); }
    }
    window.addEventListener('resize', onResize, false);
    document.addEventListener('visibilitychange', onVis, false);
    if (mouseOn) {
        mount.addEventListener('mousemove', onMove, false);
        mount.addEventListener('mouseleave', onLeave, false);
    }
    var themeMo = null;
    if (window.MutationObserver && document.body) {
        themeMo = new MutationObserver(function () { colors = resolveColors(); });
        themeMo.observe(document.body, { attributes: true, attributeFilter: ['class'] });
    }
    resize();
    return {
        destroy: function () {
            stop();
            if (resizeT) { window.clearTimeout(resizeT); resizeT = 0; }
            if (themeMo) { themeMo.disconnect(); }
            window.removeEventListener('resize', onResize, false);
            document.removeEventListener('visibilitychange', onVis, false);
            if (mouseOn) {
                mount.removeEventListener('mousemove', onMove, false);
                mount.removeEventListener('mouseleave', onLeave, false);
            }
            if (canvas.parentNode) { canvas.parentNode.removeChild(canvas); }
        }
    };
}
ENGINEJS;
    }

    /**
     * راه‌انداز موتور ذرات در صفحه‌های ورود (نصب روی ستون hero).
     * hero در HTML اولیه صفحه‌های ورود موجود است؛ بنابراین DOMContentLoaded کافی است.
     */
    private static function particlesBootJs(): string
    {
        return <<<'BOOTJS'
(function () {
    function boot() {
        var hero = document.querySelector('.tr-auth-hero');
        if (!hero || !window.__lhParticles) { return; }
        window.__lhParticles(hero, window.__loginHeroParticles || {});
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
BOOTJS;
    }

    /**
     * ایمن‌سازی یک URL برای قرارگرفتن داخل رشتهٔ CSS درون گیومه دوتایی.
     * < و > درصدی‌کدگذاری می‌شوند تا توالی </style> نتواند تگ استایل را
     * زودتر از موعد ببندد (دروازه نهایی، صرف‌نظر از منبع URL).
     */
    private static function cssEscape(string $url): string
    {
        return str_replace(
            ['\\', '"', "\n", "\r", "\t", "\0", '<', '>'],
            ['\\\\', '\\"', ' ', ' ', ' ', '', '%3C', '%3E'],
            $url
        );
    }

    /**
     * اسکن پوشهٔ تصاویر محلی افزونه
     *
     * @return array<string,string> نگاشت «نام فایل => برچسب فهرست (نام + حجم)»
     */
    private static function scanImages(): array
    {
        $dir = __DIR__ . '/assets/img';
        if (!is_dir($dir)) {
            return [];
        }

        $files = scandir($dir);
        if ($files === false) {
            return [];
        }

        $out = [];
        foreach ($files as $file) {
            if ($file === '.' || $file === '..' || is_dir($dir . '/' . $file)) {
                continue;
            }
            // فقط نام‌های ساده و امن
            if (!preg_match('/^[A-Za-z0-9._-]+$/', $file)) {
                continue;
            }
            $ext = strtolower((string) pathinfo($file, PATHINFO_EXTENSION));
            if (!in_array($ext, self::IMG_EXTS, true)) {
                continue;
            }
            $size = @filesize($dir . '/' . $file);
            if ($size === false || $size > self::IMG_MAX_BYTES) {
                continue;
            }
            $out[$file] = $file . ' (' . self::faSize((int) $size) . ')';
        }

        ksort($out, SORT_NATURAL | SORT_FLAG_CASE);
        return $out;
    }

    /**
     * نمایش حجم فایل به فارسی
     */
    private static function faSize(int $bytes): string
    {
        if ($bytes >= 1048576) {
            $text = self::faDigits((string) round($bytes / 1048576, 1));
            $text = str_replace('.', '٫', $text);
            return $text . ' مگابایت';
        }
        return self::faDigits((string) (int) round($bytes / 1024)) . ' کیلوبایت';
    }

    /**
     * تبدیل ارقام لاتین به فارسی (برای برچسب‌های فهرست تصاویر)
     */
    private static function faDigits(string $text): string
    {
        return str_replace(
            ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
            ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'],
            $text
        );
    }

    /**
     * خواندن تنظیم افزونه با مقدار پیش‌فرض (الگوی دفاعی، بدون خروج از صفحه)
     */
    private static function getOption(string $key, string $default = ''): string
    {
        try {
            $options = \Widget\Options::alloc()->plugin('LoginHero');
            if (isset($options->$key) && $options->$key !== null && $options->$key !== '') {
                return (string) $options->$key;
            }
            return $default;
        } catch (\Throwable $e) {
            return $default;
        }
    }

    /**
     * آدرس URL پوشهٔ افزونه
     */
    private static function getPluginUrl(): string
    {
        $options = \Widget\Options::alloc();
        return rtrim((string) $options->pluginUrl, '/') . '/LoginHero';
    }

    /**
     * ساخت تزریق صفحهٔ تنظیمات خود افزونه (پیش‌نمایش زنده).
     *
     * یک <style> و یک <script> به <head> صفحه options-plugin.php?config=LoginHero
     * اضافه می‌شود که بالای فرم، کارت پیش‌نمایش ستون ورود را می‌سازد و با هر تغییر
     * فیلدها (منبع تصویر، فایل، آدرس، روبالشی، متن‌ها و پترن‌ها) بلافاصله به‌روز می‌شود.
     */
    private static function buildPreviewInjection(): string
    {
        // آدرس تصاویر محلی برای پیش‌نمایش
        $locals = [];
        foreach (array_keys(self::scanImages()) as $file) {
            $url = self::getPluginUrl() . '/assets/img/' . rawurlencode((string) $file);
            $mtime = @filemtime(__DIR__ . '/assets/img/' . $file);
            if ($mtime !== false) {
                $url .= '?v=' . $mtime;
            }
            $locals[(string) $file] = $url;
        }

        // متن‌های پیش‌فرض برای نمایش وقتی فیلد خالی است
        $siteTitle = '';
        try {
            $siteTitle = trim((string) \Widget\Options::alloc()->title);
        } catch (\Throwable $e) {
            $siteTitle = '';
        }

        $cfg = [
            'locals'   => $locals,
            'defaults' => [
                'title'    => $siteTitle !== '' ? $siteTitle : 'عنوان سایت شما',
                'subtitle' => 'پنل مدیریت سبک، ساخته‌شده توسط LoginHero',
                'foot'     => '© ' . date('Y') . ' LoginHero Team',
            ],
            'caption'  => 'پیش‌نمایش تقریبی ستون تصویری صفحه ورود — رنگ روبالشی و رنگ ذراتِ حالت «هماهنگ با تم» در صفحه واقعی از تمِ انتخابی شما (دکمه تغییر تم صفحه ورود) پیروی می‌کند. در نمایش‌گرهای باریک‌تر از ۷۶۹ پیکسل، ستون تصویری به‌طور پیش‌فرض پنهان است.',
            'warnUrl'  => 'آدرس تصویر خارجی معتبر نیست — باید با http:// یا https:// شروع شود یا مسیری از ریشهٔ سایت باشد (مانند /img/bg.jpg). تا اصلاح نشود، همان گرادیانت پیش‌فرض نمایش داده می‌شود.',
            'warnHex'  => 'کد رنگ سفارشی معتبر نیست — هر دو فیلد باید کد HEX شش‌رقمی باشند (مانند #38BDF8). تا اصلاح نشود، رنگ هماهنگ با تم به کار می‌رود.',
        ];

        $json = \Typecho\Common::jsonEncode(
            $cfg,
            JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT,
            '{}'
        );

        return '<style id="loginhero-preview-css">' . self::previewCss() . '</style>' . "\n"
            . '<script id="loginhero-preview-js">window.__loginHeroPreview=' . $json . ';'
            . 'window.__lhParticles=' . self::particlesEngineJs() . ';'
            . self::previewJs() . '</script>' . "\n";
    }

    /**
     * استایل کارت پیش‌نمایش (همه کلاس‌ها با پیشوند lh-pv برای پرهیز از تداخل)
     */
    private static function previewCss(): string
    {
        return <<<'CSS'
.lh-pv{position:relative;overflow:hidden;height:300px;border-radius:16px;margin:0 0 10px;
background:linear-gradient(135deg,rgba(15,23,42,.90),rgba(6,95,70,.82));
border:1px solid rgba(15,23,42,.14);box-shadow:0 12px 30px rgba(15,23,42,.14)}
.lh-pv-img{position:absolute;inset:0;display:none;background-position:center;background-size:cover;background-repeat:no-repeat}
.lh-pv > canvas.lh-canvas{position:absolute;inset:0;width:100%;height:100%;display:block;pointer-events:none}
.lh-pv-veil{position:absolute;inset:0;display:none;background:linear-gradient(135deg,rgba(15,23,42,.90),rgba(6,95,70,.82))}
.lh-pv-txt{position:relative;z-index:1;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;color:rgba(255,255,255,.96);padding:24px}
.lh-pv-t{font-size:26px;font-weight:850;line-height:1.4;max-width:92%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.lh-pv-s{font-size:13px;opacity:.92;line-height:1.9;max-width:88%}
.lh-pv-f{position:absolute;inset-inline-start:0;inset-inline-end:0;bottom:12px;z-index:1;text-align:center;font-size:11px;color:rgba(255,255,255,.58)}
.lh-pv-cap{font-size:12px;color:#64748b;line-height:1.9;margin:0 0 14px}
.lh-pv-warn{display:none;font-size:12px;color:#b91c1c;background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:8px 12px;margin:0 0 14px;line-height:1.9}
html.tr-theme-dark .lh-pv{border-color:rgba(148,163,184,.25);box-shadow:0 12px 30px rgba(0,0,0,.4)}
html.tr-theme-dark .lh-pv-cap{color:#94a3b8}
html.tr-theme-dark .lh-pv-warn{background:#3f1d1d;border-color:#7f2d2d;color:#fca5a5}
CSS;
    }

    /**
     * اسکریپت پیش‌نمایش زنده — خواندن مقدار فیلدهای فرم و رندر کارت.
     * همه چیز با createElement/textContent ساخته می‌شود (بدون innerHTML برای داده کاربر).
     */
    private static function previewJs(): string
    {
        return <<<'JS'
(function () {
    var cfg = window.__loginHeroPreview || {};
    var locals = cfg.locals || {};
    var defaults = cfg.defaults || {};
    var engine = null;
    var lastPcfg = '';
    // Pattern layer در پیش‌نمایش
    var patternLayer = null;

    function field(name) {
        var el = document.querySelector('[name=' + name + ']');
        return el ? String(el.value).trim() : '';
    }
    function radio(name, def) {
        var el = document.querySelector('input[name=' + name + ']:checked');
        return el ? String(el.value) : (def || 'none');
    }
    function overlay() {
        var n = parseInt(field('overlayOpacity'), 10);
        if (isNaN(n)) { n = 35; }
        if (n < 0) { n = 0; }
        if (n > 90) { n = 90; }
        return n / 100;
    }
    function patternOpacity() {
        var n = parseInt(field('patternOpacity'), 10);
        if (isNaN(n)) { n = 30; }
        if (n < 0) { n = 0; }
        if (n > 100) { n = 100; }
        return n / 100;
    }
    function hexOk(v) {
        return /^#?[0-9a-fA-F]{6}$/.test(v);
    }
    function normHex(v) {
        return v.charAt(0) === '#' ? v : '#' + v;
    }
    function colorMode() {
        return field('particleColor') || 'auto';
    }
    function particleColors() {
        var k = colorMode();
        if (k === 'custom') {
            var a = field('particleCustomA');
            var b = field('particleCustomB');
            if (hexOk(a) && hexOk(b)) { return [normHex(a), normHex(b)]; }
            return 'auto';
        }
        if (k === 'auto' || k === '') { return 'auto'; }
        return 'preset:' + k;
    }
    function particleCfg() {
        var n = parseInt(field('particleDensity'), 10);
        if (isNaN(n) || n < 10) { n = 70; }
        if (n > 400) { n = 400; }
        return {
            count: n,
            speed: field('particleSpeed') || 'normal',
            lines: field('particleLines') || 'subtle',
            mouse: radio('particleMouse', '1') !== '0',
            colors: particleColors()
        };
    }
    function currentImage() {
        var src = radio('imageSource');
        if (src === 'local') {
            return locals[field('localImage')] || '';
        }
        if (src === 'url') {
            var u = field('imageUrl');
            if (/^https?:\/\//i.test(u) || u.charAt(0) === '/') { return u; }
            return '';
        }
        return '';
    }
    function urlValid() {
        if (radio('imageSource') !== 'url') { return true; }
        var u = field('imageUrl');
        return u === '' || /^https?:\/\//i.test(u) || u.charAt(0) === '/';
    }
    function hexValid() {
        if (radio('imageSource') !== 'particles' || colorMode() !== 'custom') { return true; }
        return hexOk(field('particleCustomA')) && hexOk(field('particleCustomB'));
    }

    function rowOf(name) {
        var el = document.querySelector('input[name=' + name + ']') || document.querySelector('[name=' + name + ']');
        while (el && el !== document.body) {
            if (el.className && String(el.className).indexOf('typecho-option') !== -1) { return el; }
            el = el.parentNode;
        }
        return null;
    }
    function applyRows() {
        var src = radio('imageSource');
        var custom = colorMode() === 'custom';
        var isPatterns = src === 'patterns';
        var show = {
            localImage: src === 'local',
            imageUrl: src === 'url',
            particleDensity: src === 'particles',
            particleColor: src === 'particles',
            particleCustomA: src === 'particles' && custom,
            particleCustomB: src === 'particles' && custom,
            particleSpeed: src === 'particles',
            particleLines: src === 'particles',
            particleMouse: src === 'particles',
            overlayOpacity: src === 'local' || src === 'url',
            patternStyle: isPatterns,
            patternOpacity: isPatterns
        };
        for (var k in show) {
            if (!Object.prototype.hasOwnProperty.call(show, k)) { continue; }
            var row = rowOf(k);
            if (row) { row.style.display = show[k] ? '' : 'none'; }
        }
    }

    function build() {
        var card = document.createElement('div');
        card.className = 'lh-pv';
        try {
            card.style.setProperty('--tr-auth-hero-from', 'rgba(15,23,42,0.90)');
            card.style.setProperty('--tr-auth-hero-to', 'rgba(6,95,70,0.82)');
        } catch (e) { /* مرورگر خیلی قدیمی */ }

        var img = document.createElement('div');
        img.className = 'lh-pv-img';

        var veil = document.createElement('div');
        veil.className = 'lh-pv-veil';

        var txt = document.createElement('div');
        txt.className = 'lh-pv-txt';
        var t = document.createElement('div');
        t.className = 'lh-pv-t';
        var s = document.createElement('div');
        s.className = 'lh-pv-s';
        txt.appendChild(t);
        txt.appendChild(s);

        var f = document.createElement('div');
        f.className = 'lh-pv-f';

        card.appendChild(img);
        card.appendChild(veil);
        card.appendChild(txt);
        card.appendChild(f);

        var cap = document.createElement('div');
        cap.className = 'lh-pv-cap';
        cap.textContent = cfg.caption || '';

        var warn = document.createElement('div');
        warn.className = 'lh-pv-warn';
        warn.textContent = cfg.warn || '';

        return { card: card, img: img, veil: veil, t: t, s: s, f: f, cap: cap, warn: warn };
    }

    function setParticles(on, p) {
        if (!on) {
            if (engine) { engine.destroy(); engine = null; lastPcfg = ''; }
            return;
        }
        var c = particleCfg();
        var sig = window.JSON ? JSON.stringify(c) : String(c.count) + '|' + c.speed + '|' + c.lines + '|' + c.mouse + '|' + c.colors;
        if (engine && sig === lastPcfg) { return; }
        if (engine) { engine.destroy(); }
        lastPcfg = sig;
        engine = window.__lhParticles(p.card, c);
    }

    // rebuild پترن داخل کارت پیش‌نمایش (مشابه patternBootJs اما روی کارت)
    function setPattern(on, p) {
        // حذف لایهٔ قبلی
        if (patternLayer && patternLayer.parentNode) {
            patternLayer.parentNode.removeChild(patternLayer);
            patternLayer = null;
        }
        if (!on) { return; }

        var style = field('patternStyle') || 'aura';
        var container = document.createElement('div');
        container.className = 'lh-pattern lh-pattern-' + style;
        container.style.opacity = String(patternOpacity());
        container.setAttribute('aria-hidden', 'true');

        if (style === 'aura') {
            var a1 = document.createElement('div');
            a1.className = 'lh-aurora lh-aurora-1';
            var a2 = document.createElement('div');
            a2.className = 'lh-aurora lh-aurora-2';
            var a3 = document.createElement('div');
            a3.className = 'lh-aurora lh-aurora-3';
            var grid = document.createElement('div');
            grid.className = 'lh-bg-grid';
            container.appendChild(a1);
            container.appendChild(a2);
            container.appendChild(a3);
            container.appendChild(grid);
        }

        p.card.insertBefore(container, p.card.firstChild);
        patternLayer = container;
    }

    function render(p) {
        var src = radio('imageSource');
        var u = currentImage();

        // پنهان‌سازی لایه‌های غیرمرتبط با حالت patterns
        if (src === 'patterns') {
            setPattern(true, p);
            p.img.style.display = 'none';
            p.img.style.backgroundImage = '';
            p.veil.style.display = 'none';
            setParticles(false, p);
        } else {
            setPattern(false, p);

            p.img.style.display = u ? 'block' : 'none';
            if (u) {
                var safe = u.replace(/["\\\r\n]/g, '');
                p.img.style.backgroundImage = 'url("' + safe + '")';
            }
            p.veil.style.display = u ? 'block' : 'none';
            p.veil.style.opacity = String(overlay());
            setParticles(src === 'particles', p);
        }

        p.t.textContent = field('heroTitle') || defaults.title || '';
        p.s.textContent = field('heroSubtitle') || defaults.subtitle || '';
        p.f.textContent = field('heroFoot') || defaults.foot || '';

        // هشدارها
        var msg = '';
        if (!urlValid()) {
            msg = cfg.warnUrl || '';
        } else if (!hexValid()) {
            msg = cfg.warnHex || '';
        }
        if (msg) {
            p.warn.textContent = msg;
            p.warn.style.display = 'block';
        } else {
            p.warn.style.display = 'none';
        }
    }

    function boot() {
        var host = document.querySelector('.tr-panel') || document.querySelector('.typecho-page-main');
        if (!host) { return; }
        var p = build();
        host.insertBefore(p.warn, host.firstChild);
        host.insertBefore(p.cap, host.firstChild);
        host.insertBefore(p.card, host.firstChild);
        render(p);
        applyRows();
        document.addEventListener('change', function () { applyRows(); render(p); });
        document.addEventListener('input', function () { applyRows(); render(p); });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
JS;
    }
}
