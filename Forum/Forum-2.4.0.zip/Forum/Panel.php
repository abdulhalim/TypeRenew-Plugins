<?php

declare(strict_types=1);

use TypechoPlugin\Forum\Admin;
use TypechoPlugin\Forum\Import;
use TypechoPlugin\Forum\Plugin;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$user->pass('editor');

$e = [Plugin::class, 'e'];
$fa = [Plugin::class, 'faDigits'];

$tab = trim((string) $request->get('tab', 'overview'));
$tabs = ['overview', 'topics', 'answers', 'pending', 'flags', 'categories', 'users', 'tools'];
if (!in_array($tab, $tabs, true)) {
    $tab = 'overview';
}

$status = trim((string) $request->get('status', 'approved'));
if (!in_array($status, ['approved', 'waiting', 'spam', 'done'], true)) {
    $status = 'approved';
}

// ۲.۲.۰ — فیلتر تب کاربران (همه / بلاک‌شده‌ها)
$userFilter = trim((string) $request->get('ufilter', 'all'));
if (!in_array($userFilter, ['all', 'banned'], true)) {
    $userFilter = 'all';
}

$keyword = trim((string) $request->get('keywords'));
$page = max(1, (int) $request->get('page', 1));
$pageSize = 20;

$action = Plugin::adminActionUrl();
$tokenValue = \Widget\Security::alloc()->getToken($request->getRequestUrl());

$stats = Admin::overviewStats();
$counts = Admin::statusCounts();

// نشانی‌های داخلی پنل باید «مطلق» باشند — اسکریپت هستهٔ پیشخوان
// (link-js) به هر لینکی که با نشانی مطلقِ admin شروع نشود target="_blank"
// اضافه می‌کند؛ لینک نسبی باعث باز شدن تب جدید می‌شود (رفع ۲.۰.۴).
$adminBase = \Widget\Options::alloc();

$buildUrl = static function (array $query = []) use ($tab, $adminBase): string {
    $clean = ['tab' => $tab];
    foreach ($query as $k => $v) {
        $v = trim((string) $v);
        if ($v !== '') {
            $clean[$k] = $v;
        }
    }
    return (string) $adminBase->adminUrl(
        'extending.php?panel=Forum%2FPanel.php&' . http_build_query($clean),
        true
    );
};

// دادهٔ هر تب فقط در صورت فعال‌بودنِ همان تب بارگذاری می‌شود (۲.۰.۰)
$topics = $answers = $flaggedItems = $pendingList = null;
if ($tab === 'topics') {
    $topics = Admin::listTopics($status, $keyword, $page, $pageSize);
}
if ($tab === 'answers') {
    $answers = Admin::listPosts($status, $keyword, $page, $pageSize);
}
if ($tab === 'flags') {
    $flaggedItems = Admin::listFlagged(0, $page, $pageSize);
}
if ($tab === 'pending') {
    $pendingList = Admin::listPending($page, $pageSize);
}
$usersList = null;
if ($tab === 'users') {
    $usersList = Admin::listUsers($keyword, $page, $pageSize, $userFilter);
}

$importStats = Import::stats();
$categories = Plugin::categoriesForTemplate(true);
$iconOptions = Plugin::CATEGORY_ICONS;

// آنالیز نمای کلی — فقط در همان تب محاسبه می‌شود
$activitySeries = $tab === 'overview' ? Admin::activitySeries(14) : [];
$hourlyBuckets = $tab === 'overview' ? Admin::hourlyActivity() : [];
$topCats = $tab === 'overview' ? Admin::topCategories(5) : [];

function fpanel_pagination(int $page, int $pages, callable $buildUrl): string
{
    if ($pages <= 1) {
        return '';
    }
    $out = '<div class="fpanel-pager">';
    if ($page > 1) {
        $out .= '<a class="fpanel-page-btn" href="' . htmlspecialchars($buildUrl(['page' => (string) ($page - 1)]), ENT_QUOTES, 'UTF-8') . '">قبلی</a>';
    }
    $from = max(1, $page - 2);
    $to = min($pages, $from + 4);
    $from = max(1, $to - 4);
    for ($p = $from; $p <= $to; $p++) {
        if ($p === $page) {
            $out .= '<span class="fpanel-page-btn is-current">' . Plugin::faDigits($p) . '</span>';
        } else {
            $out .= '<a class="fpanel-page-btn" href="' . htmlspecialchars($buildUrl(['page' => (string) $p]), ENT_QUOTES, 'UTF-8') . '">' . Plugin::faDigits($p) . '</a>';
        }
    }
    if ($page < $pages) {
        $out .= '<a class="fpanel-page-btn" href="' . htmlspecialchars($buildUrl(['page' => (string) ($page + 1)]), ENT_QUOTES, 'UTF-8') . '">بعدی</a>';
    }
    return $out . '</div>';
}

/** حالت خالی زیبا با آیکون (۲.۰.۰) — جایگزین متنِ خالیِ قدیمی */
function fpanel_empty(string $iconSvg, string $title, string $text = ''): string
{
    return '<div class="fpanel-empty-box">'
        . '<span class="fpanel-empty-ico" aria-hidden="true">' . $iconSvg . '</span>'
        . '<p class="fpanel-empty-title">' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</p>'
        . ($text !== '' ? '<p class="fpanel-empty-text">' . htmlspecialchars($text, ENT_QUOTES, 'UTF-8') . '</p>' : '')
        . '</div>';
}

/**
 * نمودار میله‌ای SVG سمت سرور (۲.۰.۰) — بدون هیچ وابستگی خارجی.
 *
 * $bars: [['label' => '…', 'a' => n, 'b' => n|null], …] (چپ → راست)
 * $opts: height، aName، bName (null → تک‌سری)، highlightMax (تک‌سری)
 */
function fpanel_chart_bars(array $bars, array $opts = []): string
{
    $n = count($bars);
    if ($n === 0) {
        return '';
    }

    $height = max(140, (int) ($opts['height'] ?? 210));
    $aName = (string) ($opts['aName'] ?? '');
    $bName = array_key_exists('bName', $opts) ? $opts['bName'] : null;
    $twoSeries = is_string($bName) && $bName !== '';
    $highlightMax = !empty($opts['highlightMax']);

    $W = 720;
    $H = $height;
    $padL = 34;
    $padR = 10;
    $padT = 20;
    $padB = 24;
    $plotW = $W - $padL - $padR;
    $plotH = $H - $padT - $padB;

    $maxV = 1;
    foreach ($bars as $b) {
        $maxV = max($maxV, (int) $b['a'], (int) ($b['b'] ?? 0));
    }
    $nice = max(4, (int) ceil($maxV / 4) * 4);
    if ($nice > $maxV && $maxV <= 4) {
        $nice = 4;
    }

    $groupW = $plotW / $n;
    $innerPad = min(5.0, $groupW * 0.16);
    $barGap = 3.0;
    if ($twoSeries) {
        $barW = max(2.0, ($groupW - $innerPad * 2 - $barGap) / 2);
    } else {
        $barW = max(2.0, min(26.0, $groupW - $innerPad * 2));
    }

    // ساعت/شاخص اوج برای تک‌سری
    $maxIdx = 0;
    if ($highlightMax) {
        foreach ($bars as $i => $b) {
            if ((int) $b['a'] > (int) $bars[$maxIdx]['a']) {
                $maxIdx = $i;
            }
        }
    }

    $svg = '<svg class="fpanel-chart-svg" viewBox="0 0 ' . $W . ' ' . $H . '" role="img" preserveAspectRatio="xMidYMid meet">';

    // خطوط شبکه + برچسب محور عمودی
    foreach ([0, 1, 2] as $g) {
        $gy = $padT + $plotH - ($plotH * $g / 2);
        $gv = (int) round($nice * $g / 2);
        $svg .= '<line x1="' . $padL . '" y1="' . $gy . '" x2="' . ($W - $padR) . '" y2="' . $gy . '"'
            . ' stroke="currentColor" stroke-opacity="' . ($g === 0 ? '.35' : '.14') . '" stroke-width="1"></line>';
        $svg .= '<text x="' . ($padL - 6) . '" y="' . ($gy + 3.5) . '" text-anchor="end" font-size="10" fill="currentColor" fill-opacity=".65">'
            . Plugin::faDigits($gv) . '</text>';
    }

    $labelEvery = max(1, (int) ceil($n / 8));

    foreach ($bars as $i => $b) {
        $gx = $padL + $i * $groupW;
        $label = (string) $b['label'];
        $a = (int) $b['a'];
        $c = (int) ($b['b'] ?? 0);

        $tip = $label . ' — ' . Plugin::faDigits($a) . ' ' . ($twoSeries ? $aName : '');
        if ($twoSeries) {
            $tip .= '، ' . Plugin::faDigits($c) . ' ' . $bName;
        }
        $svg .= '<g><title>' . htmlspecialchars($tip, ENT_QUOTES, 'UTF-8') . '</title>';

        if ($twoSeries) {
            $ax = $gx + $innerPad;
            $bx = $ax + $barW + $barGap;
            $ah = $nice > 0 ? $a / $nice * $plotH : 0;
            $bh = $nice > 0 ? $c / $nice * $plotH : 0;
            if ($a > 0) {
                $svg .= '<rect x="' . round($ax, 1) . '" y="' . round($padT + $plotH - $ah, 1) . '"'
                    . ' width="' . round($barW, 1) . '" height="' . round($ah, 1) . '" rx="3"'
                    . ' fill="var(--tr-accent, #2563eb)"></rect>';
            }
            if ($c > 0) {
                $svg .= '<rect x="' . round($bx, 1) . '" y="' . round($padT + $plotH - $bh, 1) . '"'
                    . ' width="' . round($barW, 1) . '" height="' . round($bh, 1) . '" rx="3"'
                    . ' fill="#0e9f6e"></rect>';
            }
        } else {
            $ax = $gx + ($groupW - $barW) / 2;
            $ah = $nice > 0 ? $a / $nice * $plotH : 0;
            if ($a > 0) {
                $isPeak = $highlightMax && $i === $maxIdx;
                $fill = $isPeak ? '#d97706' : 'var(--tr-accent, #2563eb)';
                $svg .= '<rect x="' . round($ax, 1) . '" y="' . round($padT + $plotH - $ah, 1) . '"'
                    . ' width="' . round($barW, 1) . '" height="' . round($ah, 1) . '" rx="3"'
                    . ' fill="' . $fill . '"></rect>';
                // شمار روی میله‌ها (تک‌سری)
                $svg .= '<text x="' . round($ax + $barW / 2, 1) . '" y="' . round($padT + $plotH - $ah - 4, 1) . '"'
                    . ' text-anchor="middle" font-size="9.5" font-weight="700"'
                    . ($isPeak ? ' fill="#b45309"' : ' fill="currentColor" fill-opacity=".75"') . '>'
                    . Plugin::faDigits($a) . '</text>';
            }
        }

        $svg .= '</g>';

        if ($i % $labelEvery === 0) {
            $svg .= '<text x="' . round($gx + $groupW / 2, 1) . '" y="' . ($H - 7) . '" text-anchor="middle" font-size="10"'
                . ' fill="currentColor" fill-opacity=".65">' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</text>';
        }
    }

    return $svg . '</svg>';
}
?>
<?php
// جلوگیری از کش مرورگر/میان‌افزار برای خود صفحهٔ پنل — خروجی هنوز
// بافر است (extending.php با ob_start گرفته)، پس هدرها مجازند.
if (!headers_sent()) {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
}
?>
<link rel="stylesheet" href="<?php echo $e(Plugin::assetUrl('assets/panel.css')); ?>?v=<?php echo $e(Plugin::assetVer('assets/panel.css')); ?>">
<div class="fpanel" dir="rtl">

    <!-- سربرگ -->
    <section class="fpanel-head">
        <div class="fpanel-head-main">
            <h2 class="fpanel-title">پرسش و پاسخ</h2>
            <p class="fpanel-desc">مدیریت انجمن با دیتابیس مستقل — بدون بار روی سیستم دیدگاه.</p>
        </div>
        <div class="fpanel-pills">
            <span class="tr-pill tr-pill-accent"><?php echo $fa($stats['topics']); ?> پرسش</span>
            <span class="tr-pill"><?php echo $fa($stats['answers']); ?> پاسخ</span>
            <span class="tr-pill<?php echo $stats['waiting'] > 0 ? ' fpill-warn' : ''; ?>"><?php echo $fa($stats['waiting']); ?> در انتظار تأیید</span>
            <span class="tr-pill<?php echo $stats['flags'] > 0 ? ' fpill-warn' : ''; ?>"><?php echo $fa($stats['flags']); ?> گزارش</span>
            <a class="tr-pill tr-pill-btn" href="<?php echo $e(Plugin::forumUrl()); ?>">مشاهدهٔ انجمن</a>
        </div>
    </section>

    <!-- تب‌ها -->
    <nav class="fpanel-tabs" role="tablist" aria-label="ناوبری انجمن">
        <?php
        $tabLabels = [
            'overview'    => 'نمای کلی',
            'topics'      => 'پرسش‌ها',
            'answers'     => 'پاسخ‌ها',
            'pending'     => 'در انتظار تأیید',
            'flags'       => 'گزارش‌ها',
            'categories'  => 'دسته‌بندی‌ها',
            'users'       => 'کاربران',
            'tools'       => 'ابزارها',
        ];
        foreach ($tabLabels as $t => $label):
            $badge = '';
            if ($t === 'pending' && (int) $stats['waiting'] > 0) {
                $badge = ' <span class="fpanel-tab-badge">' . $fa((int) $stats['waiting']) . '</span>';
            } elseif ($t === 'flags' && (int) $stats['flags'] > 0) {
                $badge = ' <span class="fpanel-tab-badge is-warn">' . $fa((int) $stats['flags']) . '</span>';
            } elseif ($t === 'users' && $tab === 'users' && ($usersList['bannedCount'] ?? 0) > 0) {
                $badge = ' <span class="fpanel-tab-badge is-warn">' . $fa((int) $usersList['bannedCount']) . '</span>';
            }
        ?>
        <a class="fpanel-tab<?php echo $tab === $t ? ' is-active' : ''; ?>"
           href="<?php echo $e($buildUrl(['tab' => (string) $t])); ?>"
           aria-current="<?php echo $tab === $t ? 'page' : 'false'; ?>"><?php echo $e($label); ?><?php echo $badge; ?></a>
        <?php endforeach; ?>
    </nav>

    <?php if ($tab === 'overview'): ?>
    <!-- ================= نمای کلی — کارت‌های بزرگ + نمودار آنالیز ================= -->
    <div class="fpanel-pane is-active">

        <div class="fpanel-bcards">
            <a class="fpanel-bcard" href="<?php echo $e($buildUrl(['tab' => 'topics', 'status' => 'approved'])); ?>">
                <span class="fpanel-bcard-ico" aria-hidden="true"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"></path></svg></span>
                <b><?php echo $fa($stats['topics']); ?></b>
                <span>پرسش</span>
            </a>
            <a class="fpanel-bcard is-green" href="<?php echo $e($buildUrl(['tab' => 'answers', 'status' => 'approved'])); ?>">
                <span class="fpanel-bcard-ico" aria-hidden="true"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 17 4 12 9 7"></polyline><path d="M20 18v-2a4 4 0 0 0-4-4H4"></path></svg></span>
                <b><?php echo $fa($stats['answers']); ?></b>
                <span>پاسخ</span>
            </a>
            <a class="fpanel-bcard is-amber<?php echo $stats['waiting'] > 0 ? ' is-alert' : ''; ?>" href="<?php echo $e($buildUrl(['tab' => 'pending'])); ?>">
                <span class="fpanel-bcard-ico" aria-hidden="true"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 22h14"></path><path d="M5 2h14"></path><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"></path><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"></path></svg></span>
                <b><?php echo $fa($stats['waiting']); ?></b>
                <span>در انتظار تأیید</span>
            </a>
            <a class="fpanel-bcard is-rose<?php echo $stats['flags'] > 0 ? ' is-alert' : ''; ?>" href="<?php echo $e($buildUrl(['tab' => 'flags'])); ?>">
                <span class="fpanel-bcard-ico" aria-hidden="true"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path><line x1="4" y1="22" x2="4" y2="15"></line></svg></span>
                <b><?php echo $fa($stats['flags']); ?></b>
                <span>گزارش تخلف</span>
            </a>
            <div class="fpanel-bcard is-violet">
                <span class="fpanel-bcard-ico" aria-hidden="true"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"></path><circle cx="12" cy="12" r="3"></circle></svg></span>
                <b><?php echo $fa((int) ($stats['views'] ?? 0)); ?></b>
                <span>بازدید</span>
            </div>
        </div>

        <div class="fpanel-grid-2">
            <section class="fpanel-card">
                <div class="fpanel-card-h">
                    <h3 class="fpanel-card-t">
                        <span class="fpanel-card-ico" aria-hidden="true"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"></path><path d="M18 17V9"></path><path d="M13 17V5"></path><path d="M8 17v-3"></path></svg></span>
                        روند فعالیت — ۱۴ روز اخیر
                    </h3>
                    <div class="fpanel-chart-legend" aria-hidden="true">
                        <span class="fp-lg"><i style="background: var(--tr-accent, #2563eb);"></i>پرسش</span>
                        <span class="fp-lg"><i style="background: #0e9f6e;"></i>پاسخ</span>
                    </div>
                </div>
                <div class="fpanel-card-b fpanel-chart-wrap">
                    <?php
                        $chartBars = array_map(static fn ($d) => ['label' => $d['label'], 'a' => $d['topics'], 'b' => $d['posts']], $activitySeries);
                        $chartTotal = 0;
                        foreach ($chartBars as $cb) { $chartTotal += (int) $cb['a'] + (int) $cb['b']; }
                        echo $chartTotal > 0
                            ? fpanel_chart_bars($chartBars, ['aName' => 'پرسش', 'bName' => 'پاسخ', 'height' => 210])
                            : fpanel_empty(
                                '<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"></path><path d="M18 17V9"></path><path d="M13 17V5"></path><path d="M8 17v-3"></path></svg>',
                                'فعالیتی در ۱۴ روز اخیر ثبت نشده است',
                                'با ثبت پرسش و پاسخ تازه، روند انجمن در این نمودار نمایش داده می‌شود.'
                            );
                    ?>
                </div>
            </section>

            <section class="fpanel-card">
                <div class="fpanel-card-h">
                    <h3 class="fpanel-card-t">
                        <span class="fpanel-card-ico" aria-hidden="true"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg></span>
                        ساعات شلوغی انجمن
                    </h3>
                    <span class="fpanel-card-sub">۱۸۰ روز اخیر — میلهٔ کهربایی: اوج فعالیت</span>
                </div>
                <div class="fpanel-card-b fpanel-chart-wrap">
                    <?php
                        $hourBars = [];
                        foreach ($hourlyBuckets as $h => $c) {
                            $hourBars[] = ['label' => Plugin::faDigits((string) $h), 'a' => $c];
                        }
                        $hourTotal = array_sum($hourlyBuckets);
                        echo $hourTotal > 0
                            ? fpanel_chart_bars($hourBars, ['aName' => 'پیام', 'bName' => null, 'height' => 210, 'highlightMax' => true])
                            : fpanel_empty(
                                '<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>',
                                'داده‌ای برای سنجش ساعات شلوغی نیست',
                                'پس از ثبت پیام‌های تازه، پرترافیک‌ترین ساعات انجمن در این نمودار مشخص می‌شود.'
                            );
                    ?>
                </div>
            </section>
        </div>

        <section class="fpanel-card">
            <div class="fpanel-card-h">
                <h3 class="fpanel-card-t">
                    <span class="fpanel-card-ico" aria-hidden="true"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"></path></svg></span>
                    دسته‌های پرترافیک
                </h3>
                <a class="fpanel-card-link" href="<?php echo $e($buildUrl(['tab' => 'categories'])); ?>">مدیریت دسته‌ها</a>
            </div>
            <div class="fpanel-card-b">
                <?php
                    $catsTotal = 0;
                    foreach ($topCats as $tc) { $catsTotal += (int) $tc['count']; }
                ?>
                <?php if (empty($topCats) || $catsTotal === 0): ?>
                    <?php echo fpanel_empty(
                        '<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"></path></svg>',
                        'هنوز دسته‌ای تعریف نشده است',
                        'از تب «دسته‌بندی‌ها» اولین دستهٔ انجمن را بسازید.'
                    ); ?>
                <?php else: ?>
                <ul class="fpanel-catbars">
                    <?php $catMax = (int) $topCats[0]['count']; ?>
                    <?php foreach ($topCats as $tc): ?>
                    <li class="fpanel-catbar">
                        <span class="fpanel-catbar-name"><?php echo $e($tc['name']); ?></span>
                        <span class="fpanel-catbar-track">
                            <span class="fpanel-catbar-fill" style="width: <?php echo max(3, (int) round($tc['count'] / max(1, $catMax) * 100)); ?>%;<?php echo $tc['color'] !== '' ? ' background:' . $e($tc['color']) . ';' : ''; ?>"></span>
                        </span>
                        <b class="fpanel-catbar-count"><?php echo $fa((int) $tc['count']); ?> پرسش</b>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
            </div>
        </section>

        <section class="fpanel-card">
            <div class="fpanel-card-h"><h3 class="fpanel-card-t">وضعیت ایمپورت از سیستم قدیمی</h3></div>
            <div class="fpanel-card-b">
                <?php if (!empty($importStats) && empty($importStats['fresh'])): ?>
                <p class="fpanel-note ok">
                    آخرین ایمپورت: <?php echo $e(Plugin::jalali((int) ($importStats['time'] ?? 0))); ?> —
                    <?php echo $fa((int) ($importStats['topics'] ?? 0)); ?> پرسش،
                    <?php echo $fa((int) ($importStats['posts'] ?? 0)); ?> پاسخ،
                    <?php echo $fa((int) ($importStats['categories'] ?? 0)); ?> دسته
                    <?php if ((int) ($importStats['categories_linked'] ?? 0) > 0): ?>(+<?php echo $fa((int) $importStats['categories_linked']); ?> متصل به موجود)<?php endif; ?>،
                    <?php echo $fa((int) ($importStats['polls'] ?? 0)); ?> نظرسنجی و
                    <?php echo $fa((int) ($importStats['notifications'] ?? 0)); ?> اعلان منتقل شده‌اند.
                    داده‌های قدیمی (دیدگاه‌ها) دست‌نخورده باقی مانده‌اند.
                </p>
                <?php if ((int) ($importStats['category_backfill'] ?? 0) > 0): ?>
                <p class="fpanel-note">دستهٔ <?php echo $fa((int) $importStats['category_backfill']); ?> پرسشِ موجود بر اساس دادهٔ قدیمی تکمیل شده است.</p>
                <?php endif; ?>
                <?php elseif (!empty($importStats['fresh'])): ?>
                <p class="fpanel-note">نصب تازه — دادهٔ قدیمی‌ای برای ایمپورت وجود نداشت.</p>
                <?php else: ?>
                <p class="fpanel-note warn">هنوز ایمپورتی انجام نشده است. اگر قبلاً انجمن نسخهٔ ۱ را روی سیستم دیدگاه‌ها داشتید، از تب «ابزارها» ایمپورت را اجرا کنید.</p>
                <?php endif; ?>
            </div>
        </section>
    </div>
    <?php endif; ?>

    <?php if ($tab === 'topics' || $tab === 'answers'): ?>
    <!-- ================= پرسش‌ها / پاسخ‌ها — فقط فهرست خودشان ================= -->
    <?php
        $list = $tab === 'topics' ? $topics : $answers;
        $listLabel = $tab === 'topics' ? 'پرسش' : 'پاسخ';
        $itemKey = $tab === 'topics' ? 'topic' : 'post';
        $statusTabs = [
            'approved' => 'تأییدشده',
            'waiting'  => 'در انتظار تأیید',
            'spam'     => 'اسپم',
            'done'     => 'انجام شده',
        ];
        $listBuildUrl = static function (array $query = []) use ($buildUrl, $status, $keyword): string {
            return $buildUrl($query + ['status' => $status, 'keywords' => $keyword]);
        };
        // statusCounts کلیدهای 'topics' و 'posts' دارد (نه 'answers')
        $countsKey = $tab === 'topics' ? 'topics' : 'posts';
    ?>
    <div class="fpanel-pane is-active">
        <section class="fpanel-card">
            <div class="fpanel-card-h">
                <ul class="fpanel-status-tabs">
                    <?php foreach ($statusTabs as $st => $stLabel): ?>
                    <li class="<?php echo $status === $st ? 'is-current' : ''; ?>">
                        <a href="<?php echo $e($buildUrl(['tab' => $tab, 'status' => (string) $st])); ?>">
                            <?php echo $e($stLabel); ?>
                            <?php if ((int) ($counts[$countsKey][$st] ?? 0) > 0): ?>
                            <span class="fpanel-balloon"><?php echo $fa((int) $counts[$countsKey][$st]); ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <form method="get" class="fpanel-search" action="<?php echo $e((string) $adminBase->adminUrl('extending.php', true)); ?>">
                <input type="hidden" name="panel" value="Forum/Panel.php">
                <input type="hidden" name="tab" value="<?php echo $e($tab); ?>">
                <input type="hidden" name="status" value="<?php echo $e($status); ?>">
                <input type="text" name="keywords" value="<?php echo $e($keyword); ?>" placeholder="جستجو در نویسنده یا متن…">
                <button type="submit" class="fpanel-btn">فیلتر</button>
                <?php if ($keyword !== ''): ?>
                <a class="fpanel-btn fpanel-btn-ghost" href="<?php echo $e($buildUrl(['tab' => $tab, 'status' => (string) $status])); ?>">حذف فیلتر</a>
                <?php endif; ?>
            </form>

            <form method="post" name="forum_<?php echo $tab; ?>_manage" class="fpanel-list-form" data-action="<?php echo $e($action); ?>">
                <input type="hidden" name="_" value="<?php echo $e($tokenValue); ?>">

                <div class="fpanel-operate">
                    <label class="fpanel-sr"><input type="checkbox" class="fpanel-select-all"></label>
                    <div class="fpanel-bulk">
                        <button type="button" class="fpanel-btn fpanel-btn-s" data-do="<?php echo $tab === 'topics' ? 'topic-status' : 'post-status'; ?>" data-status="approved">تأیید</button>
                        <button type="button" class="fpanel-btn fpanel-btn-s" data-do="<?php echo $tab === 'topics' ? 'topic-status' : 'post-status'; ?>" data-status="waiting">در انتظار</button>
                        <button type="button" class="fpanel-btn fpanel-btn-s" data-do="<?php echo $tab === 'topics' ? 'topic-status' : 'post-status'; ?>" data-status="spam">اسپم</button>
                        <button type="button" class="fpanel-btn fpanel-btn-s fpanel-btn-done" data-do="<?php echo $tab === 'topics' ? 'topic-status' : 'post-status'; ?>" data-status="done">انجام شده</button>
                        <button type="button" class="fpanel-btn fpanel-btn-s fpanel-btn-danger" data-do="<?php echo $tab === 'topics' ? 'topic-delete' : 'post-delete'; ?>" data-confirm="مورد(های) انتخابی برای همیشه حذف شوند؟">حذف</button>
                    </div>
                </div>

                <div class="fpanel-table">
                    <?php if (empty($list['rows'])): ?>
                        <?php echo fpanel_empty(
                            '<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 16 12 14 15 10 15 8 12 2 12"></polyline><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"></path></svg>',
                            ($keyword !== '' ? 'چیزی یافت نشد' : ($listLabel === 'پرسش' ? 'پرسشی' : 'پاسخی')) . ' برای نمایش نیست',
                            $keyword !== ''
                                ? 'عبارت دیگری را جستجو کنید یا فیلتر را حذف کنید.'
                                : 'موارد تازه با وضعیت «' . $e($statusTabs[$status] ?? '') . '» در همین صفحه ظاهر می‌شوند.'
                        ); ?>
                    <?php else: ?>
                    <?php foreach ($list['rows'] as $row): ?>
                    <div class="fpanel-row" id="fpanel-<?php echo $itemKey; ?>-<?php echo (int) $row['id']; ?>" data-id="<?php echo (int) $row['id']; ?>">
                        <label class="fpanel-sr"><input type="checkbox" value="<?php echo (int) $row['id']; ?>" name="<?php echo $itemKey; ?>s[]"></label>
                        <div class="fpanel-row-head">
                            <?php echo Plugin::avatar((string) $row['author_name'], (string) $row['author_mail']); ?>
                            <div class="fpanel-row-meta">
                                <strong><?php echo $e($row['author_name'] ?: 'مهمان'); ?></strong>
                                <?php if (!empty($row['author_mail'])): ?><span><?php echo $e($row['author_mail']); ?></span><?php endif; ?>
                                <?php if (!empty($row['author_ip'])): ?><span dir="ltr"><?php echo $e($row['author_ip']); ?></span><?php endif; ?>
                                <span><?php echo $e(Plugin::faRelative((int) $row['created'])); ?> — <?php echo $e(Plugin::jalali((int) $row['created'])); ?></span>
                                <?php if ((int) ($row['flags'] ?? 0) > 0): ?><span class="fpill-warn"><?php echo $fa((int) $row['flags']); ?> گزارش</span><?php endif; ?>
                            </div>
                        </div>
                        <div class="fpanel-row-body">
                            <?php if ($tab === 'topics'):
                                [$t] = Plugin::splitQuestion((string) $row['text']);
                                $rowTitle = Plugin::stripMarkup($t);
                            ?>
                            <a class="fpanel-row-title" href="<?php echo $e(Plugin::threadUrl((int) $row['id'])); ?>"><?php echo $e($rowTitle); ?></a>
                            <?php else: ?>
                            <a class="fpanel-row-title" href="<?php echo $e(Plugin::threadUrl((int) $row['topic_id']) . '#c' . (int) $row['id']); ?>">
                                پاسخ به «<?php echo $e(Plugin::stripMarkup(Plugin::splitQuestion((string) ($row['topic_title'] ?? ''))[0])); ?>»
                            </a>
                            <?php endif; ?>
                            <div class="fpanel-row-excerpt"><?php echo $e(Plugin::excerpt((string) $row['text'], 180)); ?></div>
                        </div>
                        <div class="fpanel-row-actions">
                            <?php if ($row['status'] !== 'approved'): ?>
                            <button type="button" class="fpanel-act fpanel-act-ok" data-do="<?php echo $itemKey; ?>-status" data-id="<?php echo (int) $row['id']; ?>" data-status="approved">تأیید</button>
                            <?php endif; ?>
                            <?php if ($row['status'] !== 'waiting'): ?>
                            <button type="button" class="fpanel-act fpanel-act-wait" data-do="<?php echo $itemKey; ?>-status" data-id="<?php echo (int) $row['id']; ?>" data-status="waiting">در انتظار</button>
                            <?php endif; ?>
                            <?php if ($row['status'] !== 'spam'): ?>
                            <button type="button" class="fpanel-act fpanel-act-spam" data-do="<?php echo $itemKey; ?>-status" data-id="<?php echo (int) $row['id']; ?>" data-status="spam">اسپم</button>
                            <?php endif; ?>
                            <?php if ($row['status'] !== 'done'): ?>
                            <button type="button" class="fpanel-act fpanel-act-done" data-do="<?php echo $itemKey; ?>-status" data-id="<?php echo (int) $row['id']; ?>" data-status="done">انجام شده</button>
                            <?php endif; ?>
                            <button type="button" class="fpanel-act fpanel-act-edit" data-edit="<?php echo $itemKey; ?>" data-id="<?php echo (int) $row['id']; ?>">ویرایش</button>
                            <?php if ($tab === 'topics'): ?>
                            <button type="button" class="fpanel-act fpanel-act-reply" data-reply="<?php echo (int) $row['id']; ?>">پاسخ</button>
                            <?php endif; ?>
                            <button type="button" class="fpanel-act fpanel-act-danger" data-do="<?php echo $itemKey; ?>-delete" data-id="<?php echo (int) $row['id']; ?>" data-confirm="این مورد برای همیشه حذف شود؟">حذف</button>
                        </div>
                        <script type="application/json" class="fpanel-row-data"><?php
                            // نظرسنجی پرسش برای ویرایش در مودال (۲.۰.۰)
                            $rowPoll = null;
                            if ($tab === 'topics' && Plugin::pollsEnabled()) {
                                $p = Plugin::getPoll((int) $row['id']);
                                if ($p !== null) {
                                    $rowPoll = ['question' => $p['question'], 'options' => implode("\n", $p['options'])];
                                }
                            }
                            echo json_encode([
                                'id' => (int) $row['id'],
                                'type' => $itemKey,
                                'author' => (string) $row['author_name'],
                                'mail' => (string) $row['author_mail'],
                                'url' => (string) ($row['author_url'] ?? ''),
                                'text' => (string) $row['text'],
                                'title' => $tab === 'topics' ? (string) Plugin::stripMarkup(Plugin::splitQuestion((string) $row['text'])[0]) : '',
                                'poll' => $rowPoll,
                            ], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
                        ?></script>
                    </div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </form>

            <?php echo fpanel_pagination((int) $list['page'], (int) $list['pages'], $listBuildUrl); ?>
        </section>
    </div>
    <?php endif; ?>

    <?php if ($tab === 'pending'): ?>
    <!-- ================= در انتظار تأیید — صف ترکیبی پرسش و پاسخ ================= -->
    <div class="fpanel-pane is-active">
        <section class="fpanel-card">
            <div class="fpanel-card-h">
                <h3 class="fpanel-card-t">
                    <span class="fpanel-card-ico" aria-hidden="true"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 22h14"></path><path d="M5 2h14"></path><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"></path><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"></path></svg></span>
                    صف تأیید — <?php echo $fa((int) ($pendingList['total'] ?? 0)); ?> مورد
                </h3>
                <span class="fpanel-card-sub">پرسش‌ها و پاسخ‌های در انتظار — جدیدترین در ابتدا</span>
            </div>

            <div class="fpanel-table">
                <?php if (empty($pendingList['rows'])): ?>
                    <?php echo fpanel_empty(
                        '<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><path d="m9 12 2 2 4-4"></path></svg>',
                        'صف تأیید خالی است',
                        'همهٔ پیام‌ها تأیید شده‌اند؛ موارد تازه بلافاصله در همین صفحه ظاهر می‌شوند.'
                    ); ?>
                <?php else: ?>
                <form method="post" class="fpanel-list-form" data-action="<?php echo $e($action); ?>">
                    <input type="hidden" name="_" value="<?php echo $e($tokenValue); ?>">
                    <?php foreach ($pendingList['rows'] as $row): ?>
                    <?php
                        $isTopic = $row['kind'] === 'topic';
                        $itemKey = $isTopic ? 'topic' : 'post';
                        if ($isTopic) {
                            $rowTitle = Plugin::stripMarkup(Plugin::splitQuestion((string) $row['text'])[0]);
                        }
                    ?>
                    <div class="fpanel-row fpanel-row--nocheck" id="fpanel-<?php echo $itemKey; ?>-<?php echo (int) $row['id']; ?>" data-id="<?php echo (int) $row['id']; ?>">
                        <div class="fpanel-row-head">
                            <?php echo Plugin::avatar((string) $row['author_name'], (string) $row['author_mail']); ?>
                            <div class="fpanel-row-meta">
                                <strong><?php echo $e($row['author_name'] ?: 'مهمان'); ?></strong>
                                <span class="fpanel-kind-chip"><?php echo $isTopic ? 'پرسش' : 'پاسخ'; ?></span>
                                <?php if (!empty($row['author_mail'])): ?><span><?php echo $e($row['author_mail']); ?></span><?php endif; ?>
                                <?php if (!empty($row['author_ip'])): ?><span dir="ltr"><?php echo $e($row['author_ip']); ?></span><?php endif; ?>
                                <span><?php echo $e(Plugin::faRelative((int) $row['created'])); ?> — <?php echo $e(Plugin::jalali((int) $row['created'])); ?></span>
                            </div>
                        </div>
                        <div class="fpanel-row-body">
                            <?php if ($isTopic): ?>
                            <a class="fpanel-row-title" href="<?php echo $e(Plugin::threadUrl((int) $row['id'])); ?>"><?php echo $e($rowTitle); ?></a>
                            <?php else: ?>
                            <a class="fpanel-row-title" href="<?php echo $e(Plugin::threadUrl((int) $row['topic_id']) . '#c' . (int) $row['id']); ?>">
                                پاسخ به «<?php echo $e(Plugin::stripMarkup(Plugin::splitQuestion((string) ($row['topic_title'] ?? ''))[0])); ?>»
                            </a>
                            <?php endif; ?>
                            <div class="fpanel-row-excerpt"><?php echo $e(Plugin::excerpt((string) $row['text'], 180)); ?></div>
                        </div>
                        <div class="fpanel-row-actions">
                            <button type="button" class="fpanel-act fpanel-act-ok" data-do="<?php echo $itemKey; ?>-status" data-id="<?php echo (int) $row['id']; ?>" data-status="approved">تأیید</button>
                            <button type="button" class="fpanel-act fpanel-act-edit" data-edit="<?php echo $itemKey; ?>" data-id="<?php echo (int) $row['id']; ?>">ویرایش</button>
                            <?php if ($isTopic): ?>
                            <button type="button" class="fpanel-act fpanel-act-reply" data-reply="<?php echo (int) $row['id']; ?>">پاسخ</button>
                            <?php endif; ?>
                            <button type="button" class="fpanel-act fpanel-act-danger" data-do="<?php echo $itemKey; ?>-delete" data-id="<?php echo (int) $row['id']; ?>" data-confirm="این مورد برای همیشه حذف شود؟">حذف</button>
                        </div>
                        <script type="application/json" class="fpanel-row-data"><?php
                            // نظرسنجی پرسش برای ویرایش در مودال (۲.۰.۰)
                            $rowPoll = null;
                            if ($isTopic && Plugin::pollsEnabled()) {
                                $p = Plugin::getPoll((int) $row['id']);
                                if ($p !== null) {
                                    $rowPoll = ['question' => $p['question'], 'options' => implode("\n", $p['options'])];
                                }
                            }
                            echo json_encode([
                                'id' => (int) $row['id'],
                                'type' => $itemKey,
                                'author' => (string) $row['author_name'],
                                'mail' => (string) $row['author_mail'],
                                'url' => (string) ($row['author_url'] ?? ''),
                                'text' => (string) $row['text'],
                                'title' => $isTopic ? (string) Plugin::stripMarkup(Plugin::splitQuestion((string) $row['text'])[0]) : '',
                                'poll' => $rowPoll,
                            ], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
                        ?></script>
                    </div>
                    <?php endforeach; ?>
                </form>
                <?php endif; ?>
            </div>

            <?php echo fpanel_pagination((int) ($pendingList['page'] ?? 1), (int) ($pendingList['pages'] ?? 1), $buildUrl); ?>
        </section>
    </div>
    <?php endif; ?>

    <?php if ($tab === 'flags'): ?>
    <!-- ================= گزارش‌ها ================= -->
    <div class="fpanel-pane is-active">
        <section class="fpanel-card">
            <div class="fpanel-card-h"><h3 class="fpanel-card-t">گزارش‌های تخلف کاربران</h3></div>
            <div class="fpanel-card-b">
                <?php if (empty($flaggedItems['rows'])): ?>
                    <?php echo fpanel_empty(
                        '<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path><line x1="4" y1="22" x2="4" y2="15"></line></svg>',
                        'گزارش فعالی وجود ندارد',
                        'عالی! در حال حاضر هیچ پرسش یا پاسخی توسط کاربران گزارش نشده است.'
                    ); ?>
                <?php else: ?>
                <div class="fpanel-table">
                    <?php foreach ($flaggedItems['rows'] as $f): ?>
                    <div class="fpanel-row fpanel-row--nocheck">
                        <div class="fpanel-row-head">
                            <?php echo Plugin::avatar((string) $f['author_name'], (string) $f['author_mail']); ?>
                            <div class="fpanel-row-meta">
                                <strong><?php echo $e($f['author_name'] ?: 'مهمان'); ?></strong>
                                <span class="fpill-warn"><?php echo $fa((int) $f['count']); ?> گزارش</span>
                                <span><?php echo $e(Plugin::faRelative((int) $f['created'])); ?></span>
                            </div>
                        </div>
                        <div class="fpanel-row-body">
                            <a class="fpanel-row-title" href="<?php echo $e(Plugin::threadUrl((int) $f['topic_id']) . '#c' . (int) $f['item_id']); ?>">
                                <?php echo $e($f['type'] === 'topic' ? 'پرسش' : 'پاسخ'); ?>: <?php echo $e(Plugin::excerpt((string) $f['text'], 120)); ?>
                            </a>
                        </div>
                        <div class="fpanel-row-actions">
                            <button type="button" class="fpanel-act fpanel-act-ok" data-do="clear-flags" data-id="<?php echo (int) $f['item_id']; ?>">رد گزارش‌ها</button>
                            <button type="button" class="fpanel-act fpanel-act-danger" data-do="<?php echo $f['type']; ?>-delete" data-id="<?php echo (int) $f['item_id']; ?>" data-confirm="این مورد حذف شود؟">حذف مورد</button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php echo fpanel_pagination((int) $flaggedItems['page'], (int) $flaggedItems['pages'], $buildUrl); ?>
                <?php endif; ?>
            </div>
        </section>
    </div>
    <?php endif; ?>

    <?php if ($tab === 'categories'): ?>
    <!-- ================= دسته‌بندی‌ها ================= -->
    <?php /* (۲.۳.۰) فهرست پیشنهادی آیکون‌های Lucide برای input های آیکون —
       فیلد آیکون اکنون متن آزاد است تا ایموجی هم بتوان paste کرد */ ?>
    <datalist id="fpanel-cat-icon-options">
        <?php foreach ($iconOptions as $iconKey => $iconLabel): ?>
        <option value="<?php echo $e($iconKey); ?>"><?php echo $e($iconLabel); ?></option>
        <?php endforeach; ?>
    </datalist>
    <div class="fpanel-pane is-active">
        <section class="fpanel-card">
            <div class="fpanel-card-h"><h3 class="fpanel-card-t">افزودن دستهٔ جدید</h3></div>
            <div class="fpanel-card-b">
                <form method="post" action="<?php echo $e($action); ?>?do=cat-create" class="fpanel-form">
                    <input type="hidden" name="_" value="<?php echo $e($tokenValue); ?>">
                    <div class="fpanel-fields">
                        <div class="fpanel-field">
                            <label>نام دسته *</label>
                            <input type="text" name="name" required maxlength="80">
                        </div>
                        <div class="fpanel-field">
                            <label>آیکون</label>
                            <input type="text" name="icon" maxlength="32" autocomplete="off"
                                   list="fpanel-cat-icon-options" placeholder="🚀 یا code یا lucide:code">
                        </div>
                        <div class="fpanel-field">
                            <label>رنگ (هگز)</label>
                            <input type="text" name="color" placeholder="#2563eb" maxlength="7" dir="ltr">
                        </div>
                        <div class="fpanel-field">
                            <label>ترتیب</label>
                            <input type="number" name="order" value="0" min="0" dir="ltr">
                        </div>
                        <div class="fpanel-field fpanel-field-btn">
                            <button type="submit" class="fpanel-btn fpanel-btn-primary">افزودن دسته</button>
                        </div>
                    </div>
                </form>
            </div>
        </section>

        <section class="fpanel-card">
            <div class="fpanel-card-h"><h3 class="fpanel-card-t">دسته‌های موجود</h3></div>
            <div class="fpanel-card-b">
                <?php if (empty($categories)): ?>
                    <?php echo fpanel_empty(
                        '<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"></path></svg>',
                        'هنوز دسته‌ای تعریف نشده است',
                        'از فرم بالا اولین دستهٔ انجمن را بسازید.'
                    ); ?>
                <?php else: ?>
                <?php foreach ($categories as $cat): ?>
                <form method="post" action="<?php echo $e($action); ?>?do=cat-update" class="fpanel-cat-row">
                    <input type="hidden" name="_" value="<?php echo $e($tokenValue); ?>">
                    <input type="hidden" name="id" value="<?php echo (int) $cat['id']; ?>">
                    <div class="fpanel-fields">
                        <div class="fpanel-field">
                            <label>نام</label>
                            <input type="text" name="name" value="<?php echo $e($cat['name']); ?>" required maxlength="80">
                        </div>
                        <div class="fpanel-field">
                            <label>آیکون</label>
                            <input type="text" name="icon" maxlength="32" autocomplete="off"
                                   list="fpanel-cat-icon-options" placeholder="🚀 یا code یا lucide:code"
                                   value="<?php echo $e($cat['icon']); ?>">
                        </div>
                        <div class="fpanel-field">
                            <label>رنگ</label>
                            <input type="text" name="color" value="<?php echo $e($cat['color']); ?>" maxlength="7" dir="ltr">
                        </div>
                        <div class="fpanel-field">
                            <label>ترتیب</label>
                            <input type="number" name="order" value="<?php echo (int) $cat['order']; ?>" min="0" dir="ltr">
                        </div>
                        <div class="fpanel-field fpanel-field-btn">
                            <button type="submit" class="fpanel-btn fpanel-btn-s">ذخیره</button>
                            <button type="submit" formaction="<?php echo $e($action); ?>?do=cat-delete" class="fpanel-btn fpanel-btn-s fpanel-btn-danger"
                                    data-fp-confirm="دستهٔ «<?php echo $e($cat['name']); ?>» حذف شود؟ پرسش‌هایش به «بدون دسته» منتقل می‌شوند."
                                    data-fp-confirm-title="حذف دسته"
                                    data-fp-confirm-variant="danger"
                                    data-fp-confirm-ok="بله، حذف شود">حذف</button>
                            <span class="fpanel-cat-count"><?php echo $fa((int) $cat['topicCount']); ?> پرسش</span>
                        </div>
                    </div>
                </form>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </section>
    </div>
    <?php endif; ?>

    <?php if ($tab === 'users'): ?>
    <!-- ================= کاربران — بلاک اداری (۲.۲.۰) ================= -->
    <div class="fpanel-pane is-active">
        <section class="fpanel-card">
            <div class="fpanel-card-h">
                <h3 class="fpanel-card-t">
                    <span class="fpanel-card-ico" aria-hidden="true"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg></span>
                    کاربران انجمن — <?php echo $fa((int) ($usersList['total'] ?? 0)); ?> نفر
                    <?php if (($usersList['bannedCount'] ?? 0) > 0): ?>
                    <span class="fpill-warn"><?php echo $fa((int) $usersList['bannedCount']); ?> بلاک‌شده</span>
                    <?php endif; ?>
                </h3>
                <ul class="fpanel-status-tabs">
                    <li class="<?php echo $userFilter === 'all' ? 'is-current' : ''; ?>">
                        <a href="<?php echo $e($buildUrl(['tab' => 'users', 'ufilter' => 'all'])); ?>">همه</a>
                    </li>
                    <li class="<?php echo $userFilter === 'banned' ? 'is-current' : ''; ?>">
                        <a href="<?php echo $e($buildUrl(['tab' => 'users', 'ufilter' => 'banned'])); ?>">بلاک‌شده‌ها</a>
                    </li>
                </ul>
            </div>

            <form method="get" class="fpanel-search" action="<?php echo $e((string) $adminBase->adminUrl('extending.php', true)); ?>">
                <input type="hidden" name="panel" value="Forum/Panel.php">
                <input type="hidden" name="tab" value="users">
                <input type="hidden" name="ufilter" value="<?php echo $e($userFilter); ?>">
                <input type="text" name="keywords" value="<?php echo $e($keyword); ?>" placeholder="جستجوی نام یا ایمیل…">
                <button type="submit" class="fpanel-btn">جستجو</button>
                <?php if ($keyword !== ''): ?>
                <a class="fpanel-btn fpanel-btn-ghost" href="<?php echo $e($buildUrl(['tab' => 'users'])); ?>">حذف فیلتر</a>
                <?php endif; ?>
            </form>

            <div class="fpanel-table">
                <?php if (empty($usersList['rows'])): ?>
                    <?php echo fpanel_empty(
                        '<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>',
                        $userFilter === 'banned' ? 'کاربر بلاک‌شده‌ای وجود ندارد' : 'کاربری یافت نشد',
                        $userFilter === 'banned'
                            ? 'با بلاک موقت یا همیشه، کاربران اینجا فهرست می‌شوند.'
                            : 'عبارت دیگری را جستجو کنید یا فیلتر را حذف کنید.'
                    ); ?>
                <?php else: ?>
                <?php foreach ($usersList['rows'] as $u): ?>
                <?php
                    $uBan = $u['ban'];
                    $uGroup = $u['group'];
                    $uGroupLabel = ['administrator' => 'مدیرکل', 'editor' => 'ویراستار', 'contributor' => 'نویسنده', 'subscriber' => 'عضو'][$uGroup] ?? $uGroup;
                    $uIsProtected = in_array($uGroup, ['administrator', 'editor'], true) || (int) $u['uid'] === Plugin::ownerUid();
                ?>
                <div class="fpanel-row fpanel-row--nocheck fpanel-user-row<?php echo $uBan !== null ? ' is-banned' : ''; ?>">
                    <div class="fpanel-row-head">
                        <?php echo Plugin::avatar((string) $u['name'], (string) $u['mail']); ?>
                        <div class="fpanel-row-meta">
                            <strong><?php echo $e($u['name']); ?></strong>
                            <span class="fpanel-kind-chip"><?php echo $e($uGroupLabel); ?></span>
                            <?php if (!empty($u['mail'])): ?><span><?php echo $e($u['mail']); ?></span><?php endif; ?>
                            <span><?php echo $fa((int) $u['questions']); ?> پرسش، <?php echo $fa((int) $u['answers']); ?> پاسخ</span>
                            <?php if ((int) $u['created'] > 0): ?><span>عضویت: <?php echo $e(Plugin::jalali((int) $u['created'])); ?></span><?php endif; ?>
                            <?php if ($uBan !== null): ?>
                            <span class="fpill-warn">بلاک: <?php echo $e(Plugin::banUntilText($uBan)); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="fpanel-row-body">
                        <?php if ($uBan !== null): ?>
                        <div class="fpanel-row-excerpt">
                            وضعیت: مسدود — <?php echo $e(Plugin::banUntilText($uBan)); ?>.
                            <?php echo trim((string) $uBan['reason']) !== '' ? 'دلیل: ' . $e(trim((string) $uBan['reason'])) . '.' : ''; ?>
                            <?php echo (int) $uBan['created'] > 0 ? 'از ' . $e(Plugin::jalali((int) $uBan['created'])) . '.' : ''; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="fpanel-row-actions">
                        <?php if ($uBan !== null): ?>
                        <form method="post" action="<?php echo $e($action); ?>?do=user-unban" class="fpanel-inline-form">
                            <input type="hidden" name="_" value="<?php echo $e($tokenValue); ?>">
                            <input type="hidden" name="uid" value="<?php echo (int) $u['uid']; ?>">
                            <input type="hidden" name="back" value="<?php echo $e('panel=Forum%2FPanel.php&tab=users&ufilter=' . $userFilter); ?>">
                            <button type="submit" class="fpanel-act fpanel-act-ok" data-fp-confirm="بلاک این کاربر برداشته شود؟" data-fp-confirm-title="رفع بلاک" data-fp-confirm-variant="ok" data-fp-confirm-ok="بله، برداشته شود">رفع بلاک</button>
                        </form>
                        <?php elseif ($uIsProtected): ?>
                        <span class="fpanel-note" style="margin:0;">کاربر مدیریتی — قابل بلاک نیست</span>
                        <?php else: ?>
                        <form method="post" action="<?php echo $e($action); ?>?do=user-ban" class="fpanel-ban-form">
                            <input type="hidden" name="_" value="<?php echo $e($tokenValue); ?>">
                            <input type="hidden" name="uid" value="<?php echo (int) $u['uid']; ?>">
                            <input type="hidden" name="back" value="<?php echo $e('panel=Forum%2FPanel.php&tab=users&ufilter=' . $userFilter); ?>">
                            <div class="fpanel-ban-fields">
                                <select name="duration" class="fpanel-ban-duration" aria-label="مدت بلاک">
                                    <option value="perm">همیشه</option>
                                    <option value="12h">۱۲ ساعت</option>
                                    <option value="1d">۱ روز</option>
                                    <option value="3d">۳ روز</option>
                                    <option value="7d" selected>۷ روز</option>
                                    <option value="30d">۳۰ روز</option>
                                    <option value="90d">۹۰ روز</option>
                                    <option value="custom">دلخواه (ساعت)</option>
                                </select>
                                <input type="number" name="custom_hours" min="1" max="87600" placeholder="ساعت" class="fpanel-ban-hours" hidden>
                                <input type="text" name="reason" maxlength="255" placeholder="دلیل (اختیاری)" class="fpanel-ban-reason">
                                <button type="submit" class="fpanel-act fpanel-act-danger"
                                        data-fp-confirm="این کاربر بلاک شود؟ تا پایان مدت، امکان پرسش/پاسخ/پسند/گزارش نخواهد داشت." data-fp-confirm-title="بلاک کاربر" data-fp-confirm-variant="danger" data-fp-confirm-ok="بله، بلاک شود">بلاک</button>
                            </div>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <?php
                $usersBuildUrl = static function (array $query = []) use ($buildUrl, $userFilter, $keyword): string {
                    return $buildUrl($query + ['ufilter' => $userFilter, 'keywords' => $keyword]);
                };
                echo fpanel_pagination((int) ($usersList['page'] ?? 1), (int) ($usersList['pages'] ?? 1), $usersBuildUrl);
            ?>
        </section>
    </div>
    <?php endif; ?>

    <?php if ($tab === 'tools'): ?>
    <!-- ================= ابزارها ================= -->
    <div class="fpanel-pane is-active">
        <section class="fpanel-card">
            <div class="fpanel-card-h"><h3 class="fpanel-card-t">گزارش سیستم قدیمی (فقط خواندن)</h3></div>
            <div class="fpanel-card-b">
                <?php $scan = Import::legacySummary(); ?>
                <?php if (empty($scan['has_post'])): ?>
                <p class="fpanel-note">نوشتهٔ پشتیبان انجمن قدیمی (slug: forum-archive) پیدا نشد — یا هرگز انجمن نسخهٔ ۱ فعال نبوده یا داده‌اش حذف شده است.</p>
                <?php else: ?>
                <p class="fpanel-note ok">
                    دادهٔ قدیمی شناسایی شد: <?php echo $fa((int) $scan['questions']); ?> پرسش،
                    <?php echo $fa((int) $scan['answers']); ?> پاسخ،
                    <?php echo $fa(count($scan['cats'])); ?> دسته و
                    <?php echo $fa((int) $scan['topic_cats']); ?> انتساب پرسش→دسته.
                </p>
                <?php if (!empty($scan['cats'])): ?>
                <p class="fpanel-note">
                    دسته‌های قدیمی: <?php echo $e(implode('، ', array_map(static fn ($c) => $c['name'], $scan['cats']))); ?>
                    — منبع: ردیف <?php echo $e($scan['cats_source']); ?> (قالب <?php echo $e($scan['cats_format']); ?>).
                </p>
                <?php elseif ($scan['cats_format'] === 'none'): ?>
                <p class="fpanel-note warn">
                    در سیستم قدیمی هیچ ردیف دسته‌ای پیدا نشد (ext:Forum-categories و نام‌های مشابه غایب‌اند). اگر در انجمن قدیمی دسته می‌دیدید، احتمالاً نسخهٔ افزونهٔ قدیمی‌تان داده را با نام یا قالب دیگری ذخیره می‌کرده است — مقدار ردیف مربوطه را برای سازندهٔ افزونه بفرستید تا پشتیبانی شود.
                </p>
                <?php elseif ($scan['cats_format'] === 'empty'): ?>
                <p class="fpanel-note warn">ردیف <?php echo $e($scan['cats_source']); ?> موجود است اما خالی است — در سیستم قدیمی دسته‌ای ثبت نشده بود.</p>
                <?php else: ?>
                <p class="fpanel-note warn">ردیف <?php echo $e($scan['cats_source']); ?> (<?php echo $fa((int) $scan['cats_raw_len']); ?> بایت) پیدا شد اما قابل خواندن نبود (قالب: <?php echo $e($scan['cats_format']); ?>) — مقدار این ردیف را برای سازندهٔ افزونه بفرستید.</p>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </section>

        <section class="fpanel-card">
            <div class="fpanel-card-h"><h3 class="fpanel-card-t">ایمپورت از سیستم قدیمی</h3></div>
            <div class="fpanel-card-b">
                <p class="fpanel-note">اگر انجمن نسخهٔ ۱ (بر پایهٔ دیدگاه‌ها) را داشته‌اید، این ابزار پرسش‌ها، پاسخ‌ها، دسته‌ها، نظرسنجی‌ها، اعلان‌ها و گزارش‌ها را با حفظ شناسه‌ها به جداول جدید منتقل می‌کند. عملیات ایمپورت ایمن و تکرارپذیر است — موارد قبلاً منتقل‌شده دوباره منتقل نمی‌شوند و دادهٔ قدیمی حذف نمی‌شود. دسته‌های قدیمی به‌صورت هوشمند ادغام یا با شناسهٔ تازه درج می‌شوند و پرسش‌های موجودِ بدون دسته هم بر اساس دادهٔ قدیمی تکمیل می‌شوند.</p>
                <form method="post" action="<?php echo $e($action); ?>?do=reimport" class="fpanel-inline-form">
                    <input type="hidden" name="_" value="<?php echo $e($tokenValue); ?>">
                    <button type="submit" class="fpanel-btn fpanel-btn-primary">اجرای ایمپورت / بررسی دادهٔ باقی‌مانده</button>
                </form>
            </div>
        </section>

        <section class="fpanel-card">
            <div class="fpanel-card-h"><h3 class="fpanel-card-t">پاک‌سازی گزارش‌های مرده</h3></div>
            <div class="fpanel-card-b">
                <p class="fpanel-note">گزارش‌هایی که آیتمشان حذف شده اما رد نشده‌اند را پاک می‌کند.</p>
                <form method="post" action="<?php echo $e($action); ?>?do=prune-flags" class="fpanel-inline-form">
                    <input type="hidden" name="_" value="<?php echo $e($tokenValue); ?>">
                    <button type="submit" class="fpanel-btn">پاک‌سازی</button>
                </form>
            </div>
        </section>
    </div>
    <?php endif; ?>
</div>

<!-- قالب ویرایش/پاسخ — به‌صورت مودال باز می‌شود (hidden در CSS تضمین شده) -->
<div class="fpanel-modal" id="fpanelModal" hidden role="dialog" aria-modal="true" aria-labelledby="fpanelModalTitle">
    <div class="fpanel-modal-box">
        <div class="fpanel-modal-head">
            <h3 class="fpanel-modal-title" id="fpanelModalTitle"><span class="fpanel-title-ico" id="fpanelModalTitleIco" aria-hidden="true"></span><span id="fpanelModalTitleText">ویرایش</span></h3>
            <button type="button" class="fpanel-modal-close" data-close aria-label="بستن">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>
            </button>
        </div>
        <form method="post" id="fpanelModalForm" action="">
            <input type="hidden" name="_" value="<?php echo $e($tokenValue); ?>">
            <div class="fpanel-modal-body">
                <div class="fpanel-field" data-f="title">
                    <label>عنوان پرسش</label>
                    <input type="text" name="title" maxlength="120">
                </div>
                <div class="fpanel-field"><label>نام نویسنده</label><input type="text" name="author" maxlength="150"></div>
                <div class="fpanel-field"><label>ایمیل</label><input type="email" name="mail" dir="ltr"></div>
                <div class="fpanel-field"><label>نشانی وب</label><input type="text" name="url" dir="ltr"></div>
                <div class="fpanel-field"><label>متن</label><textarea name="text" rows="6" dir="auto"></textarea></div>
                <?php if (Plugin::pollsEnabled()): ?>
                <div class="fpanel-field fpanel-poll-field" data-f="poll">
                    <input type="hidden" name="poll_present" value="1">
                    <label class="fpanel-poll-toggle">
                        <input type="checkbox" name="has_poll" value="1" class="fpanel-poll-toggle-box">
                        <span id="fpanelPollLabel">نظرسنجی</span>
                    </label>
                    <div class="fpanel-poll-extra" id="fpanelPollExtra" hidden>
                        <input type="text" name="poll_question" maxlength="200" dir="auto" placeholder="سؤال نظرسنجی…">
                        <textarea name="poll_options" rows="4" maxlength="500" dir="auto" placeholder="هر سطر یک گزینه — حداقل ۲، حداکثر ۸ گزینه"></textarea>
                        <p class="fpanel-field-note">با برداشتن تیک و ذخیره، نظرسنجی و همهٔ آرا آن حذف می‌شود. تغییر ترتیب یا حذف گزینه ممکن است آرا را جابه‌جا کند.</p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <div class="fpanel-modal-foot">
                <button type="submit" class="fpanel-btn fpanel-btn-primary">
                    <span class="fpanel-btn-ico" aria-hidden="true"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 12l-5 5"></path></svg></span>
                    <span>ذخیره</span>
                </button>
                <button type="button" class="fpanel-btn fpanel-btn-ghost" data-close>
                    <span class="fpanel-btn-ico" aria-hidden="true"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg></span>
                    <span>انصراف</span>
                </button>
            </div>
        </form>
    </div>
</div>

<script src="<?php echo $e(Plugin::assetUrl('assets/panel.js')); ?>?v=<?php echo $e(Plugin::assetVer('assets/panel.js')); ?>"></script>
