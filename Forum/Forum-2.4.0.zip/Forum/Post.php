<?php
namespace TypechoPlugin\Forum;

use Typecho\Cookie;
use Typecho\Db;
use Typecho\Validate;
use Widget\ActionInterface;
use Widget\Base;
use Widget\Feedback;
use Widget\Options;
use Widget\User;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Post extends Base implements ActionInterface
{
    public function action()
    {
        if (!$this->request->isPost()) {
            $this->response->redirect(Plugin::forumUrl());
        }

        // ------------------------------------------------------------------
        // حالت‌های مدیریتی: قفل/سنجاق/پیگیری/ویرایش/دسته‌بندی (پیش از جریان ثبت)
        // ------------------------------------------------------------------
        $mode = (string) $this->request->get('mode');
        if ($mode === 'lock' || $mode === 'unlock') {
            $this->handleLockToggle($mode);
            return;
        }
        if ($mode === 'pin' || $mode === 'unpin') {
            $this->handlePinToggle($mode);
            return;
        }
        if ($mode === 'track' || $mode === 'untrack') {
            $this->handleTrackToggle($mode);
            return;
        }
        if ($mode === 'hide' || $mode === 'unhide') {
            $this->handleHideToggle($mode);
            return;
        }
        if ($mode === 'delete') {
            $this->handleDelete();
            return;
        }
        if ($mode === 'best' || $mode === 'unbest') {
            $this->handleBestToggle($mode);
            return;
        }
        if ($mode === 'approve') {
            $this->handleApprove();
            return;
        }
        if ($mode === 'flag') {
            $this->handleFlag();
            return;
        }
        if ($mode === 'clear-flags') {
            $this->handleClearFlags();
            return;
        }
        if ($mode === 'read-notifs') {
            $this->handleReadNotifs();
            return;
        }
        if ($mode === 'read-notif') {
            $this->handleReadNotif();
            return;
        }
        if ($mode === 'update-profile') {
            $this->handleUpdateProfile();
            return;
        }
        if ($mode === 'update-profile-full') {
            $this->handleUpdateProfileFull();
            return;
        }
        if ($mode === 'update-password') {
            $this->handleUpdatePassword();
            return;
        }
        if ($mode === 'pm-send') {
            $this->handlePmSend();
            return;
        }
        if ($mode === 'pm-delete') {
            $this->handlePmDelete();
            return;
        }
        if ($mode === 'pm-delete-batch') {
            $this->handlePmDeleteBatch();
            return;
        }
        if ($mode === 'pm-block') {
            $this->handlePmBlock();
            return;
        }
        if ($mode === 'pm-unblock') {
            $this->handlePmUnblock();
            return;
        }
        if ($mode === 'pm-search-users') {
            $this->handlePmSearchUsers();
            return;
        }
        if ($mode === 'vote') {
            $this->handleVote();
            return;
        }
        if ($mode === 'like') {
            $this->handleLike();
            return;
        }
        if ($mode === 'upload-image') {
            $this->handleUploadImage();
            return;
        }
        if ($mode === 'edit') {
            $this->handleEdit();
            return;
        }
        if ($mode === 'cat-create' || $mode === 'cat-update' || $mode === 'cat-delete') {
            $this->handleCategoryCrud($mode);
            return;
        }
        if ($mode === 'cat-lock' || $mode === 'cat-unlock') {
            $this->handleCategoryLockToggle($mode);
            return;
        }

        // ------------------------------------------------------------------
        // جریان ثبت پرسش/پاسخ
        // ------------------------------------------------------------------

        // توکن امنیتی — همان سازوکار هسته (commentsAntiSpam)
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        // ۲.۲.۰ — کاربر بلاک‌شده (اداری) اجازهٔ ثبت پرسش/پاسخ ندارد
        $this->assertNotBanned();

        // تلهٔ اسپم (فیلد پنهان که ربات‌ها پر می‌کنند)
        if (trim((string) $this->request->get('website')) !== '') {
            $this->response->redirect(Plugin::forumUrl());
        }

        // باز بودن ارسال (تنظیم نسخهٔ ۲ — جایگزین بستن دیدگاه‌های نوشتهٔ پشتیبان)
        if (!Plugin::allowPost()) {
            $this->backWithError(_t('ارسال پرسش و پاسخ هم‌اکنون بسته شده است.'));
        }

        // اجازهٔ پرسش مهمان‌ها (تنظیم افزونه)
        $guestAsk = Plugin::opt('guestAsk', '1') !== '0';
        if (!$guestAsk && !$this->user->hasLogin()) {
            $this->backWithError(_t('برای پرسیدن پرسش و نوشتن پاسخ باید وارد حساب خود شوید.'));
        }

        // پرسشِ والد (برای پاسخ‌ها) — باید تاپیک همین انجمن باشد
        $parentId = (int) ($this->request->filter('int')->get('parent') ?: 0);
        if ($parentId > 0) {
            $parent = Plugin::topicById($parentId);
            if ($parent === null) {
                $this->backWithError(_t('پرسش موردنظر یافت نشد.'));
            }
            if ($parent['status'] !== 'approved' && !Plugin::canSeeWaiting($parentId)) {
                $this->backWithError(_t('پرسش موردنظر در دسترس نیست.'));
            }

            // پرسش قفل‌شده پاسخ جدید نمی‌پذیرد — مدیر انجمن مستثنی است (۲.۲.۰)
            if (Plugin::isLocked($parentId) && !Plugin::canManage()) {
                $this->backWithError(_t('این پرسش قفل شده است؛ امکان نوشتن پاسخ جدید نیست.'), $parentId);
            }

            // ۲.۲.۰ — دستهٔ قفل‌شده: نوشتن (پرسش/پاسخ) فقط برای مدیر
            $parentCatId = (int) ($parent['category_id'] ?? 0);
            if ($parentCatId > 0 && Plugin::isCategoryLocked($parentCatId) && !Plugin::canManage()) {
                $parentCat = Plugin::getCategory($parentCatId);
                $catName = $parentCat !== null ? $parentCat['name'] : '';
                $this->backWithError(
                    _t('دستهٔ «' . $catName . '» قفل است؛ فقط مدیران می‌توانند در آن بنویسند.'),
                    $parentId
                );
            }
        }

        // فاصلهٔ زمانی ارسال — همان منطق هسته
        $ownerId = Plugin::ownerUid();
        if (
            !$this->user->pass('editor', true) && $ownerId !== (int) $this->user->uid &&
            $this->options->commentsPostIntervalEnable
        ) {
            $latest = $this->db->fetchRow(
                $this->db->select('created')->from('table.forum_posts')
                    ->where('author_ip = ?', $this->request->getIp())
                    ->order('created', Db::SORT_DESC)
                    ->limit(1)
            );
            if (!$latest) {
                $latest = $this->db->fetchRow(
                    $this->db->select('created')->from('table.forum_topics')
                        ->where('author_ip = ?', $this->request->getIp())
                        ->order('created', Db::SORT_DESC)
                        ->limit(1)
                );
            }
            if (
                $latest
                && $this->options->time - (int) $latest['created'] >= 0
                && $this->options->time - (int) $latest['created'] < (int) $this->options->commentsPostInterval
            ) {
                $remain = (int) $this->options->commentsPostInterval
                    - ($this->options->time - (int) $latest['created']);
                $remain = max(1, $remain); // حداقل ۱ ثانیه
                // پیام ثابت + پارامتر wait برای شمارش معکوس زنده در ویو
                $url = $parentId > 0 ? Plugin::threadUrl($parentId) : Plugin::forumUrl();
                $sep = str_contains($url, '?') ? '&' : '?';
                $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
                $this->response->redirect(
                    $url . $sep . 'e=' . rawurlencode(_t('ارسال‌ها بیش از حد نزدیک است؛ لطفاً تا پایان شمارش معکوس صبر کنید:'))
                    . '&wait=' . (int) $remain
                );
            }
        }

        $item = [
            'created'      => $this->options->time,
            'author_ip'    => (string) $this->request->getIp(),
            'author_agent' => (string) $this->request->getAgent(),
        ];

        // اعتبارسنجی دستهٔ اجباری برای پرسش‌ها
        // فقط در صورتی که حداقل یک دسته تعریف شده باشد، انتخاب دسته الزامی است.
        if ($parentId === 0 && !empty(Plugin::categories())) {
            $askCatId = (int) ($this->request->filter('int')->get('category') ?: 0);
            if ($askCatId < 1 || Plugin::getCategory($askCatId) === null) {
                Cookie::set('__typecho_remember_title', (string) $this->request->get('title'));
                Cookie::set('__typecho_remember_text', (string) $this->request->get('text'));
                $this->backWithError(_t('انتخاب دسته‌بندی برای پرسش الزامی است.'));
            }

            // ۲.۲.۰ — دستهٔ قفل‌شده: ثبت پرسش فقط برای مدیر
            if (Plugin::isCategoryLocked($askCatId) && !Plugin::canManage()) {
                $lockedCat = Plugin::getCategory($askCatId);
                $lockedCatName = $lockedCat !== null ? $lockedCat['name'] : '';
                Cookie::set('__typecho_remember_title', (string) $this->request->get('title'));
                Cookie::set('__typecho_remember_text', (string) $this->request->get('text'));
                $this->backWithError(_t('دستهٔ «' . $lockedCatName . '» قفل است؛ فقط مدیران می‌توانند در آن پرسش بگذارند.'));
            }
        }

        $isPrivileged = $this->user->pass('editor', true) || ($ownerId > 0 && $ownerId === (int) $this->user->uid);
        $isLoggedIn = $this->user->hasLogin();

        // ------------------ تأیید پیش از انتشار ------------------
        // تنظیم افزونه بر تنظیمات هسته اولویت دارد: اگر افزونه بگوید «در انتظار تأیید»،
        // دیگر «فهرست سفید» هسته نمی‌تواند آن را به «approved» برگرداند.
        $pluginHolds = Plugin::shouldHoldForModeration($isLoggedIn, $isPrivileged);

        // قاعدهٔ هسته TypeRenew: commentsRequireModeration برای کاربران غیرامتیازدار
        $coreHolds = !$isPrivileged && $this->options->commentsRequireModeration;

        $item['status'] = ($pluginHolds || $coreHolds) ? 'waiting' : 'approved';

        // اعتبارسنجی — همان قواعد Widget\Feedback
        $validator = new Validate();
        $validator->addRule('author', 'required', _t('نام را بنویسید'));
        $validator->addRule('author', 'xssCheck', _t('در نام از نویسه‌های ویژه استفاده نکنید'));
        $validator->addRule('author', [$this, 'requireUserLogin'], _t('این نام قبلاً ثبت شده است؛ لطفاً وارد شوید'));
        $validator->addRule('author', 'maxLength', _t('نام حداکثر ۱۵۰ نویسه است'), 150);

        if ($this->options->commentsRequireMail && !$this->user->hasLogin()) {
            $validator->addRule('mail', 'required', _t('نشانی ایمیل الزامی است'));
        }
        $validator->addRule('mail', 'email', _t('نشانی ایمیل معتبر نیست'));
        $validator->addRule('mail', 'maxLength', _t('ایمیل حداکثر ۱۵۰ نویسه است'), 150);

        if ($this->options->commentsRequireUrl && !$this->user->hasLogin()) {
            $validator->addRule('url', 'required', _t('نشانی وب‌سایت الزامی است'));
        }
        $validator->addRule('url', 'url', _t('نشانی وب‌سایت معتبر نیست'));
        $validator->addRule('url', 'maxLength', _t('نشانی وب حداکثر ۲۵۵ نویسه است'), 255);

        $validator->addRule('text', 'required', $parentId > 0
            ? _t('متن پاسخ را بنویسید') : _t('متن پرسش را بنویسید'));

        $maxLength = Plugin::maxTextLength();
        $validator->addRule('text', 'maxLength', _t('متن حداکثر %d نویسه است', $maxLength), $maxLength);

        $item['text'] = (string) $this->request->get('text');

        // برای پرسش‌ها (parent=0): عنوان را به ابتدای متن اضافه کن
        if ($parentId === 0) {
            $askTitle = trim((string) $this->request->get('title'));
            if ($askTitle !== '') {
                $askTitle = mb_substr($askTitle, 0, 120);
                $item['text'] = $askTitle . "\n\n" . ltrim($item['text']);
            }
        }

        // ۲.۲.۰ — فیلتر کلمات (سانسور خودکار) قبل از ذخیره‌سازی
        $item['text'] = Plugin::applyWordFilters($item['text']);

        if (!$this->user->hasLogin()) {
            $item['author_name'] = (string) $this->request->filter('trim')->get('author');
            $item['author_mail'] = (string) $this->request->filter('trim')->get('mail');
            $item['author_url'] = (string) $this->request->filter('trim')->get('url');

            if (!empty($item['author_url'])) {
                $urlParams = \Typecho\Common::parseUrl((string) $item['author_url']);
                if (!isset($urlParams['scheme'])) {
                    $item['author_url'] = 'https://' . $item['author_url'];
                }
            }

            $expireAt = time() + 30 * 24 * 3600;
            Cookie::set('__typecho_remember_author', (string) $item['author_name'], $expireAt);
            Cookie::set('__typecho_remember_mail', (string) $item['author_mail'], $expireAt);
            Cookie::set('__typecho_remember_url', (string) $item['author_url'], $expireAt);
        } else {
            $item['author_name'] = $this->user->screenName;
            $item['author_mail'] = $this->user->mail;
            $item['author_url'] = $this->user->url;
            $item['author_id'] = (int) $this->user->uid;
        }

        // نگاشت کلیدهای ساختار دیدگاه (Feedback) — ولیدیتور و افزونه‌های ضداسپم
        // (هوک 'comment') با کلیدهای author/mail/url کار می‌کنند؛ بدون این نگاشت،
        // قاعدهٔ required روی author همیشه شکست می‌خورد (خطای «نام را بنویسید»).
        // در INSERT فقط ستون‌های مشخص ($rows) ذخیره می‌شوند؛ این کلیدها اضافی‌اند.
        $item['author'] = (string) ($item['author_name'] ?? '');
        $item['mail']   = (string) ($item['author_mail'] ?? '');
        $item['url']    = (string) ($item['author_url'] ?? '');

        // فهرست سفید — همان منطق هسته
        // اگر افزونه گفته «در انتظار تأیید»، فهرست سفید نباید آن را لغو کند.
        if (!$pluginHolds && !$this->options->commentsRequireModeration && $this->options->commentsWhitelist) {
            $has = $this->hasApprovedByAuthor(
                (string) ($item['author_name'] ?? ''),
                (string) ($item['author_mail'] ?? '')
            );
            $item['status'] = $has ? 'approved' : 'waiting';
        }

        if ($error = $validator->run($item)) {
            Cookie::set('__typecho_remember_text', (string) $item['text']);
            $this->backWithError(implode(' — ', $error), $parentId);
        }

        // هوک ضداسپم افزونه‌های دیگر (نقطهٔ اتصال Widget\Feedback)
        //
        // سازگاری با RenewShield و هر افزونهٔ دیگری که به هوک comment متصل
        // می‌شود: آرگومان دوم filter('comment', ...) باید object معتبر باشد
        // (همانند Widget\Archive که Widget\Feedback در حالت عادی ارسال می‌کند)،
        // نه null. RenewShield در Guard::comment() از $_content->cid برای ساختن
        // اثر انگشت زمینه و بازخوانی زمان بازدید استفاده می‌کند؛ بنابراین
        // ارسال null باعث TypeError (Fatal Error) می‌شود.
        //
        // این Content Object از داده‌های واقعی همین پرسش/پاسخ ساخته می‌شود
        // (نه یک object جعلی) تا مکانیزم امنیتی RenewShield بدون دور زدن،
        // روی درخواست انجمن اعمال شود:
        //   - برای پاسخ (parentId > 0): cid همان شناسهٔ واقعی تاپیک والد است.
        //   - برای پرسش جدید (parentId = 0): تاپیک والدی وجود ندارد؛ برای
        //     حفظ قرارداد (cid مثبت) از شناسهٔ واقعی کاربر واردشده یا هش
        //     پایدار IP مهمان استفاده می‌شود. این مقدار واقعی، پایدار و
        //     غیرصفر است و هیچ‌گاه دادهٔ جعلی یا تصادفی نیست.
        $contentObj = new \stdClass();
        $contentObj->type      = 'comment';
        $contentObj->coid      = 0; // پست/پرسش جدید — coid پس از INSERT تعیین می‌شود
        $contentObj->parent    = $parentId;
        $contentObj->authorId  = (int) ($item['author_id'] ?? 0);
        $contentObj->ownerId   = (int) Plugin::ownerUid();
        $contentObj->author    = (string) ($item['author'] ?? '');
        $contentObj->mail      = (string) ($item['mail'] ?? '');
        $contentObj->url       = (string) ($item['url'] ?? '');
        $contentObj->ip        = (string) ($item['author_ip'] ?? '');
        $contentObj->agent     = (string) ($item['author_agent'] ?? '');
        $contentObj->text      = (string) ($item['text'] ?? '');
        $contentObj->created   = (int) ($item['created'] ?? time());
        $contentObj->status    = (string) ($item['status'] ?? 'approved');
        if ($parentId > 0) {
            // پاسخ به پرسش موجود — cid همان شناسهٔ واقعی تاپیک والد است
            $contentObj->cid       = $parentId;
            $contentObj->permalink = Plugin::threadUrl($parentId);
            $contentObj->title     = isset($parent['title']) ? (string) $parent['title'] : '';
        } else {
            // پرسش جدید — تاپیک والدی وجود ندارد. برای حفظ قرارداد RenewShield
            // (cid مثبت)، از شناسهٔ واقعی کاربر واردشده یا هش پایدار IP مهمان
            // استفاده می‌شود. این مقدار واقعی، پایدار و غیرصفر است.
            $viewerUid = (int) ($this->user->uid ?? 0);
            $contentObj->cid = $viewerUid > 0
                ? $viewerUid
                : max(1, abs(crc32((string) ($item['author_ip'] ?? ''))));
            $contentObj->permalink = Plugin::forumUrl();
            $contentObj->title     = '';
        }

        try {
            $item = Feedback::pluginHandle()->filter('comment', $item, $contentObj);
        } catch (\Typecho\Exception $e) {
            Cookie::set('__typecho_remember_text', (string) $item['text']);
            $this->backWithError($e->getMessage(), $parentId);
        }

        // ------------------------------------------------------------------
        // ثبت نهایی — در جداول اختصاصی انجمن
        // ------------------------------------------------------------------
        $table = $parentId > 0 ? 'table.forum_posts' : 'table.forum_topics';
        $rows = [
            'text'         => (string) $item['text'],
            'author_id'    => (int) ($item['author_id'] ?? 0),
            'author_name'  => (string) ($item['author_name'] ?? ''),
            'author_mail'  => (string) ($item['author_mail'] ?? ''),
            'author_url'   => (string) ($item['author_url'] ?? ''),
            'author_ip'    => (string) ($item['author_ip'] ?? ''),
            'author_agent' => (string) ($item['author_agent'] ?? ''),
            'status'       => (string) $item['status'],
            'created'      => (int) ($item['created'] ?? time()),
            'modified'     => (int) ($item['created'] ?? time()),
        ];
        if ($parentId > 0) {
            $rows['topic_id'] = $parentId;
        } else {
            // عنوان جدا برای پرسش (برای جستجو/پنل — قالب‌ها همچنان splitQuestion می‌خوانند)
            [$t] = Plugin::splitQuestion((string) $item['text']);
            $rows['title'] = mb_substr(Plugin::stripMarkup($t), 0, 250);
        }

        $itemId = (int) $this->db->query($this->db->insert($table)->rows($rows));
        Cookie::delete('__typecho_remember_text');
        Cookie::delete('__typecho_remember_title');

        // ساخت نظرسنجی اگر فعال و درخواست شده
        if ($parentId === 0 && Plugin::pollsEnabled() && $this->request->get('has_poll') === '1') {
            $pollQ = trim((string) $this->request->get('poll_question'));
            $pollOptsRaw = trim((string) $this->request->get('poll_options'));
            if ($pollQ !== '' && $pollOptsRaw !== '') {
                $pollOpts = array_filter(array_map('trim', explode("\n", $pollOptsRaw)), fn ($o) => $o !== '');
                if (count($pollOpts) >= 2) {
                    Plugin::setPoll($itemId, $pollQ, $pollOpts);
                }
            }
        }

        // ثبت دستهٔ پرسش تازه
        if ($parentId === 0) {
            $askCatId = (int) ($this->request->filter('int')->get('category') ?: 0);
            if ($askCatId > 0 && Plugin::getCategory($askCatId) !== null) {
                Plugin::setTopicCategory($itemId, $askCatId);
            }
        }

        // مالکیت مهمان — برای مهلت ویرایش چنددقیقه‌ای
        if ((int) ($item['author_id'] ?? 0) === 0) {
            try {
                Plugin::rememberGuestPost($itemId);
            } catch (\Throwable $e) {
                // بدون کوکی هم ارسال موفق است؛ فقط ویرایش مهمان در دسترس نیست
            }
        }

        // اعلان درون‌انجمنی: اگر این یک پاسخ است، به نویسندهٔ پرسش اطلاع بده
        if ($parentId > 0 && $item['status'] === 'approved') {
            try {
                $qAuthorId = (int) ($parent['author_id'] ?? 0);
                $replyAuthorId = (int) ($item['author_id'] ?? 0);
                // به خودش اعلان نفرست
                if ($qAuthorId > 0 && $qAuthorId !== $replyAuthorId) {
                    Plugin::addNotification($qAuthorId, 'reply', $itemId, $parentId);
                }
            } catch (\Throwable $e) {
                // اعلان حیاتی نیست
            }
        }

        Feedback::pluginHandle()->call('finishComment', $this);

        // اعلان ایمیلی — همان صف هسته با قالب‌های فارسی
        try {
            $mailObj = Plugin::mailCommentObject(
                (string) $item['text'],
                $itemId,
                $parentId > 0 ? (string) Plugin::stripMarkup(Plugin::splitQuestion((string) $parent['text'])[0]) : (string) $rows['title'],
                Plugin::threadUrl($parentId > 0 ? $parentId : $itemId) . ($parentId > 0 ? '#c' . $itemId : ''),
                (string) $item['author_name'],
                (string) $item['author_mail'],
                (int) ($item['author_id'] ?? 0),
                (string) $item['author_ip'],
                (int) ($item['created'] ?? time()),
                $parentId,
                $parentId > 0 ? $parentId : $itemId
            );
            $mailObj->status = (string) $item['status'];
            Plugin::notifyMail($mailObj, 'created', $parentId > 0 ? $parent : null);
        } catch (\Throwable $e) {
            // نباید شکست ایمیل، ثبت پرسش را خراب کند
        }

        if ($item['status'] !== 'approved') {
            Plugin::setWaitingCookie($itemId);
        }

        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->setHeader('Pragma', 'no-cache');
        $this->response->setHeader('Expires', '0');

        // بازگشت: پرسش تازه → صفحهٔ خودش؛ پاسخ → پرسش والد
        $isWaiting = $item['status'] !== 'approved';
        if ($parentId > 0) {
            $this->response->redirect(
                Plugin::threadUrl($parentId) . '?posted=' . ($isWaiting ? 'waiting' : '1') . '#c' . $itemId
            );
        } else {
            $this->response->redirect(
                Plugin::threadUrl($itemId) . '?posted=' . ($isWaiting ? 'waiting' : '1')
            );
        }
    }

    /**
     * همان قاعدهٔ هسته: نام نمایشی نباید با کاربر دیگری تداخل کند
     */
    public function requireUserLogin(string $userName): bool
    {
        if ($this->user->hasLogin() && $this->user->screenName != $userName) {
            return false;
        } elseif (
            !$this->user->hasLogin() && $this->db->fetchRow($this->db->select('uid')
                ->from('table.users')->where('screenName = ? OR name = ?', $userName, $userName)->limit(1))
        ) {
            return false;
        }

        return true;
    }

    /** بررسی فهرست سفید: آیا این نویسنده قبلاً آیتم تأییدشده‌ای در انجمن داشته؟ */
    private function hasApprovedByAuthor(string $author, string $mail): bool
    {
        if ($author === '' && $mail === '') {
            return false;
        }
        try {
            $t = (int) $this->db->fetchObject(
                $this->db->select(['COUNT(id)' => 'n'])->from('table.forum_topics')
                    ->where('author_name = ? AND author_mail = ? AND status = ?', $author, $mail, 'approved')
            )->n;
            if ($t > 0) {
                return true;
            }
            $p = (int) $this->db->fetchObject(
                $this->db->select(['COUNT(id)' => 'n'])->from('table.forum_posts')
                    ->where('author_name = ? AND author_mail = ? AND status = ?', $author, $mail, 'approved')
            )->n;
            return $p > 0;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * بازگشت به فرم همراه پیام خطا (ریدایرکت پایانی است)
     */
    private function backWithError(string $message, int $parentId = 0): void
    {
        $url = $parentId > 0 ? Plugin::threadUrl($parentId) : Plugin::forumUrl();
        $sep = str_contains($url, '?') ? '&' : '?';
        $this->response->redirect($url . $sep . 'e=' . rawurlencode($message));
    }

    /**
     * ۲.۲.۰ — گارد بلاک اداری.
     *
     * اگر کاربر واردشده بلاک فعال (موقت یا همیشه) داشته باشد، با پیامِ
    شامل مهلت و دلیل، به صفحهٔ پرسش/انجمن برمی‌گردد. مدیران هرگز
     * بلاک نمی‌شوند (تست هنگام بلاک، مجوز را می‌سنجد).
     */
    private function assertNotBanned(int $parentId = 0): void
    {
        if (!$this->user->hasLogin()) {
            return; // بلاک فقط برای اعضا معنا دارد
        }
        if (Plugin::canManage()) {
            return; // مدیران مستثنی
        }
        $ban = Plugin::activeBanFor((int) $this->user->uid);
        if ($ban === null) {
            return;
        }

        $message = 'حساب شما ' . Plugin::banUntilText($ban) . ' از نوشتن در انجمن مسدود است.';
        if (trim((string) $ban['reason']) !== '') {
            $message .= ' دلیل: ' . trim((string) $ban['reason']);
        }
        $this->backWithError(_t($message), $parentId);
    }

    /**
     * قفل/بازکردن یک دسته — فقط مدیران (۲.۲.۰)
     * از صفحهٔ مدیریت دسته‌ها و پنل انجمن فراخوانی می‌شود.
     */
    private function handleCategoryLockToggle(string $mode): void
    {
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        if (!Plugin::canManage()) {
            $this->backWithError(_t('اجازهٔ قفل یا بازکردن دسته را ندارید.'));
        }

        $id = (int) ($this->request->filter('int')->get('id') ?: 0);
        $cat = Plugin::getCategory($id);
        if ($cat === null) {
            $this->backWithError(_t('دستهٔ موردنظر یافت نشد.'));
        }

        $lock = $mode === 'cat-lock';
        if ($lock === (bool) $cat['locked']) {
            // بدون تغییر — فقط بازگرد
            $this->response->redirect(Plugin::categoryAdminUrl());
        }

        $ok = Plugin::setCategoryLocked($id, $lock);

        $url = Plugin::categoryAdminUrl() . '?';
        if ($ok) {
            $url .= ($lock ? 'cat-locked' : 'cat-unlocked') . '=1';
        } else {
            $url .= 'e=' . rawurlencode('تغییر وضعیت قفل دسته ممکن نشد.');
        }

        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->redirect($url);
    }

    /**
     * قفل/بازکردن یک پرسش — فقط برای مدیران (editor یا مالک انجمن)
     */
    private function handleLockToggle(string $mode): void
    {
        // توکن امنیتی — همان سازوکار هسته
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        if (!Plugin::canManage()) {
            $this->backWithError(_t('اجازهٔ قفل یا بازکردن پرسش را ندارید.'));
        }

        $coid = (int) ($this->request->filter('int')->get('coid') ?: 0);

        $row = Plugin::topicById($coid);
        if ($row === null) {
            $this->backWithError(_t('پرسش موردنظر یافت نشد.'));
        }

        if ($mode === 'lock') {
            Plugin::lockThread($coid);
            $state = 'locked';
        } else {
            Plugin::unlockThread($coid);
            $state = 'unlocked';
        }

        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->redirect(Plugin::threadUrl($coid) . '?' . $state . '=1');
    }

    /**
     * سنجاق/برداشتن سنجاق یک پرسش — فقط برای مدیران
     */
    private function handlePinToggle(string $mode): void
    {
        // توکن امنیتی — همان سازوکار هسته
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        if (!Plugin::canManage()) {
            $this->backWithError(_t('اجازهٔ سنجاق یا برداشتن سنجاق پرسش را ندارید.'));
        }

        $coid = (int) ($this->request->filter('int')->get('coid') ?: 0);

        $row = Plugin::topicById($coid);
        if ($row === null) {
            $this->backWithError(_t('پرسش موردنظر یافت نشد.'));
        }

        if ($mode === 'pin') {
            Plugin::pinThread($coid);
            $state = 'pinned';
        } else {
            Plugin::unpinThread($coid);
            $state = 'unpinned';
        }

        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->redirect(Plugin::threadUrl($coid) . '?' . $state . '=1');
    }

    /**
     * فعال/غیرفعال‌کردن «در حال پیگیری» یک پرسش — فقط مدیران
     */
    private function handleTrackToggle(string $mode): void
    {
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        if (!Plugin::canManage()) {
            $this->backWithError(_t('اجازهٔ تغییر وضعیت پیگیری پرسش را ندارید.'));
        }

        $coid = (int) ($this->request->filter('int')->get('coid') ?: 0);
        $row = Plugin::topicById($coid);
        if ($row === null) {
            $this->backWithError(_t('پرسش موردنظر یافت نشد.'));
        }

        if ($mode === 'track') {
            Plugin::trackThread($coid);
            $state = 'tracked';
        } else {
            Plugin::untrackThread($coid);
            $state = 'untracked';
        }

        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->redirect(Plugin::threadUrl($coid) . '?' . $state . '=1');
    }

    /**
     * پنهان‌کردن/نمایش یک پرسش به مهمان — فقط مدیران
     */
    private function handleHideToggle(string $mode): void
    {
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        if (!Plugin::canManage()) {
            $this->backWithError(_t('اجازهٔ پنهان‌کردن پرسش را ندارید.'));
        }

        $coid = (int) ($this->request->filter('int')->get('coid') ?: 0);
        $row = Plugin::topicById($coid);
        if ($row === null) {
            $this->backWithError(_t('پرسش موردنظر یافت نشد.'));
        }

        if ($mode === 'hide') {
            Plugin::hideThread($coid);
            $state = 'hidden';
        } else {
            Plugin::unhideThread($coid);
            $state = 'unhidden';
        }

        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->redirect(Plugin::threadUrl($coid) . '?' . $state . '=1');
    }

    /**
     * حذف یک پرسش یا پاسخ.
     * مجوز:
     *  - مدیر انجمن: همیشه
     *  - کاربر واردشده: فقط نوشتهٔ خودش (در محدودهٔ زمانی مهمان، برای مهمان)
     *  - مهمان: فقط نوشتهٔ خودش و تا پایان مهلت
     *
     * هنگام حذف پرسش: همهٔ پاسخ‌های زیرش هم حذف می‌شوند (عملیات آبشاری).
     * اگر پاسخِ حذف‌شده به‌عنوان بهترین‌پاسخ انتخاب شده بود، آن انتخاب نیز
     * برداشته می‌شود. اگر خود پرسش حذف شود، دسته/نظرسنجی/گزارش‌ها و
     * بهترین‌پاسخِ آن هم پاک می‌شوند.
     */
    private function handleDelete(): void
    {
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        $coid = (int) ($this->request->filter('int')->get('coid') ?: 0);

        $topic = Plugin::topicById($coid);
        $post = $topic === null ? Plugin::postById($coid) : null;
        $row = $topic ?? $post;

        if ($row === null) {
            $this->backWithError(_t('پرسش یا پاسخ موردنظر یافت نشد.'));
        }

        // بررسی مجوز — همان منطق ویرایش
        $viewRow = $topic !== null ? Plugin::topicRowToLegacy($topic) : Plugin::postRowToLegacy($post);
        if (!Plugin::canEdit($viewRow) && !Plugin::canManage()) {
            $this->backWithError(_t('اجازهٔ حذف این پرسش/پاسخ را ندارید.'));
        }

        $isQuestion = $topic !== null;
        $redirectCoid = $isQuestion ? 0 : (int) $post['topic_id'];

        if ($isQuestion) {
            // اگر پاسخِ حذف‌شده بهترین پاسخِ پرسش است، آن انتخاب را بردار
            Plugin::unmarkBestAnswer($coid);

            // حذف آبشاری پاسخ‌های زیرِ پرسش
            try {
                $childRows = $this->db->fetchAll(
                    $this->db->select('id')->from('table.forum_posts')
                        ->where('topic_id = ?', $coid)
                );
                $childIds = array_map(static fn ($r) => (int) $r['id'], $childRows);
                if (!empty($childIds)) {
                    // حذف گزارش‌ها و پسندهای پاسخ‌ها
                    Plugin::pruneFlags();
                    Plugin::pruneLikes();
                    $this->db->query(
                        $this->db->delete('table.forum_posts')->where('id IN ?', $childIds)
                    );
                }
            } catch (\Throwable $e) {
                // ادامه — خود پرسش هم حداقل حذف شود
            }

            // پاک‌کردن نگاشت‌های پرسش
            Plugin::unpinThread($coid);
            Plugin::untrackThread($coid);
            Plugin::unhideThread($coid);
            Plugin::unmarkBestAnswer($coid);
            Plugin::setTopicCategory($coid, 0);
            Plugin::clearFlags($coid);
            Plugin::clearLikes($coid);
            Plugin::deletePoll($coid);

            // حذف اعلان‌های مربوط به همین تاپیک
            try {
                $this->db->query(
                    $this->db->delete('table.forum_notifications')
                        ->where('topic_id = ? OR item_id = ?', $coid, $coid)
                );
            } catch (\Throwable $e) {
            }
        } else {
            // اگر پاسخِ حذف‌شده بهترین پاسخِ پرسش است، آن انتخاب را بردار
            $qCoid = (int) $post['topic_id'];
            if (Plugin::bestAnswerFor($qCoid) === $coid) {
                Plugin::unmarkBestAnswer($qCoid);
            }
            Plugin::clearFlags($coid);
            Plugin::clearLikes($coid);
        }

        // حذف ردیف اصلی
        $table = $isQuestion ? 'table.forum_topics' : 'table.forum_posts';
        try {
            $this->db->query(
                $this->db->delete($table)->where('id = ?', $coid)
            );
        } catch (\Throwable $e) {
            $this->backWithError(_t('حذف ممکن نشد؛ کمی بعد دوباره تلاش کنید.'));
        }

        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        if ($isQuestion) {
            $this->response->redirect(Plugin::forumUrl() . '?deleted=1');
        } else {
            $this->response->redirect(Plugin::threadUrl($redirectCoid) . '?deleted=1');
        }
    }

    /**
     * انتخاب/برداشتن بهترین پاسخ — توسط نویسندهٔ پرسش یا مدیر.
     * انتخاب بهترین پاسخ، پرسش را قفل می‌کند.
     */
    private function handleBestToggle(string $mode): void
    {
        // توکن امنیتی — همان سازوکار هسته
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        $answerCoid = (int) ($this->request->filter('int')->get('coid') ?: 0);
        if ($answerCoid < 1) {
            $this->backWithError(_t('پاسخ موردنظر یافت نشد.'));
        }

        // خواندن ردیف پاسخ
        $answer = Plugin::postById($answerCoid);

        if ($answer === null) {
            $this->backWithError(_t('پاسخ موردنظر یافت نشد.'));
        }

        $questionCoid = (int) $answer['topic_id'];

        // خواندن ردیف پرسش برای بررسی مالکیت
        $question = Plugin::topicById($questionCoid);

        if ($question === null) {
            $this->backWithError(_t('پرسش موردنظر یافت نشد.'));
        }

        // اجازه: نویسندهٔ پرسش (واردشده) یا مدیر
        $canMarkBest = Plugin::canManage();
        if (!$canMarkBest) {
            $user = User::alloc();
            if (
                $user->hasLogin()
                && (int) $question['author_id'] > 0
                && (int) $user->uid === (int) $question['author_id']
            ) {
                $canMarkBest = true;
            }
        }

        if (!$canMarkBest) {
            $this->backWithError(_t('فقط نویسندهٔ پرسش یا مدیر می‌تواند بهترین پاسخ را انتخاب کند.'));
        }

        if ($mode === 'best') {
            Plugin::markBestAnswer($questionCoid, $answerCoid);
            $state = 'best';

            // اعلان به نویسندهٔ پاسخ: پاسخش بهترین انتخاب شد
            try {
                $answerAuthorId = (int) $answer['author_id'];
                $markerId = 0;
                try {
                    $markerId = (int) (User::alloc()->uid ?? 0);
                } catch (\Throwable $e) {
                }
                if ($answerAuthorId > 0 && $answerAuthorId !== $markerId) {
                    Plugin::addNotification($answerAuthorId, 'best', $answerCoid, $questionCoid);
                }
            } catch (\Throwable $e) {
            }
        } else {
            Plugin::unmarkBestAnswer($questionCoid);
            $state = 'unbest';
        }

        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->redirect(Plugin::threadUrl($questionCoid) . '?c' . $answerCoid . '&state=' . $state . '#c' . $answerCoid);
    }

    /**
     * تأیید نوشتهٔ در انتظار (پرسش یا پاسخ) از محیط کاربری — ۲.۰.۰.
     *
     * فقط مدیران. همان کاری که «تأیید» پنل مدیریت می‌کند: وضعیت به
     * approved تغییر می‌کند و اعلان ایمیلی مؤلف (اگر فعال باشد) در
     * صف ایمیل هسته می‌نشیند. عملیات ایمن و تکرارپذیر است — تأییدِ
     * دوبارهٔ نوشتهٔ تأییدشده فقط ریدایرکت می‌دهد.
     *
     * بازگشت هوشمند: فرمِ داخل صف تأیید فهرست back=queue می‌فرستد و
     * کاربر در همان صف می‌ماند تا بقیهٔ موارد را هم تأیید کند؛ وگرنه
     * به خودِ پرسش برمی‌گردد.
     */
    private function handleApprove(): void
    {
        // توکن امنیتی — همان سازوکار هسته
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        if (!Plugin::canManage()) {
            $this->backWithError(_t('اجازهٔ تأیید نوشته را ندارید.'));
        }

        $coid = (int) ($this->request->filter('int')->get('coid') ?: 0);
        $type = $coid > 0 ? Plugin::itemTypeOf($coid) : null;
        if ($type === null) {
            $this->backWithError(_t('آیتم موردنظر یافت نشد.'));
        }

        $row = $type === 'topic' ? Plugin::topicById($coid) : Plugin::postById($coid);
        if ($row === null) {
            $this->backWithError(_t('آیتم موردنظر یافت نشد.'));
        }

        $topicId = $type === 'topic' ? $coid : (int) ($row['topic_id'] ?? 0);
        if ($topicId < 1 || Plugin::topicById($topicId) === null) {
            $this->backWithError(_t('پرسش موردنظر یافت نشد.'));
        }

        if ((string) ($row['status'] ?? '') !== 'approved') {
            try {
                $db = Db::get();
                $db->query(
                    $db->update($type === 'topic' ? 'table.forum_topics' : 'table.forum_posts')
                        ->rows(['status' => 'approved'])
                        ->where('id = ?', $coid)
                );
            } catch (\Throwable $e) {
                $this->backWithError(_t('خطا در تأیید نوشته؛ دوباره تلاش کنید.'));
            }

            // اعلان ایمیلی مؤلف — همان سازوکار پنل مدیریت
            try {
                $view = $type === 'topic'
                    ? Plugin::topicRowToLegacy($row)
                    : Plugin::postRowToLegacy($row);
                $topicRow = $type === 'topic' ? $row : Plugin::topicById($topicId);
                [$t] = Plugin::splitQuestion((string) ($topicRow['text'] ?? ''));
                $mailObj = Plugin::mailCommentObject(
                    (string) $row['text'],
                    (int) $view['coid'],
                    (string) Plugin::stripMarkup($t),
                    Plugin::threadUrl($topicId) . ($type === 'post' ? '#c' . (int) $view['coid'] : ''),
                    (string) $view['author'],
                    (string) $view['mail'],
                    (int) $view['authorId'],
                    (string) $view['ip'],
                    (int) $view['created'],
                    $type === 'post' ? $topicId : 0,
                    $topicId
                );
                $mailObj->status = 'approved';
                Plugin::notifyMail($mailObj, 'approved', $type === 'topic' ? null : $topicRow);
            } catch (\Throwable $e) {
                // ایمیل نباید عملیات تأیید را متوقف کند
            }
        }

        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        if ((string) $this->request->get('back') === 'queue') {
            $this->response->redirect(Plugin::forumUrl() . '?sort=pending&approved=1');
        }

        $url = Plugin::threadUrl($topicId) . '?approved=1';
        if ($type === 'post') {
            $url .= '#c' . $coid;
        }
        $this->response->redirect($url);
    }

    /**
     * گزارش تخلف یک پرسش یا پاسخ.
     * AJAX-friendly: اگر درخواست AJAX بود، JSON برمی‌گرداند؛ وگرنه redirect.
     * فقط کاربران واردشده می‌توانند گزارش کنند؛ نویسندهٔ خودِ آیتم
     * نمی‌تواند نوشتهٔ خودش را گزارش کند (۲.۰.۰).
     */
    private function handleFlag(): void
    {
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        // جلوگیری از گزارش توسط کاربران مهمان
        if (!$this->user->hasLogin()) {
            if ($this->request->isAjax()) {
                Plugin::jsonOut([
                    'ok'      => false,
                    'status'  => 'login_required',
                    'message' => 'برای گزارش تخلف باید وارد حساب خود شوید.',
                ]);
            }
            $this->backWithError(_t('برای گزارش تخلف باید وارد حساب خود شوید.'));
        }

        // ۲.۲.۰ — کاربر بلاک‌شده گزارش نمی‌دهد
        if (!Plugin::canManage()) {
            $ban = Plugin::activeBanFor((int) $this->user->uid);
            if ($ban !== null) {
                $msg = 'حساب شما ' . Plugin::banUntilText($ban) . ' از فعالیت در انجمن مسدود است.';
                if ($this->request->isAjax()) {
                    Plugin::jsonOut([
                        'ok'      => false,
                        'status'  => 'banned',
                        'message' => $msg,
                    ]);
                }
                $this->backWithError(_t($msg));
            }
        }

        $coid = (int) ($this->request->filter('int')->get('coid') ?: 0);
        if ($coid < 1) {
            $this->backWithError(_t('آیتم موردنظر یافت نشد.'));
        }

        // اعتبارسنجی: آیتم باید در همین انجمن باشد
        $type = Plugin::itemTypeOf($coid);
        if ($type === null) {
            $this->backWithError(_t('آیتم موردنظر یافت نشد.'));
        }

        // نویسندهٔ خودِ آیتم نمی‌تواند آن را گزارش کند (۲.۰.۰)
        $flagRow = $type === 'topic' ? Plugin::topicById($coid) : Plugin::postById($coid);
        $viewerUid = Plugin::viewerUid();
        if (
            $viewerUid > 0 && $flagRow !== null
            && (int) ($flagRow['author_id'] ?? 0) > 0
            && (int) $flagRow['author_id'] === $viewerUid
        ) {
            if ($this->request->isAjax()) {
                Plugin::jsonOut([
                    'ok'      => false,
                    'status'  => 'own',
                    'message' => 'نمی‌توانید نوشتهٔ خودتان را گزارش کنید.',
                ]);
            }
            $this->backWithError(_t('نمی‌توانید نوشتهٔ خودتان را گزارش کنید.'));
        }

        // ۲.۲.۰ — دلیل گزارش از پارامتر reason خوانده می‌شود (حداکثر ۱۶۰ کاراکتر)
        $reason = trim((string) $this->request->get('reason'));
        if ($reason !== '') {
            $reason = mb_substr($reason, 0, 160);
        }

        // ۲.۲.۰ — نوع آیتم به‌صورت صریح از پارامتر type خوانده می‌شود.
        // این برای جلوگیری از تداخل coid بین forum_topics.id و forum_posts.id
        // ضروری است: اگر هم‌زمان پرسش و پاسخی با coid یکسان وجود داشته باشد،
        // itemTypeOf همیشه 'topic' را برمی‌گرداند و گزارش برای پرسخ ذخیره
        // می‌شد. با type صریح، گزارش برای نوع درست ذخیره می‌شود.
        $explicitType = trim((string) $this->request->get('type'));
        if ($explicitType !== 'topic' && $explicitType !== 'post') {
            $explicitType = null; // نامعتبر → از itemTypeOf استفاده شود (رفتار قدیمی)
        }

        $result = Plugin::addFlag($coid, $reason, $explicitType);

        // نوع واقعی آیتم برای پاس‌دادن به flagCount (type-aware)
        $realType = $explicitType;
        if ($realType === null) {
            $realType = Plugin::itemTypeOf($coid) ?? 'topic';
        }

        // اگر AJAX بود، JSON برگردان
        if ($this->request->isAjax()) {
            Plugin::jsonOut([
                'ok'      => $result === 'ok',
                'status'  => $result,
                'count'   => Plugin::flagCount($coid, $realType),
                'message' => $result === 'ok' ? 'گزارش شما ثبت شد؛ سپاس!' :
                            ($result === 'already' ? 'این آیتم را قبلاً گزارش کرده‌اید.' : 'خطا در ثبت گزارش.'),
            ]);
        }

        // وگرنه redirect به صفحهٔ پرسش
        $topic = Plugin::topicById($coid);
        $parent = $topic === null ? Plugin::postById($coid) : null;
        $redirectCoid = $topic !== null ? $coid : (int) ($parent['topic_id'] ?? 0);

        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->redirect(Plugin::threadUrl($redirectCoid) . '?flag=' . $result . '#c' . $coid);
    }

    /**
     * پاک‌کردن گزارش‌های یک آیتم — فقط برای مدیران.
     * مدیر می‌تواند گزارش را بدون حذف آیتم رد کند.
     *
     * ۲.۲.۰ — پارامتر type از فرم خوانده می‌شود تا فقط همان نوع پاک شود
     * (مهم برای جلوگیری از پاک‌شدن اشتباهی گزارش پرسش وقتی پاسخ رد می‌شود).
     */
    private function handleClearFlags(): void
    {
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        if (!Plugin::canManage()) {
            $this->backWithError(_t('اجازهٔ پاک‌کردن گزارش‌ها را ندارید.'));
        }

        $coid = (int) ($this->request->filter('int')->get('coid') ?: 0);
        if ($coid < 1) {
            $this->backWithError(_t('آیتم موردنظر یافت نشد.'));
        }

        // ۲.۲.۰ — نوع آیتم برای clearFlags type-aware
        $explicitType = trim((string) $this->request->get('type'));
        if ($explicitType !== 'topic' && $explicitType !== 'post') {
            $explicitType = null; // نامعتبر → هر دو نوع پاک شود (رفتار قدیمی)
        }

        Plugin::clearFlags($coid, $explicitType);

        // پیدا کردن پرسش والد برای redirect
        // توجه: اگر type='post'، باید از forum_posts پیدا کنیم تا topic_id والد را بگیریم
        if ($explicitType === 'post') {
            $post = Plugin::postById($coid);
            $parentCoid = $post ? (int) $post['topic_id'] : 0;
            $redirectCoid = $parentCoid > 0 ? $parentCoid : $coid;
        } elseif ($explicitType === 'topic') {
            $redirectCoid = $coid;
        } else {
            // رفتار قدیمی
            $topic = Plugin::topicById($coid);
            $parentCoid = 0;
            if ($topic === null) {
                $post = Plugin::postById($coid);
                $parentCoid = $post ? (int) $post['topic_id'] : 0;
            }
            $redirectCoid = $parentCoid > 0 ? $parentCoid : $coid;
        }

        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->redirect(Plugin::threadUrl($redirectCoid) . '?flags-cleared=1#c' . $coid);
    }

    /**
     * علامت‌زدن همهٔ اعلان‌های کاربر فعلی به‌عنوان خوانده‌شده
     */
    private function handleReadNotifs(): void
    {
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        if (!$this->user->hasLogin()) {
            $this->backWithError(_t('برای مشاهدهٔ اعلان‌ها باید وارد حساب خود شوید.'));
        }

        $uid = (int) $this->user->uid;
        Plugin::markAllNotificationsRead($uid);

        // redirect به صفحهٔ قبلی (یا فهرست انجمن)
        $referer = (string) ($_SERVER['HTTP_REFERER'] ?? '');
        $target = $referer !== '' ? $referer : Plugin::forumUrl();
        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->redirect($target);
    }

    /**
     * علامت‌زدن یک اعلانِ مشخص به‌عنوان خوانده‌شده.
     * AJAX-friendly: JSON برمی‌گرداند تا شمارندهٔ سایدبار بلافاصله بروزرسانی شود.
     */
    private function handleReadNotif(): void
    {
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        if (!$this->user->hasLogin()) {
            if ($this->request->isAjax()) {
                Plugin::jsonOut([
                    'ok'      => false,
                    'status'  => 'login_required',
                    'message' => 'برای مشاهدهٔ اعلان‌ها باید وارد حساب خود شوید.',
                ]);
            }
            $this->backWithError(_t('برای مشاهدهٔ اعلان‌ها باید وارد حساب خود شوید.'));
        }

        $uid = (int) $this->user->uid;
        $notifId = (int) ($this->request->filter('int')->get('id') ?: 0);

        $ok = Plugin::markNotificationRead($notifId, $uid);

        if ($this->request->isAjax()) {
            Plugin::jsonOut([
                'ok'             => $ok,
                'unread'         => Plugin::unreadNotificationCount($uid),
                'notifId'        => $notifId,
            ]);
        }

        // حالت غیر AJAX: redirect به صفحهٔ قبلی
        $referer = (string) ($_SERVER['HTTP_REFERER'] ?? '');
        $target = $referer !== '' ? $referer : Plugin::forumUrl();
        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->redirect($target);
    }

    /**
     * CRUD دسته‌بندی‌ها — فقط مدیران.
     * حالت‌ها: cat-create، cat-update، cat-delete
     * همهٔ حالت‌ها به صفحهٔ مدیریت دسته‌ها redirect می‌شوند.
     */
    private function handleCategoryCrud(string $mode): void
    {
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        if (!Plugin::canManage()) {
            $this->backWithError(_t('اجازهٔ مدیریت دسته‌بندی‌ها را ندارید.'));
        }

        $name = trim((string) $this->request->get('name'));
        $icon = trim((string) $this->request->get('icon'));
        $color = trim((string) $this->request->get('color'));
        // اعتبارسنجی سادهٔ رنگ (هگز شش‌رقی)
        if ($color !== '' && !preg_match('~^#[0-9a-fA-F]{6}$~', $color)) {
            $color = '';
        }
        // اعتبارسنجی آیکون
        if ($icon !== '' && !Plugin::isValidCategoryIcon($icon)) {
            $icon = '';
        }

        if ($mode === 'cat-create') {
            if ($name === '') {
                $this->backWithError(_t('نام دسته را بنویسید.'));
            }
            $order = (int) ($this->request->filter('int')->get('order') ?: 0);
            Plugin::createCategory($name, $icon, $color, 0, $order);
            $state = 'cat-created';
        } elseif ($mode === 'cat-update') {
            $id = (int) ($this->request->filter('int')->get('id') ?: 0);
            if ($id < 1 || Plugin::getCategory($id) === null) {
                $this->backWithError(_t('دستهٔ موردنظر یافت نشد.'));
            }
            if ($name === '') {
                $this->backWithError(_t('نام دسته را بنویسید.'));
            }
            $order = (int) ($this->request->filter('int')->get('order') ?: -1);
            Plugin::updateCategory($id, $name, $icon, $color, 0, $order);
            $state = 'cat-updated';
        } else { // cat-delete
            $id = (int) ($this->request->filter('int')->get('id') ?: 0);
            if ($id < 1 || Plugin::getCategory($id) === null) {
                $this->backWithError(_t('دستهٔ موردنظر یافت نشد.'));
            }
            $reassign = (int) ($this->request->filter('int')->get('reassign') ?: 0);
            Plugin::deleteCategory($id, $reassign);
            $state = 'cat-deleted';
        }

        $url = Plugin::categoryAdminUrl() . '?' . $state . '=1';
        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->redirect($url);
    }

    /**
     * به‌روزرسانی پروفایل کاربر (درباره + شبکه‌های اجتماعی).
     * فقط خودِ کاربر می‌تواند پروفایلش را ویرایش کند.
     */
    private function handleUpdateProfile(): void
    {
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        if (!$this->user->hasLogin()) {
            $this->backWithError(_t('برای ویرایش پروفایل باید وارد حساب خود شوید.'));
        }

        $uid = (int) $this->user->uid;

        $newValues = [
            'bio'       => (string) $this->request->get('bio'),
            'twitter'   => (string) $this->request->get('twitter'),
            'github'    => (string) $this->request->get('github'),
            'telegram'  => (string) $this->request->get('telegram'),
            'instagram' => (string) $this->request->get('instagram'),
            'linkedin'  => (string) $this->request->get('linkedin'),
            'youtube'   => (string) $this->request->get('youtube'),
        ];

        $ok = Plugin::updateUserMeta($uid, $newValues);

        $profileUrl = Plugin::profileUrl($uid);
        $sep = str_contains($profileUrl, '?') ? '&' : '?';
        $state = $ok ? 'profile-saved' : 'profile-error';
        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->redirect($profileUrl . $sep . $state . '=1');
    }

    /**
     * به‌روزرسانی کامل پروفایل — نام نمایشی، ایمیل، وب، بیوگرافی و شبکه‌های اجتماعی (۲.۱.۰).
     * این متد همان کار پلاگین SiteProfile را درون خود انجمن انجام می‌دهد، بدون
     * آنکه کاربر عادی به پنل مدیریت TypeRenew برود.
     */
    private function handleUpdateProfileFull(): void
    {
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        if (!$this->user->hasLogin()) {
            $this->backWithError(_t('برای ویرایش پروفایل باید وارد حساب خود شوید.'));
        }

        $uid = (int) $this->user->uid;

        $screenName = trim((string) $this->request->get('screenName'));
        $mail = trim((string) $this->request->get('mail'));
        $url = trim((string) $this->request->get('url'));

        // اعتبارسنجی‌های ساده
        if ($mail === '' || !filter_var($mail, FILTER_VALIDATE_EMAIL)) {
            $editUrl = Plugin::profileEditUrl($uid);
            $sep = str_contains($editUrl, '?') ? '&' : '?';
            $this->response->redirect($editUrl . $sep . 'profile-error=1');
            return;
        }
        if ($url !== '' && !preg_match('#^https?://#i', $url)) {
            $url = 'https://' . ltrim($url, '/');
        }
        // جلوگیری از تداخل نام مستعار با کاربر دیگر — همان قاعدهٔ هسته
        // (۲.۱.۰ رفع) requireUserLogin برای کاربر واردشده در صورت تفاوت با
        // screenName فعلی false برمی‌گرداند و اجازهٔ تغییر را نمی‌داد؛
        // اکنون فقط تداخل با کاربر دیگر را بررسی می‌کنیم.
        if ($screenName !== '') {
            try {
                $db0 = \Typecho\Db::get();
                $other = $db0->fetchRow(
                    $db0->select('uid')->from('table.users')
                        ->where('(screenName = ? OR name = ?) AND uid <> ?', $screenName, $screenName, $uid)
                        ->limit(1)
                );
                if ($other) {
                    $editUrl = Plugin::profileEditUrl($uid);
                    $sep = str_contains($editUrl, '?') ? '&' : '?';
                    $this->response->redirect($editUrl . $sep . 'profile-error=1');
                    return;
                }
            } catch (\Throwable $e) {
                // در صورت خطا، ریسک نکنیم و تغییر را نپذیریم
            }
        }
        // جلوگیری از تداخل ایمیل با کاربر دیگر
        try {
            $db = \Typecho\Db::get();
            $other = $db->fetchRow(
                $db->select('uid')->from('table.users')
                    ->where('mail = ? AND uid <> ?', $mail, $uid)
                    ->limit(1)
            );
            if ($other) {
                $editUrl = Plugin::profileEditUrl($uid);
                $sep = str_contains($editUrl, '?') ? '&' : '?';
                $this->response->redirect($editUrl . $sep . 'profile-error=1');
                return;
            }
            // به‌روزرسانی فیلدهای جدول users
            $rows = [
                'mail' => mb_substr($mail, 0, 150),
                'url'  => mb_substr($url, 0, 150),
            ];
            if ($screenName !== '') {
                $rows['screenName'] = mb_substr($screenName, 0, 32);
            }
            $db->query(
                $db->update('table.users')->rows($rows)->where('uid = ?', $uid)
            );
        } catch (\Throwable $e) {
            $editUrl = Plugin::profileEditUrl($uid);
            $sep = str_contains($editUrl, '?') ? '&' : '?';
            $this->response->redirect($editUrl . $sep . 'profile-error=1');
            return;
        }

        // ذخیرهٔ بیوگرافی و شبکه‌های اجتماعی
        $metaValues = [
            'bio'       => (string) $this->request->get('bio'),
            'twitter'   => (string) $this->request->get('twitter'),
            'github'    => (string) $this->request->get('github'),
            'telegram'  => (string) $this->request->get('telegram'),
            'instagram' => (string) $this->request->get('instagram'),
            'linkedin'  => (string) $this->request->get('linkedin'),
            'youtube'   => (string) $this->request->get('youtube'),
        ];
        Plugin::updateUserMeta($uid, $metaValues);

        $profileUrl = Plugin::profileUrl($uid);
        $sep = str_contains($profileUrl, '?') ? '&' : '?';
        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->redirect($profileUrl . $sep . 'profile-saved=1');
    }

    /**
     * تغییر رمز عبور کاربر از درون انجمن (۲.۱.۰).
     * همان منطق Widget\Users\Edit\Profile بدون pass().
     */
    private function handleUpdatePassword(): void
    {
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        if (!$this->user->hasLogin()) {
            $this->backWithError(_t('برای تغییر رمز عبور باید وارد حساب خود شوید.'));
        }

        $uid = (int) $this->user->uid;
        $password = (string) $this->request->get('password');
        $confirm = (string) $this->request->get('confirm');

        if ($password === '' || $password !== $confirm) {
            $editUrl = Plugin::profileEditUrl($uid);
            $sep = str_contains($editUrl, '?') ? '&' : '?';
            $this->response->redirect($editUrl . $sep . 'pw-error=1');
            return;
        }

        try {
            $minLen = 6;
            $maxLen = 64;
            if (class_exists(\Utils\Password::class)) {
                $minLen = \Utils\Password::minLength();
                $maxLen = \Utils\Password::maxLength();
            }
            if (mb_strlen($password) < $minLen) {
                $editUrl = Plugin::profileEditUrl($uid);
                $sep = str_contains($editUrl, '?') ? '&' : '?';
                $this->response->redirect($editUrl . $sep . 'pw-error=1');
                return;
            }
            if (strlen($password) > $maxLen) {
                $editUrl = Plugin::profileEditUrl($uid);
                $sep = str_contains($editUrl, '?') ? '&' : '?';
                $this->response->redirect($editUrl . $sep . 'pw-error=1');
                return;
            }
            $hash = \Utils\Password::hash($password);
            $db = \Typecho\Db::get();
            $db->query(
                $db->update('table.users')->rows(['password' => $hash])->where('uid = ?', $uid)
            );
        } catch (\Throwable $e) {
            $editUrl = Plugin::profileEditUrl($uid);
            $sep = str_contains($editUrl, '?') ? '&' : '?';
            $this->response->redirect($editUrl . $sep . 'pw-error=1');
            return;
        }

        $editUrl = Plugin::profileEditUrl($uid);
        $sep = str_contains($editUrl, '?') ? '&' : '?';
        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->redirect($editUrl . $sep . 'pw-saved=1');
    }

    /**
     * ارسال پیام خصوصی (۲.۱.۰).
     */
    private function handlePmSend(): void
    {
        // (۲.۱.۰ رفع هاست اشتراکی) به‌جای security->protect() که به referer
        // وابسته است و در هاست‌های اشتراکی با HTTPS/Proxy ناموفق می‌شود،
        // یک بررسی CSRF ساده و مستقل از URL انجام می‌دهیم.
        $isAjax = (string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest';
        $token = (string) $this->request->get('_');
        $validToken = false;
        if ($token !== '') {
            $urls = [
                (string) $this->request->getReferer(),
                (string) $this->request->getRequestUrl(),
                Plugin::postUrl(),
            ];
            foreach ($urls as $url) {
                if ($url !== '' && hash_equals($this->security->getToken($url), $token)) {
                    $validToken = true;
                    break;
                }
            }
            // همچنین بدون پروتکل (http→https)
            if (!$validToken) {
                $stripProto = static function (string $url): string {
                    return preg_replace('~^https?://~i', '', $url);
                };
                foreach ($urls as $url) {
                    $stripped = $stripProto($url);
                    if ($stripped !== '' && $stripped !== $url) {
                        if (hash_equals($this->security->getToken($stripped), $token)) {
                            $validToken = true;
                            break;
                        }
                    }
                }
            }
        }
        if (!$validToken) {
            if ($isAjax) {
                Plugin::jsonOut(['ok' => false, 'error' => 'توکن امنیتی نامعتبر است. صفحه را نوسازی کنید و دوباره تلاش کنید.']);
                return;
            }
            $composeUrl = Plugin::messageComposeUrl();
            $sep = str_contains($composeUrl, '?') ? '&' : '?';
            $this->response->redirect($composeUrl . $sep . 'pm-error=' . rawurlencode('توکن امنیتی نامعتبر است. صفحه را نوسازی کنید و دوباره تلاش کنید.'));
            return;
        }

        if (!Plugin::pmEnabled()) {
            $this->backWithError(_t('پیام خصوصی غیرفعال است.'));
        }
        if (!$this->user->hasLogin()) {
            $this->backWithError(_t('برای ارسال پیام خصوصی باید وارد حساب خود شوید.'));
        }

        // ۲.۲.۰ — کاربر بلاک‌شده پیام خصوصی نمی‌فرستد
        if (!Plugin::canManage()) {
            $ban = Plugin::activeBanFor((int) $this->user->uid);
            if ($ban !== null) {
                $msg = 'حساب شما ' . Plugin::banUntilText($ban) . ' از فعالیت در انجمن مسدود است.';
                if ($isAjax) {
                    Plugin::jsonOut(['ok' => false, 'error' => $msg]);
                    return;
                }
                $this->backWithError(_t($msg));
            }
        }

        $senderId = (int) $this->user->uid;
        $recipientId = (int) ($this->request->filter('int')->get('recipient_id') ?: 0);
        $recipientName = trim((string) $this->request->get('recipient_name'));

        // اگر گیرنده با نام وارد شده، آن را به uid تبدیل کن
        if ($recipientId < 1 && $recipientName !== '') {
            try {
                $db = \Typecho\Db::get();
                $row = $db->fetchRow(
                    $db->select('uid')->from('table.users')
                        ->where('screenName = ? OR name = ?', $recipientName, $recipientName)
                        ->limit(1)
                );
                if ($row) {
                    $recipientId = (int) $row['uid'];
                }
            } catch (\Throwable $e) {
                // ادامه با 0
            }
        }

        $subject = (string) $this->request->get('subject');
        $body = (string) $this->request->get('body');

        $result = Plugin::sendPm($senderId, $recipientId, $subject, $body);
        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');

        if ($result['ok'] && !empty($result['id'])) {
            if ($isAjax) {
                // (۲.۱.۰) برای AJAX، JSON با URL مشاهده پیام برمی‌گردانیم
                Plugin::jsonOut([
                    'ok' => true,
                    'id' => (int) $result['id'],
                    'viewUrl' => Plugin::messageViewUrl((int) $result['id']),
                ]);
                return;
            }
            $this->response->redirect(Plugin::messageViewUrl((int) $result['id']) . '?pm-sent=1');
        } else {
            $error = $result['error'] ?? 'خطا در ارسال پیام.';
            if ($isAjax) {
                Plugin::jsonOut(['ok' => false, 'error' => $error]);
                return;
            }
            $composeUrl = Plugin::messageComposeUrl($recipientId > 0 ? $recipientId : null);
            $csep = str_contains($composeUrl, '?') ? '&' : '?';
            $this->response->redirect($composeUrl . $csep . 'pm-error=' . rawurlencode($error));
        }
    }

    /** حذف نرمِ یک پیام خصوصی از دید کاربر (۲.۱.۰) */
    private function handlePmDelete(): void
    {
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        if (!Plugin::pmEnabled() || !$this->user->hasLogin()) {
            $this->response->redirect(Plugin::messagesUrl());
            return;
        }
        $uid = (int) $this->user->uid;
        $messageId = (int) ($this->request->filter('int')->get('id') ?: 0);
        Plugin::pmSoftDelete($messageId, $uid);
        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->redirect(Plugin::messagesUrl() . '?pm-deleted=1');
    }

    /** حذف دسته‌جمعی پیام‌ها (۲.۱.۰) — ids از فرم checkbox می‌آید */
    private function handlePmDeleteBatch(): void
    {
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        if (!Plugin::pmEnabled() || !$this->user->hasLogin()) {
            Plugin::jsonOut(['ok' => false, 'error' => 'دسترسی غیرمجاز']);
            return;
        }
        $uid = (int) $this->user->uid;
        $ids = $this->request->get('ids');
        if (!is_array($ids)) {
            // ممکن است از JSON یا comma-separated باشد
            $raw = (string) $ids;
            if ($raw !== '') {
                $ids = array_filter(array_map('intval', explode(',', $raw)), static fn($i) => $i > 0);
            } else {
                $ids = [];
            }
        } else {
            $ids = array_filter(array_map('intval', $ids), static fn($i) => $i > 0);
        }
        if (empty($ids)) {
            Plugin::jsonOut(['ok' => false, 'error' => 'هیچ پیامی انتخاب نشده است.']);
            return;
        }
        $deleted = 0;
        foreach ($ids as $id) {
            if (Plugin::pmSoftDelete((int) $id, $uid)) {
                $deleted++;
            }
        }
        Plugin::jsonOut(['ok' => true, 'deleted' => $deleted]);
    }

    /** بلاک کردن یک کاربر (۲.۱.۰) */
    private function handlePmBlock(): void
    {
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        if (!Plugin::pmEnabled() || !$this->user->hasLogin()) {
            $this->response->redirect(Plugin::messagesUrl());
            return;
        }
        $uid = (int) $this->user->uid;
        $blockedId = (int) ($this->request->filter('int')->get('blocked_id') ?: 0);
        Plugin::blockUser($uid, $blockedId);
        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->redirect(Plugin::messagesUrl('blocked') . '?pm-blocked=1');
    }

    /** رفع بلاک یک کاربر (۲.۱.۰) */
    private function handlePmUnblock(): void
    {
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        if (!Plugin::pmEnabled() || !$this->user->hasLogin()) {
            $this->response->redirect(Plugin::messagesUrl());
            return;
        }
        $uid = (int) $this->user->uid;
        $blockedId = (int) ($this->request->filter('int')->get('blocked_id') ?: 0);
        Plugin::unblockUser($uid, $blockedId);
        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->redirect(Plugin::messagesUrl('blocked') . '?pm-unblocked=1');
    }

    /**
     * جستجوی آجاکسی گیرنده پیام خصوصی (۲.۱.۰).
     * با هر تایپ کاراکتر، نام/نام نمایشی کاربران منطبق را برمی‌گرداند.
     * فقط اعضای واردشده می‌توانند فراخوانی کنند؛ خود کاربر از نتایج حذف می‌شود.
     * (۲.۳.۰ رفع) آدرس ایمیل کاربران به دلیل حریم خصوصی دیگر در نتایج نیست؛
     * جستجو فقط بر اساس نام نمایشی یا نام کاربری است.
     */
    private function handlePmSearchUsers(): void
    {
        if (!Plugin::pmEnabled() || !$this->user->hasLogin()) {
            Plugin::jsonOut(['ok' => false, 'users' => []]);
            return;
        }
        $uid = (int) $this->user->uid;
        $q = trim((string) $this->request->get('q'));
        $out = [];
        if ($q !== '' && mb_strlen($q) >= 1) {
            try {
                $db = \Typecho\Db::get();
                $like = '%' . str_replace(['%', '_', '\\'], ['\\%', '\\_', '\\\\'], $q) . '%';
                $rows = $db->fetchAll(
                    $db->select('uid', 'name', 'screenName', 'group')
                        ->from('table.users')
                        ->where('uid <> ? AND (screenName LIKE ? OR name LIKE ?)', $uid, $like, $like)
                        ->order('screenName', Db::SORT_ASC)
                        ->limit(15)
                );
                foreach ($rows as $r) {
                    $displayName = trim((string) ($r['screenName'] ?: $r['name']));
                    if ($displayName === '') {
                        continue;
                    }
                    // (۲.۳.۰) ایمیل در نتایج نیست — فقط نام نمایشی و uid
                    $out[] = [
                        'uid'         => (int) $r['uid'],
                        'displayName' => $displayName,
                        'profileUrl'  => Plugin::profileUrl((int) $r['uid']),
                    ];
                }
            } catch (\Throwable $e) {
                // بی‌اثر
            }
        }
        Plugin::jsonOut(['ok' => true, 'users' => $out]);
    }

    /**
     * ثبت رأی در نظرسنجی.
     */
    private function handleVote(): void
    {
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        if (!Plugin::pollsEnabled()) {
            $this->backWithError(_t('نظرسنجی فعال نیست.'));
        }

        // ۲.۲.۰ — کاربر بلاک‌شده رأی نمی‌دهد
        $this->assertNotBanned();

        $coid = (int) ($this->request->filter('int')->get('coid') ?: 0);
        $optionIdx = (int) ($this->request->filter('int')->get('option') ?: 0);

        if ($coid < 1) {
            $this->backWithError(_t('پرسش موردنظر یافت نشد.'));
        }

        Plugin::castPollVote($coid, $optionIdx);

        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->redirect(Plugin::threadUrl($coid) . '?voted=1#c' . $coid);
    }

    /**
     * پسند/برداشتن پسند یک پرسش یا پاسخ (۲.۰.۰).
     * AJAX-friendly: همیشه JSON برمی‌گرداند؛ در حالت غیر-AJAX به پرسش برمی‌گردد.
     */
    private function handleLike(): void
    {
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        // ۲.۲.۰ — کاربر بلاک‌شده پسند نمی‌دهد
        if ($this->user->hasLogin() && !Plugin::canManage()) {
            $ban = Plugin::activeBanFor((int) $this->user->uid);
            if ($ban !== null) {
                $msg = 'حساب شما ' . Plugin::banUntilText($ban) . ' از فعالیت در انجمن مسدود است.';
                if ($this->request->isAjax()) {
                    Plugin::jsonOut([
                        'ok'      => false,
                        'status'  => 'banned',
                        'message' => $msg,
                    ]);
                }
                $this->backWithError(_t($msg));
            }
        }

        if (!Plugin::likesEnabled()) {
            if ($this->request->isAjax()) {
                Plugin::jsonOut([
                    'ok'      => false,
                    'status'  => 'disabled',
                    'message' => 'سیستم پسند فعال نیست.',
                ]);
            }
            $this->backWithError(_t('سیستم پسند فعال نیست.'));
        }

        $coid = (int) ($this->request->filter('int')->get('coid') ?: 0);
        $likeType = (string) $this->request->get('type');
        if ($likeType !== 'topic' && $likeType !== 'post') {
            $likeType = '';
        }
        if ($coid < 1 || Plugin::itemTypeOf($coid) === null) {
            if ($this->request->isAjax()) {
                Plugin::jsonOut([
                    'ok'      => false,
                    'status'  => 'not_found',
                    'message' => 'آیتم موردنظر یافت نشد.',
                ]);
            }
            $this->backWithError(_t('آیتم موردنظر یافت نشد.'));
        }

        $result = Plugin::toggleLike($coid, $likeType !== '' ? $likeType : null);

        if ($this->request->isAjax()) {
            $ok = in_array($result['status'], ['added', 'removed'], true);
            $message = match ($result['status']) {
                'added'   => 'پسند شما ثبت شد.',
                'removed' => 'پسند شما برداشته شد.',
                'guest'   => 'برای پسند دادن باید وارد حساب کاربری خود شوید.',
                'own'      => 'نمی‌توانید نوشتهٔ خودتان را پسند دهید.',
                default   => 'خطا در ثبت پسند.',
            };
            Plugin::jsonOut([
                'ok'      => $ok,
                'status'  => $result['status'],
                'count'   => (int) $result['count'],
                'coid'    => $coid,
                'message' => $message,
            ]);
        }

        // غیر-AJAX: بازگشت به همان پرسش
        $topic = Plugin::topicById($coid);
        $parent = $topic === null ? Plugin::postById($coid) : null;
        $redirectCoid = $topic !== null ? $coid : (int) ($parent['topic_id'] ?? 0);

        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->redirect(Plugin::threadUrl($redirectCoid) . '#c' . $coid);
    }

    /**
     * آپلود تصویر به سرویس imgurl.ir (۲.۰.۰).
     * فایل از ویرایشگر ارسال می‌شود، سمت سرور به سرویس منتقل و
     * پیوند مستقیم به‌صورت JSON برگردانده می‌شود تا در متن درج شود.
     */
    private function handleUploadImage(): void
    {
        // (۲.۱.۰ رفع هاست اشتراکی) protect() و isAjax() حذف شدند
        $fail = function (string $message) {
            Plugin::jsonOut(['ok' => false, 'message' => $message]);
        };

        if (!Plugin::imgUploadEnabled()) {
            $fail('آپلود تصویر فعال نیست.');
        }

        // همان مجوز ارسال پرسش/پاسخ
        if (!Plugin::allowPost()) {
            $fail('ارسال پرسش و پاسخ هم‌اکنون بسته شده است.');
        }
        $guestAsk = Plugin::opt('guestAsk', '1') !== '0';
        if (!$guestAsk && !$this->user->hasLogin()) {
            $fail('برای آپلود تصویر باید وارد حساب خود شوید.');
        }

        if (empty($_FILES['file']) || !is_array($_FILES['file'])) {
            $fail('فایلی انتخاب نشده است.');
        }

        $file = $_FILES['file'];

        // خطای آپلود PHP
        if ((int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            $code = (int) $file['error'];
            if ($code === UPLOAD_ERR_INI_SIZE || $code === UPLOAD_ERR_FORM_SIZE) {
                $fail('حجم فایل از حد مجاز سرور بیشتر است.');
            }
            $fail('فایل دریافت نشد؛ دوباره تلاش کنید.');
        }

        $tmpPath = (string) $file['tmp_name'];
        $origName = (string) $file['name'];
        $size = (int) $file['size'];

        if ($size < 1 || !is_uploaded_file($tmpPath)) {
            $fail('فایل دریافت نشد؛ دوباره تلاش کنید.');
        }

        // حجم
        $maxBytes = Plugin::imgUploadMaxBytes();
        if ($size > $maxBytes) {
            $fail('حجم تصویر نباید از ' . Plugin::faDigits((string) (int) ($maxBytes / 1048576)) . ' مگابایت بیشتر باشد.');
        }

        // پسوند
        $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
        if (!in_array($ext, Plugin::imgUploadExts(), true)) {
            $fail('فقط تصاویر JPG، PNG، GIF، WebP و BMP مجاز هستند.');
        }

        // محتوای واقعاً تصویری؟ (ضد جعل پسوند)
        $info = @getimagesize($tmpPath);
        if ($info === false || empty($info[0]) || empty($info[1])) {
            $fail('فایل انتخاب‌شده یک تصویر معتبر نیست.');
        }
        $mime = (string) ($info['mime'] ?? 'image/png');
        if (strpos($mime, 'image/') !== 0) {
            $fail('فایل انتخاب‌شده یک تصویر معتبر نیست.');
        }

        // آپلود به سرویس
        $url = Plugin::uploadToImgurl($tmpPath, $origName, $mime);
        if ($url === null) {
            $fail('بارگذاری تصویر در imgurl.ir ممکن نشد؛ کمی بعد دوباره تلاش کنید.');
        }

        Plugin::jsonOut([
            'ok'  => true,
            'url' => $url,
        ]);
    }

    /**
     * ویرایش پرسش/پاسخ — توسط نویسندهٔ واردشده، مدیر، یا مهمان در
     * چند دقیقهٔ نخست پس از ارسال.
     */
    private function handleEdit(): void
    {
        // توکن امنیتی — همان سازوکار هسته
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        $coid = (int) ($this->request->filter('int')->get('coid') ?: 0);

        $topic = Plugin::topicById($coid);
        $post = $topic === null ? Plugin::postById($coid) : null;
        $row = $topic ?? $post;

        if ($row === null) {
            $this->backWithError(_t('پرسش یا پاسخ موردنظر یافت نشد.'));
        }

        $isAnswer = $post !== null;
        $viewRow = $isAnswer ? Plugin::postRowToLegacy($post) : Plugin::topicRowToLegacy($topic);
        $backId = $isAnswer ? (int) $post['topic_id'] : (int) $topic['id'];

        // ۲.۲.۰ — کاربر بلاک‌شده ویرایش نمی‌کند (مدیر مستثنی است)
        $this->assertNotBanned($backId);

        if (!Plugin::canEdit($viewRow)) {
            $this->backWithError(
                _t('ویرایش این پرسش/پاسخ فقط توسط نویسندهٔ آن (در چند دقیقهٔ نخست برای مهمان‌ها) ممکن است.'),
                $backId
            );
        }

        // ۲.۲.۰ — دستهٔ قفل‌شده: ویرایش نوشته‌ها هم فقط برای مدیر
        // (پرسش: دستهٔ خودش؛ پاسخ: دستهٔ پرسشِ والد)
        if (!Plugin::canManage()) {
            $editCatId = $isAnswer
                ? (int) (Plugin::topicById((int) $post['topic_id'])['category_id'] ?? 0)
                : (int) ($topic['category_id'] ?? 0);
            if ($editCatId > 0 && Plugin::isCategoryLocked($editCatId)) {
                $editCat = Plugin::getCategory($editCatId);
                $editCatName = $editCat !== null ? $editCat['name'] : '';
                $this->backWithError(
                    _t('دستهٔ «' . $editCatName . '» قفل است؛ نوشتن و ویرایش فقط برای مدیران ممکن است.'),
                    $backId
                );
            }
        }

        $text = trim((string) $this->request->get('text'));

        if ($text === '') {
            $this->backWithError(_t('متن نمی‌تواند خالی باشد.'), $backId);
        }

        // برای پرسش‌ها: عنوان را به ابتدای متن اضافه کن
        if (!$isAnswer) {
            $editTitle = trim((string) $this->request->get('title'));
            if ($editTitle !== '') {
                $editTitle = mb_substr($editTitle, 0, 120);
                $text = $editTitle . "\n\n" . ltrim($text);
            }
        }

        // ۲.۲.۰ — فیلتر کلمات (سانسور خودکار) قبل از ذخیره‌سازی ویرایش
        $text = Plugin::applyWordFilters($text);

        $maxLength = Plugin::maxTextLength();
        if (mb_strlen($text) > $maxLength) {
            $this->backWithError(
                _t('متن حداکثر') . ' ' . Plugin::faDigits($maxLength) . ' ' . _t('نویسه است.'),
                $backId
            );
        }

        // همان پاک‌سازی نام نویسندهٔ مهمان هنگام ویرایش (اگر فرستاده شود)
        // — نویسنده و ایمیل عمداً تغییر نمی‌کنند.

        $table = $isAnswer ? 'table.forum_posts' : 'table.forum_topics';
        $updateRows = ['text' => $text, 'modified' => time()];

        // عنوان جدا برای پرسش (ستون title جدول اختصاصی)
        if (!$isAnswer) {
            [$t] = Plugin::splitQuestion($text);
            $updateRows['title'] = mb_substr(Plugin::stripMarkup($t), 0, 250);
        }

        try {
            $this->db->query(
                $this->db->update($table)
                    ->rows($updateRows)
                    ->where('id = ?', $coid)
            );
        } catch (\Throwable $e) {
            $this->backWithError(_t('ذخیرهٔ ویرایش ممکن نشد؛ کمی بعد دوباره تلاش کنید.'), $backId);
        }

        // به‌روزرسانی دستهٔ پرسش هنگام ویرایش — فقط مدیر
        if (!$isAnswer && Plugin::canManage()) {
            $newCatId = (int) ($this->request->filter('int')->get('category') ?: 0);
            if ($newCatId > 0 && Plugin::getCategory($newCatId) !== null) {
                Plugin::setTopicCategory($coid, $newCatId);
            } elseif ($newCatId === 0) {
                // حذف از دسته (انتقال به «بدون دسته»)
                Plugin::setTopicCategory($coid, 0);
            }
        }

        // ویرایش/افزودن/حذف نظرسنجی پرسش (۲.۰.۰)
        // فقط وقتی فیلدهای نظرسنجی در فرم رندر شده باشند (poll_present) —
        // ویرایش مهمان یا فرم بدون بخش نظرسنجی، نظرسنجی موجود را دست نمی‌زند.
        if (!$isAnswer && Plugin::pollsEnabled() && $this->request->get('poll_present') === '1') {
            $hadPoll = Plugin::getPoll($coid) !== null;
            if ($this->request->get('has_poll') === '1') {
                $pollQ = trim((string) $this->request->get('poll_question'));
                $pollOptsRaw = trim((string) $this->request->get('poll_options'));
                $pollOpts = array_values(array_filter(
                    array_map('trim', explode("\n", str_replace(["\r\n", "\r"], "\n", $pollOptsRaw))),
                    static fn ($o) => $o !== ''
                ));
                if ($pollQ !== '' && count($pollOpts) >= 2) {
                    Plugin::setPoll($coid, $pollQ, $pollOpts);
                }
            } elseif ($hadPoll) {
                // تیک برداشته شده — نظرسنجی و آرا آن حذف می‌شوند
                Plugin::deletePoll($coid);
            }
        }

        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $this->response->redirect(Plugin::threadUrl($backId) . '?edited=1#c' . $coid);
    }
}
