<?php
namespace TypechoPlugin\Forum;

use Typecho\Cookie;
use Typecho\Db;
use Typecho\Router;
use Typecho\Plugin\PluginInterface;
use Utils\Helper;
use Utils\Markdown;
use Utils\Schema as CoreSchema;
use Widget\Options;
use Widget\User;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * انجمن پرسش و پاسخ — فورومی سبک و ساده برای گفتگو.
 *
 * @package Forum
 * @author  پوردریایی
 * @link    https://pourdaryaei.ir
 * @since   1.6.0
 * @version 2.4.0
 */
class Plugin implements PluginInterface
{
    public const VERSION = '2.4.0';

    public const ROUTE_LIST = 'forum';
    public const ROUTE_PAGE = 'forum_page';
    public const ROUTE_THREAD = 'forum_thread';
    public const ROUTE_PROFILE = 'forum_profile';
    public const ROUTE_PROFILE_EDIT = 'forum_profile_edit';
    public const ROUTE_CAT_ADMIN = 'forum_cat_admin';
    public const ROUTE_MESSAGES = 'forum_messages';
    public const ROUTE_MESSAGE_VIEW = 'forum_message_view';
    public const ROUTE_MESSAGE_COMPOSE = 'forum_message_compose';
    /** (۲.۳.۰) صفحهٔ مستقل اعلان‌ها — /forum/notifications */
    public const ROUTE_NOTIFICATIONS = 'forum_notifications';
    public const ACTION_NAME = 'forum';
    public const ADMIN_ACTION_NAME = 'forum_admin';

    /** ردیف ذخیرهٔ uid مالک انجمن در جدول options — مجوز مدیریت (همان الگوی نسخهٔ قدیمی) */
    public const OWNER_OPTION = 'ext:Forum-owner';

    /** نشانهٔ انجام ایمپورت از سیستم دیدگاه‌محور قدیمی */
    public const IMPORTED_OPTION = 'ext:Forum2-imported';

    /** گزارش شمارش ایمپورت (JSON) */
    public const IMPORT_STATS_OPTION = 'ext:Forum2-import-stats';

    /** نام کوکی یکتاسازی بازدیدها */
    public const VIEWS_COOKIE = 'forumViews';

    /** نام کوکی پست‌های خوانده‌شده (برای بولت سبز «خوانده‌نشده») — فرمت id:timestamp */
    public const READS_COOKIE = 'forumReads';

    /** بیشینهٔ اندازهٔ نگاشت خوانده‌شده‌ها در کوکی (پیشگیری از سرریز کوکی) */
    private const READS_MAP_MAX = 100;

    /** کش نگاشت id => آخرین زمان خواندن در طول درخواست */
    private static ?array $readMapCache = null;

    /** کش آخرین فعالیت تاپیک‌ها در طول درخواست (برای isRead بدون آرگومان) */
    private static array $lastActivityCache = [];

    /** نام کوکی یکتاسازی گزارش‌ها (flag) — جلوگیری از گزارش تکراری یک آیتم توسط یک نفر */
    public const FLAG_COOKIE = 'forumFlags';

    /** امتیاز پیش‌فرض هر موضوع (پرسش) ایجادشده — قابل تغییر در تنظیمات */
    public const DEFAULT_SCORE_QUESTION = 3;

    /** امتیاز پیش‌فرض هر پاسخ ایجادشده — قابل تغییر در تنظیمات */
    public const DEFAULT_SCORE_ANSWER = 1;

    /** امتیاز پیش‌فرض اضافی برای هر پاسخی که بهترین پاسخ انتخاب شده — قابل تغییر در تنظیمات */
    public const DEFAULT_SCORE_BEST = 5;

    /** نام کوکی مالکیت نوشته‌های مهمان (برای ویرایش چنددقیقه‌ای) */
    public const GUEST_COOKIE = 'forumGuest';

    /** بیشینهٔ طول فهرست کوکی‌ها */
    private const COOKIE_LIST_MAX = 200;

    /** نگاشت ماه‌های شمسی */
    private const J_MONTHS = [
        1 => 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
        'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
    ];

    /** شکلک‌های نوار ابزار — ۴۰ شکلک محبوب (۲.۰.۰) */
    public const EMOJIS = [
        // چهره‌ها
        '😀', '😁', '😂', '🤣', '🙂', '😊', '😍', '😘',
        '😜', '🤪', '🤔', '🤗', '🙄', '😴', '🥱', '😭',
        '😢', '😅', '😔', '😡', '🤯', '🥳', '😎', '🤩',
        // ژست‌ها
        '👍', '👎', '👌', '✌️', '🤝', '🙏', '👏', '💪',
        // نشانه‌ها
        '🔥', '❤️', '💔', '✅', '❌', '⭐', '💡', '❓',
    ];

    /** کش آمار کلی انجمن در طول درخواست */
    private static ?array $statsCache = null;

    /** کش فهرست دسته‌ها در طول درخواست */
    private static ?array $categoriesCache = null;

    /** کش نگاشت گزارش‌ها در طول درخواست: itemType:itemId => count */
    private static ?array $flagCache = null;

    /** کش نگاشت پسندها در طول درخواست: itemType:itemId => [count, voters] */
    private static ?array $likeCache = null;

    /** پرچم یک‌بارهٔ «جدول پسندها بررسی/ساخت شد» در طول درخواست */
    private static ?bool $likesTableReady = null;

    /** کش بلاک‌های اداری فعال در طول درخواست: uid => ردیف بلاک */
    private static ?array $bansCache = null;

    /** پرچم یک‌بارهٔ «جدول بلاک‌ها بررسی/ساخت شد» در طول درخواست (۲.۲.۰) */
    private static ?bool $bansTableReady = null;

    // ====================================================================
    //  فعال‌سازی / غیرفعال‌سازی
    // ====================================================================

    public static function activate()
    {
        // بهداشت مسیرها و اکشن‌ها هنگام فعال‌سازی مجدد
        Helper::removeRoute(self::ROUTE_LIST);
        Helper::removeRoute(self::ROUTE_PAGE);
        Helper::removeRoute(self::ROUTE_THREAD);
        Helper::removeRoute(self::ROUTE_PROFILE);
        Helper::removeRoute(self::ROUTE_PROFILE_EDIT);
        Helper::removeRoute(self::ROUTE_CAT_ADMIN);
        Helper::removeRoute(self::ROUTE_NOTIFICATIONS);
        Helper::removeRoute(self::ADMIN_ACTION_NAME);

        // مسیرهای عمومی — بلافاصله بعد از مسیر do ثبت می‌شوند تا در
        // اولویتِ مسیرهای انتهاییِ جامع (مانند feedback) قرار بگیرند.
        Helper::addRoute(self::ROUTE_LIST, '/forum', '\TypechoPlugin\Forum\ForumList', 'render', 'do');
        Helper::addRoute(self::ROUTE_PAGE, '/forum/page/[page:digital]', '\TypechoPlugin\Forum\ForumList', 'render', 'do');
        Helper::addRoute(self::ROUTE_PROFILE, '/forum/u/[uid:digital]', '\TypechoPlugin\Forum\Profile', 'render', 'do');
        Helper::addRoute(self::ROUTE_PROFILE_EDIT, '/forum/u/[uid:digital]/edit', '\TypechoPlugin\Forum\ProfileEdit', 'render', 'do');
        Helper::addRoute(self::ROUTE_THREAD, '/forum/[coid:digital]', '\TypechoPlugin\Forum\Thread', 'render', 'do');
        Helper::addRoute(self::ROUTE_CAT_ADMIN, '/forum/admin/categories', '\TypechoPlugin\Forum\CategoryAdmin', 'render', 'do');
        // (۲.۳.۰) صفحهٔ مستقل اعلان‌ها — مسیری ایزوله و جدید؛ هیچ مسیر
        // موجودی جابه‌جا یا حذف نمی‌شود.
        Helper::addRoute(self::ROUTE_NOTIFICATIONS, '/forum/notifications', '\TypechoPlugin\Forum\Notifications', 'render', 'do');

        Helper::removeAction(self::ACTION_NAME);
        Helper::addAction(self::ACTION_NAME, '\TypechoPlugin\Forum\Post');

        // اکشن مدیریت پنل ادمین (الگوی RenewShield)
        Helper::addRoute(self::ADMIN_ACTION_NAME, '/action/forum-admin', '\TypechoPlugin\Forum\AdminAction', 'action');

        // پنل مدیریت اختصاصی در پیشخوان — منوی «پرسش و پاسخ»
        Helper::addPanel(5, 'Forum/Panel.php', 'پرسش و پاسخ', 'مدیریت انجمن', 'editor', false, '', ['icon' => 'i-message']);

        // درج خودکار پیوند انجمن در منوی اصلی پوسته — از طریق هوک header
        \Typecho\Plugin::factory('Widget\Archive')->header = [__CLASS__, 'headerInject'];

        // سازگاری با RenewShield: هوک footer برای ست کردن cookie/state
        // روی صفحات انجمن (تفسیر کامل در متنِ footerHook).
        \Typecho\Plugin::factory('Widget\Archive')->footer = [__CLASS__, 'footerHook'];

        // (۲.۲.۰) کنترل دسترسی کاربران عادی — همان الگوی SiteProfile
        \Typecho\Plugin::factory('Widget\Login')->loginSuccess = [__CLASS__, 'onLoginSuccess'];
        \Typecho\Plugin::factory('Widget\Register')->finishRegister = [__CLASS__, 'onFinishRegister'];
        \Typecho\Plugin::factory('admin/common.php')->begin = [__CLASS__, 'onAdminBegin'];

        // ساخت جداول اختصاصی
        Schema::ensure();

        // ثبت مالک انجمن (اگر هنوز تعیین نشده)
        if ((int) self::readOptionValue(self::OWNER_OPTION) < 1) {
            try {
                $user = User::alloc();
                $uid = ($user->hasLogin() && $user->uid) ? (int) $user->uid : 0;
            } catch (\Throwable $e) {
                $uid = 0;
            }
            if ($uid > 0) {
                self::writeOptionValue(self::OWNER_OPTION, (string) $uid);
            }
        }

        // ایمپورت خودکار از سیستم قدیمی (دیدگاه‌محور) — یک‌بار، idempotent
        $importMessage = Import::runIfLegacy();

        $link = Router::url(self::ROUTE_LIST, [], Options::alloc()->index);

       $out = _t('پلاگین انجمن ساز فعال شد.')
    . ' <a href="' . htmlspecialchars($link, ENT_QUOTES, 'UTF-8') . '">'
    . htmlspecialchars($link, ENT_QUOTES, 'UTF-8') . '</a>';
	if ($importMessage !== '') {
	    $out .= '<br>' . $importMessage;
	}
	return $out;
    }

    public static function deactivate()
    {
        Helper::removeRoute(self::ROUTE_LIST);
        Helper::removeRoute(self::ROUTE_PAGE);
        Helper::removeRoute(self::ROUTE_THREAD);
        Helper::removeRoute(self::ROUTE_PROFILE);
        Helper::removeRoute(self::ROUTE_PROFILE_EDIT);
        Helper::removeRoute(self::ROUTE_CAT_ADMIN);
        Helper::removeRoute(self::ROUTE_NOTIFICATIONS);
        Helper::removeRoute(self::ADMIN_ACTION_NAME);
        Helper::removeAction(self::ACTION_NAME);

        // حذف پنل مدیریت از منو
        try {
            Helper::removePanel(5, 'Forum/Panel.php');
        } catch (\Throwable $e) {
            // از نسخه‌های پیشین پنلی ثبت نشده بوده
        }

        // هوک منو هنگام غیرفعال‌سازی به‌طور خودکار توسط هسته حذف می‌شود

	return _t('پلاگین انجمن ساز غیرفعال شد. داده‌های انجمن دست‌نخورده باقی ماند.');
    }

    /**
     * فرم تنظیمات افزونه
     */
    public static function config(\Typecho\Widget\Helper\Form $form)
    {
        $title = new \Typecho\Widget\Helper\Form\Element\Text(
            'forumTitle',
            null,
            'انجمن پرسش و پاسخ',
            _t('عنوان انجمن'),
            _t('عنوانی که بالای صفحهٔ انجمن نمایش داده می‌شود.')
        );
        $form->addInput($title);

        $intro = new \Typecho\Widget\Helper\Form\Element\Textarea(
            'forumIntro',
            null,
            'پرسش‌های خود را بپرسید؛ کاربران و مدیران پاسخ می‌دهند.',
            _t('متن معرفی'),
            _t('یک جملهٔ کوتاه که زیر عنوان انجمن نمایش داده می‌شود. خالی بگذارید تا حذف شود.')
        );
        $form->addInput($intro);

        $pageSize = new \Typecho\Widget\Helper\Form\Element\Text(
            'pageSize',
            null,
            '15',
            _t('تعداد پرسش در هر صفحه'),
            _t('عدد بین ۵ تا ۱۰۰ — تعداد پرسش‌هایی که در هر صفحهٔ فهرست نمایش داده می‌شود.')
        );
        $form->addInput($pageSize);

        $postsPerPage = new \Typecho\Widget\Helper\Form\Element\Text(
            'postsPerPage',
            null,
            '15',
            _t('تعداد پاسخ در هر صفحه (تاپیک)'),
            _t('عدد بین ۵ تا ۱۰۰ — تعداد پاسخ‌هایی که در هر صفحه از یک تاپیک (صفحهٔ پرسش) نمایش داده می‌شود. وقتی پاسخ‌های یک پرسش بیش از این تعداد شود، پاسخ‌ها به‌صورت صفحه‌بندی‌شده نمایش داده می‌شوند. پیش‌فرض ۱۵ — هم‌سان با «تعداد پرسش در هر صفحه».')
        );
        $form->addInput($postsPerPage);

        $allowPost = new \Typecho\Widget\Helper\Form\Element\Radio(
            'allowPost',
            ['1' => _t('بله، ارسال باز است'), '0' => _t('خیر، ارسال پرسش و پاسخ بسته شود')],
            '1',
            _t('ارسال پرسش و پاسخ'),
            _t('در نسخهٔ ۲ به‌جای بستن دیدگاه‌های نوشتهٔ پشتیبان، ارسال‌ها از همین‌جا بسته می‌شوند.')
        );
        $form->addInput($allowPost);

        $guestAsk = new \Typecho\Widget\Helper\Form\Element\Radio(
            'guestAsk',
            ['1' => _t('بله، مهمان‌ها بتوانند بپرسند'), '0' => _t('خیر، فقط اعضای واردشده')],
            '1',
            _t('پرسش مهمان‌ها'),
            _t('اگر خیر باشد، فقط کاربران واردشده می‌توانند پرسش جدید بپرسند یا پاسخ بدهند.')
        );
        $form->addInput($guestAsk);

        // ------------------ تأیید پیش از انتشار ------------------

        $moderationMode = new \Typecho\Widget\Helper\Form\Element\Radio(
            'moderationMode',
            [
                'off'     => _t('خاموش — همان تنظیمات هسته TypeRenew اعمال شود'),
                'guests'  => _t('فقط مهمان‌ها — پرسش‌ها و پاسخ‌های مهمان قبل از انتشار باید تأیید شوند'),
                'all'     => _t('همه — همهٔ پرسش‌ها و پاسخ‌ها (مهمان و عضو) قبل از انتشار باید تأیید شوند'),
            ],
            'guests',
            _t('تأیید پیش از انتشار'),
            _t('پرسش‌ها و پاسخ‌های جدید قبل از نمایش عمومی به وضعیت «در انتظار تأیید» در می‌آیند و در پنل مدیریت «پرسش و پاسخ» پیشخوان قابل رسیدگی هستند. کاربران دارای دسترسی ویراستار یا بالاتر (و مالک انجمن) از این قاعده مستثنی هستند. این تنظیم جدا از «فهرست سفید» و «نیاز به تأیید» هسته عمل می‌کند و بر آن اولویت دارد.')
        );
        $form->addInput($moderationMode);

        $gravatar = new \Typecho\Widget\Helper\Form\Element\Radio(
            'gravatar',
            ['1' => _t('بله، نمایش آواتار گراواتار'), '0' => _t('خیر، فقط آواتار حرف اول نام')],
            '1',
            _t('آواتار گراواتار'),
            _t('اگر کاربر ایمیل معتبر داده باشد، آواتار او از سرویس گراواتار نمایش داده می‌شود؛ در نبود آن، آواتار رنگی حرف اول نام نشان داده می‌شود (بدون هیچ درخواست اضافه).')
        );
        $form->addInput($gravatar);

        $gravatarServer = new \Typecho\Widget\Helper\Form\Element\Text(
            'gravatarServer',
            null,
            'https://secure.gravatar.com/avatar',
            _t('نشانی سرویس گراواتار'),
            _t('در صورت مسدودبودن گراواتار می‌توانید نشانی یک سرویس آینه (mirror) را بگذارید. فقط نشانی‌های http/https پذیرفته می‌شوند.')
        );
        $form->addInput($gravatarServer);

        // ------------------ نمایش ------------------

        $menuLink = new \Typecho\Widget\Helper\Form\Element\Radio(
            'menuLink',
            ['1' => _t('بله، خودکار اضافه شود'), '0' => _t('خیر، خودم پیوند می‌گذارم')],
            '1',
            _t('درج پیوند انجمن در منوی اصلی'),
            _t('پیوند انجمن به‌صورت خودکار به منوی بالای سایت (پوسته‌های دارای فهرست nav-menu استاندارد) اضافه می‌شود.')
        );
        $form->addInput($menuLink);

        $menuLabel = new \Typecho\Widget\Helper\Form\Element\Text(
            'menuLabel',
            null,
            'انجمن',
            _t('برچسب پیوند منو'),
            _t('متنی که برای پیوند انجمن در منوی اصلی نمایش داده می‌شود.')
        );
        $form->addInput($menuLabel);

        $showSidebar = new \Typecho\Widget\Helper\Form\Element\Radio(
            'showSidebar',
            ['1' => _t('نمایش سایدبار'), '0' => _t('پنهان باشد')],
            '1',
            _t('نوار کناری (سایدبار)'),
            _t('نوار کناری صفحات انجمن شامل ویجت‌های پروفایل کاربر، آمار و دکمه‌های ورود/خروج/ثبت‌نام. وقتی پنهان باشد، دکمهٔ «پرسش جدید» به‌صورت خودکار کنار نوار مرتب‌سازی (بالای فهرست) نمایش داده می‌شود.')
        );
        $form->addInput($showSidebar);

        $headerColor = new \Typecho\Widget\Helper\Form\Element\Text(
            'headerColor',
            null,
            '',
            _t('رنگ سربرگ انجمن'),
            _t('رنگ یا گرادیان سفارشی سربرگ (مثال: #7C3AED یا linear-gradient(135deg,#7C3AED,#2563EB)). خالی بگذارید تا سربرگ از رنگ تأکیدی/گرادیان پوستهٔ فعلی پیروی کند.')
        );
        $form->addInput($headerColor);

        $sidebarWidgets = new \Typecho\Widget\Helper\Form\Element\Checkbox(
            'sidebarWidgets',
            [
                'user'       => _t('ویجت پروفایل کاربر (آواتار، آمار شخصی، موضوع جدید)'),
                'categories' => _t('ویجت دسته‌بندی‌ها (فهرست دسته‌ها و شمار موضوع هر دسته)'),
                'stats'      => _t('ویجت آمار انجمن (موضوع، پاسخ، اعضا)'),
                'members'    => _t('ویجت آخرین اعضا (گرید ۸ آواتار آخرین کاربران عضو‌شده)'),
                'auth'       => _t('ویجت ورود/خروج و ثبت‌نام')
            ],
            ['user', 'categories', 'stats', 'members', 'auth'],
            _t('ویجت‌های سایدبار'),
            _t('هر ویجت را می‌توانید جداگانه نمایش یا پنهان کنید.')
        );
        $form->addInput($sidebarWidgets);

        $showProfilePage = new \Typecho\Widget\Helper\Form\Element\Radio(
            'showProfilePage',
            ['1' => _t('نمایش صفحهٔ پروفایل'), '0' => _t('پنهان باشد')],
            '1',
            _t('صفحهٔ پروفایل اعضا'),
            _t('صفحهٔ /forum/u/{شماره-عضو} شامل آمار شخصی و تب پرسش‌ها/پاسخ‌های کاربر. نام نویسنده‌های عضو به این صفحه پیوند می‌خورد.')
        );
        $form->addInput($showProfilePage);

        $enableViews = new \Typecho\Widget\Helper\Form\Element\Radio(
            'enableViews',
            ['1' => _t('بله، شمرده شود'), '0' => _t('خیر')],
            '1',
            _t('آمار بازدید پرسش‌ها'),
            _t('بازدید هر پرسش شمرده و در فهرست و صفحهٔ پرسش نمایش داده می‌شود.')
        );
        $form->addInput($enableViews);

        $enableLightbox = new \Typecho\Widget\Helper\Form\Element\Radio(
            'enableLightbox',
            ['1' => _t('بله، تصاویر در لایت‌باکس باز شوند'), '0' => _t('خیر')],
            '1',
            _t('لایت‌باکس تصاویر'),
            _t('تصاویر درون پرسش‌ها و پاسخ‌ها با کلیک در یک پنجرهٔ بزرگ روی صفحه نمایش داده می‌شوند.')
        );
        $form->addInput($enableLightbox);

        $enablePolls = new \Typecho\Widget\Helper\Form\Element\Radio(
            'enablePolls',
            ['1' => _t('بله، نظرسنجی فعال باشد'), '0' => _t('خیر')],
            '1',
            _t('نظرسنجی در پرسش‌ها'),
            _t('نویسندهٔ پرسش می‌تواند یک نظرسنجی با تا ۸ گزینه به پرسش خود اضافه کند. هر بازدیدکننده یک بار می‌تواند رأی دهد.')
        );
        $form->addInput($enablePolls);

        $enableLikes = new \Typecho\Widget\Helper\Form\Element\Radio(
            'enableLikes',
            ['1' => _t('بله، دکمهٔ پسند فعال باشد'), '0' => _t('خیر')],
            '1',
            _t('پسند (لایک) پرسش‌ها و پاسخ‌ها'),
            _t('دکمهٔ پسند برای هم پرسش‌ها و هم پاسخ‌ها نمایش داده می‌شود؛ فقط اعضای واردشده می‌توانند پسند بدهند و هیچ‌کس نمی‌تواند نوشتهٔ خودش را پسند دهد. هر عضو روی هر پرسش یا پاسخ فقط یک پسند ثبت می‌کند و می‌تواند آن را بردارد.')
        );
        $form->addInput($enableLikes);

        $enableImgUpload = new \Typecho\Widget\Helper\Form\Element\Radio(
            'enableImgUpload',
            ['1' => _t('بله، دکمهٔ آپلود نمایش داده شود'), '0' => _t('خیر')],
            '1',
            _t('آپلود تصویر در ویرایشگر'),
            _t('دکمهٔ «آپلود تصویر» به نوار ابزار ویرایشگر پرسش/پاسخ اضافه می‌شود. تصویر انتخاب‌شده از کامپیوتر از طریق سرویس imgurl.ir بارگذاری و پیوند مستقیم آن به‌صورت خودکار در متن درج می‌شود.')
        );
        $form->addInput($enableImgUpload);

        $imgUploadMaxMB = new \Typecho\Widget\Helper\Form\Element\Select(
            'imgUploadMaxMB',
            [
                '2'   => _t('۲ مگابایت'),
                '5'   => _t('۵ مگابایت'),
                '10'  => _t('۱۰ مگابایت'),
                '20'  => _t('۲۰ مگابایت')
            ],
            '10',
            _t('بیشینهٔ حجم تصویر آپلودی'),
            _t('تصاویری که از طریق سرویس imgurl.ir آپلود می‌شوند نباید از این حجم بیشتر باشند.')
        );
        $form->addInput($imgUploadMaxMB);

        $viewsInterval = new \Typecho\Widget\Helper\Form\Element\Select(
            'viewsInterval',
            [
                '0'      => _t('بدون فاصله؛ هر بازدید شمرده شود'),
                '600'    => _t('۱۰ دقیقه'),
                '3600'   => _t('۱ ساعت'),
                '21600'  => _t('۶ ساعت'),
                '86400'  => _t('۲۴ ساعت')
            ],
            '3600',
            _t('فاصلهٔ یکتاسازی بازدید'),
            _t('بازدیدهای یک نفر از یک پرسش در این بازه فقط یک بار شمرده می‌شود.')
        );
        $form->addInput($viewsInterval);

        $autoLockDays = new \Typecho\Widget\Helper\Form\Element\Select(
            'autoLockDays',
            [
                '0'   => _t('خاموش — قفل خودکار نداریم'),
                '3'   => _t('۳ روز'),
                '7'   => _t('۷ روز'),
                '14'  => _t('۱۴ روز'),
                '30'  => _t('۳۰ روز'),
                '60'  => _t('۶۰ روز'),
                '90'  => _t('۹۰ روز'),
                '180' => _t('۱۸۰ روز'),
                '365' => _t('یک سال')
            ],
            '0',
            _t('قفل خودکار پرسش‌های بی‌فعالیت'),
            _t('پرسشی که مدت ذکرشده هیچ فعالیتی (پاسخ جدید) نداشته باشد، هنگام بازدید از آن صفحه به‌طور خودکار قفل می‌شود. روش تنبل — بدون cron.')
        );
        $form->addInput($autoLockDays);

        // ---------------- امتیازدهی ----------------
        $scoreQuestion = new \Typecho\Widget\Helper\Form\Element\Text(
            'scoreQuestion',
            null,
            (string) self::DEFAULT_SCORE_QUESTION,
            _t('امتیاز هر پرسش (موضوع)'),
            _t('امتیازی که برای ایجاد هر پرسش به نویسنده داده می‌شود. پیش‌فرض: ۳')
        );
        $form->addInput($scoreQuestion);

        $scoreAnswer = new \Typecho\Widget\Helper\Form\Element\Text(
            'scoreAnswer',
            null,
            (string) self::DEFAULT_SCORE_ANSWER,
            _t('امتیاز هر پاسخ'),
            _t('امتیازی که برای ایجاد هر پاسخ به نویسنده داده می‌شود. پیش‌فرض: ۱')
        );
        $form->addInput($scoreAnswer);

        $scoreBest = new \Typecho\Widget\Helper\Form\Element\Text(
            'scoreBest',
            null,
            (string) self::DEFAULT_SCORE_BEST,
            _t('امتیاز بهترین پاسخ'),
            _t('امتیاز اضافی که وقتی پاسخی به‌عنوان بهترین پاسخ انتخاب می‌شود به نویسندهٔ آن پاسخ داده می‌شود. پیش‌فرض: ۵')
        );
        $form->addInput($scoreBest);

        $guestEditMinutes = new \Typecho\Widget\Helper\Form\Element\Text(
            'guestEditMinutes',
            null,
            '5',
            _t('مهلت ویرایش مهمان (دقیقه)'),
            _t('مهمان‌ها فقط تا این تعداد دقیقه پس از ارسال می‌توانند پرسش/پاسخ خود را ویرایش کنند. صفر یعنی ویرایش مهمان خاموش باشد. اعضای واردشده همیشه (و به‌عنوان نویسنده) اجازهٔ ویرایش دارند.')
        );
        $form->addInput($guestEditMinutes);

        // ---------------- فیلتر کلمات (۲.۲.۰) ----------------

        $wordFilters = new \Typecho\Widget\Helper\Form\Element\Textarea(
            'wordFilters',
            null,
            '',
            _t('فیلتر کلمات (سانسور خودکار)'),
            _t('هر سطر یک قانون: «کلمه=جایگزین». مثلاً: fuck=f*** یا کلمه_بد=ک***. '
               . 'تطبیق case-insensitive و فقط کلمهٔ کامل (با مرز کلمه). '
               . 'سطرهایی که با # شروع شوند، کامنت در نظر گرفته می‌شوند و نادیده گرفته می‌شوند. '
               . 'وقتی کاربر پرسش یا پاسخی می‌فرستد یا ویرایش می‌کند، کلماتِ مطابق قبل از ذخیره‌سازی به‌صورت خودکار با جایگزین‌شان عوض می‌شوند.')
        );
        $form->addInput($wordFilters);

        // (۲.۲.۰) تنظیمات «پیام خصوصی» و «تیکر خبری announce-bar» حذف شد.
        // پیام خصوصی در نسخه‌های پیشین باگ داشت و قرار است در نسخهٔ بعدی
        // به‌صورت یک افزونه/پلاگین جداگانه که از طریق هوک‌ها به انجمن
        // متصل می‌شود، بازنویسی شود. تیکر خبری نیز حذف شد.
        // هوک‌های مربوطه (loginSuccess، onFinishRegister، onAdminBegin،
        // headerInject و factory‌های اعلان/پیام) همچنان فعال‌اند تا پلاگین
        // جدید بتواند به آن‌ها متصل شود.

        // ---------------- کنترل دسترسی کاربران عادی (۲.۱.۰) ----------------

        $redirectRegularUsers = new \Typecho\Widget\Helper\Form\Element\Radio(
            'redirectRegularUsers',
            ['1' => _t('بله، کاربر عادی پس از ورود/ثبت‌نام به انجمن برود'), '0' => _t('خیر، رفتار پیش‌فرض TypeRenew')],
            '1',
            _t('ریدایرکت پس از ورود'),
            _t('فقط پس از ورود یا ثبت‌نام: کاربر عادی (subscriber) به جای پنل مدیریت، به صفحهٔ پروفایل انجمن یا ایندکس سایت هدایت می‌شود. این گزینه فقط مقصد پس از ورود را تغییر می‌دهد و اگر کاربر عادی مستقیماً نشانی پنل مدیریت را وارد کند، توسط گزینهٔ بعدی مسدود می‌شود.')
        );
        $form->addInput($redirectRegularUsers);

        $blockAdminAccess = new \Typecho\Widget\Helper\Form\Element\Radio(
            'blockAdminAccess',
            ['1' => _t('بله، کاربر عادی اجازهٔ ورود مستقیم به پنل مدیریت را نداشته باشد'), '0' => _t('خیر، رفتار پیش‌فرض TypeRenew')],
            '1',
            _t('مسدود کردن دسترسی مستقیم به پنل مدیریت'),
            _t('اگر کاربر عادی از قبل وارد شده و نشانی پنل مدیریت (/admin/) را مستقیماً باز کند، به صفحهٔ پروفایل انجمن بازگردانده می‌شود. این گزینه مکمل گزینهٔ قبلی است: آن یکی پس از ورود، این یکی در هر تلاش بعدی برای دسترسی به پنل مدیریت.')
        );
        $form->addInput($blockAdminAccess);

        $regularRedirectTarget = new \Typecho\Widget\Helper\Form\Element\Select(
            'regularRedirectTarget',
            [
                'forum_profile' => _t('صفحهٔ پروفایل کاربر در انجمن'),
                'forum_index'   => _t('ایندکس انجمن (/forum)'),
                'site_index'    => _t('ایندکس سایت (صفحهٔ اصلی)'),
            ],
            'forum_profile',
            _t('مقصد ریدایرکت کاربر عادی'),
            _t('پس از ورود/ثبت‌نام یا تلاش برای دسترسی به پنل مدیریت، کاربر عادی به این نشانی منتقل می‌شود.')
        );
        $form->addInput($regularRedirectTarget);
    }

    /**
     * حالت تأیید پیش از انتشار.
     *
     * @return string  یکی از 'off'، 'guests' یا 'all'
     */
    public static function moderationMode(): string
    {
        $mode = (string) self::opt('moderationMode', 'guests');
        if (!in_array($mode, ['off', 'guests', 'all'], true)) {
            $mode = 'guests';
        }
        return $mode;
    }

    /**
     * آیا این ارسال باید قبل از انتشار به تأیید مدیر برسد؟
     *
     * @param bool $isLoggedIn   آیا کاربر واردشده است؟
     * @param bool $isPrivileged آیا کاربر دسترسی ویراستار یا بالاتر دارد (یا مالک انجمن است)؟
     * @return bool
     */
    public static function shouldHoldForModeration(bool $isLoggedIn, bool $isPrivileged): bool
    {
        $mode = self::moderationMode();
        if ($mode === 'off') {
            return false;
        }
        if ($isPrivileged) {
            return false;
        }
        if ($mode === 'all') {
            return true;
        }
        // 'guests' — فقط مهمان‌ها
        return !$isLoggedIn;
    }

    public static function personalConfig(\Typecho\Widget\Helper\Form $form)
    {
    }

    // ====================================================================
    //  ابزارهای مشترک
    // ====================================================================

    /**
     * خواندن تنظیمات افزونه با مقدار پیش‌فرض
     */
    public static function opt(string $key, $default = '')
    {
        try {
            $options = Options::alloc()->plugin('Forum');
            $value = $options->{$key};
            return ($value === null || $value === '') ? $default : $value;
        } catch (\Throwable $e) {
            return $default;
        }
    }

    /** خواندن مقدار یک ردیف از جدول options (متن) */
    public static function readOptionValue(string $name): string
    {
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('value')->from('table.options')
                    ->where('name = ?', $name)->limit(1)
            );
            return (string) ($row['value'] ?? '');
        } catch (\Throwable $e) {
            return '';
        }
    }

    /** نوشتن یک ردیف در جدول options (upsert) */
    public static function writeOptionValue(string $name, string $value): void
    {
        try {
            $db = Db::get();
            $exists = $db->fetchRow(
                $db->select('name')->from('table.options')
                    ->where('name = ?', $name)->limit(1)
            );
            if ($exists) {
                $db->query($db->update('table.options')->rows(['value' => $value])->where('name = ?', $name));
            } else {
                $db->query($db->insert('table.options')->rows(['name' => $name, 'value' => $value, 'user' => 0]));
            }
        } catch (\Throwable $e) {
        }
    }

    /** حذف یک ردیف از جدول options */
    public static function deleteOptionValue(string $name): void
    {
        try {
            $db = Db::get();
            $db->query($db->delete('table.options')->where('name = ?', $name));
        } catch (\Throwable $e) {
        }
    }

    // ------------------------------------------------------------------
    //  مالک انجمن و مجوزها
    // ------------------------------------------------------------------

    /** uid مالک انجمن (۰ = نامعلوم) */
    public static function ownerUid(): int
    {
        return max(0, (int) self::readOptionValue(self::OWNER_OPTION));
    }

    /** شکل آرایهٔ نوشتهٔ پشتیبان برای سازگاری قالب‌ها (استفادهٔ داخلی) */
    public static function forumPostArray(): array
    {
        return [
            'cid'          => 0,
            'authorId'     => self::ownerUid(),
            'allowComment' => self::allowPost() ? 1 : 0,
            'status'       => 'hidden',
            'title'        => (string) self::opt('forumTitle', 'انجمن پرسش و پاسخ'),
        ];
    }

    /** آیا ارسال پرسش/پاسخ باز است؟ (تنظیم نسخهٔ ۲ — جایگزین بستن دیدگاه‌های نوشتهٔ پشتیبان) */
    public static function allowPost(): bool
    {
        return self::opt('allowPost', '1') !== '0';
    }

    /** آیا بازدیدکنندهٔ فعلی اجازهٔ قفل/سنجاق/ویرایش دیگران و مدیریت انجمن را دارد؟ */
    public static function canManage(): bool
    {
        try {
            $user = User::alloc();
            if ($user->pass('editor', true)) {
                return true;
            }
            if ($user->hasLogin()) {
                $owner = self::ownerUid();
                if ($owner > 0 && $owner === (int) $user->uid) {
                    return true;
                }
            }
        } catch (\Throwable $e) {
            // بدون کاربر واردشده
        }
        return false;
    }

    /** نشانی پنل مدیریت انجمن در پیشخوان */
    public static function adminPanelUrl(): string
    {
        try {
            return Helper::url('Forum/Panel.php');
        } catch (\Throwable $e) {
            return '';
        }
    }

    /** نشانی یک فایل استاتیک افزونه */
    public static function assetUrl(string $path): string
    {
        try {
            $base = rtrim((string) Options::alloc()->pluginUrl, '/') . '/Forum';
            return $base . '/' . ltrim($path, '/');
        } catch (\Throwable $e) {
            return $path;
        }
    }

    /**
     * نسخهٔ کش‌شکن یک فایل استاتیک (۲.۰.۰)
     *
     * VERSION + زمان آخرین تغییر فایل — اگر حتی شمارهٔ نسخه بین دو
     * انتشار تکرار شود، تغییر خودِ فایل نشانی را عوض می‌کند و
     * مرورگر مجبور به دریافت نسخهٔ تازه می‌شود.
     */
    public static function assetVer(string $path): string
    {
        $file = __DIR__ . '/' . ltrim($path, '/');
        $suffix = '';
        if (is_file($file)) {
            $mtime = (int) @filemtime($file);
            if ($mtime > 0) {
                // مبنای ۳۶ برای کوتاهی
                $suffix .= '.' . base_convert((string) $mtime, 10, 36);
            }
        }
        return self::VERSION . $suffix;
    }

    /**
     * رنگ سفارشی سربرگ انجمن (۲.۰.۰) — رشتهٔ امن CSS یا '' (پیروی از پوسته)
     *
     * مقدار به‌صورت inline روی --qa-grad نشسته و همهٔ اجزای سربرگ از
     * همان توکن می‌خوانند؛ فقط الگوهای رایج و امن پذیرفته می‌شود.
     */
    public static function headerColor(): string
    {
        $raw = trim((string) self::opt('headerColor', ''));
        if ($raw === '') {
            return '';
        }

        // هگز (#rgb / #rrggbb / #rrggbbaa)
        if (preg_match('~^#[0-9a-fA-F]{3,8}$~', $raw)) {
            return strtolower($raw);
        }

        // توابع رنگ/گرادیان با آرگومان‌های امن (رقم، درصد، کاما، فاصله، نقطه، #hex، کلمات رنگی)
        if (preg_match('~^(linear-gradient|radial-gradient|rgb|rgba|hsl|hsla)\(\s*[0-9a-zA-Z#%.,\s()/+-]+\)$~', $raw)) {
            // کاراکترهای خطرناک احتمالی رد می‌شوند چون در الگو نیستند
            return $raw;
        }

        // نام رنگ ساده (red، teal، …)
        if (preg_match('~^[a-zA-Z]{3,32}$~', $raw)) {
            return $raw;
        }

        return '';
    }

    /** نشانی اکشن مدیریت پنل (با توکن اختیاری) */
    public static function adminActionUrl(string $do = ''): string
    {
        $path = '/action/forum-admin';
        if ($do !== '') {
            $path .= '?do=' . rawurlencode($do);
        }
        return \Typecho\Common::url($path, (string) Options::alloc()->index);
    }

    // ------------------------------------------------------------------
    //  نشانی‌ها
    // ------------------------------------------------------------------

    /** نشانی فهرست انجمن */
    public static function forumUrl(): string
    {
        return Router::url(self::ROUTE_LIST, [], Options::alloc()->index);
    }

    /** نشانی صفحهٔ پرسش */
    public static function threadUrl(int $coid): string
    {
        return Router::url(self::ROUTE_THREAD, ['coid' => $coid], Options::alloc()->index);
    }

    /** نشانی صفحهٔ پروفایل یک عضو */
    public static function profileUrl(int $uid): string
    {
        try {
            return Router::url(self::ROUTE_PROFILE, ['uid' => $uid], Options::alloc()->index);
        } catch (\Throwable $e) {
            return self::forumUrl();
        }
    }

    /** نشانی صفحهٔ ویرایش پروفایل یک عضو (۲.۱.۰) */
    public static function profileEditUrl(int $uid): string
    {
        try {
            return Router::url(self::ROUTE_PROFILE_EDIT, ['uid' => $uid], Options::alloc()->index);
        } catch (\Throwable $e) {
            return self::profileUrl($uid);
        }
    }

    /** نشانی صفحهٔ پیام‌های خصوصی (۲.۱.۰) */
    public static function messagesUrl(string $box = 'inbox'): string
    {
        try {
            $base = Router::url(self::ROUTE_MESSAGES, [], Options::alloc()->index);
            if ($box === 'sent') {
                return $base . '?box=sent';
            }
            if ($box === 'blocked') {
                return $base . '?box=blocked';
            }
            return $base;
        } catch (\Throwable $e) {
            return self::forumUrl();
        }
    }

    /** نشانی صفحهٔ compose پیام خصوصی (۲.۱.۰) */
    public static function messageComposeUrl(?int $toUid = null): string
    {
        try {
            $url = Router::url(self::ROUTE_MESSAGE_COMPOSE, [], Options::alloc()->index);
            if ($toUid !== null && $toUid > 0) {
                $url .= '?to=' . (int) $toUid;
            }
            return $url;
        } catch (\Throwable $e) {
            return self::messagesUrl();
        }
    }

    /** نشانی مشاهدهٔ یک پیام خصوصی (۲.۱.۰) */
    public static function messageViewUrl(int $messageId): string
    {
        try {
            return Router::url(self::ROUTE_MESSAGE_VIEW, ['id' => $messageId], Options::alloc()->index);
        } catch (\Throwable $e) {
            return self::messagesUrl();
        }
    }

    /**
     * نشانی صفحهٔ مستقل اعلان‌ها (۲.۳.۰) — /forum/notifications
     *
     * مسیر فقط هنگام فعال‌سازی افزونه در جدول مسیرها ثبت می‌شود؛ اگر
     * فایل افزونه بدون فعال‌سازی مجدد جایگزین شده باشد و مسیر هنوز
     * ثبت نشده باشد (Router::url مقدار «#» برمی‌گرداند)، به‌عنوان
     * رفتار ایمن به فهرست انجمن برمی‌گردیم تا پیوند مرده رندر نشود.
     */
    public static function notificationsUrl(): string
    {
        try {
            $url = Router::url(self::ROUTE_NOTIFICATIONS, [], Options::alloc()->index);
            if ($url === '#' || $url === '') {
                return self::forumUrl();
            }
            return $url;
        } catch (\Throwable $e) {
            return self::forumUrl();
        }
    }

    /**
     * آیا پیام خصوصی فعال است؟
     *
     * ۲.۲.۰ — پیام خصوصی به‌طور پیش‌فرض خاموش است. این متد اکنون همیشه false
     * برمی‌گرداند چون سیستم پیام خصوصی قدیمی باگ داشت و قرار است در نسخهٔ
     * بعدی به‌صورت یک افزونهٔ جداگانه بازنویسی و از طریق هوک‌ها به انجمن
     * متصل شود. کد قدیمی همچنان در فایل باقی مانده تا افزونهٔ جدید بتواند
     * در صورت نیاز به ارجاع/بازنویسی دسترسی داشته باشد، ولی مسیرهای
     * عمومی پیام خصوصی (messages/compose) اکنون ۴۰۴ برمی‌گردانند.
     */
    public static function pmEnabled(): bool
    {
        return false;
    }

    /** سقف صندوق پیام هر کاربر (۲.۱.۰) — اکنون بدون استفاده (PM غیرفعال) */
    public static function pmInboxLimit(): int
    {
        $n = (int) self::opt('pmInboxLimit', '50');
        return max(5, min(500, $n));
    }

    /** آیا کاربر فعلی به پنل مدیریت سایت دسترسی دارد؟ (۲.۱.۰)
     *  مدیر کل، ویراستار و نویسنده — یعنی نقش‌های contributor و بالاتر.
     */
    public static function canAccessAdminPanel(): bool
    {
        try {
            $user = User::alloc();
            if (!$user->hasLogin()) {
                return false;
            }
            return $user->pass('contributor', true);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** آیا کاربر فعلی یک کاربر عادی (subscriber و پایین‌تر) است؟ (۲.۱.۰) */
    public static function isRegularUser(): bool
    {
        try {
            $user = User::alloc();
            if (!$user->hasLogin()) {
                return false;
            }
            return !$user->pass('contributor', true);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** آیا ریدایرکت کاربر عادی پس از ورود فعال است؟ (۲.۱.۰) */
    public static function redirectRegularUsersEnabled(): bool
    {
        return self::opt('redirectRegularUsers', '1') !== '0';
    }

    /** آیا مسدود کردن دسترسی کاربر عادی به پنل مدیریت فعال است؟ (۲.۱.۰) */
    public static function blockAdminAccessEnabled(): bool
    {
        return self::opt('blockAdminAccess', '1') !== '0';
    }

    /** مقصد ریدایرکت کاربر عادی (۲.۱.۰) */
    public static function regularRedirectTargetUrl(?int $uid = null): string
    {
        $target = (string) self::opt('regularRedirectTarget', 'forum_profile');
        if ($target === 'site_index') {
            try {
                return (string) Options::alloc()->siteUrl;
            } catch (\Throwable $e) {
                return self::forumUrl();
            }
        }
        if ($target === 'forum_index') {
            return self::forumUrl();
        }
        // forum_profile
        if ($uid === null || $uid < 1) {
            try {
                $user = User::alloc();
                $uid = $user->hasLogin() ? (int) $user->uid : 0;
            } catch (\Throwable $e) {
                $uid = 0;
            }
        }
        return $uid > 0 ? self::profileUrl($uid) : self::forumUrl();
    }

    /** (۲.۲.۰) هوک Widget\Login::loginSuccess — ریدایرکت کاربر عادی به انجمن
     *  الگو: SiteProfile::onLoginSuccess
     *  پس از ورود موفق، اگر کاربر عادی باشد (contributor نیست)، به محیط
     *  کاربری انجمن هدایت می‌شود. مدیر/ویراستار/نویسنده رفتار پیش‌فرض را می‌بینند.
     */
    public static function onLoginSuccess($user, $name = '', $title = null, $remember = false): void
    {
        if (!self::redirectRegularUsersEnabled()) {
            return;
        }
        try {
            if (!self::isRegularUserObj($user)) {
                return;
            }
            $uid = (int) $user->uid;
            $user->response->redirect(self::regularRedirectTargetUrl($uid));
        } catch (\Throwable $e) {
            // در صورت خطا منطق پیش‌فرض هسته اجرا می‌شود
            error_log('Forum[login-redirect]: ' . $e->getMessage());
        }
    }

    /** (۲.۲.۰) هوک Widget\Register::finishRegister — ریدایرکت کاربر تازه‌ثبت‌نام‌شده
     *  این هوک پس از ثبت‌نام موفق و پیش از login() و redirect پیش‌فرض فراخوانی می‌شود.
     *  اگر کاربر تازه‌ثبت‌نام‌شده عادی باشد (contributor نیست)، به محیط کاربری
     *  انجمن هدایت می‌شود تا پنل مدیریت را نبیند.
     */
    public static function onFinishRegister($register): void
    {
        if (!self::redirectRegularUsersEnabled()) {
            return;
        }
        try {
            // $register شیء Widget\Register است؛ uid و group کاربر جدید در دسترس است.
            $uid = (int) ($register->uid ?? 0);
            $group = (string) ($register->group ?? 'subscriber');
            if ($uid < 1) {
                return;
            }
            // اگر گروه کاربر contributor یا بالاتر باشد، رفتار پیش‌فرض
            if (in_array($group, ['administrator', 'editor', 'contributor'], true)) {
                return;
            }
            // کاربر عادی → پیش از redirect، login() را خودمان فراخوانی می‌کنیم
            // چون Register.php خط 90 بعد از این هوک login می‌کند و ما با redirect
            // زودتر از آن جلوی ورود به adminUrl را می‌گیریم.
            $name = (string) ($register->name ?? '');
            $request = \Typecho\Request::getInstance();
            if ($name === '') {
                $name = (string) $request->get('name');
            }
            $password = (string) $request->get('password');
            if ($name !== '' && $password !== '') {
                try {
                    $user = User::alloc();
                    $user->login($name, $password);
                } catch (\Throwable $e) {
                    // اگر login ناموفق بود، redirect نمی‌کنیم
                    return;
                }
            }
            $register->response->redirect(self::regularRedirectTargetUrl($uid));
        } catch (\Throwable $e) {
            error_log('Forum[register-redirect]: ' . $e->getMessage());
        }
    }

    /**
     * بررسی اینکه آیا شیء داده‌شده یک کاربر واردشدهٔ عادی است.
     * (الگوی SiteProfile::isRegular — سازگار با Widget\User و Widget\Login)
     */
    private static function isRegularUserObj($user): bool
    {
        if (!$user instanceof User) {
            return false;
        }
        if (!$user->hasLogin()) {
            return false;
        }
        // pass('contributor', true) → اگر کاربر contributor یا بالاتر باشد true برمی‌گرداند.
        // ما کاربر عادی را می‌خواهیم → false برمی‌گرداند.
        return !$user->pass('contributor', true);
    }

    /** (۲.۱۱.۰) هوک admin/common.php::begin — کاربر عادی را از پنل مدیریت دور می‌کند */
    public static function onAdminBegin(): void
    {
        if (!self::blockAdminAccessEnabled()) {
            return;
        }
        try {
            $user = User::alloc();
            if (!$user->hasLogin()) {
                return; // مهمان → هسته خودش به صفحهٔ ورود می‌فرستد
            }
            if ($user->pass('contributor', true)) {
                return; // نقش‌های بالاتر مجازند
            }
            // صفحات عمومی که نباید قفل شوند
            $script = strtolower(basename((string) ($_SERVER['SCRIPT_NAME'] ?? '')));
            $publicPages = ['login.php', 'register.php', 'forgot.php', 'reset.php'];
            if (in_array($script, $publicPages, true)) {
                return;
            }
            $uid = (int) $user->uid;
            $user->response->redirect(self::regularRedirectTargetUrl($uid));
        } catch (\Throwable $e) {
            // بی‌اثر
        }
    }

    /** آیا کاربر فعلی مدیر کل (administrator) سایت است؟ (۲.۱.۰) */
    public static function isAdministrator(): bool
    {
        try {
            $user = User::alloc();
            if (!$user->hasLogin()) {
                return false;
            }
            return $user->pass('administrator', true);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** نشانی پنل مدیریت سایت (مدیریت TypeRenew) — مسیر استاندارد /admin/ */
    public static function siteAdminUrl(): string
    {
        try {
            return (string) Options::alloc()->adminUrl;
        } catch (\Throwable $e) {
            return '';
        }
    }

    /** آیا صفحهٔ پروفایل اعضا فعال است؟ */
    public static function profileEnabled(): bool
    {
        return self::opt('showProfilePage', '1') !== '0';
    }

    /** نشانی اکشن ثبت پرسش/پاسخ و مدیریت قفل/سنجاق/ویرایش */
    public static function postUrl(): string
    {
        return Router::url('do', ['action' => self::ACTION_NAME], Options::alloc()->index);
    }

    /** گریز امن خروجی */
    public static function e($str): string
    {
        return htmlspecialchars((string) $str, ENT_QUOTES, 'UTF-8');
    }

    /** تبدیل ارقام به فارسی */
    public static function faDigits($str): string
    {
        return strtr((string) $str, [
            '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
            '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹'
        ]);
    }

    /** خروجی JSON و پایان اجرا — پیش از هر خروجی صفحه */
    public static function jsonOut(array $payload): void
    {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        echo json_encode($payload, JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ------------------------------------------------------------------
    //  آواتار (گراواتار + جایگزین حرف اول)
    // ------------------------------------------------------------------

    /** آیا نمایش گراواتار فعال است؟ */
    public static function gravatarEnabled(): bool
    {
        return self::opt('gravatar', '1') !== '0';
    }

    /** نشانی تصویر گراواتار برای یک ایمیل */
    public static function gravatarUrl(string $mail, int $size = 96): string
    {
        $base = trim((string) self::opt('gravatarServer', 'https://secure.gravatar.com/avatar'));
        $base = rtrim($base, '/');
        if (!preg_match('~^https?://~i', $base) || mb_strlen($base) > 200) {
            $base = 'https://secure.gravatar.com/avatar';
        }

        $hash = md5(strtolower(trim($mail)));

        return $base . '/' . $hash . '?s=' . max(16, min(256, $size)) . '&d=404&r=g';
    }

    /**
     * آواتار کاربر: تصویر گراواتار روی زمینهٔ رنگی حرف اول نام.
     * اگر گراواتار در دسترس نباشد یا ایمیل نباشد، همان حرف اول رنگی
     * (بدون هیچ درخواست بیرونی) نمایش داده می‌شود — تعویض از سمت JS
     * با حذف تصویرِ خطاخورده انجام می‌شود.
     */
    public static function avatar(string $name, string $mail = ''): string
    {
        $name = trim($name);
        $initial = mb_substr($name !== '' ? $name : '؟', 0, 1);
        $hue = abs(crc32(mb_strtolower($name))) % 360;

        $img = '';
        if (self::gravatarEnabled() && trim($mail) !== '') {
            $img = '<img class="qa-grava" src="' . self::e(self::gravatarUrl($mail, 96)) . '" alt="" '
                . 'width="42" height="42" loading="lazy" decoding="async" referrerpolicy="no-referrer">';
        }

        return '<span class="qa-avatar" style="--ava-h:' . $hue . '" aria-hidden="true">'
            . self::e($initial) . $img . '</span>';
    }

    // ------------------------------------------------------------------
    //  گروه کاربری و بج‌ها
    // ------------------------------------------------------------------

    /**
     * گروه کاربری یک نویسنده.
     * برمی‌گرداند: 'administrator'، 'editor'، 'subscriber'، … یا '' برای مهمان/نامعلوم.
     * کش‌شده در طول درخواست.
     */
    public static function userGroup(int $authorId): string
    {
        if ($authorId < 1) {
            return '';
        }

        static $cache = [];
        if (isset($cache[$authorId])) {
            return $cache[$authorId];
        }

        $cache[$authorId] = '';
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('group')->from('table.users')
                    ->where('uid = ?', $authorId)
                    ->limit(1)
            );
            if (!empty($row['group'])) {
                $cache[$authorId] = (string) $row['group'];
            }
        } catch (\Throwable $e) {
            // در دسترس نیست
        }
        return $cache[$authorId];
    }

    /** آیا این نویسنده مدیر اصلی (administrator) است؟ — برای بج «رسمی» */
    public static function isOfficialAuthor(int $authorId): bool
    {
        return self::userGroup($authorId) === 'administrator';
    }

    /** آیا این نویسنده عضو عادی (subscriber) است؟ — برای بج «عضو» */
    public static function isMemberAuthor(int $authorId): bool
    {
        $g = self::userGroup($authorId);
        return $g !== '' && $g !== 'administrator';
    }

    /**
     * بج «رسمی» برای مدیر اصلی — آیکون Lucide «badge-check».
     * رنگ از --qa-accent می‌آید. رشتهٔ خالی برای غیرمدیران.
     */
    public static function officialBadge(int $authorId): string
    {
        if (!self::isOfficialAuthor($authorId)) {
            return '';
        }
        return '<span class="qa-official-badge" data-tooltip="مدیر اصلی انجمن (رسمی)" aria-label="مدیر اصلی انجمن (رسمی)">'
            . '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor"'
            . ' stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
            . '<path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"></path>'
            . '<path d="m9 12 2 2 4-4"></path>'
            . '</svg></span>';
    }

    /**
     * بج «عضو» سبز برای کاربران عضو غیرمدیر.
     * رشتهٔ خالی برای مدیران/مهمانان.
     */
    public static function memberBadge(int $authorId): string
    {
        if (!self::isMemberAuthor($authorId)) {
            return '';
        }
        return '<span class="qa-member-badge" data-tooltip="عضو انجمن" aria-label="عضو انجمن">'
            . '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor"'
            . ' stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
            . '<path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"></path>'
            . '<path d="m9 12 2 2 4-4"></path>'
            . '</svg></span>';
    }

    /** بج مناسب هر نویسنده: رسمی برای مدیر، عضو برای بقیه، خالی برای مهمان */
    public static function authorBadge(int $authorId): string
    {
        $b = self::officialBadge($authorId);
        if ($b !== '') {
            return $b;
        }
        return self::memberBadge($authorId);
    }

    /** پیوند (یا متن ساده) نام نویسنده — عضوها به پروفایل‌شان می‌روند */
    public static function authorLink(array $row): string
    {
        $name = trim((string) ($row['author'] ?? ''));
        if ($name === '') {
            $name = '؟';
        }

        $uid = (int) ($row['authorId'] ?? 0);
        if ($uid > 0 && self::profileEnabled()) {
            return '<a class="qa-author-link" href="' . self::e(self::profileUrl($uid)) . '">'
                . self::e($name) . '</a>';
        }

        return '<span class="qa-author-link">' . self::e($name) . '</span>';
    }

    /**
     * فهرست آخرین اعضای عضو‌شده — برای ویجت «آخرین اعضا» در سایدبار.
     */
    public static function latestMembers(int $limit = 8): array
    {
        $limit = max(1, min(50, $limit));
        $out = [];
        try {
            $db = Db::get();
            $rows = $db->fetchAll(
                $db->select('uid', 'name', 'screenName', 'mail', 'created')
                    ->from('table.users')
                    ->order('created', Db::SORT_DESC)
                    ->limit($limit)
            );
            foreach ($rows as $r) {
                $uid = (int) $r['uid'];
                $name = trim((string) ($r['screenName'] ?: $r['name']));
                if ($name === '') {
                    $name = 'عضو #' . $uid;
                }
                $out[] = [
                    'uid'        => $uid,
                    'name'       => $name,
                    'mail'       => (string) $r['mail'],
                    'created'    => (int) $r['created'],
                    'profileUrl' => self::profileUrl($uid),
                    'group'      => self::userGroup($uid),
                ];
            }
        } catch (\Throwable $e) {
            // در دسترس نیست
        }
        return $out;
    }

    // ====================================================================
    //  لایهٔ داده — پرسش‌ها (forum_topics)
    // ====================================================================

    /**
     * تبدیل ردیف جدول forum_topics به شکل دیدگاه‌گونهٔ قالب‌ها
     * (حفظ کلیدهای coid/parent/author/... تا هیچ ویویی تغییر نکند).
     * (۲.۱.۰) اگر author_id > 0، نام/ایمیل/وب زنده از جدول users خوانده می‌شود
     * تا تغییرات پروفایل بلافاصله در انجمن منعکس شود.
     */
    public static function topicRowToLegacy(array $r): array
    {
        $liveUser = self::liveUserFields((int) ($r['author_id'] ?? 0));
        return [
            'coid'      => (int) $r['id'],
            'cid'       => 0,
            'parent'    => 0,
            'type'      => 'comment',
            'author'    => $liveUser !== null ? $liveUser['name'] : (string) ($r['author_name'] ?? ''),
            'mail'      => $liveUser !== null ? $liveUser['mail'] : (string) ($r['author_mail'] ?? ''),
            'url'       => $liveUser !== null ? $liveUser['url'] : (string) ($r['author_url'] ?? ''),
            'ip'        => (string) ($r['author_ip'] ?? ''),
            'agent'     => (string) ($r['author_agent'] ?? ''),
            'authorId'  => (int) ($r['author_id'] ?? 0),
            'ownerId'   => self::ownerUid(),
            'status'    => (string) ($r['status'] ?? 'approved'),
            'created'   => (int) ($r['created'] ?? 0),
            'modified'  => (int) ($r['modified'] ?? 0),
            'text'      => (string) ($r['text'] ?? ''),
            'views'     => (int) ($r['views'] ?? 0),
            // فیلدهای مستقیم جدید (برای پنل و منطق داخلی)
            'id'         => (int) $r['id'],
            'title'      => (string) ($r['title'] ?? ''),
            'categoryId' => (int) ($r['category_id'] ?? 0),
            'is_locked'  => (int) ($r['is_locked'] ?? 0),
            'is_pinned'  => (int) ($r['is_pinned'] ?? 0),
            'is_tracked' => (int) ($r['is_tracked'] ?? 0),
            'is_hidden'  => (int) ($r['is_hidden'] ?? 0),
            'best_post_id' => (int) ($r['best_post_id'] ?? 0),
        ];
    }

    /**
     * تبدیل ردیف جدول forum_posts به شکل دیدگاه‌گونهٔ قالب‌ها.
     * (۲.۱.۰) اگر author_id > 0، نام/ایمیل/وب زنده از جدول users خوانده می‌شود.
     */
    public static function postRowToLegacy(array $r): array
    {
        $liveUser = self::liveUserFields((int) ($r['author_id'] ?? 0));
        return [
            'coid'      => (int) $r['id'],
            'cid'       => 0,
            'parent'    => (int) ($r['topic_id'] ?? 0),
            'type'      => 'comment',
            'author'    => $liveUser !== null ? $liveUser['name'] : (string) ($r['author_name'] ?? ''),
            'mail'      => $liveUser !== null ? $liveUser['mail'] : (string) ($r['author_mail'] ?? ''),
            'url'       => $liveUser !== null ? $liveUser['url'] : (string) ($r['author_url'] ?? ''),
            'ip'        => (string) ($r['author_ip'] ?? ''),
            'agent'     => (string) ($r['author_agent'] ?? ''),
            'authorId'  => (int) ($r['author_id'] ?? 0),
            'ownerId'   => self::ownerUid(),
            'status'    => (string) ($r['status'] ?? 'approved'),
            'created'   => (int) ($r['created'] ?? 0),
            'modified'  => (int) ($r['modified'] ?? 0),
            'text'      => (string) ($r['text'] ?? ''),
            // فیلدهای مستقیم جدید
            'id'        => (int) $r['id'],
            'topic_id'  => (int) ($r['topic_id'] ?? 0),
        ];
    }

    /** کش ردیف‌های پرسش‌ها در طول درخواست */
    private static array $topicCache = [];

    /** یک پرسش بر اساس شناسه — یا null (کش‌شده در طول درخواست) */
    public static function topicById(int $id): ?array
    {
        if ($id < 1) {
            return null;
        }
        if (array_key_exists($id, self::$topicCache)) {
            return self::$topicCache[$id];
        }
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select()->from('table.forum_topics')
                    ->where('id = ?', $id)->limit(1)
            );
            return self::$topicCache[$id] = ($row ?: null);
        } catch (\Throwable $e) {
            return self::$topicCache[$id] = null;
        }
    }

    /** یک پرسش (به شکل قالب) بر اساس شناسه — یا null */
    public static function topicForView(int $id): ?array
    {
        $row = self::topicById($id);
        return $row ? self::topicRowToLegacy($row) : null;
    }

    /** یک پاسخ بر اساس شناسه — یا null */
    public static function postById(int $id): ?array
    {
        if ($id < 1) {
            return null;
        }
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select()->from('table.forum_posts')
                    ->where('id = ?', $id)->limit(1)
            );
            return $row ?: null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** یک پاسخ (به شکل قالب) بر اساس شناسه — یا null */
    public static function postForView(int $id): ?array
    {
        $row = self::postById($id);
        return $row ? self::postRowToLegacy($row) : null;
    }

    /**
     * پاسخ‌های یک پرسش — مرتب بر اساس زمان ساخت.
     * $status: 'approved' | 'waiting' | null (همه)
     */
    public static function postsForTopic(int $topicId, ?string $status = null): array
    {
        $out = [];
        try {
            $db = Db::get();
            $select = $db->select()->from('table.forum_posts')
                ->where('topic_id = ?', $topicId)
                ->order('created', Db::SORT_ASC);
            if ($status !== null) {
                $select->where('status = ?', $status);
            }
            $rows = $db->fetchAll($select);
            foreach ($rows as $r) {
                $out[] = self::postRowToLegacy($r);
            }
        } catch (\Throwable $e) {
        }
        return $out;
    }

    // ------------------------------------------------------------------
    //  وضعیت پرسش‌ها: قفل / سنجاق / پیگیری / پنهان / بهترین پاسخ
    //  (اکنون ستون‌هایی روی خود جدول forum_topics — نه ردیف‌های options)
    // ------------------------------------------------------------------

    /** پاک‌کردن کش ردیف پرسش پس از تغییر (قفل/سنجاق/حذف/…) */
    public static function invalidateTopicCache(int $id): void
    {
        unset(self::$topicCache[$id]);
    }

    /** مقدار یک ستون بولینی یک پرسش */
    private static function topicFlag(int $coid, string $column): int
    {
        $row = self::topicById($coid);
        return $row ? (int) ($row[$column] ?? 0) : 0;
    }

    /** تنظیم یک ستون بولینی یک پرسش */
    private static function setTopicFlag(int $coid, string $column, int $value): void
    {
        try {
            $db = Db::get();
            $db->query(
                $db->update('table.forum_topics')
                    ->rows([$column => $value ? 1 : 0])
                    ->where('id = ?', $coid)
            );
        } catch (\Throwable $e) {
        }
        self::invalidateTopicCache($coid);
    }

    /** آیا پرسشی قفل شده است؟ */
    public static function isLocked(int $coid): bool
    {
        return self::topicFlag($coid, 'is_locked') === 1;
    }

    /** قفل کردن یک پرسش */
    public static function lockThread(int $coid): void
    {
        self::setTopicFlag($coid, 'is_locked', 1);
    }

    /** بازکردن قفل یک پرسش */
    public static function unlockThread(int $coid): void
    {
        self::setTopicFlag($coid, 'is_locked', 0);
    }

    /** آیا پرسشی سنجاق شده است؟ */
    public static function isPinned(int $coid): bool
    {
        return self::topicFlag($coid, 'is_pinned') === 1;
    }

    /** سنجاق کردن یک پرسش */
    public static function pinThread(int $coid): void
    {
        self::setTopicFlag($coid, 'is_pinned', 1);
    }

    /** برداشتن سنجاق یک پرسش */
    public static function unpinThread(int $coid): void
    {
        self::setTopicFlag($coid, 'is_pinned', 0);
    }

    /** فهرست شناسهٔ پرسش‌های سنجاق‌شده */
    public static function pinnedIds(): array
    {
        try {
            $db = Db::get();
            $rows = $db->fetchAll(
                $db->select('id')->from('table.forum_topics')->where('is_pinned = 1')
            );
            return array_map(static fn ($r) => (int) $r['id'], $rows);
        } catch (\Throwable $e) {
            return [];
        }
    }

    /** فهرست شناسهٔ پرسش‌های قفل‌شده */
    public static function lockedIds(): array
    {
        try {
            $db = Db::get();
            $rows = $db->fetchAll(
                $db->select('id')->from('table.forum_topics')->where('is_locked = 1')
            );
            return array_map(static fn ($r) => (int) $r['id'], $rows);
        } catch (\Throwable $e) {
            return [];
        }
    }

    /** فهرست شناسهٔ پرسش‌های «در حال پیگیری» */
    public static function trackedIds(): array
    {
        try {
            $db = Db::get();
            $rows = $db->fetchAll(
                $db->select('id')->from('table.forum_topics')->where('is_tracked = 1')
            );
            return array_map(static fn ($r) => (int) $r['id'], $rows);
        } catch (\Throwable $e) {
            return [];
        }
    }

    /** آیا پرسشی «در حال پیگیری» است؟ */
    public static function isTracked(int $coid): bool
    {
        return self::topicFlag($coid, 'is_tracked') === 1;
    }

    /** فعال‌کردن «در حال پیگیری» یک پرسش */
    public static function trackThread(int $coid): void
    {
        self::setTopicFlag($coid, 'is_tracked', 1);
    }

    /** برداشتن «در حال پیگیری» یک پرسش */
    public static function untrackThread(int $coid): void
    {
        self::setTopicFlag($coid, 'is_tracked', 0);
    }

    /** آیا پرسشی از دید مهمان پنهان است؟ */
    public static function isHidden(int $coid): bool
    {
        return self::topicFlag($coid, 'is_hidden') === 1;
    }

    /** پنهان‌کردن یک پرسش از دید مهمان */
    public static function hideThread(int $coid): void
    {
        self::setTopicFlag($coid, 'is_hidden', 1);
    }

    /** نمایش مجدد یک پرسش به مهمان */
    public static function unhideThread(int $coid): void
    {
        self::setTopicFlag($coid, 'is_hidden', 0);
    }

    /** فهرست شناسهٔ پرسش‌های پنهان از مهمان */
    public static function hiddenIds(): array
    {
        try {
            $db = Db::get();
            $rows = $db->fetchAll(
                $db->select('id')->from('table.forum_topics')->where('is_hidden = 1')
            );
            return array_map(static fn ($r) => (int) $r['id'], $rows);
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * آیا بازدیدکنندهٔ فعلی اجازهٔ دیدن این پرسش (که ممکن است پنهان‌شده باشد) را دارد؟
     * — مدیر/کاربر واردشده: همیشه بله
     * — مهمان: فقط اگر پرسش پنهان نیست
     */
    public static function canSee(int $coid): bool
    {
        try {
            $user = User::alloc();
            if ($user->hasLogin()) {
                return true;
            }
        } catch (\Throwable $e) {
            // بدون کاربر واردشده
        }
        return !self::isHidden($coid);
    }

    // ------------------------------------------------------------------
    //  بهترین پاسخ
    // ------------------------------------------------------------------

    /** شناسهٔ پاسخِ برگزیدهٔ یک پرسش (یا ۰) */
    public static function bestAnswerFor(int $questionCoid): int
    {
        return self::topicFlag($questionCoid, 'best_post_id');
    }

    /** آیا این پاسخ، بهترین پاسخِ پرسشِ خودش است؟ */
    public static function isBestAnswer(int $answerCoid): bool
    {
        $post = self::postById($answerCoid);
        if ($post === null) {
            return false;
        }
        $topic = self::topicById((int) $post['topic_id']);
        return $topic !== null && (int) ($topic['best_post_id'] ?? 0) === $answerCoid;
    }

    /** انتخاب بهترین پاسخ برای یک پرسش (و قفل خودکار پرسش) */
    public static function markBestAnswer(int $questionCoid, int $answerCoid): void
    {
        try {
            $db = Db::get();
            $db->query(
                $db->update('table.forum_topics')
                    ->rows(['best_post_id' => $answerCoid, 'is_locked' => 1])
                    ->where('id = ?', $questionCoid)
            );
        } catch (\Throwable $e) {
        }
        self::invalidateTopicCache($questionCoid);
    }

    /** برداشتن انتخاب بهترین پاسخ از یک پرسش (قفل باقی می‌ماند — مثل نسخهٔ قدیم) */
    public static function unmarkBestAnswer(int $questionCoid): void
    {
        self::setTopicFlag($questionCoid, 'best_post_id', 0);
    }

    // ------------------------------------------------------------------
    //  قفل خودکار پرسش‌های بی‌فعالیت
    // ------------------------------------------------------------------

    /** تعداد روزهای بدون فعالیت پیش از قفل خودکار (۰ = خاموش) */
    public static function autoLockDays(): int
    {
        $d = (int) self::opt('autoLockDays', '0');
        return max(0, min(365, $d));
    }

    /**
     * بررسی و اعمال قفل خودکار برای یک پرسش.
     * اگر آخرین فعالیت پرسش قدیمی‌تر از آستانه باشد و پرسش هنوز قفل
     * نشده باشد، قفل می‌شود. روش تنبل — بدون cron.
     */
    public static function checkAutoLock(int $coid, int $lastActivity): bool
    {
        $days = self::autoLockDays();
        if ($days < 1 || $coid < 1) {
            return false;
        }
        if (self::isLocked($coid)) {
            return false;
        }
        $threshold = time() - ($days * 86400);
        if ($lastActivity > 0 && $lastActivity < $threshold) {
            self::lockThread($coid);
            return true;
        }
        return false;
    }

    // ====================================================================
    //  دسته‌بندی‌ها — جدول forum_categories
    // ====================================================================

    /**
     * فهرست آیکون‌های Lucide مجاز برای دسته‌بندی‌ها.
     */
    public const CATEGORY_ICONS = [
        'folder'         => 'Folder',
        'book-open'      => 'BookOpen',
        'message-circle' => 'MessageCircle',
        'help-circle'    => 'HelpCircle',
        'briefcase'      => 'Briefcase',
        'users'          => 'Users',
        'shield'         => 'Shield',
        'monitor'        => 'Monitor',
        'smartphone'     => 'Smartphone',
        'code'           => 'Code',
        'cpu'            => 'Cpu',
        'wrench'         => 'Wrench',
        'bug'            => 'Bug',
        'trophy'         => 'Trophy',
        'globe'          => 'Globe',
        'file-text'      => 'FileText',
        'megaphone'      => 'Megaphone',
        'star'           => 'Star',
        'heart'          => 'Heart',
        'lightbulb'      => 'Lightbulb',
    ];

    /** مسیرهای SVG (داخل viewBox 0 0 24 24) برای هر آیکون دسته */
    public const CATEGORY_ICON_PATHS = [
        'folder'         => '<path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"></path>',
        'book-open'      => '<path d="M12 7v14"></path><path d="M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z"></path>',
        'message-circle' => '<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"></path>',
        'help-circle'    => '<circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path><line x1="12" y1="17" x2="12.01" y2="17"></line>',
        'briefcase'      => '<rect width="20" height="14" x="2" y="7" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path>',
        'users'          => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M22 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path>',
        'shield'         => '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path>',
        'monitor'        => '<rect width="20" height="14" x="2" y="3" rx="2"></rect><line x1="8" x2="16" y1="21" y2="21"></line><line x1="12" x2="12" y1="17" y2="21"></line>',
        'smartphone'     => '<rect width="14" height="20" x="5" y="2" rx="2" ry="2"></rect><path d="M12 18h.01"></path>',
        'code'           => '<polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline>',
        'cpu'            => '<rect width="16" height="16" x="4" y="4" rx="2"></rect><rect width="6" height="6" x="9" y="9" rx="1"></rect><path d="M15 2v2"></path><path d="M15 20v2"></path><path d="M2 15h2"></path><path d="M2 9h2"></path><path d="M20 15h2"></path><path d="M20 9h2"></path><path d="M9 2v2"></path><path d="M9 20v2"></path>',
        'wrench'         => '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>',
        'bug'            => '<path d="m8 2 1.88 1.88"></path><path d="M14.12 3.88 16 2"></path><path d="M9 7.13v-1a3.003 3.003 0 1 1 6 0v1"></path><path d="M12 20c-3.3 0-6-2.7-6-6v-3a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v3c0 3.3-2.7 6-6 6"></path><path d="M12 20v-9"></path><path d="M6.53 9C4.6 8.8 3 7.1 3 5"></path><path d="M6 13H2"></path><path d="M3 21c0-2.1 1.7-3.9 3.8-4"></path><path d="M20.97 5c0 2.1-1.6 3.8-3.5 4"></path><path d="M22 13h-4"></path><path d="M17.2 17c2.0.0 3.8 1.9 3.8 4"></path>',
        'trophy'         => '<path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"></path><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"></path><path d="M4 22h16"></path><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"></path><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"></path><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"></path>',
        'globe'          => '<circle cx="12" cy="12" r="10"></circle><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"></path><path d="M2 12h20"></path>',
        'file-text'      => '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"></path><path d="M14 2v4a2 2 0 0 0 2 2h4"></path><path d="M16 13H8"></path><path d="M16 17H8"></path><path d="M10 9H8"></path>',
        'megaphone'      => '<path d="m3 11 18-5v12L3 14v-3z"></path><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"></path>',
        'star'           => '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>',
        'heart'          => '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path>',
        'lightbulb'      => '<path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"></path><path d="M9 18h6"></path><path d="M10 22h4"></path>',
    ];

    /**
     * خروجی SVG یک آیکون دسته (یا آیکون پیش‌فرض Folder).
     *
     * (۲.۳.۰) پشتیبانی از ایموجی به‌عنوان آیکون دسته — بدون هیچ کتابخانه
     * یا تبدیلی، همان نویسهٔ ذخیره‌شده رندر می‌شود:
     *   - «lucide:code»     → آیکون Lucide با کلید code
     *   - «code»            → آیکون Lucide (کلید قدیمی — سازگاری با نسخه‌های قبل)
     *   - «😀» / «📚» / …  → همان ایموجی به‌صورت متن
     * مقدار نامعتبر یا خالی → آیکون پیش‌فرض Folder (رفتار قبلی حفظ شده).
     */
    public static function categoryIconSvg(string $icon, int $size = 14): string
    {
        $icon = trim($icon);
        // کلید Lucide — با یا بدون پیشوند «lucide:» (پیشوند جدید ۲.۳.۰)
        $lucideKey = $icon;
        if (str_starts_with($lucideKey, 'lucide:')) {
            $lucideKey = trim(substr($lucideKey, strlen('lucide:')));
        }
        if ($lucideKey !== '' && isset(self::CATEGORY_ICON_PATHS[$lucideKey])) {
            $path = self::CATEGORY_ICON_PATHS[$lucideKey];
            return '<svg viewBox="0 0 24 24" width="' . (int) $size . '" height="' . (int) $size
                . '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"'
                . ' stroke-linejoin="round" aria-hidden="true">' . $path . '</svg>';
        }
        // ایموجی؟ — فقط وقتی پیشوند lucide: ندارد؛ همان نویسه رندر می‌شود
        // (بدون تبدیل به تصویر/SVG). کلید ناشناختهٔ پیشونددار → Folder.
        if ($icon !== '' && !str_starts_with($icon, 'lucide:') && self::isCategoryEmoji($icon)) {
            return '<span class="qa-cat-emoji" style="font-size:' . max(10, (int) $size + 1) . 'px" aria-hidden="true">'
                . self::e($icon) . '</span>';
        }
        // پیش‌فرض — Folder (رفتار نسخه‌های قبل)
        $path = self::CATEGORY_ICON_PATHS['folder'];
        return '<svg viewBox="0 0 24 24" width="' . (int) $size . '" height="' . (int) $size
            . '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"'
            . ' stroke-linejoin="round" aria-hidden="true">' . $path . '</svg>';
    }

    /**
     * آیا مقدار آیکون یک ایموجی قابل‌نمایش است؟ (۲.۳.۰)
     *
     * ایموجی‌های مرکبی (پرچم، تُن پوست، ZWJ) تا ۲۴ نویسه مجازند؛ رشته‌های
     * بلندتر یا دارای نویسه‌های کنترلی/جداساز خط به‌عنوان ایموجی پذیرفته
     * نمی‌شوند تا چیدمان دسته‌ها به‌هم نریزد.
     */
    public static function isCategoryEmoji(string $icon): bool
    {
        $icon = trim($icon);
        if ($icon === '' || mb_strlen($icon) > 24) {
            return false;
        }
        // نویسه‌های کنترلی، خط جدید و تب — در ایموجی جایی ندارند
        if (preg_match('~[\x00-\x1f\x7f]|\s{2,}~u', $icon)) {
            return false;
        }
        // باید دست‌کم یک نویسه خارج از محدودهٔ ASCII داشته باشد
        // (متن سادهٔ انگلیسی/فارسی به‌عنوان آیکون پذیرفته نمی‌شود)
        if (preg_match('~^[\x00-\x7f]+$~', $icon)) {
            return false;
        }
        return true;
    }

    /**
     * آیا نام آیکون در فهرست مجاز هست؟ (۲.۳.۰ — ایموجی هم مجاز است)
     *
     * سازگاری کامل با نسخه‌های قبل: کلیدهای قدیمی (مثل code یا folder)
     * همچنان معتبرند؛ علاوه بر آن «lucide:*» و نویسهٔ ایموجی نیز پذیرفته
     * می‌شود. تمام مسیرهای ذخیرهٔ دسته (Post/AdminAction/Import/Plugin)
     * از همین متد برای اعتبارسنجی استفاده می‌کنند.
     */
    public static function isValidCategoryIcon(string $icon): bool
    {
        $icon = trim($icon);
        if ($icon === '') {
            return false;
        }
        $lucideKey = $icon;
        if (str_starts_with($lucideKey, 'lucide:')) {
            $lucideKey = trim(substr($lucideKey, strlen('lucide:')));
            if ($lucideKey !== '') {
                return isset(self::CATEGORY_ICON_PATHS[$lucideKey]);
            }
            return false;
        }
        if (isset(self::CATEGORY_ICON_PATHS[$lucideKey])) {
            return true;
        }
        return self::isCategoryEmoji($icon);
    }

    /** خواندن فهرست دسته‌ها از جدول (کش‌شده در طول درخواست) */
    public static function categories(): array
    {
        if (self::$categoriesCache !== null) {
            return self::$categoriesCache;
        }
        $out = [];
        try {
            $db = Db::get();
            try {
                // ۲.۲.۰: ستون is_locked — پس از فعال‌سازی/مهاجرت همیشه موجود است
                $rows = $db->fetchAll(
                    $db->select('id', 'name', 'slug', 'icon', 'color', 'parent_id', 'sort_order', 'is_locked')
                        ->from('table.forum_categories')
                );
                $hasLock = true;
            } catch (\Throwable $e) {
                // جایگزینی فایل بدون فعال‌سازی مجدد — ستون هنوز ساخته نشده
                $rows = $db->fetchAll(
                    $db->select('id', 'name', 'slug', 'icon', 'color', 'parent_id', 'sort_order')
                        ->from('table.forum_categories')
                );
                $hasLock = false;
            }
            foreach ($rows as $r) {
                $out[] = [
                    'id'       => (int) $r['id'],
                    'name'     => trim((string) $r['name']),
                    'slug'     => trim((string) ($r['slug'] ?? '')),
                    'icon'     => trim((string) ($r['icon'] ?? '')),
                    'color'    => trim((string) ($r['color'] ?? '')),
                    'parentId' => (int) ($r['parent_id'] ?? 0),
                    'order'    => (int) ($r['sort_order'] ?? 0),
                    'locked'   => $hasLock && (int) ($r['is_locked'] ?? 0) === 1,
                ];
            }
        } catch (\Throwable $e) {
        }
        // مرتب‌سازی بر اساس order سپس id
        usort($out, static function ($a, $b) {
            if ($a['order'] !== $b['order']) {
                return $a['order'] <=> $b['order'];
            }
            return $a['id'] <=> $b['id'];
        });
        return self::$categoriesCache = $out;
    }

    /** بازتنظیم کش دسته‌ها (پس از تغییر) */
    public static function resetCategoriesCache(): void
    {
        self::$categoriesCache = null;
    }

    /** ذخیرهٔ کامل فهرست دسته‌ها (پاک‌سازی و بازنویسی جدول) */
    public static function setCategories(array $cats): void
    {
        try {
            $db = Db::get();
            $db->query($db->delete('table.forum_categories'));

            foreach ($cats as $cat) {
                if (!isset($cat['name']) || trim((string) $cat['name']) === '') {
                    continue;
                }
                $icon = self::isValidCategoryIcon((string) ($cat['icon'] ?? '')) ? trim((string) $cat['icon']) : '';
                $color = preg_match('~^#[0-9a-fA-F]{6}$~', (string) ($cat['color'] ?? ''))
                    ? (string) $cat['color'] : '';
                $db->query(
                    $db->insert('table.forum_categories')->rows([
                        'id'         => max(0, (int) ($cat['id'] ?? 0)),
                        'name'       => mb_substr(trim((string) $cat['name']), 0, 80),
                        'slug'       => mb_substr(trim((string) ($cat['slug'] ?? '')), 0, 80),
                        'icon'       => $icon,
                        'color'      => $color,
                        'parent_id'  => max(0, (int) ($cat['parentId'] ?? 0)),
                        'sort_order' => max(0, (int) ($cat['order'] ?? 0)),
                        'is_locked'  => !empty($cat['locked']) ? 1 : 0,
                        'created'    => time(),
                    ])
                );
            }
            Schema::syncSequences();
        } catch (\Throwable $e) {
        }
        self::resetCategoriesCache();
    }

    /** یافتن یک دسته بر اساس id (یا null) */
    public static function getCategory(int $id): ?array
    {
        if ($id < 1) {
            return null;
        }
        foreach (self::categories() as $cat) {
            if ($cat['id'] === $id) {
                return $cat;
            }
        }
        return null;
    }

    /** ساخت یک دستهٔ جدید و بازگرداندن id آن */
    public static function createCategory(string $name, string $icon = '', string $color = '', int $parentId = 0, int $order = 0): int
    {
        $newId = 0;
        try {
            $db = Db::get();
            // query() برای INSERT همان شناسهٔ درج‌شده را برمی‌گرداند
            $newId = (int) $db->query(
                $db->insert('table.forum_categories')->rows([
                    'name'       => mb_substr(trim($name), 0, 80),
                    'slug'       => '',
                    'icon'       => self::isValidCategoryIcon($icon) ? $icon : '',
                    'color'      => $color,
                    'parent_id'  => max(0, $parentId),
                    'sort_order' => max(0, $order),
                    'created'    => time(),
                ])
            );
        } catch (\Throwable $e) {
        }
        if ($newId < 1) {
            // fallback: بیشینهٔ فعلی
            try {
                $db = Db::get();
                $row = $db->fetchRow($db->select('id')->from('table.forum_categories')
                    ->order('id', Db::SORT_DESC)->limit(1));
                $newId = (int) ($row['id'] ?? 0);
            } catch (\Throwable $e) {
            }
        }
        self::resetCategoriesCache();
        return $newId;
    }

    /** به‌روزرسانی یک دسته — برمی‌گرداند true/false */
    public static function updateCategory(int $id, string $name, string $icon = '', string $color = '', int $parentId = 0, int $order = -1): bool
    {
        if (self::getCategory($id) === null) {
            return false;
        }
        try {
            $db = Db::get();
            $rows = [
                'name'      => mb_substr(trim($name), 0, 80),
                'icon'      => self::isValidCategoryIcon($icon) ? $icon : '',
                'color'     => $color,
                'parent_id' => max(0, $parentId),
            ];
            if ($order >= 0) {
                $rows['sort_order'] = $order;
            }
            $db->query($db->update('table.forum_categories')->rows($rows)->where('id = ?', $id));
        } catch (\Throwable $e) {
            return false;
        }
        self::resetCategoriesCache();
        return true;
    }

    /**
     * حذف یک دسته.
     * روی تاپیک‌های این دسته: یا به «بدون دسته» (catId=0) منتقل شوند،
     * یا به دستهٔ جدید (اگر $reassignId داده شود). هیچ تاپیکی حذف نمی‌شود.
     */
    public static function deleteCategory(int $id, int $reassignId = 0): bool
    {
        if (self::getCategory($id) === null) {
            return false;
        }
        try {
            $db = Db::get();
            $db->query($db->delete('table.forum_categories')->where('id = ?', $id));

            $target = ($reassignId > 0 && self::getCategory($reassignId) !== null) ? $reassignId : 0;
            $db->query(
                $db->update('table.forum_topics')
                    ->rows(['category_id' => $target])
                    ->where('category_id = ?', $id)
            );
        } catch (\Throwable $e) {
            return false;
        }
        self::resetCategoriesCache();
        return true;
    }

    /** شمار تاپیک‌های هر دسته — برمی‌گرداند [catId => count] */
    public static function categoryTopicCounts(): array
    {
        $counts = [];
        try {
            $db = Db::get();
            $rows = $db->fetchAll(
                $db->select('category_id', ['COUNT(id)' => 'n'])
                    ->from('table.forum_topics')
                    ->where('status = ?', 'approved')
                    ->group('category_id')
            );
            foreach ($rows as $r) {
                $cid = (int) $r['category_id'];
                if ($cid > 0) {
                    $counts[$cid] = (int) $r['n'];
                }
            }
        } catch (\Throwable $e) {
        }
        return $counts;
    }

    /** نگاشت topic=>catId — از ستون category_id مشتق می‌شود (سازگاری با قالب‌ها) */
    public static function topicCatMap(): array
    {
        $map = [];
        try {
            $db = Db::get();
            $rows = $db->fetchAll(
                $db->select('id', 'category_id')->from('table.forum_topics')
                    ->where('category_id > 0')
            );
            foreach ($rows as $r) {
                $map[(int) $r['id']] = (int) $r['category_id'];
            }
        } catch (\Throwable $e) {
        }
        return $map;
    }

    /** catId یک تاپیک (یا ۰ برای «بدون دسته») */
    public static function topicCategoryId(int $coid): int
    {
        $row = self::topicById($coid);
        return $row ? (int) ($row['category_id'] ?? 0) : 0;
    }

    /** تنظیم دستهٔ یک تاپیک (catId=0 یعنی حذف از دسته) */
    public static function setTopicCategory(int $coid, int $catId): void
    {
        if ($coid < 1) {
            return;
        }
        $valid = $catId > 0 && self::getCategory($catId) !== null;
        try {
            $db = Db::get();
            $db->query(
                $db->update('table.forum_topics')
                    ->rows(['category_id' => $valid ? $catId : 0])
                    ->where('id = ?', $coid)
            );
        } catch (\Throwable $e) {
        }
        self::invalidateTopicCache($coid);
    }

    /**
     * ساخت نگاشت catId => آرایهٔ دسته برای استفادهٔ قالب.
     * همچنین شامل شمار تاپیک هر دسته و آیکون SVG آمادهٔ نمایش.
     */
    public static function categoriesForTemplate(bool $includeCounts = true): array
    {
        $counts = $includeCounts ? self::categoryTopicCounts() : [];
        $out = [];
        foreach (self::categories() as $cat) {
            $cat['topicCount'] = $counts[$cat['id']] ?? 0;
            $cat['iconSvg'] = self::categoryIconSvg($cat['icon']);
            $out[] = $cat;
        }
        return $out;
    }

    /** نشانی صفحهٔ مدیریت دسته‌بندی‌ها */
    public static function categoryAdminUrl(): string
    {
        try {
            return Router::url(self::ROUTE_CAT_ADMIN, [], Options::alloc()->index);
        } catch (\Throwable $e) {
            return self::forumUrl();
        }
    }

    // ------------------------------------------------------------------
    //  قفل دسته‌بندی‌ها — ۲.۲.۰
    // ------------------------------------------------------------------

    /**
     * آیا این دسته قفل است؟ (نوشتن فقط با مدیر)
     */
    public static function isCategoryLocked(int $catId): bool
    {
        $cat = $catId > 0 ? self::getCategory($catId) : null;
        return $cat !== null && !empty($cat['locked']);
    }

    /**
     * قفل/بازکردن یک دسته (۲.۲.۰).
     * دستهٔ قفل‌شده فقط برای مدیران نوشتنی است؛ کاربران عادی و مهمان‌ها
     * نمی‌توانند در آن پرسش بگذارند یا به پرسش‌هایش پاسخ بدهند.
     */
    public static function setCategoryLocked(int $catId, bool $locked): bool
    {
        if ($catId < 1 || self::getCategory($catId) === null) {
            return false;
        }
        try {
            $db = Db::get();
            $q = $db->update('table.forum_categories')
                ->rows(['is_locked' => $locked ? 1 : 0])
                ->where('id = ?', $catId);
            $db->query($q);
        } catch (\Throwable $e) {
            // ستون is_locked شاید در نصبِ «جایگزینی فایل» هنوز ساخته نشده باشد
            // (Schema::ensure فقط هنگام فعال‌سازی اجرا می‌شود) — یک‌بار می‌سازیم و دوباره.
            try {
                Schema::ensure();
                $db = Db::get();
                $db->query(
                    $db->update('table.forum_categories')
                        ->rows(['is_locked' => $locked ? 1 : 0])
                        ->where('id = ?', $catId)
                );
            } catch (\Throwable $e2) {
                return false;
            }
        }
        self::resetCategoriesCache();
        return true;
    }

    // ====================================================================
    //  گزارش تخلف (flag) — جدول forum_flags
    // ====================================================================

    /**
     * نگاشت گزارش‌های فعال: "type:id" => ['count'=>n, 'reporters'=>[...], 'reasons'=>[...]]
     *
     * ۲.۲.۰ — reasons آرایه‌ای از دلایل گزارش (هر سطر یک دلیل) است که
     * در بنر زیر qa-admin-bar برای مدیر نمایش داده می‌شود.
     */
    public static function flagMap(): array
    {
        if (self::$flagCache !== null) {
            return self::$flagCache;
        }
        $map = [];
        try {
            $db = Db::get();
            // ۲.۲.۰ — reason به select اضافه شد؛ برای نسخه‌های قدیمی بدون ستون هم امن است.
            // توجه: columnExists باید با نام کامل جدول (با prefix) فراخوانی شود،
            // در غیر این صورت همیشه false برمی‌گرداند و reason ذخیره/خوانده نمی‌شد.
            $hasReasonColumn = false;
            try {
                $hasReasonColumn = CoreSchema::columnExists($db, Schema::table('forum_flags'), 'reason');
            } catch (\Throwable $e) {
                $hasReasonColumn = false;
            }
            $select = $hasReasonColumn
                ? $db->select('item_type', 'item_id', 'reporter_hash', 'reason')->from('table.forum_flags')
                : $db->select('item_type', 'item_id', 'reporter_hash')->from('table.forum_flags');
            $rows = $db->fetchAll($select);
            foreach ($rows as $r) {
                $key = (string) $r['item_type'] . ':' . (int) $r['item_id'];
                if (!isset($map[$key])) {
                    $map[$key] = ['count' => 0, 'reporters' => [], 'reasons' => []];
                }
                $map[$key]['count']++;
                $map[$key]['reporters'][] = (string) $r['reporter_hash'];
                $reason = trim((string) ($r['reason'] ?? ''));
                if ($reason !== '') {
                    $map[$key]['reasons'][] = $reason;
                }
            }
        } catch (\Throwable $e) {
        }
        return self::$flagCache = $map;
    }

    /** بازتنظیم کش گزارش‌ها */
    public static function resetFlagCache(): void
    {
        self::$flagCache = null;
    }

    /**
     * شمار فعلی گزارش‌های یک آیتم.
     *
     * ۲.۲.۰ — پارامتر $type اضافه شد. چون forum_topics.id و forum_posts.id
     * دو شمارندهٔ جداگانهٔ auto-increment هستند، ممکن است هم‌زمان یک پرسش
     * با coid=1 و یک پاسخ با coid=1 وجود داشته باشند. اگر $type مشخص
     * نشود، شمار هر دو نوع با هم جمع می‌شود که رفتار قدیمی است. برای
     * دقت بیشتر، $type را به‌صورت 'topic' یا 'post' پاس بدهید.
     */
    public static function flagCount(int $coid, ?string $type = null): int
    {
        $map = self::flagMap();
        if ($type === 'topic') {
            return (int) ($map['topic:' . $coid]['count'] ?? 0);
        }
        if ($type === 'post') {
            return (int) ($map['post:' . $coid]['count'] ?? 0);
        }
        // رفتار قدیمی: جمع هر دو نوع (برای سازگاری با کد قدیمی)
        $n = (int) ($map['topic:' . $coid]['count'] ?? 0);
        $n += (int) ($map['post:' . $coid]['count'] ?? 0);
        return $n;
    }

    /**
     * آیا این بازدیدکنندهٔ فعلی این آیتم را گزارش داده است؟
     *
     * ۲.۲.۰ — پارامتر $type اضافه شد. برای جلوگیری از تداخل coid بین
     * پرسش و پاسخ، حتماً $type را به‌صورت 'topic' یا 'post' پاس بدهید.
     */
    public static function hasFlagged(int $coid, ?string $type = null): bool
    {
        $map = self::flagMap();
        $id = self::flagReporterId();
        if ($type === 'topic') {
            return in_array($id, $map['topic:' . $coid]['reporters'] ?? [], true);
        }
        if ($type === 'post') {
            return in_array($id, $map['post:' . $coid]['reporters'] ?? [], true);
        }
        // رفتار قدیمی: چک هر دو نوع (برای سازگاری)
        return in_array($id, $map['topic:' . $coid]['reporters'] ?? [], true)
            || in_array($id, $map['post:' . $coid]['reporters'] ?? [], true);
    }

    /** شناسهٔ یکتای بازدیدکننده برای گزارش‌دهی (uid یا کوکی) */
    public static function flagReporterId(): string
    {
        try {
            $user = User::alloc();
            if ($user->hasLogin() && $user->uid) {
                return 'u' . (int) $user->uid;
            }
        } catch (\Throwable $e) {
        }
        // مهمان: از کوکی استفاده کن
        $cookieId = (string) Cookie::get('forumGuestId', '');
        if ($cookieId === '') {
            $cookieId = 'g' . bin2hex(random_bytes(8));
            Cookie::set('forumGuestId', $cookieId, time() + 31536000);
        }
        return $cookieId;
    }

    /** هش امن شناسهٔ گزارش‌دهنده برای ذخیره در جدول */
    private static function flagReporterHash(): string
    {
        return hash('sha256', self::flagReporterId());
    }

    /** نوع آیتم بر اساس وجود در جداول — 'topic' | 'post' | null */
    public static function itemTypeOf(int $coid): ?string
    {
        if (self::topicById($coid) !== null) {
            return 'topic';
        }
        if (self::postById($coid) !== null) {
            return 'post';
        }
        return null;
    }

    /**
     * ثبت یک گزارش برای یک آیتم — برمی‌گرداند: 'ok' | 'already' | 'error'
     *
     * ۲.۲.۰ — پارامتر $type اضافه شد. چون forum_topics.id و forum_posts.id
     * شمارنده‌های جداگانه‌اند و ممکن است هم‌زمان coid یکسان داشته باشند،
     * برای جلوگیری از تداخل، حتماً $type را به‌صورت 'topic' یا 'post' پاس
     * بدهید. اگر $type پاس داده نشود، از itemTypeOf استفاده می‌شود که
     * در صورت تداخل coid، 'topic' را ترجیح می‌دهد (رفتار قدیمی).
     */
    public static function addFlag(int $coid, string $reason = '', ?string $type = null): string
    {
        if ($coid < 1) {
            return 'error';
        }
        // اگر نوع به‌صورت صریح پاس داده نشد، از itemTypeOf استفاده کن (رفتار قدیمی).
        // توجه: در صورت وجود هم‌زمان topic و post با coid یکسان، itemTypeOf
        // همیشه 'topic' را برمی‌گرداند که می‌تواند نادرست باشد. برای دقت،
        // $type را به‌صورت 'topic' یا 'post' پاس بدهید.
        if ($type === null) {
            $type = self::itemTypeOf($coid);
        }
        if ($type !== 'topic' && $type !== 'post') {
            return 'error';
        }
        // اعتبارسنجی نهایی: مطمئن شو آیتم با این coid و type واقعاً وجود دارد
        $row = $type === 'topic' ? self::topicById($coid) : self::postById($coid);
        if ($row === null) {
            return 'error';
        }

        // ۲.۲.۰ — دلیل گزارش حداکثر ۱۶۰ کاراکتر
        $reason = trim(mb_substr($reason, 0, 160));

        $hash = self::flagReporterHash();
        try {
            $db = Db::get();

            // ۲.۲.۰ — مهاجرت خودکار: اگر ستون reason وجود ندارد (نصب قدیمی قبل از
            // اجرای Schema::ensure)، یک‌بار Schema::ensure را اجرا می‌کنیم تا ستون
            // اضافه شود. این کار فقط یک‌بار رخ می‌دهد؛ فراخوانی‌های بعدی چون ستون
            // موجود است، سریع برمی‌گردند.
            try {
                if (!CoreSchema::columnExists($db, Schema::table('forum_flags'), 'reason')) {
                    Schema::ensure();
                }
            } catch (\Throwable $e) {
                // بی‌اثر — در صورت خطا، reason ذخیره نمی‌شود ولی گزارش ثبت می‌شود
            }

            $exists = $db->fetchRow(
                $db->select('id')->from('table.forum_flags')
                    ->where('item_type = ? AND item_id = ? AND reporter_hash = ?', $type, $coid, $hash)
                    ->limit(1)
            );
            if ($exists) {
                return 'already';
            }

            // ۲.۲.۰ — اگر ستون reason وجود ندارد (نباید رخ دهد چون بالا مهاجرت کردیم)،
            // ردیف بدون reason درج می‌شود.
            // توجه: columnExists باید با نام کامل جدول (با prefix) فراخوانی شود.
            $rows = [
                'item_type'     => $type,
                'item_id'       => $coid,
                'reporter_hash' => $hash,
                'created'       => time(),
            ];
            try {
                if (CoreSchema::columnExists($db, Schema::table('forum_flags'), 'reason')) {
                    $rows['reason'] = $reason;
                }
            } catch (\Throwable $e) {
                // بی‌اثر — بدون reason درج می‌شود
            }

            $db->query(
                $db->insert('table.forum_flags')
                    ->rows($rows)
            );
        } catch (\Throwable $e) {
            return 'error';
        }
        self::resetFlagCache();
        return 'ok';
    }

    /**
     * پاک‌کردن همهٔ گزارش‌های یک آیتم (پس از بررسی توسط مدیر)
     *
     * ۲.۲.۰ — پارامتر $type اضافه شد. اگر $type مشخص باشد ('topic' یا 'post')،
     * فقط همان نوع پاک می‌شود. اگر null باشد، هر دو نوع پاک می‌شوند (رفتار قدیمی).
     * این برای جلوگیری از تداخل coid بین topic و post ضروری است.
     */
    public static function clearFlags(int $coid, ?string $type = null): void
    {
        try {
            $db = Db::get();
            if ($type === 'topic' || $type === 'post') {
                $db->query(
                    $db->delete('table.forum_flags')
                        ->where('item_type = ? AND item_id = ?', $type, $coid)
                );
            } else {
                // رفتار قدیمی: هر دو نوع پاک می‌شوند
                $db->query(
                    $db->delete('table.forum_flags')
                        ->where('(item_type = ? AND item_id = ?) OR (item_type = ? AND item_id = ?)',
                            'topic', $coid, 'post', $coid)
                );
            }
        } catch (\Throwable $e) {
        }
        self::resetFlagCache();
    }

    /** پاک‌کردن گزارش‌های آیتم‌های حذف‌شده */
    public static function pruneFlags(?array $validTopicIds = null, ?array $validPostIds = null): void
    {
        try {
            $db = Db::get();
            $rows = $db->fetchAll($db->select('item_type', 'item_id')->from('table.forum_flags'));
            $dead = [];
            foreach ($rows as $r) {
                $type = (string) $r['item_type'];
                $id = (int) $r['item_id'];
                if ($type === 'topic' && self::topicById($id) === null) {
                    $dead[] = ['topic', $id];
                } elseif ($type === 'post' && self::postById($id) === null) {
                    $dead[] = ['post', $id];
                }
            }
            foreach ($dead as [$type, $id]) {
                $db->query(
                    $db->delete('table.forum_flags')
                        ->where('item_type = ? AND item_id = ?', $type, $id)
                );
            }
        } catch (\Throwable $e) {
        }
        self::resetFlagCache();
    }

    /**
     * آیا یک تاپیک (خود پرسش یا یکی از پاسخ‌هایش) گزارش‌شده است؟
     */
    public static function isTopicReported(int $questionCoid, ?array $answerCoids = null): bool
    {
        $map = self::flagMap();
        if (isset($map['topic:' . $questionCoid])) {
            return true;
        }
        if ($answerCoids === null) {
            return false;
        }
        foreach ($answerCoids as $acoid) {
            if (isset($map['post:' . (int) $acoid])) {
                return true;
            }
        }
        return false;
    }

    /**
     * آیا این شناسه (پرسش یا پاسخ) گزارش‌شده است؟
     *
     * ۲.۲.۰ — پارامتر $type اضافه شد. چون forum_topics.id و forum_posts.id
     * شمارنده‌های جداگانه‌اند و ممکن است هم‌زمان coid یکسان داشته باشند،
     * برای دقت بالا حتماً $type را به‌صورت 'topic' یا 'post' پاس بدهید.
     * اگر $type پاس داده نشود، هر دو نوع چک می‌شود (رفتار قدیمی).
     */
    public static function isReported(int $coid, ?string $type = null): bool
    {
        $map = self::flagMap();
        if ($type === 'topic') {
            return isset($map['topic:' . $coid]);
        }
        if ($type === 'post') {
            return isset($map['post:' . $coid]);
        }
        // رفتار قدیمی: چک هر دو نوع (برای سازگاری با کد قدیمی)
        return isset($map['topic:' . $coid]) || isset($map['post:' . $coid]);
    }

    /** شمار کل گزارش‌های تخلف فعال (هر آیتم یک‌بار) */
    public static function totalFlagCount(): int
    {
        $map = self::flagMap();
        return count($map);
    }

    /**
     * ۲.۲.۰ — گزارش‌های فعال برای نمایش در بنر زیر qa-admin-bar.
     *
     * خروجی: آرایه‌ای از اشیاء با کلیدهای:
     *   - 'coid'    => شناسهٔ آیتم (int)
     *   - 'type'    => 'topic' | 'post'
     *   - 'count'   => تعداد گزارش‌ها (int)
     *   - 'reasons' => آرایه‌ای از دلایل غیرخالی (هر سطر یک دلیل)
     *   - 'topicId' => شناسهٔ پرسش (برای ساخت پیوند به صفحهٔ پرسش)
     *   - 'anchor'  => 'c{coid}' برای اسکرول به همان پست
     *   - 'url'     => نشانی کامل برای کلیک
     *   - 'title'   => متن کوتاه پست/پرسش برای شناسایی
     *
     * فقط در صورتی که آیتم هنوز موجود باشد و قبلاً پاک نشده باشد.
     */
    public static function activeReportsForBanner(): array
    {
        $map = self::flagMap();
        if (empty($map)) {
            return [];
        }

        $out = [];
        try {
            $db = Db::get();
            foreach ($map as $key => $info) {
                [$type, $idStr] = explode(':', $key, 2);
                $coid = (int) $idStr;
                if ($coid < 1) {
                    continue;
                }

                $topicId = 0;
                $title = '';
                $text = '';

                if ($type === 'topic') {
                    $row = self::topicById($coid);
                    if ($row === null) {
                        continue; // تاپیک حذف شده — پر شده توسط pruneFlags
                    }
                    $topicId = $coid;
                    [$titlePart] = self::splitQuestion((string) ($row['text'] ?? ''));
                    $title = self::stripMarkup($titlePart);
                    $text = (string) ($row['text'] ?? '');
                } else {
                    $row = self::postById($coid);
                    if ($row === null) {
                        continue;
                    }
                    $topicId = (int) ($row['topic_id'] ?? 0);
                    $text = (string) ($row['text'] ?? '');
                    // عنوان از روی تاپیک والد
                    $topic = $topicId > 0 ? self::topicById($topicId) : null;
                    if ($topic !== null) {
                        [$titlePart] = self::splitQuestion((string) ($topic['text'] ?? ''));
                        $title = self::stripMarkup($titlePart);
                    }
                }

                if ($topicId < 1) {
                    continue; // نمی‌توانیم پیوند بسازیم
                }

                $out[] = [
                    'coid'    => $coid,
                    'type'    => $type,
                    'count'   => (int) ($info['count'] ?? 0),
                    'reasons' => array_values(array_unique($info['reasons'] ?? [])),
                    'topicId' => $topicId,
                    'anchor'  => 'c' . $coid,
                    'url'     => self::threadUrl($topicId) . '#c' . $coid,
                    'title'   => $title !== '' ? $title : self::excerpt($text, 60),
                    'kind'    => $type === 'topic' ? 'پرسش' : 'پاسخ',
                ];
            }
        } catch (\Throwable $e) {
        }
        return $out;
    }

    // ====================================================================
    //  پیام‌های در انتظار تأیید — تب مخفی فهرست (۲.۰.۰)
    //  مانند تب گزارش‌ها: فقط وقتی که واقعاً موردی هست نمایش
    //  داده می‌شود؛ مدیر همه را می‌بیند، عضو فقط‌‌های خودش را.
    // ====================================================================

    /**
     * ردیف‌های سبک پرسش‌های در انتظار تأیید.
     *
     * $authorId = null → همه (مدیر)؛ عدد → فقط پرسش‌های خود آن عضو.
     */
    public static function waitingTopicRows(?int $authorId = null): array
    {
        try {
            $db = Db::get();
            $select = $db->select('id', 'created', 'author_name', 'author_mail', 'author_id')
                ->from('table.forum_topics')
                ->where('status = ?', 'waiting');
            if ($authorId !== null) {
                $select->where('author_id = ?', $authorId);
            }
            return $db->fetchAll($select->order('created', Db::SORT_DESC));
        } catch (\Throwable $e) {
            return [];
        }
    }

    /** شمار پرسش‌های در انتظار تأیید (همه یا مالِ یک عضو) */
    public static function countWaitingTopics(?int $authorId = null): int
    {
        try {
            $db = Db::get();
            $select = $db->select(['COUNT(id)' => 'n'])->from('table.forum_topics')->where('status = ?', 'waiting');
            if ($authorId !== null) {
                $select->where('author_id = ?', $authorId);
            }
            return (int) $db->fetchObject($select)->n;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /**
     * نگاشت topic_id → شمار پاسخ‌های در انتظار تأیید آن تاپیک.
     *
     * برای نمای مدیر: تاپیک‌های تأییدشده‌ای که پاسخِ در انتظار دارند
     * در تب «در انتظار تأیید» با نشان «پاسخ در انتظار» ظاهر می‌شوند.
     */
    public static function topicsWithWaitingPosts(): array
    {
        try {
            $db = Db::get();
            $rows = $db->fetchAll(
                $db->select('topic_id', ['COUNT(id)' => 'n'])
                    ->from('table.forum_posts')
                    ->where('status = ?', 'waiting')
                    ->group('topic_id')
            );
            $map = [];
            foreach ($rows as $r) {
                $map[(int) $r['topic_id']] = (int) $r['n'];
            }
            return $map;
        } catch (\Throwable $e) {
            return [];
        }
    }

    // ====================================================================
    //  پسند (لایک) — جدول forum_likes (۲.۰.۰)
    //  هم برای پرسش‌ها و هم برای پاسخ‌ها؛ یکتاسازی با هش شناسهٔ
    //  رأی‌دهنده (uid عضو یا کوکی مهمان — همان سازوکار گزارش‌ها)
    // ====================================================================

    /** آیا دکمهٔ پسند فعال است؟ */
    public static function likesEnabled(): bool
    {
        return self::opt('enableLikes', '1') !== '0';
    }

    /** شناسهٔ عضوِ در حال بازدید (بدون لاگین: ۰) — بدون پرتاب استثنا */
    public static function viewerUid(): int
    {
        try {
            $user = User::alloc();
            if ($user->hasLogin() && $user->uid) {
                return (int) $user->uid;
            }
        } catch (\Throwable $e) {
        }
        return 0;
    }

    /**
     * آیا بازدیدکنندهٔ فعلی می‌تواند این آیتم را پسند بدهد؟ (۲.۰.۰)
     *
     * فقط اعضای واردشده؛ و نه نویسندهٔ خودِ آیتم (نویسنده نمی‌تواند
     * به نوشتهٔ خودش پسند بدهد — به‌جای دکمه، نشان شمار پسندهای
     * دریافتی می‌بیند). مهمان‌ها هیچ دکمهٔ پسندی نمی‌بینند.
     *
     * $row ردیف به «شکل قالب» است (کلید authorId).
     */
    public static function canLike(array $row): bool
    {
        if (!self::likesEnabled()) {
            return false;
        }
        $uid = self::viewerUid();
        if ($uid < 1) {
            return false; // مهمان — پسند کاملاً غیرفعال
        }
        $authorId = (int) ($row['authorId'] ?? 0);
        if ($authorId > 0 && $authorId === $uid) {
            return false; // نویسندهٔ خودش
        }
        return true;
    }

    /**
     * آیا بازدیدکنندهٔ فعلی می‌تواند این آیتم را گزارش کند؟ (۲.۰.۰)
     *
     * گزارش فقط برای اعضای واردشده است و نویسندهٔ خودِ آیتم نمی‌تواند
     * نوشتهٔ خودش را گزارش کند (همان قاعدهٔ پسند). $row ردیف به
     * «شکل قالب» است (کلید authorId).
     */
    public static function canFlag(array $row): bool
    {
        $uid = self::viewerUid();
        if ($uid < 1) {
            return false; // مهمان — دکمهٔ گزارش ندارد
        }
        // ۲.۲.۰ — مدیران نیازی به دکمهٔ گزارش ندارند؛ خودشان مستقیماً اقدام می‌کنند
        if (self::canManage()) {
            return false;
        }
        $authorId = (int) ($row['authorId'] ?? 0);
        if ($authorId > 0 && $authorId === $uid) {
            return false; // نویسندهٔ خودش
        }
        return true;
    }

    /**
     * اطمینان از وجود جدول پسندها — خودترمیم پس از ارتقای «جایگزینی فایل».
     *
     * جدول forum_likes در ۲.۰.۰ معرفی شد اما Schema::ensure فقط هنگام
     * فعال‌سازی افزونه اجرا می‌شود؛ اگر مدیر پوشهٔ افزونه را بدون
     * خاموش/روشن‌کردن جایگزین کند، جدول وجود ندارد و هر پسندی خطا می‌دهد.
     * این متد با یک کوئری سبک وجود جدول را می‌سنجد و در نبودش یک‌بار
     * کل ساختار را می‌سازد (ایده‌مپوتنت است؛ بقیهٔ جدول‌ها هم اگر
     * نباشند ساخته می‌شوند).
     */
    public static function ensureLikesTable(): void
    {
        if (self::$likesTableReady !== null) {
            return;
        }
        try {
            $db = Db::get();
            $db->fetchRow($db->select('id')->from('table.forum_likes')->limit(1));
            self::$likesTableReady = true;
            return;
        } catch (\Throwable $e) {
            // جدول وجود ندارد (یا خطای دسترسی) — تلاش برای ساخت
        }
        try {
            Schema::ensure();
            self::$likesTableReady = true;
        } catch (\Throwable $e) {
            self::$likesTableReady = false;
        }
    }

    /**
     * نگاشت پسندها: "type:id" => ['count'=>n, 'voters'=>[...]]
     */
    public static function likeMap(): array
    {
        if (self::$likeCache !== null) {
            return self::$likeCache;
        }
        self::ensureLikesTable();
        $map = [];
        try {
            $db = Db::get();
            $rows = $db->fetchAll(
                $db->select('item_type', 'item_id', 'voter_hash')
                    ->from('table.forum_likes')
            );
            foreach ($rows as $r) {
                $key = (string) $r['item_type'] . ':' . (int) $r['item_id'];
                if (!isset($map[$key])) {
                    $map[$key] = ['count' => 0, 'voters' => []];
                }
                $map[$key]['count']++;
                $map[$key]['voters'][] = (string) $r['voter_hash'];
            }
        } catch (\Throwable $e) {
        }
        return self::$likeCache = $map;
    }

    /** بازتنظیم کش پسندها */
    public static function resetLikeCache(): void
    {
        self::$likeCache = null;
    }

    /** شمار پسندهای یک آیتم (پرسش یا پاسخ) — با نوع صریح */
    public static function likeCountTyped(string $type, int $coid): int
    {
        if ($type !== 'topic' && $type !== 'post') {
            return 0;
        }
        $map = self::likeMap();
        return (int) ($map[$type . ':' . $coid]['count'] ?? 0);
    }

    /** آیا این بازدیدکنندهٔ فعلی این آیتم را پسندیده است؟ — با نوع صریح */
    public static function hasLikedTyped(string $type, int $coid): bool
    {
        if ($type !== 'topic' && $type !== 'post') {
            return false;
        }
        // مهمان — پسند غیرفعال است (۲.۰.۰)
        if (self::viewerUid() < 1) {
            return false;
        }
        $map = self::likeMap();
        return in_array(self::likeVoterHash(), $map[$type . ':' . $coid]['voters'] ?? [], true);
    }

    /** شمار پسندهای یک آیتم بدون نوع مشخص (جمع هر دو نوع) — فقط برای نمایش‌های عمومی */
    public static function likeCount(int $coid): int
    {
        $map = self::likeMap();
        return (int) ($map['topic:' . $coid]['count'] ?? 0)
            + (int) ($map['post:' . $coid]['count'] ?? 0);
    }

    /** آیا این بازدیدکنندهٔ فعلی این آیتم را پسندیده است؟ (بدون نوع) */
    public static function hasLiked(int $coid): bool
    {
        $map = self::likeMap();
        $hash = self::likeVoterHash();
        return in_array($hash, $map['topic:' . $coid]['voters'] ?? [], true)
            || in_array($hash, $map['post:' . $coid]['voters'] ?? [], true);
    }

    /** هش امن شناسهٔ پسندکننده برای ذخیره در جدول */
    private static function likeVoterHash(): string
    {
        return hash('sha256', self::flagReporterId());
    }

    /**
     * ثبت/برداشتن پسند یک آیتم — برمی‌گرداند:
     *   ['status'=>'added'|'removed'|'guest'|'own'|'error', 'count'=>n]
     *
     * قواعد ۲.۰.۰:
     *   - مهمان‌ها نمی‌توانند پسند بدهند ('guest').
     *   - نویسندهٔ آیتم نمی‌تواند نوشتهٔ خودش را پسند بدهد ('own').
     *
     * @param string|null $type  نوع صریح آیتم ('topic'|'post') از فرم —
     *                           برای حل ابهامِ هم‌شماری شناسه‌های دو جدول؛
     *                           اگر داده نشد از itemTypeOf تشخیص می‌شود.
     */
    public static function toggleLike(int $coid, ?string $type = null): array
    {
        $out = ['status' => 'error', 'count' => 0];
        if ($coid < 1) {
            return $out;
        }

        // مهمان — پسند کاملاً غیرفعال (۲.۰.۰)
        $uid = self::viewerUid();
        if ($uid < 1) {
            $out['status'] = 'guest';
            return $out;
        }

        self::ensureLikesTable();
        $item = null;
        if ($type === 'topic') {
            $item = self::topicById($coid);
        } elseif ($type === 'post') {
            $item = self::postById($coid);
        } else {
            $type = self::itemTypeOf($coid);
            if ($type === 'topic') {
                $item = self::topicById($coid);
            } elseif ($type === 'post') {
                $item = self::postById($coid);
            }
        }
        if ($item === null || $type === null) {
            return $out;
        }

        // نویسندهٔ آیتم نمی‌تواند به نوشتهٔ خودش پسند بدهد (۲.۰.۰)
        $authorId = (int) ($item['author_id'] ?? ($item['authorId'] ?? 0));
        if ($authorId > 0 && $authorId === $uid) {
            $out['status'] = 'own';
            $out['count'] = self::likeCountTyped($type, $coid);
            return $out;
        }

        $hash = self::likeVoterHash();
        try {
            $db = Db::get();
            $exists = $db->fetchRow(
                $db->select('id')->from('table.forum_likes')
                    ->where('item_type = ? AND item_id = ? AND voter_hash = ?', $type, $coid, $hash)
                    ->limit(1)
            );
            if ($exists) {
                $db->query(
                    $db->delete('table.forum_likes')
                        ->where('id = ?', (int) $exists['id'])
                );
                $out['status'] = 'removed';
            } else {
                $db->query(
                    $db->insert('table.forum_likes')
                        ->rows([
                            'item_type'  => $type,
                            'item_id'    => $coid,
                            'voter_hash' => $hash,
                            'created'    => time(),
                        ])
                );
                $out['status'] = 'added';
            }
        } catch (\Throwable $e) {
            return $out;
        }

        self::resetLikeCache();
        $out['count'] = self::likeCountTyped($type, $coid);
        return $out;
    }

    /** پاک‌کردن همهٔ پسندهای یک آیتم (هنگام حذف) */
    public static function clearLikes(int $coid): void
    {
        try {
            $db = Db::get();
            $db->query(
                $db->delete('table.forum_likes')
                    ->where('(item_type = ? AND item_id = ?) OR (item_type = ? AND item_id = ?)',
                        'topic', $coid, 'post', $coid)
            );
        } catch (\Throwable $e) {
        }
        self::resetLikeCache();
    }

    /** پاک‌کردن پسندهای آیتم‌های حذف‌شده (بررسی مستقیم وجود آیتم) */
    public static function pruneLikes(): void
    {
        try {
            $db = Db::get();
            $rows = $db->fetchAll($db->select('item_type', 'item_id')->from('table.forum_likes'));
            $dead = [];
            foreach ($rows as $r) {
                $type = (string) $r['item_type'];
                $id = (int) $r['item_id'];
                if ($type === 'topic' && self::topicById($id) === null) {
                    $dead[] = ['topic', $id];
                } elseif ($type === 'post' && self::postById($id) === null) {
                    $dead[] = ['post', $id];
                }
            }
            foreach ($dead as [$type, $id]) {
                $db->query(
                    $db->delete('table.forum_likes')
                        ->where('item_type = ? AND item_id = ?', $type, $id)
                );
            }
        } catch (\Throwable $e) {
        }
        self::resetLikeCache();
    }

    /** شمار پسندهای دریافتی یک کاربر (روی پرسش‌ها و پاسخ‌هایش) */
    public static function likesReceived(int $uid): int
    {
        if ($uid < 1) {
            return 0;
        }
        self::ensureLikesTable();
        try {
            $db = Db::get();
            $n = (int) $db->fetchObject(
                $db->select(['COUNT(table.forum_likes.id)' => 'n'])
                    ->from('table.forum_likes')
                    ->join('table.forum_topics', "table.forum_topics.id = table.forum_likes.item_id AND table.forum_likes.item_type = 'topic'", Db::LEFT_JOIN)
                    ->where('table.forum_topics.author_id = ?', $uid)
            )->n;
            $n += (int) $db->fetchObject(
                $db->select(['COUNT(table.forum_likes.id)' => 'n'])
                    ->from('table.forum_likes')
                    ->join('table.forum_posts', "table.forum_posts.id = table.forum_likes.item_id AND table.forum_likes.item_type = 'post'", Db::LEFT_JOIN)
                    ->where('table.forum_posts.author_id = ?', $uid)
            )->n;
            return $n;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    // ====================================================================
    //  آپلود تصویر — سرویس imgurl.ir (۲.۰.۰)
    //  بارگذاری سمت سرور (پروکسی) تا مشکل CORS مرورگر و محدودیت‌های
    //  دامنه رخ ندهد؛ پاسخ HTML سرویس برای یافتن پیوند مستقیم پارس می‌شود.
    // ====================================================================

    /** نشانی نقطهٔ پایانی (endpoint) آپلود سرویس */
    private const IMGURL_ENDPOINT = 'https://imgurl.ir/upload.php';

    /** آیا دکمهٔ آپلود تصویر فعال است؟ */
    public static function imgUploadEnabled(): bool
    {
        return self::opt('enableImgUpload', '1') !== '0';
    }

    /** بیشینهٔ حجم مجاز تصویر (بایت) */
    public static function imgUploadMaxBytes(): int
    {
        $mb = (int) self::opt('imgUploadMaxMB', '10');
        if ($mb < 1) {
            $mb = 10;
        }
        return $mb * 1048576;
    }

    /** پسوندهای مجاز آپلود */
    public static function imgUploadExts(): array
    {
        return ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
    }

    /**
     * آپلود یک فایل تصویری به imgurl.ir — پیوند مستقیم یا null.
     *
     * @param string $tmpPath  مسیر فایل موقت روی سرور
     * @param string $origName نام اصلی فایل (برای نام‌گذاری سمت سرویس)
     * @param string $mime     نوع MIME (مثلاً image/png)
     */
    public static function uploadToImgurl(string $tmpPath, string $origName, string $mime = 'image/png'): ?string
    {
        if (!is_file($tmpPath) || (int) @filesize($tmpPath) < 1) {
            return null;
        }

        // نام امن: فقط حرف/رقم/نقطه/خط تیره؛ پیشوند imgforum_ برای شناسایی
        $safe = preg_replace('/[^A-Za-z0-9._-]+/', '_', basename($origName));
        if ($safe === null || $safe === '') {
            $safe = 'image_' . substr(md5((string) time()), 0, 8) . '.png';
        }
        $safe = 'imgforum_' . $safe;

        $body = self::imgurlRequest($tmpPath, $safe, $mime);
        if ($body === null) {
            return null;
        }
        return self::imgurlExtractLink($body);
    }

    /** فراخوانی سرویس — بدنهٔ HTML پاسخ یا null (cURL یا fallback) */
    private static function imgurlRequest(string $tmpPath, string $name, string $mime): ?string
    {
        if (function_exists('curl_init')) {
            try {
                $ch = curl_init(self::IMGURL_ENDPOINT);
                if ($ch === false) {
                    return null;
                }
                curl_setopt_array($ch, [
                    CURLOPT_POST           => true,
                    CURLOPT_POSTFIELDS     => [
                        'userfile[]'     => new \CURLFile($tmpPath, $mime, $name),
                        'private_upload' => '0',
                        'delete_at'      => '',
                    ],
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_MAXREDIRS      => 3,
                    CURLOPT_CONNECTTIMEOUT => 15,
                    CURLOPT_TIMEOUT        => 60,
                    CURLOPT_USERAGENT      => 'TypeRenew-Forum/' . self::VERSION . ' (+https://imgurl.ir)',
                ]);
                $body = curl_exec($ch);
                $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
                curl_close($ch);
                if (is_string($body) && $code >= 200 && $code < 300 && $body !== '') {
                    return $body;
                }
                return null;
            } catch (\Throwable $e) {
                return null;
            }
        }

        // بدون cURL — ساخت دستی multipart با stream context
        try {
            $boundary = '----ForumBoundary' . bin2hex(random_bytes(8));
            $data = (string) @file_get_contents($tmpPath);
            if ($data === '' || $data === false) {
                return null;
            }
            $eol = "\r\n";
            $parts = '';
            foreach (['private_upload' => '0', 'delete_at' => ''] as $k => $v) {
                $parts .= '--' . $boundary . $eol
                    . 'Content-Disposition: form-data; name="' . $k . '"' . $eol . $eol
                    . $v . $eol;
            }
            $parts .= '--' . $boundary . $eol
                . 'Content-Disposition: form-data; name="userfile[]"; filename="' . str_replace('"', '', $name) . '"' . $eol
                . 'Content-Type: ' . $mime . $eol . $eol
                . $data . $eol;
            $parts .= '--' . $boundary . '--' . $eol;

            $ctx = stream_context_create(['http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: multipart/form-data; boundary=" . $boundary . $eol
                    . "User-Agent: TypeRenew-Forum/" . self::VERSION . $eol,
                'content' => $parts,
                'timeout' => 60,
                'ignore_errors' => false,
            ]]);
            $body = @file_get_contents(self::IMGURL_ENDPOINT, false, $ctx);
            return is_string($body) && $body !== '' ? $body : null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** بیرون‌کشیدن پیوند مستقیم تصویر از پاسخ HTML سرویس */
    private static function imgurlExtractLink(string $body): ?string
    {
        // الگوی اصلی: پیوند مستقیم CDN سرویس
        if (preg_match('/https?:\/\/cdn\.imgurl\.ir\/uploads\/[A-Za-z0-9._%+-]+/i', $body, $m)) {
            return str_replace('http://cdn.', 'https://cdn.', $m[0]);
        }
        // الگوی جایگزین: هر نشانی تصویری معتبر که خود سرویس برگردانده باشد
        if (preg_match('/https?:\/\/imgurl\.ir\/(?:up|files)\/[A-Za-z0-9._%+-]+/i', $body, $m)) {
            return str_replace('http://', 'https://', $m[0]);
        }
        return null;
    }

    // ====================================================================
    //  اعلان‌های درون‌انجمنی — جدول forum_notifications
    // ====================================================================

    /**
     * تعیین شناسهٔ تاپیک برای یک آیتم (پرسش یا پاسخ).
     *
     * این متد برای رفع باگ لینک‌های اعلان در نسخهٔ ۲.۰.۱ اضافه شده:
     * اعلان‌های قدیمیِ نسخهٔ ۱ ممکن است topic_id = ۰ داشته باشند؛ این
     * متد با lookup از جدول‌ها شناسهٔ تاپیک را پیدا می‌کند.
     */
    public static function topicIdForItem(int $itemId): int
    {
        if ($itemId < 1) {
            return 0;
        }
        try {
            $db = Db::get();
            // اگر خود آیتم یک تاپیک است
            $tRow = $db->fetchRow(
                $db->select('id')->from('table.forum_topics')
                    ->where('id = ?', $itemId)->limit(1)
            );
            if ($tRow) {
                return (int) $tRow['id'];
            }
            // در غیر این صورت یک پاسخ است؛ topic_id آن را برمی‌گردانیم
            $pRow = $db->fetchRow(
                $db->select('topic_id')->from('table.forum_posts')
                    ->where('id = ?', $itemId)->limit(1)
            );
            if ($pRow) {
                return (int) $pRow['topic_id'];
            }
        } catch (\Throwable $e) {
            // بی‌اثر
        }
        return 0;
    }

    /** افزودن یک اعلان برای یک کاربر */
    public static function addNotification(int $uid, string $type, int $itemId, int $topicId = 0): void
    {
        if ($uid < 1) {
            return;
        }
        if (!in_array($type, ['reply', 'best', 'mention', 'pm'], true)) {
            $type = 'reply';
        }
        if ($topicId < 1) {
            // تعیین خودکار تاپیک مربوطه
            if (self::topicById($itemId) !== null) {
                $topicId = $itemId;
            } else {
                $post = self::postById($itemId);
                $topicId = $post ? (int) $post['topic_id'] : 0;
            }
        }
        try {
            $db = Db::get();
            // جلوگیری از اعلان تکراری برای همان آیتم و همان نوع
            $exists = $db->fetchRow(
                $db->select('id')->from('table.forum_notifications')
                    ->where('uid = ? AND type = ? AND item_id = ?', $uid, $type, $itemId)
                    ->limit(1)
            );
            if ($exists) {
                return;
            }
            $db->query(
                $db->insert('table.forum_notifications')->rows([
                    'uid'     => $uid,
                    'type'    => $type,
                    'topic_id' => $topicId,
                    'item_id' => $itemId,
                    'is_read' => 0,
                    'created' => time(),
                ])
            );
            // نگه‌داری فقط ۲۰۰ اعلان اخیر هر کاربر (جلوگیری از تورم)
            $old = $db->fetchAll(
                $db->select('id')->from('table.forum_notifications')
                    ->where('uid = ?', $uid)
                    ->order('created', Db::SORT_DESC)
                    ->offset(200)
            );
            if (!empty($old)) {
                $ids = array_map(static fn ($r) => (int) $r['id'], $old);
                $db->query($db->delete('table.forum_notifications')->where('id IN ?', $ids));
            }
        } catch (\Throwable $e) {
        }
    }

    /** اعلان‌های یک کاربر (مرتب بر اساس زمان نزولی — شکل سازگار با قالب)
     *  (۲.۳.۰) کش‌شده در طول درخواست — صفحهٔ اعلان‌ها و commonContext
     *  از یک کوئری مشترک استفاده می‌کنند؛ خروجی همان آرایهٔ قبلی است. */
    public static function notificationsFor(int $uid): array
    {
        static $requestCache = [];
        if (isset($requestCache[$uid])) {
            return $requestCache[$uid];
        }
        $out = [];
        if ($uid < 1) {
            return $requestCache[$uid] = $out;
        }
        try {
            $db = Db::get();
            $rows = $db->fetchAll(
                $db->select()->from('table.forum_notifications')
                    ->where('uid = ?', $uid)
                    ->order('created', Db::SORT_DESC)
            );
            foreach ($rows as $r) {
                $out[] = [
                    'id'      => (int) $r['id'],
                    'uid'     => (int) $r['uid'],
                    'type'    => (string) $r['type'],
                    'topic_id' => (int) $r['topic_id'],
                    // «coid» سازگار با قالب: شناسهٔ آیتم (پرسش یا پاسخ)
                    'coid'    => (int) $r['item_id'],
                    'created' => (int) $r['created'],
                    'read'    => (int) $r['is_read'] === 1,
                ];
            }
        } catch (\Throwable $e) {
        }
        return $requestCache[$uid] = $out;
    }

    /** شمار اعلان‌های خوانده‌نشدهٔ یک کاربر */
    public static function unreadNotificationCount(int $uid): int
    {
        if ($uid < 1) {
            return 0;
        }
        try {
            $db = Db::get();
            return (int) $db->fetchObject(
                $db->select(['COUNT(id)' => 'n'])->from('table.forum_notifications')
                    ->where('uid = ? AND is_read = 0', $uid)
            )->n;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /** علامت‌زدن همهٔ اعلان‌های یک کاربر به‌عنوان خوانده‌شده */
    public static function markAllNotificationsRead(int $uid): void
    {
        if ($uid < 1) {
            return;
        }
        try {
            $db = Db::get();
            $db->query(
                $db->update('table.forum_notifications')
                    ->rows(['is_read' => 1])
                    ->where('uid = ? AND is_read = 0', $uid)
            );
        } catch (\Throwable $e) {
        }
    }

    /**
     * علامت‌زدن یک اعلانِ مشخص به‌عنوان خوانده‌شده.
     * مالکیت کاربر بررسی می‌شود.
     */
    public static function markNotificationRead(int $notifId, int $uid): bool
    {
        if ($notifId < 1 || $uid < 1) {
            return false;
        }
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('uid', 'is_read')->from('table.forum_notifications')
                    ->where('id = ?', $notifId)->limit(1)
            );
            if (!$row) {
                return false;
            }
            if ((int) $row['uid'] !== $uid) {
                return false;
            }
            if ((int) $row['is_read'] === 1) {
                return true;
            }
            $db->query(
                $db->update('table.forum_notifications')
                    ->rows(['is_read' => 1])
                    ->where('id = ?', $notifId)
            );
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** متن فارسی نوع اعلان */
    public static function notificationLabel(string $type): string
    {
        return match ($type) {
            'reply'    => 'به پرسش شما پاسخی داده شد',
            'best'     => 'پاسخ شما به‌عنوان بهترین پاسخ انتخاب شد',
            'mention'  => 'در پاسخی نام برده شدید',
            'pm'       => 'پیام خصوصی جدید دریافت کردید',
            default    => 'اعلان جدید',
        };
    }

    // ====================================================================
    //  نظرسنجی — جداول forum_polls / forum_poll_votes
    // ====================================================================

    /** آیا نظرسنجی فعال است؟ */
    public static function pollsEnabled(): bool
    {
        return self::opt('enablePolls', '1') !== '0';
    }

    /** خواندن تعریف نظرسنجی یک پرسش (یا null) */
    public static function getPoll(int $coid): ?array
    {
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('question', 'options')->from('table.forum_polls')
                    ->where('topic_id = ?', $coid)->limit(1)
            );
            if (!$row) {
                return null;
            }
            $options = json_decode((string) $row['options'], true);
            if (!is_array($options) || empty($options)) {
                return null;
            }
            return [
                'question' => trim((string) $row['question']),
                'options'  => array_values(array_filter(array_map('strval', $options), fn ($o) => trim($o) !== '')),
            ];
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** ذخیرهٔ تعریف نظرسنجی */
    public static function setPoll(int $coid, string $question, array $options): void
    {
        $question = trim(mb_substr($question, 0, 200));
        $options = array_filter(array_map('trim', $options), fn ($o) => $o !== '');
        $options = array_slice($options, 0, 8);
        if ($question === '' || count($options) < 2) {
            return;
        }
        try {
            $db = Db::get();
            $exists = $db->fetchRow(
                $db->select('topic_id')->from('table.forum_polls')
                    ->where('topic_id = ?', $coid)->limit(1)
            );
            $rows = [
                'question' => $question,
                'options'  => json_encode(array_values($options), JSON_UNESCAPED_UNICODE),
                'created'  => time(),
            ];
            if ($exists) {
                unset($rows['created']);
                $db->query($db->update('table.forum_polls')->rows($rows)->where('topic_id = ?', $coid));
            } else {
                $db->query($db->insert('table.forum_polls')->rows($rows + ['topic_id' => $coid]));
            }
        } catch (\Throwable $e) {
        }
    }

    /** حذف نظرسنجی و آرا آن */
    public static function deletePoll(int $coid): void
    {
        try {
            $db = Db::get();
            $db->query($db->delete('table.forum_polls')->where('topic_id = ?', $coid));
            $db->query($db->delete('table.forum_poll_votes')->where('topic_id = ?', $coid));
        } catch (\Throwable $e) {
        }
    }

    /** خواندن آرا نظرسنجی — برمی‌گرداند آرایه idx=>count */
    public static function getPollVotes(int $coid): array
    {
        $votes = [];
        try {
            $db = Db::get();
            $rows = $db->fetchAll(
                $db->select('option_index', ['COUNT(id)' => 'n'])
                    ->from('table.forum_poll_votes')
                    ->where('topic_id = ?', $coid)
                    ->group('option_index')
            );
            foreach ($rows as $r) {
                $votes[(int) $r['option_index']] = (int) $r['n'];
            }
        } catch (\Throwable $e) {
        }
        return $votes;
    }

    /** هش یکتای رأی‌دهنده (uid یا کوکی) */
    private static function voterHash(): string
    {
        try {
            $user = User::alloc();
            if ($user->hasLogin() && $user->uid) {
                return hash('sha256', 'u' . (int) $user->uid);
            }
        } catch (\Throwable $e) {
        }
        $cookieId = (string) Cookie::get('forumGuestId', '');
        if ($cookieId === '') {
            $cookieId = 'g' . bin2hex(random_bytes(8));
            Cookie::set('forumGuestId', $cookieId, time() + 31536000);
        }
        return hash('sha256', $cookieId);
    }

    /** ثبت یک رأی — برمی‌گرداند true یا false */
    public static function castPollVote(int $coid, int $optionIdx): bool
    {
        $poll = self::getPoll($coid);
        if ($poll === null || $optionIdx < 0 || $optionIdx >= count($poll['options'])) {
            return false;
        }
        $hash = self::voterHash();
        try {
            $db = Db::get();
            $exists = $db->fetchRow(
                $db->select('id')->from('table.forum_poll_votes')
                    ->where('topic_id = ? AND voter_hash = ?', $coid, $hash)
                    ->limit(1)
            );
            if ($exists) {
                return false; // قبلاً رأی داده
            }
            $db->query(
                $db->insert('table.forum_poll_votes')->rows([
                    'topic_id'     => $coid,
                    'option_index' => $optionIdx,
                    'voter_hash'   => $hash,
                    'created'      => time(),
                ])
            );
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** آیا این بازدیدکننده در این نظرسنجی رأی داده؟ */
    public static function hasVoted(int $coid): bool
    {
        $hash = self::voterHash();
        try {
            $db = Db::get();
            $exists = $db->fetchRow(
                $db->select('id')->from('table.forum_poll_votes')
                    ->where('topic_id = ? AND voter_hash = ?', $coid, $hash)
                    ->limit(1)
            );
            return !empty($exists);
        } catch (\Throwable $e) {
            // سازگاری با کوکی نسخهٔ قدیم
            return (string) Cookie::get('forumPollVote_' . $coid, '') !== '';
        }
    }

    // ====================================================================
    //  آمار
    // ====================================================================

    /** آیا آمار بازدید فعال است؟ */
    public static function viewsEnabled(): bool
    {
        return self::opt('enableViews', '1') !== '0';
    }

    /** آیا لایت‌باکس تصاویر فعال است؟ */
    public static function lightboxEnabled(): bool
    {
        return self::opt('enableLightbox', '1') !== '0';
    }

    // ====================================================================
    //  فیلتر کلمات (سانسور خودکار) — ۲.۲.۰
    // ====================================================================

    /**
     * فهرست قوانین فیلتر کلمات — هر قانون ['from' => ..., 'to' => ...].
     *
     * فرمت تنظیمات: هر سطر یک قانون به‌صورت «کلمه=جایگزین».
     * سطرهای خالی یا начиная با # نادیده گرفته می‌شوند (کامنت).
     * تطبیق case-insensitive و فقط کلمهٔ کامل (با مرز کلمه \b) انجام می‌شود.
     */
    public static function wordFilters(): array
    {
        $raw = (string) self::opt('wordFilters', '');
        if (trim($raw) === '') {
            return [];
        }
        $lines = preg_split('/\r\n|\r|\n/', $raw) ?: [];
        $out = [];
        foreach ($lines as $line) {
            $line = trim($line);
            // کامنت یا سطر خالی
            if ($line === '' || str_starts_with($line, '#')) {
                continue;
            }
            // جداسازی با اولین «=»
            $eqPos = strpos($line, '=');
            if ($eqPos === false) {
                continue; // بدون =، نادیده
            }
            $from = trim(substr($line, 0, $eqPos));
            $to = trim(substr($line, $eqPos + 1));
            if ($from === '') {
                continue;
            }
            $out[] = ['from' => $from, 'to' => $to];
        }
        return $out;
    }

    /**
     * اعمال فیلتر کلمات روی متن.
     *
     * - تطبیق case-insensitive و فقط کلمهٔ کامل (با مرز کلمه‌ی Unicode).
     * - اگر کلمهٔ جایگزین خالی باشد، کلمهٔ اصلی با کاراکترهای * جایگزین می‌شود
     *   (مثلاً «badword» → «*******» به همان طول).
     * - از فلگ u برای UTF-8 (پشتیبانی از کلمات فارسی) و i برای case-insensitive.
     * - به‌جای \b (که در PCRE فقط برای ASCII مطمئن است)، از lookarounds صریح
     *   برای letter/number/underscore استفاده می‌شود تا با حروف فارسی هم درست
     *   کار کند: (?<![\p{L}\p{N}_]) و (?![\p{L}\p{N}_]).
     * - اگر کلمه شامل کاراکترهای regex خاص باشد، با preg_quote ایمن می‌شود.
     * - از preg_replace_callback استفاده می‌شود تا جایگزین به‌صورت literal
     *   رفتار کند (بدون تفسیر backreference مثل $1 یا \1).
     *
     * @param string $text متن ورودی
     * @return متن فیلترشده
     */
    public static function applyWordFilters(string $text): string
    {
        $filters = self::wordFilters();
        if (empty($filters)) {
            return $text;
        }
        foreach ($filters as $f) {
            $from = (string) $f['from'];
            $to = (string) $f['to'];
            // اگر جایگزین خالی است، با ستاره‌های هم‌طول کلمه جایگزین کن
            if ($to === '') {
                $to = str_repeat('*', max(1, mb_strlen($from)));
            }
            // pattern: مرز کلمه‌ی Unicode + کلمه‌ی escape‌شده + مرز کلمه‌ی Unicode،
            // case-insensitive، UTF-8.
            // \p{L} = حروف همهٔ اسکریپت‌ها (فارسی، عربی، لاتین و ...),
            // \p{N} = اعداد همهٔ اسکریپت‌ها، _ = underscore.
            $pattern = '/(?<![\p{L}\p{N}_])' . preg_quote($from, '/') . '(?![\p{L}\p{N}_])/iu';
            // از preg_replace_callback استفاده می‌کنیم تا $to به‌صورت literal
            // رفتار کند (بدون تفسیر $1 یا \1 به‌عنوان backreference).
            $replacement = $to;
            $text = preg_replace_callback(
                $pattern,
                function () use ($replacement) {
                    return $replacement;
                },
                $text
            );
        }
        return $text;
    }

    /** آیا فیلتر کلمات فعال است (حداقل یک قانون دارد)؟ */
    public static function wordFiltersEnabled(): bool
    {
        return !empty(self::wordFilters());
    }


    // ------------------------------------------------------------------
    //  تیکر خبری اطلاع‌رسانی (announce-bar) — ۲.۲.۰ [حذف شد]
    // ------------------------------------------------------------------
    //  تیکر خبری در ۲.۲.۰ حذف شد. متدها به‌صورت no-op نگه داشته شده‌اند
    //  تا هر کد قدیمی که هنوز به آن‌ها ارجاع می‌دهد (مثلاً commonContext)
    //  به‌درستی کار کند و آرایهٔ خالی برگرداند.
    // ------------------------------------------------------------------

    /** آیا نوار اطلاع‌رسانی فعال است؟ — ۲.۲.۰: همیشه false (تیکر حذف شد) */
    public static function announceEnabled(): bool
    {
        return false;
    }

    /**
     * پیام‌های تیکر خبری — ۲.۲.۰: همیشه [] (تیکر حذف شد)
     */
    public static function announceMessages(): array
    {
        return [];
    }

    /** پیام‌های آمادهٔ نمایش تیکر — ۲.۲.۰: همیشه [] (تیکر حذف شد) */
    public static function announceItems(): array
    {
        return [];
    }

    /** آمار کلی انجمن */
    public static function forumStats(): array
    {
        if (self::$statsCache !== null) {
            return self::$statsCache;
        }

        $stats = ['questions' => 0, 'answers' => 0, 'members' => 0];

        try {
            $db = Db::get();
            $stats['questions'] = (int) $db->fetchObject(
                $db->select(['COUNT(id)' => 'n'])->from('table.forum_topics')
                    ->where('status = ?', 'approved')
            )->n;

            $stats['answers'] = (int) $db->fetchObject(
                $db->select(['COUNT(id)' => 'n'])->from('table.forum_posts')
                    ->where('status = ?', 'approved')
            )->n;
        } catch (\Throwable $e) {
            // آمار حیاتی نیست
        }

        try {
            $db = Db::get();
            $stats['members'] = (int) $db->fetchObject(
                $db->select(['COUNT(uid)' => 'n'])->from('table.users')
            )->n;
        } catch (\Throwable $e) {
            // آمار حیاتی نیست
        }

        return self::$statsCache = $stats;
    }

    /** شمار پرسش‌ها و پاسخ‌های در انتظار تأیید — برای نوار اعلان مدیر */
    public static function pendingCount(): int
    {
        try {
            $db = Db::get();
            $t = (int) $db->fetchObject(
                $db->select(['COUNT(id)' => 'n'])->from('table.forum_topics')
                    ->where('status = ?', 'waiting')
            )->n;
            $p = (int) $db->fetchObject(
                $db->select(['COUNT(id)' => 'n'])->from('table.forum_posts')
                    ->where('status = ?', 'waiting')
            )->n;
            return $t + $p;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /** شمار نشست‌های فعال (برای نمایش احتیاطی — اگر جدول sessions موجود باشد) */
    public static function onlineCount(): int
    {
        try {
            $db = Db::get();
            return (int) $db->fetchObject(
                $db->select(['COUNT(*)' => 'n'])->from('table.sessions')
                    ->where('expires > ?', time())
            )->n;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /** آمار شخصی یک عضو: موضوع، بهترین‌پاسخ، امتیاز */
    public static function userStats(int $uid): array
    {
        $stats = ['questions' => 0, 'answers' => 0, 'bestAnswers' => 0, 'score' => 0, 'likes' => 0];
        if ($uid < 1) {
            return $stats;
        }

        try {
            $db = Db::get();

            $stats['questions'] = (int) $db->fetchObject(
                $db->select(['COUNT(id)' => 'n'])->from('table.forum_topics')
                    ->where('author_id = ? AND status = ?', $uid, 'approved')
            )->n;

            $stats['answers'] = (int) $db->fetchObject(
                $db->select(['COUNT(id)' => 'n'])->from('table.forum_posts')
                    ->where('author_id = ? AND status = ?', $uid, 'approved')
            )->n;

            // شمار بهترین‌پاسخ‌ها: پاسخ‌های این کاربر که بهترین انتخاب شده‌اند
            $stats['bestAnswers'] = (int) $db->fetchObject(
                $db->select(['COUNT(table.forum_posts.id)' => 'n'])
                    ->from('table.forum_posts')
                    ->join('table.forum_topics', 'table.forum_topics.id = table.forum_posts.topic_id', Db::LEFT_JOIN)
                    ->where('table.forum_posts.author_id = ? AND table.forum_posts.status = ? AND table.forum_topics.best_post_id = table.forum_posts.id', $uid, 'approved')
            )->n;

            $stats['score'] = self::computeScore(
                $stats['questions'],
                $stats['answers'],
                $stats['bestAnswers']
            );

            // پسندهای دریافتی (۲.۰.۰) — روی پرسش‌ها و پاسخ‌های این کاربر
            $stats['likes'] = self::likesReceived($uid);
        } catch (\Throwable $e) {
            // آمار حیاتی نیست
        }

        return $stats;
    }

    /** امتیاز هر موضوع (پرسش) — از تنظیمات خوانده می‌شود */
    public static function scorePerQuestion(): int
    {
        return max(0, (int) self::opt('scoreQuestion', (string) self::DEFAULT_SCORE_QUESTION));
    }

    /** امتیاز هر پاسخ — از تنظیمات خوانده می‌شود */
    public static function scorePerAnswer(): int
    {
        return max(0, (int) self::opt('scoreAnswer', (string) self::DEFAULT_SCORE_ANSWER));
    }

    /** امتیاز اضافی هر بهترین‌پاسخ — از تنظیمات خوانده می‌شود */
    public static function scorePerBest(): int
    {
        return max(0, (int) self::opt('scoreBest', (string) self::DEFAULT_SCORE_BEST));
    }

    /** محاسبهٔ امتیاز بر اساس شمارش‌ها و تنظیمات کاربر */
    public static function computeScore(int $questions, int $answers, int $bestAnswers): int
    {
        return $questions * self::scorePerQuestion()
            + $answers * self::scorePerAnswer()
            + $bestAnswers * self::scorePerBest();
    }

    // ====================================================================
    //  خوانده‌شدن و بازدید — کوکی‌محور (مثل نسخهٔ قدیم)
    // ====================================================================

    /** فهرست coidهای دیده‌شدهٔ این بازدیدکننده (از کوکی) */
    public static function viewedList(): array
    {
        return array_values(array_filter(explode(',', (string) Cookie::get(self::VIEWS_COOKIE, ''))));
    }

    /**
     * نگاشت coid => timestamp آخرین خواندن (از کوکی).
     * فرمت کوکی: coid:timestamp,coid:timestamp,...
     * سازگاری با نسخه‌های پیشین: ورودی‌های بدون «:» به‌عنوان coid با
     * timestamp = زمان فعلیِ درخواست تفسیر می‌شوند (مهاجرت تنبل).
     *
     * @return array<int,int>  coid => last_read_timestamp
     */
    public static function readMap(): array
    {
        if (self::$readMapCache !== null) {
            return self::$readMapCache;
        }

        $raw = (string) Cookie::get(self::READS_COOKIE, '');
        $map = [];
        $now = time();
        $dirty = false;

        foreach (explode(',', $raw) as $entry) {
            $entry = trim($entry);
            if ($entry === '') {
                continue;
            }

            // فرمت جدید: coid:timestamp
            if (str_contains($entry, ':')) {
                $parts = explode(':', $entry, 2);
                $coidStr = trim($parts[0]);
                $tsStr = trim($parts[1]);
                if (ctype_digit($coidStr) && ctype_digit($tsStr)) {
                    $map[(int) $coidStr] = (int) $tsStr;
                }
                continue;
            }

            // فرمت قدیمی: فقط coid — مهاجرت تنبل به timestamp = اکنون
            if (ctype_digit($entry)) {
                $map[(int) $entry] = $now;
                $dirty = true;
            }
        }

        // اگر ورودی قدیمی داشت، یک‌بار کوکی را به فرمت جدید ارتقا بده
        if ($dirty) {
            self::persistReadMap($map);
        }

        return self::$readMapCache = $map;
    }

    /** نگاشت قدیمی readList — برای سازگاری با کدهای بیرونی */
    public static function readList(): array
    {
        return array_map('strval', array_keys(self::readMap()));
    }

    /**
     * آخرین فعالیت یک تاپیک (پرسش) — max(زمان ساخت پرسش، زمان آخرین پاسخ تأییدشده)
     */
    public static function threadLastActivity(int $coid): int
    {
        if ($coid < 1) {
            return 0;
        }
        if (isset(self::$lastActivityCache[$coid])) {
            return self::$lastActivityCache[$coid];
        }

        try {
            $topic = self::topicById($coid);
            if ($topic === null) {
                return self::$lastActivityCache[$coid] = 0;
            }

            $lastActivity = (int) $topic['created'];

            $db = Db::get();
            $replyAgg = $db->fetchRow(
                $db->select(['MAX(created)' => 'last'])
                    ->from('table.forum_posts')
                    ->where('topic_id = ? AND status = ?', $coid, 'approved')
            );
            if (!empty($replyAgg['last'])) {
                $lastActivity = max($lastActivity, (int) $replyAgg['last']);
            }

            return self::$lastActivityCache[$coid] = $lastActivity;
        } catch (\Throwable $e) {
            return self::$lastActivityCache[$coid] = 0;
        }
    }

    /**
     * آیا این پرسش توسط بازدیدکننده خوانده شده است؟
     */
    public static function isRead(int $coid, ?int $lastActivity = null): bool
    {
        $map = self::readMap();
        if (!isset($map[$coid])) {
            // پرسش تازه است یا کاربر هنوز ندیده ← خوانده‌نشده
            return false;
        }

        if ($lastActivity === null) {
            $lastActivity = self::threadLastActivity($coid);
        }

        // اگر آخرین خواندن قبل از آخرین فعالیت تاپیک باشد ← خوانده‌نشده
        return $map[$coid] >= $lastActivity;
    }

    /**
     * ثبت خوانده‌شدن یک پرسش در کوکی.
     */
    public static function markRead(int $coid, ?int $atTime = null): void
    {
        if ($coid < 1) {
            return;
        }
        $atTime = $atTime ?? time();

        $map = self::readMap();
        // اگر قبلاً در زمانی برابر یا بعد از این ثبت شده، نیازی به نوشتن دوباره نیست
        if (isset($map[$coid]) && $map[$coid] >= $atTime) {
            return;
        }

        $map[$coid] = $atTime;

        // نگه‌داری فقط READS_MAP_MAX مورد اخیر — کوکی‌های مرورگر محدود به ~4KB هستند
        if (count($map) > self::READS_MAP_MAX) {
            arsort($map); // نزولی بر اساس timestamp
            $map = array_slice($map, 0, self::READS_MAP_MAX, true);
        }

        self::persistReadMap($map);
        // به‌روزرسانی کش درخواست
        self::$readMapCache = $map;
    }

    /** نوشتن نگاشت خوانده‌شده‌ها در کوکی به فرمت coid:timestamp */
    private static function persistReadMap(array $map): void
    {
        $parts = [];
        foreach ($map as $coid => $ts) {
            $parts[] = $coid . ':' . (int) $ts;
        }
        Cookie::set(self::READS_COOKIE, implode(',', $parts), time() + 31536000);
    }

    /**
     * شمارش یک بازدید پرسش — بر اساس هر کلیک (۲.۱.۰).
     *
     * هر بار که صفحهٔ یک پرسش باز می‌شود، شمارندهٔ بازدید یک واحد افزایش
     * می‌یابد. دیگر یکتاسازی بر اساس کاربر یا بازهٔ زمانی اعمال نمی‌شود
     * و بازدید مدیران و مهمانان هم شمرده می‌شود.
     */
    public static function countThreadView(int $coid, int $authorId = 0): bool
    {
        if (!self::viewsEnabled() || $coid < 1) {
            return false;
        }
        // (۲.۱.۰) هر کلیک شمرده می‌شود — یکتاسازی بر اساس کوکی یا بازهٔ زمانی حذف شد.
        try {
            $db = Db::get();
            $db->query(
                $db->update('table.forum_topics')
                    ->rows(['views' => Db::expr('views + 1')])
                    ->where('id = ?', $coid)
            );
        } catch (\Throwable $e) {
            try {
                // fallback: خواندن و نوشتن مقدار (سازگار با SQLite قدیمی)
                $topic = self::topicById($coid);
                if ($topic !== null) {
                    $db->query(
                        $db->update('table.forum_topics')
                            ->rows(['views' => (int) ($topic['views'] ?? 0) + 1])
                            ->where('id = ?', $coid)
                    );
                }
            } catch (\Throwable $e2) {
                // آمار بازدید حیاتی نیست
            }
        }

        return true;
    }

    // ====================================================================
    //  متای کاربر (درباره + شبکه‌های اجتماعی) — users.meta با fallback
    // ====================================================================

    /** کش نام/ایمیل/وب کاربران در طول درخواست — برای جلوگیری از کوئری تکراری */
    private static ?array $liveUserCache = null;

    /**
     * (۲.۱.۰) خواندن زندهٔ نام/ایمیل/وب کاربر از جدول users.
     * اگر uid < 1 یا کاربر یافت نشد، null برمی‌گرداند تا فراخواننده از
     * مقادیر ذخیره‌شده در forum_topics/forum_posts استفاده کند.
     * نتایج در طول درخواست کش می‌شوند تا برای هر ردیف کوئری نزند.
     *
     * @return array|null  ['name'=>string, 'mail'=>string, 'url'=>string]
     */
    private static function liveUserFields(int $uid): ?array
    {
        if ($uid < 1) {
            return null;
        }
        if (self::$liveUserCache === null) {
            self::$liveUserCache = [];
        }
        if (isset(self::$liveUserCache[$uid])) {
            return self::$liveUserCache[$uid];
        }
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('screenName', 'name', 'mail', 'url')
                    ->from('table.users')
                    ->where('uid = ?', $uid)
                    ->limit(1)
            );
            if ($row) {
                $name = trim((string) ($row['screenName'] ?: $row['name']));
                self::$liveUserCache[$uid] = [
                    'name' => $name !== '' ? $name : (string) $row['name'],
                    'mail' => (string) $row['mail'],
                    'url'  => (string) $row['url'],
                ];
                return self::$liveUserCache[$uid];
            }
        } catch (\Throwable $e) {
            // بی‌اثر
        }
        self::$liveUserCache[$uid] = null;
        return null;
    }

    /**
     * (۲.۱.۰) wrapper عمومی برای خواندن زندهٔ نام/ایمیل/وب کاربر.
     * برای استفاده در ForumList و سایر کنترلرها.
     *
     * @return array|null  ['name'=>string, 'mail'=>string, 'url'=>string]
     */
    public static function liveUserFieldsForList(int $uid): ?array
    {
        return self::liveUserFields($uid);
    }

    /**
     * خواندن فیلد meta یک کاربر به‌صورت آرایه.
     */
    public static function getUserMeta(int $uid): array
    {
        if ($uid < 1) {
            return [];
        }
        try {
            $db = Db::get();
            // اول از فیلد meta جدول users بخوان
            $row = $db->fetchRow(
                $db->select('meta')->from('table.users')
                    ->where('uid = ?', $uid)->limit(1)
            );
            $meta = (string) ($row['meta'] ?? '');
            if ($meta !== '') {
                $decoded = @unserialize($meta);
                if (is_array($decoded)) {
                    return $decoded;
                }
            }
            // اگر نبود، از options بخوان (fallback)
            $optName = 'ext:Forum-user-meta-' . $uid;
            $optVal = self::readOptionValue($optName);
            if ($optVal !== '') {
                $decoded = @unserialize($optVal);
                if (is_array($decoded)) {
                    return $decoded;
                }
            }
            return [];
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * ذخیرهٔ فیلد meta یک کاربر — meta فعلی با مقادیر جدید ادغام می‌شود.
     * فقط فیلدهای مجاز (bio, twitter, github, telegram, instagram, linkedin) ذخیره می‌شوند.
     */
    public static function updateUserMeta(int $uid, array $newValues): bool
    {
        if ($uid < 1) {
            return false;
        }
        $allowed = ['bio', 'twitter', 'github', 'telegram', 'instagram', 'linkedin', 'youtube'];
        $current = self::getUserMeta($uid);
        foreach ($allowed as $key) {
            if (array_key_exists($key, $newValues)) {
                $val = trim((string) $newValues[$key]);
                // اعتبارسنجی ساده برای URLها — اگر پر باشد باید http/https داشته باشد
                if ($key !== 'bio' && $val !== '' && !preg_match('#^https?://#i', $val)) {
                    $val = 'https://' . ltrim($val, '/');
                }
                $current[$key] = mb_substr($val, 0, 255);
            }
        }

        try {
            $db = Db::get();
            $serialized = serialize($current);

            // چک کن آیا سطر کاربر وجود دارد
            $exists = $db->fetchRow(
                $db->select('uid')->from('table.users')
                    ->where('uid = ?', $uid)->limit(1)
            );
            if (!$exists) {
                return false;
            }

            // اگر فیلد meta وجود ندارد یا TEXT نیست، در options ذخیره کن
            try {
                $db->query(
                    $db->update('table.users')->rows(['meta' => $serialized])
                        ->where('uid = ?', $uid)
                );
            } catch (\Throwable $metaErr) {
                // اگر ستون meta نبود یا خطا داد، در options ذخیره کن
                self::writeOptionValue('ext:Forum-user-meta-' . $uid, $serialized);
            }

            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    // ====================================================================
    //  ویرایش — دسترسی نویسنده و مهلت مهمان
    // ====================================================================

    /** مهلت ویرایش مهمان بر حسب دقیقه (صفر = خاموش) */
    public static function guestEditMinutes(): int
    {
        $m = (int) self::opt('guestEditMinutes', '5');
        return max(0, min(120, $m));
    }

    /** امضای مالکیت یک نوشتهٔ مهمان (HMAC سایت) */
    public static function guestSig(int $coid): string
    {
        return hash_hmac('sha256', 'forum-guest-' . $coid, (string) Options::alloc()->secret);
    }

    /** افزودن یک نوشتهٔ تازه به کوکی مالکیت مهمان */
    public static function rememberGuestPost(int $coid): void
    {
        $minutes = self::guestEditMinutes();
        if ($minutes < 1 || $coid < 1) {
            return;
        }

        $entries = self::guestEntries();

        // فقط نگه‌داشتن ورودی‌های معتبر و تازه
        $entries = array_values(array_filter($entries, static function ($e) {
            return isset($e[0]);
        }));
        $entries[] = [$coid, self::guestSig($coid)];
        $entries = array_slice($entries, -50);

        $parts = [];
        foreach ($entries as $e) {
            $parts[] = $e[0] . '.' . $e[1];
        }

        Cookie::set(self::GUEST_COOKIE, implode(',', $parts), time() + $minutes * 60 + 60);
    }

    /**
     * فهرست نوشته‌های مهمانِ این مرورگر — هر عنصر [coid, sig]
     * @return array<int, array{0:int,1:string}>
     */
    public static function guestEntries(): array
    {
        $raw = (string) Cookie::get(self::GUEST_COOKIE, '');
        $out = [];
        foreach (explode(',', $raw) as $item) {
            if (preg_match('/^(\d+)\.([a-f0-9]{64})$/', trim($item), $m)) {
                $coid = (int) $m[1];
                $sig = $m[2];
                if (hash_equals(self::guestSig($coid), $sig)) {
                    $out[] = [$coid, $sig];
                }
            }
        }
        return $out;
    }

    /**
     * آیا بازدیدکنندهٔ فعلی اجازهٔ ویرایش این پرسش/پاسخ را دارد؟
     *  - مدیر انجمن: بله
     *  - کاربر واردشده: فقط نوشته‌های خودش (authorId)
     *  - مهمان: فقط نوشته‌های خودش و تا پایان مهلت (پیش‌فرض ۵ دقیقه)
     */
    public static function canEdit(array $row): bool
    {
        if (empty($row)) {
            return false;
        }

        if (self::canManage()) {
            return true;
        }

        try {
            $user = User::alloc();
            $uid = ($user->hasLogin() && $user->uid) ? (int) $user->uid : 0;
        } catch (\Throwable $e) {
            $uid = 0;
        }

        $authorId = (int) ($row['authorId'] ?? 0);
        $coid = (int) ($row['coid'] ?? 0);
        $created = (int) ($row['created'] ?? 0);

        // نوشتهٔ عضو: فقط خودِ عضو
        if ($authorId > 0) {
            return $uid > 0 && $uid === $authorId;
        }

        // نوشتهٔ مهمان: کوکی مالکیت + مهلت زمانی
        if ($uid === 0 && $coid > 0) {
            $minutes = self::guestEditMinutes();
            if ($minutes < 1) {
                return false;
            }
            if (time() - $created > $minutes * 60) {
                return false;
            }
            foreach (self::guestEntries() as $e) {
                if ($e[0] === $coid) {
                    return true;
                }
            }
        }

        return false;
    }

    // ====================================================================
    //  درج خودکار پیوند انجمن در منوی اصلی — هوک header
    // ====================================================================

    /**
     * تزریق اسکریپت منو در <head> صفحات پوسته — پیوند «انجمن» به
     * فهرست‌های ناوبری استاندارد (ul.nav-menu و مانند آن) اضافه می‌شود.
     */
    public static function headerInject(string $header, \Widget\Archive $archive): void
    {
        if (self::opt('menuLink', '1') === '0') {
            return;
        }

        try {
            $url = self::forumUrl();
        } catch (\Throwable $e) {
            return;
        }

        $label = trim((string) self::opt('menuLabel', 'انجمن'));
        if ($label === '') {
            $label = 'انجمن';
        }

        $json = json_encode(
            ['url' => $url, 'label' => $label],
            JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
        );
        if (!is_string($json)) {
            return;
        }

        echo '<script data-forum-menu-inject>(function () {'
            . 'var CFG=' . $json . ';'
            . 'function injectForumMenu(){'
            . 'var menus=document.querySelectorAll("ul.nav-menu,header nav ul,.site-nav ul,nav.main-nav ul,#nav ul,.main-menu ul");'
            . 'for(var i=0;i<menus.length;i++){var m=menus[i];'
            . 'if(!m||m.getAttribute("data-forum-menu")){continue;}'
            . 'm.setAttribute("data-forum-menu","1");'
            . 'var li=document.createElement("li");li.setAttribute("role","none");'
            . 'var a=document.createElement("a");a.setAttribute("role","menuitem");a.href=CFG.url;a.textContent=CFG.label;'
            . 'var path=window.location.pathname.replace(/\\/$/,"");var furl=CFG.url.replace(/^https?:\/\/[^\/]+/,"").replace(/\\/$/,"");'
            . 'if(furl&&path===furl){a.className="active";a.setAttribute("aria-current","page");}'
            . 'else if(furl&&furl!==""&&path.indexOf(furl)===0){a.className="active";a.setAttribute("aria-current","page");}'
            . 'li.appendChild(a);m.appendChild(li);}'
            . '}'
            . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",injectForumMenu);}'
            . 'else{injectForumMenu();}'
            // تزریق مجدد پس از تأخیر کوتاه — برای اطمینان از تزریق حتی اگر DOM دیرتر آماده شود
            . 'setTimeout(injectForumMenu,100);'
            . 'setTimeout(injectForumMenu,500);'
            . 'setTimeout(injectForumMenu,1500);'
            . '})();</script>' . "\n";
    }

    // ====================================================================
    //  سازگاری با RenewShield — هوک footer
    // ====================================================================

    /** پرچم یک‌باره برای جلوگیری از فراخوانی دوبارهٔ Guard::footer */
    private static bool $renewShieldPrepared = false;

    /**
     * روی صفحات انجمن که فرم کامنت دارند (Thread و ForumList)،
     * Guard::footer مربوط به RenewShield را اجرا می‌کند تا cookie و state
     * مورد نیاز برای عبور از بررسی «زمینهٔ صفحه» ست شود.
     *
     * پیش‌زمینه:
     * RenewShield در Guard::footer فقط روی صفحاتی که is('single') باشد،
     * یک token در cookie می‌گذارد و یک رکورد state با کلید
     * comment:view:<hash(ip|ua|cid)> ثبت می‌کند. سپس در Guard::comment
     * هنگام ارسال کامنت، این cookie/state را راستی‌آزمایی می‌کند؛ اگر
     * نباشد، خطای «درخواست نظر فاقد زمینهٔ معتبر صفحه است» می‌دهد.
     *
     * صفحات انجمن archiveType='forum' دارند (نه 'single')، پس Guard::footer
     * به‌صورت پیش‌فرض روی آن‌ها کار نمی‌کند. این متد، موقتاً archiveType
     * را روی 'single' و cid آرشیو را روی مقداری که Post.php هنگام ارسال
     * به filter('comment', ...) می‌فرستد، قرار می‌دهد، Guard::footer را
     * صدا می‌زند، سپس archiveType اصلی را بازمی‌گرداند.
     *
     * نکتهٔ مهم: cid که اینجا ست می‌شود دقیقاً همان cid است که Post.php
     * هنگام ارسال در $_content->cid قرار می‌دهد:
     *   - برای پاسخ (Thread): cid = coid تاپیک از URL
     *   - برای پرسش جدید (ForumList): cid = UID بیننده یا هش پایدار IP
     * بنابراین token.ctx در زمان بازدید با expectedContext در زمان ارسال
     * مطابقت دارد و مکانیزم امنیتی RenewShield بدون دور زدن، روی درخواست
     * انجمن اعمال می‌شود.
     *
     * این متد هم از هوک footer (ثبت‌شده در activate) و هم از فراخوانی
     * مستقیم در ForumPage::renderForumPage صدا زده می‌شود. پرچم
     * $renewShieldPrepared از فراخوانی دوباره جلوگیری می‌کند.
     *
     * هیچ فایل/کد RenewShield تغییر نمی‌کند؛ فقط Guard::footer از مسیر
     * عمومی‌اش فراخوانی می‌شود.
     */
    public static function footerHook(\Widget\Archive $archive): void
    {
        self::prepareRenewShieldContext($archive);
    }

    /**
     * آماده‌سازی زمینهٔ RenewShield روی صفحات انجمن.
     * این متد مستقیماً از ForumPage::renderForumPage صدا زده می‌شود
     * (بدون وابستگی به ثبت هوک یا قالب).
     */
    public static function prepareRenewShieldContext(\Widget\Archive $archive): void
    {
        // جلوگیری از فراخوانی دوباره در همان درخواست
        if (self::$renewShieldPrepared) {
            return;
        }

        // فقط روی صفحات انجمن که فرم کامنت دارند
        if (!($archive instanceof \TypechoPlugin\Forum\ForumPage)) {
            return;
        }

        // RenewShield باید نصب باشد
        if (!class_exists('\TypechoPlugin\RenewShield\Guard')) {
            return;
        }

        // تعیین cid که در زمان ارسال به filter('comment', ...) داده می‌شود
        // (باید با منطق Post.php خط ۳۸۳–۳۹۸ یکسان باشد)
        if ($archive instanceof \TypechoPlugin\Forum\Thread) {
            // صفحهٔ پاسخ به پرسش: cid = شناسهٔ تاپیک از URL
            $coid = (int) ($archive->request->get('coid') ?: 0);
            if ($coid <= 0) {
                return;
            }
            $cid = $coid;
        } elseif ($archive instanceof \TypechoPlugin\Forum\ForumList) {
            // صفحهٔ پرسش جدید: cid = UID بیننده یا هش پایدار IP
            $viewerUid = self::viewerUid();
            if ($viewerUid > 0) {
                $cid = $viewerUid;
            } else {
                try {
                    $ip = (string) $archive->request->getIp();
                } catch (\Throwable $e) {
                    $ip = '';
                }
                $cid = max(1, abs(crc32($ip)));
            }
        } else {
            // سایر صفحات انجمن (پروفایل، دسته‌بندی، پیام‌ها) فرم کامنت ندارند
            return;
        }

        if ($cid <= 0) {
            return;
        }

        // Guard::footer فقط روی is('single') اجرا می‌شود؛ موقتاً archiveType
        // و cid را تنظیم می‌کنیم، سپس archiveType اصلی را بازمی‌گردانیم تا
        // سایر هوک‌ها/قالب‌ها رفتار طبیعی ببینند.
        $oldType = (string) $archive->getArchiveType();
        if ($oldType === '') {
            $oldType = 'forum';
        }

        try {
            $archive->setArchiveType('single');
            $archive->cid = $cid;
            \TypechoPlugin\RenewShield\Guard::footer($archive);
        } catch (\Throwable $e) {
            // در صورت بروز خطا، بی‌اثر است — فقط log
            error_log('[Forum] prepareRenewShieldContext: ' . $e->getMessage());
        } finally {
            $archive->setArchiveType($oldType);
        }

        self::$renewShieldPrepared = true;
    }

    // ====================================================================
    //  تاریخ شمسی
    // ====================================================================

    /** میلادی → جلالی (الگوریتم استاندارد jdf) */
    private static function toJalali(int $gy, int $gm, int $gd): array
    {
        $gDm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];

        $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
        $days = 355666 + (365 * $gy)
            + intdiv($gy2 + 3, 4) - intdiv($gy2 + 99, 100) + intdiv($gy2 + 399, 400)
            + $gd + $gDm[$gm - 1];

        $jy = -1595 + (33 * intdiv($days, 12053));
        $days %= 12053;
        $jy += 4 * intdiv($days, 1461);
        $days %= 1461;

        if ($days > 365) {
            $jy += intdiv($days - 1, 365);
            $days = ($days - 1) % 365;
        }

        if ($days < 186) {
            $jm = 1 + intdiv($days, 31);
            $jd = 1 + ($days % 31);
        } else {
            $jm = 7 + intdiv($days - 186, 30);
            $jd = 1 + (($days - 186) % 30);
        }

        return [$jy, $jm, $jd];
    }

    /** تاریخ شمسی «۱۲ شهریور ۱۴۰۵» با احتساب منطقهٔ زمانی سایت */
    public static function jalali(int $timestamp): string
    {
        $dt = \Utils\Zone::dateTime($timestamp);
        [$jy, $jm, $jd] = self::toJalali((int) $dt->format('Y'), (int) $dt->format('n'), (int) $dt->format('j'));
        return self::faDigits($jd) . ' ' . self::J_MONTHS[$jm] . ' ' . self::faDigits($jy);
    }

    /** برچسب کوتاه روز شمسی «۱۲ شهریور» — برای محور نمودارها (۲.۰.۰) */
    public static function jalaliDayLabel(int $timestamp): string
    {
        $dt = \Utils\Zone::dateTime($timestamp);
        [, $jm, $jd] = self::toJalali((int) $dt->format('Y'), (int) $dt->format('n'), (int) $dt->format('j'));
        return self::faDigits($jd) . ' ' . self::J_MONTHS[$jm];
    }

    /** ساعت «۱۴:۳۰» با منطقهٔ زمانی سایت */
    public static function jalaliTime(int $timestamp): string
    {
        $dt = \Utils\Zone::dateTime($timestamp);
        return self::faDigits($dt->format('H:i'));
    }

    /** زمان نسبی فارسی یا تاریخ کامل برای موارد قدیمی‌تر از یک هفته */
    public static function faRelative(int $timestamp): string
    {
        $now = time();
        $diff = $now - $timestamp;

        if ($diff >= 0 && $diff < 60) {
            return 'چند لحظه پیش';
        }
        if ($diff >= 0 && $diff < 3600) {
            return self::faDigits((string) max(1, (int) round($diff / 60))) . ' دقیقه پیش';
        }
        if ($diff >= 0 && $diff < 86400) {
            return self::faDigits((string) max(1, (int) round($diff / 3600))) . ' ساعت پیش';
        }
        if ($diff >= 0 && $diff < 7 * 86400) {
            return self::faDigits((string) max(1, (int) round($diff / 86400))) . ' روز پیش';
        }

        return self::jalali($timestamp);
    }

    // ====================================================================
    //  متن و نشانه‌گذاری
    // ====================================================================

    /**
     * جداسازی «عنوان» (نخستین سطر) و «ادامهٔ متن» پرسش
     * @return array{0:string,1:string}
     */
    public static function splitQuestion(string $text): array
    {
        $text = trim(str_replace(["\r\n", "\r"], "\n", $text));
        $parts = preg_split('/\n/', $text, 2);
        $first = trim((string) ($parts[0] ?? ''));
        $rest = trim((string) ($parts[1] ?? ''));

        if ($first === '') {
            $first = 'پرسش بدون متن';
        }

        if (mb_strlen($first) > 90) {
            $head = mb_substr($first, 0, 90);
            $tail = mb_substr($first, 90);
            $rest = trim($tail . ($rest !== '' ? "\n" . $rest : ''));
            $first = $head;
        }

        return [$first, $rest];
    }

    /**
     * پاک‌کردن نشانه‌گذاری برای نمایش خلاصه (فهرست پرسش‌ها)
     */
    public static function stripMarkup(string $text): string
    {
        $text = str_replace(["\r\n", "\r"], "\n", $text);

        // بلوک کد → فقط نشان کوتاه
        $text = preg_replace('/\[code\]\n?(.*?)\n?\[\/code\]/s', ' [کد] ', $text);

        // پیوند → متن آن
        $text = preg_replace('/\[url=[^\]\n]*\]([^\n\[]*)\[\/url\]/', '$1', $text);

        // تصویر → نشان
        $text = preg_replace('/\[img\][^\[\]\n]*\[\/img\]/', ' [تصویر] ', $text);

        // نقل قول → محتوا
        $text = preg_replace('/\[quote=?[^\]\n]*\](.*?)\[\/quote\]/s', ' $1 ', $text);

        // کد درون‌خطی
        $text = str_replace('`', ' ', $text);

        $text = preg_replace('/[ \t]+/u', ' ', $text);
        $text = preg_replace('/\s*\n\s*/u', "\n", $text);

        return trim($text);
    }

    /** کوتاه‌کردن متن برای خلاصه */
    public static function excerpt(string $text, int $len = 130): string
    {
        $text = self::stripMarkup($text);
        if (mb_strlen($text) > $len) {
            $text = rtrim(mb_substr($text, 0, $len)) . '…';
        }
        return $text;
    }

    /**
     * خلاصهٔ برجسته‌شده برای نتایج جستجو:
     * بخشی از متن حول نخستین تطبیق با برچسب <mark> برمی‌گرداند.
     */
    public static function highlightExcerpt(string $text, string $keyword, int $len = 130): string
    {
        $plain = self::stripMarkup($text);
        $keyword = trim($keyword);

        if ($keyword === '') {
            return self::e(self::excerpt($plain, $len));
        }

        $pos = mb_stripos($plain, $keyword);
        if ($pos === false) {
            return self::e(self::excerpt($plain, $len));
        }

        $kwLen = mb_strlen($keyword);
        $half = max(20, (int) floor(($len - $kwLen) / 2));

        $start = max(0, $pos - $half);
        $prefix = '';
        if ($start > 0) {
            $prefix = '…';
            $plain = mb_substr($plain, $start);
            $pos -= $start;
        }

        $chunk = mb_substr($plain, 0, $pos + $kwLen + $half);
        if (mb_strlen($plain) > mb_strlen($chunk)) {
            $chunk .= '…';
        }

        $before = mb_substr($chunk, 0, $pos);
        $match = mb_substr($chunk, $pos, $kwLen);
        $after = mb_substr($chunk, $pos + $kwLen);

        return self::e($prefix . $before) . '<mark class="qa-mark">' . self::e($match) . '</mark>' . self::e($after);
    }

    /**
     * اعتبارسنجی نشانی برای قرارگرفتن در href/src — فقط http/https
     * (متن ورودی از قبل escape شده است؛ خروجی برای attribute آماده است)
     */
    private static function attrUrl(string $url): ?string
    {
        $url = trim($url);
        if ($url === '' || mb_strlen($url) > 600) {
            return null;
        }
        // (۲.۲.۰ رفع) متن ورودی از htmlspecialchars عبور کرده است، پس
        // &amp; و &quot; و &#039; ممکن است در URL باشند. آن‌ها را بازگردان.
        $url = str_replace(['&amp;', '&quot;', '&#039;', '&#39;'], ['&', '"', "'", "'"], $url);
        // (۲.۲.۰ رفع) اگر URL پروتکل نداشت ولی با دامنه‌ی معتبر شروع می‌شد،
        // https:// را به ابتدا اضافه کن. این برای URLهایی که imgurl یا سرویس‌های
        // دیگر بدون پروتکل برمی‌گردانند ضروری است.
        if (!preg_match('~^https?://[^\s]*$~i', $url)) {
            // الگوی دامنه: چیزی که با یک کلمه + نقطه شروع می‌شود (مثل cdn.imgurl.ir)
            if (preg_match('~^[a-z0-9][a-z0-9.-]*\.[a-z]{2,}(/[^\s]*)?$~i', $url)) {
                $url = 'https://' . $url;
            } else {
                return null;
            }
        }
        return $url;
    }

    /**
     * خروجی امن متن با نشانه‌گذاری Markdown (نسخهٔ ۲.۱.۰ — مهاجرت از BBCode به Markdown).
     *
     * از موتور Markdown خود TypeRenew (Utils\Markdown::convert که بر پایهٔ HyperDown است)
     * استفاده می‌کند. ویژگی‌های اضافی انجمن که HyperDown آن‌ها را ندارد:
     *  - [aparat]VIDEO_ID[/aparat] → iframe embed آپارات (pre-process)
     *  - تصاویر پشت‌سرهم → گالری خودکار grid (post-process)
     *  - افزودن کلاس qa-lightbox-img به همهٔ تصاویر (post-process)
     *  - افزودن rel=nofollow و target=_blank به لینک‌های خارجی (post-process)
     *  - افزودن کلاس qa-code به بلوک‌های کد (post-process)
     */
    public static function renderText(string $text): string
    {
        $text = str_replace(["\r\n", "\r"], "\n", $text);

        // ۱) pre-process: جایگزینی [aparat]VIDEO_ID[/aparat] با placeholder
        //    تا HyperDown آن را به‌عنوان HTML بلوکی قبول کند.
        $aparatPlaceholders = [];
        $text = (string) preg_replace_callback(
            '/\[aparat\]([A-Za-z0-9_-]+)\[\/aparat\]/',
            function ($m) use (&$aparatPlaceholders) {
                $vid = trim($m[1]);
                if ($vid === '' || !preg_match('/^[A-Za-z0-9_-]+$/', $vid)) {
                    return $m[0];
                }
                $html = '<div class="qa-aparat"><iframe src="https://www.aparat.com/video/video/embed/videohash/' . $vid . '/vt/frame" '
                    . 'allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true" '
                    . 'scrolling="no" frameborder="0" loading="lazy" referrerpolicy="no-referrer"></iframe></div>';
                $key = "\x01APARAT" . count($aparatPlaceholders) . "\x01";
                $aparatPlaceholders[$key] = $html;
                return $key;
            },
            $text
        );

        // ۲) رندر با موتور Markdown خود TypeRenew
        $html = Markdown::convert($text);

        // ۳) post-process: افزودن کلاس qa-lightbox-img به همهٔ تصاویر
        //    HyperDown خروجی <img src="..." alt="..."> می‌دهد؛ ما کلاس اضافه می‌کنیم.
        $html = (string) preg_replace_callback(
            '/<img\s+([^>]*?)>/i',
            function ($m) {
                $attrs = $m[1];
                // اگر قبلاً کلاس دارد، qa-lightbox-img را به آن اضافه کن
                if (preg_match('/class="([^"]*)"/i', $attrs, $cm)) {
                    $classes = $cm[1];
                    if (strpos($classes, 'qa-lightbox-img') === false) {
                        $classes = trim($classes . ' qa-lightbox-img qa-img');
                        $attrs = preg_replace('/class="[^"]*"/i', 'class="' . $classes . '"', $attrs);
                    }
                } else {
                    $attrs .= ' class="qa-img qa-lightbox-img"';
                }
                // اطمینان از وجود loading="lazy" و decoding="async"
                if (!preg_match('/loading=/i', $attrs)) {
                    $attrs .= ' loading="lazy"';
                }
                if (!preg_match('/decoding=/i', $attrs)) {
                    $attrs .= ' decoding="async"';
                }
                if (!preg_match('/referrerpolicy=/i', $attrs)) {
                    $attrs .= ' referrerpolicy="no-referrer"';
                }
                return '<img ' . $attrs . '>';
            },
            $html
        );

        // ۴) post-process: گالری خودکار — تصاویر پشت‌سرهم (هر کدام روی یک خط جدا)
        //    الگو: چند تگ <img> پشت‌سرهم که فقط whitespace بینشان است.
        $html = (string) preg_replace_callback(
            '/((?:\s*<img[^>]*>\s*(?:\n|$)){2,})/m',
            function ($m) {
                $block = (string) $m[1];
                preg_match_all('/<img[^>]*src="([^"]*)"[^>]*(?:alt="([^"]*)")?[^>]*>/i', $block, $imgMatches, PREG_SET_ORDER);
                $images = [];
                foreach ($imgMatches as $im) {
                    $url = $im[1];
                    $alt = $im[2] ?? '';
                    $images[] = ['url' => $url, 'alt' => $alt];
                }
                $count = count($images);
                if ($count < 2) {
                    return $m[0];
                }
                // منطق تعداد ستون
                if ($count === 2) { $cols = 2; }
                elseif ($count === 3) { $cols = 3; }
                elseif ($count === 4) { $cols = 2; }
                elseif ($count === 5) { $cols = 3; }
                elseif ($count === 6) { $cols = 3; }
                elseif ($count === 7) { $cols = 4; }
                elseif ($count === 8) { $cols = 4; }
                else { $cols = $count <= 9 ? 3 : 4; }
                $out = '<div class="qa-gallery qa-gallery-cols-' . $cols . ' qa-gallery-ratio-square" data-qa-gallery>';
                foreach ($images as $img) {
                    $altAttr = htmlspecialchars($img['alt'] !== '' ? $img['alt'] : 'تصویر گالری', ENT_QUOTES, 'UTF-8');
                    $out .= '<a href="' . htmlspecialchars($img['url'], ENT_QUOTES, 'UTF-8') . '" class="qa-gallery-item qa-lightbox-img" '
                        . 'data-qa-gallery-item data-qa-lightbox-group="gallery" '
                        . 'data-alt="' . $altAttr . '">'
                        . '<img src="' . htmlspecialchars($img['url'], ENT_QUOTES, 'UTF-8') . '" alt="' . $altAttr . '" loading="lazy" decoding="async" referrerpolicy="no-referrer">'
                        . '</a>';
                }
                $out .= '</div>';
                return $out;
            },
            $html
        );

        // ۵) post-process: افزودن rel=nofollow noopener و target=_blank به لینک‌های خارجی
        $html = (string) preg_replace_callback(
            '/<a\s+([^>]*?)>/i',
            function ($m) {
                $attrs = $m[1];
                // فقط لینک‌های خارجی (http/https) را تغییر بده
                if (!preg_match('/href="https?:\/\//i', $attrs)) {
                    return '<a ' . $attrs . '>';
                }
                if (!preg_match('/rel=/i', $attrs)) {
                    $attrs .= ' rel="nofollow noopener"';
                }
                if (!preg_match('/target=/i', $attrs)) {
                    $attrs .= ' target="_blank"';
                }
                if (!preg_match('/class=/i', $attrs)) {
                    $attrs .= ' class="qa-link"';
                }
                return '<a ' . $attrs . '>';
            },
            $html
        );

        // ۶) post-process: افزودن dir=ltr به بلوک‌های کد و کلاس qa-code
        $html = (string) preg_replace(
            '/<pre><code/',
            '<pre dir="ltr" class="qa-code"><code',
            $html
        );

        // ۷) بازگرداندن placeholder های آپارات
        foreach ($aparatPlaceholders as $key => $aparatHtml) {
            $html = str_replace($key, $aparatHtml, $html);
        }

        return $html;
    }

    // ------------------------------------------------------------------
    //  پیام‌های وضعیت
    // ------------------------------------------------------------------

    /**
     * پیام نوار وضعیت از پارامترهای نشانی (پس از ارسال، خطا، قفل و…)
     * @return array{0:string,1:string,2?:int}|null  [پیام, نوع, wait ثانیه (اختیاری)]
     */
    public static function statusBanner(): ?array
    {
        if (isset($_GET['e'])) {
            $msg = (string) $_GET['e'];
            // اگر پارامتر wait وجود دارد، شمارش معکوس زنده در ویو نمایش داده می‌شود
            $wait = isset($_GET['wait']) ? max(1, (int) $_GET['wait']) : 0;
            if ($wait > 0) {
                return [$msg, 'error', $wait];
            }
            return [$msg, 'error'];
        }
        if (($_GET['posted'] ?? '') === '1') {
            return ['ثبت شد؛ با سپاس از مشارکت شما.', 'ok'];
        }
        if (($_GET['posted'] ?? '') === 'waiting') {
            return ['ثبت شد؛ پس از تأیید مدیر، برای همه نمایش عمومی می‌یابد.', 'waiting'];
        }
        if (($_GET['approved'] ?? '') === '1') {
            return ['نوشتهٔ موردنظر تأیید شد و اکنون برای همه نمایش داده می‌شود.', 'ok'];
        }
        if (($_GET['locked'] ?? '') === '1') {
            return ['این پرسش قفل شد؛ امکان نوشتن پاسخ جدید نیست.', 'ok'];
        }
        if (($_GET['unlocked'] ?? '') === '1') {
            return ['قفل این پرسش باز شد؛ می‌توانید پاسخ جدید بنویسید.', 'ok'];
        }
        if (($_GET['pinned'] ?? '') === '1') {
            return ['این پرسش سنجاق شد و همیشه بالای فهرست می‌ماند.', 'ok'];
        }
        if (($_GET['unpinned'] ?? '') === '1') {
            return ['سنجاق این پرسش برداشته شد.', 'ok'];
        }
        if (($_GET['tracked'] ?? '') === '1') {
            return ['وضعیت «در حال پیگیری» برای این پرسش فعال شد.', 'ok'];
        }
        if (($_GET['untracked'] ?? '') === '1') {
            return ['وضعیت «در حال پیگیری» برای این پرسش غیرفعال شد.', 'ok'];
        }
        if (($_GET['hidden'] ?? '') === '1') {
            return ['این پرسش از دید کاربران مهمان پنهان شد.', 'ok'];
        }
        if (($_GET['unhidden'] ?? '') === '1') {
            return ['این پرسش دوباره برای کاربران مهمان نمایش داده می‌شود.', 'ok'];
        }
        if (($_GET['deleted'] ?? '') === '1') {
            return ['پرسش/پاسخ حذف شد.', 'ok'];
        }
        if (($_GET['cat-created'] ?? '') === '1') {
            return ['دستهٔ جدید ساخته شد.', 'ok'];
        }
        if (($_GET['cat-updated'] ?? '') === '1') {
            return ['تغییرات دسته ذخیره شد.', 'ok'];
        }
        if (($_GET['cat-deleted'] ?? '') === '1') {
            return ['دسته حذف شد و تاپیک‌هایش جابجا شدند.', 'ok'];
        }
        if (($_GET['cat-locked'] ?? '') === '1') {
            return ['دسته قفل شد؛ از این پس فقط مدیران می‌توانند در آن بنویسند.', 'ok'];
        }
        if (($_GET['cat-unlocked'] ?? '') === '1') {
            return ['قفل دسته باز شد؛ کاربران می‌توانند در آن پرسش و پاسخ بگذارند.', 'ok'];
        }
        if (($_GET['edited'] ?? '') === '1') {
            return ['ویرایش ذخیره شد.', 'ok'];
        }
        if (($_GET['flags-cleared'] ?? '') === '1') {
            return ['گزارش‌های این مورد رد شد.', 'ok'];
        }
        if (($_GET['voted'] ?? '') === '1') {
            return ['رأی شما در نظرسنجی ثبت شد.', 'ok'];
        }
        // (۲.۱.۰) سیستم پیام خصوصی موقتاً غیرفعال
        return null;
    }

    // ------------------------------------------------------------------
    //  دسترسی و اعتبارسنجی
    // ------------------------------------------------------------------

    /**
     * آیا بازدیدکنندهٔ فعلی اجازهٔ دیدن این آیتمِ «در انتظار تأیید» را دارد؟
     * (نویسندهٔ خودش — از طریق کوکی HMAC — یا مدیر)
     */
    public static function canSeeWaiting(int $coid): bool
    {
        try {
            if (User::alloc()->pass('editor', true)) {
                return true;
            }
        } catch (\Throwable $e) {
            // بدون کاربر واردشده
        }

        $cookie = (string) (\Typecho\Cookie::get('__typecho_unapproved_comment') ?? '');
        if (preg_match('/^(\d+)\.([a-f0-9]{64})$/', $cookie, $m)) {
            $expected = hash_hmac('sha256', $m[1], (string) Options::alloc()->secret);
            return hash_equals($expected, $m[2]) && (int) $m[1] === $coid;
        }

        return false;
    }

    /** کوکی نمایش آیتمِ در انتظار تأیید به نویسندهٔ خودش */
    public static function setWaitingCookie(int $itemId): void
    {
        Cookie::set(
            '__typecho_unapproved_comment',
            $itemId . '.' . hash_hmac('sha256', (string) $itemId, (string) Options::alloc()->secret)
        );
    }

    /** بیشینهٔ طول مجاز متن — مطابق منطق هسته */
    public static function maxTextLength(): int
    {
        try {
            $len = (int) (Options::alloc()->commentsMaxLength ?? 8000);
            $len = $len > 0 ? min($len, 16000) : 8000;
        } catch (\Throwable $e) {
            $len = 8000;
        }
        return $len;
    }

    /**
     * تعداد پاسخ در هر صفحه (داخل تاپیک) — ۲.۲.۰
     *
     * پیش‌فرض ۱۵ — هم‌سان با pageSize. اگر مدیر تنظیم کرد، همان مقدار
     * (با clamp بین ۵ تا ۱۰۰) استفاده می‌شود.
     */
    public static function postsPerPage(): int
    {
        $n = (int) self::opt('postsPerPage', '15');
        if ($n < 5) { $n = 5; }
        if ($n > 100) { $n = 100; }
        return $n;
    }

    // ------------------------------------------------------------------
    //  جستجو
    // ------------------------------------------------------------------

    /** گریز نویسه‌های ویژه LIKE */
    public static function likeEscape(string $kw): string
    {
        return addcslashes($kw, "\\%_");
    }

    // ====================================================================
    //  اعلان ایمیلی — از صف ایمیل هسته TypeRenew (الگوی Queue::enqueue)
    // ====================================================================

    /**
     * تنظیمات ایمیل — همان کلیدهای هسته.
     */
    private static function mailSettings(Options $options): array
    {
        return [
            'enable'        => (bool) ((int) ($options->mailEnable ?? 0) === 1),
            'adminMail'     => (string) ($options->mailAdmin ?? ''),
            'notifyOwner'   => (bool) ((int) ($options->mailNotifyOwner ?? 1) === 1),
            'notifyGuest'   => (bool) ((int) ($options->mailNotifyGuest ?? 1) === 1),
            'notifyPending' => (bool) ((int) ($options->mailNotifyPending ?? 1) === 1),
            'notifyMe'      => (bool) ((int) ($options->mailNotifyMe ?? 0) === 1),
            'subjectOwner'  => (string) ($options->mailSubjectOwner ?? ''),
            'subjectGuest'  => (string) ($options->mailSubjectGuest ?? ''),
            'subjectPending' => (string) ($options->mailSubjectPending ?? ''),
        ];
    }

    /** نشانی لغو اشتراک اعلان — همان سازوکار HMAC هسته */
    private static function unsubUrl(string $email, string $scope, Options $options): string
    {
        $email = strtolower(trim($email));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return '';
        }

        $ts = time();
        $payload = 'v2|' . $email . '|' . $scope . '|' . $ts;
        $sig = hash_hmac('sha256', $payload, (string) ($options->secret ?? ''), true);
        $token = rtrim(strtr(base64_encode($payload . '|' . base64_encode($sig)), '+/', '-_'), '=');
        return \Typecho\Common::url('/action/mail?do=unsub&token=' . rawurlencode($token), (string) $options->index);
    }

    /**
     * ساخت آبجکت شبه‌دیدگاه برای سازگاری با موضوع‌ساز/قالب‌های ایمیل هسته.
     *
     * @param string $text        متن خام آیتم
     * @param int    $itemId      شناسهٔ آیتم (پرسش یا پاسخ)
     * @param string $title       عنوان (موضوع پرسش)
     * @param string $permalink   نشانی صفحه
     * @param string $author      نام نویسنده
     * @param string $mail        ایمیل نویسنده
     * @param int    $authorId    شناسهٔ نویسنده (۰ = مهمان)
     * @param string $ip          IP نویسنده
     * @param int    $created     زمان ساخت
     * @param int    $parentId    شناسهٔ پرسش والد (۰ برای خود پرسش)
     * @param int    $itemTopicId شناسهٔ تاپیک (برای cid نه‌چندان مهم)
     */
    public static function mailCommentObject(
        string $text,
        int $itemId,
        string $title,
        string $permalink,
        string $author,
        string $mail,
        int $authorId,
        string $ip,
        int $created,
        int $parentId = 0,
        int $itemTopicId = 0
    ): object {
        $o = new \stdClass();
        $o->coid = $itemId;
        $o->cid = 0;
        $o->parent = $parentId;
        $o->authorId = $authorId;
        $o->ownerId = self::ownerUid();
        $o->author = $author;
        $o->mail = $mail;
        $o->url = '';
        $o->ip = $ip;
        $o->agent = '';
        $o->text = $text;
        $o->content = self::renderText($text);
        $o->title = $title !== '' ? $title : 'انجمن';
        $o->permalink = $permalink;
        $o->created = $created;
        $o->status = 'approved';
        return $o;
    }

    /**
     * ارسال اعلان‌های ایمیلی پس از ایجاد پرسش/پاسخ — دقیقاً همان صف
     * هسته (table.mail_queue) با قالب‌های فارسی usr/mail.
     *
     * رویدادها (مثل نسخهٔ قدیم که از Feedback/Core ایمیل می‌رفت):
     *  - آیتم در انتظار تأیید + notifyPending → اعلان به مدیر ('notice')
     *  - آیتم تأییدشده + notifyOwner → اعلان به مالک انجمن ('owner')
     *  - پاسخ جدید + notifyGuest → اعلان به نویسندهٔ پرسش ('guest')
     */
    public static function notifyMail(object $comment, string $event, ?array $parentTopic = null): void
    {
        try {
            $options = Options::alloc();
            $settings = self::mailSettings($options);
            if (!$settings['enable']) {
                return;
            }

            $db = Db::get();
            $status = (string) ($comment->status ?? 'approved');
            $isApproved = $status === 'approved';

            // ۱) اعلان «در انتظار تأیید» به مدیر
            if (!$isApproved && $event === 'created' && $settings['notifyPending']) {
                $adminMail = trim((string) $settings['adminMail']);
                if ($adminMail === '' || !filter_var($adminMail, FILTER_VALIDATE_EMAIL)) {
                    $owner = self::ownerUid();
                    if ($owner > 0) {
                        $row = $db->fetchRow(
                            $db->select('screenName', 'mail')->from('table.users')->where('uid = ?', $owner)->limit(1)
                        );
                        $adminMail = trim((string) ($row['mail'] ?? ''));
                    }
                }
                if ($adminMail !== '' && filter_var($adminMail, FILTER_VALIDATE_EMAIL)) {
                    if (!\Typecho\Mail\Queue::isUnsub($adminMail, 'pending', $db)) {
                        self::enqueueMailJob('notice', $adminMail, (string) $options->title, $comment, $options, $settings, true);
                    }
                }
                return; // آیتم در انتظار تأیید است — اعلان دیگری نمی‌رود
            }

            if (!in_array($event, ['created', 'approved'], true)) {
                return;
            }

            // ۲) اعلان «مطلب جدید» به مالک انجمن — به‌جز خودش
            if ($isApproved && $settings['notifyOwner']) {
                $owner = self::ownerUid();
                $ownerMail = '';
                $ownerName = '';
                if ($owner > 0) {
                    $row = $db->fetchRow(
                        $db->select('screenName', 'mail')->from('table.users')->where('uid = ?', $owner)->limit(1)
                    );
                    $ownerMail = trim((string) ($row['mail'] ?? ''));
                    $ownerName = (string) ($row['screenName'] ?? '');
                }
                if ($ownerMail === '' && filter_var((string) $settings['adminMail'], FILTER_VALIDATE_EMAIL)) {
                    $ownerMail = trim((string) $settings['adminMail']);
                }

                $isSelf = $owner > 0 && (int) ($comment->authorId ?? 0) === $owner;
                $sameMail = strtolower(trim((string) ($comment->mail ?? ''))) === strtolower($ownerMail) && $ownerMail !== '';
                if ($ownerMail !== '' && filter_var($ownerMail, FILTER_VALIDATE_EMAIL)
                    && ((!$isSelf && !$sameMail) || $settings['notifyMe'])) {
                    if (!\Typecho\Mail\Queue::isUnsub($ownerMail, 'owner', $db)) {
                        self::enqueueMailJob('owner', $ownerMail, $ownerName, $comment, $options, $settings);
                    }
                }
            }

            // ۳) اعلان «پاسخ جدید» به نویسندهٔ پرسش — به‌جز خودش
            if ($isApproved && $settings['notifyGuest'] && $parentTopic !== null) {
                $topicAuthorMail = trim((string) ($parentTopic['author_mail'] ?? ''));
                $topicAuthorId = (int) ($parentTopic['author_id'] ?? 0);
                if ($topicAuthorId < 1 && $topicAuthorMail === '') {
                    // نویسندهٔ پرسش عضو است — از جدول users بخوان
                    $topic = self::topicById((int) ($parentTopic['id'] ?? 0));
                    if ($topic !== null && (int) $topic['author_id'] > 0) {
                        $row = $db->fetchRow(
                            $db->select('screenName', 'mail')->from('table.users')
                                ->where('uid = ?', (int) $topic['author_id'])->limit(1)
                        );
                        $topicAuthorMail = trim((string) ($row['mail'] ?? ''));
                    }
                }

                $currentMail = strtolower(trim((string) ($comment->mail ?? '')));
                if ($topicAuthorMail !== '' && filter_var($topicAuthorMail, FILTER_VALIDATE_EMAIL)) {
                    $isSelf = $topicAuthorId > 0 && (int) ($comment->authorId ?? 0) === $topicAuthorId;
                    if ($isSelf || strtolower($topicAuthorMail) === $currentMail) {
                        return; // به خودش اعلان نفرست
                    }
                    if (!\Typecho\Mail\Queue::isUnsub($topicAuthorMail, 'reply', $db)) {
                        // موضوع پاسخ: از آبجکت والد برای Ptext استفاده می‌کنیم
                        $comment->parent = 0; // جلوگیری از lookup دیدگاه هسته
                        self::enqueueMailJob('guest', $topicAuthorMail, (string) ($parentTopic['author_name'] ?? ''), $comment, $options, $settings, false, $parentTopic);
                    }
                }
            }
        } catch (\Throwable $e) {
            // ایمیل هرگز نباید جریان اصلی را بشکند
        }
    }

    /**
     * ساخت و صف‌کردن یک کار ایمیل با قالب‌های هسته.
     */
    private static function enqueueMailJob(
        string $type,
        string $to,
        string $toName,
        object $comment,
        Options $options,
        array $settings,
        bool $isNotice = false,
        ?array $parentTopic = null
    ): void {
        try {
            $now = new \Typecho\Date((int) ($comment->created ?? time()));
            $time = $now->format('Y-m-d H:i:s');

            $commentHtml = (string) ($comment->content ?? '');
            $commentTextPlain = trim(strip_tags($commentHtml));
            $commentTextPlain = html_entity_decode($commentTextPlain, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $commentTextPlain = preg_replace("/\r\n?/", "\n", $commentTextPlain) ?? $commentTextPlain;

            $parentText = '';
            $parentName = '';
            $parentTime = '';
            if ($parentTopic !== null) {
                $parentName = (string) ($parentTopic['author_name'] ?? '');
                $parentText = self::renderText((string) ($parentTopic['text'] ?? ''));
                $pt = new \Typecho\Date((int) ($parentTopic['created'] ?? time()));
                $parentTime = $pt->format('Y-m-d H:i:s');
            }
            $parentTextPlain = trim(html_entity_decode(strip_tags($parentText), ENT_QUOTES | ENT_HTML5, 'UTF-8'));

            // موضوع ایمیل — همان الگوی Notify::subject هسته با ترجمهٔ fa_IR
            $raw = match ($type) {
                'guest'  => (string) ($settings['subjectGuest'] ?: _t('您在「{title}」的评论有了回复')),
                'notice' => (string) ($settings['subjectPending'] ?: _t('文章「{title}」有一条待审评论')),
                default  => (string) ($settings['subjectOwner'] ?: _t('你的文章「{title}」有了新评论')),
            };
            $subject = str_replace('{title}', (string) $comment->title, $raw);

            $manageUrl = (string) $options->adminUrl !== '' ? (string) $options->adminUrl . 'extending.php?panel=Forum%2FPanel.php' : '';

            $vars = [
                'subject'          => $subject,
                'title'            => (string) $comment->title,
                'PostAuthor'       => '',
                'time'             => $time,
                'commentText'      => $commentTextPlain,
                'commentTextPlain' => $commentTextPlain,
                'commentHtml'      => $commentHtml,
                'author'           => (string) $comment->author,
                'mail'             => (string) $comment->mail,
                'ip'               => (string) $comment->ip,
                'permalink'        => (string) $comment->permalink,
                'siteUrl'          => (string) $options->siteUrl,
                'siteTitle'        => (string) $options->title,
                'Pname'            => $parentName,
                'Ptext'            => $parentTextPlain,
                'Phtml'            => $parentText,
                'Pmail'            => '',
                'Ptime'            => $parentTime,
                'manageurl'        => $manageUrl,
                'status'           => _t('通过'),
            ];

            $vars['unsubUrl'] = $type === 'guest'
                ? self::unsubUrl($to, 'reply', $options)
                : self::unsubUrl($to, $isNotice ? 'pending' : 'owner', $options);

            $html = \Typecho\Mail\Template::render($type, $vars, $options);

            $message = \Typecho\Mail\Queue::buildMessage($options, $to, $subject, $html, $toName);

            \Typecho\Mail\Queue::enqueue($type === 'guest' ? 'guest' : ($isNotice ? 'notice' : 'owner'), $message, Db::get(), $options);
        } catch (\Throwable $e) {
            // صف‌کردن ایمیل نباید جریان اصلی را بشکند
        }
    }

    // ====================================================================
    //  پیام خصوصی — جداول forum_messages / forum_blocks (۲.۱.۰)
    // ====================================================================

    /** اطلاعات پایهٔ یک کاربر برای نمایش در PM (نام، آواتار، گروه) */
    public static function pmUserSummary(int $uid): ?array
    {
        if ($uid < 1) {
            return null;
        }
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('uid', 'name', 'screenName', 'mail', 'group')
                    ->from('table.users')->where('uid = ?', $uid)->limit(1)
            );
            if (!$row) {
                return null;
            }
            $displayName = trim((string) ($row['screenName'] ?: $row['name']));
            return [
                'uid'         => (int) $row['uid'],
                'name'        => (string) $row['name'],
                'displayName' => $displayName !== '' ? $displayName : (string) $row['name'],
                'mail'        => (string) $row['mail'],
                'group'       => (string) $row['group'],
                'profileUrl'  => self::profileUrl((int) $row['uid']),
            ];
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** آیا کاربر $blockedId توسط $userId بلاک شده؟ */
    public static function isBlocked(int $userId, int $blockedId): bool
    {
        if ($userId < 1 || $blockedId < 1 || $userId === $blockedId) {
            return false;
        }
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('id')->from('table.forum_blocks')
                    ->where('user_id = ? AND blocked_id = ?', $userId, $blockedId)
                    ->limit(1)
            );
            return !empty($row);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** افزودن بلاک — idempotent */
    public static function blockUser(int $userId, int $blockedId): bool
    {
        if ($userId < 1 || $blockedId < 1 || $userId === $blockedId) {
            return false;
        }
        try {
            $db = Db::get();
            if (self::isBlocked($userId, $blockedId)) {
                return true;
            }
            $db->query(
                $db->insert('table.forum_blocks')->rows([
                    'user_id'   => $userId,
                    'blocked_id' => $blockedId,
                    'created'   => time(),
                ])
            );
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** حذف بلاک */
    public static function unblockUser(int $userId, int $blockedId): bool
    {
        if ($userId < 1 || $blockedId < 1) {
            return false;
        }
        try {
            $db = Db::get();
            $db->query(
                $db->delete('table.forum_blocks')
                    ->where('user_id = ? AND blocked_id = ?', $userId, $blockedId)
            );
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** فهرست بلاک‌شوندگان یک کاربر */
    public static function blockedUsers(int $userId): array
    {
        if ($userId < 1) {
            return [];
        }
        try {
            $db = Db::get();
            $rows = $db->fetchAll(
                $db->select('blocked_id', 'created')->from('table.forum_blocks')
                    ->where('user_id = ?', $userId)
                    ->order('created', Db::SORT_DESC)
            );
            $out = [];
            foreach ($rows as $r) {
                $u = self::pmUserSummary((int) $r['blocked_id']);
                if ($u !== null) {
                    $u['blockedAt'] = (int) $r['created'];
                    $out[] = $u;
                }
            }
            return $out;
        } catch (\Throwable $e) {
            return [];
        }
    }

    // ====================================================================
    //  بلاک اداری کاربران — ۲.۲.۰ (موقت یا همیشه)
    // ====================================================================

    /**
     * اطمینان از وجود جدول forum_bans — خودترمیم پس از «جایگزینی فایل».
     *
     * جدول forum_bans در ۲.۲.۰ معرفی شد؛ اگر مدیر پوشهٔ افزونه را بدون
     * خاموش/روشن‌کردن جایگزین کند، با این متد یک‌بار ساختار ساخته می‌شود
     * (همان الگوی ensureLikesTable).
     */
    public static function ensureBansTable(): void
    {
        if (self::$bansTableReady !== null) {
            return;
        }
        try {
            $db = Db::get();
            $db->fetchRow($db->select('id')->from('table.forum_bans')->limit(1));
            self::$bansTableReady = true;
            return;
        } catch (\Throwable $e) {
            // جدول وجود ندارد — تلاش برای ساخت
        }
        try {
            Schema::ensure();
            self::$bansTableReady = true;
        } catch (\Throwable $e) {
            self::$bansTableReady = false;
        }
    }

    /**
     * نگاشت بلاک‌های فعال: uid => ['until'=>..., 'reason'=>..., 'created'=>..., 'bannedBy'=>...]
     *
     * بلاک «فعال» یعنی until=0 (همیشه) یا until > time(). ردیف‌های
     * موقتیِ منقضی نادیده گرفته می‌شوند (خوانده‌شدنشان هزینه ندارد).
     */
    public static function activeBans(): array
    {
        if (self::$bansCache !== null) {
            return self::$bansCache;
        }
        self::ensureBansTable();
        $map = [];
        try {
            $db = Db::get();
            $rows = $db->fetchAll(
                $db->select('uid', 'until', 'reason', 'banned_by', 'created')
                    ->from('table.forum_bans')
                    ->order('created', Db::SORT_DESC)
            );
            $now = time();
            foreach ($rows as $r) {
                $uid = (int) $r['uid'];
                $until = (int) $r['until'];
                if ($until > 0 && $until <= $now) {
                    continue; // موقتیِ منقضی
                }
                // اگر چند ردیف هست، جدیدترین (اولین در مرتب‌سازی نزولی) معیار است
                if (!isset($map[$uid])) {
                    $map[$uid] = [
                        'until'    => $until,
                        'reason'   => (string) $r['reason'],
                        'bannedBy' => (int) $r['banned_by'],
                        'created'  => (int) $r['created'],
                    ];
                }
            }
        } catch (\Throwable $e) {
        }
        return self::$bansCache = $map;
    }

    /** بازتنظیم کش بلاک‌ها */
    public static function resetBansCache(): void
    {
        self::$bansCache = null;
    }

    /**
     * بلاک فعالِ یک کاربر — یا null.
     *
     * @return array{until:int, reason:string, bannedBy:int, created:int}|null
     */
    public static function activeBanFor(int $uid): ?array
    {
        if ($uid < 1) {
            return null;
        }
        return self::activeBans()[$uid] ?? null;
    }

    /** آیا این کاربر الان بلاک است؟ */
    public static function isUserBanned(int $uid): bool
    {
        return self::activeBanFor($uid) !== null;
    }

    /**
     * بلاک اداری یک کاربر — موقت (تimestamp پایان) یا همیشه (until=0).
     *
     * ردیف‌های قبلی همان کاربر حذف و بلاک تازه ثبت می‌شود
     * (بلاکِ دوباره مهلت تازه می‌سازد).
     */
    public static function banUser(int $uid, int $until, string $reason = '', int $bannedBy = 0): bool
    {
        if ($uid < 1) {
            return false;
        }
        self::ensureBansTable();
        try {
            $db = Db::get();
            $db->query($db->delete('table.forum_bans')->where('uid = ?', $uid));
            $db->query(
                $db->insert('table.forum_bans')->rows([
                    'uid'       => $uid,
                    'until'     => max(0, $until),
                    'reason'    => mb_substr(trim($reason), 0, 255),
                    'banned_by' => max(0, $bannedBy),
                    'created'   => time(),
                ])
            );
            self::resetBansCache();
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** رفع بلاک اداری یک کاربر */
    public static function unbanUser(int $uid): bool
    {
        if ($uid < 1) {
            return false;
        }
        self::ensureBansTable();
        try {
            $db = Db::get();
            $db->query($db->delete('table.forum_bans')->where('uid = ?', $uid));
            self::resetBansCache();
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * متن فارسی مهلت بلاک برای نمایش به کاربر/مدیر.
     *
     * «همیشه» یا «تا ۱۲ آبان ۱۴۰۴، ۱۸:۳۰» یا «تا ۴۵ دقیقهٔ دیگر».
     */
    public static function banUntilText(array $ban): string
    {
        $until = (int) ($ban['until'] ?? 0);
        if ($until < 1) {
            return 'همیشه';
        }
        $left = $until - time();
        if ($left <= 0) {
            return 'منقضی‌شده';
        }
        if ($left < 3600) {
            return 'تا ' . self::faDigits((string) max(1, (int) ceil($left / 60))) . ' دقیقهٔ دیگر';
        }
        if ($left < 86400) {
            return 'تا ' . self::faDigits((string) max(1, (int) ceil($left / 3600))) . ' ساعت دیگر';
        }
        return 'تا ' . self::jalali($until) . '، ' . self::jalaliTime($until);
    }

    /**
     * بلاکِ فعالِ بازدیدکنندهٔ فعلی — یا null.
     * (برای نمایش نوار «حساب شما مسدود است» در صفحات انجمن)
     */
    public static function viewerBan(): ?array
    {
        $uid = self::viewerUid();
        if ($uid < 1) {
            return null;
        }
        return self::activeBanFor($uid);
    }

    /**
     * ارسال یک پیام خصوصی.
     *
     * اعتبارسنجی‌ها:
     *  - فرستنده و گیرنده باید عضو واردشده باشند
     *  - گیرنده نباید فرستنده را بلاک کرده باشد
     *  - فرستنده نباید خود گیرنده باشد
     *  - بدنهٔ پیام نباید خالی باشد
     *  - شمار پیام‌های فعال گیرنده از سقف تعیین‌شده بالاتر نرود
     *
     * @return array{ok:bool, id?:int, error?:string}
     */
    public static function sendPm(int $senderId, int $recipientId, string $subject, string $body): array
    {
        if (!self::pmEnabled()) {
            return ['ok' => false, 'error' => 'پیام خصوصی غیرفعال است.'];
        }
        if ($senderId < 1 || $recipientId < 1) {
            return ['ok' => false, 'error' => 'گیرنده یا فرستنده نامعتبر است.'];
        }
        if ($senderId === $recipientId) {
            return ['ok' => false, 'error' => 'نمی‌توانید به خودتان پیام بفرستید.'];
        }
        $body = trim($body);
        if ($body === '') {
            return ['ok' => false, 'error' => 'متن پیام خالی است.'];
        }
        if (mb_strlen($body) > self::maxTextLength()) {
            return ['ok' => false, 'error' => 'متن پیام بیش از حد طولانی است.'];
        }
        $subject = trim($subject);
        if ($subject === '') {
            $subject = mb_substr(strip_tags($body), 0, 80);
        }
        // گیرنده باید عضو باشد
        $recipient = self::pmUserSummary($recipientId);
        if ($recipient === null) {
            return ['ok' => false, 'error' => 'گیرنده یافت نشد.'];
        }
        // بلاک‌بودن فرستنده از سوی گیرنده
        if (self::isBlocked($recipientId, $senderId)) {
            return ['ok' => false, 'error' => 'گیرنده اجازه دریافت پیام از شما را ندارد.'];
        }
        // سقف صندوق گیرنده
        $inboxCount = self::pmCountForRecipient($recipientId);
        if ($inboxCount >= self::pmInboxLimit()) {
            // پیام‌های قدیمی‌تر از سقف را (به ترتیب FIFO) سافت‌دیلیت کن
            self::pruneInbox($recipientId, $inboxCount - self::pmInboxLimit() + 1);
        }
        try {
            $db = Db::get();
            $now = time();
            $db->query(
                $db->insert('table.forum_messages')->rows([
                    'sender_id'    => $senderId,
                    'recipient_id' => $recipientId,
                    'subject'      => mb_substr($subject, 0, 255),
                    'body'         => $body,
                    'is_read'      => 0,
                    'deleted_by_sender'    => 0,
                    'deleted_by_recipient' => 0,
                    'created'      => $now,
                    'read_at'      => 0,
                ])
            );
            // lastInsertId ممکن است در برخی گویش‌ها (SQLite/Pgsql) استثنا پرتاب کند
            // یا ۰ برگرداند؛ در آن حالت با کوئری fallback شناسه را پیدا می‌کنیم.
            $id = 0;
            try {
                $id = (int) $db->lastInsertId();
            } catch (\Throwable $lidErr) {
                $id = 0;
            }
            if ($id < 1) {
                // fallback: آخرین پیام این فرستنده در همین لحظه
                $row = $db->fetchRow(
                    $db->select('id')->from('table.forum_messages')
                        ->where('sender_id = ? AND created = ?', $senderId, $now)
                        ->order('id', Db::SORT_DESC)
                        ->limit(1)
                );
                if ($row) {
                    $id = (int) $row['id'];
                }
            }
            // اعلان درون‌انجمنی به گیرنده — در بلوک جداگانه تا خطای احتمالی
            // اعلان، موفقیت ارسال پیام را مخدوش نکند.
            if ($id > 0) {
                try {
                    self::addNotification($recipientId, 'pm', $id, 0);
                } catch (\Throwable $notifErr) {
                    // اعلان حیاتی نیست؛ پیام ثبت شده است.
                }
            }
            return ['ok' => true, 'id' => $id];
        } catch (\Throwable $e) {
            return ['ok' => false, 'error' => 'خطای پایگاه‌داده هنگام ذخیرهٔ پیام: ' . $e->getMessage()];
        }
    }

    /** شمار پیام‌های فعالِ دریافتی یک کاربر */
    public static function pmCountForRecipient(int $uid): int
    {
        if ($uid < 1) {
            return 0;
        }
        try {
            $db = Db::get();
            return (int) $db->fetchObject(
                $db->select(['COUNT(id)' => 'n'])->from('table.forum_messages')
                    ->where('recipient_id = ? AND deleted_by_recipient = 0', $uid)
            )->n;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /** شمار پیام‌های فعالِ ارسال‌شده یک کاربر */
    public static function pmCountForSender(int $uid): int
    {
        if ($uid < 1) {
            return 0;
        }
        try {
            $db = Db::get();
            return (int) $db->fetchObject(
                $db->select(['COUNT(id)' => 'n'])->from('table.forum_messages')
                    ->where('sender_id = ? AND deleted_by_sender = 0', $uid)
            )->n;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /** شمار پیام‌های خوانده‌نشدهٔ دریافتی یک کاربر */
    public static function pmUnreadCount(int $uid): int
    {
        if ($uid < 1) {
            return 0;
        }
        try {
            $db = Db::get();
            return (int) $db->fetchObject(
                $db->select(['COUNT(id)' => 'n'])->from('table.forum_messages')
                    ->where('recipient_id = ? AND is_read = 0 AND deleted_by_recipient = 0', $uid)
            )->n;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /**
     * حذف پیام‌های قدیمی‌تر از سقف (FIFO) — فقط deleted_by_recipient = 0
     */
    private static function pruneInbox(int $uid, int $count): void
    {
        if ($uid < 1 || $count < 1) {
            return;
        }
        try {
            $db = Db::get();
            $old = $db->fetchAll(
                $db->select('id')->from('table.forum_messages')
                    ->where('recipient_id = ? AND deleted_by_recipient = 0', $uid)
                    ->order('created', Db::SORT_ASC)
                    ->limit($count)
            );
            if (empty($old)) {
                return;
            }
            $ids = array_map(static fn ($r) => (int) $r['id'], $old);
            $db->query(
                $db->update('table.forum_messages')
                    ->rows(['deleted_by_recipient' => 1])
                    ->where('id IN ?', $ids)
            );
        } catch (\Throwable $e) {
            // بی‌اثر
        }
    }

    /** فهرست پیام‌های دریافتی یک کاربر */
    public static function pmInbox(int $uid, int $page = 1, int $pageSize = 20): array
    {
        if ($uid < 1) {
            return [];
        }
        $page = max(1, $page);
        $pageSize = max(5, min(100, $pageSize));
        try {
            $db = Db::get();
            return $db->fetchAll(
                $db->select('id', 'sender_id', 'subject', 'is_read', 'created')
                    ->from('table.forum_messages')
                    ->where('recipient_id = ? AND deleted_by_recipient = 0', $uid)
                    ->order('created', Db::SORT_DESC)
                    ->page($page, $pageSize)
            );
        } catch (\Throwable $e) {
            return [];
        }
    }

    /** فهرست پیام‌های ارسال‌شده یک کاربر */
    public static function pmSent(int $uid, int $page = 1, int $pageSize = 20): array
    {
        if ($uid < 1) {
            return [];
        }
        $page = max(1, $page);
        $pageSize = max(5, min(100, $pageSize));
        try {
            $db = Db::get();
            return $db->fetchAll(
                $db->select('id', 'recipient_id', 'subject', 'created')
                    ->from('table.forum_messages')
                    ->where('sender_id = ? AND deleted_by_sender = 0', $uid)
                    ->order('created', Db::SORT_DESC)
                    ->page($page, $pageSize)
            );
        } catch (\Throwable $e) {
            return [];
        }
    }

    /** دریافت یک پیام (به‌همراه metadata) — فقط اگر کاربر فرستنده یا گیرنده باشد */
    public static function pmGet(int $messageId, int $viewerId): ?array
    {
        if ($messageId < 1 || $viewerId < 1) {
            return null;
        }
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select()->from('table.forum_messages')
                    ->where('id = ?', $messageId)->limit(1)
            );
            if (!$row) {
                return null;
            }
            // مالکیت یا دسترسی کاربر
            $isSender = (int) $row['sender_id'] === $viewerId;
            $isRecipient = (int) $row['recipient_id'] === $viewerId;
            if (!$isSender && !$isRecipient) {
                return null;
            }
            // آیا از دید کاربر حذف شده؟
            if ($isSender && (int) $row['deleted_by_sender'] === 1) {
                return null;
            }
            if ($isRecipient && (int) $row['deleted_by_recipient'] === 1) {
                return null;
            }
            $row['id'] = (int) $row['id'];
            $row['sender_id'] = (int) $row['sender_id'];
            $row['recipient_id'] = (int) $row['recipient_id'];
            $row['is_read'] = (int) $row['is_read'];
            $row['created'] = (int) $row['created'];
            $row['read_at'] = (int) $row['read_at'];
            $row['is_sender'] = $isSender;
            $row['is_recipient'] = $isRecipient;
            $row['sender'] = self::pmUserSummary($row['sender_id']);
            $row['recipient'] = self::pmUserSummary($row['recipient_id']);
            return $row;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** علامت‌گذاری یک پیام به‌عنوان خوانده‌شده (اگر گیرنده آن را باز کند) */
    public static function pmMarkRead(int $messageId, int $viewerId): bool
    {
        if ($messageId < 1 || $viewerId < 1) {
            return false;
        }
        try {
            $db = Db::get();
            $db->query(
                $db->update('table.forum_messages')
                    ->rows(['is_read' => 1, 'read_at' => time()])
                    ->where('id = ? AND recipient_id = ? AND is_read = 0', $messageId, $viewerId)
            );
            // خواندن اعلان pm متناظر
            self::markPmNotificationRead($messageId, $viewerId);
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** علامت‌گذاری اعلان pm متناظر به‌عنوان خوانده‌شده */
    private static function markPmNotificationRead(int $messageId, int $uid): void
    {
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('id')->from('table.forum_notifications')
                    ->where('uid = ? AND type = ? AND item_id = ?', $uid, 'pm', $messageId)
                    ->limit(1)
            );
            if ($row) {
                self::markNotificationRead((int) $row['id'], $uid);
            }
        } catch (\Throwable $e) {
            // بی‌اثر
        }
    }

    /**
     * Soft-delete یک پیام از دید کاربر.
     *  - اگر کاربر گیرنده باشد → deleted_by_recipient = 1
     *  - اگر کاربر فرستنده باشد → deleted_by_sender = 1
     *  - پیام فقط از دید کاربر حذف می‌شود؛ طرف مقابل همچنان آن را می‌بیند.
     */
    public static function pmSoftDelete(int $messageId, int $viewerId): bool
    {
        if ($messageId < 1 || $viewerId < 1) {
            return false;
        }
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('sender_id', 'recipient_id')->from('table.forum_messages')
                    ->where('id = ?', $messageId)->limit(1)
            );
            if (!$row) {
                return false;
            }
            if ((int) $row['sender_id'] === $viewerId) {
                $db->query(
                    $db->update('table.forum_messages')
                        ->rows(['deleted_by_sender' => 1])
                        ->where('id = ?', $messageId)
                );
                return true;
            }
            if ((int) $row['recipient_id'] === $viewerId) {
                $db->query(
                    $db->update('table.forum_messages')
                        ->rows(['deleted_by_recipient' => 1])
                        ->where('id = ?', $messageId)
                );
                return true;
            }
            return false;
        } catch (\Throwable $e) {
            return false;
        }
    }
}
