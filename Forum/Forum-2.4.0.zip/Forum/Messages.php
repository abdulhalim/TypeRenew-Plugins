<?php
namespace TypechoPlugin\Forum;

use Typecho\Db;
use Typecho\Widget\Exception as WidgetException;
use Widget\Options;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Messages extends ForumPage
{
    protected function forumPageTitle(): string
    {
        $box = $this->currentBox();
        if ($box === 'sent') {
            return 'پیام‌های ارسال‌شده — انجمن';
        }
        if ($box === 'blocked') {
            return 'فهرست بلاک‌شوندگان — انجمن';
        }
        if ($this->isCompose()) {
            return 'پیام خصوصی جدید — انجمن';
        }
        if ($this->isView()) {
            return 'مشاهدهٔ پیام — انجمن';
        }
        return 'صندوق پیام‌های خصوصی — انجمن';
    }

    protected function forumPageDescription(): string
    {
        return 'پیام‌های خصوصی بین اعضای انجمن';
    }

    protected function forumPageUrl(): string
    {
        $box = $this->currentBox();
        if ($box === 'sent' || $box === 'blocked') {
            return Plugin::messagesUrl($box);
        }
        if ($this->isCompose()) {
            $to = (int) ($this->request->get('to') ?: 0);
            return $to > 0 ? Plugin::messageComposeUrl($to) : Plugin::messageComposeUrl();
        }
        $id = (int) ($this->request->get('id') ?: 0);
        if ($id > 0) {
            return Plugin::messageViewUrl($id);
        }
        return Plugin::messagesUrl();
    }

    public function render(): void
    {
        $this->renderForumPage('messages.php');
    }

    private function isCompose(): bool
    {
        $slug = (string) $this->request->get('slug');
        // route /forum/messages/compose
        $pathInfo = trim((string) ($_SERVER['PATH_INFO'] ?? ''), '/');
        return $pathInfo === 'forum/messages/compose'
            || $slug === 'compose'
            || (string) $this->request->get('do') === 'compose';
    }

    private function isView(): bool
    {
        $id = (int) ($this->request->get('id') ?: 0);
        return $id > 0 && !$this->isCompose();
    }

    private function currentBox(): string
    {
        if ($this->isCompose()) {
            return 'inbox';
        }
        // در حالت view، box را با توجه به مالکیت پیام تعیین می‌کنیم تا
        // تب فعال و دکمهٔ «بازگشت» به‌درستی به صندوق مرجع برگردند.
        if ($this->isView()) {
            $box = (string) $this->request->get('box');
            if (in_array($box, ['sent', 'blocked'], true)) {
                return $box;
            }
            // بدون پارامتر box: با توجه به فرستنده/گیرنده بودن کاربر فعلی
            $id = (int) ($this->request->get('id') ?: 0);
            $uid = (int) $this->user->uid;
            if ($id > 0 && $uid > 0) {
                $msg = Plugin::pmGet($id, $uid);
                if ($msg !== null) {
                    // اگر فرستنده‌ایم → صندوق ارسال؛ در غیر این صورت → صندوق دریافت
                    return (int) $msg['sender_id'] === $uid ? 'sent' : 'inbox';
                }
            }
            return 'inbox';
        }
        $box = (string) $this->request->get('box');
        return in_array($box, ['sent', 'blocked'], true) ? $box : 'inbox';
    }

    protected function prepareContext(): array
    {
        if (!Plugin::pmEnabled()) {
            throw new WidgetException(_t('پیام خصوصی غیرفعال است.'), 404);
        }
        // (۲.۱.۰ رفع) اگر کاربر وارد نشده، به جای 403 به صفحهٔ ورود هدایت شو
        if (!$this->user->hasLogin()) {
            $loginUrl = (string) $this->options->loginUrl;
            $pmUrl = Plugin::messagesUrl();
            $sep = str_contains($loginUrl, '?') ? '&' : '?';
            $this->response->redirect($loginUrl . $sep . 'referer=' . rawurlencode($pmUrl));
            return []; // redirect() درون خود exit می‌کند اما PHP برای return type array مقدار می‌خواهد
        }

        $uid = (int) $this->user->uid;
        $box = $this->currentBox();
        $pageSize = max(5, min(50, (int) Plugin::opt('pageSize', 15)));
        $page = max(1, (int) ($this->request->get('page') ?: 1));

        $view = [
            'mode'  => 'inbox',
            'box'   => $box,
            'page'  => $page,
            'pages' => 1,
            'rows'  => [],
            'total' => 0,
        ];

        if ($this->isView()) {
            $messageId = (int) ($this->request->get('id') ?: 0);
            $msg = Plugin::pmGet($messageId, $uid);
            if ($msg === null) {
                throw new WidgetException(_t('پیام یافت نشد.'), 404);
            }
            // علامت‌گذاری به‌عنوان خوانده‌شده اگر گیرنده باشد
            if ((int) $msg['recipient_id'] === $uid && (int) $msg['is_read'] === 0) {
                Plugin::pmMarkRead($messageId, $uid);
                $msg['is_read'] = 1;
            }
            $view['mode'] = 'view';
            $view['message'] = $msg;
            // پیشنهاد پاسخ سریع: compose به فرستنده (اگر گیرنده‌ایم)
            if ((int) $msg['recipient_id'] === $uid) {
                $view['replyTo'] = (int) $msg['sender_id'];
            } elseif ((int) $msg['sender_id'] === $uid) {
                $view['replyTo'] = (int) $msg['recipient_id'];
            } else {
                $view['replyTo'] = 0;
            }
        } elseif ($this->isCompose()) {
            $toUid = (int) ($this->request->get('to') ?: 0);
            $recipient = $toUid > 0 ? Plugin::pmUserSummary($toUid) : null;
            // اگر گیرنده فرستنده را بلاک کرده
            $recipientBlocked = false;
            if ($recipient !== null) {
                $recipientBlocked = Plugin::isBlocked((int) $recipient['uid'], $uid);
            }
            $view['mode'] = 'compose';
            $view['recipient'] = $recipient;
            $view['recipientBlocked'] = $recipientBlocked;
            $view['replyToSubject'] = '';
            // پاسخ به یک پیام: پرکردن موضوع
            $replyToId = (int) ($this->request->get('reply') ?: 0);
            if ($replyToId > 0) {
                $orig = Plugin::pmGet($replyToId, $uid);
                if ($orig !== null) {
                    $origSubject = (string) $orig['subject'];
                    if (mb_strpos($origSubject, 'پاسخ: ') !== 0) {
                        $view['replyToSubject'] = 'پاسخ: ' . $origSubject;
                    } else {
                        $view['replyToSubject'] = $origSubject;
                    }
                }
            }
        } elseif ($box === 'sent') {
            $total = Plugin::pmCountForSender($uid);
            $pages = max(1, (int) ceil($total / $pageSize));
            if ($total > 0 && $page > $pages) {
                throw new WidgetException(_t('صفحهٔ درخواستی وجود ندارد'), 404);
            }
            $rows = Plugin::pmSent($uid, $page, $pageSize);
            $view['rows'] = array_map(static function ($r) {
                $u = Plugin::pmUserSummary((int) $r['recipient_id']);
                return [
                    'id'        => (int) $r['id'],
                    'toUid'     => (int) $r['recipient_id'],
                    'toName'    => $u ? $u['displayName'] : '—',
                    'toMail'    => $u ? $u['mail'] : '',
                    'subject'   => (string) $r['subject'],
                    'created'   => (int) $r['created'],
                    'is_read'   => 1, // از دید فرستنده خوانده‌شده محسوب می‌شود
                    'url'       => Plugin::messageViewUrl((int) $r['id']),
                ];
            }, $rows);
            $view['total'] = $total;
            $view['pages'] = $pages;
        } elseif ($box === 'blocked') {
            $rows = Plugin::blockedUsers($uid);
            $view['rows'] = array_map(static function ($u) {
                return [
                    'uid'      => (int) $u['uid'],
                    'name'     => (string) $u['displayName'],
                    'mail'     => (string) $u['mail'],
                    'group'    => (string) $u['group'],
                    'blockedAt' => (int) $u['blockedAt'],
                    'profileUrl' => (string) $u['profileUrl'],
                    'composeUrl' => Plugin::messageComposeUrl((int) $u['uid']),
                ];
            }, $rows);
            $view['total'] = count($rows);
        } else {
            $total = Plugin::pmCountForRecipient($uid);
            $pages = max(1, (int) ceil($total / $pageSize));
            if ($total > 0 && $page > $pages) {
                throw new WidgetException(_t('صفحهٔ درخواستی وجود ندارد'), 404);
            }
            $rows = Plugin::pmInbox($uid, $page, $pageSize);
            $view['rows'] = array_map(static function ($r) {
                $u = Plugin::pmUserSummary((int) $r['sender_id']);
                return [
                    'id'        => (int) $r['id'],
                    'fromUid'   => (int) $r['sender_id'],
                    'fromName'  => $u ? $u['displayName'] : '—',
                    'fromMail'  => $u ? $u['mail'] : '',
                    'subject'   => (string) $r['subject'],
                    'created'   => (int) $r['created'],
                    'is_read'   => (int) $r['is_read'],
                    'url'       => Plugin::messageViewUrl((int) $r['id']),
                ];
            }, $rows);
            $view['total'] = $total;
            $view['pages'] = $pages;
        }

        // صفحه‌بندی URL builder
        $box0 = $box;
        $pageUrlFn = static function (int $n) use ($box0): string {
            $url = Plugin::messagesUrl($box0);
            $sep = str_contains($url, '?') ? '&' : '?';
            return $n > 1 ? $url . $sep . 'page=' . $n : $url;
        };

        // آمار برای نمایش در بالای صفحه
        $stats = [
            'inboxTotal'  => Plugin::pmCountForRecipient($uid),
            'inboxUnread' => Plugin::pmUnreadCount($uid),
            'sentTotal'   => Plugin::pmCountForSender($uid),
            'inboxLimit'  => Plugin::pmInboxLimit(),
        ];

        return $this->commonContext() + [
            'pmView'     => $view,
            'pmStats'    => $stats,
            'pageUrl'    => $pageUrlFn,
            'composeUrl' => Plugin::messageComposeUrl(),
            'inboxUrl'   => Plugin::messagesUrl(),
            'sentUrl'    => Plugin::messagesUrl('sent'),
            'blockedUrl' => Plugin::messagesUrl('blocked'),
            'actionUrl'  => Plugin::postUrl(),
            'token'      => $this->security->getToken($this->request->getRequestUrl()),
            'maxLen'     => Plugin::maxTextLength(),
            'imgUploadEnabled' => Plugin::imgUploadEnabled(),
            'imgUploadMaxMB' => (int) (Plugin::imgUploadMaxBytes() / 1048576),
            'toolbarTarget' => 'qa-pm-body',
            'pmRecipientUid' => $view['mode'] === 'compose' && !empty($view['recipient'])
                ? (int) $view['recipient']['uid']
                : 0,
        ];
    }
}
