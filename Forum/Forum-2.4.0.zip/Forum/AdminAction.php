<?php
namespace TypechoPlugin\Forum;

use Typecho\Db;
use Widget\Notice;
use Widget\Security;
use Widget\User;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class AdminAction extends \Typecho\Widget
{
    public function action(): void
    {
        $do = trim((string) $this->request->get('do'));

        $this->guard();
        $this->requirePost();

        match ($do) {
            'topic-status' => $this->handleStatus('topic'),
            'post-status' => $this->handleStatus('post'),
            'topic-delete' => $this->handleDelete('topic'),
            'post-delete' => $this->handleDelete('post'),
            'topic-edit' => $this->handleEdit('topic'),
            'post-edit' => $this->handleEdit('post'),
            'reply' => $this->handleReply(),
            'cat-create' => $this->handleCategory('cat-create'),
            'cat-update' => $this->handleCategory('cat-update'),
            'cat-delete' => $this->handleCategory('cat-delete'),
            'cat-lock' => $this->handleCategoryLock(true),
            'cat-unlock' => $this->handleCategoryLock(false),
            'user-ban' => $this->handleUserBan(),
            'user-unban' => $this->handleUserUnban(),
            'clear-flags' => $this->handleClearFlags(),
            'reimport' => $this->handleReimport(),
            'prune-flags' => $this->handlePruneFlags(),
            default => $this->error('عملیات ناشناخته'),
        };
    }

    // ------------------------------------------------------------------
    //  امنیت
    // ------------------------------------------------------------------

    private function guard(): void
    {
        // مدیران (ویراستار به بالا) یا مالک انجمن
        $allowed = false;
        try {
            $user = User::alloc();
            if ($user->pass('editor', true)) {
                $allowed = true;
            } elseif ($user->hasLogin()) {
                $owner = Plugin::ownerUid();
                if ($owner > 0 && $owner === (int) $user->uid) {
                    $allowed = true;
                }
            }
        } catch (\Throwable $e) {
        }
        if (!$allowed) {
            User::alloc()->pass('editor'); // پرتاب خطای دسترسی هسته
        }

        Security::alloc()->protect();
    }

    private function requirePost(): void
    {
        if (!$this->request->isPost()) {
            $this->response->setStatus(405)->throwContent('این عملیات باید از طریق درخواست POST ارسال شود', 'text/plain');
        }
    }

    private function error(string $message): void
    {
        Notice::alloc()->set($message, 'error');
        $this->redirectHome();
        exit;
    }

    private function done(string $message): void
    {
        Notice::alloc()->set($message, 'success');
        $this->redirectBack();
    }

    private function redirectHome(): void
    {
        $this->response->redirect(Plugin::adminPanelUrl());
    }

    private function redirectBack(): void
    {
        // بازگشت به همان تب پنل — پشتیبانی از هر دو قالب back:
        // «panel=Forum%2FPanel.php&...» یا «extending.php?panel=...»
        $back = trim((string) $this->request->get('back', ''));
        $query = '';
        if ($back !== '') {
            if (str_starts_with($back, 'panel=')) {
                $query = $back;
            } elseif (str_starts_with($back, 'extending.php?')) {
                $query = substr($back, strlen('extending.php?'));
            }
        }

        $url = Plugin::adminPanelUrl();
        if ($query !== '' && str_contains($query, 'panel=Forum%2FPanel.php')) {
            $url .= (str_contains($url, '?') ? '&' : '?') . $query;
        }
        $this->response->redirect($url);
    }

    // ------------------------------------------------------------------
    //  وضعیت (تأیید / در انتظار / اسپم) — تکی و گروهی
    // ------------------------------------------------------------------

    private function handleStatus(string $type): void
    {
        $status = (string) $this->request->get('status');
        if (!in_array($status, ['approved', 'waiting', 'spam', 'done'], true)) {
            $this->error('وضعیت نامعتبر است.');
        }

        $ids = $this->itemIds($type);
        if (empty($ids)) {
            $this->error('موردی انتخاب نشده است.');
        }

        $db = Db::get();
        $table = $type === 'topic' ? 'table.forum_topics' : 'table.forum_posts';

        $db->query(
            $db->update($table)->rows(['status' => $status])->where('id IN ?', $ids)
        );

        $label = $type === 'topic' ? 'پرسش' : 'پاسخ';
        $stateLabel = ['approved' => 'تأیید', 'waiting' => 'در انتظار تأیید', 'spam' => 'اسپم', 'done' => 'انجام شده'][$status];

        // اعلان‌های ایمیلی برای مواردی که تأیید شدند (مثل پنل دیدگاه‌ها)
        if ($status === 'approved') {
            foreach ($ids as $id) {
                try {
                    $row = $type === 'topic'
                        ? Plugin::topicById((int) $id)
                        : Plugin::postById((int) $id);
                    if ($row === null) {
                        continue;
                    }
                    $view = $type === 'topic'
                        ? Plugin::topicRowToLegacy($row)
                        : Plugin::postRowToLegacy($row);
                    $topicRow = $type === 'topic' ? $row : Plugin::topicById((int) $row['topic_id']);
                    if ($topicRow === null) {
                        continue;
                    }
                    [$t] = Plugin::splitQuestion((string) $topicRow['text']);
                    $mailObj = Plugin::mailCommentObject(
                        (string) $row['text'],
                        (int) $view['coid'],
                        (string) Plugin::stripMarkup($t),
                        Plugin::threadUrl((int) $topicRow['id']) . ($type === 'post' ? '#c' . (int) $view['coid'] : ''),
                        (string) $view['author'],
                        (string) $view['mail'],
                        (int) $view['authorId'],
                        (string) $view['ip'],
                        (int) $view['created'],
                        $type === 'post' ? (int) $topicRow['id'] : 0,
                        (int) $topicRow['id']
                    );
                    $mailObj->status = 'approved';
                    Plugin::notifyMail($mailObj, 'approved', $type === 'topic' ? null : $topicRow);
                } catch (\Throwable $e) {
                    // ایمیل نباید عملیات را متوقف کند
                }
            }
        }

        $this->done('وضعیت ' . count($ids) . ' ' . $label . ' به «' . $stateLabel . '» تغییر کرد.');
    }

    /** خواندن شناسه‌های انتخابی (تکی یا گروهی) */
    private function itemIds(string $type): array
    {
        $key = $type === 'topic' ? 'topic' : 'post';
        $single = (int) ($this->request->filter('int')->get($key) ?: 0);
        if ($single > 0) {
            return [$single];
        }
        $multi = (array) ($this->request->get($key . 's') ?: []);
        $ids = [];
        foreach ($multi as $v) {
            $v = (int) $v;
            if ($v > 0) {
                $ids[] = $v;
            }
        }
        return array_values(array_unique($ids));
    }

    // ------------------------------------------------------------------
    //  حذف
    // ------------------------------------------------------------------

    private function handleDelete(string $type): void
    {
        $ids = $this->itemIds($type);
        if (empty($ids)) {
            $this->error('موردی انتخاب نشده است.');
        }

        $db = Db::get();
        $count = 0;

        foreach ($ids as $id) {
            if ($type === 'topic') {
                $topic = Plugin::topicById((int) $id);
                if ($topic === null) {
                    continue;
                }
                // حذف آبشاری پاسخ‌ها + اعلان‌ها + نظرسنجی + گزارش‌ها + پسندها
                Plugin::deletePoll((int) $id);
                Plugin::clearFlags((int) $id);
                Plugin::clearLikes((int) $id);
                $db->query($db->delete('table.forum_posts')->where('topic_id = ?', (int) $id));
                $db->query($db->delete('table.forum_notifications')->where('topic_id = ? OR item_id = ?', (int) $id, (int) $id));
                $db->query($db->delete('table.forum_topics')->where('id = ?', (int) $id));
                $count++;
            } else {
                $post = Plugin::postById((int) $id);
                if ($post === null) {
                    continue;
                }
                Plugin::clearFlags((int) $id);
                Plugin::clearLikes((int) $id);
                $db->query($db->delete('table.forum_posts')->where('id = ?', (int) $id));
                $count++;
            }
        }

        Plugin::pruneFlags();
        Plugin::pruneLikes();

        $label = $type === 'topic' ? 'پرسش' : 'پاسخ';
        $this->done($count . ' ' . $label . ' حذف شد.');
    }

    // ------------------------------------------------------------------
    //  ویرایش (نویسنده/ایمیل/نشانی/متن/عنوان)
    // ------------------------------------------------------------------

    private function handleEdit(string $type): void
    {
        $id = (int) ($this->request->filter('int')->get($type === 'topic' ? 'topic' : 'post') ?: 0);
        $row = $type === 'topic' ? Plugin::topicById($id) : Plugin::postById($id);
        if ($row === null) {
            $this->error('مورد یافت نشد.');
        }

        $db = Db::get();
        $table = $type === 'topic' ? 'table.forum_topics' : 'table.forum_posts';

        $rows = [];

        $author = trim((string) $this->request->get('author'));
        if ($author !== '') {
            $rows['author_name'] = mb_substr($author, 0, 150);
        }
        $mail = trim((string) $this->request->get('mail'));
        if ($mail !== '') {
            if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
                $this->error('نشانی ایمیل معتبر نیست.');
            }
            $rows['author_mail'] = mb_substr($mail, 0, 150);
        }
        $url = trim((string) $this->request->get('url'));
        if ($url !== '') {
            if (!preg_match('#^https?://#i', $url)) {
                $url = 'https://' . ltrim($url, '/');
            }
            $rows['author_url'] = mb_substr($url, 0, 255);
        }

        $text = trim((string) $this->request->get('text'));
        if ($text !== '') {
            if (mb_strlen($text) > Plugin::maxTextLength()) {
                $this->error('متن بیش از حد مجاز است.');
            }
            // ۲.۲.۰ — فیلتر کلمات (سانسور خودکار) قبل از ذخیره‌سازی ویرایش مدیر
            $text = Plugin::applyWordFilters($text);
            $rows['text'] = $text;
            if ($type === 'topic') {
                $title = trim((string) $this->request->get('title'));
                if ($title === '') {
                    [$title] = Plugin::splitQuestion($text);
                }
                $rows['title'] = mb_substr(Plugin::stripMarkup($title), 0, 250);
            }
        } elseif ($type === 'topic') {
            $title = trim((string) $this->request->get('title'));
            if ($title !== '') {
                $rows['title'] = mb_substr(Plugin::stripMarkup($title), 0, 250);
            }
        }

        if (empty($rows)) {
            $this->error('تغییری برای ذخیره ارسال نشد.');
        }

        $rows['modified'] = time();
        $db->query($db->update($table)->rows($rows)->where('id = ?', $id));

        // ویرایش/افزودن/حذف نظرسنجی پرسش در پنل (۲.۰.۰)
        // poll_present تضمین می‌کند فیلدهای نظرسنجی در مودال بوده‌اند
        if ($type === 'topic' && Plugin::pollsEnabled()
            && (string) $this->request->get('poll_present') === '1') {
            $hadPoll = Plugin::getPoll($id) !== null;
            if ((string) $this->request->get('has_poll') === '1') {
                $pollQ = trim((string) $this->request->get('poll_question'));
                $pollOptsRaw = trim((string) $this->request->get('poll_options'));
                $pollOpts = array_values(array_filter(
                    array_map('trim', explode("\n", str_replace(["\r\n", "\r"], "\n", $pollOptsRaw))),
                    static fn ($o) => $o !== ''
                ));
                if ($pollQ !== '' && count($pollOpts) >= 2) {
                    Plugin::setPoll($id, $pollQ, $pollOpts);
                }
            } elseif ($hadPoll) {
                // تیک برداشته شده — نظرسنجی و آرا آن حذف می‌شوند
                Plugin::deletePoll($id);
            }
        }

        $this->done('تغییرات ذخیره شد.');
    }

    // ------------------------------------------------------------------
    //  پاسخ مدیر
    // ------------------------------------------------------------------

    private function handleReply(): void
    {
        $topicId = (int) ($this->request->filter('int')->get('topic') ?: 0);
        $topic = Plugin::topicById($topicId);
        if ($topic === null) {
            $this->error('پرسش یافت نشد.');
        }

        $text = trim((string) $this->request->get('text'));
        if ($text === '') {
            $this->error('متن پاسخ را بنویسید.');
        }
        if (mb_strlen($text) > Plugin::maxTextLength()) {
            $this->error('متن بیش از حد مجاز است.');
        }

        $user = User::alloc();
        $now = time();

        $db = Db::get();
        // query() برای INSERT همان شناسهٔ درج‌شده را برمی‌گرداند
        $postId = (int) $db->query(
            $db->insert('table.forum_posts')->rows([
                'topic_id'     => $topicId,
                'text'         => $text,
                'author_id'    => (int) ($user->uid ?? 0),
                'author_name'  => (string) ($user->screenName ?? 'مدیر'),
                'author_mail'  => (string) ($user->mail ?? ''),
                'author_url'   => (string) ($user->url ?? ''),
                'author_ip'    => (string) $this->request->getIp(),
                'author_agent' => (string) $this->request->getAgent(),
                'status'       => 'approved',
                'created'      => $now,
                'modified'     => $now,
            ])
        );

        // اعلان درون‌انجمنی به نویسندهٔ پرسش
        try {
            $qAuthorId = (int) ($topic['author_id'] ?? 0);
            if ($qAuthorId > 0 && $qAuthorId !== (int) ($user->uid ?? 0)) {
                Plugin::addNotification($qAuthorId, 'reply', $postId, $topicId);
            }
        } catch (\Throwable $e) {
        }

        $this->done('پاسخ شما منتشر شد.');
    }

    // ------------------------------------------------------------------
    //  دسته‌ها
    // ------------------------------------------------------------------

    private function handleCategory(string $mode): void
    {
        $name = trim((string) $this->request->get('name'));
        $icon = trim((string) $this->request->get('icon'));
        $color = trim((string) $this->request->get('color'));
        if ($color !== '' && !preg_match('~^#[0-9a-fA-F]{6}$~', $color)) {
            $color = '';
        }
        if ($icon !== '' && !Plugin::isValidCategoryIcon($icon)) {
            $icon = '';
        }

        if ($mode === 'cat-create') {
            if ($name === '') {
                $this->error('نام دسته را بنویسید.');
            }
            $order = (int) ($this->request->filter('int')->get('order') ?: 0);
            Plugin::createCategory($name, $icon, $color, 0, $order);
            $this->done('دستهٔ جدید ساخته شد.');
        }

        if ($mode === 'cat-update') {
            $id = (int) ($this->request->filter('int')->get('id') ?: 0);
            if ($id < 1 || Plugin::getCategory($id) === null) {
                $this->error('دستهٔ موردنظر یافت نشد.');
            }
            if ($name === '') {
                $this->error('نام دسته را بنویسید.');
            }
            $order = (int) ($this->request->filter('int')->get('order') ?: -1);
            Plugin::updateCategory($id, $name, $icon, $color, 0, $order);
            $this->done('تغییرات دسته ذخیره شد.');
        }

        // cat-delete
        $id = (int) ($this->request->filter('int')->get('id') ?: 0);
        if ($id < 1 || Plugin::getCategory($id) === null) {
            $this->error('دستهٔ موردنظر یافت نشد.');
        }
        $reassign = (int) ($this->request->filter('int')->get('reassign') ?: 0);
        Plugin::deleteCategory($id, $reassign);
        $this->done('دسته حذف شد و پرسش‌هایش جابجا شدند.');
    }

    // ------------------------------------------------------------------
    //  قفل دسته — ۲.۲.۰
    // ------------------------------------------------------------------

    private function handleCategoryLock(bool $lock): void
    {
        $id = (int) ($this->request->filter('int')->get('id') ?: 0);
        if ($id < 1 || Plugin::getCategory($id) === null) {
            $this->error('دستهٔ موردنظر یافت نشد.');
        }

        Plugin::setCategoryLocked($id, $lock);
        $this->done($lock
            ? 'دسته قفل شد؛ نوشتن در آن فقط برای مدیران ممکن است.'
            : 'قفل دسته باز شد؛ کاربران می‌توانند در آن بنویسند.');
    }

    // ------------------------------------------------------------------
    //  بلاک اداری کاربران — ۲.۲.۰ (موقت یا همیشه)
    // ------------------------------------------------------------------

    /**
     * بلاک کاربر — مدت: همیشه یا ساعتی دلخواه.
     *
     * پارامترها: uid، duration (perm|12h|1d|3d|7d|30d|90d|custom)،
     * custom_hours (اگر duration=custom)، reason (اختیاری).
     * مدیران (editor+) و مالک انجمن قابل بلاک نیستند.
     */
    private function handleUserBan(): void
    {
        $uid = (int) ($this->request->filter('int')->get('uid') ?: 0);
        $user = Admin::findUser($uid);
        if ($user === null) {
            $this->error('کاربر موردنظر یافت نشد.');
        }

        // مدیران و مالک انجمن بلاک نمی‌شوند
        if (in_array($user['group'], ['administrator', 'editor'], true)) {
            $this->error('کاربران مدیر را نمی‌توان بلاک کرد.');
        }
        if ($uid === Plugin::ownerUid()) {
            $this->error('مالک انجمن را نمی‌توان بلاک کرد.');
        }

        $duration = (string) $this->request->get('duration', 'perm');
        $reason = trim((string) $this->request->get('reason'));

        $hours = match ($duration) {
            'perm'    => 0,
            '12h'     => 12,
            '1d'      => 24,
            '3d'      => 72,
            '7d'      => 168,
            '30d'     => 720,
            '90d'     => 2160,
            'custom'  => max(1, (int) ($this->request->filter('int')->get('custom_hours') ?: 0)),
            default   => 0,
        };

        if ($duration === 'custom' && $hours < 1) {
            $this->error('برای مدت دلخواه، تعداد ساعت را بنویسید.');
        }

        $until = $hours > 0 ? time() + $hours * 3600 : 0;

        $bannedBy = 0;
        try {
            $bannedBy = (int) User::alloc()->uid;
        } catch (\Throwable $e) {
        }

        $ok = Plugin::banUser($uid, $until, $reason, $bannedBy);
        if (!$ok) {
            $this->error('ثبت بلاک ممکن نشد؛ دوباره تلاش کنید.');
        }

        $untilText = $until === 0 ? 'برای همیشه' : Plugin::banUntilText(['until' => $until]);
        $this->done('کاربر «' . $user['name'] . '» ' . $untilText . ' بلاک شد.');
    }

    /** رفع بلاک کاربر */
    private function handleUserUnban(): void
    {
        $uid = (int) ($this->request->filter('int')->get('uid') ?: 0);
        $user = Admin::findUser($uid);
        if ($user === null) {
            $this->error('کاربر موردنظر یافت نشد.');
        }

        Plugin::unbanUser($uid);
        $this->done('بلاک کاربر «' . $user['name'] . '» برداشته شد.');
    }

    // ------------------------------------------------------------------
    //  گزارش‌ها
    // ------------------------------------------------------------------

    private function handleClearFlags(): void
    {
        $coid = (int) ($this->request->filter('int')->get('coid') ?: 0);
        if ($coid < 1) {
            $this->error('آیتم یافت نشد.');
        }
        Plugin::clearFlags($coid);
        $this->done('گزارش‌های این مورد رد شد.');
    }

    // ------------------------------------------------------------------
    //  ابزارها
    // ------------------------------------------------------------------

    private function handleReimport(): void
    {
        // ایمپورت idempotent است — فقط موارد منتقل‌نشده را اضافه می‌کند.
        $message = Import::run(null);
        $this->done($message !== '' ? $message : 'دادهٔ تازه‌ای برای ایمپورت نبود.');
    }

    private function handlePruneFlags(): void
    {
        Plugin::pruneFlags();
        Plugin::pruneLikes();
        $this->done('گزارش‌ها و پسندهای مرده پاک‌سازی شد.');
    }
}
