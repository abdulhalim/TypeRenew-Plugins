<?php
namespace TypechoPlugin\Forum;

use Typecho\Db;
use Typecho\Widget\Exception as WidgetException;
use Widget\Notice;
use Widget\Options;
use Widget\User;
use Widget\Security;
use Utils\Password;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class ProfileEdit extends ForumPage
{
    /** نگاشت نام گروه‌های هسته به فارسی */
    private const GROUP_LABELS = [
        'administrator' => 'مدیر',
        'editor'        => 'ویراستار',
        'contributor'   => 'همکار',
        'subscriber'    => 'عضو',
        'visitor'       => 'بازدیدکننده'
    ];

    protected function forumPageTitle(): string
    {
        $user = $this->profileUser();
        if ($user === null) {
            return (string) Plugin::opt('forumTitle', 'انجمن پرسش و پاسخ');
        }
        return 'ویرایش پروفایل ' . $user['displayName'];
    }

    protected function forumPageDescription(): string
    {
        return 'ویرایش پروفایل، ایمیل، رمز عبون و شبکه‌های اجتماعی در انجمن';
    }

    protected function forumPageUrl(): string
    {
        $uid = (int) ($this->request->get('uid') ?: 0);
        return $uid > 0 ? Plugin::profileEditUrl($uid) : Plugin::forumUrl();
    }

    public function render(): void
    {
        $this->renderForumPage('profile_edit.php');
    }

    /** ردیف کاربر پروفایل — یا null */
    private function profileUser(): ?array
    {
        static $cache = null;
        static $loaded = false;

        if ($loaded) {
            return $cache;
        }
        $loaded = true;
        $cache = null;

        $uid = (int) ($this->request->get('uid') ?: 0);
        if ($uid < 1) {
            return null;
        }

        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('uid', 'name', 'screenName', 'mail', 'url', 'created', 'group')
                    ->from('table.users')
                    ->where('uid = ?', $uid)
                    ->limit(1)
            );

            if ($row) {
                $row['displayName'] = trim((string) ($row['screenName'] ?: $row['name']));
                $row['groupLabel'] = self::GROUP_LABELS[$row['group']] ?? $row['group'];
                $meta = Plugin::getUserMeta((int) $uid);
                $row['bio'] = (string) ($meta['bio'] ?? '');
                $row['social'] = [
                    'twitter'   => (string) ($meta['twitter'] ?? ''),
                    'github'    => (string) ($meta['github'] ?? ''),
                    'telegram'  => (string) ($meta['telegram'] ?? ''),
                    'instagram' => (string) ($meta['instagram'] ?? ''),
                    'linkedin'  => (string) ($meta['linkedin'] ?? ''),
                    'youtube'   => (string) ($meta['youtube'] ?? ''),
                ];
                $cache = $row;
            }
        } catch (\Throwable $e) {
            $cache = null;
        }

        return $cache;
    }

    protected function prepareContext(): array
    {
        if (!Plugin::profileEnabled()) {
            throw new WidgetException(_t('صفحهٔ موردنظر یافت نشد'), 404);
        }

        $user = $this->profileUser();
        if ($user === null) {
            throw new WidgetException(_t('عضو موردنظر یافت نشد'), 404);
        }

        // فقط خود کاربر می‌تواند ویرایش کند
        // (۲.۱.۰ رفع) اگر کاربر وارد نشده باشد یا uid او با uid پروفایل
        // تطابق نداشته باشد، به جای پرتاب استثنای 403 (که پس از خروج در
        // همین صفحه رخ می‌داد)، او را به صفحهٔ ورود یا پروفایل هدایت می‌کنیم.
        if (!$this->user->hasLogin()) {
            $loginUrl = (string) $this->options->loginUrl;
            $editUrl = Plugin::profileEditUrl($uid);
            $sep = str_contains($loginUrl, '?') ? '&' : '?';
            $this->response->redirect($loginUrl . $sep . 'referer=' . rawurlencode($editUrl));
            return []; // redirect() درون خود exit می‌کند
        }
        if ((int) $this->user->uid !== (int) $user['uid']) {
            // کاربر واردشده ولی سعی می‌کند پروفایل دیگری را ویرایش کند → پروفایل خودش
            $this->response->redirect(Plugin::profileUrl((int) $this->user->uid));
            return [];
        }

        $uid = (int) $user['uid'];

        // اکشن ذخیره — مسیر /action/forum
        $actionUrl = Plugin::postUrl();
        $token = $this->security->getToken($this->request->getRequestUrl());

        // حداقل/حداکثر طول رمز عبور از کلاس Utils\Password
        $pwMin = 6;
        $pwMax = 64;
        try {
            $pwMin = Password::minLength();
            $pwMax = Password::maxLength();
        } catch (\Throwable $e) {
            // مقادیر پیش‌فرض
        }

        return $this->commonContext() + [
            'user'         => $user,
            'uid'          => $uid,
            'actionUrl'    => $actionUrl,
            'token'        => $token,
            'pwMin'        => $pwMin,
            'pwMax'        => $pwMax,
            'backUrl'      => Plugin::profileUrl($uid),
            'messagesUrl'  => Plugin::messagesUrl(),
            'profileEditUrl' => Plugin::profileEditUrl($uid),
            'maxTextLen'   => Plugin::maxTextLength(),
            'imgUploadEnabled' => Plugin::imgUploadEnabled(),
            'imgUploadMaxMB' => (int) (Plugin::imgUploadMaxBytes() / 1048576),
        ];
    }
}
