<?php
namespace TypechoPlugin\Forum;

use Typecho\Db;
use Typecho\Router;
use Typecho\Widget\Exception as WidgetException;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class ForumList extends ForumPage
{
    protected function forumPageTitle(): string
    {
        $search = $this->searchQuery();
        if ($search !== '') {
            return 'نتایج جستجو برای «' . $search . '»';
        }
        $catFilter = (int) ($this->request->filter('int')->get('cat') ?: 0);
        if ($catFilter > 0) {
            $cat = Plugin::getCategory($catFilter);
            if ($cat !== null) {
                return 'دستهٔ «' . $cat['name'] . '»';
            }
        }
        return (string) Plugin::opt('forumTitle', 'انجمن پرسش و پاسخ');
    }

    protected function forumPageDescription(): string
    {
        $search = $this->searchQuery();
        if ($search !== '') {
            return 'نتایج جستجوی «' . $search . '» در انجمن';
        }
        $catFilter = (int) ($this->request->filter('int')->get('cat') ?: 0);
        if ($catFilter > 0) {
            $cat = Plugin::getCategory($catFilter);
            if ($cat !== null) {
                return 'پرسش‌های دستهٔ «' . $cat['name'] . '» در انجمن';
            }
        }
        $intro = trim((string) Plugin::opt('forumIntro', ''));
        return $intro !== '' ? $intro : (string) $this->options->description;
    }

    protected function forumPageUrl(): string
    {
        $page = max(1, (int) ($this->request->get('page') ?: 1));
        $search = $this->searchQuery();
        $sort = (string) $this->request->get('sort');
        $cat = (int) ($this->request->filter('int')->get('cat') ?: 0);
        $filter = $this->request->get('filter') === 'unanswered' ? 'unanswered' : '';
        $url = ($page > 1 || $search !== '' || $cat > 0 || $filter !== '')
            ? self::pageUrl($page, $search, $filter, $sort, $cat)
            : Plugin::forumUrl();
        return $url;
    }

    public function render(): void
    {
        $this->renderForumPage('list.php');
    }

    /** عبارت جستجو از پارامتر q */
    protected function searchQuery(): string
    {
        $q = trim((string) ($this->request->get('q') ?? ''));
        return mb_strlen($q) > 100 ? mb_substr($q, 0, 100) : $q;
    }

    protected function prepareContext(): array
    {
        $db = Db::get();

        $pageSize = max(5, min(100, (int) Plugin::opt('pageSize', 15)));
        $page = max(1, (int) ($this->request->get('page') ?: 1));
        $search = $this->searchQuery();
        $filterUnanswered = ($this->request->get('filter') === 'unanswered');
        $sort = (string) $this->request->get('sort');
        if (!in_array($sort, ['newest', 'popular', 'unread', 'reported', 'pending'], true)) {
            $sort = 'newest';
        }
        $canManage = Plugin::canManage();
        $viewerUid = Plugin::viewerUid();
        // 'reported' فقط برای مدیران معتبر است
        if ($sort === 'reported' && !$canManage) {
            $sort = 'newest';
        }
        // 'pending' — مدیر: همهٔ صف تأیید؛ عضو: فقط‌‌های خودش؛ مهمان/جستجو: بی‌اعتبار
        if ($sort === 'pending' && (($viewerUid < 1 && !$canManage) || $search !== '')) {
            $sort = 'newest';
        }

        // فیلتر دسته‌بندی
        $catFilter = (int) ($this->request->filter('int')->get('cat') ?: 0);
        if ($catFilter > 0 && Plugin::getCategory($catFilter) === null) {
            $catFilter = 0;
        }

        // کاربر مهمان؟ — برای فیلتر پنهان‌شده‌ها
        $isGuest = false;
        try {
            $isGuest = !\Widget\User::alloc()->hasLogin();
        } catch (\Throwable $e) {
            $isGuest = true;
        }

        // -------------------------------------------------------------
        // ۰) حالت ویژه: صف «در انتظار تأیید» (۲.۰.۰)
        //    مدیر → همهٔ پرسش‌های در انتظار + تاپیک‌های دارای پاسخِ در انتظار
        //    عضو  → فقط پرسش‌های در انتظارِ خودش
        //    (دسته/جستجو/خوانده‌نشده روی این صف اثر ندارد)
        // -------------------------------------------------------------
        $pendingMode = ($sort === 'pending');
        $items = [];

        if ($pendingMode) {
            $waitingIds = [];
            foreach (Plugin::waitingTopicRows($canManage ? null : $viewerUid) as $w) {
                $waitingIds[(int) $w['id']] = true;
                $items[] = [
                    'coid'         => (int) $w['id'],
                    'created'      => (int) $w['created'],
                    'author'       => (string) $w['author_name'],
                    'mail'         => (string) $w['author_mail'],
                    'authorId'     => (int) ($w['author_id'] ?? 0),
                    'replies'      => 0,
                    'hasReply'     => false,
                    'lastActivity' => (int) $w['created'],
                    'isWaiting'    => true,
                ];
            }

            // مدیر: تاپیک‌های تأییدشده‌ای که پاسخِ در انتظار دارند
            if ($canManage) {
                $withWaiting = Plugin::topicsWithWaitingPosts();
                if (!empty($withWaiting)) {
                    $rows = $db->fetchAll(
                        $db->select('id', 'created', 'author_name', 'author_mail', 'author_id')
                            ->from('table.forum_topics')
                            ->where('status = ? AND id IN ?', 'approved', array_keys($withWaiting))
                    );
                    foreach ($rows as $w) {
                        if (isset($waitingIds[(int) $w['id']])) {
                            continue; // خودِ پرسش هم در صف است
                        }
                        $items[] = [
                            'coid'           => (int) $w['id'],
                            'created'        => (int) $w['created'],
                            'author'         => (string) $w['author_name'],
                            'mail'           => (string) $w['author_mail'],
                            'authorId'       => (int) ($w['author_id'] ?? 0),
                            'replies'        => 0,
                            'hasReply'       => false,
                            'lastActivity'   => (int) $w['created'],
                            'isWaiting'      => false,
                            'pendingReplies' => (int) ($withWaiting[(int) $w['id']] ?? 0),
                        ];
                    }
                }
            }

            usort($items, static fn ($a, $b) => $b['lastActivity'] <=> $a['lastActivity']);
        }

        // -------------------------------------------------------------
        // ۱) پرسش‌های تأییدشده — ستون‌های سبک برای مرتب‌سازی
        //    حالت جستجو: تطبیق روی عنوان/متن پرسش یا متن هر پاسخ
        // -------------------------------------------------------------
        if (!$pendingMode && $search !== '') {
            // تطبیق مستقیم روی خود پرسش‌ها (عنوان + متن = همان ستون text)
            $directRows = $db->fetchAll(
                $db->select('id')->from('table.forum_topics')
                    ->where(
                        'status = ? AND text LIKE ?',
                        'approved',
                        '%' . Plugin::likeEscape($search) . '%'
                    )
            );
            $directIds = array_map(static fn ($r) => (int) $r['id'], $directRows);

            // تطبیق غیرمستقیم: پاسخ‌هایی که متنشان می‌خورد → parent (پرسش) آن‌ها
            $indirectRows = $db->fetchAll(
                $db->select('topic_id')->from('table.forum_posts')
                    ->where(
                        'status = ? AND text LIKE ?',
                        'approved',
                        '%' . Plugin::likeEscape($search) . '%'
                    )
            );
            $indirectIds = array_map(static fn ($r) => (int) $r['topic_id'], $indirectRows);

            $matchingIds = array_values(array_unique(array_merge($directIds, $indirectIds)));

            if (empty($matchingIds)) {
                $lightRows = [];
            } else {
                $lightRows = $db->fetchAll(
                    $db->select('id', 'created', 'author_name', 'author_mail', 'author_id')
                        ->from('table.forum_topics')
                        ->where('status = ?', 'approved')
                        ->where('id IN ?', $matchingIds)
                );
            }
        } elseif (!$pendingMode) {
            $lightRows = $db->fetchAll(
                $db->select('id', 'created', 'author_name', 'author_mail', 'author_id')
                    ->from('table.forum_topics')
                    ->where('status = ?', 'approved')
            );
        }

        // -------------------------------------------------------------
        // ۲) تجمیع پاسخ‌ها: شمار و زمان آخرین پاسخ هر پرسش
        //    (در صف تأیید فقط برای شمار پاسخ‌های تأییدشدهٔ تاپیک‌ها)
        // -------------------------------------------------------------
        $aggRows = $pendingMode ? [] : $db->fetchAll(
            $db->select('topic_id', ['COUNT(id)' => 'num'], ['MAX(created)' => 'last'])
                ->from('table.forum_posts')
                ->where('status = ?', 'approved')
                ->group('topic_id')
        );
        $agg = [];
        $totalA = 0;
        foreach ($aggRows as $r) {
            $agg[(int) $r['topic_id']] = ['num' => (int) $r['num'], 'last' => (int) $r['last']];
            $totalA += (int) $r['num'];
        }

        // -------------------------------------------------------------
        // ۳) مرتب‌سازی بر اساس آخرین فعالیت (بامپ) — سپس برش صفحه
        // -------------------------------------------------------------
        $hiddenIds = $isGuest ? Plugin::hiddenIds() : [];
        foreach ((!$pendingMode && isset($lightRows)) ? $lightRows : [] as $q) {
            $coid = (int) $q['id'];
            // مهمان: پرسش‌های پنهان را نشان نده
            if ($isGuest && in_array($coid, $hiddenIds, true)) {
                continue;
            }
            $lastReply = $agg[$coid]['last'] ?? 0;
            $items[] = [
                'coid'         => $coid,
                'created'      => (int) $q['created'],
                'author'       => (string) $q['author_name'],
                'mail'         => (string) $q['author_mail'],
                'authorId'     => (int) ($q['author_id'] ?? 0),
                'replies'      => $agg[$coid]['num'] ?? 0,
                'hasReply'     => $lastReply > 0,
                'lastActivity' => max((int) $q['created'], $lastReply),
            ];
        }
        unset($lightRows, $aggRows, $agg);

        usort($items, static function ($a, $b) use ($sort) {
            if ($sort === 'popular') {
                // محبوب‌ترین: بیشترین پاسخ، سپس آخرین فعالیت
                if ($a['replies'] !== $b['replies']) {
                    return $b['replies'] <=> $a['replies'];
                }
            }
            if ($a['lastActivity'] !== $b['lastActivity']) {
                return $b['lastActivity'] <=> $a['lastActivity']; // جدیدترین فعالیت در ابتدا
            }
            return $b['coid'] <=> $a['coid'];
        });

        // ۲.۲.۰ — در تب «محبوب‌ترین» پست‌های سنجاق‌شده نادیده گرفته می‌شوند
        // (فقط بر اساس بیشترین پاسخ لیست می‌شوند). در سایر تب‌ها سنجاق‌شده‌ها
        // بالای فهرست می‌مانند (رفتار پیش‌فرض).
        $pinnedIds = ($pendingMode || $sort === 'popular') ? [] : Plugin::pinnedIds();
        if (!empty($pinnedIds)) {
            $pinnedItems = [];
            $plainItems = [];
            foreach ($items as $it) {
                if (in_array($it['coid'], $pinnedIds, true)) {
                    $pinnedItems[] = $it;
                } else {
                    $plainItems[] = $it;
                }
            }
            $items = array_merge($pinnedItems, $plainItems);
        } elseif ($sort === 'popular' && !empty(Plugin::pinnedIds())) {
            // در تب محبوب‌ترین، اگر پین‌شده‌ای در items بود، آن‌ها هم در همان
            // ترتیب sort محبوب‌ترین باقی بمانند (هیچ جداسازی بالای فهرست نمی‌شود).
            // یعنی: سنجاق‌شده‌ها هم مثل بقیه فقط بر اساس تعداد پاسخ مرتب می‌شوند.
        }

        // فیلتر دسته‌بندی (در صف تأیید اعمال نمی‌شود)
        if ($catFilter > 0 && !$pendingMode) {
            $items = array_values(array_filter($items, static function ($it) use ($db, $catFilter) {
                $topic = Plugin::topicById((int) $it['coid']);
                return $topic !== null && (int) ($topic['category_id'] ?? 0) === $catFilter;
            }));
        }

        // فیلتر «خوانده‌نشده» — پرسش‌هایی که بازدیدکننده هنوز ندیده، یا
        // پس از آخرین خواندنش پاسخ جدید گرفته‌اند
        if ($sort === 'unread') {
            $items = array_filter($items, static fn ($it) => !Plugin::isRead((int) $it['coid'], (int) $it['lastActivity']));
            $items = array_values($items);
        }

        // فیلتر «گزارش‌شده» — فقط پرسش‌هایی که خودشان یا پاسخ‌هایشان گزارش داده شده
        if ($sort === 'reported') {
            $flagMap = Plugin::flagMap();
            if (!empty($flagMap)) {
                $flaggedQuestionCoids = [];
                foreach (array_keys($flagMap) as $key) {
                    [$type, $id] = explode(':', $key, 2);
                    $id = (int) $id;
                    if ($type === 'topic') {
                        $flaggedQuestionCoids[$id] = true;
                    } else {
                        $post = Plugin::postById($id);
                        if ($post !== null) {
                            $flaggedQuestionCoids[(int) $post['topic_id']] = true;
                        }
                    }
                }
                $items = array_values(array_filter($items, static fn ($it) => isset($flaggedQuestionCoids[$it['coid']])));
            } else {
                $items = [];
            }
        }

        // فیلتر «بدون پاسخ» — فقط پرسش‌های بی‌پاسخ (نه در صف تأیید)
        if ($filterUnanswered && !$pendingMode) {
            $items = array_filter($items, static fn ($it) => $it['replies'] === 0);
            $items = array_values($items);
        }

        $totalQ = count($items);

        $pages = max(1, (int) ceil(count($items) / $pageSize));
        if (count($items) > 0 && $page > $pages) {
            throw new WidgetException(_t('صفحهٔ درخواستی وجود ندارد'), 404);
        }

        $slice = array_slice($items, ($page - 1) * $pageSize, $pageSize);

        // -------------------------------------------------------------
        // ۴) متن کامل پرسش‌های این صفحه + آخرین پاسخ‌دهندهٔ هرکدام
        // -------------------------------------------------------------
        $questions = [];
        $lockedIds = Plugin::lockedIds();
        $trackedIds = Plugin::trackedIds();
        $hiddenIdsAll = Plugin::hiddenIds();
        $viewsOn = Plugin::viewsEnabled();
        $pollsOn = Plugin::pollsEnabled();
        $flagMap = Plugin::flagMap();

        // یافتن کدام تاپیک‌های این صفحه نظرسنجی دارند — یک کوئری روی جدول polls
        $pollCoids = [];
        if ($pollsOn && !empty($slice)) {
            $sliceCoids = array_map(static fn ($it) => $it['coid'], $slice);
            try {
                $pollRows = $db->fetchAll(
                    $db->select('topic_id')->from('table.forum_polls')
                        ->where('topic_id IN ?', $sliceCoids)
                );
                foreach ($pollRows as $r) {
                    $pollCoids[(int) $r['topic_id']] = true;
                }
            } catch (\Throwable $e) {
            }
        }

        if ($slice) {
            $coids = array_map(static fn ($it) => $it['coid'], $slice);
            $fullRows = $db->fetchAll(
                $db->select()->from('table.forum_topics')->where('id IN ?', $coids)
            );
            $fullMap = [];
            foreach ($fullRows as $r) {
                $fullMap[(int) $r['id']] = $r;
            }

            foreach ($slice as $it) {
                $row = $fullMap[$it['coid']] ?? null;
                if (!$row) {
                    continue;
                }

                // شکل سازگار با قالب (کلیدهای coid/parent/author/…)
                $out = Plugin::topicRowToLegacy($row);

                $out['qaReplies'] = $it['replies'];
                $out['qaHasReply'] = $it['hasReply'];
                $out['qaLastActivity'] = $it['lastActivity'];
                // صف تأیید (۲.۰.۰): خودِ پرسش در انتظار است / پاسخِ در انتظار دارد
                $out['qaWaiting'] = !empty($it['isWaiting']);
                $out['qaPendingReplies'] = (int) ($it['pendingReplies'] ?? 0);
                $out['qaLocked'] = in_array($it['coid'], $lockedIds, true);
                $out['qaPinned'] = in_array($it['coid'], $pinnedIds, true);
                $out['qaTracked'] = in_array($it['coid'], $trackedIds, true);
                $out['qaHidden'] = in_array($it['coid'], $hiddenIdsAll, true);
                $out['qaHasBest'] = (int) ($row['best_post_id'] ?? 0) > 0;
                $out['qaViews'] = $viewsOn ? (int) ($row['views'] ?? 0) : 0;
                $out['qaHasPoll'] = isset($pollCoids[$it['coid']]);
                $out['qaCatId'] = (int) ($row['category_id'] ?? 0);
                $out['qaReported'] = isset($flagMap['topic:' . $it['coid']]);

                // آخرین پاسخ‌دهنده — یک کوئریِ نقطه‌ایِ سبک برای هر پرسشِ همین صفحه
                $out['qaLastAuthor'] = '';
                $out['qaLastMail'] = '';
                $out['qaLastAuthorId'] = 0;
                if ($it['hasReply']) {
                    $lr = $db->fetchRow(
                        $db->select('author_name', 'author_mail', 'author_id', 'created')
                            ->from('table.forum_posts')
                            ->where('topic_id = ? AND status = ?', $it['coid'], 'approved')
                            ->order('created', Db::SORT_DESC)
                            ->limit(1)
                    );
                    if ($lr) {
                        $lastUid = (int) ($lr['author_id'] ?? 0);
                        // (۲.۱.۰) اگر کاربر عضو است، نام/ایمیل زنده از جدول users خوانده می‌شود
                        $liveLast = Plugin::liveUserFieldsForList($lastUid);
                        $out['qaLastAuthor'] = $liveLast !== null
                            ? $liveLast['name']
                            : (string) $lr['author_name'];
                        $out['qaLastMail'] = $liveLast !== null
                            ? $liveLast['mail']
                            : (string) $lr['author_mail'];
                        $out['qaLastAuthorId'] = $lastUid;
                        $out['qaLastActivity'] = max($it['lastActivity'], (int) $lr['created']);
                    }
                }

                $questions[] = $out;
            }
        }

        $askOpen = (($this->request->get('ask') ?? '') === '1');

        // شمار پرسش‌های بی‌پاسخ (برای نمایش در دکمهٔ فیلتر)
        $unansweredCount = 0;
        foreach ($items as $it) {
            if ($it['replies'] === 0) {
                $unansweredCount++;
            }
        }

        // تب‌های مخفی «گزارش‌ها» و «در انتظار تأیید» از ۲.۰.۰ در
        // views/sortbar.php خودشان محاسبه می‌شوند (مشترک با پروفایل).

        return $this->commonContext() + [
            'questions'        => $questions,
            'page'             => $page,
            'pages'            => $pages,
            'totalQ'           => $totalQ,
            'totalA'           => $totalA,
            'search'           => $search,
            'askOpen'          => $askOpen,
            'filterUnanswered' => $filterUnanswered,
            'unansweredCount'  => $unansweredCount,
            'sort'             => $sort,
            'catFilter'        => $catFilter,
        ];
    }

    /** نشانی صفحهٔ n از فهرست (با حفظ عبارت جستجو، فیلتر، مرتب‌سازی و دسته) */
    public static function pageUrl(int $n, string $q = '', string $filter = '', string $sort = '', int $cat = 0): string
    {
        $url = $n <= 1
            ? Plugin::forumUrl()
            : Router::url(Plugin::ROUTE_PAGE, ['page' => $n], \Widget\Options::alloc()->index);

        $params = [];
        if ($q !== '') {
            $params['q'] = rawurlencode($q);
        }
        if ($filter !== '') {
            $params['filter'] = rawurlencode($filter);
        }
        if ($sort !== '' && $sort !== 'newest') {
            $params['sort'] = rawurlencode($sort);
        }
        if ($cat > 0) {
            $params['cat'] = $cat;
        }
        if (!empty($params)) {
            $url .= (str_contains($url, '?') ? '&' : '?') . http_build_query($params);
        }

        return $url;
    }
}
