(function () {
  'use strict';

  var root = document.documentElement;

  /* ---------- ۱. حالت روشن/تاریک (فقط قالب مستقل) ---------- */
  function currentTheme() {
    return root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  }

  var themeBtn = document.getElementById('qa-theme-btn');
  if (themeBtn) {
    themeBtn.addEventListener('click', function () {
      var next = currentTheme() === 'dark' ? 'light' : 'dark';
      root.setAttribute('data-theme', next);
      try { localStorage.setItem('tr-theme', next); } catch (e) { /* حالت خصوصی */ }
    });
  }

  /* ---------- ۷. آواتار گراواتار — جایگزین حرف اول ---------- */
  // رویداد error حبوب نمی‌شود ولی در فاز capture در document گرفته می‌شود
  document.addEventListener('error', function (ev) {
    var t = ev.target;
    if (t && t.tagName === 'IMG' && t.classList && t.classList.contains('qa-grava')) {
      t.remove();
    }
  }, true);

  /* ---------- ۲. فرم پرسش جدید ---------- */
  // دکمهٔ «پرسش جدید» در نوار مرتب‌سازی است (a.qa-nav-ask).
  // روی صفحهٔ فهرست فرم را باز/بسته می‌کند؛ در صفحات دیگر به
  // فهرست با پارامتر ask=1 می‌رود (رفتار طبیعی لینک).
  var askPanel = document.getElementById('qa-ask');

  function setAskOpen(open) {
    if (!askPanel) { return; }
    if (open) {
      askPanel.removeAttribute('hidden');
      askPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
      var focusTarget =
        askPanel.querySelector('textarea[name="text"]') ||
        askPanel.querySelector('input[name="author"]');
      if (focusTarget) {
        setTimeout(function () { focusTarget.focus(); }, 260);
      }
    } else {
      askPanel.setAttribute('hidden', '');
    }
    Array.prototype.forEach.call(document.querySelectorAll('.qa-nav-ask'), function (l) {
      l.setAttribute('aria-expanded', String(open));
      if (open) { l.classList.add('is-open'); } else { l.classList.remove('is-open'); }
    });
  }

  Array.prototype.forEach.call(document.querySelectorAll('.qa-nav-ask'), function (link) {
    link.addEventListener('click', function (ev) {
      if (!askPanel) { return; } // صفحهٔ فهرست نیست — لینک عادی به ?ask=1
      ev.preventDefault();
      setAskOpen(askPanel.hasAttribute('hidden'));
    });
  });

  // دکمهٔ «موضوع جدید» سایدبار هم فرم را باز می‌کند
  var sideAsk = document.querySelector('.qa-wu-new[href*="ask=1"]');
  if (sideAsk && sideAsk.getAttribute('href').indexOf('#') === -1) {
    sideAsk.addEventListener('click', function (ev) {
      if (askPanel) {
        // اگر روی همان صفحهٔ فهرست هستیم، فقط فرم باز شود
        ev.preventDefault();
        if (askPanel.hasAttribute('hidden')) {
          setAskOpen(true);
        } else {
          askPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      } else if ((sideAsk.getAttribute('href') || '').indexOf('javascript') === 0) {
        ev.preventDefault();
      }
    });
  }

  /* ---------- ۲.۵ منوی کاربر سربرگ (۲.۰.۰) ---------- */
  var userBtn = document.getElementById('qa-usermenu-btn');
  var userPop = document.getElementById('qa-usermenu-pop');

  function closeUserPop() {
    if (!userPop) { return; }
    userPop.setAttribute('hidden', '');
    if (userBtn) {
      userBtn.setAttribute('aria-expanded', 'false');
      userBtn.classList.remove('is-open');
    }
  }

  if (userBtn && userPop) {
    userBtn.addEventListener('click', function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      if (userPop.hasAttribute('hidden')) {
        userPop.removeAttribute('hidden');
        userBtn.setAttribute('aria-expanded', 'true');
        userBtn.classList.add('is-open');
      } else {
        closeUserPop();
      }
    });

    userBtn.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape') { closeUserPop(); userBtn.focus(); }
    });

    document.addEventListener('click', function (ev) {
      if (userPop.hasAttribute('hidden')) { return; }
      var t = ev.target;
      if (t && t.closest && t.closest('#qa-usermenu')) { return; }
      closeUserPop();
    });
  }

  /* ---------- ۳. بستن پیام‌ها ---------- */
  Array.prototype.forEach.call(
    document.querySelectorAll('.qa-banner-close'),
    function (btn) {
      btn.addEventListener('click', function () {
        var banner = btn.closest('.qa-banner');
        if (banner) { banner.remove(); }
      });
    }
  );

  /* ---------- ۱۰. پرش به فرم پاسخ + حذف جستجو ---------- */
  Array.prototype.forEach.call(
    document.querySelectorAll('.qa-reply-jump'),
    function (btn) {
      btn.addEventListener('click', function () {
        var respond = document.getElementById('respond');
        if (respond) {
          respond.scrollIntoView({ behavior: 'smooth', block: 'start' });
          var area = respond.querySelector('textarea[name="text"]');
          if (area) {
            setTimeout(function () { area.focus(); }, 260);
          }
        }
      });
    }
  );

  var searchClearBtn = document.querySelector('.qa-search-clear-btn');
  if (searchClearBtn) {
    searchClearBtn.addEventListener('click', function () {
      window.location.href = searchClearBtn.closest('form').getAttribute('action') || window.location.pathname;
    });
  }

  /* ---------- ۱۰.۵ دکمهٔ «لغو» در فرم پرسش/پاسخ ---------- */
  Array.prototype.forEach.call(
    document.querySelectorAll('.qa-form-cancel'),
    function (btn) {
      btn.addEventListener('click', function () {
        var targetId = btn.getAttribute('data-target') || '';
        var target = targetId ? document.getElementById(targetId) : null;

        // پاک‌کردن متن جعبهٔ متنِ همان فرم
        var form = btn.closest('form');
        if (form) {
          var area = form.querySelector('textarea[name="text"]');
          if (area) { area.value = ''; area.dispatchEvent(new Event('input', { bubbles: true })); }
        }

        // بستن پنل «پرسش جدید» اگر دکمه داخل آن است
        if (btn.closest('#qa-ask') && askPanel && !askPanel.hasAttribute('hidden')) {
          setAskOpen(false);
        }

        if (target) {
          target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        } else if (history.length > 1) {
          history.back();
        }
      });
    }
  );

  /* ---------- ۴. رشد خودکار جعبهٔ متن ---------- */
  function bindGrow(area) {
    var minHeight = Math.max(76, area.offsetHeight);
    function grow() {
      area.style.height = 'auto';
      area.style.height = Math.max(minHeight, area.scrollHeight) + 'px';
    }
    area.addEventListener('input', grow);
    if (area.value) { grow(); }
    area.addEventListener('qa:insert', grow);
  }
  Array.prototype.forEach.call(
    document.querySelectorAll('.qa-form textarea'),
    bindGrow
  );

  /* ---------- ۵. نوار ابزار ---------- */
  function insertInto(area, text, selStart, selEnd) {
    if (!area) { return; }
    var s = area.selectionStart || 0;
    var e = area.selectionEnd || 0;
    var v = area.value;
    area.value = v.slice(0, s) + text + v.slice(e);
    if (selStart != null) {
      area.setSelectionRange(s + selStart, s + (selEnd != null ? selEnd : selStart));
    } else {
      var cursor = s + text.length;
      area.setSelectionRange(cursor, cursor);
    }
    area.focus();
    area.dispatchEvent(new Event('input', { bubbles: true }));
    area.dispatchEvent(new Event('qa:insert', { bubbles: true }));
  }

  function selectedTextOf(area) {
    var s = area.selectionStart || 0;
    var e = area.selectionEnd || 0;
    return area.value.slice(s, e);
  }

  function promptUrl(msg, iconKind) {
    return qaPrompt({
      message: msg,
      variant: 'info',
      icon: iconKind === 'image' ? QA_ICONS.image : QA_ICONS.link,
      placeholder: 'https://',
      value: '',
      okText: 'درج'
    }).then(function (u) {
      if (u === null) { return null; }
      u = (u || '').trim();
      if (u === '' || u === 'https://') { return null; }
      if (!/^https?:\/\//i.test(u)) { u = 'https://' + u; }
      return u;
    });
  }

  /**
   * (۲.۱.۰ Markdown) پیش‌نمایش متن — رندر سمت کلاینت از Markdown.
   * متن را به HTML تبدیل کرده و در پنل زیر textarea نمایش می‌دهد.
   * این رندر ساده‌سازی‌شده است؛ رندر نهایی سمت سرور با HyperDown دقیق‌تر است.
   */
  function renderPreview(text) {
    var html = text;
    // escape HTML
    html = String(html).replace(/[&<>]/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[c];
    });

    // code block: ```\ncode\n```
    html = html.replace(/```(?:\n)?([\s\S]*?)(?:\n)?```/g, function (_, c) {
      return '<pre dir="ltr" class="qa-code"><code>' + c + '</code></pre>';
    });
    // inline code: `code`
    html = html.replace(/`([^`\n]+)`/g, '<code class="qa-code-i">$1</code>');
    // headings: ## text
    html = html.replace(/^### (.+)$/gm, '<h3 class="qa-head">$1</h3>');
    html = html.replace(/^## (.+)$/gm, '<h2 class="qa-head">$1</h2>');
    html = html.replace(/^# (.+)$/gm, '<h1 class="qa-head">$1</h1>');

    // (۲.۱.۰ رفع) ابتدا تصاویر را استخراج و با placeholder جایگزین کن
    // تا مرحلهٔ italic/bold به URL آسیب نزند (مثل تبدیل _ به <em>)
    var imgPlaceholders = [];
    html = html.replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g, function (_, alt, url) {
      var a = (alt || 'تصویر').trim();
      if (url && !/^https?:\/\//i.test(url) && !/^data:/i.test(url) && !/^\//.test(url)) {
        url = 'https://' + url;
      }
      var imgHtml = '<img src="' + url + '" class="qa-img qa-lightbox-img" alt="' + a + '" loading="lazy">';
      var key = '\x01IMG' + imgPlaceholders.length + '\x01';
      imgPlaceholders.push({ key: key, html: imgHtml });
      return key;
    });

    // bold: **text** or __text__
    html = html.replace(/\*\*([^\*\n]+)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/__([^_\n]+)__/g, '<strong>$1</strong>');
    // italic: *text* or _text_
    html = html.replace(/\*([^\*\n]+)\*/g, '<em>$1</em>');
    html = html.replace(/_([^_\n]+)_/g, '<em>$1</em>');

    // بازگرداندن placeholder های تصویر
    for (var ip = 0; ip < imgPlaceholders.length; ip++) {
      html = html.replace(imgPlaceholders[ip].key, imgPlaceholders[ip].html);
    }
    // aparat embed (placeholder)
    html = html.replace(/\[aparat\]([A-Za-z0-9_-]+)\[\/aparat\]/g, function (_, v) {
      return '<div class="qa-aparat"><iframe src="https://www.aparat.com/video/video/embed/videohash/' + v + '/vt/frame" allowfullscreen="true" scrolling="no" frameborder="0"></iframe></div>';
    });
    // hr: ---
    html = html.replace(/^---$/gm, '<hr class="qa-hr">');
    // quote: > text (می‌تواند چند خط باشد)
    html = html.replace(/(?:^|\n)((?:&gt; .+(?:\n|$))+)/g, function (_, items) {
      var lines = items.trim().split('\n').map(function (l) {
        return l.replace(/^&gt; /, '');
      });
      return '<blockquote class="qa-quote"><div class="qa-quote-body">' + lines.join('<br>') + '</div></blockquote>';
    });
    // unordered list: - item
    html = html.replace(/(?:^|\n)((?:- .+(?:\n|$))+)/g, function (_, items) {
      var lis = items.trim().split('\n').map(function (l) {
        return '<li>' + l.replace(/^- /, '') + '</li>';
      }).join('');
      return '<ul class="qa-list">' + lis + '</ul>';
    });
    // ordered list: 1. item
    html = html.replace(/(?:^|\n)((?:\d+\. .+(?:\n|$))+)/g, function (_, items) {
      var lis = items.trim().split('\n').map(function (l) {
        return '<li>' + l.replace(/^\d+\. /, '') + '</li>';
      }).join('');
      return '<ol class="qa-list">' + lis + '</ol>';
    });

    // nl2br (only for lines not already wrapped in block elements)
    html = html.replace(/\n/g, '<br>');

    return html;
  }

  function togglePreview(bar, area) {
    var form = bar.closest('form') || bar.parentNode;
    if (!form) { return; }
    var existing = form.querySelector('.qa-preview-panel');
    if (existing) {
      // اگر باز است، ببند
      existing.parentNode.removeChild(existing);
      bar.classList.remove('is-active');
      return;
    }
    var panel = document.createElement('div');
    panel.className = 'qa-preview-panel';
    var head = document.createElement('div');
    head.className = 'qa-preview-head';
    head.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg><span>پیش‌نمایش</span>';
    panel.appendChild(head);
    var body = document.createElement('div');
    body.className = 'qa-preview-body';
    body.innerHTML = renderPreview(area.value || '');
    panel.appendChild(body);
    // قرار دادن پنل بعد از textarea
    if (area.parentNode) {
      area.parentNode.insertBefore(panel, area.nextSibling);
    }
    bar.classList.add('is-active');
    // به‌روزرسانی زنده هنگام تایپ
    var update = function () { body.innerHTML = renderPreview(area.value || ''); };
    area.addEventListener('input', update);
    // در صورت بستن پنل، listener پاک شود
    panel._cleanup = function () { area.removeEventListener('input', update); };
  }

  /* آپلود تصویر از کامپیوتر به imgurl.ir (۲.۰.۰) — انتخاب فایل، ارسال
     به اکشن افزونه (پروکسی سمت سرور) و درج خودکار ![alt](url) به‌صورت Markdown */
  function triggerImageUpload(bar, area, btn) {
    var form = bar.closest('form');
    if (!form) {
      qaNotice({ variant: 'danger', title: 'خطای ویرایشگر', message: 'فرم ویرایشگر یافت نشد.' });
      return;
    }
    var tokenInput = form.querySelector('input[name="_"]');
    if (!tokenInput) {
      qaNotice({ variant: 'danger', title: 'توکن امنیتی', message: 'توکن امنیتی فرم یافت نشد؛ صفحه را نوسازی کنید.' });
      return;
    }
    var actionUrl = form.getAttribute('action') || window.location.href;

    var input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/jpeg,image/jpg,image/png,image/gif,image/webp,image/bmp';
    input.style.display = 'none';
    input.setAttribute('aria-hidden', 'true');
    input.setAttribute('tabindex', '-1');

    input.addEventListener('change', function () {
      var file = input.files && input.files[0];
      var done = function () {
        if (input.parentNode) { input.parentNode.removeChild(input); }
      };
      if (!file) { done(); return; }

      var maxMB = parseInt(btn.getAttribute('data-max-mb') || '10', 10);
      if (file.size > maxMB * 1048576) {
        qaNotice({ variant: 'warn', title: 'حجم تصویر', icon: QA_ICONS.image, message: 'حجم تصویر نباید از ' + faDigitsJs(maxMB) + ' مگابایت بیشتر باشد.' });
        done();
        return;
      }
      if (file.type && file.type.indexOf('image/') !== 0) {
        qaNotice({ variant: 'warn', title: 'نوع فایل', icon: QA_ICONS.image, message: 'فقط فایل‌های تصویری (JPG، PNG، GIF، WebP، BMP) مجاز هستند.' });
        done();
        return;
      }

      var oldTip = btn.getAttribute('data-tooltip');
      btn.classList.add('is-busy');
      btn.setAttribute('data-tooltip', 'در حال بارگذاری تصویر…');

      var fd = new FormData();
      fd.append('mode', 'upload-image');
      fd.append('file', file, file.name || 'image.png');
      fd.append('_', tokenInput.value);

      fetch(actionUrl, {
        method: 'POST',
        body: fd,
        credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      })
        .then(function (res) { return res.json(); })
        .then(function (data) {
          btn.classList.remove('is-busy');
          btn.setAttribute('data-tooltip', oldTip);
          done();
          if (data && data.ok && data.url) {
            // (۲.۱.۰ Markdown) مودال دوم: متن جایگزین تصویر (alt) را بپرس.
            // خروجی: ![alt](url)
            qaPrompt({
              message: 'متن جایگزین تصویر (alt) را بنویسید (اختیاری):',
              variant: 'info',
              icon: QA_ICONS.image,
              placeholder: 'متن جایگزین تصویر',
              value: '',
              okText: 'درج'
            }).then(function (alt) {
              alt = (alt || '').trim();
              insertInto(area, '![' + alt + '](' + data.url + ')');
            });
          } else {
            qaNotice({
              variant: 'danger',
              title: 'بارگذاری تصویر',
              icon: QA_ICONS.image,
              message: (data && data.message) || 'بارگذاری تصویر ممکن نشد؛ کمی بعد دوباره تلاش کنید.'
            });
          }
        })
        .catch(function () {
          btn.classList.remove('is-busy');
          btn.setAttribute('data-tooltip', oldTip);
          done();
          qaNotice({
            variant: 'danger',
            title: 'خطای ارتباط',
            icon: QA_ICONS.wifiOff,
            message: 'برقراری ارتباط با سرور ممکن نشد؛ دوباره تلاش کنید.'
          });
        });
    });

    document.body.appendChild(input);
    input.click();
  }

  Array.prototype.forEach.call(
    document.querySelectorAll('.qa-toolbar'),
    function (bar) {
      var area = document.getElementById(bar.getAttribute('data-qa-toolbar') || '');

      bar.addEventListener('click', function (ev) {
        var btn = ev.target.closest('.qa-tb-btn, .qa-emoji-btn');
        if (!btn || !area) { return; }
        ev.preventDefault();

        // شکلک‌ها
        if (btn.classList.contains('qa-emoji-btn')) {
          insertInto(area, btn.getAttribute('data-emoji') || '');
          return;
        }

        var kind = btn.getAttribute('data-qa');

        if (kind === 'bold') {
          // (۲.۱.۰ Markdown) بولد — **text**
          var bSel = selectedTextOf(area);
          if (bSel) { insertInto(area, '**' + bSel + '**'); }
          else { insertInto(area, '****', 2, 2); }
        } else if (kind === 'italic') {
          // (۲.۱.۰ Markdown) ایتالیک — *text*
          var iSel = selectedTextOf(area);
          if (iSel) { insertInto(area, '*' + iSel + '*'); }
          else { insertInto(area, '**', 1, 1); }
        } else if (kind === 'h2') {
          // (۲.۱.۰ Markdown) سربرگ — ## text
          var hSel = selectedTextOf(area);
          if (hSel) { insertInto(area, '## ' + hSel); }
          else { insertInto(area, '## ', 3, 3); }
        } else if (kind === 'code') {
          // (۲.۱.۰ Markdown) بلوک کد — ```\ncode\n```
          var sel = selectedTextOf(area);
          if (sel) {
            insertInto(area, '```\n' + sel + '\n```');
          } else {
            insertInto(area, '```\n\n```', 5, 5);
          }
        } else if (kind === 'inline-code') {
          // (۲.۱.۰ Markdown) کد درون‌خطی — `code`
          var icSel = selectedTextOf(area);
          if (icSel) {
            insertInto(area, '`' + icSel + '`');
          } else {
            insertInto(area, '``', 1, 1);
          }
        } else if (kind === 'hr') {
          // (۲.۱.۰ Markdown) خط افقی — ---
          insertInto(area, '\n---\n');
        } else if (kind === 'quote') {
          // (۲.۱.۰ Markdown) نقل قول — > text
          var qSel = selectedTextOf(area);
          if (qSel) {
            // اگر متن انتخاب شده، هر خط را با > پیشوند کن
            var lines = qSel.split('\n');
            var quoted = lines.map(function (l) { return '> ' + l; }).join('\n');
            insertInto(area, '\n' + quoted + '\n');
          } else {
            insertInto(area, '\n> ', 3, 3);
          }
        } else if (kind === 'ul') {
          // (۲.۱.۰ Markdown) لیست نامرتب — - item
          insertInto(area, '- مورد اول\n- مورد دوم\n- مورد سوم', 2, 0);
        } else if (kind === 'ol') {
          // (۲.۱.۰ Markdown) لیست مرتب — 1. item
          insertInto(area, '1. مورد اول\n2. مورد دوم\n3. مورد سوم', 3, 0);
        } else if (kind === 'aparat') {
          // (۲.۱.۰) ویدئو آپارات — دریافت URL یا Video ID
          qaPrompt({
            message: 'نشانی ویدئو در آپارات یا کد ویدئو را بنویسید:',
            variant: 'info',
            icon: QA_ICONS.image,
            placeholder: 'https://www.aparat.com/v/XXXXXXXX',
            value: '',
            okText: 'درج'
          }).then(function (raw) {
            if (raw === null) { return; }
            raw = (raw || '').trim();
            if (raw === '') { return; }
            // استخراج video hash از URL آپارات
            var vid = '';
            var m = raw.match(/aparat\.com\/v\/([A-Za-z0-9_-]+)/i);
            if (m) { vid = m[1]; }
            else if (/^[A-Za-z0-9_-]+$/.test(raw)) { vid = raw; }
            else if ((m = raw.match(/aparat\.com\/video\/video\/[^\/]+\/([^\/?]+)/i))) { vid = m[1]; }
            if (vid === '') {
              qaNotice({ variant: 'warn', title: 'ویدئو آپارات', icon: QA_ICONS.image, message: 'نشانی آپارات معتبر نیست.' });
              return;
            }
            // [aparat] همچنان به‌صورت BBCode نگه‌داری می‌شود (در renderText pre-process می‌شود)
            insertInto(area, '[aparat]' + vid + '[/aparat]');
          });
        } else if (kind === 'preview') {
          // (۲.۱.۰) پیش‌نمایش متن — بدون نیاز به ذخیره
          togglePreview(bar, area);
        } else if (kind === 'link') {
          // (۲.۱.۰ Markdown) مودال دو مرحله‌ای: اول URL، سپس متن پیوند.
          // خروجی: [text](url) یا <url>
          var preselectedLabel = selectedTextOf(area) || '';
          promptUrl('نشانی پیوند را بنویسید:').then(function (u) {
            if (!u) { return; }
            qaPrompt({
              message: 'متن پیوند را بنویسید (اختیاری):',
              variant: 'info',
              icon: QA_ICONS.link,
              placeholder: 'متن پیوند',
              value: preselectedLabel,
              okText: 'درج'
            }).then(function (label) {
              if (label === null) { label = preselectedLabel; }
              label = (label || '').trim();
              if (label === '') {
                // بدون متن: <url>
                insertInto(area, '<' + u + '>');
              } else {
                // با متن: [text](url)
                insertInto(area, '[' + label + '](' + u + ')');
              }
            });
          });
        } else if (kind === 'image') {
          // (۲.۱.۰ Markdown) مودال دو مرحله‌ای: اول نشانی تصویر، سپس متن جایگزین.
          // خروجی: ![alt](url)
          promptUrl('نشانی تصویر را بنویسید:', 'image').then(function (iu) {
            if (!iu) { return; }
            qaPrompt({
              message: 'متن جایگزین تصویر (alt) را بنویسید (اختیاری):',
              variant: 'info',
              icon: QA_ICONS.image,
              placeholder: 'متن جایگزین',
              value: '',
              okText: 'درج'
            }).then(function (alt) {
              alt = (alt || '').trim();
              // ![alt](url) — حتی بدون alt هم ![](url) درست است
              insertInto(area, '![' + alt + '](' + iu + ')');
            });
          });
        } else if (kind === 'upload') {
          triggerImageUpload(bar, area, btn);
        } else if (kind === 'emoji') {
          /* نوار شکلک‌ها (۲.۰.۰) — نواری درون‌خطی زیر همان نوار ابزار؛
             فقط همین دکمه آن را نشان/مخفی می‌کند و کلیک روی شکلک‌ها
             هرگز آن را نمی‌بندد تا بتوان چند شکلک پشت‌سرهم درج کرد */
          var panel = bar.querySelector('.qa-emoji-bar');
          if (!panel) { return; }
          if (panel.hasAttribute('hidden')) {
            panel.removeAttribute('hidden');
            btn.setAttribute('aria-expanded', 'true');
            btn.classList.add('is-open');
          } else {
            panel.setAttribute('hidden', '');
            btn.setAttribute('aria-expanded', 'false');
            btn.classList.remove('is-open');
          }
        }
      });
    }
  );

  /* ---------- ۶. نقل قول از پاسخ‌ها (۲.۱.۰ Markdown) ---------- */
  Array.prototype.forEach.call(
    document.querySelectorAll('.qa-quote-btn'),
    function (btn) {
      btn.addEventListener('click', function () {
        var replyArea = document.getElementById('qa-reply-text');
        if (!replyArea) { return; }

        var author = btn.getAttribute('data-quote-author') || '';
        var article = btn.closest('.qa-answer');
        var bodyEl = article ? article.querySelector('.qa-answer-body') : null;
        var text = bodyEl ? (bodyEl.textContent || '') : '';

        text = text.replace(/\s+/g, ' ').trim();
        if (text.length > 400) { text = text.slice(0, 400).trim() + '…'; }

        // (۲.۱.۰ Markdown) نقل قول به‌صورت Markdown:
        //   > **نام نویسنده** نوشت:
        //   > متن نقل‌شده
        var block = '';
        if (author) {
          block += '> **' + author + ' نوشت:**\n';
        }
        // هر خط متن را با > پیشوند کن
        var lines = (text || '…').split('\n');
        for (var i = 0; i < lines.length; i++) {
          block += '> ' + lines[i] + '\n';
        }
        var insert = (replyArea.value ? '\n\n' : '') + block + '\n';

        replyArea.focus();
        var pos = replyArea.value.length;
        replyArea.setSelectionRange(pos, pos);
        insertInto(replyArea, insert);

        var replySection = document.getElementById('respond');
        if (replySection) {
          replySection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      });
    }
  );

  /* ---------- ۹. ویرایش درجا ---------- */
  function bindEditToggle(btn) {
    btn.addEventListener('click', function () {
      var editBox = document.getElementById(btn.getAttribute('data-target') || '');
      if (!editBox) { return; }

      var article = btn.closest('article, .qa-question') || btn.closest('.qa-answer');
      var bodyEl = article ? (article.querySelector('.qa-question-body') || article.querySelector('.qa-answer-body')) : null;

      if (editBox.hasAttribute('hidden')) {
        // بستن سایر ویرایش‌های باز
        Array.prototype.forEach.call(
          document.querySelectorAll('.qa-edit:not([hidden])'),
          function (open) { open.setAttribute('hidden', ''); }
        );

        editBox.removeAttribute('hidden');
        if (bodyEl) { bodyEl.style.display = 'none'; }
        editBox.scrollIntoView({ behavior: 'smooth', block: 'center' });

        var area = editBox.querySelector('textarea[name="text"]');
        if (area) {
          bindGrow(area);
          setTimeout(function () { area.focus(); }, 200);
        }
      } else {
        editBox.setAttribute('hidden', '');
        if (bodyEl) { bodyEl.style.display = ''; }
      }
    });
  }

  Array.prototype.forEach.call(
    document.querySelectorAll('.qa-edit-toggle'),
    bindEditToggle
  );

  Array.prototype.forEach.call(
    document.querySelectorAll('.qa-edit-cancel'),
    function (btn) {
      btn.addEventListener('click', function () {
        var editBox = document.getElementById(btn.getAttribute('data-target') || '');
        if (!editBox) { return; }

        // بازگرداندن متن اولیه
        var area = editBox.querySelector('textarea[name="text"]');
        if (area && area.getAttribute('data-original') !== null) {
          area.value = area.getAttribute('data-original') || '';
        }

        editBox.setAttribute('hidden', '');

        var article = editBox.closest('article') || editBox.closest('.qa-question');
        var bodyEl = article ? (article.querySelector('.qa-question-body') || article.querySelector('.qa-answer-body')) : null;
        if (bodyEl) { bodyEl.style.display = ''; }
      });
    }
  );

  // نگه‌داری متن اولیه برای انصراف
  Array.prototype.forEach.call(
    document.querySelectorAll('.qa-edit-form textarea'),
    function (area) {
      area.setAttribute('data-original', area.value);
    }
  );

  /* ---------- ۱۱. دکمهٔ کپی خودکار روی بلوک‌های کد ---------- */
  function showCopied(btn) {
    btn.classList.add('is-copied');
    setTimeout(function () { btn.classList.remove('is-copied'); }, 1800);
  }

  function fallbackCopy(text, btn) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.top = '0';
    ta.style.left = '0';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); showCopied(btn); } catch (e) { /* بی‌اثر */ }
    document.body.removeChild(ta);
  }

  function copyCode(btn) {
    var pre = btn.closest('.qa-code');
    var codeEl = pre ? pre.querySelector('code') : null;
    var text = codeEl ? codeEl.textContent : '';
    if (!text) { return; }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text)
        .then(function () { showCopied(btn); })
        .catch(function () { fallbackCopy(text, btn); });
    } else {
      fallbackCopy(text, btn);
    }
  }

  Array.prototype.forEach.call(
    document.querySelectorAll('pre.qa-code'),
    function (pre) {
      if (pre.querySelector('.qa-code-copy')) { return; }
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'qa-code-copy';
      btn.setAttribute('aria-label', 'کپی این کد');
      btn.setAttribute('data-tooltip', 'کپی این کد');
      btn.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor"'
        + ' stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
        + '<rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>'
        + '<path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>'
        + '</svg>';
      btn.addEventListener('click', function () { copyCode(btn); });
      pre.appendChild(btn);
    }
  );

  /* ---------- ۱۲. اشتراک‌گذاری پرسش (۱.۴.۰) ---------- */
  Array.prototype.forEach.call(
    document.querySelectorAll('.qa-share-bar'),
    function (bar) {
      var url = bar.getAttribute('data-share-url') || window.location.href;
      var title = bar.getAttribute('data-share-title') || document.title;

      // کپی پیوند
      var copyBtn = bar.querySelector('.qa-share-copy');
      if (copyBtn) {
        copyBtn.addEventListener('click', function () {
          function done() {
            copyBtn.classList.add('is-copied');
            var old = copyBtn.querySelector('span');
            var orig = old ? old.textContent : '';
            if (old) { old.textContent = 'کپی شد!'; }
            setTimeout(function () {
              copyBtn.classList.remove('is-copied');
              if (old && orig) { old.textContent = orig; }
            }, 1800);
          }
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(url).then(done).catch(function () { fallbackCopy(url, done); });
          } else {
            fallbackCopy(url, done);
          }
        });
      }

      // تلگرام
      var tg = bar.querySelector('.qa-share-tg');
      if (tg) {
        tg.setAttribute('href', 'https://t.me/share/url?url=' + encodeURIComponent(url) + '&text=' + encodeURIComponent(title));
      }

      // ایکس (توییتر)
      var xBtn = bar.querySelector('.qa-share-x');
      if (xBtn) {
        xBtn.setAttribute('href', 'https://twitter.com/intent/tweet?url=' + encodeURIComponent(url) + '&text=' + encodeURIComponent(title));
      }
    }
  );

  /* ---------- ۱۳. گزارش تخلف AJAX (۱.۴.۰) ---------- */
  Array.prototype.forEach.call(
    document.querySelectorAll('.qa-flag-form'),
    function (form) {
      var btn = form.querySelector('.qa-flag-btn');
      if (!btn) { return; }

      form.addEventListener('submit', function (ev) {
        if (btn.classList.contains('is-flagged')) {
          ev.preventDefault();
          return;
        }
        ev.preventDefault();
        btn.classList.add('is-busy');

        var fd = new FormData(form);
        fd.append('X-Requested-With', 'XMLHttpRequest');

        fetch(form.getAttribute('action') || window.location.href, {
          method: 'POST',
          body: fd,
          credentials: 'same-origin',
          headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
          .then(function (res) { return res.json(); })
          .then(function (data) {
            btn.classList.remove('is-busy');
            if (data && data.ok) {
              btn.classList.add('is-flagged');
              btn.setAttribute('data-tooltip', 'گزارش داده‌اید');
              var span = btn.querySelector('span');
              if (span) { span.textContent = 'گزارش داده‌اید'; }
            } else if (data && data.status === 'already') {
              btn.classList.add('is-flagged');
              btn.setAttribute('data-tooltip', 'گزارش داده‌اید');
            } else if (data && data.status === 'login_required') {
              // مهمان — پیام ورود
              qaNotice({
                variant: 'info',
                title: 'ورود لازم است',
                icon: QA_ICONS.login,
                message: data.message || 'برای گزارش تخلف باید وارد حساب خود شوید.'
              });
            } else if (data && data.status === 'own') {
              // نویسنده نمی‌تواند نوشتهٔ خودش را گزارش کند (۲.۰.۰)
              qaNotice({
                variant: 'info',
                title: 'گزارش تخلف',
                icon: QA_ICONS.shield,
                message: data.message || 'نمی‌توانید نوشتهٔ خودتان را گزارش کنید.'
              });
            } else if (data && data.message) {
              // سایر خطاها — پیام سرور
              qaNotice({
                variant: 'danger',
                title: 'گزارش تخلف',
                icon: QA_ICONS.shield,
                message: data.message
              });
            }
          })
          .catch(function () {
            btn.classList.remove('is-busy');
            // در صورت خطا، فرم به‌صورت عادی ارسال شود
            form.submit();
          });
      });
    }
  );

  /* ---------- ۱۳.۵ پسند (لایک) پرسش‌ها و پاسخ‌ها — AJAX (۲.۰.۰) ---------- */
  function faDigitsJs(str) {
    var fa = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return String(str).replace(/[0-9]/g, function (d) { return fa[+d]; });
  }

  /* انفجار ذره‌ای پسند — به سبک قلب اینستاگرام (۲.۰.۰):
     ۸ نقطهٔ ریز رز در دایره اطراف دکمه پخش و محو می‌شوند. */
  function qaLikeBurst(btn) {
    var old = btn.querySelector('.qa-like-burst');
    if (old && old.parentNode) { old.parentNode.removeChild(old); }
    var wrap = document.createElement('span');
    wrap.className = 'qa-like-burst';
    wrap.setAttribute('aria-hidden', 'true');
    var n = 8;
    for (var i = 0; i < n; i++) {
      var dot = document.createElement('i');
      var ang = (Math.PI * 2 * i) / n + (Math.random() * 0.5 - 0.25);
      var dist = 15 + Math.random() * 12;
      dot.style.setProperty('--tx', (Math.cos(ang) * dist).toFixed(1) + 'px');
      dot.style.setProperty('--ty', (Math.sin(ang) * dist).toFixed(1) + 'px');
      dot.style.animationDelay = Math.floor(Math.random() * 70) + 'ms';
      wrap.appendChild(dot);
    }
    btn.appendChild(wrap);
    setTimeout(function () {
      if (wrap.parentNode) { wrap.parentNode.removeChild(wrap); }
    }, 800);
  }

  /* پخش انیمیشن قلب — حذف کلاس، جبران چیدمان، افزودن دوباره
     تا هر کلیک، حتی پشت‌سرهم، انیمیشن تازه بگیرد. */
  function qaLikeAnim(btn, cls) {
    btn.classList.remove('qa-just-liked', 'qa-just-unliked');
    void btn.offsetWidth; // jshint ignore:line — اجبار به چیدمان مجدد
    btn.classList.add(cls);
    setTimeout(function () { btn.classList.remove(cls); }, 900);
  }

  Array.prototype.forEach.call(
    document.querySelectorAll('.qa-like-form'),
    function (form) {
      var btn = form.querySelector('.qa-like-btn');
      if (!btn) { return; }

      var baseTip = form.classList.contains('qa-like-form--question')
        ? 'پسندیدن این پرسش' : 'پسندیدن این پاسخ';

      form.addEventListener('submit', function (ev) {
        ev.preventDefault();
        if (btn.classList.contains('is-busy')) { return; }
        btn.classList.add('is-busy');

        var fd = new FormData(form);

        fetch(form.getAttribute('action') || window.location.href, {
          method: 'POST',
          body: fd,
          credentials: 'same-origin',
          headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
          .then(function (res) { return res.json(); })
          .then(function (data) {
            btn.classList.remove('is-busy');
            if (!data || (data.status !== 'added' && data.status !== 'removed')) {
              if (data && data.message) {
                qaNotice({
                  variant: 'danger',
                  title: 'ثبت پسند',
                  icon: QA_ICONS.heart,
                  message: data.message
                });
              }
              return;
            }
            var count = btn.querySelector('.qa-like-count');
            if (count) { count.textContent = faDigitsJs(data.count || 0); }
            if (data.status === 'added') {
              btn.classList.add('is-liked');
              btn.setAttribute('data-tooltip', 'پسندیده‌اید — برای برداشتن کلیک کنید');
              // انیمیشن پسند — پاپِ قلب + حلقه + انفجار ذره‌ای (مثل اینستاگرام)
              qaLikeAnim(btn, 'qa-just-liked');
              qaLikeBurst(btn);
            } else {
              btn.classList.remove('is-liked');
              btn.setAttribute('data-tooltip', baseTip);
              // برداشتن پسند — یک جمع‌شدن کوچک و ظریف
              qaLikeAnim(btn, 'qa-just-unliked');
            }
          })
          .catch(function () {
            btn.classList.remove('is-busy');
            // در صورت خطا، فرم به‌صورت عادی ارسال شود
            form.submit();
          });
      });
    }
  );

  /* ---------- ۱۴. لایت‌باکس تصاویر (۱.۰.۰) + ناوبری گالری (۲.۱.۰) ---------- */
  // فقط اگر data-qa-lightbox روی .qa-main ست شده باشد
  var qaMain = document.querySelector('.qa-main');
  if (qaMain && qaMain.getAttribute('data-qa-lightbox') === '1') {
    // ساخت المان لایت‌باکس — شامل دکمه‌های قبلی/بعدی برای گالری‌ها (۲.۱.۰)
    var lightbox = document.createElement('div');
    lightbox.className = 'qa-lightbox';
    lightbox.setAttribute('role', 'dialog');
    lightbox.setAttribute('aria-modal', 'true');
    lightbox.setAttribute('aria-label', 'نمایش تصویر');
    lightbox.innerHTML =
      '<button type="button" class="qa-lightbox-close" aria-label="بستن">&times;</button>' +
      '<button type="button" class="qa-lightbox-prev" aria-label="قبلی" hidden>' +
        '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 18 9 12 15 6"></polyline></svg>' +
      '</button>' +
      '<button type="button" class="qa-lightbox-next" aria-label="بعدی" hidden>' +
        '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 18 15 12 9 6"></polyline></svg>' +
      '</button>' +
      '<span class="qa-lightbox-counter" hidden></span>';
    var lbImg = document.createElement('img');
    lightbox.appendChild(lbImg);
    document.body.appendChild(lightbox);

    // state جاری گالری (اگر لایت‌باکس روی یک گالری باز شده باشد)
    var lbGalleryItems = [];
    var lbGalleryIdx = -1;

    var lbPrev = lightbox.querySelector('.qa-lightbox-prev');
    var lbNext = lightbox.querySelector('.qa-lightbox-next');
    var lbCounter = lightbox.querySelector('.qa-lightbox-counter');

    function showLightboxImage(idx) {
      if (lbGalleryItems.length === 0) { return; }
      if (idx < 0) { idx = lbGalleryItems.length - 1; }
      if (idx >= lbGalleryItems.length) { idx = 0; }
      lbGalleryIdx = idx;
      var item = lbGalleryItems[idx];
      lbImg.src = item.src;
      lbImg.alt = item.alt || '';
      if (lbGalleryItems.length > 1) {
        lbPrev.removeAttribute('hidden');
        lbNext.removeAttribute('hidden');
        lbCounter.removeAttribute('hidden');
        lbCounter.textContent = (idx + 1) + ' / ' + lbGalleryItems.length;
      } else {
        lbPrev.setAttribute('hidden', '');
        lbNext.setAttribute('hidden', '');
        lbCounter.setAttribute('hidden', '');
      }
    }

    function openLightbox(src, alt, galleryEl) {
      lbGalleryItems = [];
      lbGalleryIdx = -1;
      if (galleryEl) {
        // مجموعهٔ تصاویر گالری را جمع می‌کنیم تا ناوبری ممکن شود
        var items = galleryEl.querySelectorAll('[data-qa-gallery-item]');
        for (var i = 0; i < items.length; i++) {
          var href = items[i].getAttribute('href') || '';
          var imgInside = items[i].querySelector('img');
          // (۲.۱.۰ رفع) از getAttribute('src') استفاده می‌کنیم تا URL خام باشد
          // و با src دریافتی از کلیک (که نیز href است) مطابقت کند.
          var imgSrc = imgInside ? imgInside.getAttribute('src') : href;
          var imgAlt = items[i].getAttribute('data-alt') || (imgInside ? imgInside.getAttribute('alt') : '');
          // مطابقت با src — اگر href یا src مطابق باشد، این آیتم جاری است
          if (imgSrc === src || href === src) { lbGalleryIdx = lbGalleryItems.length; }
          lbGalleryItems.push({ src: href || imgSrc, alt: imgAlt });
        }
      }
      lbImg.src = src;
      lbImg.alt = alt || '';
      if (lbGalleryItems.length > 1) {
        lbPrev.removeAttribute('hidden');
        lbNext.removeAttribute('hidden');
        lbCounter.removeAttribute('hidden');
        lbCounter.textContent = (lbGalleryIdx + 1) + ' / ' + lbGalleryItems.length;
      } else {
        lbPrev.setAttribute('hidden', '');
        lbNext.setAttribute('hidden', '');
        lbCounter.setAttribute('hidden', '');
      }
      lightbox.classList.add('is-open');
      document.body.style.overflow = 'hidden';
    }
    function closeLightbox() {
      lightbox.classList.remove('is-open');
      document.body.style.overflow = '';
      lbGalleryItems = [];
      lbGalleryIdx = -1;
    }

    // باز کردن با کلیک روی تصویر
    // (۲.۱.۰ رفع) هم تصاویر تکی (img.qa-lightbox-img) و هم آیتم‌های گالری
    // (a.qa-lightbox-img با img داخلشان) را پوشش می‌دهد.
    document.addEventListener('click', function (ev) {
      // اول: کلیک روی یک تصویر با کلاس qa-lightbox-img (تصویر تکی)
      var img = ev.target.closest('img.qa-lightbox-img');
      // دوم: کلیک روی یک لنگر گالری که کلاس qa-lightbox-img دارد
      var anchor = null;
      if (!img) {
        anchor = ev.target.closest('a.qa-lightbox-img');
        if (anchor) {
          img = anchor.querySelector('img');
        }
      } else {
        anchor = img.closest('a[href]');
      }
      if (!img) { return; }
      ev.preventDefault();
      // اگر تصویر داخل یک گالری است، گالری را به‌عنوان context پاس می‌دهیم
      var galleryEl = img.closest('[data-qa-gallery]');
      var src = anchor ? anchor.getAttribute('href') : (img.src || img.getAttribute('src') || '');
      var alt = img.getAttribute('alt') || (anchor ? anchor.getAttribute('data-alt') : '') || '';
      openLightbox(src, alt, galleryEl);
    });

    // ناوبری گالری
    if (lbPrev) {
      lbPrev.addEventListener('click', function (ev) {
        ev.preventDefault();
        ev.stopPropagation();
        if (lbGalleryItems.length > 1) { showLightboxImage(lbGalleryIdx - 1); }
      });
    }
    if (lbNext) {
      lbNext.addEventListener('click', function (ev) {
        ev.preventDefault();
        ev.stopPropagation();
        if (lbGalleryItems.length > 1) { showLightboxImage(lbGalleryIdx + 1); }
      });
    }

    // بستن با کلیک روی پس‌زمینه یا دکمه
    lightbox.addEventListener('click', function (ev) {
      if (ev.target === lightbox || ev.target.classList.contains('qa-lightbox-close')) {
        closeLightbox();
      }
    });

    // کلیدهای Escape، فلش‌های چپ/راست
    // (۲.۳.۰ رفع) در هر دو حالت LTR و RTL، فلش راست → تصویر بعدی، فلش چپ → تصویر قبلی.
    // این رفتار با جهت فیزیکی کلید مطابقت دارد و برای کاربر شهودی‌تر است.
    document.addEventListener('keydown', function (ev) {
      if (!lightbox.classList.contains('is-open')) { return; }
      if (ev.key === 'Escape') {
        closeLightbox();
      } else if (ev.key === 'ArrowRight' && lbGalleryItems.length > 1) {
        // فلش راست → تصویر بعدی
        showLightboxImage(lbGalleryIdx + 1);
      } else if (ev.key === 'ArrowLeft' && lbGalleryItems.length > 1) {
        // فلش چپ → تصویر قبلی
        showLightboxImage(lbGalleryIdx - 1);
      }
    });
  }

  /* ---------- ۱۵. نظرسنجی — نمایش/پنهان فیلدها ----------
   * (۲.۰.۰) کلاس‌محور: هم فرم «پرسش جدید» (list) و هم فرم ویرایش
   * درجا (thread) که هر کدام چک‌باکس .qa-poll-toggle و جعبهٔ
   * .qa-poll-options خودشان را دارند. */
  Array.prototype.forEach.call(
    document.querySelectorAll('.qa-poll-toggle'),
    function (toggle) {
      var wrap = toggle.closest('.qa-poll-field');
      var opts = wrap ? wrap.querySelector('.qa-poll-options') : null;
      if (!opts) { return; }
      toggle.addEventListener('change', function () {
        if (toggle.checked) {
          opts.removeAttribute('hidden');
        } else {
          opts.setAttribute('hidden', '');
        }
      });
    }
  );

  /* ---------- ۱۶. اعلان‌ها — زنگولهٔ popup + علامت‌گذاری خوانده‌شده (۱.۵.۲) ----------
   * زنگوله در ویجت کاربر سایدبار قرار دارد. با کلیک روی آن، popup لیست
   * اعلان‌ها باز/بسته می‌شود. با کلیک روی یک اعلان، پیش از هدایت، یک
   * درخواست AJAX به read-notif ارسال می‌شود تا اعلان خوانده‌شده شود و
   * شمارندهٔ زنگوله بلافاصله بروزرسانی شود — بدون refresh.
   */
  var notifWidget = document.getElementById('qa-user-widget');
  var notifAction = notifWidget ? notifWidget.getAttribute('data-notif-action') : '';
  var notifToken = notifWidget ? notifWidget.getAttribute('data-notif-token') : '';
  var notifBell = document.getElementById('qa-notif-bell');
  var notifPop = document.getElementById('qa-notif-pop');

  function updateNotifBadge(newCount) {
    var badges = document.querySelectorAll('[data-notif-badge]');
    Array.prototype.forEach.call(badges, function (badge) {
      badge.textContent = String(newCount);
      badge.setAttribute('data-notif-badge', String(newCount));
      if (newCount > 0) {
        badge.removeAttribute('hidden');
      } else {
        badge.setAttribute('hidden', '');
      }
    });
    // اگر فرم «خواندن همه» وجود دارد و شمار = ۰، آن را پنهان کن
    var markForm = document.querySelector('.qa-notif-mark-form');
    if (markForm) {
      markForm.style.display = newCount > 0 ? '' : 'none';
    }
    // زنگوله: اگر شمار = ۰، حالت چشمک‌زن را بردار
    if (notifBell) {
      if (newCount > 0) {
        notifBell.classList.add('has-unread', 'is-ringing');
      } else {
        notifBell.classList.remove('has-unread', 'is-ringing');
      }
      notifBell.setAttribute('data-tooltip', newCount > 0
        ? (qaTipFaDigits(newCount) + ' اعلان خوانده‌نشده')
        : 'اعلان‌ها');
    }
  }

  function closeNotifPop() {
    if (notifPop) { notifPop.setAttribute('hidden', ''); }
    if (notifBell) { notifBell.setAttribute('aria-expanded', 'false'); }
  }

  function openNotifPop() {
    if (notifPop) { notifPop.removeAttribute('hidden'); }
    if (notifBell) { notifBell.setAttribute('aria-expanded', 'true'); }
  }

  // باز/بسته‌کردن popup با کلیک روی زنگوله
  // (۲.۳.۰) زنگوله‌ای که data-notif-page دارد پیوند به صفحهٔ اعلان‌هاست؛
  // رفتار toggle برای آن بسته می‌شود تا مرورگر به مقصد پیوند برود.
  // popup زیرین (لایهٔ درونی) از بیرون باز نمی‌شود.
  if (notifBell && notifPop && !notifBell.hasAttribute('data-notif-page')) {
    notifBell.addEventListener('click', function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      if (notifPop.hasAttribute('hidden')) {
        openNotifPop();
      } else {
        closeNotifPop();
      }
    });
    // کلید Escape برای بستن
    notifBell.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape') { closeNotifPop(); notifBell.focus(); }
    });
  }

  // بستن popup با کلیک بیرون از آن
  if (notifPop) {
    document.addEventListener('click', function (ev) {
      if (notifPop.hasAttribute('hidden')) { return; }
      var t = ev.target;
      if (t && t.closest && t.closest('#qa-notif-pop')) { return; }
      if (t && t.closest && t.closest('#qa-notif-bell')) { return; }
      closeNotifPop();
    });
  }

  function markNotifRead(notifId, linkEl) {
    if (!notifAction || !notifToken || !notifId) { return; }
    try {
      var fd = new FormData();
      fd.append('_', notifToken);
      fd.append('mode', 'read-notif');
      fd.append('id', String(notifId));
      fetch(notifAction, {
        method: 'POST',
        body: fd,
        credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      })
        .then(function (res) { return res.json(); })
        .then(function (data) {
          if (data && typeof data.unread === 'number') {
            updateNotifBadge(data.unread);
          }
          // آیتم را به‌عنوان خوانده‌شده علامت بزن (کلاس is-unread → is-read)
          if (linkEl) {
            var item = linkEl.closest('.qa-notif-item');
            if (item) {
              item.classList.remove('is-unread');
              item.classList.add('is-read');
              var dot = item.querySelector('.qa-notif-dot');
              if (dot) { dot.remove(); }
            }
          }
        })
        .catch(function () { /* بی‌اثر — لینک به هر حال باز می‌شود */ });
    } catch (e) { /* بی‌اثر */ }
  }

  if (notifWidget) {
    Array.prototype.forEach.call(
      notifWidget.querySelectorAll('.qa-notif-link'),
      function (link) {
        link.addEventListener('click', function () {
          var item = link.closest('.qa-notif-item');
          if (!item) { return; }
          var notifId = item.getAttribute('data-notif-id') || '';
          // فقط اگر خوانده‌نشده است، درخواست بفرست
          if (item.classList.contains('is-unread') && notifId) {
            markNotifRead(parseInt(notifId, 10) || 0, link);
          }
        });
      }
    );
  }

  /* ---------- ۱۶.۵ صفحهٔ اعلان‌ها (۲.۳.۰) — /forum/notifications ----------
   * همان رفتار popup: با کلیک روی یک اعلانِ خوانده‌نشده، پیش از هدایت،
   * درخواست AJAX read-notif ارسال می‌شود تا شمارندهٔ زنگوله بروزرسانی شود.
   * توکن/اکشن همان ویجت کاربر است (صفحه هم سایدبار دارد)؛ در نبود
   * ویجت، این بلوک بی‌اثر است — هیچ وابستگی جدیدی اضافه نمی‌شود.
   */
  var npList = document.getElementById('qa-np-list');
  if (npList) {
    Array.prototype.forEach.call(
      npList.querySelectorAll('.qa-notif-link'),
      function (link) {
        link.addEventListener('click', function () {
          var item = link.closest('.qa-notif-item');
          if (!item) { return; }
          var notifId = item.getAttribute('data-notif-id') || '';
          if (item.classList.contains('is-unread') && notifId && notifAction && notifToken) {
            markNotifRead(parseInt(notifId, 10) || 0, link);
          }
        });
      }
    );
  }

  /* ---------- ۱۷. شمارش معکوس زنده برای فلود کنترل (۱.۵.۳) ----------
   * وقتی بنر خطا data-wait-banner دارد، یک تایمر ثانیه‌ای راه‌اندازی
   * می‌شود که متن .qa-countdown را بروزرسانی می‌کند تا به 00:00 برسد.
   * سپس دکمهٔ بستن بنر فعال می‌شود.
   */
  function faDigitsConvert(s) {
    var map = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    return String(s).replace(/[0-9]/g, function (d) { return map[parseInt(d, 10)]; });
  }
  function formatCountdown(seconds) {
    var m = Math.floor(seconds / 60);
    var s = seconds % 60;
    return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
  }
  Array.prototype.forEach.call(
    document.querySelectorAll('[data-wait-banner]'),
    function (banner) {
      var countdownEl = banner.querySelector('.qa-countdown');
      if (!countdownEl) { return; }
      var remaining = parseInt(countdownEl.getAttribute('data-countdown') || '0', 10);
      if (!(remaining > 0)) { return; }
      // تایمر ثانیه‌ای
      var timer = setInterval(function () {
        remaining -= 1;
        if (remaining <= 0) {
          clearInterval(timer);
          countdownEl.textContent = faDigitsConvert('00:00');
          // فعال‌کردن دکمهٔ بستن
          var closeBtn = banner.querySelector('.qa-banner-close');
          if (closeBtn) { closeBtn.removeAttribute('disabled'); }
          // اختیاری: حذف خودکار بنر پس از اتمام
          // banner.remove();
          return;
        }
        countdownEl.textContent = faDigitsConvert(formatCountdown(remaining));
      }, 1000);
    }
  );

  /* ---------- ۱۵. مودال تأیید/اطلاع‌رسانی سفارشی (۱.۲.۱ — یکپارچه‌سازی کامل) ----------
   * qaConfirm({ message, title, variant, okText, cancelText })
   *   → Promise<boolean> — true = تأیید کاربر، false = لغو
   * qaNotice({ message, title, variant, icon, okText })
   *   → Promise<true> — مودال تک‌دکمه‌ای (جایگزین window.alert)
   * qaPrompt({ message, title, variant, value, placeholder, okText })
   *   → Promise<string|null> — مودال ورود نشانی (جایگزین window.prompt)
   *
   * همهٔ مودال‌ها یک استایل واحد دارند: دکمه‌های کپسولی هماهنگ با
   * اکشن‌های انجمن (.qa-post-action/.qa-btn) و آیکون‌های Lucide
   * (stroke خطی با گوشه‌های گرد) به‌علاوهٔ آیکون داخل دکمه‌ها.
   *
   * ویژگی‌ها:
   *  - هماهنگ با حالت روشن/تاریک (متغیرهای CSS پوسته + [data-theme="dark"])
   *  - چهار رنگ‌بندی: danger (قرمز) / warn (کهربایی) / info (آبی) / ok (سبز)
   *  - قفل تاب: چرخهٔ فوکوس داخل دیالوگ می‌ماند (Tab / Shift+Tab)
   *  - بستن با Escape و کلیک روی پس‌زمینه (هر دو = لغو)
   *  - role="alertdialog" + aria-modal + aria-labelledby/describedby
   *  - فوکوس و اسکرول صفحه پس از بستن بازگردانده می‌شود
   *  - برای عملیات حساسِ برگشت‌ناپذیر (danger) فوکوس اولیه روی «لغو» است
   *
   * اتصال خودکار: هر فرمی که ویژگی data-confirm داشته باشد، هنگام ارسال
   * متوقف می‌شود و مودال نمایش داده می‌شود؛ فقط پس از تأیید، فرم واقعاً
   * ارسال می‌شود. سایر ویژگی‌های اختیاری روی همان فرم:
   *   data-confirm-title   → عنوان مودال
   *   data-confirm-variant → danger | warn | info | ok (پیش‌فرض: warn)
   *   data-confirm-ok      → متن دکمهٔ تأیید
   *   data-confirm-cancel  → متن دکمهٔ لغو
   */
  var QA_MODAL = null;          // المان ریشهٔ مودال (یک‌بار ساخته و بازاستفاده)
  var QA_MODAL_BUSY = false;    // مودال باز است؟
  var QA_MODAL_PREV_FOCUS = null;
  var QA_MODAL_PREV_SCROLL = '';
  var QA_MODAL_RESOLVER = null;

  /* کتابخانهٔ آیکون‌ها — کاغذهای Lucide (svg خطی، stroke-width 2، گوشه‌های گرد) */
  function qaLucide(inner, size) {
    size = size || 22;
    return '<svg viewBox="0 0 24 24" width="' + size + '" height="' + size + '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + inner + '</svg>';
  }

  var QA_ICONS = {
    /* وضعیت‌ها */
    danger: qaLucide('<circle cx="12" cy="12" r="10"></circle><path d="M12 8v4"></path><path d="M12 16h.01"></path>'),
    warn: qaLucide('<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"></path><path d="M12 9v4"></path><path d="M12 17h.01"></path>'),
    info: qaLucide('<circle cx="12" cy="12" r="10"></circle><path d="M12 16v-4"></path><path d="M12 8h.01"></path>'),
    ok: qaLucide('<circle cx="12" cy="12" r="10"></circle><path d="m9 12 2 2 4-4"></path>'),
    /* موضوعی */
    heart: qaLucide('<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path>'),
    login: qaLucide('<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path><path d="m10 17 5-5-5-5"></path><path d="M15 12H3"></path>'),
    image: qaLucide('<rect width="18" height="18" x="3" y="3" rx="2" ry="2"></rect><circle cx="9" cy="9" r="2"></circle><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"></path>'),
    link: qaLucide('<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>'),
    wifiOff: qaLucide('<path d="M12 20h.01"></path><path d="M8.5 16.429a5 5 0 0 1 7 0"></path><path d="M5 12.859a10 10 0 0 1 5.17-2.69"></path><path d="M19 12.859a10 10 0 0 0-2.007-1.523"></path><path d="M2 8.82a15 15 0 0 1 4.177-2.643"></path><path d="M22 8.82a15 15 0 0 0-11.288-3.764"></path><path d="m2 2 20 20"></path>'),
    shield: qaLucide('<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path>'),
    /* داخل دکمه‌ها — کاغذهای رسمی Lucide:
       check = «بله/تأیید» (M20 6 9 17l-5-5)، x = «خیر/لغو» */
    check: qaLucide('<path d="M20 6 9 17l-5-5"></path>', 15),
    x: qaLucide('<path d="M18 6 6 18"></path><path d="m6 6 12 12"></path>', 15)
  };

  var QA_VARIANTS = {
    danger: { title: 'تأیید عملیات حساس', ok: 'بله، انجام شود', notice: 'خطا' },
    warn: { title: 'تأیید عملیات', ok: 'بله، انجام شود', notice: 'هشدار' },
    info: { title: 'تأیید عملیات', ok: 'تأیید', notice: 'پیام' },
    ok: { title: 'تأیید عملیات', ok: 'بله', notice: 'انجام شد' }
  };

  function qaModalFocusables() {
    if (!QA_MODAL) { return []; }
    return Array.prototype.filter.call(
      QA_MODAL.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'),
      function (el) {
        // عناصر پنهان (نمایش:none) از چرخهٔ تاب حذف می‌شوند
        return !el.disabled && el.getAttribute('aria-hidden') !== 'true' && el.getClientRects().length > 0;
      }
    );
  }

  function qaModalSettle(yes) {
    if (!QA_MODAL_BUSY || !QA_MODAL) { return; }
    QA_MODAL_BUSY = false;

    QA_MODAL.classList.remove('is-open');
    document.removeEventListener('keydown', qaModalKeydown, true);

    // بازگرداندن اسکرول و فوکوس صفحه
    document.documentElement.style.overflow = QA_MODAL_PREV_SCROLL;
    document.body.style.overflow = '';
    if (QA_MODAL_PREV_FOCUS && document.contains(QA_MODAL_PREV_FOCUS)) {
      try { QA_MODAL_PREV_FOCUS.focus(); } catch (e) { /* بی‌اثر */ }
    }
    QA_MODAL_PREV_FOCUS = null;

    var resolver = QA_MODAL_RESOLVER;
    QA_MODAL_RESOLVER = null;
    if (resolver) {
      try { resolver(yes === true); } catch (e) { /* بی‌اثر */ }
    }
  }

  function qaModalKeydown(ev) {
    if (!QA_MODAL_BUSY) { return; }
    if (ev.key === 'Escape' || ev.keyCode === 27) {
      ev.preventDefault();
      ev.stopPropagation();
      qaModalSettle(false);
      return;
    }
    if (ev.key === 'Tab' || ev.keyCode === 9) {
      var f = qaModalFocusables();
      if (!f.length) { ev.preventDefault(); return; }
      var first = f[0];
      var last = f[f.length - 1];
      var active = document.activeElement;
      if (ev.shiftKey) {
        if (active === first || !QA_MODAL.contains(active)) {
          ev.preventDefault();
          last.focus();
        }
      } else {
        if (active === last || !QA_MODAL.contains(active)) {
          ev.preventDefault();
          first.focus();
        }
      }
      ev.stopPropagation();
    }
  }

  function qaModalClick(ev) {
    if (!QA_MODAL_BUSY) { return; }
    var t = ev.target;
    if (t && t.closest && t.closest('[data-qa-close]')) {
      ev.preventDefault();
      qaModalSettle(false);
    }
  }

  function qaModalBuild() {
    var modal = document.createElement('div');
    modal.className = 'qa-modal';
    modal.setAttribute('role', 'alertdialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-labelledby', 'qa-confirm-title');
    modal.setAttribute('aria-describedby', 'qa-confirm-desc');
    modal.innerHTML =
      '<div class="qa-modal-backdrop" data-qa-close="1"></div>' +
      '<div class="qa-modal-dialog" dir="auto">' +
        '<span class="qa-modal-icon" aria-hidden="true"></span>' +
        '<h3 class="qa-modal-title" id="qa-confirm-title"></h3>' +
        '<p class="qa-modal-desc" id="qa-confirm-desc"></p>' +
        '<input type="text" class="qa-modal-input" id="qa-modal-input" dir="ltr" spellcheck="false" autocomplete="off" hidden>' +
        '<div class="qa-modal-actions">' +
          '<button type="button" class="qa-btn qa-modal-confirm"></button>' +
          '<button type="button" class="qa-btn qa-modal-cancel" data-qa-close="1"></button>' +
        '</div>' +
      '</div>';
    modal.addEventListener('click', qaModalClick);

    // در حالت prompt، کلید Enter داخل ورودی = تأیید
    var input = modal.querySelector('.qa-modal-input');
    input.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter' || ev.keyCode === 13) {
        ev.preventDefault();
        ev.stopPropagation();
        var c = QA_MODAL && QA_MODAL.querySelector('.qa-modal-confirm');
        if (c) { c.click(); }
      }
    });

    // مودال داخل .qa-main نصب می‌شود تا متغیرهای رنگی پوسته (روشن/تاریک)
    // عیناً به آن ارث برسد؛ در نبود .qa-main به body می‌رود.
    var host = document.querySelector('.qa-main') || document.body;
    host.appendChild(modal);
    return modal;
  }

  /* محتوای امن دکمهٔ مودال: آیکون + متن (بدون تزریق HTML بیرونی) */
  function qaModalFill(btn, text, iconSvg) {
    btn.innerHTML = '';
    if (iconSvg) {
      var ico = document.createElement('span');
      ico.className = 'qa-modal-btn-ico';
      ico.setAttribute('aria-hidden', 'true');
      ico.innerHTML = iconSvg;
      btn.appendChild(ico);
    }
    var lbl = document.createElement('span');
    lbl.textContent = text || '';
    btn.appendChild(lbl);
  }

  /* منطق مشترک باز شدن مودال پس از پیکربندی المان‌ها */
  function qaModalOpen(variant, initial) {
    QA_MODAL_PREV_FOCUS = document.activeElement;
    QA_MODAL_PREV_SCROLL = document.documentElement.style.overflow || '';
    QA_MODAL_BUSY = true;

    // اگر تولتیپی باز است بسته شود تا زیر مودال نماند
    qaTipHideNow();

    // قفل اسکرول و نمایش
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';
    document.addEventListener('keydown', qaModalKeydown, true);

    // اجرای انیمیشن باز شدن پس از چیدمان — خواندن offsetWidth چیدمان را
    // اجبار می‌کند تا transition مربوط به .is-open درست اجرا شود
    void QA_MODAL.offsetWidth;
    QA_MODAL.classList.add('is-open');

    setTimeout(function () {
      if (QA_MODAL_BUSY && initial && document.contains(initial)) {
        try { initial.focus(); } catch (e) { /* بی‌اثر */ }
      }
    }, 60);
  }

  function qaConfirm(opts) {
    opts = opts || {};
    return new Promise(function (resolve) {
      if (QA_MODAL_BUSY) { resolve(false); return; }

      if (!QA_MODAL) { QA_MODAL = qaModalBuild(); }

      var variant = QA_VARIANTS[opts.variant] ? opts.variant : 'warn';
      var preset = QA_VARIANTS[variant];
      var title = (opts.title || preset.title || 'تأیید عملیات');
      var message = (opts.message || '');
      var okText = (opts.okText || preset.ok || 'تأیید');
      var cancelText = (opts.cancelText || 'لغو');

      // حالت‌های دیگر (notice/prompt) را بازنشانی کن
      QA_MODAL.removeAttribute('data-notice');
      QA_MODAL.removeAttribute('data-prompt');
      var pInput = QA_MODAL.querySelector('.qa-modal-input');
      if (pInput) { pInput.setAttribute('hidden', ''); pInput.value = ''; }

      QA_MODAL.setAttribute('data-variant', variant);
      QA_MODAL.querySelector('.qa-modal-icon').innerHTML = QA_ICONS[variant];
      QA_MODAL.querySelector('.qa-modal-title').textContent = title;
      QA_MODAL.querySelector('.qa-modal-desc').textContent = message;

      var confirmBtn = QA_MODAL.querySelector('.qa-modal-confirm');
      var cancelBtn = QA_MODAL.querySelector('.qa-modal-cancel');
      cancelBtn.style.display = '';
      qaModalFill(confirmBtn, okText, QA_ICONS.check);
      qaModalFill(cancelBtn, cancelText, QA_ICONS.x);

      confirmBtn.onclick = function () { qaModalSettle(true); };
      cancelBtn.onclick = function () { qaModalSettle(false); };

      QA_MODAL_RESOLVER = function (yes) { resolve(yes === true); };

      // فوکوس اولیه: برای عملیات‌های خطرناک روی «لغو» (امن)، در غیر این
      // صورت روی «تأیید» — مطابق الگوی دیالوگ‌های استاندارد
      qaModalOpen(variant, variant === 'danger' ? cancelBtn : confirmBtn);
    });
  }

  /* مودال تک‌دکمه‌ای برای نمایش پیام — جایگزین window.alert
   * qaNotice({ message, title, variant, icon, okText }) → Promise<true> */
  function qaNotice(opts) {
    opts = opts || {};
    return new Promise(function (resolve) {
      if (QA_MODAL_BUSY) { resolve(true); return; }

      if (!QA_MODAL) { QA_MODAL = qaModalBuild(); }

      var variant = QA_VARIANTS[opts.variant] ? opts.variant : 'info';
      var preset = QA_VARIANTS[variant];
      var icon = opts.icon || QA_ICONS[variant];
      var title = (opts.title || preset.notice || 'پیام');
      var okText = (opts.okText || 'متوجه شدم');

      // حالت prompt را بازنشانی کن
      QA_MODAL.removeAttribute('data-prompt');
      var pInput = QA_MODAL.querySelector('.qa-modal-input');
      if (pInput) { pInput.setAttribute('hidden', ''); pInput.value = ''; }

      QA_MODAL.setAttribute('data-notice', '1');
      QA_MODAL.setAttribute('data-variant', variant);
      QA_MODAL.querySelector('.qa-modal-icon').innerHTML = icon;
      QA_MODAL.querySelector('.qa-modal-title').textContent = title;
      QA_MODAL.querySelector('.qa-modal-desc').textContent = (opts.message || '');

      var confirmBtn = QA_MODAL.querySelector('.qa-modal-confirm');
      var cancelBtn = QA_MODAL.querySelector('.qa-modal-cancel');
      cancelBtn.style.display = 'none';
      qaModalFill(confirmBtn, okText, QA_ICONS.check);

      confirmBtn.onclick = function () { qaModalSettle(true); };
      cancelBtn.onclick = null;

      QA_MODAL_RESOLVER = function () { resolve(true); };
      qaModalOpen(variant, confirmBtn);
    });
  }

  /* مودال ورود مقدار — جایگزین window.prompt
   * qaPrompt({ message, title, variant, value, placeholder, okText })
   *   → Promise<string|null> — مقدار وارد‌شده یا null در صورت لغو */
  function qaPrompt(opts) {
    opts = opts || {};
    return new Promise(function (resolve) {
      if (QA_MODAL_BUSY) { resolve(null); return; }

      if (!QA_MODAL) { QA_MODAL = qaModalBuild(); }

      var variant = QA_VARIANTS[opts.variant] ? opts.variant : 'info';

      // حالت notice را بازنشانی کن
      QA_MODAL.removeAttribute('data-notice');
      QA_MODAL.setAttribute('data-prompt', '1');
      QA_MODAL.setAttribute('data-variant', variant);
      QA_MODAL.querySelector('.qa-modal-icon').innerHTML = opts.icon || QA_ICONS.link;
      QA_MODAL.querySelector('.qa-modal-title').textContent = (opts.title || 'ورود مقدار');
      QA_MODAL.querySelector('.qa-modal-desc').textContent = (opts.message || '');

      var input = QA_MODAL.querySelector('.qa-modal-input');
      input.removeAttribute('hidden');
      input.value = opts.value || '';
      input.setAttribute('placeholder', opts.placeholder || '');

      var confirmBtn = QA_MODAL.querySelector('.qa-modal-confirm');
      var cancelBtn = QA_MODAL.querySelector('.qa-modal-cancel');
      cancelBtn.style.display = '';
      qaModalFill(confirmBtn, opts.okText || 'درج', QA_ICONS.check);
      qaModalFill(cancelBtn, opts.cancelText || 'لغو', QA_ICONS.x);

      confirmBtn.onclick = function () { qaModalSettle(true); };
      cancelBtn.onclick = function () { qaModalSettle(false); };

      QA_MODAL_RESOLVER = function (yes) {
        resolve(yes === true ? String(input.value || '') : null);
      };
      qaModalOpen(variant, input);
      setTimeout(function () {
        try {
          input.focus();
          if (!input.value) { input.select(); }
          else { input.setSelectionRange(input.value.length, input.value.length); }
        } catch (e) { /* بی‌اثر */ }
      }, 70);
    });
  }

  // رهگیر ارسال فرم‌های دارای data-confirm — در فاز capture ثبت می‌شود تا
  // پیش از هر شنوندهٔ دیگری روی خود فرم اجرا شود و ارسال را متوقف کند.
  document.addEventListener('submit', function (ev) {
    var form = ev.target;
    if (!form || !form.getAttribute || !form.hasAttribute('data-confirm')) {
      return;
    }
    ev.preventDefault();
    ev.stopPropagation();

    if (QA_MODAL_BUSY) { return; }

    qaConfirm({
      message: form.getAttribute('data-confirm') || '',
      title: form.getAttribute('data-confirm-title') || '',
      variant: form.getAttribute('data-confirm-variant') || 'warn',
      okText: form.getAttribute('data-confirm-ok') || '',
      cancelText: form.getAttribute('data-confirm-cancel') || ''
    }).then(function (yes) {
      if (yes) {
        // form.submit() رویداد submit را دوباره فعال نمی‌کند؛ ارسال مستقیم
        try { form.submit(); } catch (e) { /* بی‌اثر */ }
      }
    });
  }, true);

  /* ---------- ۱۶. تولتیپ یکپارچهٔ همهٔ [data-tooltip] ها (۱.۲.۲) ----------
   *
   * پیش‌تر فقط کارت‌های «آخرین اعضا» تولتیپ سفارشی داشتند و سایر عناصر
   * از title مرورگر استفاده می‌کردند. اکنون همهٔ پیام‌های تولتیپ با
   * همان سبکِ واحد نمایش داده می‌شوند:
   *
   *  - یک المان واحد (div.qa-tooltip) که یک‌بار ساخته و همیشه بازاستفاده
   *    می‌شود؛ محتوایش از ویژگی data-tooltip عنصرِ هدف خوانده می‌شود.
   *  - جعبهٔ تیره با متن روشن در حالت روشن، و برعکس در حالت تاریک
   *    ([data-theme="dark"]) — دقیقاً مثل تولتیپ آواتارها.
   *  - جای‌گذاری هوشمند: پیش‌فرض بالای عنصر؛ اگر جا نبود خودکار زیر آن؛
   *    جفت‌شدن افقی به لبهٔ صفحه؛ فلش همیشه به مرکز عنصر اشاره می‌کند.
   *  - پشتیبانی صفحه‌کلید: با فوکوس‌گرفتن عنصر باز و با خروج بسته می‌شود.
   *  - بسته‌شدن با: خروج نشانگر، کلیک، اسکرول، تغییر اندازه و Escape.
   *  - روی صفحه‌های لمسی تولتیپ نمایش داده نمی‌شود (خطای نگه‌داشتن انگشت
   *    و شناورماندن جعبه جلوگیری می‌شود)؛ با حرکت واقعی موس دوباره فعال
   *    می‌شود (دستگاه‌های دوگانه).
   *  - نمایش با تأخیر کوتاه ۸۰ms و بستن نرم؛ و empty هیچ‌وقت باز نمی‌شود.
   */
  var QA_TIP = null;            // المان ریشهٔ تولتیپ
  var QA_TIP_TARGET = null;     // عنصرِ هدف فعلی
  var QA_TIP_SHOW_TIMER = 0;
  var QA_TIP_HIDE_TIMER = 0;
  var QA_TIP_IS_TOUCH = false;  // آخرین ورودی، لمس بوده؟

  function qaTipFaDigits(n) {
    return String(n).replace(/\d/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹' [+d]; });
  }

  function qaTipBuild() {
    var tip = document.createElement('div');
    tip.className = 'qa-tooltip';
    tip.setAttribute('role', 'tooltip');
    tip.setAttribute('aria-hidden', 'true');
    tip.innerHTML =
      '<span class="qa-tooltip-text"></span>' +
      '<span class="qa-tooltip-arrow" aria-hidden="true"></span>';
    // روی body نصب می‌شود تا هیچ ancestorی با transform جای‌گذاری fixed را
    // جابه‌جا نکند؛ رنگ‌ها ثابتند و به data-theme روی <html> واکنش نشان می‌دهند.
    document.body.appendChild(tip);
    return tip;
  }

  function qaTipHideNow() {
    if (!QA_TIP) { return; }
    QA_TIP.classList.remove('is-visible');
    QA_TIP_TARGET = null;
  }

  function qaTipHide() {
    clearTimeout(QA_TIP_SHOW_TIMER);
    clearTimeout(QA_TIP_HIDE_TIMER);
    QA_TIP_HIDE_TIMER = setTimeout(qaTipHideNow, 60);
  }

  function qaTipShow(target) {
    var text = (target.getAttribute('data-tooltip') || '').replace(/\s+/g, ' ').trim();
    if (!text) { return; }
    if (!QA_TIP) { QA_TIP = qaTipBuild(); }
    clearTimeout(QA_TIP_HIDE_TIMER);
    QA_TIP_TARGET = target;

    QA_TIP.querySelector('.qa-tooltip-text').textContent = text;

    // اندازه‌گیری با شفافیت صفر (display حذف نمی‌شود تا offsetWidth کار کند)
    QA_TIP.classList.remove('is-visible', 'qa-tooltip-below');
    QA_TIP.style.left = '0px';
    QA_TIP.style.top = '0px';
    var tw = QA_TIP.offsetWidth;
    var th = QA_TIP.offsetHeight;

    var r = target.getBoundingClientRect();
    var vw = window.innerWidth || document.documentElement.clientWidth;
    var vh = window.innerHeight || document.documentElement.clientHeight;
    var margin = 8;   // حداقل فاصله از لبهٔ صفحه
    var gap = 8;      // فاصلهٔ تولتیپ از عنصر هدف

    // اگر بالای عنصر جا نیست، زیر آن نمایش داده می‌شود
    var below = (r.top - th - gap) < margin;
    var x = r.left + (r.width / 2) - (tw / 2);
    var y = below ? (r.bottom + gap) : (r.top - th - gap);

    // جفت‌شدن افقی به لبهٔ صفحه
    if (x < margin) { x = margin; }
    if (x + tw > vw - margin) { x = vw - margin - tw; }
    if (x < 0) { x = 0; }

    QA_TIP.style.left = Math.round(x) + 'px';
    QA_TIP.style.top = Math.round(y) + 'px';
    QA_TIP.classList.toggle('qa-tooltip-below', below);

    // فلش به مرکز عنصر اشاره می‌کند (در محدودهٔ جعبه نگه داشته می‌شود)
    var arrow = QA_TIP.querySelector('.qa-tooltip-arrow');
    var arrowX = r.left + (r.width / 2) - x;
    arrowX = Math.max(14, Math.min(tw - 14, arrowX));
    arrow.style.left = Math.round(arrowX) + 'px';

    // اجرای transition پس از چیدمان
    void QA_TIP.offsetWidth;
    QA_TIP.classList.add('is-visible');
  }

  function qaTipTarget(ev) {
    var t = ev.target;
    return (t && t.closest) ? t.closest('[data-tooltip]') : null;
  }

  // شناوری نشانگر — با رویداد غیرمستقیم (delegation) روی document
  document.addEventListener('mouseover', function (ev) {
    if (QA_TIP_IS_TOUCH) { return; }
    var t = qaTipTarget(ev);
    if (t) {
      if (t === QA_TIP_TARGET) { return; }
      clearTimeout(QA_TIP_SHOW_TIMER);
      clearTimeout(QA_TIP_HIDE_TIMER);
      QA_TIP_SHOW_TIMER = setTimeout(function () {
        // هدف هنوز در سند هست؟ (مثلاً پس از AJAX حذف نشده باشد)
        if (t.isConnected) { qaTipShow(t); }
      }, 80);
    } else if (QA_TIP_TARGET) {
      // نشانگر روی عنصری بدون data-tooltip آمده — یعنی از هدف خارج شده.
      // (اگر روی فرزندِ همان هدف بود، t همان هدف می‌شد و این شاخه اجرا نمی‌شد.)
      qaTipHide();
    }
  });

  // فوکوس صفحه‌کلید — همان تولتیپ، بدون تأخیر
  document.addEventListener('focusin', function (ev) {
    if (QA_TIP_IS_TOUCH) { return; }
    var t = qaTipTarget(ev);
    if (t) {
      clearTimeout(QA_TIP_SHOW_TIMER);
      qaTipShow(t);
    }
  });
  document.addEventListener('focusout', function () {
    qaTipHide();
  });

  // کلیک روی هدف = بستن فوری (تا مسیر عملیات را نپوشاند)
  document.addEventListener('click', function (ev) {
    if (qaTipTarget(ev)) { qaTipHideNow(); }
  }, true);

  // اسکرول/تغییر اندازه = بستن فوری (جای تولتیپ کهنه می‌شود)
  window.addEventListener('scroll', qaTipHideNow, true);
  window.addEventListener('resize', qaTipHideNow);

  // Escape هم تولتیپ را می‌بندد
  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape' || ev.keyCode === 27) { qaTipHideNow(); }
  }, true);

  // روی صفحه‌های لمسی، تولتیپ‌ها غیرفعال‌اند؛ با حرکت واقعی موس دوباره فعال
  window.addEventListener('touchstart', function () {
    QA_TIP_IS_TOUCH = true;
    qaTipHideNow();
  }, { capture: true, passive: true });
  document.addEventListener('mousemove', function (ev) {
    if (QA_TIP_IS_TOUCH
        && (Math.abs(ev.movementX || 0) > 2 || Math.abs(ev.movementY || 0) > 2)) {
      QA_TIP_IS_TOUCH = false;
    }
  });

  /* (۲.۱.۰) سیستم پیام خصوصی موقتاً غیرفعال است */

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* (۲.۱.۰) سیستم پیام خصوصی موقتاً غیرفعال است */

  /* ==================================================================
     ۱۷. افزوده‌های ۲.۲.۰ — دراپ‌داون چرخ‌دنده، شمارشگر کپی پیوند، تیکر خبری
     ================================================================== */

  /* ---------- ۱۷.۱ دراپ‌داون چرخ‌دندهٔ مدیریت پرسش ---------- */

  /* ۲.۲.۱ — دراپ‌داون به <body> منتقل می‌شود تا از هر ancestor با
     overflow:hidden یا transform فرار کند. موقعیت با position:absolute
     نسبت به document (نه viewport) محاسبه می‌شود، تا با اسکرول هم
     به دکمه چسبیده بماند. اگر فضای کافی پایین نبود، بالا چرخد. */
  function qaIsRTL() {
    return (document.documentElement.getAttribute('dir') === 'ltr') ? false :
      ((document.documentElement.dir === 'ltr') ? false :
        ((window.getComputedStyle(document.documentElement).direction) === 'ltr' ? false : true));
  }

  function qaPositionGearPop(pop, btn) {
    if (!document.body || !pop || !btn) { return; }

    // اگر هنوز به body منتقل نشده، منتقلش کن
    if (pop.parentNode !== document.body) {
      pop._qaOrigParent = pop.parentNode;
      document.body.appendChild(pop);
      pop.classList.add('is-ported');
    }

    var btnRect = btn.getBoundingClientRect();
    var vw = document.documentElement.clientWidth;
    var vh = window.innerHeight;
    var scrollY = window.pageYOffset || document.documentElement.scrollTop || 0;
    var scrollX = window.pageXOffset || document.documentElement.scrollLeft || 0;
    var isRTL = qaIsRTL();
    var isMobile = window.matchMedia && window.matchMedia('(max-width: 640px)').matches;
    var PAD = 8;

    // ارتفاع pop را با یک اندازه‌گیری موقت به‌دست بیاور
    var prevHidden = pop.hidden;
    if (prevHidden) { pop.hidden = false; }
    pop.style.position = 'absolute';
    pop.style.left = '-9999px';
    pop.style.top = '-9999px';
    pop.style.right = 'auto';
    pop.style.bottom = 'auto';
    pop.style.insetInlineStart = 'auto';
    pop.style.insetInlineEnd = 'auto';
    var popRect = pop.getBoundingClientRect();
    var popW = popRect.width;
    var popH = popRect.height;

    // محاسبهٔ موقعیت عمودی (نسبت به document)
    var topBelowDoc = btnRect.bottom + PAD + scrollY;
    var topAboveDoc = btnRect.top - PAD - popH + scrollY;
    // اگر پایین جا نداشت و بالا جا داشت، بالا چرخد
    var useBelow = (btnRect.bottom + PAD + popH <= vh - PAD) || (btnRect.top - PAD - popH < PAD);
    var topDoc = useBelow ? topBelowDoc : topAboveDoc;
    if (useBelow) { pop.classList.remove('is-flip-up'); }
    else { pop.classList.add('is-flip-up'); }

    // محاسبهٔ موقعیت افقی (نسبت به document)
    // desktop: inset-inline-end:0 → RTL: لبهٔ چپ pop روی لبهٔ چپ btn
    //                            → LTR: لبهٔ راست pop روی لبهٔ راست btn
    // mobile: inset-inline-start:0 → RTL: لبهٔ راست pop روی لبهٔ راست btn
    //                             → LTR: لبهٔ چپ pop روی لبهٔ چپ btn
    var leftDoc;
    if (isMobile) {
      if (isRTL) { leftDoc = btnRect.right - popW + scrollX; }
      else { leftDoc = btnRect.left + scrollX; }
    } else {
      if (isRTL) { leftDoc = btnRect.left + scrollX; }
      else { leftDoc = btnRect.right - popW + scrollX; }
    }

    // مهار در viewport
    if (leftDoc + popW > vw - PAD + scrollX) { leftDoc = vw - PAD - popW + scrollX; }
    if (leftDoc < PAD + scrollX) { leftDoc = PAD + scrollX; }

    pop.style.left = leftDoc + 'px';
    pop.style.top = topDoc + 'px';

    // ذخیره برای reposition روی scroll/resize
    pop._qaBtn = btn;

    if (prevHidden) { pop.hidden = true; }
  }

  // هندلر اسکرول/resize — چون pop با position:absolute روی document است
  // و دکمه هم با document می‌چسبد، فقط روی resize نیاز به محاسبهٔ دوباره داریم.
  function qaRepositionOpenGears() {
    Array.prototype.forEach.call(document.querySelectorAll('.qa-gear-pop.is-ported:not([hidden])'), function (pop) {
      if (pop._qaBtn) { qaPositionGearPop(pop, pop._qaBtn); }
    });
  }

  function qaCloseAllGears() {
    Array.prototype.forEach.call(document.querySelectorAll('.qa-gear'), function (gear) {
      var btn = gear.querySelector('.qa-gear-btn');
      // pop ممکن است به body منتقل شده باشد، پس از document جستجو کن
      var popId = btn ? btn.getAttribute('aria-controls') : null;
      var pop = popId ? document.getElementById(popId) : gear.querySelector('.qa-gear-pop');
      if (pop && !pop.hidden) {
        pop.hidden = true;
        pop.classList.remove('is-flip-up');
        pop._qaBtn = null;
      }
      if (btn) {
        btn.classList.remove('is-open');
        btn.setAttribute('aria-expanded', 'false');
      }
    });
  }

  Array.prototype.forEach.call(
    document.querySelectorAll('.qa-gear'),
    function (gear) {
      var btn = gear.querySelector('.qa-gear-btn');
      var popId = btn ? btn.getAttribute('aria-controls') : null;
      var pop = popId ? document.getElementById(popId) : gear.querySelector('.qa-gear-pop');
      if (!btn || !pop) { return; }

      btn.addEventListener('click', function (ev) {
        ev.preventDefault();
        ev.stopPropagation();
        var willOpen = pop.hidden;
        qaCloseAllGears();
        if (willOpen) {
          pop.hidden = false;
          btn.classList.add('is-open');
          btn.setAttribute('aria-expanded', 'true');
          qaPositionGearPop(pop, btn);
        }
      });
    }
  );

  // محاسبهٔ دوباره روی resize (تغییر layout)
  window.addEventListener('resize', qaRepositionOpenGears);

  /* بستن با کلیک بیرون یا Escape */
  document.addEventListener('click', function (ev) {
    if (ev.target.closest && ev.target.closest('.qa-gear')) { return; }
    qaCloseAllGears();
  });
  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape' || ev.keyCode === 27) { qaCloseAllGears(); }
  });

  /* ---------- ۱۷.۲ شمارشگر پست — کلیک = کپی پیوند ---------- */
  Array.prototype.forEach.call(
    document.querySelectorAll('.qa-post-counter'),
    function (btn) {
      btn.addEventListener('click', function () {
        var url = btn.getAttribute('data-copy-url');
        if (!url) { return; }

        function done() {
          btn.classList.add('is-copied');
          var oldTip = btn.getAttribute('data-tooltip') || '';
          btn.setAttribute('data-tooltip', 'کپی شد!');
          if (btn.textContent.indexOf('#') === 0) {
            btn.setAttribute('data-copied-label', btn.textContent);
          }
          setTimeout(function () {
            btn.classList.remove('is-copied');
            btn.setAttribute('data-tooltip', oldTip);
          }, 1600);
        }

        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(url).then(done).catch(function () { fallbackCopy(url, btn); });
        } else {
          fallbackCopy(url, btn);
        }
      });
    }
  );

  /* ---------- ۱۷.۳ [حذف شد] تیکر خبری announce-bar در ۲.۲.۰ حذف شد ---------- */

  /* ---------- ۱۷.۴ مودال دلیل گزارش تخلف (۲.۲.۰) ---------- */
  (function () {
    var modal = document.getElementById('qa-flag-modal');
    if (!modal) { return; }

    var backdrop = modal.querySelector('.qa-flag-modal-backdrop');
    var closeBtn = modal.querySelector('.qa-flag-modal-close');
    var cancelBtn = modal.querySelector('.qa-flag-modal-actions [data-flag-close]');
    var form = document.getElementById('qa-flag-modal-form');
    var tokenInput = document.getElementById('qa-flag-modal-token');
    var coidInput = document.getElementById('qa-flag-modal-coid');
    var typeInput = document.getElementById('qa-flag-modal-type');
    var reasonInput = document.getElementById('qa-flag-modal-reason');
    var counter = document.getElementById('qa-flag-modal-counter');
    var kindLbl = document.getElementById('qa-flag-modal-kind');
    var hint = document.getElementById('qa-flag-modal-hint');
    var submitBtn = document.getElementById('qa-flag-modal-submit');

    function toFaDigits(s) {
      var map = '۰۱۲۳۴۵۶۷۸۹';
      return String(s).replace(/\d/g, function (d) { return map[+d]; });
    }

    function openModal(coid, kind, token, alreadyFlagged, type) {
      if (!modal || !form) { return; }
      if (tokenInput) { tokenInput.value = token || ''; }
      if (coidInput) { coidInput.value = String(coid || ''); }
      // ۲.۲.۰ — type برای جلوگیری از تداخل coid بین topic و post
      if (typeInput) { typeInput.value = (type === 'post') ? 'post' : 'topic'; }
      if (reasonInput) { reasonInput.value = ''; }
      if (counter) { counter.textContent = toFaDigits('0'); }
      if (kindLbl) { kindLbl.textContent = kind || 'پست'; }
      if (hint) { hint.hidden = true; hint.textContent = ''; }
      if (submitBtn) {
        if (alreadyFlagged === '1' || alreadyFlagged === 1) {
          submitBtn.textContent = 'گزارش داده‌اید';
          submitBtn.disabled = true;
        } else {
          submitBtn.textContent = 'ثبت گزارش';
          submitBtn.disabled = false;
        }
      }
      modal.hidden = false;
      document.body.style.overflow = 'hidden';
      setTimeout(function () {
        if (reasonInput) { reasonInput.focus(); }
      }, 60);
    }

    function closeModal() {
      if (!modal) { return; }
      modal.hidden = true;
      document.body.style.overflow = '';
    }

    /* باز کردن مودال روی کلیک پرچم گزارش */
    document.querySelectorAll('.qa-flag-trigger').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        var coid = btn.getAttribute('data-flag-coid');
        var kind = btn.getAttribute('data-flag-kind') || 'پست';
        var token = btn.getAttribute('data-flag-token') || '';
        var already = btn.getAttribute('data-flag-already') || '0';
        var type = btn.getAttribute('data-flag-type') || 'topic';
        openModal(coid, kind, token, already, type);
      });
    });

    /* شمارندهٔ کاراکتر */
    if (reasonInput && counter) {
      reasonInput.addEventListener('input', function () {
        var v = reasonInput.value || '';
        counter.textContent = toFaDigits(String(v.length));
      });
    }

    /* بستن روی backdrop / close / cancel */
    if (backdrop) { backdrop.addEventListener('click', closeModal); }
    if (closeBtn) { closeBtn.addEventListener('click', closeModal); }
    if (cancelBtn) { cancelBtn.addEventListener('click', closeModal); }

    /* بستن روی ESC */
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && !modal.hidden) { closeModal(); }
    });

    /* ارسال فرم گزارش با AJAX — برای حفظ صفحه و نمایش پیام */
    if (form) {
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.textContent = 'در حال ثبت…';
        }
        if (hint) {
          hint.hidden = true;
          hint.classList.remove('is-ok');
          hint.textContent = '';
        }

        var data = new FormData(form);
        // هدر X-Requested-With برای شناسایی AJAX در سمت سرور
        var xhr = new XMLHttpRequest();
        xhr.open('POST', form.action, true);
        xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
        xhr.onload = function () {
          var msg = 'گزارش شما ثبت شد؛ سپاس!';
          var isOk = true;
          if (xhr.status >= 200 && xhr.status < 300) {
            try {
              var resp = JSON.parse(xhr.responseText);
              if (resp && typeof resp === 'object') {
                if (resp.ok === true || resp.status === 'ok') {
                  msg = resp.message || msg;
                  isOk = true;
                } else if (resp.status === 'already') {
                  msg = resp.message || 'این آیتم را قبلاً گزارش کرده‌اید.';
                  isOk = false;
                } else {
                  msg = resp.message || 'خطا در ثبت گزارش.';
                  isOk = false;
                }
              }
            } catch (e2) {
              // پاسخ غیر JSON — احتمالاً صفحهٔ خطا
              msg = 'پاسخ سرور نامعتبر بود؛ دوباره تلاش کنید.';
              isOk = false;
            }
          } else {
            msg = 'خطای شبکه؛ دوباره تلاش کنید.';
            isOk = false;
          }

          if (hint) {
            hint.textContent = msg;
            hint.classList.toggle('is-ok', isOk);
            hint.hidden = false;
          }
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = isOk ? 'ثبت شد' : 'ثبت دوباره';
          }

          if (isOk) {
            /* بستن مودال پس از ۱.۴ ثانیه و علامت‌گذاری دکمه‌ها به‌عنوان flagged */
            setTimeout(function () {
              closeModal();
              document.querySelectorAll('.qa-flag-trigger[data-flag-coid="' + (coidInput ? coidInput.value : '') + '"]').forEach(function (b) {
                b.classList.add('is-flagged');
                b.setAttribute('data-flag-already', '1');
                b.setAttribute('data-tooltip', 'گزارش داده‌اید');
              });
            }, 1400);
          }
        };
        xhr.onerror = function () {
          if (hint) {
            hint.textContent = 'خطای شبکه؛ دوباره تلاش کنید.';
            hint.classList.remove('is-ok');
            hint.hidden = false;
          }
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = 'ثبت دوباره';
          }
        };
        xhr.send(data);
      });
    }
  })();

  /* ---------- ۱۷.۵ پاپ‌آپ زنگولهٔ اعلان‌ها در هدر (وقتی سایدبار پنهان است) ---------- */
  (function () {
    var bell = document.getElementById('qa-notif-bell-header');
    var pop = document.getElementById('qa-notif-pop-header');
    if (!bell || !pop) { return; }
    // (۲.۳.۰) زنگولهٔ هدر نیز پیوند به صفحهٔ اعلان‌هاست؛ toggle غیرفعال می‌شود.
    if (bell.hasAttribute('data-notif-page')) { return; }

    bell.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      var isHidden = pop.hasAttribute('hidden');
      if (isHidden) {
        pop.hidden = false;
        bell.setAttribute('aria-expanded', 'true');
      } else {
        pop.hidden = true;
        bell.setAttribute('aria-expanded', 'false');
      }
    });

    document.addEventListener('click', function (e) {
      if (pop.hidden) { return; }
      if (bell.contains(e.target) || pop.contains(e.target)) { return; }
      pop.hidden = true;
      bell.setAttribute('aria-expanded', 'false');
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && !pop.hidden) {
        pop.hidden = true;
        bell.setAttribute('aria-expanded', 'false');
        bell.focus();
      }
    });
  })();

  /* (۲.۲.۰) پاپ‌آپ زنگولهٔ اعلان‌ها در سایدبار در نسخه‌های پیشین این‌جا
     تعریف می‌شد؛ در ۲.۲.۰ این کار در همان بلوک ۱۷.۱ (lines ~1178) انجام
     می‌شود. این بلوک به‌صورت عمدی حذف شده تا دو event listener روی یک دکمه
     باعث toggle متضاد نشود. پاپ‌آپ زنگولهٔ هدر در ۱۷.۵ تعریف می‌شود. */


})();
