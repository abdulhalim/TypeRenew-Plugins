(function () {
    'use strict';

    // آواتار گراواتار — اگر تصویر لود نشود (۴۰۴) حذفش کن تا حرف اول
    // نویسنده که پشت تصویر است دیده شود (همان رفتار فرانت‌اند).
    document.addEventListener('error', function (ev) {
        var t = ev.target;
        if (t && t.tagName === 'IMG' && t.classList && t.classList.contains('qa-grava')) {
            t.remove();
        }
    }, true);

    // ------------------------------------------------------------------
    // پیشخوان TypeRenew (link-js) به هر لینکی که نشانی مطلق پیشخوان یا
    // action نباشد، target="_blank" اضافه می‌کند — از جمله «مشاهدهٔ انجمن»
    // و عنوان پرسش‌ها که به سایت (فرانت‌اند) اشاره دارند. این لینک‌ها
    // باید در همان تب باز شوند، پس هدفشان را برمی‌داریم:
    // ۱) جارو پس از آماده‌شدن DOM (بعد از اجرای اسکریپت هسته)،
    // ۲) جارو پس از بارگذاری کامل صفحه (بیمه)،
    // ۳) اگر هم قبل از جارو کلیک شد، همان لحظه هدف پاک می‌شود.
    // ------------------------------------------------------------------
    var stripPanelTargets = function () {
        var root = document.querySelector('.fpanel');
        if (!root) { return; }
        root.querySelectorAll('a[target="_blank"]').forEach(function (a) {
            a.removeAttribute('target');
            a.removeAttribute('rel');
        });
    };

    document.addEventListener('DOMContentLoaded', function () {
        // setTimeout صفر تضمین می‌کند پس از همهٔ شنونده‌های DOMContentLoaded
        // (از جمله link-js هسته) اجرا شود.
        setTimeout(stripPanelTargets, 0);
    });
    window.addEventListener('load', stripPanelTargets);

    document.addEventListener('click', function (ev) {
        var a = ev.target && ev.target.closest ? ev.target.closest('.fpanel a[target="_blank"]') : null;
        if (a) {
            a.removeAttribute('target');
            a.removeAttribute('rel');
        }
    }, true);

    // ------------------------------------------------------------------
    // دیالوگ‌های سفارشی — هماهنگ با استایل اکشن‌های پنل + آیکون Lucide
    // fpConfirm({message, title, variant, okText, cancelText}) → Promise<boolean>
    // fpNotice({message, title, variant, okText})               → Promise<true>
    // ------------------------------------------------------------------
    function fpLucide(inner, size) {
        size = size || 18;
        return '<svg viewBox="0 0 24 24" width="' + size + '" height="' + size + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + inner + '</svg>';
    }

    var FP_ICONS = {
        danger: fpLucide('<circle cx="12" cy="12" r="10"></circle><path d="M12 8v4"></path><path d="M12 16h.01"></path>'),
        warn: fpLucide('<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"></path><path d="M12 9v4"></path><path d="M12 17h.01"></path>'),
        info: fpLucide('<circle cx="12" cy="12" r="10"></circle><path d="M12 16v-4"></path><path d="M12 8h.01"></path>'),
        ok: fpLucide('<circle cx="12" cy="12" r="10"></circle><path d="m9 12 2 2 4-4"></path>'),
        /* کاغذ رسمی Lucide — «بله/تأیید» (M20 6 9 17l-5-5) و «خیر/انصراف» */
        check: fpLucide('<path d="M20 6 9 17l-5-5"></path>', 15),
        x: fpLucide('<path d="M18 6 6 18"></path><path d="m6 6 12 12"></path>', 15),
        pencil: fpLucide('<path d="M12 20h9"></path><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"></path>'),
        reply: fpLucide('<polyline points="9 17 4 12 9 7"></polyline><path d="M20 18v-2a4 4 0 0 0-4-4H4"></path>')
    };

    var FP_DIALOG = null;
    var FP_DIALOG_RESOLVER = null;

    function fpDialogBuild() {
        var d = document.createElement('div');
        d.className = 'fpanel-dlg';
        d.setAttribute('role', 'alertdialog');
        d.setAttribute('aria-modal', 'true');
        d.hidden = true;
        d.innerHTML =
            '<div class="fpanel-dlg-backdrop" data-fp-close="1"></div>' +
            '<div class="fpanel-dlg-box" dir="rtl">' +
                '<span class="fpanel-dlg-icon" aria-hidden="true"></span>' +
                '<h3 class="fpanel-dlg-title"></h3>' +
                '<p class="fpanel-dlg-desc" dir="auto"></p>' +
                '<div class="fpanel-dlg-actions">' +
                    '<button type="button" class="fpanel-btn fpanel-btn-danger fpanel-dlg-ok"></button>' +
                    '<button type="button" class="fpanel-btn fpanel-btn-ghost fpanel-dlg-cancel" data-fp-close="1"></button>' +
                '</div>' +
            '</div>';

        d.addEventListener('click', function (ev) {
            if (ev.target === d || (ev.target.closest && ev.target.closest('[data-fp-close]'))) {
                fpDialogSettle(false);
            }
        });
        document.addEventListener('keydown', function (ev) {
            if ((ev.key === 'Escape' || ev.keyCode === 27) && !d.hidden) {
                ev.preventDefault();
                fpDialogSettle(false);
            }
        });
        document.body.appendChild(d);
        return d;
    }

    function fpDialogSettle(yes) {
        if (!FP_DIALOG || FP_DIALOG.hidden) { return; }
        FP_DIALOG.hidden = true;
        var r = FP_DIALOG_RESOLVER;
        FP_DIALOG_RESOLVER = null;
        if (r) {
            try { r(yes === true); } catch (e) { /* بی‌اثر */ }
        }
    }

    function fpFill(btn, text, icon) {
        btn.innerHTML = '';
        if (icon) {
            var i = document.createElement('span');
            i.className = 'fpanel-btn-ico';
            i.setAttribute('aria-hidden', 'true');
            i.innerHTML = icon;
            btn.appendChild(i);
        }
        var s = document.createElement('span');
        s.textContent = text || '';
        btn.appendChild(s);
    }

    /* مودال دودکمه‌ای — جایگزین window.confirm */
    function fpConfirm(opts) {
        opts = opts || {};
        return new Promise(function (resolve) {
            if (!FP_DIALOG) { FP_DIALOG = fpDialogBuild(); }
            if (!FP_DIALOG.hidden) { resolve(false); return; }

            var variant = FP_ICONS[opts.variant] ? opts.variant : 'danger';
            var okBtn = FP_DIALOG.querySelector('.fpanel-dlg-ok');
            var cancelBtn = FP_DIALOG.querySelector('.fpanel-dlg-cancel');

            FP_DIALOG.removeAttribute('data-notice');
            FP_DIALOG.setAttribute('data-variant', variant);
            FP_DIALOG.querySelector('.fpanel-dlg-icon').innerHTML = opts.icon || FP_ICONS[variant];
            FP_DIALOG.querySelector('.fpanel-dlg-title').textContent = opts.title || 'تأیید عملیات';
            FP_DIALOG.querySelector('.fpanel-dlg-desc').textContent = opts.message || '';
            cancelBtn.style.display = '';
            okBtn.className = 'fpanel-btn fpanel-btn-danger fpanel-dlg-ok';
            fpFill(okBtn, opts.okText || 'بله، انجام شود', FP_ICONS.check);
            fpFill(cancelBtn, opts.cancelText || 'انصراف', FP_ICONS.x);

            okBtn.onclick = function () { fpDialogSettle(true); };
            cancelBtn.onclick = function () { fpDialogSettle(false); };

            FP_DIALOG_RESOLVER = resolve;
            FP_DIALOG.hidden = false;
            setTimeout(function () {
                try { (variant === 'danger' ? cancelBtn : okBtn).focus(); } catch (e) { /* بی‌اثر */ }
            }, 40);
        });
    }

    /* مودال تک‌دکمه‌ای — جایگزین window.alert */
    function fpNotice(opts) {
        opts = opts || {};
        return new Promise(function (resolve) {
            if (!FP_DIALOG) { FP_DIALOG = fpDialogBuild(); }
            if (!FP_DIALOG.hidden) { resolve(true); return; }

            var variant = FP_ICONS[opts.variant] ? opts.variant : 'info';
            var okBtn = FP_DIALOG.querySelector('.fpanel-dlg-ok');
            var cancelBtn = FP_DIALOG.querySelector('.fpanel-dlg-cancel');

            FP_DIALOG.setAttribute('data-notice', '1');
            FP_DIALOG.setAttribute('data-variant', variant);
            FP_DIALOG.querySelector('.fpanel-dlg-icon').innerHTML = opts.icon || FP_ICONS[variant];
            FP_DIALOG.querySelector('.fpanel-dlg-title').textContent = opts.title || 'پیام';
            FP_DIALOG.querySelector('.fpanel-dlg-desc').textContent = opts.message || '';
            cancelBtn.style.display = 'none';
            okBtn.className = 'fpanel-btn fpanel-btn-primary fpanel-dlg-ok';
            fpFill(okBtn, opts.okText || 'متوجه شدم', FP_ICONS.check);

            okBtn.onclick = function () { fpDialogSettle(true); };
            cancelBtn.onclick = null;

            FP_DIALOG_RESOLVER = function () { resolve(true); };
            FP_DIALOG.hidden = false;
            setTimeout(function () {
                try { okBtn.focus(); } catch (e) { /* بی‌اثر */ }
            }, 40);
        });
    }

    var modal = document.getElementById('fpanelModal');
    var modalForm = document.getElementById('fpanelModalForm');
    var modalTitle = document.getElementById('fpanelModalTitle');
    var modalTitleText = document.getElementById('fpanelModalTitleText');
    var modalTitleIco = document.getElementById('fpanelModalTitleIco');
    if (!modal || !modalForm) {
        return;
    }

    // ۲.۰.۰ — انتقال مودال به انتهای body: مقاوم در برابر هر جدایش/
    // برش در والدهای پنل (position:fixed همیشه نسبت به صفحه می‌ماند).
    if (modal.parentNode !== document.body) {
        document.body.appendChild(modal);
    }

    // ۲.۰.۰ — بیمه: اگر مودال به هر دلیل (کش/مترک قدیمی) بدون hidden رندر
    // شده باشد، در ابتدای بارگذاری بسته می‌شود؛ قانون CSS جدید
    // «fpanel-modal[hidden]» نیز استایل‌گذاری را قطعی می‌کند.
    modal.hidden = true;

    // ۲.۰.۰ — فیلدهای نظرسنجی مودال: تیک ← نمایش سؤال/گزینه‌ها
    var pollFieldBox = modalForm.querySelector('[data-f="poll"]');
    var pollToggleBox = modalForm.querySelector('.fpanel-poll-toggle-box');
    var pollExtraBox = modalForm.querySelector('.fpanel-poll-extra');
    if (pollToggleBox && pollExtraBox) {
        pollToggleBox.addEventListener('change', function () {
            pollExtraBox.hidden = !pollToggleBox.checked;
        });
    }

    // مقداردهی/بازنشانی فیلدهای نظرسنجی (نوع: topic/post/null)
    var fillPollFields = function (type, pollData) {
        if (!pollFieldBox) { return; }
        var q = modalForm.querySelector('input[name="poll_question"]');
        var o = modalForm.querySelector('textarea[name="poll_options"]');
        var label = pollFieldBox.querySelector('#fpanelPollLabel');
        var isTopic = type === 'topic';
        var hasPoll = !!(isTopic && pollData && pollData.question);

        pollFieldBox.style.display = isTopic ? '' : 'none';
        if (pollToggleBox) {
            pollToggleBox.checked = hasPoll;
            // برای پاسخ‌ها ارسال نشود
            pollToggleBox.disabled = !isTopic;
        }
        if (q) { q.value = hasPoll ? String(pollData.question || '') : ''; }
        if (o) { o.value = hasPoll ? String(pollData.options || '') : ''; }
        if (pollExtraBox) { pollExtraBox.hidden = !hasPoll; }
        if (label) { label.textContent = hasPoll ? 'ویرایش نظرسنجی' : 'افزودن نظرسنجی'; }
    };

    // ------------------------------------------------------------------
    // ۲.۰.۰ — تأیید سفارشی برای دکمه‌های داخل فرم (مثل حذف دسته).
    // دکمه با data-fp-confirm ارسال فرم را متوقف می‌کند، دیالوگ سفارشی
    // نمایش می‌دهد و در صورت تأیید، درخواست با formaction دکمه ارسال می‌شود.
    // ------------------------------------------------------------------
    document.addEventListener('click', function (ev) {
        var btn = ev.target.closest ? ev.target.closest('[data-fp-confirm]') : null;
        if (!btn) { return; }
        ev.preventDefault();
        ev.stopPropagation();

        var form = btn.closest('form');
        fpConfirm({
            message: btn.getAttribute('data-fp-confirm'),
            title: btn.getAttribute('data-fp-confirm-title') || 'تأیید عملیات',
            variant: btn.getAttribute('data-fp-confirm-variant') || 'danger',
            okText: btn.getAttribute('data-fp-confirm-ok') || 'بله، انجام شود'
        }).then(function (yes) {
            if (!yes || !form) { return; }
            var go = document.createElement('form');
            go.method = 'post';
            go.action = btn.getAttribute('formaction') || form.getAttribute('action') || '';
            // ۲.۲.۰ — همهٔ فیلدهای فرم کپی می‌شوند (نه فقط _ و id) تا
            // فرم‌هایی مثل بلاک کاربر (uid/duration/reason/…) هم درست ارسال شوند.
            form.querySelectorAll('input[name], select[name], textarea[name]').forEach(function (src) {
                if (src.disabled) { return; }
                if ((src.type === 'checkbox' || src.type === 'radio') && !src.checked) { return; }
                var inp = document.createElement('input');
                inp.type = 'hidden';
                inp.name = src.name;
                inp.value = src.value;
                go.appendChild(inp);
            });
            document.body.appendChild(go);
            go.submit();
        });
    }, true);

    // ------------------------------------------------------------------
    // ۲.۲.۰ — فرم بلاک کاربر: نمایش فیلد «ساعت» فقط برای مدت دلخواه
    // ------------------------------------------------------------------
    document.addEventListener('change', function (ev) {
        var sel = ev.target.closest ? ev.target.closest('.fpanel-ban-duration') : null;
        if (!sel) { return; }
        var hours = sel.closest('.fpanel-ban-fields')
            ? sel.closest('.fpanel-ban-fields').querySelector('.fpanel-ban-hours')
            : null;
        if (hours) {
            hours.hidden = sel.value !== 'custom';
            if (hours.hidden) { hours.value = ''; }
            else { hours.focus(); }
        }
    });

    // jQuery در پیشخوان هسته موجود است (در Panel.php بعد از محتوا لود شد)

    var submitForm = function (data, confirmText) {
        var go = function () {
            var form = document.createElement('form');
            form.method = 'post';
            form.action = data.__action || '';
            Object.keys(data).forEach(function (key) {
                if (key === '__action') { return; }
                var input = document.createElement('input');
                input.type = 'hidden';
                input.name = key;
                input.value = String(data[key]);
                form.appendChild(input);
            });
            document.body.appendChild(form);
            form.submit();
        };

        if (confirmText) {
            fpConfirm({
                message: confirmText,
                title: 'تأیید حذف',
                variant: 'danger'
            }).then(function (yes) {
                if (yes) { go(); }
            });
            return;
        }
        go();
    };

    var readToken = function () {
        var input = modalForm.querySelector('input[name="_"]');
        return input ? input.value : '';
    };

    var actionUrl = (function () {
        var listForm = document.querySelector('.fpanel-list-form');
        return listForm ? listForm.getAttribute('data-action') : '';
    })();

    // ---------------- عملیات تکی ----------------
    document.addEventListener('click', function (ev) {
        var btn = ev.target.closest('.fpanel-act');
        if (!btn) { return; }

        var doMode = btn.getAttribute('data-do');
        var id = parseInt(btn.getAttribute('data-id') || '0', 10);

        if (btn.hasAttribute('data-edit')) {
            openEdit(btn.getAttribute('data-edit'), id, btn);
            return;
        }

        if (btn.hasAttribute('data-reply')) {
            openReply(parseInt(btn.getAttribute('data-reply') || '0', 10));
            return;
        }

        if (!doMode || !id) { return; }
        ev.preventDefault();

        var data = {
            '_': readToken(),
            'do': doMode,
            'back': location.search.replace(/^\?/, '')
        };
        var key = doMode.indexOf('topic') === 0 ? 'topic' : 'post';
        data[key] = id;

        if (doMode.indexOf('-status') !== -1) {
            data['status'] = btn.getAttribute('data-status');
        }

        data.__action = actionUrl + (actionUrl.indexOf('?') === -1 ? '?' : '&') + 'do=' + encodeURIComponent(doMode);
        submitForm(data, btn.getAttribute('data-confirm'));
    });

    // ---------------- عملیات گروهی ----------------
    document.addEventListener('click', function (ev) {
        var btn = ev.target.closest('.fpanel-bulk button[data-do]');
        if (!btn) { return; }
        ev.preventDefault();

        var checkboxes = document.querySelectorAll('.fpanel-list-form input[type="checkbox"]:checked:not(.fpanel-select-all)');
        var ids = [];
        checkboxes.forEach(function (cb) { ids.push(cb.value); });

        if (ids.length === 0) {
            fpNotice({
                variant: 'info',
                title: 'انتخاب نشده',
                message: 'ابتدا موارد موردنظر را انتخاب کنید.'
            });
            return;
        }

        var doMode = btn.getAttribute('data-do');
        var data = {
            '_': readToken(),
            'do': doMode,
            'back': location.search.replace(/^\?/, ''),
            '__action': ''
        };
        data.__action = actionUrl + (actionUrl.indexOf('?') === -1 ? '?' : '&') + 'do=' + encodeURIComponent(doMode);

        var key = doMode.indexOf('topic') === 0 ? 'topics' : 'posts';

        // ساخت فرم مستقل و انتقال فیلدها
        var form = document.createElement('form');
        form.method = 'post';
        form.action = data.__action;

        var token = document.createElement('input');
        token.type = 'hidden';
        token.name = '_';
        token.value = readToken();
        form.appendChild(token);

        var doInput = document.createElement('input');
        doInput.type = 'hidden';
        doInput.name = 'do';
        doInput.value = doMode;
        form.appendChild(doInput);

        var back = document.createElement('input');
        back.type = 'hidden';
        back.name = 'back';
        back.value = location.search.replace(/^\?/, '');
        form.appendChild(back);

        if (btn.getAttribute('data-status')) {
            var st = document.createElement('input');
            st.type = 'hidden';
            st.name = 'status';
            st.value = btn.getAttribute('data-status');
            form.appendChild(st);
        }

        ids.forEach(function (id) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = key + 's[]';
            input.value = id;
            form.appendChild(input);
        });

        // پاک‌سازی فیلدهای موقت داخل مودال
        modalForm.querySelectorAll('input[name$="[]"]').forEach(function (n) { n.remove(); });

        var go = function () {
            document.body.appendChild(form);
            form.submit();
        };

        if (btn.getAttribute('data-confirm')) {
            fpConfirm({
                message: btn.getAttribute('data-confirm'),
                title: 'تأیید حذف',
                variant: 'danger'
            }).then(function (yes) {
                if (yes) { go(); }
            });
            return;
        }
        go();
    });

    // ---------------- انتخاب همه ----------------
    document.addEventListener('change', function (ev) {
        var cb = ev.target.closest('.fpanel-select-all');
        if (!cb) { return; }
        var form = cb.closest('.fpanel-list-form');
        if (!form) { return; }
        form.querySelectorAll('input[type="checkbox"]:not(.fpanel-select-all)').forEach(function (c) {
            c.checked = cb.checked;
        });
    });

    // ---------------- مودال ویرایش ----------------
    function openEdit(type, id, btn) {
        var row = btn.closest('.fpanel-row');
        var raw = row ? row.querySelector('.fpanel-row-data') : null;
        if (!raw) { return; }

        var data;
        try {
            data = JSON.parse(raw.textContent);
        } catch (e) {
            return;
        }

        if (modalTitleText) {
            modalTitleText.textContent = 'ویرایش ' + (type === 'topic' ? 'پرسش' : 'پاسخ');
        } else {
            modalTitle.textContent = 'ویرایش ' + (type === 'topic' ? 'پرسش' : 'پاسخ');
        }
        if (modalTitleIco) { modalTitleIco.innerHTML = FP_ICONS.pencil; }

        var titleField = modalForm.querySelector('[data-f="title"]');
        if (titleField) {
            titleField.style.display = (type === 'topic' && data.title) ? '' : 'none';
        }

        modalForm.querySelector('input[name="author"]').value = data.author || '';
        modalForm.querySelector('input[name="mail"]').value = data.mail || '';
        modalForm.querySelector('input[name="url"]').value = data.url || '';
        var titleInput = modalForm.querySelector('input[name="title"]');
        if (titleInput) { titleInput.value = data.title || ''; }
        modalForm.querySelector('textarea[name="text"]').value = data.text || '';

        var doMode = type === 'topic' ? 'topic-edit' : 'post-edit';
        modalForm.action = actionUrl + (actionUrl.indexOf('?') === -1 ? '?' : '&') + 'do=' + doMode;

        // نظرسنجی (۲.۰.۰) — فقط برای پرسش‌ها؛ مقدار از دادهٔ ردیف
        fillPollFields(type, data.poll || null);

        // کلید شناسه: topic یا post
        modalForm.querySelectorAll('input[name="topic"], input[name="post"]').forEach(function (n) { n.remove(); });
        var idInput = document.createElement('input');
        idInput.type = 'hidden';
        idInput.name = type;
        idInput.value = id;
        modalForm.appendChild(idInput);

        modal.hidden = false;
    }

    function openReply(topicId) {
        if (modalTitleText) {
            modalTitleText.textContent = 'پاسخ مدیر';
        } else {
            modalTitle.textContent = 'پاسخ مدیر';
        }
        if (modalTitleIco) { modalTitleIco.innerHTML = FP_ICONS.reply; }

        var titleField = modalForm.querySelector('[data-f="title"]');
        if (titleField) {
            titleField.style.display = 'none';
        }

        modalForm.querySelector('input[name="author"]').value = '';
        modalForm.querySelector('input[name="mail"]').value = '';
        modalForm.querySelector('input[name="url"]').value = '';
        modalForm.querySelector('textarea[name="text"]').value = '';

        modalForm.action = actionUrl + (actionUrl.indexOf('?') === -1 ? '?' : '&') + 'do=reply';

        // پاسخ مدیر نظرسنجی ندارد (۲.۰.۰)
        fillPollFields('post', null);

        modalForm.querySelectorAll('input[name="topic"], input[name="post"]').forEach(function (n) { n.remove(); });
        var idInput = document.createElement('input');
        idInput.type = 'hidden';
        idInput.name = 'topic';
        idInput.value = topicId;
        modalForm.appendChild(idInput);

        modal.hidden = false;
        modalForm.querySelector('textarea[name="text"]').focus();
    }

    // بستن مودال
    modal.addEventListener('click', function (ev) {
        if (ev.target === modal || ev.target.closest('[data-close]')) {
            modal.hidden = true;
        }
    });

    document.addEventListener('keydown', function (ev) {
        if (ev.key === 'Escape' && !modal.hidden) {
            modal.hidden = true;
        }
    });
})();
