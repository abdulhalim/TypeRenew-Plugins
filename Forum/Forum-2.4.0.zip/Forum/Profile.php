<?php
namespace TypechoPlugin\Forum;

use Typecho\Db;
use Typecho\Widget\Exception as WidgetException;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Profile extends ForumPage
{
    /** نگاشت نام گروه‌های هسته به فارسی */
    private const GROUP_LABELS = [
        'administrator' => 'مدیر',
        'editor'        => 'ویراستار',
        'contributor'   => 'همکار',
        'subscriber'    => 'عضو',
        'visitor'       => 'بازدیدکننده'
    ];

    protected function forumPageTitle(): string
    {
        $user = $this->profileUser();
        if ($user === null) {
            return (string) Plugin::opt('forumTitle', 'انجمن پرسش و پاسخ');
        }
        return 'پروفایل ' . $user['displayName'];
    }

    protected function forumPageDescription(): string
    {
        $user = $this->profileUser();
        if ($user === null) {
            return (string) $this->options->description;
        }
        return 'پروفایل، آمار و پرسش‌ها و پاسخ‌های ' . $user['displayName'] . ' در انجمن';
    }

    protected function forumPageUrl(): string
    {
        $uid = (int) ($this->request->get('uid') ?: 0);
        return $uid > 0 ? Plugin::profileUrl($uid) : Plugin::forumUrl();
    }

    public function render(): void
    {
        $this->renderForumPage('profile.php');
    }

    /** ردیف کاربر پروفایل — یا null */
    private function profileUser(): ?array
    {
        static $cache = null;
        static $loaded = false;

        if ($loaded) {
            return $cache;
        }
        $loaded = true;
        $cache = null;

        $uid = (int) ($this->request->get('uid') ?: 0);
        if ($uid < 1) {
            return null;
        }

        try {
            $db = Db::get();
            // ستون meta را از SELECT حذف می‌کنیم چون ممکن است وجود نداشته باشد
            $row = $db->fetchRow(
                $db->select('uid', 'name', 'screenName', 'mail', 'url', 'created', 'group')
                    ->from('table.users')
                    ->where('uid = ?', $uid)
                    ->limit(1)
            );

            if ($row) {
                $row['displayName'] = trim((string) ($row['screenName'] ?: $row['name']));
                $row['groupLabel'] = self::GROUP_LABELS[$row['group']] ?? $row['group'];
                // خواندن meta از Plugin::getUserMeta (از users.meta یا fallback به options)
                $meta = Plugin::getUserMeta((int) $uid);
                $row['bio'] = (string) ($meta['bio'] ?? '');
                $row['social'] = [
                    'twitter'   => (string) ($meta['twitter'] ?? ''),
                    'github'    => (string) ($meta['github'] ?? ''),
                    'telegram'  => (string) ($meta['telegram'] ?? ''),
                    'instagram' => (string) ($meta['instagram'] ?? ''),
                    'linkedin'  => (string) ($meta['linkedin'] ?? ''),
                    'youtube'   => (string) ($meta['youtube'] ?? ''),
                ];
                $cache = $row;
            }
        } catch (\Throwable $e) {
            $cache = null;
        }

        return $cache;
    }

    protected function prepareContext(): array
    {
        if (!Plugin::profileEnabled()) {
            throw new WidgetException(_t('صفحهٔ موردنظر یافت نشد'), 404);
        }

        $user = $this->profileUser();
        if ($user === null) {
            throw new WidgetException(_t('عضو موردنظر یافت نشد'), 404);
        }

        $uid = (int) $user['uid'];
        $db = Db::get();

        $pageSize = max(5, min(50, (int) Plugin::opt('pageSize', 15)));
        $page = max(1, (int) ($this->request->get('page') ?: 1));
        $tab = $this->request->get('tab');
        $tab = in_array($tab, ['questions', 'answers'], true) ? $tab : 'questions';

        // ---------------- آمار شخصی ----------------
        $stats = Plugin::userStats($uid);

        // ---------------- تب پرسش‌ها ----------------
        $rows = [];
        $totalRows = 0;
        $pages = 1;

        if ($tab === 'questions') {
            $totalRows = $stats['questions'];
            $pages = max(1, (int) ceil($totalRows / $pageSize));
            if ($totalRows > 0 && $page > $pages) {
                throw new WidgetException(_t('صفحهٔ درخواستی وجود ندارد'), 404);
            }

            $topicRows = $db->fetchAll(
                $db->select('id', 'created', 'text')
                    ->from('table.forum_topics')
                    ->where('author_id = ? AND status = ?', $uid, 'approved')
                    ->order('created', Db::SORT_DESC)
                    ->page($page, $pageSize)
            );
            foreach ($topicRows as $r) {
                $out = Plugin::topicRowToLegacy($r);
                $out['replies'] = (int) $db->fetchObject(
                    $db->select(['COUNT(id)' => 'n'])->from('table.forum_posts')
                        ->where('topic_id = ? AND status = ?', (int) $r['id'], 'approved')
                )->n;
                $rows[] = $out;
            }
        } else {
            // ---------------- تب پاسخ‌ها ----------------
            $totalRows = $stats['answers'];
            $pages = max(1, (int) ceil($totalRows / $pageSize));
            if ($totalRows > 0 && $page > $pages) {
                throw new WidgetException(_t('صفحهٔ درخواستی وجود ندارد'), 404);
            }

            $answerRows = $db->fetchAll(
                $db->select('id', 'topic_id', 'created', 'text')
                    ->from('table.forum_posts')
                    ->where('author_id = ? AND status = ?', $uid, 'approved')
                    ->order('created', Db::SORT_DESC)
                    ->page($page, $pageSize)
            );

            if ($answerRows) {
                // پرسشِ هر پاسخ برای عنوان و پیوند
                $parentIds = array_values(array_unique(array_map(static fn ($r) => (int) $r['topic_id'], $answerRows)));
                $qRows = $db->fetchAll(
                    $db->select('id', 'text')->from('table.forum_topics')->where('id IN ?', $parentIds)
                );
                $qMap = [];
                foreach ($qRows as $qr) {
                    $qMap[(int) $qr['id']] = (string) $qr['text'];
                }
                foreach ($answerRows as $ar) {
                    $out = Plugin::postRowToLegacy($ar);
                    $qText = $qMap[(int) $ar['topic_id']] ?? '';
                    [$ttl] = Plugin::splitQuestion($qText);
                    $out['questionTitle'] = Plugin::stripMarkup($ttl);
                    $out['excerpt'] = Plugin::excerpt((string) $ar['text'], 200);
                    $rows[] = $out;
                }
            }
        }

        // نشانی صفحهٔ n از همین تب
        $pageUrlFn = static function (int $n) use ($uid, $tab): string {
            $url = Plugin::profileUrl($uid);
            $params = [];
            if ($tab !== 'questions') {
                $params['tab'] = $tab;
            }
            if ($n > 1) {
                $params['page'] = $n;
            }
            if ($params) {
                $url .= '?' . http_build_query($params);
            }
            return $url;
        };

        return $this->commonContext() + [
            'user'      => $user,
            'uid'       => $uid,
            'stats'     => $stats,
            'tab'       => $tab,
            'rows'      => $rows,
            'page'      => $page,
            'pages'     => $pages,
            'totalRows' => $totalRows,
            'pageUrl'   => $pageUrlFn,
        ];
    }
}
