<?php

namespace TypechoPlugin\Forum;

use Typecho\Db;
use Utils\Schema as CoreSchema;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Schema
{
    /** اطمینان از وجود همهٔ جداول و ایندکس‌ها — idempotent */
    public static function ensure(): void
    {
        try {
            $db = Db::get();
        } catch (\Throwable $e) {
            return;
        }

        $dialect = CoreSchema::dialect($db);
        $prefix = $db->getPrefix();

        self::ensureCategories($db, $dialect, $prefix . 'forum_categories');
        self::ensureTopics($db, $dialect, $prefix . 'forum_topics');
        self::ensurePosts($db, $dialect, $prefix . 'forum_posts');
        self::ensurePolls($db, $dialect, $prefix . 'forum_polls');
        self::ensurePollVotes($db, $dialect, $prefix . 'forum_poll_votes');
        self::ensureNotifications($db, $dialect, $prefix . 'forum_notifications');
        self::ensureFlags($db, $dialect, $prefix . 'forum_flags');
        self::ensureLikes($db, $dialect, $prefix . 'forum_likes');
        // ۲.۱.۰: جداول پیام خصوصی و بلاک‌ها
        self::ensureMessages($db, $dialect, $prefix . 'forum_messages');
        self::ensureBlocks($db, $dialect, $prefix . 'forum_blocks');
        // ۲.۲.۰: بلاک اداری کاربران (موقت/همیشه)
        self::ensureBans($db, $dialect, $prefix . 'forum_bans');
        // ۲.۲.۰: ستون قفل دسته‌ها (نصب‌های موجود)
        self::ensureCategoryLockColumn($db, $dialect, $prefix . 'forum_categories');
    }

    /** نشانی واقعی جدول با پیشوند */
    public static function table(string $name): string
    {
        return Db::get()->getPrefix() . $name;
    }

    /** نام‌گذاری ایندکس برای هر گویش (طول مجاز MySQL) */
    private static function index(string $table, string $short): string
    {
        return $table . '_' . $short;
    }

    // ------------------------------------------------------------------
    //  دسته‌بندی‌ها
    // ------------------------------------------------------------------

    private static function ensureCategories(Db $db, string $dialect, string $table): void
    {
        $name = CoreSchema::quote($table, $dialect);

        $db->query(match ($dialect) {
            'sqlite' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" INTEGER PRIMARY KEY AUTOINCREMENT,'
                . '"name" TEXT NOT NULL,'
                . '"slug" TEXT NOT NULL DEFAULT \'\','
                . '"icon" TEXT NOT NULL DEFAULT \'\','
                . '"color" TEXT NOT NULL DEFAULT \'\','
                . '"parent_id" INTEGER NOT NULL DEFAULT 0,'
                . '"sort_order" INTEGER NOT NULL DEFAULT 0,'
                . '"is_locked" INTEGER NOT NULL DEFAULT 0,'
                . '"created" INTEGER NOT NULL DEFAULT 0'
                . ')',
            'pgsql' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" BIGSERIAL PRIMARY KEY,'
                . '"name" VARCHAR(80) NOT NULL,'
                . '"slug" VARCHAR(80) NOT NULL DEFAULT \'\','
                . '"icon" VARCHAR(40) NOT NULL DEFAULT \'\','
                . '"color" VARCHAR(9) NOT NULL DEFAULT \'\','
                . '"parent_id" INT NOT NULL DEFAULT 0,'
                . '"sort_order" INT NOT NULL DEFAULT 0,'
                . '"is_locked" INT NOT NULL DEFAULT 0,'
                . '"created" INT NOT NULL DEFAULT 0'
                . ')',
            default => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '`id` bigint unsigned NOT NULL auto_increment,'
                . '`name` varchar(80) NOT NULL,'
                . '`slug` varchar(80) NOT NULL DEFAULT \'\','
                . '`icon` varchar(40) NOT NULL DEFAULT \'\','
                . '`color` varchar(9) NOT NULL DEFAULT \'\','
                . '`parent_id` int unsigned NOT NULL DEFAULT 0,'
                . '`sort_order` int unsigned NOT NULL DEFAULT 0,'
                . '`is_locked` tinyint unsigned NOT NULL DEFAULT 0,'
                . '`created` int unsigned NOT NULL DEFAULT 0,'
                . 'PRIMARY KEY (`id`),'
                . 'KEY `' . self::index($table, 'sort') . '` (`sort_order`)'
                . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=' . CoreSchema::detectMysqlCollation($db),
        }, Db::WRITE);

        CoreSchema::ensureIndex($db, $table, self::index($table, 'sort'), ['sort_order']);
    }

    /**
     * ۲.۲.۰ — افزودن ستون is_locked به جدول دسته‌های موجود (مهاجرت idempotent)
     *
     * جدول‌های نصب‌شده پیش از ۲.۲.۰ این ستون را ندارند؛ CREATE TABLE IF
     * NOT EXISTS ستون تازه را اضافه نمی‌کند. این مهاجرت با columnExists
     * هسته بررسی و در نبودِ ستون، ALTER TABLE اجرا می‌کند.
     */
    private static function ensureCategoryLockColumn(Db $db, string $dialect, string $table): void
    {
        try {
            if (CoreSchema::columnExists($db, $table, 'is_locked')) {
                return;
            }
        } catch (\Throwable $e) {
            return; // جدول هنوز ساخته نشده — CREATE TABLE بالا کافی است
        }

        $name = CoreSchema::quote($table, $dialect);
        $col = match ($dialect) {
            'pgsql' => 'ADD COLUMN "is_locked" INT NOT NULL DEFAULT 0',
            'sqlite' => 'ADD COLUMN "is_locked" INTEGER NOT NULL DEFAULT 0',
            default => 'ADD COLUMN `is_locked` tinyint unsigned NOT NULL DEFAULT 0',
        };

        try {
            $db->query('ALTER TABLE ' . $name . ' ' . $col, Db::WRITE);
        } catch (\Throwable $e) {
            // ستون شاید هم‌اکنون توسط نصب موازی اضافه شده باشد
        }
    }

    // ------------------------------------------------------------------
    //  پرسش‌ها (موضوعات)
    // ------------------------------------------------------------------

    private static function ensureTopics(Db $db, string $dialect, string $table): void
    {
        $name = CoreSchema::quote($table, $dialect);

        $db->query(match ($dialect) {
            'sqlite' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" INTEGER PRIMARY KEY AUTOINCREMENT,'
                . '"title" TEXT NOT NULL DEFAULT \'\','
                . '"text" TEXT NOT NULL,'
                . '"author_id" INTEGER NOT NULL DEFAULT 0,'
                . '"author_name" TEXT NOT NULL DEFAULT \'\','
                . '"author_mail" TEXT NOT NULL DEFAULT \'\','
                . '"author_url" TEXT NOT NULL DEFAULT \'\','
                . '"author_ip" TEXT NOT NULL DEFAULT \'\','
                . '"author_agent" TEXT NOT NULL DEFAULT \'\','
                . '"status" TEXT NOT NULL DEFAULT \'approved\','
                . '"category_id" INTEGER NOT NULL DEFAULT 0,'
                . '"is_locked" INTEGER NOT NULL DEFAULT 0,'
                . '"is_pinned" INTEGER NOT NULL DEFAULT 0,'
                . '"is_tracked" INTEGER NOT NULL DEFAULT 0,'
                . '"is_hidden" INTEGER NOT NULL DEFAULT 0,'
                . '"best_post_id" INTEGER NOT NULL DEFAULT 0,'
                . '"views" INTEGER NOT NULL DEFAULT 0,'
                . '"created" INTEGER NOT NULL,'
                . '"modified" INTEGER NOT NULL DEFAULT 0'
                . ')',
            'pgsql' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" BIGSERIAL PRIMARY KEY,'
                . '"title" VARCHAR(255) NOT NULL DEFAULT \'\','
                . '"text" TEXT NOT NULL,'
                . '"author_id" INT NOT NULL DEFAULT 0,'
                . '"author_name" VARCHAR(150) NOT NULL DEFAULT \'\','
                . '"author_mail" VARCHAR(150) NOT NULL DEFAULT \'\','
                . '"author_url" VARCHAR(255) NOT NULL DEFAULT \'\','
                . '"author_ip" VARCHAR(64) NOT NULL DEFAULT \'\','
                . '"author_agent" VARCHAR(512) NOT NULL DEFAULT \'\','
                . '"status" VARCHAR(16) NOT NULL DEFAULT \'approved\','
                . '"category_id" INT NOT NULL DEFAULT 0,'
                . '"is_locked" INT NOT NULL DEFAULT 0,'
                . '"is_pinned" INT NOT NULL DEFAULT 0,'
                . '"is_tracked" INT NOT NULL DEFAULT 0,'
                . '"is_hidden" INT NOT NULL DEFAULT 0,'
                . '"best_post_id" INT NOT NULL DEFAULT 0,'
                . '"views" INT NOT NULL DEFAULT 0,'
                . '"created" INT NOT NULL,'
                . '"modified" INT NOT NULL DEFAULT 0'
                . ')',
            default => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '`id` bigint unsigned NOT NULL auto_increment,'
                . '`title` varchar(255) NOT NULL DEFAULT \'\','
                . '`text` text NOT NULL,'
                . '`author_id` bigint unsigned NOT NULL DEFAULT 0,'
                . '`author_name` varchar(150) NOT NULL DEFAULT \'\','
                . '`author_mail` varchar(150) NOT NULL DEFAULT \'\','
                . '`author_url` varchar(255) NOT NULL DEFAULT \'\','
                . '`author_ip` varchar(64) NOT NULL DEFAULT \'\','
                . '`author_agent` varchar(512) NOT NULL DEFAULT \'\','
                . '`status` varchar(16) NOT NULL DEFAULT \'approved\','
                . '`category_id` bigint unsigned NOT NULL DEFAULT 0,'
                . '`is_locked` tinyint unsigned NOT NULL DEFAULT 0,'
                . '`is_pinned` tinyint unsigned NOT NULL DEFAULT 0,'
                . '`is_tracked` tinyint unsigned NOT NULL DEFAULT 0,'
                . '`is_hidden` tinyint unsigned NOT NULL DEFAULT 0,'
                . '`best_post_id` bigint unsigned NOT NULL DEFAULT 0,'
                . '`views` int unsigned NOT NULL DEFAULT 0,'
                . '`created` int unsigned NOT NULL,'
                . '`modified` int unsigned NOT NULL DEFAULT 0,'
                . 'PRIMARY KEY (`id`),'
                . 'KEY `' . self::index($table, 'status_created') . '` (`status`, `created`),'
                . 'KEY `' . self::index($table, 'category') . '` (`category_id`),'
                . 'KEY `' . self::index($table, 'pinned') . '` (`is_pinned`),'
                . 'KEY `' . self::index($table, 'author') . '` (`author_id`, `status`)'
                . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=' . CoreSchema::detectMysqlCollation($db),
        }, Db::WRITE);

        CoreSchema::ensureIndex($db, $table, self::index($table, 'status_created'), ['status', 'created']);
        CoreSchema::ensureIndex($db, $table, self::index($table, 'category'), ['category_id']);
        CoreSchema::ensureIndex($db, $table, self::index($table, 'pinned'), ['is_pinned']);
        CoreSchema::ensureIndex($db, $table, self::index($table, 'author'), ['author_id', 'status']);
    }

    // ------------------------------------------------------------------
    //  پاسخ‌ها
    // ------------------------------------------------------------------

    private static function ensurePosts(Db $db, string $dialect, string $table): void
    {
        $name = CoreSchema::quote($table, $dialect);

        $db->query(match ($dialect) {
            'sqlite' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" INTEGER PRIMARY KEY AUTOINCREMENT,'
                . '"topic_id" INTEGER NOT NULL,'
                . '"text" TEXT NOT NULL,'
                . '"author_id" INTEGER NOT NULL DEFAULT 0,'
                . '"author_name" TEXT NOT NULL DEFAULT \'\','
                . '"author_mail" TEXT NOT NULL DEFAULT \'\','
                . '"author_url" TEXT NOT NULL DEFAULT \'\','
                . '"author_ip" TEXT NOT NULL DEFAULT \'\','
                . '"author_agent" TEXT NOT NULL DEFAULT \'\','
                . '"status" TEXT NOT NULL DEFAULT \'approved\','
                . '"created" INTEGER NOT NULL,'
                . '"modified" INTEGER NOT NULL DEFAULT 0'
                . ')',
            'pgsql' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" BIGSERIAL PRIMARY KEY,'
                . '"topic_id" INT NOT NULL,'
                . '"text" TEXT NOT NULL,'
                . '"author_id" INT NOT NULL DEFAULT 0,'
                . '"author_name" VARCHAR(150) NOT NULL DEFAULT \'\','
                . '"author_mail" VARCHAR(150) NOT NULL DEFAULT \'\','
                . '"author_url" VARCHAR(255) NOT NULL DEFAULT \'\','
                . '"author_ip" VARCHAR(64) NOT NULL DEFAULT \'\','
                . '"author_agent" VARCHAR(512) NOT NULL DEFAULT \'\','
                . '"status" VARCHAR(16) NOT NULL DEFAULT \'approved\','
                . '"created" INT NOT NULL,'
                . '"modified" INT NOT NULL DEFAULT 0'
                . ')',
            default => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '`id` bigint unsigned NOT NULL auto_increment,'
                . '`topic_id` bigint unsigned NOT NULL,'
                . '`text` text NOT NULL,'
                . '`author_id` bigint unsigned NOT NULL DEFAULT 0,'
                . '`author_name` varchar(150) NOT NULL DEFAULT \'\','
                . '`author_mail` varchar(150) NOT NULL DEFAULT \'\','
                . '`author_url` varchar(255) NOT NULL DEFAULT \'\','
                . '`author_ip` varchar(64) NOT NULL DEFAULT \'\','
                . '`author_agent` varchar(512) NOT NULL DEFAULT \'\','
                . '`status` varchar(16) NOT NULL DEFAULT \'approved\','
                . '`created` int unsigned NOT NULL,'
                . '`modified` int unsigned NOT NULL DEFAULT 0,'
                . 'PRIMARY KEY (`id`),'
                . 'KEY `' . self::index($table, 'topic_status') . '` (`topic_id`, `status`, `created`),'
                . 'KEY `' . self::index($table, 'author') . '` (`author_id`, `status`),'
                . 'KEY `' . self::index($table, 'created') . '` (`created`)'
                . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=' . CoreSchema::detectMysqlCollation($db),
        }, Db::WRITE);

        CoreSchema::ensureIndex($db, $table, self::index($table, 'topic_status'), ['topic_id', 'status', 'created']);
        CoreSchema::ensureIndex($db, $table, self::index($table, 'author'), ['author_id', 'status']);
        CoreSchema::ensureIndex($db, $table, self::index($table, 'created'), ['created']);
    }

    // ------------------------------------------------------------------
    //  نظرسنجی‌ها و آرا
    // ------------------------------------------------------------------

    private static function ensurePolls(Db $db, string $dialect, string $table): void
    {
        $name = CoreSchema::quote($table, $dialect);

        $db->query(match ($dialect) {
            'sqlite' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"topic_id" INTEGER PRIMARY KEY,'
                . '"question" TEXT NOT NULL,'
                . '"options" TEXT NOT NULL,'
                . '"created" INTEGER NOT NULL'
                . ')',
            'pgsql' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"topic_id" INT PRIMARY KEY,'
                . '"question" VARCHAR(255) NOT NULL,'
                . '"options" TEXT NOT NULL,'
                . '"created" INT NOT NULL'
                . ')',
            default => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '`topic_id` bigint unsigned NOT NULL,'
                . '`question` varchar(255) NOT NULL,'
                . '`options` text NOT NULL,'
                . '`created` int unsigned NOT NULL,'
                . 'PRIMARY KEY (`topic_id`)'
                . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=' . CoreSchema::detectMysqlCollation($db),
        }, Db::WRITE);
    }

    private static function ensurePollVotes(Db $db, string $dialect, string $table): void
    {
        $name = CoreSchema::quote($table, $dialect);

        $db->query(match ($dialect) {
            'sqlite' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" INTEGER PRIMARY KEY AUTOINCREMENT,'
                . '"topic_id" INTEGER NOT NULL,'
                . '"option_index" INTEGER NOT NULL,'
                . '"voter_hash" TEXT NOT NULL,'
                . '"created" INTEGER NOT NULL'
                . ')',
            'pgsql' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" BIGSERIAL PRIMARY KEY,'
                . '"topic_id" INT NOT NULL,'
                . '"option_index" INT NOT NULL,'
                . '"voter_hash" CHAR(64) NOT NULL,'
                . '"created" INT NOT NULL'
                . ')',
            default => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '`id` bigint unsigned NOT NULL auto_increment,'
                . '`topic_id` bigint unsigned NOT NULL,'
                . '`option_index` int unsigned NOT NULL,'
                . '`voter_hash` char(64) NOT NULL,'
                . '`created` int unsigned NOT NULL,'
                . 'PRIMARY KEY (`id`),'
                . 'KEY `' . self::index($table, 'topic') . '` (`topic_id`)'
                . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=' . CoreSchema::detectMysqlCollation($db),
        }, Db::WRITE);

        CoreSchema::ensureIndex($db, $table, self::index($table, 'topic'), ['topic_id']);
        CoreSchema::ensureIndex($db, $table, self::index($table, 'uniq_voter'), ['topic_id', 'voter_hash'], true);
    }

    // ------------------------------------------------------------------
    //  اعلان‌ها
    // ------------------------------------------------------------------

    private static function ensureNotifications(Db $db, string $dialect, string $table): void
    {
        $name = CoreSchema::quote($table, $dialect);

        $db->query(match ($dialect) {
            'sqlite' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" INTEGER PRIMARY KEY AUTOINCREMENT,'
                . '"uid" INTEGER NOT NULL,'
                . '"type" TEXT NOT NULL,'
                . '"topic_id" INTEGER NOT NULL DEFAULT 0,'
                . '"item_id" INTEGER NOT NULL DEFAULT 0,'
                . '"is_read" INTEGER NOT NULL DEFAULT 0,'
                . '"created" INTEGER NOT NULL'
                . ')',
            'pgsql' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" BIGSERIAL PRIMARY KEY,'
                . '"uid" INT NOT NULL,'
                . '"type" VARCHAR(20) NOT NULL,'
                . '"topic_id" INT NOT NULL DEFAULT 0,'
                . '"item_id" INT NOT NULL DEFAULT 0,'
                . '"is_read" INT NOT NULL DEFAULT 0,'
                . '"created" INT NOT NULL'
                . ')',
            default => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '`id` bigint unsigned NOT NULL auto_increment,'
                . '`uid` bigint unsigned NOT NULL,'
                . '`type` varchar(20) NOT NULL,'
                . '`topic_id` bigint unsigned NOT NULL DEFAULT 0,'
                . '`item_id` bigint unsigned NOT NULL DEFAULT 0,'
                . '`is_read` tinyint unsigned NOT NULL DEFAULT 0,'
                . '`created` int unsigned NOT NULL,'
                . 'PRIMARY KEY (`id`),'
                . 'KEY `' . self::index($table, 'uid_read') . '` (`uid`, `is_read`)'
                . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=' . CoreSchema::detectMysqlCollation($db),
        }, Db::WRITE);

        CoreSchema::ensureIndex($db, $table, self::index($table, 'uid_read'), ['uid', 'is_read']);
    }

    // ------------------------------------------------------------------
    //  گزارش‌های تخلف
    // ------------------------------------------------------------------

    private static function ensureFlags(Db $db, string $dialect, string $table): void
    {
        $name = CoreSchema::quote($table, $dialect);

        $db->query(match ($dialect) {
            'sqlite' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" INTEGER PRIMARY KEY AUTOINCREMENT,'
                . '"item_type" TEXT NOT NULL,'
                . '"item_id" INTEGER NOT NULL,'
                . '"reporter_hash" TEXT NOT NULL,'
                . '"reason" TEXT NOT NULL DEFAULT \'\','
                . '"created" INTEGER NOT NULL'
                . ')',
            'pgsql' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" BIGSERIAL PRIMARY KEY,'
                . '"item_type" VARCHAR(10) NOT NULL,'
                . '"item_id" INT NOT NULL,'
                . '"reporter_hash" VARCHAR(80) NOT NULL,'
                . '"reason" VARCHAR(160) NOT NULL DEFAULT \'\','
                . '"created" INT NOT NULL'
                . ')',
            default => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '`id` bigint unsigned NOT NULL auto_increment,'
                . '`item_type` varchar(10) NOT NULL,'
                . '`item_id` bigint unsigned NOT NULL,'
                . '`reporter_hash` varchar(80) NOT NULL,'
                . '`reason` varchar(160) NOT NULL DEFAULT \'\','
                . '`created` int unsigned NOT NULL,'
                . 'PRIMARY KEY (`id`),'
                . 'KEY `' . self::index($table, 'item') . '` (`item_type`, `item_id`)'
                . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=' . CoreSchema::detectMysqlCollation($db),
        }, Db::WRITE);

        CoreSchema::ensureIndex($db, $table, self::index($table, 'item'), ['item_type', 'item_id']);
        CoreSchema::ensureIndex($db, $table, self::index($table, 'uniq_report'), ['item_type', 'item_id', 'reporter_hash'], true);

        // ۲.۲.۰ — مهاجرت ستون reason برای نصب‌های قدیمی
        self::ensureFlagReasonColumn($db, $dialect, $table);
    }

    /**
     * ۲.۲.۰ — افزودن ستون reason به جدول forum_flags موجود (idempotent)
     *
     * نصب‌های قدیمی این ستون را ندارند؛ CREATE TABLE IF NOT EXISTS
     * ستون تازه را اضافه نمی‌کند. این مهاجرت با columnExists هسته
     * بررسی و در نبودِ ستون، ALTER TABLE اجرا می‌کند.
     */
    private static function ensureFlagReasonColumn(Db $db, string $dialect, string $table): void
    {
        try {
            if (CoreSchema::columnExists($db, $table, 'reason')) {
                return;
            }
        } catch (\Throwable $e) {
            return; // جدول هنوز ساخته نشده — CREATE TABLE بالا کافی است
        }

        $name = CoreSchema::quote($table, $dialect);
        $col = match ($dialect) {
            'pgsql'   => 'ADD COLUMN "reason" VARCHAR(160) NOT NULL DEFAULT \'\'',
            'sqlite'  => 'ADD COLUMN "reason" VARCHAR(160) NOT NULL DEFAULT \'\'',
            default   => 'ADD COLUMN `reason` varchar(160) NOT NULL DEFAULT \'\'',
        };

        try {
            $db->query('ALTER TABLE ' . $name . ' ' . $col, Db::WRITE);
        } catch (\Throwable $e) {
            // ستون شاید هم‌اکنون توسط نصب موازی اضافه شده باشد
        }
    }

    // ------------------------------------------------------------------
    //  پسندها (لایک) — ۲.۰.۰
    // ------------------------------------------------------------------

    private static function ensureLikes(Db $db, string $dialect, string $table): void
    {
        $name = CoreSchema::quote($table, $dialect);

        $db->query(match ($dialect) {
            'sqlite' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" INTEGER PRIMARY KEY AUTOINCREMENT,'
                . '"item_type" TEXT NOT NULL,'
                . '"item_id" INTEGER NOT NULL,'
                . '"voter_hash" TEXT NOT NULL,'
                . '"created" INTEGER NOT NULL'
                . ')',
            'pgsql' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" BIGSERIAL PRIMARY KEY,'
                . '"item_type" VARCHAR(10) NOT NULL,'
                . '"item_id" INT NOT NULL,'
                . '"voter_hash" CHAR(64) NOT NULL,'
                . '"created" INT NOT NULL'
                . ')',
            default => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '`id` bigint unsigned NOT NULL auto_increment,'
                . '`item_type` varchar(10) NOT NULL,'
                . '`item_id` bigint unsigned NOT NULL,'
                . '`voter_hash` char(64) NOT NULL,'
                . '`created` int unsigned NOT NULL,'
                . 'PRIMARY KEY (`id`),'
                . 'KEY `' . self::index($table, 'item') . '` (`item_type`, `item_id`)'
                . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=' . CoreSchema::detectMysqlCollation($db),
        }, Db::WRITE);

        CoreSchema::ensureIndex($db, $table, self::index($table, 'item'), ['item_type', 'item_id']);
        CoreSchema::ensureIndex($db, $table, self::index($table, 'uniq_voter'), ['item_type', 'item_id', 'voter_hash'], true);
    }

    // ------------------------------------------------------------------
    //  پیام‌های خصوصی — ۲.۱.۰
    // ------------------------------------------------------------------

    private static function ensureMessages(Db $db, string $dialect, string $table): void
    {
        $name = CoreSchema::quote($table, $dialect);

        $db->query(match ($dialect) {
            'sqlite' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" INTEGER PRIMARY KEY AUTOINCREMENT,'
                . '"sender_id" INTEGER NOT NULL,'
                . '"recipient_id" INTEGER NOT NULL,'
                . '"subject" TEXT NOT NULL DEFAULT \'\','
                . '"body" TEXT NOT NULL,'
                . '"is_read" INTEGER NOT NULL DEFAULT 0,'
                . '"deleted_by_sender" INTEGER NOT NULL DEFAULT 0,'
                . '"deleted_by_recipient" INTEGER NOT NULL DEFAULT 0,'
                . '"created" INTEGER NOT NULL,'
                . '"read_at" INTEGER NOT NULL DEFAULT 0'
                . ')',
            'pgsql' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" BIGSERIAL PRIMARY KEY,'
                . '"sender_id" INT NOT NULL,'
                . '"recipient_id" INT NOT NULL,'
                . '"subject" VARCHAR(255) NOT NULL DEFAULT \'\','
                . '"body" TEXT NOT NULL,'
                . '"is_read" INT NOT NULL DEFAULT 0,'
                . '"deleted_by_sender" INT NOT NULL DEFAULT 0,'
                . '"deleted_by_recipient" INT NOT NULL DEFAULT 0,'
                . '"created" INT NOT NULL,'
                . '"read_at" INT NOT NULL DEFAULT 0'
                . ')',
            default => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '`id` bigint unsigned NOT NULL auto_increment,'
                . '`sender_id` bigint unsigned NOT NULL,'
                . '`recipient_id` bigint unsigned NOT NULL,'
                . '`subject` varchar(255) NOT NULL DEFAULT \'\','
                . '`body` text NOT NULL,'
                . '`is_read` tinyint unsigned NOT NULL DEFAULT 0,'
                . '`deleted_by_sender` tinyint unsigned NOT NULL DEFAULT 0,'
                . '`deleted_by_recipient` tinyint unsigned NOT NULL DEFAULT 0,'
                . '`created` int unsigned NOT NULL,'
                . '`read_at` int unsigned NOT NULL DEFAULT 0,'
                . 'PRIMARY KEY (`id`),'
                . 'KEY `' . self::index($table, 'recipient') . '` (`recipient_id`, `deleted_by_recipient`, `created`),'
                . 'KEY `' . self::index($table, 'sender') . '` (`sender_id`, `deleted_by_sender`, `created`)'
                . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=' . CoreSchema::detectMysqlCollation($db),
        }, Db::WRITE);

        CoreSchema::ensureIndex($db, $table, self::index($table, 'recipient'), ['recipient_id', 'deleted_by_recipient', 'created']);
        CoreSchema::ensureIndex($db, $table, self::index($table, 'sender'), ['sender_id', 'deleted_by_sender', 'created']);
    }

    // ------------------------------------------------------------------
    //  بلاک‌ها — ۲.۱.۰
    // ------------------------------------------------------------------

    private static function ensureBlocks(Db $db, string $dialect, string $table): void
    {
        $name = CoreSchema::quote($table, $dialect);

        $db->query(match ($dialect) {
            'sqlite' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" INTEGER PRIMARY KEY AUTOINCREMENT,'
                . '"user_id" INTEGER NOT NULL,'
                . '"blocked_id" INTEGER NOT NULL,'
                . '"created" INTEGER NOT NULL'
                . ')',
            'pgsql' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" BIGSERIAL PRIMARY KEY,'
                . '"user_id" INT NOT NULL,'
                . '"blocked_id" INT NOT NULL,'
                . '"created" INT NOT NULL'
                . ')',
            default => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '`id` bigint unsigned NOT NULL auto_increment,'
                . '`user_id` bigint unsigned NOT NULL,'
                . '`blocked_id` bigint unsigned NOT NULL,'
                . '`created` int unsigned NOT NULL,'
                . 'PRIMARY KEY (`id`),'
                . 'KEY `' . self::index($table, 'user') . '` (`user_id`, `blocked_id`)'
                . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=' . CoreSchema::detectMysqlCollation($db),
        }, Db::WRITE);

        CoreSchema::ensureIndex($db, $table, self::index($table, 'user'), ['user_id', 'blocked_id']);
        CoreSchema::ensureIndex($db, $table, self::index($table, 'uniq_block'), ['user_id', 'blocked_id'], true);
    }

    // ------------------------------------------------------------------
    //  بلاک اداری کاربران — ۲.۲.۰ (موقت یا همیشه)
    // ------------------------------------------------------------------

    private static function ensureBans(Db $db, string $dialect, string $table): void
    {
        $name = CoreSchema::quote($table, $dialect);

        $db->query(match ($dialect) {
            'sqlite' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" INTEGER PRIMARY KEY AUTOINCREMENT,'
                . '"uid" INTEGER NOT NULL,'
                . '"until" INTEGER NOT NULL DEFAULT 0,'
                . '"reason" TEXT NOT NULL DEFAULT \'\','
                . '"banned_by" INTEGER NOT NULL DEFAULT 0,'
                . '"created" INTEGER NOT NULL'
                . ')',
            'pgsql' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" BIGSERIAL PRIMARY KEY,'
                . '"uid" INT NOT NULL,'
                . '"until" INT NOT NULL DEFAULT 0,'
                . '"reason" VARCHAR(255) NOT NULL DEFAULT \'\','
                . '"banned_by" INT NOT NULL DEFAULT 0,'
                . '"created" INT NOT NULL'
                . ')',
            default => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '`id` bigint unsigned NOT NULL auto_increment,'
                . '`uid` bigint unsigned NOT NULL,'
                . '`until` int unsigned NOT NULL DEFAULT 0,'
                . '`reason` varchar(255) NOT NULL DEFAULT \'\','
                . '`banned_by` bigint unsigned NOT NULL DEFAULT 0,'
                . '`created` int unsigned NOT NULL,'
                . 'PRIMARY KEY (`id`),'
                . 'KEY `' . self::index($table, 'uid') . '` (`uid`, `until`)'
                . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=' . CoreSchema::detectMysqlCollation($db),
        }, Db::WRITE);

        CoreSchema::ensureIndex($db, $table, self::index($table, 'uid'), ['uid', 'until']);
    }

    // ------------------------------------------------------------------
    //  ابزار مهاجرت
    // ------------------------------------------------------------------

    /**
     * پس از درج ردیف‌های با شناسهٔ صریح (ایمپورت)، دنبالهٔ خودافزایش
     * PostgreSQL را به بیشینهٔ فعلی می‌رساند. MySQL و SQLite خودکار
     * همگام می‌شوند.
     */
    public static function syncSequences(): void
    {
        try {
            $db = Db::get();
            if (CoreSchema::dialect($db) !== 'pgsql') {
                return;
            }
            $prefix = $db->getPrefix();
            foreach (['forum_categories', 'forum_topics', 'forum_posts', 'forum_notifications', 'forum_flags', 'forum_likes', 'forum_messages', 'forum_blocks', 'forum_bans'] as $t) {
                $table = $prefix . $t;
                $db->query(
                    'SELECT setval(pg_get_serial_sequence(\'' . $table . '\', \'id\'), '
                    . 'COALESCE((SELECT MAX(id) FROM ' . $table . '), 0) + 1, false)'
                );
            }
        } catch (\Throwable $e) {
            // بدون همگام‌سازی هم درج‌های صریح کار می‌کنند؛ فقط شناسهٔ بعدی ممکن است تداخل کند
        }
    }
}
