<?php

namespace TypechoPlugin\Forum;

use Typecho\Db;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Import
{
    /**
     * اجرای ایمپورت در صورت وجود دادهٔ قدیمی (یک‌بار — idempotent).
     * برمی‌گرداند پیام نتیجه (یا رشتهٔ خالی اگر کاری نبود).
     */
    public static function runIfLegacy(): string
    {
        try {
            if (self::alreadyDone()) {
                return '';
            }
            $legacy = self::legacyForumPost();
            if ($legacy === null) {
                // نصب تازه است — فقط نشانه را بنویس
                self::markDone(['fresh' => true, 'time' => time()]);
                return '';
            }
            $stats = self::run($legacy);
            return $stats;
        } catch (\Throwable $e) {
            return 'هشدار: ایمپورت خودکار از سیستم قدیمی با خطا متوقف شد («'
                . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8')
                . '»). می‌توانید از پنل مدیریت انجمن، تب «ابزارها»، دوباره اجرا کنید.'
                . ' [اجرا با کد افزونهٔ ' . Plugin::VERSION . ']';
        }
    }

    /** آیا ایمپورت قبلاً انجام شده؟ */
    public static function alreadyDone(): bool
    {
        return Plugin::readOptionValue(Plugin::IMPORTED_OPTION) !== '';
    }

    /** خواندن شمارش ایمپورت */
    public static function stats(): array
    {
        $raw = Plugin::readOptionValue(Plugin::IMPORT_STATS_OPTION);
        if ($raw === '') {
            return [];
        }
        $decoded = json_decode($raw, true);
        return is_array($decoded) ? $decoded : [];
    }

    /** نوشتن نشانهٔ انجام + شمارش */
    private static function markDone(array $stats): void
    {
        Plugin::writeOptionValue(Plugin::IMPORTED_OPTION, (string) time());
        Plugin::writeOptionValue(Plugin::IMPORT_STATS_OPTION, json_encode($stats, JSON_UNESCAPED_UNICODE));
    }

    /**
     * نوشتهٔ پشتیبان انجمن قدیمی (یا null اگر هرگز نسخهٔ ۱.x فعال نبوده).
     */
    public static function legacyForumPost(): ?array
    {
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('cid', 'authorId', 'allowComment')
                    ->from('table.contents')
                    ->where('slug = ? AND type = ?', 'forum-archive', 'post')
                    ->limit(1)
            );
            return $row ?: null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * خواندن دسته‌های قدیمی با پارس مقاوم (۲.۰.۴).
     *
     * چند نام ردیف را امتحان می‌کند (ext:Forum-categories استاندارد v1.5+
     * و نام‌های جایگزین) و قالب‌های سریالایز PHP، JSON، سریالایزِ
     * html-escaped و سریالایزِ slash-اضافه‌شده را می‌فهمد. ساختارهای
     * قدیمی «id => نام» و «کلید = شناسه» هم پذیرفته می‌شوند.
     *
     * برمی‌گرداند: ['source' => نام ردیف یا '', 'row_exists' => bool,
     * 'raw_len' => int, 'format' => توضیح قالب, 'cats' => فهرست نرمال‌شده]
     */
    public static function legacyCategoriesInfo(): array
    {
        $info = [
            'source'     => '',
            'row_exists' => false,
            'raw_len'    => 0,
            'format'     => 'none',
            'cats'       => [],
        ];

        try {
            $db = Db::get();
            $names = ['ext:Forum-categories', 'ext:Forum-category', 'ext:Forum-cats'];

            // اسکان مستقیم — همهٔ ردیف‌های «ext:Forum-cat%» را یک‌جا بگیر
            // (تا اگر نام ردیف با نسخهٔ قدیمی فرق داشت هم پیدا شود)
            $rows = $db->fetchAll(
                $db->select('name', 'value')->from('table.options')
                    ->where('name LIKE ?', 'ext:Forum-cat%')
            );
            $byName = [];
            foreach ($rows as $r) {
                $byName[(string) $r['name']] = (string) $r['value'];
            }

            $raw = '';
            $source = '';
            foreach ($names as $n) {
                if (isset($byName[$n])) {
                    $raw = $byName[$n];
                    $source = $n;
                    break;
                }
            }
            // نام استاندارد نبود؟ اولین ردیف پُرِ همین خانواده را بگیر
            if ($source === '') {
                foreach ($byName as $n => $v) {
                    if (trim($v) !== '') {
                        $raw = $v;
                        $source = $n;
                        break;
                    }
                }
            }
            if ($source === '') {
                return $info;
            }

            $info['source'] = $source;
            $info['row_exists'] = true;
            $info['raw_len'] = strlen($raw);
            if (trim($raw) === '') {
                $info['format'] = 'empty';
                return $info;
            }

            // کاندیداهای بازیابی — قالب اصلی، سپس رمزگشایی‌های رایج خرابی
            $candidates = [['format' => 'serialize', 'value' => $raw]];
            $unescaped = htmlspecialchars_decode($raw, ENT_QUOTES);
            if ($unescaped !== $raw) {
                $candidates[] = ['format' => 'unescape+serialize', 'value' => $unescaped];
            }
            $stripped = stripslashes($raw);
            if ($stripped !== $raw) {
                $candidates[] = ['format' => 'stripslashes+serialize', 'value' => $stripped];
            }

            $decoded = null;
            $format = 'unknown';
            foreach ($candidates as $c) {
                $try = @unserialize($c['value']);
                if (is_array($try)) {
                    $decoded = $try;
                    $format = $c['format'];
                    break;
                }
                $try = json_decode($c['value'], true);
                if (is_array($try)) {
                    $decoded = $try;
                    $format = str_replace('serialize', 'json', $c['format']);
                    break;
                }
            }

            if (is_array($decoded)) {
                $seen = [];
                foreach ($decoded as $k => $cat) {
                    $entry = null;
                    if (is_array($cat)) {
                        $id = isset($cat['id']) ? (int) $cat['id'] : (is_numeric($k) ? (int) $k : 0);
                        $name = isset($cat['name']) ? trim((string) $cat['name']) : '';
                        if ($id > 0 && $name !== '') {
                            $entry = [
                                'id'       => $id,
                                'name'     => mb_substr($name, 0, 80),
                                'slug'     => trim((string) ($cat['slug'] ?? '')),
                                'icon'     => trim((string) ($cat['icon'] ?? '')),
                                'color'    => trim((string) ($cat['color'] ?? '')),
                                'parentId' => max(0, (int) ($cat['parentId'] ?? 0)),
                                'order'    => max(0, (int) ($cat['order'] ?? 0)),
                            ];
                        }
                    } elseif (is_string($cat) && trim($cat) !== '' && is_numeric($k)) {
                        // قالب قدیمی‌تر: [شناسه => نام]
                        $entry = [
                            'id'       => (int) $k,
                            'name'     => mb_substr(trim($cat), 0, 80),
                            'slug'     => '',
                            'icon'     => '',
                            'color'    => '',
                            'parentId' => 0,
                            'order'    => 0,
                        ];
                    }
                    if ($entry !== null && !isset($seen[$entry['id']])) {
                        $seen[$entry['id']] = true;
                        $info['cats'][] = $entry;
                    }
                }
                $info['format'] = $format;
            }
        } catch (\Throwable $e) {
            $info['format'] = 'error';
        }

        return $info;
    }

    /**
     * گزارش تشخیصی سیستم قدیمی — فقط خواندن، بدون هیچ تغییری (۲.۰.۴).
     *
     * برای نمایش در تب «ابزارها»: چه داده‌ای در سیستم قدیمی پیدا می‌شود؟
     * اگر دسته‌ها پیدا نمی‌شوند، همین گزارش علت را مشخص می‌کند.
     */
    public static function legacySummary(): array
    {
        $out = [
            'has_post'      => false,
            'questions'     => 0,
            'answers'       => 0,
            'cats'          => [],
            'cats_source'   => '',
            'cats_format'   => 'none',
            'cats_raw_len'  => 0,
            'topic_cats'    => 0,
            'polls'         => 0,
            'notifications' => 0,
            'flags'         => 0,
        ];

        try {
            $legacy = self::legacyForumPost();
            if ($legacy === null) {
                return $out;
            }
            $out['has_post'] = true;

            $db = Db::get();
            $cid = (int) $legacy['cid'];

            $row = $db->fetchRow(
                $db->select(['COUNT(coid)' => 'n'])->from('table.comments')
                    ->where('cid = ? AND parent = 0 AND type = ?', $cid, 'comment')
            );
            $out['questions'] = (int) ($row['n'] ?? 0);

            $row = $db->fetchRow(
                $db->select(['COUNT(coid)' => 'n'])->from('table.comments')
                    ->where('cid = ? AND parent > 0 AND type = ?', $cid, 'comment')
            );
            $out['answers'] = (int) ($row['n'] ?? 0);

            $catInfo = self::legacyCategoriesInfo();
            $out['cats'] = $catInfo['cats'];
            $out['cats_source'] = $catInfo['source'];
            $out['cats_format'] = $catInfo['format'];
            $out['cats_raw_len'] = $catInfo['raw_len'];

            $out['topic_cats'] = count(self::pairMap('ext:Forum-topic-cats'));

            $pollRows = $db->fetchAll(
                $db->select('name')->from('table.options')->where('name LIKE ?', 'ext:Forum-poll-%')
            );
            foreach ($pollRows as $pr) {
                if (str_starts_with((string) $pr['name'], 'ext:Forum-poll-')) {
                    $out['polls']++;
                }
            }

            $raw = Plugin::readOptionValue('ext:Forum-notifications');
            $out['notifications'] = $raw === ''
                ? 0
                : count(array_filter(explode(';', $raw), static fn ($x) => trim($x) !== ''));

            $raw = Plugin::readOptionValue('ext:Forum-flags');
            $out['flags'] = $raw === ''
                ? 0
                : count(array_filter(explode(';', $raw), static fn ($x) => trim($x) !== ''));
        } catch (\Throwable $e) {
            // خروجی تا جایی که خوانده شد
        }

        return $out;
    }

    /**
     * اجرای کامل ایمپورت. برمی‌گرداند پیام نتیجهٔ فارسی.
     */
    public static function run(?array $legacy = null): string
    {
        $db = Db::get();
        $legacy = $legacy ?? self::legacyForumPost();
        if ($legacy === null) {
            self::markDone(['fresh' => true, 'time' => time()]);
            return '';
        }

        $cid = (int) $legacy['cid'];

        // مالک انجمن قدیمی → تنظیم مالک نسخهٔ ۲
        $legacyOwner = (int) ($legacy['authorId'] ?? 0);
        if ($legacyOwner > 0 && Plugin::ownerUid() < 1) {
            Plugin::writeOptionValue(Plugin::OWNER_OPTION, (string) $legacyOwner);
        }

        Schema::ensure();

        $stats = [
            'topics' => 0,
            'posts' => 0,
            'categories' => 0,
            'cats_found' => 0,
            'categories_linked' => 0,
            'category_backfill' => 0,
            'polls' => 0,
            'poll_votes' => 0,
            'notifications' => 0,
            'flags' => 0,
            'time' => time(),
        ];

        /** نگاشت «شناسهٔ دستهٔ قدیم → شناسهٔ دستهٔ جدید» (در صورت تعارض/ادغام) */
        $catRemap = [];

        // ------------------------------------------------------------------
        // ۱) دسته‌بندی‌ها — از options به جدول forum_categories
        //
        // مقاوم‌سازی ۲.۰.۴: خواندن از چند نام ردیف ممکن، پارس چند قالب
        // (سریالایز PHP، JSON، سریالایزِ درانتقال خراب‌شده) و پذیرش دو
        // ساختار قدیمی. تعارض شناسه یا نام هم‌زمان حل می‌شود:
        //  - دستهٔ هم‌نام → اتصال به ردیف موجود (بدون تکرار) + نگاشت
        //  - تعارض شناسه با نام متفاوت → درج با شناسهٔ تازه + نگاشت
        //  - درج عادی با حفظ شناسهٔ قدیمی
        // نگاشت «شناسهٔ قدیم → شناسهٔ جدید» روی انتساب پرسش‌ها و بخش
        // تکمیل (۲.۵) اعمال می‌شود.
        // ------------------------------------------------------------------
        $catInfo = self::legacyCategoriesInfo();
        $stats['cats_found'] = count($catInfo['cats']);
        $catDetail = [];

        if (!empty($catInfo['cats'])) {
            // فهرست دسته‌های فعلی جدول جدید (id => name)
            $existingCats = [];
            {
                $rows = $db->fetchAll($db->select('id', 'name')->from('table.forum_categories'));
                foreach ($rows as $r) {
                    $existingCats[(int) $r['id']] = trim((string) $r['name']);
                }
            }
            $existingByName = array_flip($existingCats); // name => id

            foreach ($catInfo['cats'] as $cat) {
                $oldId = (int) $cat['id'];
                $name = (string) $cat['name'];
                if ($name === '' || isset($catRemap[$oldId])) {
                    continue;
                }

                $icon = Plugin::isValidCategoryIcon((string) $cat['icon']) ? (string) $cat['icon'] : '';
                $color = preg_match('~^#[0-9a-fA-F]{6}$~', (string) $cat['color'])
                    ? (string) $cat['color'] : '';

                if (isset($existingByName[$name])) {
                    // دستهٔ هم‌نام از قبل هست — فقط نگاشت (بدون تکرار)
                    $catRemap[$oldId] = (int) $existingByName[$name];
                    $stats['categories_linked']++;
                    $catDetail[] = '«' . $name . '» به دستهٔ موجود متصل شد';
                    continue;
                }

                if (isset($existingCats[$oldId])) {
                    // تعارض شناسه: ردیفی با این id هست اما نامش فرق دارد —
                    // درج با شناسهٔ تازه (خروجی query برای INSERT همان
                    // شناسهٔ تازه است — متد جداگانه‌ای در هسته نیست)
                    $newId = (int) $db->query(
                        $db->insert('table.forum_categories')->rows([
                            'name'       => $name,
                            'slug'       => mb_substr(trim((string) ($cat['slug'] ?? '')), 0, 80),
                            'icon'       => $icon,
                            'color'      => $color,
                            'parent_id'  => max(0, (int) $cat['parentId']),
                            'sort_order' => max(0, (int) $cat['order']),
                            'created'    => time(),
                        ])
                    );
                    if ($newId < 1) {
                        // پشتیبان: خواندن بزرگترین شناسه
                        $r = $db->fetchRow($db->select(['MAX(id)' => 'm'])->from('table.forum_categories'));
                        $newId = (int) ($r['m'] ?? 0);
                    }
                    $catRemap[$oldId] = $newId;
                    $existingCats[$newId] = $name;
                    $existingByName[$name] = $newId;
                    $stats['categories']++;
                    $catDetail[] = '«' . $name . '» با شناسهٔ تازه درج شد (تعارض شناسه)';
                    continue;
                }

                // درج عادی با حفظ شناسهٔ قدیمی
                $db->query(
                    $db->insert('table.forum_categories')->rows([
                        'id'         => $oldId,
                        'name'       => $name,
                        'slug'       => mb_substr(trim((string) ($cat['slug'] ?? '')), 0, 80),
                        'icon'       => $icon,
                        'color'      => $color,
                        'parent_id'  => max(0, (int) $cat['parentId']),
                        'sort_order' => max(0, (int) $cat['order']),
                        'created'    => time(),
                    ])
                );
                $catRemap[$oldId] = $oldId;
                $existingCats[$oldId] = $name;
                $existingByName[$name] = $oldId;
                $stats['categories']++;
                $catDetail[] = '«' . $name . '» درج شد';
            }
        }

        // نگاشت‌های وضعیت قدیمی
        $lockedIds = self::idList('ext:Forum-locks');
        $pinnedIds = self::idList('ext:Forum-pins');
        $trackedIds = self::idList('ext:Forum-tracks');
        $hiddenIds = self::idList('ext:Forum-hidden');
        $topicCats = self::pairMap('ext:Forum-topic-cats');  // coid => catId
        $bestMap = self::pairMap('ext:Forum-best');           // qCoid => aCoid

        // اعمال نگاشت دسته‌ها روی انتساب‌های قدیمی پرسش‌ها
        $remapCat = static function (int $catId) use ($catRemap): int {
            return $catId > 0 ? (int) ($catRemap[$catId] ?? 0) : 0;
        };

        // ------------------------------------------------------------------
        // ۲) پرسش‌ها — comments(parent=0) → forum_topics (حفظ شناسه)
        // ------------------------------------------------------------------
        $questionRows = $db->fetchAll(
            $db->select()->from('table.comments')
                ->where('cid = ? AND parent = 0 AND type = ?', $cid, 'comment')
                ->order('coid', Db::SORT_ASC)
        );

        $existingTopicIds = [];
        {
            $rows = $db->fetchAll($db->select('id')->from('table.forum_topics'));
            foreach ($rows as $r) {
                $existingTopicIds[(int) $r['id']] = true;
            }
        }

        foreach ($questionRows as $q) {
            $coid = (int) $q['coid'];
            if (isset($existingTopicIds[$coid])) {
                continue; // قبلاً منتقل شده
            }

            [$title] = Plugin::splitQuestion((string) $q['text']);

            $db->query(
                $db->insert('table.forum_topics')->rows([
                    'id'           => $coid,
                    'title'        => mb_substr(Plugin::stripMarkup($title), 0, 250),
                    'text'         => (string) $q['text'],
                    'author_id'    => (int) ($q['authorId'] ?? 0),
                    'author_name'  => (string) ($q['author'] ?? ''),
                    'author_mail'  => (string) ($q['mail'] ?? ''),
                    'author_url'   => (string) ($q['url'] ?? ''),
                    'author_ip'    => (string) ($q['ip'] ?? ''),
                    'author_agent' => (string) ($q['agent'] ?? ''),
                    'status'       => self::normalizeStatus((string) ($q['status'] ?? 'approved')),
                    'category_id'  => $remapCat((int) ($topicCats[$coid] ?? 0)),
                    'is_locked'    => in_array($coid, $lockedIds, true) ? 1 : 0,
                    'is_pinned'    => in_array($coid, $pinnedIds, true) ? 1 : 0,
                    'is_tracked'   => in_array($coid, $trackedIds, true) ? 1 : 0,
                    'is_hidden'    => in_array($coid, $hiddenIds, true) ? 1 : 0,
                    'best_post_id' => (int) ($bestMap[$coid] ?? 0),
                    'views'        => (int) ($q['views'] ?? 0),
                    'created'      => (int) ($q['created'] ?? time()),
                    'modified'     => (int) ($q['created'] ?? time()),
                ])
            );
            $stats['topics']++;
        }

        // ------------------------------------------------------------------
        // ۲.۵) تکمیل دستهٔ پرسش‌های موجود — اگر پرسشی قبلاً بدون دسته
        // ایمپورت شده باشد و نگاشت قدیمی برایش دسته‌ای داشته باشد،
        // همان را (با نگاشت شناسهٔ درست) به‌روز کن.
        // ------------------------------------------------------------------
        if (!empty($topicCats)) {
            foreach ($topicCats as $oldCoid => $oldCatId) {
                $topicId = (int) $oldCoid;
                $newCatId = $remapCat((int) $oldCatId);
                if ($topicId < 1 || $newCatId < 1) {
                    continue;
                }
                $row = $db->fetchRow(
                    $db->select('id', 'category_id')->from('table.forum_topics')
                        ->where('id = ?', $topicId)->limit(1)
                );
                if ($row === null || (int) $row['category_id'] === $newCatId) {
                    continue;
                }
                // فقط وقتی به‌روز کن که دستهٔ فعلی «بدون دسته» است یا به دستهٔ
                // حذف‌شده اشاره دارد؛ دستهٔ تنظیم‌شدهٔ دستی مدیر را نمی‌بندد.
                $currentCat = (int) $row['category_id'];
                $catStillExists = $currentCat > 0
                    && $db->fetchRow(
                        $db->select('id')->from('table.forum_categories')
                            ->where('id = ?', $currentCat)->limit(1)
                    ) !== null;
                if ($currentCat > 0 && $catStillExists) {
                    continue;
                }
                $db->query(
                    $db->update('table.forum_topics')
                        ->rows(['category_id' => $newCatId])
                        ->where('id = ?', $topicId)
                );
                $stats['category_backfill']++;
            }
        }

        // ------------------------------------------------------------------
        // ۳) پاسخ‌ها — comments(parent>0) → forum_posts (حفظ شناسه)
        // ------------------------------------------------------------------
        $answerRows = $db->fetchAll(
            $db->select()->from('table.comments')
                ->where('cid = ? AND parent > 0 AND type = ?', $cid, 'comment')
                ->order('coid', Db::SORT_ASC)
        );

        $existingPostIds = [];
        {
            $rows = $db->fetchAll($db->select('id')->from('table.forum_posts'));
            foreach ($rows as $r) {
                $existingPostIds[(int) $r['id']] = true;
            }
        }

        foreach ($answerRows as $a) {
            $coid = (int) $a['coid'];
            if (isset($existingPostIds[$coid])) {
                continue; // قبلاً منتقل شده
            }

            $db->query(
                $db->insert('table.forum_posts')->rows([
                    'id'           => $coid,
                    'topic_id'     => (int) $a['parent'],
                    'text'         => (string) $a['text'],
                    'author_id'    => (int) ($a['authorId'] ?? 0),
                    'author_name'  => (string) ($a['author'] ?? ''),
                    'author_mail'  => (string) ($a['mail'] ?? ''),
                    'author_url'   => (string) ($a['url'] ?? ''),
                    'author_ip'    => (string) ($a['ip'] ?? ''),
                    'author_agent' => (string) ($a['agent'] ?? ''),
                    'status'       => self::normalizeStatus((string) ($a['status'] ?? 'approved')),
                    'created'      => (int) ($a['created'] ?? time()),
                    'modified'     => (int) ($a['created'] ?? time()),
                ])
            );
            $stats['posts']++;
        }

        // ------------------------------------------------------------------
        // ۴) نظرسنجی‌ها و آرا — ext:Forum-poll-* → جداول
        // ------------------------------------------------------------------
        $pollRows = $db->fetchAll(
            $db->select('name', 'value')->from('table.options')
                ->where('name LIKE ?', 'ext:Forum-poll-%')
        );
        foreach ($pollRows as $pr) {
            $name = (string) $pr['name'];
            $value = (string) $pr['value'];
            if (str_starts_with($name, 'ext:Forum-pollvotes-')) {
                // آرا: «idx:count;…»
                $topicId = (int) substr($name, strlen('ext:Forum-pollvotes-'));
                if ($topicId < 1 || $value === '') {
                    continue;
                }
                foreach (explode(';', $value) as $pair) {
                    $pair = trim($pair);
                    if ($pair === '' || !str_contains($pair, ':')) {
                        continue;
                    }
                    [$idx, $count] = explode(':', $pair, 2);
                    if (!ctype_digit($idx) || !ctype_digit($count)) {
                        continue;
                    }
                    for ($i = 0; $i < (int) $count; $i++) {
                        $db->query(
                            $db->insert('table.forum_poll_votes')->rows([
                                'topic_id'     => $topicId,
                                'option_index' => (int) $idx,
                                'voter_hash'   => hash('sha256', 'legacy-' . $topicId . '-' . $idx . '-' . $i),
                                'created'      => time(),
                            ])
                        );
                        $stats['poll_votes']++;
                    }
                }
            } elseif (str_starts_with($name, 'ext:Forum-poll-')) {
                // تعریف: «question|opt1|opt2|…»
                $topicId = (int) substr($name, strlen('ext:Forum-poll-'));
                if ($topicId < 1 || $value === '') {
                    continue;
                }
                $exists = $db->fetchRow(
                    $db->select('topic_id')->from('table.forum_polls')
                        ->where('topic_id = ?', $topicId)->limit(1)
                );
                if ($exists) {
                    continue;
                }
                $parts = explode('|', $value);
                $question = trim((string) array_shift($parts));
                $options2 = array_values(array_filter(array_map('trim', $parts), fn ($o) => $o !== ''));
                if ($question === '' || count($options2) < 1) {
                    continue;
                }
                $db->query(
                    $db->insert('table.forum_polls')->rows([
                        'topic_id' => $topicId,
                        'question' => $question,
                        'options'  => json_encode($options2, JSON_UNESCAPED_UNICODE),
                        'created'  => time(),
                    ])
                );
                $stats['polls']++;
            }
        }

        // ------------------------------------------------------------------
        // ۵) اعلان‌ها — ext:Forum-notifications → جدول
        // ------------------------------------------------------------------
        $notifRaw = Plugin::readOptionValue('ext:Forum-notifications');
        if ($notifRaw !== '') {
            foreach (explode(';', $notifRaw) as $entry) {
                $entry = trim($entry);
                if ($entry === '' || !str_contains($entry, '|')) {
                    continue;
                }
                $parts = explode('|', $entry);
                if (count($parts) < 6) {
                    continue;
                }
                [$id, $uid, $type, $coid, $created, $read] = $parts;
                $uid = (int) $uid;
                $coid = (int) $coid;
                if ($uid < 1 || $coid < 1) {
                    continue;
                }
                // تشخیص تاپیک مربوطه
                $topicId = 0;
                if (Plugin::topicById($coid) !== null) {
                    $topicId = $coid;
                } else {
                    $post = Plugin::postById($coid);
                    $topicId = $post ? (int) $post['topic_id'] : 0;
                }
                $db->query(
                    $db->insert('table.forum_notifications')->rows([
                        'uid'      => $uid,
                        'type'     => in_array($type, ['reply', 'best', 'mention'], true) ? $type : 'reply',
                        'topic_id' => $topicId,
                        'item_id'  => $coid,
                        'is_read'  => $read === '1' ? 1 : 0,
                        'created'  => (int) $created,
                    ])
                );
                $stats['notifications']++;
            }
        }

        // ------------------------------------------------------------------
        // ۶) گزارش‌ها — ext:Forum-flags → جدول
        // ------------------------------------------------------------------
        $flagRaw = Plugin::readOptionValue('ext:Forum-flags');
        if ($flagRaw !== '') {
            foreach (explode(';', $flagRaw) as $entry) {
                $entry = trim($entry);
                if ($entry === '' || !str_contains($entry, '|')) {
                    continue;
                }
                $parts = explode('|', $entry);
                $coid = (int) ($parts[0] ?? 0);
                if ($coid < 1) {
                    continue;
                }
                $type = Plugin::topicById($coid) !== null ? 'topic' : 'post';
                $reporters = array_filter(array_slice($parts, 2), fn ($x) => $x !== '');
                foreach ($reporters as $reporter) {
                    $db->query(
                        $db->insert('table.forum_flags')->rows([
                            'item_type'    => $type,
                            'item_id'      => $coid,
                            'reporter_hash' => hash('sha256', 'legacy-' . $reporter),
                            'created'      => time(),
                        ])
                    );
                    $stats['flags']++;
                }
            }
        }

        // همگام‌سازی دنباله‌های خودافزایش (PostgreSQL)
        Schema::syncSequences();

        Plugin::resetCategoriesCache();
        Plugin::resetFlagCache();

        self::markDone($stats);

        $catMsg = $stats['categories'] . ' دسته';
        if ((int) $stats['categories_linked'] > 0) {
            $catMsg .= ' (و ' . $stats['categories_linked'] . ' دستهٔ هم‌نام موجود متصل شد)';
        }
        if ((int) $stats['category_backfill'] > 0) {
            $catMsg .= ' و دستهٔ ' . $stats['category_backfill'] . ' پرسشِ موجود تکمیل شد';
        }

        $msg = 'ایمپورت از سیستم قدیمی انجام شد: '
            . $stats['topics'] . ' پرسش، '
            . $stats['posts'] . ' پاسخ، '
            . $catMsg . '، '
            . $stats['polls'] . ' نظرسنجی و '
            . $stats['notifications'] . ' اعلان منتقل شد'
            . ' (داده‌های قدیمی دست‌نخورده باقی مانده‌اند).';

        // شفاف‌سازی وضعیت دسته‌ها برای ردیابی مشکلات (۲.۰.۴)
        $found = (int) $stats['cats_found'];
        if ($found > 0) {
            $msg .= ' در سیستم قدیمی ' . $found . ' دسته یافت شد'
                . ' (ردیف «' . $catInfo['source'] . '»، قالب: ' . $catInfo['format'] . ')'
                . (empty($catDetail) ? '؛ همهٔ آن‌ها قبلاً منتقل یا متصل شده بودند.' : ': ' . implode('؛ ', $catDetail) . '.');
        } elseif ($catInfo['source'] !== '' && $catInfo['format'] === 'empty') {
            $msg .= ' در سیستم قدیمی دسته‌ای ثبت نشده بود — ردیف «' . $catInfo['source'] . '» موجود اما خالی است.';
        } elseif ($catInfo['source'] !== '') {
            $msg .= ' هشدار: ردیف «' . $catInfo['source'] . '» (' . $catInfo['raw_len'] . ' بایت) پیدا شد اما در هیچ قالب شناخته‌شده‌ای قابل خواندن نبود — برای بررسی، مقدار این ردیف را برای سازندهٔ افزونه بفرستید.';
        } else {
            $msg .= ' در سیستم قدیمی هیچ ردیف دسته‌ای پیدا نشد (ext:Forum-categories و مشابه‌ها غایب‌اند).';
        }

        // نشانگر نسخهٔ کد در حال اجرا — اگر نسخهٔ قدیمی‌تر از این نمایش داده شد،
        // یعنی کش OPcache هنوز کد کهنه را سرو می‌کند و Apache باید ری‌استارت شود.
        $msg .= ' [اجرا با کد افزونهٔ ' . Plugin::VERSION . ']';

        return $msg;
    }

    /** نرمال‌سازی وضعیت دیدگاه قدیمی به وضعیت انجمن */
    private static function normalizeStatus(string $status): string
    {
        return in_array($status, ['approved', 'waiting', 'spam'], true) ? $status : 'approved';
    }

    /** خواندن فهرست شناسهٔ از یک ردیف options با فرمت «1,2,3» */
    private static function idList(string $name): array
    {
        $raw = Plugin::readOptionValue($name);
        $ids = [];
        foreach (explode(',', $raw) as $id) {
            $id = trim($id);
            if ($id !== '' && ctype_digit($id)) {
                $ids[] = (int) $id;
            }
        }
        return $ids;
    }

    /** خواندن نگاشت «a:b,a:b» از یک ردیف options */
    private static function pairMap(string $name): array
    {
        $raw = Plugin::readOptionValue($name);
        $map = [];
        foreach (explode(',', $raw) as $pair) {
            $pair = trim($pair);
            if ($pair === '' || !str_contains($pair, ':')) {
                continue;
            }
            [$a, $b] = explode(':', $pair, 2);
            if (ctype_digit($a) && ctype_digit($b)) {
                $map[(int) $a] = (int) $b;
            }
        }
        return $map;
    }
}
