<?php
namespace TypechoPlugin\Forum;

use Typecho\Config;
use Typecho\Db;
use Typecho\Widget\Exception as WidgetException;
use Widget\Archive;
use Widget\Options;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

abstract class ForumPage extends Archive
{
    /** داده‌های قالب — توسط prepare() پر می‌شود */
    protected ?array $forumContext = null;

    /** کش تصمیم «رندر داخل پوسته یا مستقل» */
    protected ?bool $useThemeCache = null;

    protected function initComponents(int &$components)
    {
        $components = self::INIT_OPTIONS | self::INIT_USER | self::INIT_SECURITY;
    }

    protected function initParameter(Config $parameter)
    {
        try {
            // تنظیم‌های پیش‌فرض آرشیو + پوشهٔ پوستهٔ فعلی (themeDir)
            parent::initParameter($parameter);
        } catch (WidgetException $e) {
            // فراخوانی خارج از روتر — نادر؛ فقط themeDir را خودمان می‌سازیم
            $parameter->setDefault(['pageSize' => 20, 'type' => 'forum']);
            $this->setThemeDir(
                rtrim((string) $this->options->themeFile((string) $this->options->theme), '/') . '/'
            );
        }
    }

    public function execute()
    {
        if ($this->forumContext !== null) {
            return; // idempotent — اجرای دوباره بی‌اثر
        }

        // ۱) بارگذاری functions.php پوستهٔ فعلی — همانند Archive::execute هسته.
        if ($this->useTheme()) {
            $functionsFile = (string) $this->getThemeDir() . 'functions.php';
            if (file_exists($functionsFile)) {
                require_once $functionsFile;
                if (function_exists('themeInit')) {
                    themeInit($this);
                }
            }
        }

        // ۲) فرادادهٔ آرشیو (عنوان/توضیح/پیوندها) — پیش از نیاز قالب‌ها
        $this->setupArchiveMeta();

        // ۳) داده‌های اختصاصی صفحه (فهرست یا پرسش)
        $this->forumContext = $this->prepareContext();
    }

    /**
     * همیشه داخل پوستهٔ فعلی سایت رندر می‌شود
     */
    protected function useTheme(): bool
    {
        return true;
    }

    /**
     * فرادادهٔ آرشیو برای سرآیهٔ پوسته (عنوان صفحه، توضیح، فیدها)
     */
    protected function setupArchiveMeta(): void
    {
        $this->setArchiveType('forum');
        $this->setArchiveSlug('');
        $this->setArchiveTitle($this->forumPageTitle());
        $this->setArchiveDescription($this->forumPageDescription());
        $this->setArchiveKeywords((string) $this->options->keywords);
        $this->setArchiveUrl($this->forumPageUrl());
        $this->setArchiveFeedUrl((string) $this->options->feedUrl);
        $this->setArchiveFeedRssUrl((string) $this->options->feedRssUrl);
        $this->setArchiveFeedAtomUrl((string) $this->options->feedAtomUrl);
    }

    /** عنوان آرشیو (برای <title> و سرآیه) */
    abstract protected function forumPageTitle(): string;

    /** توضیح آرشیو (برای meta description) */
    abstract protected function forumPageDescription(): string;

    /** نشانی canonical صفحهٔ فعلی */
    abstract protected function forumPageUrl(): string;

    /**
     * داده‌های موردنیاز قالب — هر زیرکلاس کوئری‌های خودش را اجرا می‌کند.
     * استثناهای 404 نیز از همین‌جا پرتاب می‌شوند (پیش از هر خروجی).
     */
    abstract protected function prepareContext(): array;

    /**
     * متغیرهای مشترک همهٔ قالب‌های انجمن
     */
    protected function commonContext(): array
    {
        $requireUrl = false;
        try {
            $requireUrl = (bool) ($this->options->commentsRequireUrl
                ?? ($this->options->commentsRequireURL ?? false));
        } catch (\Throwable $e) {
            $requireUrl = false;
        }

        $sidebarWidgets = Plugin::opt('sidebarWidgets', ['user', 'categories', 'stats', 'members', 'auth']);
        if (!is_array($sidebarWidgets)) {
            $sidebarWidgets = $sidebarWidgets === '' ? [] : [$sidebarWidgets];
        }

        $showSidebar = Plugin::opt('showSidebar', '1') !== '0'
            && !empty($sidebarWidgets);

        // ---- آخرین اعضا (برای ویجت سایدبار) ----
        $latestMembers = [];
        if (in_array('members', $sidebarWidgets, true)) {
            $latestMembers = Plugin::latestMembers(8);
        }

        // ---- کاربر فعلی (برای سایدبار) ----
        $me = null;
        $unreadNotifs = 0;
        $myNotifs = [];
        if ($this->user->hasLogin()) {
            $uid = (int) $this->user->uid;
            $me = [
                'uid'        => $uid,
                'name'       => (string) $this->user->screenName,
                'mail'       => (string) $this->user->mail,
                'group'      => (string) ($this->user->group ?? 'subscriber'),
                'url'        => (string) $this->user->url,
                'created'    => (int) ($this->user->created ?? 0),
                'stats'      => Plugin::userStats($uid),
                'profileUrl' => Plugin::profileUrl($uid),
            ];
            $unreadNotifs = Plugin::unreadNotificationCount($uid);
            $myNotifs = Plugin::notificationsFor($uid);
        }

        // ---- دکمهٔ «موضوع جدید» سایدبار ----
        $askUrl = Plugin::forumUrl();
        $askUrl .= (str_contains($askUrl, '?') ? '&' : '?') . 'ask=1';

        // ---- دسته‌ها برای ویجت سایدبار ----
        $sidebarCategories = Plugin::categoriesForTemplate(true);

        // ---- تیکر خبری اطلاع‌رسانی (۲.۲.۰) ----
        $announceItems = Plugin::announceItems();

        // ---- بلاک اداری بازدیدکنندهٔ فعلی (۲.۲.۰) — برای نوار هشدار ----
        $viewerBan = $me !== null ? Plugin::activeBanFor((int) $me['uid']) : null;

        return [
            'post'             => Plugin::forumPostArray(),
            'forumTitle'       => (string) Plugin::opt('forumTitle', 'انجمن پرسش و پاسخ'),
            'forumIntro'       => trim((string) Plugin::opt('forumIntro', '')),
            'guestAsk'         => Plugin::opt('guestAsk', '1') !== '0',
            'commentsOpen'     => Plugin::allowPost(),
            'token'            => $this->security->getToken($this->request->getRequestUrl()),
            'hasLogin'         => $this->user->hasLogin(),
            'canManage'        => Plugin::canManage(),
            'maxLen'           => Plugin::maxTextLength(),
            'requireMail'      => (bool) $this->options->commentsRequireMail,
            'requireUrl'       => $requireUrl,
            'banner'           => Plugin::statusBanner(),
            'showSidebar'      => $showSidebar,
            'sidebarWidgets'   => $sidebarWidgets,
            'showProfile'      => Plugin::profileEnabled(),
            'viewsEnabled'     => Plugin::viewsEnabled(),
            'lightboxEnabled'  => Plugin::lightboxEnabled(),
            'pollsEnabled'     => Plugin::pollsEnabled(),
            'me'               => $me,
            'forumStats'       => Plugin::forumStats(),
            'latestMembers'    => $latestMembers,
            'unreadNotifs'     => $unreadNotifs,
            'myNotifs'         => $myNotifs,
            'askUrl'           => $askUrl,
            'loginUrl'         => (string) $this->options->loginUrl,
            'registerUrl'      => (string) $this->options->registerUrl,
            'logoutUrl'        => (string) $this->options->logoutUrl,
            'allowRegister'    => (bool) ($this->options->allowRegister ?? false),
            'sidebarCategories'  => $sidebarCategories,
            'categoryAdminUrl'   => Plugin::categoryAdminUrl(),
            // ۲.۲.۰ — تیکر خبری و بلاک اداری
            'announceItems'      => $announceItems,
            'viewerBan'          => $viewerBan,
        ];
    }

    /**
     * رندر نهایی: خروجی قالب را داخل پوستهٔ سایت می‌نشاند
     *
     * @param string $view نام فایل قالب داخل views/
     */
    protected function renderForumPage(string $view): void
    {
        $this->execute();

        $context = $this->forumContext;
        extract($context, EXTR_SKIP);

        ob_start();
        require __DIR__ . '/views/' . $view;
        $body = (string) ob_get_clean();

        // همیشه داخل پوستهٔ فعلی سایت رندر می‌شود
        $pluginUrl = rtrim((string) $this->options->pluginUrl, '/') . '/Forum';
        $assetBase = Plugin::e($pluginUrl) . '/assets';
        // نسخهٔ کش‌شکن: VERSION + زمان تغییر فایل (۲.۰.۰) — حتی با تکرار
        // شمارهٔ نسخه بین دو انتشار، فایل تغییرکرده نشانی تازه می‌گیرد.
        $vCss = Plugin::e(Plugin::assetVer('assets/forum.css'));
        $vJs = Plugin::e(Plugin::assetVer('assets/forum.js'));

        $this->need('header.php');

        echo '<link rel="stylesheet" href="' . $assetBase . '/forum.css?v=' . $vCss . '">' . "\n";
        // data-qa-lightbox روی qa-main div ست می‌شود تا forum.js بلافاصله آن را بخواند
        $lbAttr = Plugin::lightboxEnabled() ? ' data-qa-lightbox="1"' : '';
        echo '<div class="qa-main"' . $lbAttr . '>' . "\n" . $body . "\n" . '</div>' . "\n";
        echo '<script src="' . $assetBase . '/forum.js?v=' . $vJs . '" defer></script>' . "\n";

        // سازگاری با RenewShield — ست کردن cookie/state روی صفحات انجمن
        // (فراخوانی مستقیم، بدون وابستگی به هوک یا قالب)
        Plugin::prepareRenewShieldContext($this);

        $this->need('footer.php');
    }
}
