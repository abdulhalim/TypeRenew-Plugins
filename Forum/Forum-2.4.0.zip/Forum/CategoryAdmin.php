<?php
namespace TypechoPlugin\Forum;

use Typecho\Widget\Exception as WidgetException;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class CategoryAdmin extends ForumPage
{
    protected function forumPageTitle(): string
    {
        return 'مدیریت دسته‌بندی‌های انجمن';
    }

    protected function forumPageDescription(): string
    {
        return 'ایجاد، ویرایش و حذف دسته‌بندی‌های انجمن';
    }

    protected function forumPageUrl(): string
    {
        return Plugin::categoryAdminUrl();
    }

    public function render(): void
    {
        $this->renderForumPage('admin_categories.php');
    }

    protected function prepareContext(): array
    {
        // فقط مدیران
        if (!Plugin::canManage()) {
            throw new WidgetException(_t('صفحهٔ موردنظر یافت نشد'), 404);
        }

        $cats = Plugin::categoriesForTemplate(true);
        $counts = Plugin::categoryTopicCounts();

        // عناصر فرم: فهرست آیکون‌ها برای <select>
        $iconOptions = Plugin::CATEGORY_ICONS;

        return $this->commonContext() + [
            'categories'  => $cats,
            'counts'      => $counts,
            'iconOptions' => $iconOptions,
            'token'       => $this->security->getToken($this->request->getRequestUrl()),
            'adminUrl'    => Plugin::categoryAdminUrl(),
        ];
    }
}
