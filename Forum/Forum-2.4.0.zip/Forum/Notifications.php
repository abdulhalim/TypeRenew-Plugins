<?php
namespace TypechoPlugin\Forum;

use Typecho\Db;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * صفحهٔ مستقل اعلان‌ها (۲.۳.۰) — /forum/notifications
 *
 * فقط لایهٔ «ارائه» است: تولید اعلان‌ها، جدول و منطق خوانده‌شدن
 * دست‌نخورده می‌ماند (Plugin::notificationsFor / unreadNotificationCount /
 * Post::handleReadNotif[s]). این صفحه صرفاً همان داده‌ها را کامل‌تر
 * (آواتار + نام کنشگر + عنوان تاپیک) و در ۲۰ موردِ اخیر نمایش می‌دهد.
 *
 * کارایی: کوئری اعلان‌ها با commonContext مشترک است (کش درخواست) و
 * آواتار/عنوان‌ها با سه کوئری گروهی (IN) واکشی می‌شوند — بدون N+1.
 */
class Notifications extends ForumPage
{
    /** شمار اعلان‌های نمایش‌داده‌شده در صفحه */
    private const PAGE_LIMIT = 20;

    protected function forumPageTitle(): string
    {
        return 'اعلان‌ها — انجمن';
    }

    protected function forumPageDescription(): string
    {
        return 'اعلان‌های شما در انجمن — پاسخ‌ها، بهترین پاسخ‌ها و نام‌بردها';
    }

    protected function forumPageUrl(): string
    {
        return Plugin::notificationsUrl();
    }

    public function render(): void
    {
        $this->renderForumPage('notifications.php');
    }

    protected function prepareContext(): array
    {
        // (الگوی ۲.۱.۰ Messages) اگر کاربر وارد نشده، به‌جای 403 به
        // صفحهٔ ورود هدایت می‌شود — هیچ تغییرِ دسترسی/نشست انجام نمی‌شود.
        if (!$this->user->hasLogin()) {
            $loginUrl = (string) $this->options->loginUrl;
            $notifUrl = Plugin::notificationsUrl();
            $sep = str_contains($loginUrl, '?') ? '&' : '?';
            $this->response->redirect($loginUrl . $sep . 'referer=' . rawurlencode($notifUrl));
            return []; // redirect() خودش اجرا را پایان می‌دهد
        }

        $uid = (int) $this->user->uid;

        // myNotifs/unreadNotifs از commonContext می‌آیند؛
        // Plugin::notificationsFor در طول درخواست کش می‌شود → بدون کوئری تکراری.
        $ctx = $this->commonContext();
        $all = is_array($ctx['myNotifs'] ?? null) ? $ctx['myNotifs'] : [];
        $rows = array_slice($all, 0, self::PAGE_LIMIT);

        return $ctx + [
            'notifRows'  => $this->enrichNotifications($rows),
            'notifTotal' => count($all),
            'notifLimit' => self::PAGE_LIMIT,
        ];
    }

    /**
     * غنی‌سازی اعلان‌ها برای نمایش کامل — بدون N+1.
     *
     * سه کوئری گروهی (IN) برای حداکثر ۲۰ اعلانِ صفحه:
     *   ۱) forum_posts  → کنشگر (نویسندهٔ پاسخ) + topic_id هر آیتم
     *   ۲) forum_topics → عنوان تاپیک‌ها (+ آیتم‌های قدیمیِ نسخهٔ ۱ که
     *      خودشان تاپیک بوده‌اند — همان fallbackِ topicIdForItem)
     *   ۳) users        → نام/ایمیل کنشگرهای عضو برای آواتار
     * مهمان‌ها (author_id = 0) با author_name نمایش داده می‌شوند.
     *
     * @param array $rows خروجی Plugin::notificationsFor (۲۰ موردِ اخیر)
     * @return array آرایهٔ آمادهٔ قالب: id/type/read/created + url +
     *               actor{name, mail, profileUrl} + topicTitle
     */
    private function enrichNotifications(array $rows): array
    {
        $out = [];
        if (empty($rows)) {
            return $out;
        }

        $itemIds = [];
        $topicIds = [];
        foreach ($rows as $n) {
            $itemId = (int) $n['coid'];
            if ($itemId > 0) {
                $itemIds[$itemId] = true;
            }
            $topicId = (int) $n['topic_id'];
            if ($topicId > 0) {
                $topicIds[$topicId] = true;
            }
        }

        try {
            $db = Db::get();
        } catch (\Throwable $e) {
            $db = null;
        }

        // ---- ۱) آیتم‌ها: پاسخ‌ها (کنشگر + تاپیک مرجع) ----
        $itemsMap = []; // itemId => ['authorId', 'authorName', 'topicId']
        if ($db !== null && $itemIds !== []) {
            try {
                $r = $db->fetchAll(
                    $db->select('id', 'topic_id', 'author_id', 'author_name')
                        ->from('table.forum_posts')
                        ->where('id IN ?', array_keys($itemIds))
                );
                foreach ($r as $p) {
                    $itemsMap[(int) $p['id']] = [
                        'authorId'   => (int) $p['author_id'],
                        'authorName' => (string) $p['author_name'],
                        'topicId'    => (int) $p['topic_id'],
                    ];
                    if ((int) $p['topic_id'] > 0) {
                        $topicIds[(int) $p['topic_id']] = true;
                    }
                }
            } catch (\Throwable $e) {
            }
        }

        // ---- ۲) تاپیک‌ها: عنوان + fallback آیتم‌های قدیمی (نسخهٔ ۱) ----
        // اعلان‌های قدیمی ممکن است item_id = شناسهٔ تاپیک داشته باشند؛
        // همان منطق Plugin::topicIdForItem، این‌جا به‌صورت گروهی انجام می‌شود.
        $legacyIds = [];
        foreach (array_keys($itemIds) as $id) {
            if (!isset($itemsMap[$id])) {
                $legacyIds[] = $id;
            }
        }
        $topics = []; // topicId => ['title' (متن خام), 'authorId', 'authorName']
        if ($db !== null && ($topicIds !== [] || $legacyIds !== [])) {
            $needTopics = array_unique(array_merge(array_keys($topicIds), $legacyIds));
            try {
                $r = $db->fetchAll(
                    $db->select('id', 'text', 'author_id', 'author_name')
                        ->from('table.forum_topics')
                        ->where('id IN ?', $needTopics)
                );
                foreach ($r as $t) {
                    $topics[(int) $t['id']] = [
                        'text'       => (string) $t['text'],
                        'authorId'   => (int) $t['author_id'],
                        'authorName' => (string) $t['author_name'],
                    ];
                }
            } catch (\Throwable $e) {
            }
        }
        // آیتم‌های قدیمی = خودِ تاپیک (fallback نسخهٔ ۱)
        foreach ($legacyIds as $id) {
            if (isset($topics[$id])) {
                $itemsMap[$id] = [
                    'authorId'   => $topics[$id]['authorId'],
                    'authorName' => $topics[$id]['authorName'],
                    'topicId'    => $id,
                ];
            }
        }

        // ---- ۳) کنشگرهای عضو: نام + ایمیل برای آواتار ----
        $authorIds = [];
        foreach ($itemsMap as $m) {
            if ($m['authorId'] > 0) {
                $authorIds[$m['authorId']] = true;
            }
        }
        $users = []; // uid => ['name', 'mail']
        if ($db !== null && $authorIds !== []) {
            try {
                $r = $db->fetchAll(
                    $db->select('uid', 'name', 'screenName', 'mail')
                        ->from('table.users')
                        ->where('uid IN ?', array_keys($authorIds))
                );
                foreach ($r as $u) {
                    $users[(int) $u['uid']] = [
                        'name' => trim((string) ($u['screenName'] ?: $u['name'])),
                        'mail' => (string) $u['mail'],
                    ];
                }
            } catch (\Throwable $e) {
            }
        }

        // ---- ساخت ردیف‌های نهایی ----
        foreach ($rows as $n) {
            $itemId = (int) $n['coid'];
            $item = $itemsMap[$itemId] ?? null;

            // تاپیکِ اعلان: اول topic_id خود اعلان، بعد topic_id آیتم
            $topicId = (int) $n['topic_id'];
            if ($topicId < 1 && $item !== null) {
                $topicId = (int) $item['topicId'];
            }

            // عنوان تاپیک — نخستین سطر متن (همند فهرست پرسش‌ها)
            $topicTitle = '';
            if ($topicId > 0 && isset($topics[$topicId])) {
                [$ttl] = Plugin::splitQuestion((string) $topics[$topicId]['text']);
                $topicTitle = Plugin::stripMarkup($ttl);
            }

            // کنشگر: نویسندهٔ آیتم (پاسخ/پرسش)؛ pm از messageViewUrl می‌آید
            $actorName = $item !== null ? (string) $item['authorName'] : '';
            $actorMail = '';
            $actorProfileUrl = '';
            if ($item !== null && $item['authorId'] > 0) {
                $u = $users[$item['authorId']] ?? null;
                if ($u !== null) {
                    $actorName = $u['name'] !== '' ? $u['name'] : $actorName;
                    $actorMail = $u['mail'];
                }
                if (Plugin::profileEnabled()) {
                    $actorProfileUrl = Plugin::profileUrl((int) $item['authorId']);
                }
            }

            // نشانی مقصد — همان قاعدهٔ popup (pm → پیام، بقیه → تاپیک + لنگر)
            if ($n['type'] === 'pm') {
                $url = Plugin::messageViewUrl($itemId);
            } else {
                if ($topicId < 1) {
                    // fallback همان popup: جست‌وجوی تک‌موردی فقط وقتی لازم شد
                    $topicId = Plugin::topicIdForItem($itemId);
                }
                $url = Plugin::threadUrl($topicId) . '#c' . $itemId;
            }

            $out[] = [
                'id'        => (int) $n['id'],
                'type'      => (string) $n['type'],
                'read'      => (bool) $n['read'],
                'created'   => (int) $n['created'],
                'url'       => $url,
                'topicTitle' => $topicTitle,
                'actorName'  => $actorName,
                'actorMail'  => $actorMail,
                'actorProfileUrl' => $actorProfileUrl,
            ];
        }

        return $out;
    }
}
