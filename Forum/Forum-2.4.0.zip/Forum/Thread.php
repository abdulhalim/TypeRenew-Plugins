<?php
namespace TypechoPlugin\Forum;

use Typecho\Db;
use Typecho\Widget\Exception as WidgetException;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * صفحهٔ پرسش (تاپیک) — نسخهٔ ۲ (دیتابیس مستقل).
 */
class Thread extends ForumPage
{
    /** پرسش فعلی — کش‌شده برای فراخوانی‌های متعدد در طول رندر */
    protected ?array $questionRow = null;

    private bool $questionLoaded = false;

    protected function forumPageTitle(): string
    {
        $q = $this->threadQuestion();
        if ($q === null) {
            return (string) Plugin::opt('forumTitle', 'انجمن پرسش و پاسخ');
        }
        [$title] = Plugin::splitQuestion((string) $q['text']);
        $title = Plugin::stripMarkup($title);
        return $title !== '' ? $title : (string) Plugin::opt('forumTitle', 'انجمن پرسش و پاسخ');
    }

    protected function forumPageDescription(): string
    {
        $q = $this->threadQuestion();
        if ($q === null) {
            return (string) $this->options->description;
        }
        $desc = Plugin::excerpt((string) $q['text'], 160);
        return $desc !== '' ? $desc : (string) $this->options->description;
    }

    protected function forumPageUrl(): string
    {
        $coid = (int) ($this->request->get('coid') ?: 0);
        return $coid > 0 ? Plugin::threadUrl($coid) : Plugin::forumUrl();
    }

    public function render(): void
    {
        // اگر شمارهٔ پرسش در واقع «پاسخ» باشد، به پرسشِ خودش هدایت می‌شویم.
        // (redirect با exit تمام می‌شود؛ بنابراین پیش از هر خروجی امن است)
        $q = $this->threadQuestion();
        if ($q !== null && (int) $q['parent'] > 0) {
            $this->response->redirect(
                Plugin::threadUrl((int) $q['parent']) . '#c' . (int) $q['coid']
            );
        }

        $this->renderForumPage('thread.php');
    }

    /** ردیف پرسش یا پاسخِ فعلی (به شکل قالب) — یا null */
    private function threadQuestion(): ?array
    {
        if (!$this->questionLoaded) {
            $this->questionLoaded = true;
            $this->questionRow = null;

            $coid = (int) ($this->request->get('coid') ?: 0);
            if ($coid > 0) {
                // اول پرسش، بعد پاسخ (برای ریدایرکت)
                $topic = Plugin::topicForView($coid);
                if ($topic !== null) {
                    $this->questionRow = $topic;
                } else {
                    $post = Plugin::postForView($coid);
                    $this->questionRow = $post;
                }
            }
        }
        return $this->questionRow;
    }

    protected function prepareContext(): array
    {
        $question = $this->threadQuestion();

        if (!$question || (int) $question['parent'] > 0) {
            throw new WidgetException(_t('پرسش موردنظر یافت نشد'), 404);
        }

        $coid = (int) $question['coid'];

        if ($question['status'] === 'spam') {
            throw new WidgetException(_t('پرسش موردنظر یافت نشد'), 404);
        }

        if ($question['status'] !== 'approved' && !Plugin::canSeeWaiting($coid)) {
            throw new WidgetException(_t('پرسش موردنظر یافت نشد'), 404);
        }

        // مهمان: پرسش پنهان‌شده را نبیند
        if (!Plugin::canSee($coid)) {
            throw new WidgetException(_t('پرسش موردنظر یافت نشد'), 404);
        }

        // پاسخ‌های تأییدشده (کهنگی به تازگی)
        $answers = Plugin::postsForTopic($coid, 'approved');

        // پاسخ‌های در انتظار تأیید: فقط برای مدیر یا خودِ نویسنده (کوکی هسته)
        $waiting = Plugin::postsForTopic($coid, 'waiting');
        foreach ($waiting as $w) {
            if (Plugin::canSeeWaiting((int) $w['coid'])) {
                $answers[] = $w;
            }
        }
        usort($answers, static fn ($a, $b) => (int) $a['created'] <=> (int) $b['created']);

        $approvedCount = 0;
        foreach ($answers as $a) {
            if ($a['status'] === 'approved') {
                $approvedCount++;
            }
        }

        // ۲.۲.۰ — صفحه‌بندی پاسخ‌ها: محاسبهٔ تعداد صفحات و صفحهٔ فعلی.
        // برش آرایه (array_slice) بعد از اعمال فلگ‌ها انجام می‌شود تا
        // پاسخ‌های صفحهٔ فعلی شامل همهٔ فلگ‌های مدیریتی باشند.
        $postsPerPage = Plugin::postsPerPage();
        $answersTotal = count($answers);
        $answersPages = $answersTotal > 0 ? (int) ceil($answersTotal / $postsPerPage) : 1;

        // تشخیص صفحه: اولویت با coid_answer (پیوند عمیق)، سپس pa (شماره صفحه)
        $targetCoid = (int) ($this->request->get('coid_answer') ?: 0);
        $answersPage = 0;
        if ($targetCoid > 0) {
            foreach ($answers as $i => $a) {
                if ((int) $a['coid'] === $targetCoid) {
                    $answersPage = (int) floor($i / $postsPerPage) + 1;
                    break;
                }
            }
        }
        if ($answersPage < 1) {
            $answersPage = max(1, (int) ($this->request->get('pa') ?: 1));
        }
        if ($answersPage < 1) { $answersPage = 1; }
        if ($answersPage > $answersPages) { $answersPage = $answersPages; }

        // ---------------- شمارش بازدید ----------------
        $viewsOn = Plugin::viewsEnabled();
        $viewCount = 0;
        $viewCounted = false;
        if ($viewsOn && $question['status'] === 'approved') {
            $viewCount = (int) ($question['views'] ?? 0);
            $viewCounted = Plugin::countThreadView($coid, (int) ($question['authorId'] ?? 0));
            $viewCount += $viewCounted ? 1 : 0;
        }

        // ---------------- ثبت خوانده‌شدن پرسش (بولت سبز «خوانده‌نشده») ----------------
        Plugin::markRead($coid);

        // ---------------- داده‌های قالب ----------------
        [$qTitle, $qRest] = Plugin::splitQuestion((string) $question['text']);
        $question['titleLine'] = $qTitle;
        $question['restText'] = $qRest;
        $question['isWaiting'] = $question['status'] !== 'approved';
        $question['qaViews'] = $viewCount;
        $question['qaPinned'] = Plugin::isPinned($coid);
        $question['qaTracked'] = Plugin::isTracked($coid);
        $question['qaHidden'] = Plugin::isHidden($coid);
        $question['qaCatId'] = Plugin::topicCategoryId($coid);
        $question['qaReported'] = Plugin::isReported($coid, 'topic');

        foreach ($answers as &$a) {
            $a['canEdit'] = Plugin::canEdit($a);
            $a['qaReported'] = Plugin::isReported((int) $a['coid'], 'post');
        }
        unset($a);

        $question['canEdit'] = Plugin::canEdit($question);

        // ---------------- گزارش تخلف — ۲.۰.۰ ----------------
        // نویسنده دکمهٔ گزارش برای نوشتهٔ خودش را نمی‌بیند (مثل پسند)؛
        // سرور هم همین قاعده را در handleFlag اعمال می‌کند.
        $myUid = Plugin::viewerUid();
        $question['qaFlagOn'] = Plugin::canFlag($question);
        foreach ($answers as &$a) {
            $a['qaFlagOn'] = Plugin::canFlag($a);
        }
        unset($a);

        // ---------------- پسند (لایک) — ۲.۰.۰ ----------------
        // فقط اعضای واردشده؛ نویسنده دکمه ندارد (نشان شمار پسند می‌بیند)؛
        // مهمان هیچ چیزی نمی‌بیند. نوع صریح: شناسه‌های دو جدول
        // مستقل‌اند و ممکن است هم‌شماره باشند.
        $likesOn = Plugin::likesEnabled();
        $question['qaLikesOn'] = $likesOn && Plugin::canLike($question);
        $question['qaLikesOwn'] = $likesOn && $myUid > 0
            && (int) ($question['authorId'] ?? 0) === $myUid;
        $question['qaLikes'] = $likesOn ? Plugin::likeCountTyped('topic', $coid) : 0;
        $question['qaLiked'] = $question['qaLikesOn'] && Plugin::hasLikedTyped('topic', $coid);
        foreach ($answers as &$a) {
            $a['qaLikesOn'] = $likesOn && Plugin::canLike($a);
            $a['qaLikesOwn'] = $likesOn && $myUid > 0
                && (int) ($a['authorId'] ?? 0) === $myUid;
            $a['qaLikes'] = $likesOn ? Plugin::likeCountTyped('post', (int) $a['coid']) : 0;
            $a['qaLiked'] = $a['qaLikesOn'] && Plugin::hasLikedTyped('post', (int) $a['coid']);
        }
        unset($a);

        $isLocked = Plugin::isLocked($coid);
        $isTracked = $question['qaTracked'];

        // ---------------- قفل خودکار پرسش‌های بی‌فعالیت ----------------
        // آخرین فعالیت = max(ساخت پرسش، آخرین پاسخ تأییدشده)
        $lastActivity = (int) $question['created'];
        foreach ($answers as $a) {
            if ($a['status'] === 'approved' && (int) $a['created'] > $lastActivity) {
                $lastActivity = (int) $a['created'];
            }
        }
        $autoLocked = false;
        if (!$isLocked) {
            $autoLocked = Plugin::checkAutoLock($coid, $lastActivity);
            if ($autoLocked) {
                $isLocked = true;
            }
        }

        // ---------------- بهترین پاسخ ----------------
        $bestAnswerId = Plugin::bestAnswerFor($coid);

        // ---------------- قفل دستهٔ پرسش (۲.۲.۰) ----------------
        // دستهٔ قفل‌شده فقط برای مدیران نوشتنی است؛ دیدن عادی می‌ماند.
        $qCatId = (int) ($question['qaCatId'] ?? 0);
        $qCatLocked = $qCatId > 0 && Plugin::isCategoryLocked($qCatId);

        $ctx = $this->commonContext();

        // آیا کاربر فعلی می‌تواند بهترین پاسخ را انتخاب کند؟
        // (نویسندهٔ پرسشِ واردشده، یا مدیر)
        $canMarkBest = false;
        if (!empty($ctx['canManage'])) {
            $canMarkBest = true;
        } elseif (!empty($ctx['hasLogin'])) {
            $user = \Widget\User::alloc();
            $qAuthorId = (int) ($question['authorId'] ?? 0);
            if ($qAuthorId > 0 && $user->hasLogin() && (int) $user->uid === $qAuthorId) {
                $canMarkBest = true;
            }
        }

        // ۲.۲.۰ — پرسش قفل‌شده برای مدیر باز است؛ دستهٔ قفل‌شده هم فقط مدیر می‌نویسد؛
        // کاربر بلاک‌شده (اداری) هم فرم نوشتن را نمی‌بیند.
        $canReply = ($ctx['guestAsk'] || $ctx['hasLogin']) && $ctx['commentsOpen']
            && (!$isLocked || !empty($ctx['canManage']))
            && (!$qCatLocked || !empty($ctx['canManage']))
            && empty($ctx['viewerBan']);

        // ۲.۲.۰ — برش پاسخ‌های صفحهٔ فعلی (بعد از اعمال همهٔ فلگ‌ها).
        // پاسخ‌های خارج از این صفحه در آرایهٔ answers باقی می‌مانند تا
        // بهترین‌پاسخ و قفل خودکار و سایر منطق‌های مبتنی بر کل تاپیک درست کار کنند.
        $answersOffset = ($answersPage - 1) * $postsPerPage;
        $answersPageItems = array_slice($answers, $answersOffset, $postsPerPage);
        // اگر بهترین پاسخ در صفحهٔ فعلی نیست، آن را به‌صورت یک آیتم
        // «بهترین پاسخ» در بالای صفحه فعلی هم نمایش بدهیم (حفظ تجربه کاربر).
        // ولی این کار را فعلاً انجام نمی‌دهیم چون پیچیده می‌شود؛ کاربر می‌تواند
        // با صفحه‌بندی به صفحهٔ بهترین پاسخ برود.

        return $ctx + [
            'question'       => $question,
            'answers'        => $answersPageItems,
            'answersAll'     => $answers,            // آرایهٔ کامل (برای منطق داخلی)
            'approvedCount'  => $approvedCount,
            'isLocked'       => $isLocked,
            'isPinned'       => $question['qaPinned'],
            'isTracked'      => $isTracked,
            'isHidden'       => $question['qaHidden'],
            'autoLocked'     => $autoLocked,
            'bestAnswerId'   => $bestAnswerId,
            'canMarkBest'    => $canMarkBest,
            'canReply'       => $canReply,
            'qCatLocked'     => $qCatLocked,
            // ۲.۲.۰ — داده‌های صفحه‌بندی پاسخ‌ها
            'answersPage'    => $answersPage,
            'answersPages'   => $answersPages,
            'answersTotal'   => $answersTotal,
            'postsPerPage'   => $postsPerPage,
        ];
    }
}
