<?php

use TypechoPlugin\Forum\Plugin;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

// $qaPageKind برای حالت فعالِ منوی کاربر و سربرگ
$qaPageKind = 'notifications';
include __DIR__ . '/header.php';
include __DIR__ . '/sortbar.php';

// داده‌های صفحه — از Notifications::prepareContext()
$notifRows = isset($notifRows) && is_array($notifRows) ? $notifRows : [];
$notifTotal = (int) ($notifTotal ?? 0);
$notifLimit = (int) ($notifLimit ?? 20);
$notifUnread = (int) ($unreadNotifs ?? 0);
$markAllUrl = Plugin::postUrl();
?>
<div class="qa-layout">
<div class="qa-content">

<?php if ($banner !== null): ?>
<?php $bannerWait = isset($banner[2]) ? (int) $banner[2] : 0; ?>
<div class="qa-banner is-<?php echo Plugin::e($banner[1]); ?>" role="status"<?php echo $bannerWait > 0 ? ' data-wait-banner="' . $bannerWait . '"' : ''; ?>>
  <p>
    <?php echo Plugin::e($banner[0]); ?>
  </p>
  <button type="button" class="qa-banner-close" aria-label="بستن پیام">&times;</button>
</div>
<?php endif; ?>

<section class="qa-np" aria-label="اعلان‌ها">
  <header class="qa-np-head">
    <h1 class="qa-np-title">
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
      اعلان‌های شما
      <?php if ($notifUnread > 0): ?>
      <span class="qa-np-badge"><?php echo Plugin::faDigits($notifUnread); ?> خوانده‌نشده</span>
      <?php endif; ?>
    </h1>
    <?php if ($notifUnread > 0): ?>
    <form method="post" action="<?php echo Plugin::e($markAllUrl); ?>" class="qa-notif-mark-form">
      <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
      <input type="hidden" name="mode" value="read-notifs">
      <button type="submit" class="qa-btn qa-btn-ghost qa-np-markall">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="20 6 9 17 4 12"></polyline></svg>
        <span>خواندن همهٔ اعلان‌ها</span>
      </button>
    </form>
    <?php endif; ?>
  </header>

  <p class="qa-np-sub">
    <?php echo Plugin::faDigits(min($notifTotal, $notifLimit)); ?> اعلانِ اخیر نمایش داده می‌شود<?php echo $notifTotal > $notifLimit ? ' (از ' . Plugin::faDigits($notifTotal) . ' اعلان)' : ''; ?>.
  </p>

  <?php if (empty($notifRows)): ?>
  <div class="qa-empty">
    <div class="qa-empty-icon" aria-hidden="true">
      <svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
    </div>
    <p class="qa-empty-title">اعلانی وجود ندارد</p>
    <p class="qa-empty-text">هرگاه کسی به پرسش شما پاسخ دهد، پاسخ‌تان بهترین انتخاب شود یا نامتان را ببرد، این‌جا خبرش را می‌بینید.</p>
  </div>
  <?php else: ?>
  <ul class="qa-np-list" id="qa-np-list">
    <?php foreach ($notifRows as $n): ?>
    <li class="qa-notif-item qa-np-item<?php echo $n['read'] ? ' is-read' : ' is-unread'; ?>"
        data-notif-id="<?php echo (int) $n['id']; ?>">
      <a href="<?php echo Plugin::e($n['url']); ?>" class="qa-notif-link qa-np-link">
        <span class="qa-np-avatar" aria-hidden="true">
          <?php echo Plugin::avatar((string) $n['actorName'], (string) $n['actorMail']); ?>
        </span>
        <span class="qa-np-body">
          <span class="qa-np-line">
            <?php if ((string) $n['actorName'] !== ''): ?>
            <span class="qa-np-user"><?php echo Plugin::e($n['actorName']); ?></span>
            <?php endif; ?>
            <span class="qa-np-action"><?php echo Plugin::e(Plugin::notificationLabel($n['type'])); ?></span>
          </span>
          <?php if ((string) $n['topicTitle'] !== ''): ?>
          <span class="qa-np-topic" dir="auto"><?php echo Plugin::e(Plugin::excerpt((string) $n['topicTitle'], 90)); ?></span>
          <?php endif; ?>
          <time class="qa-notif-time qa-np-time" datetime="<?php echo Plugin::e(date('c', (int) $n['created'])); ?>"><?php echo Plugin::faRelative((int) $n['created']); ?></time>
        </span>
        <?php if (!$n['read']): ?>
        <span class="qa-notif-dot qa-np-dot" aria-label="خوانده‌نشده"></span>
        <?php endif; ?>
      </a>
    </li>
    <?php endforeach; ?>
  </ul>
  <?php endif; ?>
</section>

</div>
<?php include __DIR__ . '/sidebar.php'; ?>
</div>
