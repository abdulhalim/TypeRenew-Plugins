<?php

use TypechoPlugin\Forum\Plugin;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$widgets = is_array($sidebarWidgets) ? $sidebarWidgets : [];
$canAsk = ($guestAsk || $hasLogin) && $commentsOpen;
?>
<?php if ($showSidebar): ?>
<aside class="qa-sidebar" aria-label="نوار کناری انجمن">

  <?php if (in_array('user', $widgets, true)): ?>
  <section class="qa-widget qa-widget-user" id="qa-user-widget"
           data-notif-token="<?php echo Plugin::e($token); ?>"
           data-notif-action="<?php echo Plugin::e(Plugin::postUrl()); ?>">
    <?php if ($me !== null): ?>
    <div class="qa-wu-head">
      <?php echo Plugin::avatar((string) $me['name'], (string) $me['mail']); ?>
      <div class="qa-wu-id">
        <span class="qa-wu-name">
          <?php if ($showProfile): ?>
          <a href="<?php echo Plugin::e($me['profileUrl']); ?>"><?php echo Plugin::e($me['name']); ?></a>
          <?php else: ?>
          <?php echo Plugin::e($me['name']); ?>
          <?php endif; ?>
          <?php echo Plugin::authorBadge((int) $me['uid']); ?>
        </span>
        <span class="qa-wu-role"><?php echo Plugin::e($me['group'] === 'administrator' ? 'مدیر' : ($me['group'] === 'editor' ? 'ویراستار' : 'عضو')); ?></span>
      </div>
      <?php /* زنگولهٔ اعلان‌ها — سمت مخالف نام (۱.۵.۲)
         (۲.۳.۰) اکنون به صفحهٔ مستقل اعلان‌ها پیوند می‌خورد؛ popup زیرین
         به‌عنوان لایهٔ درونی حفظ شده و از زنگوله باز نمی‌شود. */ ?>
      <a href="<?php echo Plugin::e(Plugin::notificationsUrl()); ?>"
         class="qa-notif-bell<?php echo $unreadNotifs > 0 ? ' has-unread is-ringing' : ''; ?>"
         id="qa-notif-bell"
         aria-label="اعلان‌ها"
         data-notif-page="1"
         data-tooltip="<?php echo $unreadNotifs > 0 ? Plugin::faDigits($unreadNotifs) . ' اعلان خوانده‌نشده' : 'اعلان‌ها'; ?>">
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
        <?php if ($unreadNotifs > 0): ?>
        <span class="qa-notif-bell-badge" data-notif-badge="<?php echo (int) $unreadNotifs; ?>"><?php echo Plugin::faDigits($unreadNotifs); ?></span>
        <?php else: ?>
        <span class="qa-notif-bell-badge" data-notif-badge="0" hidden>0</span>
        <?php endif; ?>
      </a>
      <?php /* popup اعلان‌ها — زیر زنگوله */ ?>
      <div class="qa-notif-pop" id="qa-notif-pop" hidden role="dialog" aria-label="اعلان‌ها">
        <div class="qa-notif-pop-head">
          <span>اعلان‌ها</span>
          <?php if ($unreadNotifs > 0): ?>
          <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-notif-mark-form">
            <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
            <input type="hidden" name="mode" value="read-notifs">
            <button type="submit" class="qa-notif-mark-btn">خواندن همه</button>
          </form>
          <?php endif; ?>
        </div>
        <?php if (!empty($myNotifs)): ?>
        <ul class="qa-notif-list" id="qa-notif-list">
          <?php foreach (array_slice($myNotifs, 0, 10) as $n): ?>
            <?php
              // رفع باگ ۲.۰.۱: لینک اعلان باید به تاپیک (topic_id) برود نه به پست.
              // در نسخهٔ ۱ linkها با item_id ساخته می‌شدند و ۴۰۴ می‌دادند چون
              // threadUrl منتظر شناسهٔ تاپیک است؛ اکنون از topic_id استفاده می‌کنیم
              // و فقط هش (#c...) به item_id اشاره می‌کند تا به پاسخ مربوطه اسکرول شود.
              // اعلان‌های نوع pm به صفحهٔ پیام خصوصی هدایت می‌شوند (۲.۱.۰).
              if ($n['type'] === 'pm') {
                $notifUrl = Plugin::messageViewUrl((int) $n['coid']);
              } else {
                $notifTopicId = (int) $n['topic_id'];
                if ($notifTopicId < 1) {
                  // اعلان‌های قدیمیِ نسخهٔ ۱ ممکن است topic_id نداشته باشند؛
                  // با fallback آن را از روی item_id پیدا می‌کنیم.
                  $notifTopicId = Plugin::topicIdForItem((int) $n['coid']);
                }
                $notifUrl = Plugin::threadUrl($notifTopicId) . '#c' . (int) $n['coid'];
              }
            ?>
          <li class="qa-notif-item<?php echo $n['read'] ? ' is-read' : ' is-unread'; ?>"
              data-notif-id="<?php echo (int) $n['id']; ?>">
            <a href="<?php echo Plugin::e($notifUrl); ?>" class="qa-notif-link">
              <span class="qa-notif-icon" aria-hidden="true">
                <?php if ($n['type'] === 'best'): ?>
                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                <?php elseif ($n['type'] === 'pm'): ?>
                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                <?php else: ?>
                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                <?php endif; ?>
              </span>
              <span class="qa-notif-text">
                <span class="qa-notif-label"><?php echo Plugin::e(Plugin::notificationLabel($n['type'])); ?></span>
                <time class="qa-notif-time"><?php echo Plugin::faRelative((int) $n['created']); ?></time>
              </span>
              <?php if (!$n['read']): ?>
              <span class="qa-notif-dot" aria-label="خوانده‌نشده"></span>
              <?php endif; ?>
            </a>
          </li>
          <?php endforeach; ?>
        </ul>
        <?php else: ?>
        <p class="qa-notif-pop-empty">اعلانی وجود ندارد.</p>
        <?php endif; ?>
      </div>
    </div>
    <div class="qa-wu-stats">
      <?php if ($showProfile): ?>
      <a href="<?php echo Plugin::e($me['profileUrl']); ?>">
        <b><?php echo Plugin::faDigits($me['stats']['questions']); ?></b>
        <span>موضوع</span>
      </a>
      <a href="<?php echo Plugin::e($me['profileUrl'] . '?tab=answers'); ?>">
        <b><?php echo Plugin::faDigits($me['stats']['answers']); ?></b>
        <span>پاسخ</span>
      </a>
      <?php else: ?>
      <span>
        <b><?php echo Plugin::faDigits($me['stats']['questions']); ?></b>
        <span>موضوع</span>
      </span>
      <span>
        <b><?php echo Plugin::faDigits($me['stats']['answers']); ?></b>
        <span>پاسخ</span>
      </span>
      <?php endif; ?>
      <?php
        // (۲.۱.۰) bestAnswers و likes فقط در صفحهٔ پروفایل نمایش داده می‌شوند،
        // نه در کارت سایدبار — برای نگه‌داشتن کارت مینیمال با سه بلوک وضعیتی.
      ?>
      <span class="qa-wu-score">
        <b><?php echo Plugin::faDigits($me['stats']['score']); ?></b>
        <span>امتیاز</span>
      </span>
    </div>
    <?php if ($canAsk): ?>
    <a class="qa-btn qa-btn-primary qa-wu-new" href="<?php echo Plugin::e($askUrl); ?>">
      <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
      <span>پرسش جدید</span>
    </a>
    <?php else: ?>
    <a class="qa-btn qa-btn-primary qa-wu-new" href="<?php echo Plugin::e($loginUrl); ?>">
      <span>ورود برای پرسش</span>
    </a>
    <?php endif; ?>
    <?php else: ?>
    <div class="qa-wu-head">
      <span class="qa-avatar qa-avatar-guest" aria-hidden="true">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
      </span>
      <div class="qa-wu-id">
        <span class="qa-wu-name">مهمان</span>
        <span class="qa-wu-role">وارد نشده‌اید</span>
      </div>
    </div>
    <?php /* اصلاح مهمان‌ها (نسخهٔ اصلاحی): وقتی تنظیم «پرسش مهمان‌ها» باز است،
       مهمان هم دکمهٔ «پرسش جدید» می‌بیند (مثل عضو واردشده)؛ در غیر این صورت
       همان دکمهٔ ورود نشان داده می‌شود. پیش از این، برای مهمان همیشه فقط
       دکمهٔ «ورود به حساب» رندر می‌شد و چون دکمهٔ نوار مرتب‌سازی هم شرطی
       حذف می‌شد، مهمان هیچ راهی برای باز کردن فرم پرسش نداشت. */ ?>
    <?php if ($canAsk): ?>
    <p class="qa-wu-note">بدون ورود هم می‌توانید پرسش بپرسید یا پاسخ بدهید؛ برای پیگیری پرسش‌هایتان می‌توانید وارد حساب شوید.</p>
    <a class="qa-btn qa-btn-primary qa-wu-new" href="<?php echo Plugin::e($askUrl); ?>">
      <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
      <span>پرسش جدید</span>
    </a>
    <?php else: ?>
    <p class="qa-wu-note">برای پرسیدن و پاسخ‌دادن، وارد حساب خود شوید یا ثبت‌نام کنید.</p>
    <a class="qa-btn qa-btn-primary qa-wu-new" href="<?php echo Plugin::e($loginUrl); ?>">
      <span>ورود به حساب</span>
    </a>
    <?php endif; ?>
    <?php endif; ?>
  </section>
  <?php endif; ?>

  <?php
    // ویجت دسته‌بندی‌ها — از ۱.۲.۲ جزو ویجت‌های قابل کنترل از تنظیمات است
    $activeCat = isset($catFilter) ? (int) $catFilter : 0;
    $forumUrl = Plugin::forumUrl();
    $currentSort = isset($sort) ? (string) $sort : '';
    $sortSuffix = ($currentSort !== '' && $currentSort !== 'newest') ? '?sort=' . rawurlencode($currentSort) : '';
    $sortSuffixAmp = ($currentSort !== '' && $currentSort !== 'newest') ? '&sort=' . rawurlencode($currentSort) : '';
    $allHref = $forumUrl . $sortSuffix;
  ?>
  <?php if (in_array('categories', $widgets, true) && (!empty($sidebarCategories) || $canManage)): ?>
  <section class="qa-widget qa-widget-categories" aria-label="دسته‌بندی‌ها">
    <h2 class="qa-widget-title">
      <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"></path></svg>
      دسته‌بندی‌ها
      <?php if ($canManage): ?>
      <a class="qa-widget-title-action" href="<?php echo Plugin::e($categoryAdminUrl); ?>" data-tooltip="مدیریت دسته‌ها" aria-label="مدیریت دسته‌ها">
        <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
      </a>
      <?php endif; ?>
    </h2>
    <ul class="qa-cat-nav">
      <li<?php echo $activeCat === 0 ? ' class="is-active"' : ''; ?>>
        <a href="<?php echo Plugin::e($allHref); ?>" class="qa-cat-nav-link">
          <span class="qa-cat-nav-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"></path></svg>
          </span>
          <span class="qa-cat-nav-name">همه دسته‌ها</span>
          <span class="qa-cat-nav-count" aria-hidden="true"></span>
        </a>
      </li>
      <?php foreach ($sidebarCategories as $cat): ?>
        <?php
          $catHref = $forumUrl . '?cat=' . (int) $cat['id'] . $sortSuffixAmp;
          $styleAttr = $cat['color'] !== '' ? ' style="--cat-color:' . Plugin::e($cat['color']) . '"' : '';
          // ۲.۲.۰ — نشان قفل برای دسته‌های قفل‌شده
          $catLocked = !empty($cat['locked']);
        ?>
      <li<?php echo $activeCat === (int) $cat['id'] ? ' class="is-active"' : ''; ?><?php echo $styleAttr; ?>>
        <a href="<?php echo Plugin::e($catHref); ?>" class="qa-cat-nav-link"<?php echo $catLocked ? ' data-tooltip="دستهٔ قفل‌شده — نوشتن فقط برای مدیر"' : ''; ?>>
          <span class="qa-cat-nav-icon" aria-hidden="true"><?php echo $cat['iconSvg']; ?></span>
          <span class="qa-cat-nav-name"><?php echo Plugin::e($cat['name']); ?><?php if ($catLocked): ?>
            <svg class="qa-cat-lock-ico" viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
          <?php endif; ?></span>
          <span class="qa-cat-nav-count"><?php echo Plugin::faDigits((int) $cat['topicCount']); ?></span>
        </a>
      </li>
      <?php endforeach; ?>
    </ul>
  </section>
  <?php endif; ?>

  <?php if (in_array('stats', $widgets, true)): ?>
  <section class="qa-widget qa-widget-stats">
    <h2 class="qa-widget-title">
      <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
      آمار انجمن
    </h2>
    <ul class="qa-stat-list">
      <li><span>موضوع</span><b><?php echo Plugin::faDigits($forumStats['questions']); ?></b></li>
      <li><span>پاسخ</span><b><?php echo Plugin::faDigits($forumStats['answers']); ?></b></li>
      <li><span>اعضا</span><b><?php echo Plugin::faDigits($forumStats['members']); ?></b></li>
    </ul>
  </section>
  <?php endif; ?>

  <?php if (in_array('members', $widgets, true) && !empty($latestMembers)): ?>
  <section class="qa-widget qa-widget-members">
    <h2 class="qa-widget-title">
      <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M22 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
      آخرین اعضا
    </h2>
    <div class="qa-members-grid">
      <?php foreach ($latestMembers as $m): ?>
      <?php
        $mAvatar = Plugin::avatar((string) $m['name'], (string) $m['mail']);
        $mTooltip = Plugin::e($m['name']) . ' — عضو شده ' . Plugin::faRelative((int) $m['created']);
        if ($showProfile && !empty($m['profileUrl'])):
      ?>
      <a class="qa-member-card" href="<?php echo Plugin::e($m['profileUrl']); ?>"
         data-tooltip="<?php echo $mTooltip; ?>"
         aria-label="<?php echo Plugin::e($m['name']); ?>">
        <?php echo $mAvatar; ?>
        <span class="qa-member-name"><?php echo Plugin::e($m['name']); ?></span>
      </a>
      <?php else: ?>
      <span class="qa-member-card" data-tooltip="<?php echo $mTooltip; ?>">
        <?php echo $mAvatar; ?>
        <span class="qa-member-name"><?php echo Plugin::e($m['name']); ?></span>
      </span>
      <?php endif; ?>
      <?php endforeach; ?>
    </div>
  </section>
  <?php endif; ?>

  <?php if (in_array('auth', $widgets, true)): ?>
  <section class="qa-widget qa-widget-auth">
    <h2 class="qa-widget-title">
      <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
      حساب کاربری
    </h2>
    <?php if ($me !== null): ?>
    <div class="qa-auth-row">
      <?php if ($showProfile): ?>
      <a class="qa-btn qa-btn-ghost qa-auth-btn" href="<?php echo Plugin::e($me['profileUrl']); ?>">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
        <span>پروفایل من</span>
      </a>
      <?php endif; ?>
      <a class="qa-btn qa-btn-ghost qa-auth-btn" href="<?php echo Plugin::e($logoutUrl); ?>">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
        <span>خروج</span>
      </a>
    </div>
    <?php else: ?>
    <div class="qa-auth-row">
      <a class="qa-btn qa-btn-primary qa-auth-btn" href="<?php echo Plugin::e($loginUrl); ?>">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path><polyline points="10 17 15 12 10 7"></polyline><line x1="15" y1="12" x2="3" y2="12"></line></svg>
        <span>ورود</span>
      </a>
      <?php if ($allowRegister): ?>
      <a class="qa-btn qa-btn-ghost qa-auth-btn" href="<?php echo Plugin::e($registerUrl); ?>">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="20" y1="8" x2="20" y2="14"></line><line x1="23" y1="11" x2="17" y2="11"></line></svg>
        <span>ثبت‌نام</span>
      </a>
      <?php endif; ?>
    </div>
    <?php endif; ?>
  </section>
  <?php endif; ?>

</aside>
<?php endif; ?>
