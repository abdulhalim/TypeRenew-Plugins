<?php

use TypechoPlugin\Forum\Plugin;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$qaPageKind = 'messages';
include __DIR__ . '/header.php';
include __DIR__ . '/sortbar.php';

$v = $pmView;
$stats = $pmStats;
?>
<div class="qa-layout">
<div class="qa-content">

<?php if ($banner !== null): ?>
<?php $bannerWait = isset($banner[2]) ? (int) $banner[2] : 0; ?>
<div class="qa-banner is-<?php echo Plugin::e($banner[1]); ?>" role="status"<?php echo $bannerWait > 0 ? ' data-wait-banner="' . $bannerWait . '"' : ''; ?>>
  <p>
    <?php echo Plugin::e($banner[0]); ?>
  </p>
  <button type="button" class="qa-banner-close" aria-label="بستن پیام">&times;</button>
</div>
<?php endif; ?>

<section class="qa-pm">
  <header class="qa-pm-head">
    <h1 class="qa-pm-title">
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
      <?php if ($v['mode'] === 'view'): ?>
        مشاهدهٔ پیام خصوصی
      <?php elseif ($v['mode'] === 'compose'): ?>
        پیام خصوصی جدید
      <?php elseif ($v['box'] === 'sent'): ?>
        پیام‌های ارسال‌شده
      <?php elseif ($v['box'] === 'blocked'): ?>
        فهرست بلاک‌شوندگان
      <?php else: ?>
        صندوق پیام‌های خصوصی
      <?php endif; ?>
    </h1>
    <div class="qa-pm-head-actions">
      <?php /* (۲.۱.۰ موقتاً غیرفعال) دکمه پیام جدید مخفی شد تا ارسال PM فعال شود */ ?>
    </div>
  </header>

  <?php /* تب‌ها + آمار صندوق */ ?>
  <?php
    // URL بازگشت در حالت view — به صندوق مرجع (ارسال یا دریافت) برمی‌گردد.
    $backBox = $v['box'] === 'sent' ? 'sent' : 'inbox';
    $backUrl = $v['box'] === 'sent' ? $sentUrl : $inboxUrl;
    // شمار کاربران مسدودشده — فقط برای badge تب مسدودها
    $blockedCount = Plugin::blockedUsers($me !== null ? (int) $me['uid'] : 0);
    $blockedCount = is_array($blockedCount) ? count($blockedCount) : 0;
  ?>
  <div class="qa-pm-tabs-bar">
    <a class="qa-sort-btn<?php echo $v['box'] === 'inbox' ? ' is-active' : ''; ?>"
       href="<?php echo Plugin::e($inboxUrl); ?>"<?php echo $v['box'] === 'inbox' ? ' aria-current="page"' : ''; ?>>
      <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="22 12 16 12 14 15 10 15 8 12 2 12"></polyline><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"></path></svg>
      <span>صندوق دریافت</span>
      <?php if ($stats['inboxUnread'] > 0): ?>
      <span class="qa-sort-badge qa-sort-badge-accent"><?php echo Plugin::faDigits($stats['inboxUnread']); ?></span>
      <?php endif; ?>
    </a>
    <a class="qa-sort-btn<?php echo $v['box'] === 'sent' ? ' is-active' : ''; ?>"
       href="<?php echo Plugin::e($sentUrl); ?>"<?php echo $v['box'] === 'sent' ? ' aria-current="page"' : ''; ?>>
      <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
      <span>صندوق ارسال</span>
    </a>
    <a class="qa-sort-btn<?php echo $v['box'] === 'blocked' ? ' is-active' : ''; ?>"
       href="<?php echo Plugin::e($blockedUrl); ?>"<?php echo $v['box'] === 'blocked' ? ' aria-current="page"' : ''; ?>>
      <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"></line></svg>
      <span>مسدود شده‌ها</span>
      <?php if ($blockedCount > 0): ?>
      <span class="qa-sort-badge"><?php echo Plugin::faDigits($blockedCount); ?></span>
      <?php endif; ?>
    </a>
    <span class="qa-pm-quota" data-tooltip="سقف صندوق پیام شما">
      <b><?php echo Plugin::faDigits($stats['inboxTotal']); ?></b>
      <span>از</span>
      <b><?php echo Plugin::faDigits($stats['inboxLimit']); ?></b>
    </span>
  </div>

  <?php /* ============ حالت مشاهدهٔ یک پیام ============ */ ?>
  <?php if ($v['mode'] === 'view'): ?>
    <?php $msg = $v['message']; ?>
    <?php
      // (۲.۱.۰) فقط طرف مقابل نمایش داده می‌شود:
      //  - اگر گیرنده‌ایم → فرستنده طرف مقابل است.
      //  - اگر فرستنده‌ایم → گیرنده طرف مقابل است.
      $myUid = (int) ($me['uid'] ?? 0);
      $isSender = (int) $msg['sender_id'] === $myUid;
      $peer = $isSender ? $msg['recipient'] : $msg['sender'];
      $peerName = $peer ? $peer['displayName'] : '—';
      $peerMail = $peer ? $peer['mail'] : '';
      $peerRole = $isSender ? 'گیرنده' : 'فرستنده';
    ?>
    <article class="qa-pm-view">
      <header class="qa-pm-view-head">
        <h2 class="qa-pm-view-subject"><?php echo Plugin::e($msg['subject']); ?></h2>
        <div class="qa-pm-view-meta">
          <span class="qa-pm-view-from">
            <?php echo Plugin::avatar($peerName, $peerMail); ?>
            <span>
              <span class="qa-pm-from-name"><?php echo Plugin::e($peerName); ?></span>
              <span class="qa-pm-from-role"><?php echo Plugin::e($peerRole); ?></span>
            </span>
          </span>
          <time class="qa-pm-view-time" datetime="<?php echo date('c', (int) $msg['created']); ?>"><?php echo Plugin::faRelative((int) $msg['created']); ?></time>
        </div>
      </header>
      <div class="qa-pm-view-body">
        <?php echo Plugin::renderText((string) $msg['body']); ?>
      </div>
      <footer class="qa-pm-view-actions">
        <a class="qa-btn qa-btn-ghost" href="<?php echo Plugin::e($backUrl); ?>">بازگشت</a>
        <?php /* (۲.۱.۰ موقتاً غیرفعال) دکمه پاسخ مخفی شد */ ?>
        <?php /* بلاک فرستنده — فقط اگر گیرنده پیام باشیم */ ?>
        <?php if ((int) $msg['recipient_id'] === (int) $me['uid'] && !empty($msg['sender'])): ?>
          <?php if (!Plugin::isBlocked((int) $me['uid'], (int) $msg['sender']['uid'])): ?>
        <form method="post" action="<?php echo Plugin::e($actionUrl); ?>" class="qa-pm-inline-form">
          <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
          <input type="hidden" name="mode" value="pm-block">
          <input type="hidden" name="blocked_id" value="<?php echo (int) $msg['sender']['uid']; ?>">
          <button type="submit" class="qa-btn qa-btn-ghost is-danger" data-confirm="آیا از بلاک کردن این کاربر مطمئن هستید؟">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"></line></svg>
            <span>بلاک فرستنده</span>
          </button>
        </form>
          <?php else: ?>
        <form method="post" action="<?php echo Plugin::e($actionUrl); ?>" class="qa-pm-inline-form">
          <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
          <input type="hidden" name="mode" value="pm-unblock">
          <input type="hidden" name="blocked_id" value="<?php echo (int) $msg['sender']['uid']; ?>">
          <button type="submit" class="qa-btn qa-btn-ghost">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"></line></svg>
            <span>رفع بلاک</span>
          </button>
        </form>
          <?php endif; ?>
        <?php endif; ?>
        <form method="post" action="<?php echo Plugin::e($actionUrl); ?>" class="qa-pm-inline-form">
          <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
          <input type="hidden" name="mode" value="pm-delete">
          <input type="hidden" name="id" value="<?php echo (int) $msg['id']; ?>">
          <button type="submit" class="qa-btn qa-btn-ghost is-danger" data-confirm="این پیام حذف شود؟">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
            <span>حذف</span>
          </button>
        </form>
      </footer>
    </article>

  <?php /* ============ حالت compose — موقتاً غیرفعال ============ */ ?>
  <?php elseif ($v['mode'] === 'compose'): ?>
    <div class="qa-banner is-warn" role="status">
      <p>ارسال پیام خصوصی موقتاً غیرفعال است. لطفاً بعداً تلاش کنید.</p>
    </div>
    <div style="text-align:center; padding: 24px;">
      <a class="qa-btn qa-btn-primary" href="<?php echo Plugin::e($inboxUrl); ?>">بازگشت به صندوق دریافت</a>
    </div>

  <?php /* ============ حالت بلاک‌شوندگان ============ */ ?>
  <?php elseif ($v['box'] === 'blocked'): ?>
    <div class="qa-pm-list">
      <?php if (empty($v['rows'])): ?>
      <div class="qa-empty qa-empty-pm">
        <span class="qa-empty-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" width="42" height="42" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"></line></svg>
        </span>
        <p class="qa-empty-title">هیچ کاربر مسدودی ندارید</p>
        <p class="qa-empty-subtitle">با مسدود کردن فرستنده‌های مزاحم، آن‌ها دیگر نمی‌توانند به شما پیام بفرستند.</p>
      </div>
      <?php else: ?>
      <ul class="qa-pm-list-ul">
        <?php foreach ($v['rows'] as $r): ?>
        <li class="qa-pm-blocked-row">
          <a class="qa-pm-blocked-avatar" href="<?php echo Plugin::e($r['profileUrl']); ?>">
            <?php echo Plugin::avatar($r['name'], $r['mail']); ?>
          </a>
          <div class="qa-pm-blocked-info">
            <a class="qa-pm-blocked-name" href="<?php echo Plugin::e($r['profileUrl']); ?>"><?php echo Plugin::e($r['name']); ?></a>
            <time class="qa-pm-blocked-time"><?php echo Plugin::faRelative((int) $r['blockedAt']); ?></time>
          </div>
          <form method="post" action="<?php echo Plugin::e($actionUrl); ?>" class="qa-pm-inline-form">
            <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
            <input type="hidden" name="mode" value="pm-unblock">
            <input type="hidden" name="blocked_id" value="<?php echo (int) $r['uid']; ?>">
            <button type="submit" class="qa-btn qa-btn-ghost qa-btn-sm">رفع مسدودی</button>
          </form>
        </li>
        <?php endforeach; ?>
      </ul>
      <?php endif; ?>
    </div>

  <?php /* ============ حالت صندوق دریافتی یا ارسالی ============ */ ?>
  <?php else: ?>
    <div class="qa-pm-list">
      <?php if (empty($v['rows'])): ?>
      <div class="qa-empty qa-empty-pm">
        <span class="qa-empty-icon" aria-hidden="true">
          <?php if ($v['box'] === 'sent'): ?>
          <svg viewBox="0 0 24 24" width="42" height="42" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
          <?php else: ?>
          <svg viewBox="0 0 24 24" width="42" height="42" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="22 12 16 12 14 15 10 15 8 12 2 12"></polyline><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"></path></svg>
          <?php endif; ?>
        </span>
        <p class="qa-empty-title">
          <?php if ($v['box'] === 'sent'): ?>
          هنوز پیامی ارسال نکرده‌اید
          <?php else: ?>
            صندوق پیام خصوصی شما خالی است
          <?php endif; ?>
        </p>
        <p class="qa-empty-subtitle">با کلیک روی دکمهٔ «پیام جدید» اولین پیام خود را بفرستید.</p>
      </div>
      <?php else: ?>
      <?php /* (۲.۱.۰) نوار ابزار حذف دسته‌جمعی */ ?>
      <div class="qa-pm-batch-bar" id="qa-pm-batch-bar">
        <label class="qa-pm-select-all">
          <input type="checkbox" id="qa-pm-select-all-chk" aria-label="انتخاب همه">
          <span>انتخاب همه</span>
        </label>
        <button type="button" class="qa-btn qa-btn-ghost is-danger qa-btn-sm qa-pm-batch-del" id="qa-pm-batch-del" disabled>
          <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
          <span>حذف انتخاب‌شده‌ها</span>
        </button>
        <span class="qa-pm-batch-count" id="qa-pm-batch-count" hidden></span>
      </div>
      <ul class="qa-pm-list-ul">
        <?php foreach ($v['rows'] as $r): ?>
        <?php
          // (۲.۳.۰) نام و آواتار طرف مقابل — در صندوق دریافت: فرستنده؛ در صندوق ارسال: گیرنده
          $peerName = $v['box'] === 'sent' ? ($r['toName'] ?? '—') : ($r['fromName'] ?? '—');
          $peerMail = $v['box'] === 'sent' ? ($r['toMail'] ?? '') : ($r['fromMail'] ?? '');
        ?>
        <li class="qa-pm-row<?php echo (int) $r['is_read'] === 0 ? ' is-unread' : ''; ?>" data-pm-id="<?php echo (int) $r['id']; ?>">
          <label class="qa-pm-row-check">
            <input type="checkbox" class="qa-pm-chk" value="<?php echo (int) $r['id']; ?>" aria-label="انتخاب این پیام">
          </label>
          <a class="qa-pm-row-main" href="<?php echo Plugin::e($r['url']); ?>">
            <span class="qa-pm-row-from">
              <?php echo Plugin::avatar($peerName, $peerMail); ?>
              <span class="qa-pm-row-from-name"><?php echo Plugin::e($peerName); ?></span>
            </span>
            <span class="qa-pm-row-subject"><?php echo Plugin::e($r['subject'] !== '' ? $r['subject'] : '(بدون موضوع)'); ?></span>
            <time class="qa-pm-row-time"><?php echo Plugin::faRelative((int) $r['created']); ?></time>
            <?php if ((int) $r['is_read'] === 0): ?>
            <span class="qa-pm-row-dot" aria-label="خوانده‌نشده"></span>
            <?php endif; ?>
          </a>
          <form method="post" action="<?php echo Plugin::e($actionUrl); ?>" class="qa-pm-inline-form">
            <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
            <input type="hidden" name="mode" value="pm-delete">
            <input type="hidden" name="id" value="<?php echo (int) $r['id']; ?>">
            <button type="submit" class="qa-pm-row-del" data-confirm="این پیام حذف شود؟" aria-label="حذف پیام">
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
            </button>
          </form>
        </li>
        <?php endforeach; ?>
      </ul>
      <?php endif; ?>
    </div>

    <?php /* صفحه‌بندی */ ?>
    <?php if ($v['pages'] > 1): ?>
    <nav class="qa-pagination" aria-label="صفحه‌بندی پیام‌ها">
      <?php if ($v['page'] > 1): ?>
      <a class="qa-page-btn" href="<?php echo Plugin::e($pageUrl($v['page'] - 1)); ?>" rel="prev">قبلی</a>
      <?php else: ?>
      <span class="qa-page-btn is-disabled" aria-hidden="true">قبلی</span>
      <?php endif; ?>
      <?php
        $from = max(1, $v['page'] - 2);
        $to = min($v['pages'], $from + 4);
        $from = max(1, $to - 4);
      ?>
      <?php for ($p = $from; $p <= $to; $p++): ?>
        <?php if ($p == $v['page']): ?>
        <span class="qa-page-btn is-current" aria-current="page"><?php echo Plugin::faDigits($p); ?></span>
        <?php else: ?>
        <a class="qa-page-btn" href="<?php echo Plugin::e($pageUrl($p)); ?>"><?php echo Plugin::faDigits($p); ?></a>
        <?php endif; ?>
      <?php endfor; ?>
      <?php if ($v['page'] < $v['pages']): ?>
      <a class="qa-page-btn" href="<?php echo Plugin::e($pageUrl($v['page'] + 1)); ?>" rel="next">بعدی</a>
      <?php else: ?>
      <span class="qa-page-btn is-disabled" aria-hidden="true">بعدی</span>
      <?php endif; ?>
    </nav>
    <?php endif; ?>
  <?php endif; ?>
</section>

</div>
<?php include __DIR__ . '/sidebar.php'; ?>
</div>
