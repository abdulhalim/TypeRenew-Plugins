<?php

use TypechoPlugin\Forum\Plugin;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}


$qaPageKind = $qaPageKind ?? 'list';
$qaCanAsk = ($guestAsk || $hasLogin) && $commentsOpen && empty($viewerBan);
$qaSearchValue = isset($search) ? (string) $search : '';
$qaIsSearch = $qaSearchValue !== '';
$qaAskOpen = !empty($askOpen);
$qaMyName = $me !== null ? (string) $me['name'] : '';
$qaMyRole = $me !== null
    ? ($me['group'] === 'administrator' ? 'مدیر' : ($me['group'] === 'editor' ? 'ویراستار' : 'عضو'))
    : '';
// امکان جایگزینی عنوان/توضیح سربرگ در صفحات خاص (مثلاً مدیریت دسته‌ها)
$qaHeaderTitle = $qaHeaderTitle ?? $forumTitle;
$qaHeaderIntro = trim((string) ($qaHeaderIntro ?? $forumIntro));
// رنگ سربرگ — خالی یعنی پیروی از رنگ/گرادیان پوسته (۲.۰.۰)
$qaHeaderColor = Plugin::headerColor();

// محاسبه آیتم‌های منوی کاربر (۲.۱.۰) — ویرایش پروفایل، پیام خصوصی، پنل مدیریت
$qaMyUid = $me !== null ? (int) $me['uid'] : 0;
$qaProfileEditHref = $qaMyUid > 0 ? Plugin::profileEditUrl($qaMyUid) : '';
$qaPmHref = '';
$qaPmUnread = 0;
// دسترسی به پنل مدیریت TypeRenew (contributor و بالاتر — مدیر/ویراستار/نویسنده)
$qaCanAccessAdmin = Plugin::canAccessAdminPanel();
$qaAdminPanelHref = $qaCanAccessAdmin ? Plugin::siteAdminUrl() : '';
// دسترسی مدیر اصلی به پنل انجمن ساز (Forum/Panel.php)
$qaCanAccessForumAdmin = Plugin::isAdministrator();
$qaForumAdminHref = $qaCanAccessForumAdmin ? Plugin::adminPanelUrl() : '';

// (۲.۱.۰) تعیین active state برای آیتم‌های منوی کشویی
$qaCurrentUri = trim((string) ($_SERVER['REQUEST_URI'] ?? ''), '/');
$qaCurrentPath = trim((string) ($_SERVER['PATH_INFO'] ?? ''), '/');
// نشانی فعلی برای مقایسه
$qaIsOnProfileEdit = $qaPageKind === 'profile_edit'
    || (str_contains($qaCurrentPath, '/forum/u/') && str_contains($qaCurrentPath, '/edit'))
    || substr($qaCurrentUri, -5) === '/edit';
$qaIsOnMessages = $qaPageKind === 'messages'
    || str_contains($qaCurrentPath, 'forum/messages');
$qaIsOnForumAdmin = str_contains($qaCurrentUri, 'extending.php')
    && str_contains($qaCurrentUri, 'Forum/Panel.php');
$qaIsOnSiteAdmin = (str_contains($qaCurrentUri, '/admin/') || strpos($qaCurrentPath, 'admin/') === 0)
    && !$qaIsOnForumAdmin;

// ۲.۲.۰ — بلاک اداری بازدیدکننده (تیکر خبری حذف شد)
$qaViewerBan = $viewerBan ?? null;
?>
<?php if ($qaViewerBan !== null): ?>
<!-- ۲.۲.۰ — نوار هشدار بلاک اداری برای کاربر مسدود -->
<div class="qa-ban-bar" role="alert">
  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"></line></svg>
  <span>حساب شما <?php echo Plugin::e(Plugin::banUntilText($qaViewerBan)); ?> از نوشتن در انجمن مسدود است.<?php echo trim((string) $qaViewerBan['reason']) !== '' ? ' دلیل: ' . Plugin::e(trim((string) $qaViewerBan['reason'])) : ''; ?></span>
</div>
<?php endif; ?>
<header class="qa-fhead"<?php echo $qaHeaderColor !== '' ? ' style="--qa-grad:' . Plugin::e($qaHeaderColor) . '"' : ''; ?>>
  <div class="qa-fhead-row">
    <div class="qa-fhead-main">
      <span class="qa-fhead-mark" aria-hidden="true">
        <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"></path><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path><path d="M12 17h.01"></path></svg>
      </span>
      <div class="qa-fhead-id">
        <h1 class="qa-fhead-title"><?php echo Plugin::e($qaHeaderTitle); ?></h1>
        <?php if ($qaHeaderIntro !== ''): ?>
        <p class="qa-fhead-intro"><?php echo Plugin::e($qaHeaderIntro); ?></p>
        <?php endif; ?>
      </div>
    </div>

    <div class="qa-fhead-user">
      <?php if ($me !== null): ?>
      <div class="qa-usermenu" id="qa-usermenu">
        <?php /* ۲.۲.۰ — زنگولهٔ اعلان‌ها وقتی سایدبار پنهان است، کنار دکمهٔ منوی کاربر در هدر نمایش داده می‌شود */ ?>
        <?php if (!$showSidebar && !empty($myNotifs) || (!$showSidebar && $me !== null)): ?>
        <?php
          $qaHdrNotifToken = isset($token) ? (string) $token : '';
          $qaHdrNotifAction = Plugin::postUrl();
          $qaHdrUnread = (int) ($unreadNotifs ?? 0);
          $qaHdrNotifs = isset($myNotifs) && is_array($myNotifs) ? $myNotifs : [];
          // (۲.۳.۰) زنگولهٔ اعلان‌ها به صفحهٔ مستقل اعلان‌ها پیوند می‌خورد؛
          // popup زیرین طبق طراحی «درونی» باقی می‌ماند اما از زنگوله باز نمی‌شود.
          $qaHdrNotifUrl = Plugin::notificationsUrl();
        ?>
        <a href="<?php echo Plugin::e($qaHdrNotifUrl); ?>"
           class="qa-notif-bell qa-notif-bell--header<?php echo $qaHdrUnread > 0 ? ' has-unread is-ringing' : ''; ?>"
           id="qa-notif-bell-header"
           aria-label="اعلان‌ها"
           data-notif-page="1"
           data-tooltip="<?php echo $qaHdrUnread > 0 ? Plugin::faDigits($qaHdrUnread) . ' اعلان خوانده‌نشده' : 'اعلان‌ها'; ?>">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
          <span class="qa-notif-bell-badge" data-notif-badge="<?php echo $qaHdrUnread; ?>"><?php echo Plugin::faDigits($qaHdrUnread); ?></span>
        </a>
        <div class="qa-notif-pop qa-notif-pop--header" id="qa-notif-pop-header" hidden role="dialog" aria-label="اعلان‌ها">
          <div class="qa-notif-pop-head">
            <span>اعلان‌ها</span>
            <?php if ($qaHdrUnread > 0): ?>
            <form method="post" action="<?php echo Plugin::e($qaHdrNotifAction); ?>" class="qa-notif-mark-form">
              <input type="hidden" name="_" value="<?php echo Plugin::e($qaHdrNotifToken); ?>">
              <input type="hidden" name="mode" value="read-notifs">
              <button type="submit" class="qa-notif-mark-btn">خواندن همه</button>
            </form>
            <?php endif; ?>
          </div>
          <?php if (!empty($qaHdrNotifs)): ?>
          <ul class="qa-notif-list" id="qa-notif-list-header">
            <?php foreach (array_slice($qaHdrNotifs, 0, 10) as $n): ?>
              <?php
                if ($n['type'] === 'pm') {
                  $notifUrl = Plugin::messageViewUrl((int) $n['coid']);
                } else {
                  $notifTopicId = (int) $n['topic_id'];
                  if ($notifTopicId < 1) {
                    $notifTopicId = Plugin::topicIdForItem((int) $n['coid']);
                  }
                  $notifUrl = Plugin::threadUrl($notifTopicId) . '#c' . (int) $n['coid'];
                }
              ?>
            <li class="qa-notif-item<?php echo $n['read'] ? ' is-read' : ' is-unread'; ?>"
                data-notif-id="<?php echo (int) $n['id']; ?>">
              <a href="<?php echo Plugin::e($notifUrl); ?>" class="qa-notif-link">
                <span class="qa-notif-icon" aria-hidden="true">
                  <?php if ($n['type'] === 'best'): ?>
                  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                  <?php elseif ($n['type'] === 'pm'): ?>
                  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                  <?php else: ?>
                  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                  <?php endif; ?>
                </span>
                <span class="qa-notif-text">
                  <span class="qa-notif-label"><?php echo Plugin::e(Plugin::notificationLabel($n['type'])); ?></span>
                  <time class="qa-notif-time"><?php echo Plugin::faRelative((int) $n['created']); ?></time>
                </span>
                <?php if (!$n['read']): ?>
                <span class="qa-notif-dot" aria-label="خوانده‌نشده"></span>
                <?php endif; ?>
              </a>
            </li>
            <?php endforeach; ?>
          </ul>
          <?php else: ?>
          <p class="qa-notif-pop-empty">اعلانی وجود ندارد.</p>
          <?php endif; ?>
        </div>
        <?php endif; ?>
        <button type="button" class="qa-usermenu-btn" id="qa-usermenu-btn"
                aria-expanded="false" aria-haspopup="true" aria-controls="qa-usermenu-pop">
          <?php echo Plugin::avatar($qaMyName, (string) $me['mail']); ?>
          <span class="qa-usermenu-id">
            <span class="qa-usermenu-name"><?php echo Plugin::e($qaMyName); ?></span>
            <span class="qa-usermenu-role"><?php echo Plugin::e($qaMyRole); ?></span>
          </span>
          <svg class="qa-usermenu-chev" viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"></path></svg>
        </button>
        <div class="qa-usermenu-pop" id="qa-usermenu-pop" hidden>
          <div class="qa-usermenu-head">
            <span class="qa-usermenu-head-name"><?php echo Plugin::e($qaMyName); ?></span>
            <span class="qa-usermenu-head-role"><?php echo Plugin::e($qaMyRole); ?></span>
          </div>
          <?php if ($showProfile): ?>
          <a class="qa-usermenu-item<?php echo $qaPageKind === 'profile' ? ' is-active' : ''; ?>" href="<?php echo Plugin::e($me['profileUrl']); ?>">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
            <span>پروفایل من</span>
          </a>
          <?php endif; ?>
          <?php if ($qaProfileEditHref !== ''): ?>
          <a class="qa-usermenu-item<?php echo $qaIsOnProfileEdit ? ' is-active' : ''; ?>" href="<?php echo Plugin::e($qaProfileEditHref); ?>">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
            <span>ویرایش پروفایل</span>
          </a>
          <?php endif; ?>
          <?php /* (۲.۱.۰) پیام خصوصی موقتاً غیرفعال */ ?>
          <?php if (false && $qaPmHref !== ''): ?>
          <a class="qa-usermenu-item<?php echo $qaIsOnMessages ? ' is-active' : ''; ?>" href="<?php echo Plugin::e($qaPmHref); ?>">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
            <span>پیام‌های خصوصی</span>
            <?php if ($qaPmUnread > 0): ?>
            <span class="qa-usermenu-badge"><?php echo Plugin::faDigits($qaPmUnread); ?></span>
            <?php endif; ?>
          </a>
          <?php endif; ?>
          <?php if ($qaForumAdminHref !== ''): ?>
          <a class="qa-usermenu-item<?php echo $qaIsOnForumAdmin ? ' is-active' : ''; ?>" href="<?php echo Plugin::e($qaForumAdminHref); ?>">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path><path d="M8 10h.01"></path><path d="M12 10h.01"></path><path d="M16 10h.01"></path></svg>
            <span>پنل انجمن‌ساز</span>
          </a>
          <?php endif; ?>
          <?php if ($qaAdminPanelHref !== ''): ?>
          <a class="qa-usermenu-item<?php echo $qaIsOnSiteAdmin ? ' is-active' : ''; ?>" href="<?php echo Plugin::e($qaAdminPanelHref); ?>">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
            <span>پنل مدیریت سایت</span>
          </a>
          <?php endif; ?>
          <a class="qa-usermenu-item is-danger" href="<?php echo Plugin::e($logoutUrl); ?>">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
            <span>خروج از حساب</span>
          </a>
        </div>
      </div>
      <?php else: ?>
      <div class="qa-fhead-guest">
        <a class="qa-fhead-gbtn is-primary" href="<?php echo Plugin::e($loginUrl); ?>">
          <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path><polyline points="10 17 15 12 10 7"></polyline><line x1="15" y1="12" x2="3" y2="12"></line></svg>
          <span>ورود</span>
        </a>
        <?php if ($allowRegister): ?>
        <a class="qa-fhead-gbtn" href="<?php echo Plugin::e($registerUrl); ?>">
          <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="20" y1="8" x2="20" y2="14"></line><line x1="23" y1="11" x2="17" y2="11"></line></svg>
          <span>ثبت‌نام</span>
        </a>
        <?php endif; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- آمار شیشه‌ای + جستجو (۲.۰.۰ — جستجو از نوار ناوبری به اینجا منتقل شد) -->
  <div class="qa-fhead-strip">
    <ul class="qa-fhead-stats" aria-label="آمار انجمن">
      <li class="qa-fhead-stat">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
        <b><?php echo Plugin::faDigits($forumStats['questions']); ?></b>
        <span>پرسش</span>
      </li>
      <li class="qa-fhead-stat">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>
        <b><?php echo Plugin::faDigits($forumStats['answers']); ?></b>
        <span>پاسخ</span>
      </li>
      <li class="qa-fhead-stat">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M22 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
        <b><?php echo Plugin::faDigits($forumStats['members']); ?></b>
        <span>عضو</span>
      </li>
    </ul>

    <form class="qa-search qa-fhead-search" method="get" action="<?php echo Plugin::e(Plugin::forumUrl()); ?>" role="search">
      <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
      <input type="search" name="q" value="<?php echo Plugin::e($qaSearchValue); ?>"
             placeholder="جستجو در پرسش‌ها…" aria-label="جستجو در پرسش‌ها" minlength="1" maxlength="100">
      <?php if ($qaIsSearch): ?>
      <button type="button" class="qa-search-clear-btn" aria-label="حذف جستجو" data-tooltip="حذف جستجو">
        <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
      </button>
      <?php endif; ?>
    </form>
  </div>
</header>
