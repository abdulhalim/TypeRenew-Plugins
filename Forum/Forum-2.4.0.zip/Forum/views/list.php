<?php

use TypechoPlugin\Forum\ForumList;
use TypechoPlugin\Forum\Plugin;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$rememberAuthor = (string) (\Typecho\Cookie::get('__typecho_remember_author') ?? '');
$rememberMail = (string) (\Typecho\Cookie::get('__typecho_remember_mail') ?? '');
$loginUrl = (string) $this->options->loginUrl;
$canAsk = ($guestAsk || $hasLogin) && $commentsOpen && empty($viewerBan);
$isSearch = $search !== '';

// سربرگ مشترک (۲.۰.۰) — بالای تمام عناصر انجمن؛ جستجو داخل سربرگ است
$qaPageKind = 'list';
include __DIR__ . '/header.php';
include __DIR__ . '/sortbar.php';
?>

<?php
  $adminPending = $canManage ? Plugin::pendingCount() : 0;
  $adminFlags = $canManage ? Plugin::totalFlagCount() : 0;
  // پنل مدیریت اختصاصی انجمن (نسخهٔ ۲ — جایگزین پنل دیدگاه‌ها)
  $adminCommentsUrl = Plugin::adminPanelUrl();
?>
<?php if ($canManage && ($adminPending > 0 || $adminFlags > 0)): ?>
<div class="qa-admin-bar" role="alert">
  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
  <div class="qa-admin-bar-text">
    <?php if ($adminPending > 0): ?>
    <a href="<?php echo Plugin::e($adminCommentsUrl); ?>" class="qa-admin-bar-link">
      <?php echo Plugin::faDigits($adminPending); ?> پرسش/پاسخ در انتظار تأیید
    </a>
    <?php endif; ?>
    <?php if ($adminPending > 0 && $adminFlags > 0): ?>
    <span class="qa-admin-bar-sep" aria-hidden="true">•</span>
    <?php endif; ?>
    <?php if ($adminFlags > 0): ?>
    <span class="qa-admin-bar-info"><?php echo Plugin::faDigits($adminFlags); ?> گزارش ثبت‌شده توسط کاربران — موارد را بررسی و اقدام مناسب را انجام دهید</span>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>

<?php if ($banner !== null): ?>
<?php
  // اگر banner شامل شمارش معکوس است (اندیس ۲ = ثانیه)، عنصر شمارش معکوس رندر می‌کنیم (۱.۵.۳)
  $bannerWait = isset($banner[2]) ? (int) $banner[2] : 0;
?>
<div class="qa-banner is-<?php echo Plugin::e($banner[1]); ?>" role="status"<?php echo $bannerWait > 0 ? ' data-wait-banner="' . $bannerWait . '"' : ''; ?>>
  <p>
    <?php echo Plugin::e($banner[0]); ?>
    <?php if ($bannerWait > 0): ?>
    <span class="qa-countdown" data-countdown="<?php echo $bannerWait; ?>" role="timer" aria-live="polite" aria-atomic="true">
      <?php echo Plugin::faDigits((string) sprintf('%02d:%02d', (int) floor($bannerWait / 60), $bannerWait % 60)); ?>
    </span>
    <?php endif; ?>
  </p>
  <button type="button" class="qa-banner-close" aria-label="بستن پیام"<?php echo $bannerWait > 0 ? ' disabled' : ''; ?>>&times;</button>
</div>
<?php endif; ?>

<div class="qa-layout">
<div class="qa-content">

<?php if ($canAsk): ?>
<section id="qa-ask" class="qa-ask"<?php echo $askOpen ? '' : ' hidden'; ?>>
  <h2 class="qa-ask-title">پرسش تازه بپرسید</h2>
  <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-form" id="qa-ask-form">
    <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
    <input type="text" name="website" value="" class="qa-hp" tabindex="-1" autocomplete="off" aria-hidden="true">

    <?php if ($hasLogin): ?>
    <p class="qa-form-identity">
      <?php echo Plugin::avatar((string) $this->user->screenName, (string) $this->user->mail); ?>
      <span>ارسال با حساب <b><?php echo Plugin::e($this->user->screenName); ?></b></span>
    </p>
    <?php else: ?>
    <div class="qa-form-row">
      <div class="qa-field">
        <label for="qa-ask-author">نام <span class="qa-req">*</span></label>
        <input type="text" id="qa-ask-author" name="author" required maxlength="150"
               placeholder="نام شما" value="<?php echo Plugin::e($rememberAuthor); ?>">
      </div>
      <div class="qa-field">
        <label for="qa-ask-mail">ایمیل<?php if ($requireMail): ?> <span class="qa-req">*</span><?php endif; ?></label>
        <input type="email" id="qa-ask-mail" name="mail" dir="ltr" placeholder="you@example.com"
               <?php echo $requireMail ? 'required' : ''; ?> value="<?php echo Plugin::e($rememberMail); ?>">
      </div>
    </div>
    <?php endif; ?>

    <div class="qa-field">
      <label for="qa-ask-title">عنوان پرسش <span class="qa-req">*</span></label>
      <input type="text" id="qa-ask-title" name="title" required maxlength="120"
             placeholder="عنوان کوتاه و واضح پرسش خود را بنویسید…"
             value="<?php echo Plugin::e((string) (\Typecho\Cookie::get('__typecho_remember_title') ?? '')); ?>">
    </div>

    <?php if (!empty($sidebarCategories)): ?>
    <?php
      // ۲.۲.۰ — دستهٔ قفل‌شده فقط برای مدیر قابل انتخاب است
      $qaCanPickLocked = !empty($canManage);
      $qaHasUnlockedCats = false;
      foreach ($sidebarCategories as $cat) {
          if (empty($cat['locked'])) { $qaHasUnlockedCats = true; }
      }
    ?>
    <div class="qa-field qa-field-category">
      <label for="qa-ask-category">دسته‌بندی <span class="qa-req">*</span></label>
      <select id="qa-ask-category" name="category" required<?php echo !$qaCanPickLocked && !$qaHasUnlockedCats ? ' disabled' : ''; ?>>
        <option value=""><?php echo $qaCanPickLocked ? '— انتخاب دسته —' : ($qaHasUnlockedCats ? '— انتخاب دسته —' : '— همهٔ دسته‌ها قفل است —'); ?></option>
        <?php foreach ($sidebarCategories as $cat): ?>
        <?php $qaCatLocked = !empty($cat['locked']); ?>
        <option value="<?php echo (int) $cat['id']; ?>"<?php echo $qaCatLocked && !$qaCanPickLocked ? ' disabled' : ''; ?>>
          <?php echo Plugin::e($cat['name']); ?><?php echo $qaCatLocked ? ' 🔒' : ''; ?>
        </option>
        <?php endforeach; ?>
      </select>
      <p class="qa-field-note"><?php echo $qaCanPickLocked
          ? 'دسته‌های دارای 🔒 قفل‌اند؛ به‌عنوان مدیر می‌توانید در آن‌ها بنویسید.'
          : ($qaHasUnlockedCats ? 'انتخاب دسته الزامی است.' : 'فعلاً دستهٔ بازِ قابل انتخاب وجود ندارد؛ از مدیر انجمن بخواهید.'); ?></p>
    </div>
    <?php endif; ?>

    <div class="qa-field">
      <label for="qa-ask-text">متن پرسش <span class="qa-req">*</span></label>
      <?php $toolbarTarget = 'qa-ask-text'; include __DIR__ . '/toolbar.php'; ?>
      <textarea id="qa-ask-text" name="text" rows="4" required maxlength="<?php echo Plugin::e($maxLen); ?>"
                placeholder="جزئیات پرسش خود را بنویسید…"><?php echo Plugin::e((string) (\Typecho\Cookie::get('__typecho_remember_text') ?? '')); ?></textarea>
      <p class="qa-field-note">متن ساده با نشانه‌گذاری [code] [url] [img] [quote].<?php if (!$hasLogin && Plugin::guestEditMinutes() > 0): ?> پس از ارسال تا <?php echo Plugin::faDigits(Plugin::guestEditMinutes()); ?> دقیقه فرصت ویرایش دارید.<?php endif; ?></p>
    </div>

    <?php if (!empty($pollsEnabled) && $hasLogin): ?>
    <div class="qa-field qa-poll-field">
      <label class="qa-poll-toggle-label">
        <input type="checkbox" id="qa-ask-poll-toggle" class="qa-poll-toggle" name="has_poll" value="1">
        افزودن نظرسنجی
      </label>
      <div id="qa-poll-options" class="qa-poll-options" hidden>
        <input type="text" name="poll_question" maxlength="200"
               placeholder="سؤال نظرسنجی…" class="qa-poll-q">
        <p class="qa-field-note">هر سطر یک گزینه. حداقل ۲، حداکثر ۸ گزینه.</p>
        <textarea name="poll_options" rows="4" maxlength="500"
                  placeholder="گزینهٔ اول&#10;گزینهٔ دوم&#10;گزینهٔ سوم…"></textarea>
      </div>
    </div>
    <?php endif; ?>

    <div class="qa-form-actions">
      <button type="submit" class="qa-btn qa-btn-primary">ارسال پرسش</button>
      <button type="button" class="qa-btn qa-btn-ghost qa-form-cancel" data-target="qa-list">لغو</button>
    </div>
  </form>
</section>
<?php endif; ?>

<?php if (!$commentsOpen): ?>
<p class="qa-closed-note">ارسال پرسش و پاسخ هم‌اکنون بسته است.</p>
<?php elseif (!$guestAsk && !$hasLogin): ?>
<p class="qa-closed-note">برای پرسیدن پرسش، <a href="<?php echo Plugin::e($loginUrl); ?>">وارد حساب خود شوید</a>.</p>
<?php endif; ?>

<div class="qa-list" id="qa-list">
<?php if (!$questions): ?>
  <?php
    // پیام وضعیت خالی متناسب با فیلتر/مرتب‌سازی فعال (۱.۵.۱)
    $emptyTitle = 'هنوز پرسشی مطرح نشده است';
    $emptyText = 'اولین پرسش را شما بپرسید؛ پاسخ‌ها زیر همان پرسش نمایش داده می‌شوند.';
    if ($isSearch) {
      $emptyTitle = 'چیزی برای «' . Plugin::e($search) . '» یافت نشد';
      $emptyText = 'عبارت دیگری را امتحان کنید یا پرسش خود را بپرسید.';
    } elseif ($sort === 'unread') {
      $emptyTitle = 'همهٔ پرسش‌ها را خوانده‌اید';
      $emptyText = 'پرسش خوانده‌نشده‌ای برای نمایش وجود ندارد.';
    } elseif ($sort === 'pending') {
      $emptyTitle = 'موردی در انتظار تأیید نیست';
      $emptyText = 'همهٔ پیام‌ها تأیید شده‌اند؛ موارد تازه پس از ثبت در همین تب ظاهر می‌شوند.';
    } elseif ($sort === 'reported') {
      $emptyTitle = 'گزارش فعالی وجود ندارد';
      $emptyText = 'در حال حاضر هیچ پرسش یا پاسخ گزارش‌شده‌ای برای رسیدگی نیست.';
    } elseif ($filterUnanswered) {
      $emptyTitle = 'همهٔ پرسش‌ها پاسخ دارند';
      $emptyText = 'در حال حاضر پرسش بی‌پاسخی برای نمایش وجود ندارد.';
    } elseif (!empty($catFilter)) {
      $activeCat = Plugin::getCategory((int) $catFilter);
      if ($activeCat !== null) {
        $emptyTitle = 'هنوز پرسشی در دستهٔ «' . $activeCat['name'] . '» ثبت نشده است';
        $emptyText = 'اولین پرسش این دسته را شما بپرسید.';
      }
    }
  ?>
  <div class="qa-empty">
    <div class="qa-empty-icon" aria-hidden="true">
      <svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path><path d="M8 9h8"></path><path d="M8 13h6"></path></svg>
    </div>
    <p class="qa-empty-title"><?php echo $emptyTitle; ?></p>
    <p class="qa-empty-text"><?php echo $emptyText; ?></p>
  </div>
<?php else: ?>
  <?php foreach ($questions as $q): ?>
    <?php
        [$qTitle, $qRest] = Plugin::splitQuestion((string) $q['text']);
        $qTitle = Plugin::stripMarkup($qTitle);
        $replies = (int) ($q['qaReplies'] ?? 0);
        $locked = !empty($q['qaLocked']);
        $pinned = !empty($q['qaPinned']);
        $tracked = !empty($q['qaTracked']);
        $hidden = !empty($q['qaHidden']);
        $hasBest = !empty($q['qaHasBest']);
        $hasPoll = !empty($q['qaHasPoll']);
        $reported = !empty($q['qaReported']);
        $waiting = !empty($q['qaWaiting']);
        $pendingReplies = (int) ($q['qaPendingReplies'] ?? 0);
        $catId = (int) ($q['qaCatId'] ?? 0);
        $cat = $catId > 0 ? Plugin::getCategory($catId) : null;
        // اگر پرسش به‌دلیل بهترین‌پاسخ قفل شده، نشان تیک سبز نشان داده می‌شود (نه قفل)
        $lockedDueBest = $locked && $hasBest;
        $views = (int) ($q['qaViews'] ?? 0);
        $lastAuthor = (string) ($q['qaLastAuthor'] ?? '');
        $itemClasses = 'qa-item';
        if ($locked) { $itemClasses .= ' is-locked'; }
        if ($pinned) { $itemClasses .= ' is-pinned'; }
        if ($tracked) { $itemClasses .= ' is-tracked'; }
        if ($hidden) { $itemClasses .= ' is-hidden'; }
        // صف تأیید (۲.۰.۰) — پرسش در انتظار یا دارای پاسخِ در انتظار
        if ($waiting) { $itemClasses .= ' is-waiting'; }
        elseif ($pendingReplies > 0) { $itemClasses .= ' is-pending-replies'; }
        // برجسته‌سازی زرد فقط برای مدیران (۱.۵.۲) — نویسنده و مهمان نمی‌بینند
        if ($reported && $canManage) { $itemClasses .= ' is-reported'; }
        // ۱.۷.۰: حالت خوانده‌نشده اکنون پاسخ‌های جدید را هم تشخیص می‌دهد —
        // آخرین فعالیت تاپیک (max زمان ساخت پرسش، آخرین پاسخ) به‌عنوان معیار استفاده می‌شود.
        // در صف تأیید، نشان خوانده‌نشده نمایش داده نمی‌شود.
        if (!$waiting && $pendingReplies === 0 && !Plugin::isRead((int) $q['coid'], (int) ($q['qaLastActivity'] ?? 0))) { $itemClasses .= ' is-unread'; }
    ?>
  <article class="<?php echo $itemClasses; ?>">
    <?php echo Plugin::avatar((string) $q['author'], (string) $q['mail']); ?>
    <div class="qa-item-main">
      <span class="qa-item-title">
        <a class="qa-item-link" href="<?php echo Plugin::e(Plugin::threadUrl((int) $q['coid'])); ?>" aria-label="<?php echo Plugin::e($qTitle); ?>">
          <?php if (!$waiting && $pendingReplies === 0 && !Plugin::isRead((int) $q['coid'], (int) ($q['qaLastActivity'] ?? 0))): ?>
          <span class="qa-unread-dot" aria-label="خوانده‌نشده" data-tooltip="خوانده‌نشده"></span>
          <?php endif; ?>
          <?php if ($waiting): ?>
          <span class="qa-wait-badge" data-tooltip="در انتظار تأیید مدیر — پس از تأیید برای همه نمایش داده می‌شود">
            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 22h14"></path><path d="M5 2h14"></path><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"></path><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"></path></svg>
          </span>
          <?php endif; ?>
          <?php if ($pendingReplies > 0): ?>
          <span class="qa-wait-badge is-reply" data-tooltip="این پرسش <?php echo Plugin::faDigits($pendingReplies); ?> پاسخ در انتظار تأیید دارد">
            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
            <b><?php echo Plugin::faDigits($pendingReplies); ?></b>
          </span>
          <?php endif; ?>
          <?php if ($pinned): ?>
          <span class="qa-pin-badge" data-tooltip="سنجاق‌شده — همیشه بالای فهرست">
            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 17v5"></path><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1z"></path></svg>
          </span>
          <?php endif; ?>
          <?php if ($locked): ?>
            <?php if ($lockedDueBest): ?>
            <span class="qa-best-badge-mini" data-tooltip="این پرسش به‌دلیل انتخاب بهترین پاسخ بسته شده است">
              <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
            </span>
            <?php else: ?>
            <span class="qa-lock-badge" data-tooltip="این پرسش قفل شده است">
              <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
            </span>
            <?php endif; ?>
          <?php endif; ?>
          <?php if ($tracked): ?>
          <span class="qa-track-badge" data-tooltip="در حال پیگیری">
            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3v5h5"></path><path d="M3.05 13A9 9 0 1 0 6 5.3L3 8"></path><path d="M12 7v5l4 2"></path></svg>
          </span>
          <?php endif; ?>
          <?php if ($hidden): ?>
          <span class="qa-hidden-badge" data-tooltip="این پرسش از دید کاربران مهمان پنهان است">
            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"></path><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"></path><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"></path><line x1="2" y1="2" x2="22" y2="22"></line></svg>
          </span>
          <?php endif; ?>
          <?php if ($hasPoll && $hasLogin): ?>
          <span class="qa-poll-badge" data-tooltip="این پرسش نظرسنجی دارد">
            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
          </span>
          <?php endif; ?>
          <?php if ($reported && $canManage): ?>
          <span class="qa-reported-badge" data-tooltip="گزارش‌شده — در انتظار رسیدگی مدیر">
            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path><line x1="4" y1="22" x2="4" y2="15"></line></svg>
          </span>
          <?php endif; ?>
          <span class="qa-item-title-text"><?php echo Plugin::e($qTitle); ?></span>
        </a>
      </span>
      <span class="qa-item-meta">
        <?php if ($cat !== null): ?>
        <a class="qa-item-cat" href="<?php echo Plugin::e(Plugin::forumUrl() . '?cat=' . (int) $cat['id']); ?>"
           data-tooltip="دسته: <?php echo Plugin::e($cat['name']); ?>"<?php echo $cat['color'] !== '' ? ' style="--cat-color:' . Plugin::e($cat['color']) . '"' : ''; ?>>
          <?php echo Plugin::categoryIconSvg($cat['icon'], 12); ?>
          <span><?php echo Plugin::e($cat['name']); ?></span>
        </a>
        <span class="qa-dot" aria-hidden="true">•</span>
        <?php endif; ?>
        <?php echo Plugin::authorLink($q); ?>
        <span class="qa-dot" aria-hidden="true">•</span>
        <time datetime="<?php echo Plugin::e(date('c', (int) $q['created'])); ?>"><?php echo Plugin::faRelative((int) $q['created']); ?></time>
        <?php if ($viewsEnabled && $views > 0): ?>
        <span class="qa-dot" aria-hidden="true">•</span>
        <span class="qa-views" data-tooltip="بازدید">
          <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-4-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
          <?php echo Plugin::faDigits($views); ?> بازدید
        </span>
        <?php endif; ?>
        <?php if ($q['qaHasReply'] && $lastAuthor !== ''): ?>
        <span class="qa-dot" aria-hidden="true">•</span>
        <span class="qa-item-last">
          آخرین پاسخ: <?php echo Plugin::authorLink(['author' => $q['qaLastAuthor'], 'authorId' => $q['qaLastAuthorId'] ?? 0]); ?>
        </span>
        <?php endif; ?>
      </span>
    </div>
    <div class="qa-item-side">
      <?php if ($waiting && $canManage): ?>
      <!-- تأیید پرسشِ در انتظار — بی‌درنگ از صف (۲.۰.۰)؛ پس از تأیید در همین صف می‌مانیم -->
      <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-approve-form">
        <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
        <input type="hidden" name="mode" value="approve">
        <input type="hidden" name="coid" value="<?php echo Plugin::e($q['coid']); ?>">
        <input type="hidden" name="back" value="queue">
        <button type="submit" class="qa-post-action qa-approve-btn"
                data-tooltip="تأیید و انتشار این پرسش برای همه"
                aria-label="تأیید این پرسش">
          <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="m9 12 2 2 4-4"></path></svg>
          <span>تأیید</span>
        </button>
      </form>
      <?php endif; ?>
      <span class="qa-count<?php echo $replies === 0 ? ' is-zero' : ''; ?>">
        <?php if ($replies > 0): ?>
        <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
        <?php endif; ?>
        <?php echo Plugin::faDigits($replies); ?> پاسخ
      </span>
      <span class="qa-activity" data-tooltip="آخرین فعالیت">
        <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
        <?php echo Plugin::faRelative((int) $q['qaLastActivity']); ?>
      </span>
    </div>
  </article>
  <?php endforeach; ?>
<?php endif; ?>
</div>

<?php if ($pages > 1): ?>
<nav class="qa-pagination" aria-label="صفحه‌بندی پرسش‌ها">
  <?php
    $pageHref = static function (int $n) use ($search, $filterUnanswered, $sort, $catFilter): string {
        return ForumList::pageUrl($n, $search, $filterUnanswered ? 'unanswered' : '', $sort, (int) ($catFilter ?? 0));
    };
  ?>
  <?php if ($page > 1): ?>
  <a class="qa-page-btn" href="<?php echo Plugin::e($pageHref($page - 1)); ?>" rel="prev">
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 18 15 12 9 6"></polyline></svg>
    <span>قبلی</span>
  </a>
  <?php else: ?>
  <span class="qa-page-btn is-disabled" aria-hidden="true">
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 18 15 12 9 6"></polyline></svg>
    <span>قبلی</span>
  </span>
  <?php endif; ?>

  <?php
  $from = max(1, $page - 2);
  $to = min($pages, $from + 4);
  $from = max(1, $to - 4);
  if ($from > 1): ?>
  <a class="qa-page-btn" href="<?php echo Plugin::e($pageHref(1)); ?>"><?php echo Plugin::faDigits(1); ?></a>
  <span class="qa-page-ellipsis" aria-hidden="true">…</span>
  <?php endif; ?>
  <?php for ($p = $from; $p <= $to; $p++): ?>
  <?php if ($p == $page): ?>
  <span class="qa-page-btn is-current" aria-current="page"><?php echo Plugin::faDigits($p); ?></span>
  <?php else: ?>
  <a class="qa-page-btn" href="<?php echo Plugin::e($pageHref($p)); ?>"><?php echo Plugin::faDigits($p); ?></a>
  <?php endif; ?>
  <?php endfor; ?>
  <?php if ($to < $pages): ?>
  <span class="qa-page-ellipsis" aria-hidden="true">…</span>
  <a class="qa-page-btn" href="<?php echo Plugin::e($pageHref($pages)); ?>"><?php echo Plugin::faDigits($pages); ?></a>
  <?php endif; ?>

  <?php if ($page < $pages): ?>
  <a class="qa-page-btn" href="<?php echo Plugin::e($pageHref($page + 1)); ?>" rel="next">
    <span>بعدی</span>
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 18 9 12 15 6"></polyline></svg>
  </a>
  <?php else: ?>
  <span class="qa-page-btn is-disabled" aria-hidden="true">
    <span>بعدی</span>
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 18 9 12 15 6"></polyline></svg>
  </span>
  <?php endif; ?>

  <span class="qa-page-info" aria-live="polite">
    <?php echo Plugin::faDigits($page); ?> / <?php echo Plugin::faDigits($pages); ?>
    <span class="qa-page-info-sep" aria-hidden="true">•</span>
    <?php echo Plugin::faDigits((int) ($totalQ ?? 0)); ?> پرسش
  </span>
</nav>
<?php elseif (isset($totalQ) && (int) $totalQ > 0): ?>
<p class="qa-page-info qa-page-info--solo" aria-live="polite">
  <?php echo Plugin::faDigits((int) $totalQ); ?> پرسش در انجمن
</p>
<?php endif; ?>

</div>
<?php include __DIR__ . '/sidebar.php'; ?>
</div>
