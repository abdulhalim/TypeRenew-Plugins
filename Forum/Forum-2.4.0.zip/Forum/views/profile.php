<?php

use TypechoPlugin\Forum\Plugin;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$tab = ($tab === 'answers') ? 'answers' : 'questions';
$baseProfileUrl = Plugin::profileUrl((int) $uid);
$questionsUrl = $baseProfileUrl;
$answersUrl = $baseProfileUrl . '?tab=answers';

// سربرگ مشترک (۲.۰.۰) — جستجو داخل سربرگ؛ نوار مرتب‌سازی همیشه دیده می‌شود
$qaPageKind = 'profile';
include __DIR__ . '/header.php';
include __DIR__ . '/sortbar.php';
?>
<div class="qa-layout">
<div class="qa-content">

<?php if ($banner !== null): ?>
<?php $bannerWait = isset($banner[2]) ? (int) $banner[2] : 0; ?>
<div class="qa-banner is-<?php echo Plugin::e($banner[1]); ?>" role="status"<?php echo $bannerWait > 0 ? ' data-wait-banner="' . $bannerWait . '"' : ''; ?>>
  <p>
    <?php echo Plugin::e($banner[0]); ?>
    <?php if ($bannerWait > 0): ?>
    <span class="qa-countdown" data-countdown="<?php echo $bannerWait; ?>" role="timer" aria-live="polite" aria-atomic="true">
      <?php echo Plugin::faDigits((string) sprintf('%02d:%02d', (int) floor($bannerWait / 60), $bannerWait % 60)); ?>
    </span>
    <?php endif; ?>
  </p>
  <button type="button" class="qa-banner-close" aria-label="بستن پیام"<?php echo $bannerWait > 0 ? ' disabled' : ''; ?>>&times;</button>
</div>
<?php endif; ?>

<section class="qa-profile">
  <?php
    // (۲.۱.۰) دکمه ویرایش پروفایل داخل qa-profile-id — مینیمال، هم‌رنگ پس‌زمینه، با آیکون چرخ‌دنده.
    // سکشن قدیمی qa-profile-edit پایین صفحه کاملاً حذف شده است.
    $isOwnProfile = $hasLogin && !empty($me) && (int) ($me['uid'] ?? 0) === (int) $uid;
    $canSendPm = $hasLogin && !$isOwnProfile && Plugin::pmEnabled();
    $myProfileEditUrl = $isOwnProfile ? Plugin::profileEditUrl((int) $uid) : '';
    $profilePmUrl = $canSendPm ? Plugin::messageComposeUrl((int) $uid) : '';
  ?>
  <header class="qa-profile-head">
    <div class="qa-profile-id">
      <?php if ($isOwnProfile && $myProfileEditUrl !== ''): ?>
      <a class="qa-profile-edit-icon" href="<?php echo Plugin::e($myProfileEditUrl); ?>"
         data-tooltip="ویرایش پروفایل" aria-label="ویرایش پروفایل">
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
      </a>
      <?php endif; ?>
      <?php echo Plugin::avatar((string) $user['displayName'], (string) $user['mail']); ?>
      <h1 class="qa-profile-name">
        <?php echo Plugin::e($user['displayName']); ?>
        <?php echo Plugin::authorBadge((int) $user['uid']); ?>
      </h1>
      <span class="qa-profile-role"><?php echo Plugin::e($user['groupLabel']); ?></span>
      <?php if (!empty($user['bio'])): ?>
      <p class="qa-profile-bio"><?php echo Plugin::e($user['bio']); ?></p>
      <?php endif; ?>
      <?php
        $social = $user['social'] ?? [];
        $hasSocial = false;
        foreach ($social as $s) { if (!empty($s)) { $hasSocial = true; break; } }
      ?>
      <?php if ($hasSocial || !empty($user['url'])): ?>
      <div class="qa-profile-social">
        <?php if (!empty($user['url'])): ?>
        <a href="<?php echo Plugin::e($user['url']); ?>" target="_blank" rel="noopener noreferrer" class="qa-social-link" data-tooltip="وب‌سایت" aria-label="وب‌سایت">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>
        </a>
        <?php endif; ?>
        <?php if (!empty($social['twitter'])): ?>
        <a href="<?php echo Plugin::e($social['twitter']); ?>" target="_blank" rel="noopener noreferrer" class="qa-social-link" data-tooltip="ایکس / توییتر" aria-label="ایکس / توییتر">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"></path></svg>
        </a>
        <?php endif; ?>
        <?php if (!empty($social['github'])): ?>
        <a href="<?php echo Plugin::e($social['github']); ?>" target="_blank" rel="noopener noreferrer" class="qa-social-link" data-tooltip="گیت‌هاب" aria-label="گیت‌هاب">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true"><path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"></path></svg>
        </a>
        <?php endif; ?>
        <?php if (!empty($social['telegram'])): ?>
        <a href="<?php echo Plugin::e($social['telegram']); ?>" target="_blank" rel="noopener noreferrer" class="qa-social-link" data-tooltip="تلگرام" aria-label="تلگرام">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"></path></svg>
        </a>
        <?php endif; ?>
        <?php if (!empty($social['instagram'])): ?>
        <a href="<?php echo Plugin::e($social['instagram']); ?>" target="_blank" rel="noopener noreferrer" class="qa-social-link" data-tooltip="اینستاگرام" aria-label="اینستاگرام">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>
        </a>
        <?php endif; ?>
        <?php if (!empty($social['linkedin'])): ?>
        <a href="<?php echo Plugin::e($social['linkedin']); ?>" target="_blank" rel="noopener noreferrer" class="qa-social-link" data-tooltip="لینکدین" aria-label="لینکدین">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"></path></svg>
        </a>
        <?php endif; ?>
        <?php if (!empty($social['youtube'])): ?>
        <a href="<?php echo Plugin::e($social['youtube']); ?>" target="_blank" rel="noopener noreferrer" class="qa-social-link" data-tooltip="یوتوب" aria-label="یوتوب">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"></path></svg>
        </a>
        <?php endif; ?>
      </div>
      <?php endif; ?>
      <p class="qa-profile-date">
        <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
        عضویت: <?php echo Plugin::e(Plugin::jalali((int) $user['created'])); ?>
      </p>
      <?php /* (۲.۱.۰ موقتاً غیرفعال) دکمه ارسال پیام خصوصی مخفی شد */ ?>
    </div>

    <div class="qa-profile-stats">
      <a class="qa-pstat" href="<?php echo Plugin::e($questionsUrl); ?>">
        <b><?php echo Plugin::faDigits($stats['questions']); ?></b>
        <span>موضوع</span>
      </a>
      <a class="qa-pstat" href="<?php echo Plugin::e($answersUrl); ?>">
        <b><?php echo Plugin::faDigits($stats['answers']); ?></b>
        <span>پاسخ</span>
      </a>
      <?php if ((int) $stats['bestAnswers'] > 0): ?>
      <a class="qa-pstat qa-pstat-best" href="<?php echo Plugin::e($answersUrl); ?>">
        <b><?php echo Plugin::faDigits($stats['bestAnswers']); ?></b>
        <span>بهترین پاسخ</span>
      </a>
      <?php endif; ?>
      <?php if (Plugin::likesEnabled()): ?>
      <span class="qa-pstat qa-pstat-likes" data-tooltip="پسندهای دریافتی روی پرسش‌ها و پاسخ‌ها">
        <b><?php echo Plugin::faDigits((string) (int) ($stats['likes'] ?? 0)); ?></b>
        <span>پسند</span>
      </span>
      <?php endif; ?>
      <span class="qa-pstat qa-pstat-score">
        <b><?php echo Plugin::faDigits($stats['score']); ?></b>
        <span>امتیاز</span>
      </span>
    </div>
  </header>

  <div class="qa-profile-tabs-bar">
    <a class="qa-sort-btn<?php echo $tab === 'questions' ? ' is-active' : ''; ?>"
       href="<?php echo Plugin::e($questionsUrl); ?>"<?php echo $tab === 'questions' ? ' aria-current="page"' : ''; ?>>
      <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
      <span>پرسش‌ها</span>
      <span class="qa-sort-badge"><?php echo Plugin::faDigits($stats['questions']); ?></span>
    </a>
    <a class="qa-sort-btn<?php echo $tab === 'answers' ? ' is-active' : ''; ?>"
       href="<?php echo Plugin::e($answersUrl); ?>"<?php echo $tab === 'answers' ? ' aria-current="page"' : ''; ?>>
      <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>
      <span>پاسخ‌ها</span>
      <span class="qa-sort-badge"><?php echo Plugin::faDigits($stats['answers']); ?></span>
    </a>
  </div>

  <div class="qa-profile-list">
    <?php if (!$rows): ?>
    <div class="qa-empty qa-empty-slim">
      <p class="qa-empty-title"><?php echo $tab === 'questions' ? 'هنوز پرسشی مطرح نکرده است' : 'هنوز پاسخی ننوشته است'; ?></p>
    </div>
    <?php elseif ($tab === 'questions'): ?>
      <?php foreach ($rows as $r): ?>
        <?php [$ttl, $rest] = Plugin::splitQuestion((string) $r['text']); ?>
        <a class="qa-profile-row" href="<?php echo Plugin::e(Plugin::threadUrl((int) $r['coid'])); ?>">
          <div class="qa-pr-main">
            <span class="qa-pr-title"><?php echo Plugin::e(Plugin::stripMarkup($ttl)); ?></span>
            <?php if ($rest !== ''): ?>
            <span class="qa-pr-excerpt"><?php echo Plugin::e(Plugin::excerpt($rest, 120)); ?></span>
            <?php endif; ?>
            <span class="qa-pr-meta">
              <time datetime="<?php echo Plugin::e(date('c', (int) $r['created'])); ?>"><?php echo Plugin::faRelative((int) $r['created']); ?></time>
            </span>
          </div>
          <div class="qa-pr-side">
            <span class="qa-count<?php echo (int) $r['replies'] === 0 ? ' is-zero' : ''; ?>">
              <?php echo Plugin::faDigits((int) $r['replies']); ?> پاسخ
            </span>
          </div>
        </a>
      <?php endforeach; ?>
    <?php else: ?>
      <?php foreach ($rows as $r): ?>
        <a class="qa-profile-row" href="<?php echo Plugin::e(Plugin::threadUrl((int) $r['parent']) . '#c' . (int) $r['coid']); ?>">
          <div class="qa-pr-main">
            <span class="qa-pr-title">
              <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>
              <?php echo Plugin::e($r['questionTitle'] !== '' ? $r['questionTitle'] : 'پرسش'); ?>
            </span>
            <span class="qa-pr-excerpt"><?php echo Plugin::e($r['excerpt']); ?></span>
            <span class="qa-pr-meta">
              <time datetime="<?php echo Plugin::e(date('c', (int) $r['created'])); ?>"><?php echo Plugin::faRelative((int) $r['created']); ?></time>
            </span>
          </div>
        </a>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <?php if ($pages > 1): ?>
  <nav class="qa-pagination" aria-label="صفحه‌بندی فهرست">
    <?php if ($page > 1): ?>
    <a class="qa-page-btn" href="<?php echo Plugin::e($pageUrl($page - 1)); ?>" rel="prev">قبلی</a>
    <?php else: ?>
    <span class="qa-page-btn is-disabled" aria-hidden="true">قبلی</span>
    <?php endif; ?>

    <?php
    $from = max(1, $page - 2);
    $to = min($pages, $from + 4);
    $from = max(1, $to - 4);
    if ($from > 1): ?>
    <a class="qa-page-btn" href="<?php echo Plugin::e($pageUrl(1)); ?>">۱</a>
    <span class="qa-page-ellipsis" aria-hidden="true">…</span>
    <?php endif; ?>
    <?php for ($p = $from; $p <= $to; $p++): ?>
    <?php if ($p == $page): ?>
    <span class="qa-page-btn is-current" aria-current="page"><?php echo Plugin::faDigits($p); ?></span>
    <?php else: ?>
    <a class="qa-page-btn" href="<?php echo Plugin::e($pageUrl($p)); ?>"><?php echo Plugin::faDigits($p); ?></a>
    <?php endif; ?>
    <?php endfor; ?>
    <?php if ($to < $pages): ?>
    <span class="qa-page-ellipsis" aria-hidden="true">…</span>
    <a class="qa-page-btn" href="<?php echo Plugin::e($pageUrl($pages)); ?>"><?php echo Plugin::faDigits($pages); ?></a>
    <?php endif; ?>

    <?php if ($page < $pages): ?>
    <a class="qa-page-btn" href="<?php echo Plugin::e($pageUrl($page + 1)); ?>" rel="next">بعدی</a>
    <?php else: ?>
    <span class="qa-page-btn is-disabled" aria-hidden="true">بعدی</span>
    <?php endif; ?>
  </nav>
  <?php endif; ?>

  <?php
    // (۲.۱.۰) سکشن qa-profile-edit از اینجا حذف شد.
    // ویرایش پروفایل اکنون در صفحهٔ مستقل forum/u/{uid}/edit انجام می‌شود
    // که دکمهٔ گوشه بالا-چف صفحۀ پروفایل به آن هدایت می‌کند.
    // فقط پیام وضعیت ذخیره/خطا در صورت بازگشت از صفحهٔ ویرایش نمایش داده می‌شود.
    $isOwnProfile = $hasLogin && !empty($me) && (int) ($me['uid'] ?? 0) === (int) $uid;
    $profileSaved = (string) ($this->request->get('profile-saved') ?? '') === '1';
    $profileError = (string) ($this->request->get('profile-error') ?? '') === '1';
  ?>
  <?php if ($isOwnProfile && ($profileSaved || $profileError)): ?>
  <div class="qa-banner <?php echo $profileSaved ? 'is-ok' : 'is-error'; ?>" role="status">
    <p>
      <?php if ($profileSaved): ?>
      پروفایل شما ذخیره شد.
      <?php else: ?>
      ذخیرهٔ پروفایل ممکن نشد؛ دوباره تلاش کنید.
      <?php endif; ?>
    </p>
    <button type="button" class="qa-banner-close" aria-label="بستن پیام">&times;</button>
  </div>
  <?php endif; ?>
</section>

</div>
<?php include __DIR__ . '/sidebar.php'; ?>
</div>
