<?php

use TypechoPlugin\Forum\Plugin;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

// سربرگ مشترک انجمن — صفحهٔ ویرایش پروفایل (۲.۱.۰)
$qaPageKind = 'profile_edit';
include __DIR__ . '/header.php';
include __DIR__ . '/sortbar.php';
?>
<div class="qa-layout">
<div class="qa-content">

<?php if ($banner !== null): ?>
<?php $bannerWait = isset($banner[2]) ? (int) $banner[2] : 0; ?>
<div class="qa-banner is-<?php echo Plugin::e($banner[1]); ?>" role="status"<?php echo $bannerWait > 0 ? ' data-wait-banner="' . $bannerWait . '"' : ''; ?>>
  <p>
    <?php echo Plugin::e($banner[0]); ?>
    <?php if ($bannerWait > 0): ?>
    <span class="qa-countdown" data-countdown="<?php echo $bannerWait; ?>" role="timer" aria-live="polite" aria-atomic="true">
      <?php echo Plugin::faDigits((string) sprintf('%02d:%02d', (int) floor($bannerWait / 60), $bannerWait % 60)); ?>
    </span>
    <?php endif; ?>
  </p>
  <button type="button" class="qa-banner-close" aria-label="بستن پیام"<?php echo $bannerWait > 0 ? ' disabled' : ''; ?>>&times;</button>
</div>
<?php endif; ?>

<section class="qa-profile qa-profile-edit-page">
  <header class="qa-profile-head">
    <div class="qa-profile-id">
      <?php echo Plugin::avatar((string) $user['displayName'], (string) $user['mail']); ?>
      <h1 class="qa-profile-name">
        <?php echo Plugin::e($user['displayName']); ?>
        <?php echo Plugin::authorBadge((int) $user['uid']); ?>
      </h1>
      <span class="qa-profile-role"><?php echo Plugin::e($user['groupLabel']); ?></span>
      <p class="qa-profile-date">
        <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
        عضویت: <?php echo Plugin::e(Plugin::jalali((int) $user['created'])); ?>
      </p>
    </div>
    <div class="qa-profile-edit-actions">
      <a class="qa-btn qa-btn-ghost" href="<?php echo Plugin::e($backUrl); ?>">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
        <span>بازگشت به پروفایل</span>
      </a>
    </div>
  </header>

  <?php /* اطلاعاتات پایهٔ پروفایل — نام، ایمیل، وب */ ?>
  <section class="qa-profile-edit-card">
    <h2 class="qa-profile-edit-title">
      <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
      اطلاعات پایهٔ پروفایل
    </h2>
    <form method="post" action="<?php echo Plugin::e($actionUrl); ?>" class="qa-form qa-profile-edit-form">
      <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
      <input type="hidden" name="mode" value="update-profile-full">
      <div class="qa-field">
        <label for="qa-screenName">نام نمایشی</label>
        <input type="text" id="qa-screenName" name="screenName" dir="rtl"
               maxlength="32" autocomplete="nickname"
               value="<?php echo Plugin::e((string) $user['screenName']); ?>">
        <p class="qa-field-hint">نامی که در سایت و انجمن نمایش داده می‌شود؛ خالی بماند تا نام کاربری استفاده شود.</p>
      </div>
      <div class="qa-field">
        <label for="qa-mail">آدرس ایمیل</label>
        <input type="email" id="qa-mail" name="mail" dir="ltr"
               maxlength="150" required autocomplete="email"
               value="<?php echo Plugin::e((string) $user['mail']); ?>">
        <p class="qa-field-hint">آواتار شما از سرویس گراواتار بر اساس همین آدرس ساخته می‌شود.</p>
      </div>
      <div class="qa-field">
        <label for="qa-url">نشانی وب</label>
        <input type="url" id="qa-url" name="url" dir="ltr"
               maxlength="150" placeholder="https://example.com" autocomplete="url"
               value="<?php echo Plugin::e((string) $user['url']); ?>">
      </div>

      <?php /* بیوگرافی و شبکه‌های اجتماعی */ ?>
      <div class="qa-field">
        <label for="qa-bio">دربارهٔ شما</label>
        <textarea id="qa-bio" name="bio" rows="3" maxlength="300"
                  placeholder="چند خط دربارهٔ خودتان بنویسید…"><?php echo Plugin::e((string) $user['bio']); ?></textarea>
        <p class="qa-field-hint">حداکثر ۳۰۰ نویسه.</p>
      </div>
      <div class="qa-form-row">
        <div class="qa-field">
          <label for="qa-twitter">ایکس / توییتر</label>
          <input type="url" id="qa-twitter" name="twitter" dir="ltr" placeholder="https://twitter.com/username"
                 value="<?php echo Plugin::e((string) $user['social']['twitter']); ?>">
        </div>
        <div class="qa-field">
          <label for="qa-github">گیت‌هاب</label>
          <input type="url" id="qa-github" name="github" dir="ltr" placeholder="https://github.com/username"
                 value="<?php echo Plugin::e((string) $user['social']['github']); ?>">
        </div>
      </div>
      <div class="qa-form-row">
        <div class="qa-field">
          <label for="qa-telegram">تلگرام</label>
          <input type="url" id="qa-telegram" name="telegram" dir="ltr" placeholder="https://t.me/username"
                 value="<?php echo Plugin::e((string) $user['social']['telegram']); ?>">
        </div>
        <div class="qa-field">
          <label for="qa-instagram">اینستاگرام</label>
          <input type="url" id="qa-instagram" name="instagram" dir="ltr" placeholder="https://instagram.com/username"
                 value="<?php echo Plugin::e((string) $user['social']['instagram']); ?>">
        </div>
      </div>
      <div class="qa-form-row">
        <div class="qa-field">
          <label for="qa-linkedin">لینکدین</label>
          <input type="url" id="qa-linkedin" name="linkedin" dir="ltr" placeholder="https://linkedin.com/in/username"
                 value="<?php echo Plugin::e((string) $user['social']['linkedin']); ?>">
        </div>
        <div class="qa-field">
          <label for="qa-youtube">یوتوب</label>
          <input type="url" id="qa-youtube" name="youtube" dir="ltr" placeholder="https://youtube.com/@username"
                 value="<?php echo Plugin::e((string) $user['social']['youtube']); ?>">
        </div>
      </div>
      <div class="qa-form-actions">
        <button type="submit" class="qa-btn qa-btn-primary">ذخیرهٔ اطلاعات</button>
      </div>
    </form>
  </section>

  <?php /* تغییر رمز عبور */ ?>
  <section class="qa-profile-edit-card">
    <h2 class="qa-profile-edit-title">
      <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
      تغییر رمز عبور
    </h2>
    <form method="post" action="<?php echo Plugin::e($actionUrl); ?>" class="qa-form qa-profile-edit-form" autocomplete="off">
      <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
      <input type="hidden" name="mode" value="update-password">
      <div class="qa-field">
        <label for="qa-password">رمز عبور جدید</label>
        <input type="password" id="qa-password" name="password" dir="ltr" autocomplete="new-password">
        <p class="qa-field-hint">حداقل <?php echo Plugin::faDigits((string) $pwMin); ?> نویسه و حداکثر <?php echo Plugin::faDigits((string) $pwMax); ?> بایت.</p>
      </div>
      <div class="qa-field">
        <label for="qa-confirm">تکرار رمز عبور جدید</label>
        <input type="password" id="qa-confirm" name="confirm" dir="ltr" autocomplete="new-password">
      </div>
      <div class="qa-form-actions">
        <button type="submit" class="qa-btn qa-btn-primary">به‌روزرسانی رمز عبور</button>
      </div>
    </form>
    <p class="qa-profile-edit-hint">پس از تغییر رمز عبور، دفعات بعد با رمز جدید وارد حساب خود شوید.</p>
  </section>
</section>

</div>
<?php include __DIR__ . '/sidebar.php'; ?>
</div>
