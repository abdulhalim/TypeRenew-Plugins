<?php

use TypechoPlugin\Forum\Plugin;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
?>
<div class="qa-toolbar" data-qa-toolbar="<?php echo Plugin::e($toolbarTarget); ?>">
  <?php /* سربرگ (H) — ## text (Markdown) */ ?>
  <button type="button" class="qa-tb-btn qa-tb-text-btn" data-qa="h2" data-tooltip="سربرگ — ## متن" aria-label="درج سربرگ">
    <span class="qa-tb-text-icon">H</span>
  </button>
  <?php /* بولد (B) — **text** (Markdown) */ ?>
  <button type="button" class="qa-tb-btn qa-tb-text-btn" data-qa="bold" data-tooltip="بولد — **متن**" aria-label="درج متن بولد">
    <span class="qa-tb-text-icon" style="font-weight:800">B</span>
  </button>
  <?php /* ایتالیک (I) — *text* (Markdown) */ ?>
  <button type="button" class="qa-tb-btn qa-tb-text-btn" data-qa="italic" data-tooltip="ایتالیک — *متن*" aria-label="درج متن ایتالیک">
    <span class="qa-tb-text-icon" style="font-style:italic">I</span>
  </button>
  <span class="qa-tb-sep" aria-hidden="true"></span>
  <button type="button" class="qa-tb-btn" data-qa="code" data-tooltip="بلوک کد — ```کد```" aria-label="درج بلوک کد">
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>
  </button>
  <?php /* کد درون‌خطی با آیکون terminal — `code` (Markdown) */ ?>
  <button type="button" class="qa-tb-btn" data-qa="inline-code" data-tooltip="کد درون‌خطی — `code`" aria-label="درج کد درون‌خطی">
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="4 17 10 11 4 5"></polyline><line x1="12" y1="19" x2="20" y2="19"></line></svg>
  </button>
  <button type="button" class="qa-tb-btn" data-qa="link" data-tooltip="پیوند — [متن](url)" aria-label="درج پیوند">
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>
  </button>
  <button type="button" class="qa-tb-btn" data-qa="image" data-tooltip="تصویر — ![alt](url)" aria-label="درج تصویر">
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>
  </button>
  <?php if (Plugin::imgUploadEnabled()): ?>
  <button type="button" class="qa-tb-btn qa-tb-upload-btn" data-qa="upload"
          data-tooltip="آپلود تصویر از کامپیوتر"
          data-max-mb="<?php echo (string) (int) (Plugin::imgUploadMaxBytes() / 1048576); ?>"
          aria-label="آپلود تصویر از کامپیوتر">
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>
  </button>
  <?php endif; ?>
  <?php /* (۲.۱.۰) دکمه ویدئو آپارات — [aparat]VIDEO_ID[/aparat] با embed خودکار */ ?>
  <button type="button" class="qa-tb-btn" data-qa="aparat" data-tooltip="ویدئو آپارات" aria-label="درج ویدئو آپارات">
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="23 7 16 12 23 17 23 7"></polygon><rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect></svg>
  </button>
  <span class="qa-tb-sep" aria-hidden="true"></span>
  <?php /* لیست نامرتب */ ?>
  <button type="button" class="qa-tb-btn" data-qa="ul" data-tooltip="لیست نامرتب" aria-label="درج لیست نامرتب">
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3.01" y2="6"></line><line x1="3" y1="12" x2="3.01" y2="12"></line><line x1="3" y1="18" x2="3.01" y2="18"></line></svg>
  </button>
  <?php /* لیست مرتب */ ?>
  <button type="button" class="qa-tb-btn" data-qa="ol" data-tooltip="لیست مرتب" aria-label="درج لیست مرتب">
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="10" y1="6" x2="21" y2="6"></line><line x1="10" y1="12" x2="21" y2="12"></line><line x1="10" y1="18" x2="21" y2="18"></line><path d="M4 6h1v4"></path><path d="M4 10h2"></path><path d="M6 18H4c0-1 2-2 2-3s-1-1.5-2-1"></path></svg>
  </button>
  <?php /* خط افقی */ ?>
  <button type="button" class="qa-tb-btn" data-qa="hr" data-tooltip="خط افقی" aria-label="درج خط افقی">
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line></svg>
  </button>
  <?php /* نقل قول (Markdown) — > text */ ?>
  <button type="button" class="qa-tb-btn" data-qa="quote" data-tooltip="نقل قول — > متن" aria-label="درج نقل قول">
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"></path><path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z"></path></svg>
  </button>
  <span class="qa-tb-sep" aria-hidden="true"></span>
  <button type="button" class="qa-tb-btn qa-tb-emoji" data-qa="emoji" data-tooltip="شکلک‌ها" aria-label="درج شکلک" aria-expanded="false">
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="M8 14s1.5 2 4 2 4-2 4-2"></path><line x1="9" y1="9" x2="9.01" y2="9"></line><line x1="15" y1="9" x2="15.01" y2="9"></line></svg>
  </button>
  <?php /* پیش‌نمایش */ ?>
  <button type="button" class="qa-tb-btn qa-tb-preview" data-qa="preview" data-tooltip="پیش‌نمایش" aria-label="پیش‌نمایش متن">
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
  </button>
  <?php /* نوار شکلک‌ها (۲.۰.۰) — نواری درون‌خطی داخل جعبهٔ نوار ابزار؛
     با کلیک روی هر شکلک بسته نمی‌شود؛ فقط دکمهٔ شکلک آن را نشان/مخفی می‌کند */ ?>
  <div class="qa-emoji-bar" hidden>
    <?php foreach (Plugin::EMOJIS as $emo): ?>
    <button type="button" class="qa-emoji-btn" data-emoji="<?php echo Plugin::e($emo); ?>" aria-label="درج <?php echo Plugin::e($emo); ?>"><?php echo Plugin::e($emo); ?></button>
    <?php endforeach; ?>
  </div>
</div>
