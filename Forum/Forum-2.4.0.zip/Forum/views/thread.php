<?php

use TypechoPlugin\Forum\Plugin;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$rememberAuthor = (string) (\Typecho\Cookie::get('__typecho_remember_author') ?? '');
$rememberMail = (string) (\Typecho\Cookie::get('__typecho_remember_mail') ?? '');
$loginUrl = (string) $this->options->loginUrl;

/** فرم ویرایش درجا برای پرسش/پاسخ — نظرسنجی پرسش هم قابل ویرایش است (۲.۰.۰) */
if (!function_exists('TypechoPlugin\Forum\qaEditForm')) {
    function qaEditForm(array $row, string $token, int $maxLen, ?array $pollEdit = null, bool $pollAllowed = false): string
    {
        if (empty($row['canEdit'])) {
            return '';
        }

        $isAnswer = (int) $row['parent'] > 0;
        $coid = (int) $row['coid'];

        $hint = '';
        if ((int) ($row['authorId'] ?? 0) === 0) {
            $minutes = Plugin::guestEditMinutes();
            $left = (int) ceil(max(0, $minutes * 60 - (time() - (int) $row['created'])) / 60);
            if ($left > 0) {
                $hint = '<p class="qa-field-note">مهلت ویرایش مهمان: حدود ' . Plugin::faDigits($left) . ' دقیقه دیگر.</p>';
            }
        }

        // برای پرسش‌ها: عنوان و متن را جدا کن (۱.۵.۰)
        $titleField = '';
        $catField = '';
        $editBody = (string) $row['text'];
        if (!$isAnswer) {
            [$editTitle, $editRest] = Plugin::splitQuestion($editBody);
            $titleField = '<div class="qa-field">'
                . '<label for="qa-edit-title-' . $coid . '">عنوان پرسش <span class="qa-req">*</span></label>'
                . '<input type="text" id="qa-edit-title-' . $coid . '" name="title" required maxlength="120" value="' . Plugin::e($editTitle) . '">'
                . '</div>';
            $editBody = $editRest;

            // فیلد دسته فقط برای مدیر — ۱.۵.۰ (۲.۲.۰: نشان 🔒 برای دسته‌های قفل)
            if (Plugin::canManage()) {
                $currentCat = Plugin::topicCategoryId($coid);
                $opts = '<option value="0"' . ($currentCat === 0 ? ' selected' : '') . '>— بدون دسته —</option>';
                foreach (Plugin::categories() as $c) {
                    $sel = ((int) $c['id'] === $currentCat) ? ' selected' : '';
                    $lockMark = !empty($c['locked']) ? ' 🔒' : '';
                    $opts .= '<option value="' . (int) $c['id'] . '"' . $sel . '>' . Plugin::e($c['name']) . $lockMark . '</option>';
                }
                $catField = '<div class="qa-field qa-field-category">'
                    . '<label for="qa-edit-cat-' . $coid . '">دسته‌بندی (فقط مدیر)</label>'
                    . '<select id="qa-edit-cat-' . $coid . '" name="category">' . $opts . '</select>'
                    . '</div>';
            }
        }

        // نظرسنجی — فقط برای پرسش‌ها، وقتی نظرسنجی فعال و کاربر واردشده است (۲.۰.۰)
        // poll_present به سرور می‌گوید فیلدهای نظرسنجی در فرم بوده‌اند؛ بدون آن
        // (مثلاً ویرایش مهمان) سرور نظرسنجی موجود را دست نمی‌زند.
        $pollField = '';
        if (!$isAnswer && $pollAllowed) {
            $hasPoll = $pollEdit !== null;
            $pollQ = $hasPoll ? (string) $pollEdit['question'] : '';
            $pollOpts = $hasPoll ? implode("\n", (array) $pollEdit['options']) : '';
            $pollField = '<input type="hidden" name="poll_present" value="1">'
                . '<div class="qa-field qa-poll-field">'
                . '<label class="qa-poll-toggle-label">'
                . '<input type="checkbox" class="qa-poll-toggle" name="has_poll" value="1"' . ($hasPoll ? ' checked' : '') . '>'
                . ($hasPoll ? 'ویرایش نظرسنجی' : 'افزودن نظرسنجی')
                . '</label>'
                . '<div class="qa-poll-options"' . ($hasPoll ? '' : ' hidden') . '>'
                . '<input type="text" name="poll_question" maxlength="200" dir="auto" value="' . Plugin::e($pollQ) . '"'
                . ' placeholder="سؤال نظرسنجی…" class="qa-poll-q">'
                . '<p class="qa-field-note">هر سطر یک گزینه. حداقل ۲، حداکثر ۸ گزینه.</p>'
                . '<textarea name="poll_options" rows="4" maxlength="500" dir="auto"'
                . ' placeholder="گزینهٔ اول&#10;گزینهٔ دوم&#10;گزینهٔ سوم…">' . Plugin::e($pollOpts) . '</textarea>'
                . ($hasPoll
                    ? '<p class="qa-field-note qa-field-note--warn">با برداشتن تیک و ذخیره، نظرسنجی و همهٔ آرا آن حذف می‌شود. تغییر ترتیب یا حذف گزینه ممکن است آرا را جابه‌جا کند.</p>'
                    : '')
                . '</div>'
                . '</div>';
        }

        // نوار ابزار ویرایشگر برای فرم ویرایش (۲.۰.۰)
        ob_start();
        $toolbarTarget = 'qa-edit-text-' . $coid;
        include __DIR__ . '/toolbar.php';
        $editToolbar = (string) ob_get_clean();

        return '<div class="qa-edit" id="qa-edit-' . $coid . '" hidden>'
            . '<form method="post" action="' . Plugin::e(Plugin::postUrl()) . '" class="qa-form qa-edit-form">'
            . '<input type="hidden" name="_" value="' . Plugin::e($token) . '">'
            . '<input type="hidden" name="mode" value="edit">'
            . '<input type="hidden" name="coid" value="' . $coid . '">'
            . $titleField
            . $catField
            . '<div class="qa-field">'
            . '<label for="qa-edit-text-' . $coid . '">' . ($isAnswer ? 'ویرایش پاسخ' : 'متن پرسش') . ' <span class="qa-req">*</span></label>'
            . $editToolbar
            . '<textarea id="qa-edit-text-' . $coid . '" name="text" rows="4" required maxlength="' . (int) $maxLen . '">'
            . Plugin::e($editBody) . '</textarea>'
            . $hint
            . '</div>'
            . $pollField
            . '<div class="qa-form-actions">'
            . '<button type="submit" class="qa-btn qa-btn-primary">ذخیرهٔ ویرایش</button> '
            . '<button type="button" class="qa-btn qa-btn-ghost qa-edit-cancel" data-target="qa-edit-' . $coid . '">انصراف</button>'
            . '</div>'
            . '</form></div>';
    }
}

/** دکمهٔ نمایش/پنهان‌سازی فرم ویرایش */
if (!function_exists('TypechoPlugin\Forum\qaEditToggle')) {
    function qaEditToggle(array $row): string
    {
        if (empty($row['canEdit'])) {
            return '';
        }

        return '<button type="button" class="qa-post-action qa-edit-toggle" data-target="qa-edit-' . (int) $row['coid'] . '"'
            . ' data-tooltip="ویرایش این ' . ((int) $row['parent'] > 0 ? 'پاسخ' : 'پرسش') . '">'
            . '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path></svg>'
            . '<span>ویرایش</span>'
            . '</button>';
    }
}
?>
<?php
// سربرگ مشترک (۲.۰.۰) — جستجو داخل سربرگ؛ نوار مرتب‌سازی همیشه دیده می‌شود
$qaPageKind = 'thread';
include __DIR__ . '/header.php';
include __DIR__ . '/sortbar.php';
?>
<div class="qa-layout">
<div class="qa-content">

<?php
  $adminPending = $canManage ? Plugin::pendingCount() : 0;
  $adminFlags = $canManage ? Plugin::totalFlagCount() : 0;
  // پنل مدیریت اختصاصی انجمن (نسخهٔ ۲ — جایگزین پنل دیدگاه‌ها)
  $adminCommentsUrl = Plugin::adminPanelUrl();
?>
<?php if ($canManage && ($adminPending > 0 || $adminFlags > 0)): ?>
<div class="qa-admin-bar" role="alert">
  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
  <div class="qa-admin-bar-text">
    <?php if ($adminPending > 0): ?>
    <a href="<?php echo Plugin::e($adminCommentsUrl); ?>" class="qa-admin-bar-link">
      <?php echo Plugin::faDigits($adminPending); ?> پرسش/پاسخ در انتظار تأیید
    </a>
    <?php endif; ?>
    <?php if ($adminPending > 0 && $adminFlags > 0): ?>
    <span class="qa-admin-bar-sep" aria-hidden="true">•</span>
    <?php endif; ?>
    <?php if ($adminFlags > 0): ?>
    <span class="qa-admin-bar-info"><?php echo Plugin::faDigits($adminFlags); ?> گزارش ثبت‌شده توسط کاربران — در همین صفحه بررسی و اقدام مناسب را انجام دهید</span>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>

<?php
  // ۲.۲.۰ — بنر گزارش‌های فعال با دلیل، زیر qa-admin-bar (فقط برای مدیر)
  $qaActiveReports = $canManage ? Plugin::activeReportsForBanner() : [];
  if (!empty($qaActiveReports)):
?>
<div class="qa-flag-banner-wrap" id="qa-flag-banner-wrap" role="region" aria-label="گزارش‌های تخلف فعال">
  <?php foreach ($qaActiveReports as $qaRep): ?>
  <div class="qa-flag-banner" data-flag-coid="<?php echo (int) $qaRep['coid']; ?>">
    <div class="qa-flag-banner-head">
      <span class="qa-flag-banner-kind"><?php echo Plugin::e($qaRep['kind']); ?></span>
      <span class="qa-flag-banner-count" data-tooltip="<?php echo Plugin::faDigits($qaRep['count']); ?> گزارش">
        <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path><line x1="4" y1="22" x2="4" y2="15"></line></svg>
        <?php echo Plugin::faDigits($qaRep['count']); ?> گزارش
      </span>
      <a class="qa-flag-banner-title" href="<?php echo Plugin::e($qaRep['url']); ?>"><?php echo Plugin::e($qaRep['title']); ?></a>
    </div>
    <?php if (!empty($qaRep['reasons'])): ?>
    <ul class="qa-flag-banner-reasons">
      <?php foreach ($qaRep['reasons'] as $qaReason): ?>
      <li><?php echo Plugin::e($qaReason); ?></li>
      <?php endforeach; ?>
    </ul>
    <?php else: ?>
    <p class="qa-flag-banner-noreason">دلیلی ثبت نشده است.</p>
    <?php endif; ?>
    <div class="qa-flag-banner-actions">
      <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-clear-flags-form qa-flag-banner-form">
        <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
        <input type="hidden" name="mode" value="clear-flags">
        <input type="hidden" name="coid" value="<?php echo (int) $qaRep['coid']; ?>">
        <?php /* ۲.۲.۰ — type برای clearFlags type-aware (جلوگیری از پاک‌شدن اشتباه) */ ?>
        <input type="hidden" name="type" value="<?php echo Plugin::e($qaRep['type']); ?>">
        <button type="submit" class="qa-flag-banner-btn is-reject"
                data-confirm="گزارش‌های این <?php echo Plugin::e($qaRep['kind']); ?> رد شود؟">
          رد کردن گزارش
        </button>
      </form>
      <a class="qa-flag-banner-btn is-view" href="<?php echo Plugin::e($qaRep['url']); ?>">مشاهدهٔ <?php echo Plugin::e($qaRep['kind']); ?></a>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if ($banner !== null): ?>
<?php
  // اگر banner شامل شمارش معکوس است (اندیس ۲ = ثانیه)، عنصر شمارش معکوس رندر می‌کنیم (۱.۵.۳)
  $bannerWait = isset($banner[2]) ? (int) $banner[2] : 0;
?>
<div class="qa-banner is-<?php echo Plugin::e($banner[1]); ?>" role="status"<?php echo $bannerWait > 0 ? ' data-wait-banner="' . $bannerWait . '"' : ''; ?>>
  <p>
    <?php echo Plugin::e($banner[0]); ?>
    <?php if ($bannerWait > 0): ?>
    <span class="qa-countdown" data-countdown="<?php echo $bannerWait; ?>" role="timer" aria-live="polite" aria-atomic="true">
      <?php echo Plugin::faDigits((string) sprintf('%02d:%02d', (int) floor($bannerWait / 60), $bannerWait % 60)); ?>
    </span>
    <?php endif; ?>
  </p>
  <button type="button" class="qa-banner-close" aria-label="بستن پیام"<?php echo $bannerWait > 0 ? ' disabled' : ''; ?>>&times;</button>
</div>
<?php endif; ?>

<?php
  $qCatId = (int) ($question['qaCatId'] ?? 0);
  $qCat = $qCatId > 0 ? Plugin::getCategory($qCatId) : null;
  $qReported = !empty($question['qaReported']);
  $qHidden = !empty($question['qaHidden']);
  // ۲.۲.۰ — وضعیت «انجام شده»
  $qStatus = (string) ($question['status'] ?? 'approved');
  $qIsDone = $qStatus === 'done';
  $qArticleClass = 'qa-question';
  if ($question['isWaiting']) { $qArticleClass .= ' is-waiting'; }
  if ($qIsDone) { $qArticleClass .= ' is-done'; }
  if ($isLocked) { $qArticleClass .= ' is-locked'; }
  if ($isPinned) { $qArticleClass .= ' is-pinned'; }
  if ($isTracked) { $qArticleClass .= ' is-tracked'; }
  if ($qHidden) { $qArticleClass .= ' is-hidden'; }
  // برجسته‌سازی زرد فقط برای مدیران (۱.۵.۲) — نویسنده و مهمان نمی‌بینند.
  // ۲.۲.۰ — فقط خود پرسشِ گزارش‌شده زرد می‌شود (رفتار اصلی بازگشت).
  if ($qReported && $canManage) { $qArticleClass .= ' is-reported'; }
  // ۲.۲.۰ — نشانی شمارشگر پرسش: بدون anchor (نشانی پرسش، نه پاسخ)
  $qCounterUrl = Plugin::threadUrl((int) $question['coid']);
?>
<article class="<?php echo $qArticleClass; ?>" id="c<?php echo Plugin::e($question['coid']); ?>">
  <header class="qa-question-head">
    <?php echo Plugin::avatar((string) $question['author'], (string) $question['mail']); ?>
    <div class="qa-question-id">
      <span class="qa-question-author"><?php echo Plugin::authorLink($question); ?> <?php echo Plugin::authorBadge((int) ($question['authorId'] ?? 0)); ?></span>
      <span class="qa-question-meta">
        <time datetime="<?php echo Plugin::e(date('c', (int) $question['created'])); ?>"
              data-tooltip="<?php echo Plugin::e(Plugin::jalali((int) $question['created']) . '، ' . Plugin::jalaliTime((int) $question['created'])); ?>">
          <?php echo Plugin::faRelative((int) $question['created']); ?>
        </time>
        <?php if ($viewsEnabled && (int) $question['qaViews'] > 0): ?>
        <span class="qa-dot" aria-hidden="true">•</span>
        <span class="qa-question-views" data-tooltip="بازدید این پرسش">
          <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-4-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
          <?php echo Plugin::faDigits($question['qaViews']); ?> بازدید
        </span>
        <?php endif; ?>
        <?php if ($qCat !== null): ?>
        <span class="qa-dot" aria-hidden="true">•</span>
        <a class="qa-question-cat" href="<?php echo Plugin::e(Plugin::forumUrl() . '?cat=' . (int) $qCat['id']); ?>"
           data-tooltip="دسته: <?php echo Plugin::e($qCat['name']); ?><?php echo !empty($qCat['locked']) ? ' (قفل)' : ''; ?>"<?php echo $qCat['color'] !== '' ? ' style="--cat-color:' . Plugin::e($qCat['color']) . '"' : ''; ?>>
          <?php echo Plugin::categoryIconSvg($qCat['icon'], 12); ?>
          <span><?php echo Plugin::e($qCat['name']); ?></span>
          <?php if (!empty($qCat['locked'])): ?>
          <svg class="qa-cat-lock-ico" viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
          <?php endif; ?>
        </a>
        <?php endif; ?>
        <?php if ($qIsDone): ?>
        <span class="qa-badge is-done">انجام شده</span>
        <?php elseif ($question['isWaiting']): ?>
        <span class="qa-badge is-waiting">در انتظار تأیید</span>
        <?php endif; ?>
        <?php if ($isPinned): ?>
        <span class="qa-badge is-pinned">
          <svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 17v5"></path><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1z"></path></svg>
          سنجاق‌شده
        </span>
        <?php endif; ?>
        <?php if ($isTracked): ?>
        <span class="qa-badge is-tracked">
          <svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3v5h5"></path><path d="M3.05 13A9 9 0 1 0 6 5.3L3 8"></path><path d="M12 7v5l4 2"></path></svg>
          در حال پیگیری
        </span>
        <?php endif; ?>
        <?php if ($qHidden): ?>
        <span class="qa-badge is-hidden" data-tooltip="این پرسش از دید کاربران مهمان پنهان است">
          <svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"></path><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"></path><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"></path><line x1="2" y1="2" x2="22" y2="22"></line></svg>
          پنهان از مهمان
        </span>
        <?php endif; ?>
        <?php if ($isLocked): ?>
          <?php if ($bestAnswerId > 0): ?>
          <span class="qa-badge is-best-solved">
            <svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
            حل‌شده
          </span>
          <?php else: ?>
          <span class="qa-badge is-locked">
            <svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
            قفل شده
          </span>
          <?php endif; ?>
        <?php endif; ?>
      </span>
    </div>

    <?php /* ۲.۲.۰ — شمارشگر پرسش در هدر (سمت چپ)؛ کلیک = کپی پیوند پرسش (بدون anchor) */ ?>
    <button type="button" class="qa-post-counter qa-post-counter--head" data-copy-url="<?php echo Plugin::e($qCounterUrl); ?>"
            data-tooltip="کپی پیوند این پرسش" aria-label="کپی پیوند این پرسش">#<?php echo Plugin::faDigits(1); ?></button>

    <?php /* ۲.۲.۰ — دکمه‌های کارت به پابرگ منتقل شدند؛ ابزارهای مدیر داخل دراپ‌داون چرخ‌دنده */ ?>
  </header>
  <div class="qa-question-body">
    <h1 class="qa-question-title"><?php echo Plugin::e(Plugin::stripMarkup($question['titleLine'])); ?></h1>
    <?php if ($question['restText'] !== ''): ?>
    <div class="qa-question-text"><?php echo Plugin::renderText($question['restText']); ?></div>
    <?php endif; ?>
  </div>

  <?php
    // نمایش نظرسنجی اگر وجود دارد (۱.۶.۰) — فقط برای کاربران واردشده (۱.۵.۲)
    $poll = (!empty($pollsEnabled) && $hasLogin && (int) $question['coid'] > 0) ? Plugin::getPoll((int) $question['coid']) : null;
  ?>
  <?php if ($poll !== null): ?>
  <?php
    $pollVotes = Plugin::getPollVotes((int) $question['coid']);
    $pollTotal = array_sum($pollVotes);
    $hasVoted = Plugin::hasVoted((int) $question['coid']);
  ?>
  <div class="qa-poll" id="qa-poll">
    <h3 class="qa-poll-title">
      <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
      <?php echo Plugin::e($poll['question']); ?>
    </h3>
    <?php if (!$hasVoted): ?>
    <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-poll-form">
      <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
      <input type="hidden" name="mode" value="vote">
      <input type="hidden" name="coid" value="<?php echo Plugin::e($question['coid']); ?>">
      <?php foreach ($poll['options'] as $i => $opt): ?>
      <label class="qa-poll-option">
        <input type="radio" name="option" value="<?php echo $i; ?>" required>
        <span class="qa-poll-option-text"><?php echo Plugin::e($opt); ?></span>
      </label>
      <?php endforeach; ?>
      <button type="submit" class="qa-btn qa-btn-primary qa-poll-vote-btn">ثبت رأی</button>
    </form>
    <?php else: ?>
    <div class="qa-poll-results">
      <?php foreach ($poll['options'] as $i => $opt):
        $count = $pollVotes[$i] ?? 0;
        $pct = $pollTotal > 0 ? round(($count / $pollTotal) * 100) : 0;
      ?>
      <div class="qa-poll-result">
        <div class="qa-poll-result-head">
          <span><?php echo Plugin::e($opt); ?></span>
          <span class="qa-poll-result-count"><?php echo Plugin::faDigits($count); ?> (<?php echo Plugin::faDigits($pct); ?>٪)</span>
        </div>
        <div class="qa-poll-bar"><div class="qa-poll-bar-fill" style="width: <?php echo $pct; ?>%"></div></div>
      </div>
      <?php endforeach; ?>
      <p class="qa-poll-total">مجموع: <?php echo Plugin::faDigits($pollTotal); ?> رأی</p>
    </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <?php
    // ویرایش نظرسنجی در فرم ویرایش پرسش (۲.۰.۰) — فقط وقتی نظرسنجی فعال و کاربر واردشده است
    $qaPollAllowed = !empty($pollsEnabled) && $hasLogin;
    $qaPollEdit = $qaPollAllowed ? Plugin::getPoll((int) $question['coid']) : null;
    echo qaEditForm($question, $token, $maxLen, $qaPollEdit, $qaPollAllowed);
  ?>

  <footer class="qa-question-foot qa-card-foot">
    <?php /* ۲.۲.۰ — چیدمان جدید پابرگ: نوشتاری‌ها راست، گزارش/شمارشگر/مدیریت چپ */ ?>
    <div class="qa-foot-side qa-foot-right">
      <?php if (!empty($question['qaLikesOn'])): $qLiked = !empty($question['qaLiked']); ?>
      <!-- پسند پرسش — فقط اعضای غیرنویسنده (۲.۰.۰) -->
      <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-like-form qa-like-form--question" data-coid="<?php echo Plugin::e($question['coid']); ?>">
        <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
        <input type="hidden" name="mode" value="like">
        <input type="hidden" name="type" value="topic">
        <input type="hidden" name="coid" value="<?php echo Plugin::e($question['coid']); ?>">
        <button type="submit" class="qa-post-action qa-like-btn<?php echo $qLiked ? ' is-liked' : ''; ?>"
                data-tooltip="<?php echo $qLiked ? 'پسندیده‌اید — برای برداشتن کلیک کنید' : 'پسندیدن این پرسش'; ?>"
                aria-label="پسندیدن این پرسش">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path></svg>
          <span class="qa-like-count"><?php echo Plugin::faDigits((string) (int) $question['qaLikes']); ?></span>
        </button>
      </form>
      <?php elseif (!empty($question['qaLikesOwn'])): ?>
      <!-- نویسندهٔ پرسش — نشان شمار پسندهای دریافتی (بدون امکان پسند) -->
      <span class="qa-post-action qa-like-badge" data-tooltip="پسندهای دریافتی پرسش شما" aria-label="پسندهای دریافتی این پرسش">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path></svg>
        <span class="qa-like-count"><?php echo Plugin::faDigits((string) (int) $question['qaLikes']); ?></span>
      </span>
      <?php endif; ?>
      <?php if ($canReply): ?>
      <button type="button" class="qa-post-action qa-reply-jump" data-target="respond" data-tooltip="نوشتن پاسخ">
        <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
        <span>پاسخ</span>
      </button>
      <?php endif; ?>
      <?php echo qaEditToggle($question); ?>
      <?php if ($canManage || !empty($question['canEdit'])): ?>
      <!-- حذف پرسش — با تأیید سفارشی -->
      <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-delete-form"
            data-confirm="این پرسش و همهٔ پاسخ‌های زیرش حذف شوند؟ این عمل قابل بازگشت نیست."
            data-confirm-title="حذف پرسش"
            data-confirm-variant="danger"
            data-confirm-ok="بله، حذف شود">
        <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
        <input type="hidden" name="mode" value="delete">
        <input type="hidden" name="coid" value="<?php echo Plugin::e($question['coid']); ?>">
        <button type="submit" class="qa-post-action qa-delete-btn"
                data-tooltip="حذف پرسش"
                aria-label="حذف پرسش">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
          <span>حذف</span>
        </button>
      </form>
      <?php endif; ?>
    </div>

    <div class="qa-foot-side qa-foot-left">
      <?php /* اشتراک‌گذاری در تلگرام/ایکس — کپی پیوند به شمارشگر منتقل شد (۲.۲.۰) */ ?>
      <div class="qa-share-bar" data-share-url="<?php echo Plugin::e(Plugin::threadUrl((int) $question['coid'])); ?>" data-share-title="<?php echo Plugin::e(Plugin::stripMarkup($question['titleLine'])); ?>">
        <a class="qa-post-action qa-share-tg" href="#" target="_blank" rel="noopener noreferrer" data-tooltip="اشتراک در تلگرام" aria-label="اشتراک در تلگرام">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"></path></svg>
        </a>
        <a class="qa-post-action qa-share-x" href="#" target="_blank" rel="noopener noreferrer" data-tooltip="اشتراک در ایکس" aria-label="اشتراک در ایکس">
          <svg viewBox="0 0 24 24" width="13" height="13" fill="currentColor" aria-hidden="true"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"></path></svg>
        </a>
      </div>

      <?php /* تأیید پرسشِ در انتظار داخل دراپ‌داون چرخ‌دنده است (مدیر) */ ?>

      <?php if (!empty($question['qaFlagOn'])): ?>
      <!-- گزارش تخلف پرسش — فقط اعضای غیرنویسنده (نویسنده/مهمان نمی‌بینند) -->
      <?php /* ۲.۲.۰ — کلیک روی پرچم، به‌جای ارسال مستقیم، مودال دلیل را باز می‌کند
               data-flag-type="topic" برای جلوگیری از تداخل با پاسخ‌های هم‌coid */ ?>
      <button type="button" class="qa-post-action qa-flag-btn qa-flag-trigger<?php echo Plugin::hasFlagged((int) $question['coid'], 'topic') ? ' is-flagged' : ''; ?>"
              data-flag-coid="<?php echo Plugin::e($question['coid']); ?>"
              data-flag-type="topic"
              data-flag-kind="پرسش"
              data-flag-token="<?php echo Plugin::e($token); ?>"
              data-flag-already="<?php echo Plugin::hasFlagged((int) $question['coid'], 'topic') ? '1' : '0'; ?>"
              data-tooltip="<?php echo Plugin::hasFlagged((int) $question['coid'], 'topic') ? 'گزارش داده‌اید' : 'گزارش تخلف'; ?>"
              aria-label="گزارش تخلف">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path><line x1="4" y1="22" x2="4" y2="15"></line></svg>
      </button>
      <?php endif; ?>

      <?php /* ۲.۲.۰ — شمارشگر پرسش به هدر منتقل شد (سمت چپ)؛ این بلوک خالی نگه داشته شده */ ?>

      <?php if ($canManage): ?>
      <?php /* ۲.۲.۰ — ابزارهای مدیریتی پرسش داخل دراپ‌داون چرخ‌دنده */ ?>
      <div class="qa-gear" data-gear>
        <button type="button" class="qa-post-action qa-gear-btn" aria-expanded="false" aria-haspopup="true" aria-controls="qa-gear-pop-q"
                data-tooltip="ابزارهای مدیریت پرسش" aria-label="ابزارهای مدیریت پرسش">
          <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
        </button>
        <div class="qa-gear-pop" id="qa-gear-pop-q" hidden>
          <p class="qa-gear-pop-title">مدیریت پرسش</p>

          <?php if ($question['isWaiting']): ?>
          <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-gear-item qa-approve-form">
            <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
            <input type="hidden" name="mode" value="approve">
            <input type="hidden" name="coid" value="<?php echo Plugin::e($question['coid']); ?>">
            <button type="submit" class="qa-gear-item-btn is-ok">
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="m9 12 2 2 4-4"></path></svg>
              <span>تأیید و انتشار</span>
            </button>
          </form>
          <?php endif; ?>

          <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-gear-item qa-pin-form"
                data-confirm="<?php echo $isPinned ? 'سنجاق این پرسش برداشته شود؟' : 'این پرسش در صدر فهرست پرسش‌های انجمن سنجاق شود؟'; ?>"
                data-confirm-title="<?php echo $isPinned ? 'برداشتن سنجاق' : 'سنجاق کردن پرسش'; ?>"
                data-confirm-variant="warn"
                data-confirm-ok="<?php echo $isPinned ? 'بله، برداشته شود' : 'بله، سنجاق شود'; ?>">
            <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
            <input type="hidden" name="mode" value="<?php echo $isPinned ? 'unpin' : 'pin'; ?>">
            <input type="hidden" name="coid" value="<?php echo Plugin::e($question['coid']); ?>">
            <button type="submit" class="qa-gear-item-btn<?php echo $isPinned ? ' is-active' : ''; ?>">
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 17v5"></path><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1z"></path></svg>
              <span><?php echo $isPinned ? 'برداشتن سنجاق' : 'سنجاق کردن پرسش'; ?></span>
            </button>
          </form>

          <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-gear-item qa-track-form">
            <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
            <input type="hidden" name="mode" value="<?php echo $isTracked ? 'untrack' : 'track'; ?>">
            <input type="hidden" name="coid" value="<?php echo Plugin::e($question['coid']); ?>">
            <button type="submit" class="qa-gear-item-btn<?php echo $isTracked ? ' is-active' : ''; ?>">
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3v5h5"></path><path d="M3.05 13A9 9 0 1 0 6 5.3L3 8"></path><path d="M12 7v5l4 2"></path></svg>
              <span><?php echo $isTracked ? 'برداشتن «در حال پیگیری»' : 'علامت‌گذاری «در حال پیگیری»'; ?></span>
            </button>
          </form>

          <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-gear-item qa-hide-form"
                data-confirm="<?php echo $qHidden ? 'این پرسش دوباره برای کاربران مهمان نمایش داده شود؟' : 'این پرسش از دید کاربران مهمان پنهان شود؟ کاربران واردشده آن را می‌بینند.'; ?>"
                data-confirm-title="<?php echo $qHidden ? 'نمایش مجدد به مهمان' : 'پنهان‌کردن از مهمان'; ?>"
                data-confirm-variant="warn"
                data-confirm-ok="<?php echo $qHidden ? 'بله، نمایش داده شود' : 'بله، پنهان شود'; ?>">
            <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
            <input type="hidden" name="mode" value="<?php echo $qHidden ? 'unhide' : 'hide'; ?>">
            <input type="hidden" name="coid" value="<?php echo Plugin::e($question['coid']); ?>">
            <button type="submit" class="qa-gear-item-btn<?php echo $qHidden ? ' is-active' : ''; ?>">
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"></path><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"></path><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"></path><line x1="2" y1="2" x2="22" y2="22"></line></svg>
              <span><?php echo $qHidden ? 'نمایش مجدد به مهمان' : 'پنهان‌کردن از مهمان'; ?></span>
            </button>
          </form>

          <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-gear-item qa-lock-form"
                data-confirm="<?php echo $isLocked ? 'قفل این پرسش باز شود؟ کاربران می‌توانند دوباره پاسخ بنویسند.' : 'پرسش قفل شود؟ فقط مدیران می‌توانند در پرسش قفل‌شده بنویسند.'; ?>"
                data-confirm-title="<?php echo $isLocked ? 'بازکردن قفل پرسش' : 'قفل کردن پرسش'; ?>"
                data-confirm-variant="warn"
                data-confirm-ok="<?php echo $isLocked ? 'بله، باز شود' : 'بله، قفل شود'; ?>">
            <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
            <input type="hidden" name="mode" value="<?php echo $isLocked ? 'unlock' : 'lock'; ?>">
            <input type="hidden" name="coid" value="<?php echo Plugin::e($question['coid']); ?>">
            <button type="submit" class="qa-gear-item-btn<?php echo $isLocked ? ' is-active' : ''; ?>">
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
              <span><?php echo $isLocked ? 'بازکردن قفل پرسش' : 'قفل کردن پرسش'; ?></span>
            </button>
          </form>

          <?php $qFlagCount = Plugin::flagCount((int) $question['coid'], 'topic'); ?>
          <?php if ($qFlagCount > 0): ?>
          <div class="qa-gear-sep" role="separator"></div>
          <div class="qa-gear-flagrow">
            <span class="qa-flag-indicator" data-tooltip="<?php echo Plugin::faDigits($qFlagCount); ?> گزارش تخلف">
              <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path><line x1="4" y1="22" x2="4" y2="15"></line></svg>
              <?php echo Plugin::faDigits($qFlagCount); ?> گزارش
            </span>
            <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-clear-flags-form"
                  data-confirm="<?php echo Plugin::faDigits($qFlagCount); ?> گزارش تخلف ثبت‌شده برای این پرسش رد شود؟ گزارش‌ها پاک می‌شوند ولی خود پرسش باقی می‌ماند."
                  data-confirm-title="رد کردن گزارش‌ها"
                  data-confirm-variant="info"
                  data-confirm-ok="بله، رد شود">
              <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
              <input type="hidden" name="mode" value="clear-flags">
              <input type="hidden" name="coid" value="<?php echo Plugin::e($question['coid']); ?>">
              <button type="submit" class="qa-gear-item-btn is-danger" data-tooltip="رد کردن گزارش‌ها" aria-label="رد کردن گزارش‌ها">
                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                <span>رد کردن گزارش‌ها</span>
              </button>
            </form>
          </div>
          <?php endif; ?>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </footer>
</article>

<?php
  // ۲.۲.۰ — تعریف متغیرهای صفحه‌بندی پاسخ‌ها قبل از هر شرط
  // (رفع هشدار Undefined variable وقتی $answers خالی است)
  $aPage  = (int) ($answersPage ?? 1);
  $aPages = (int) ($answersPages ?? 1);
  $aTotal = (int) ($answersTotal ?? 0);
  $aPerPage = (int) ($postsPerPage ?? 15);
  $aStartOffset = ($aPage - 1) * $aPerPage;
?>

<section class="qa-answers" id="answers">
  <?php /* ۲.۲.۰ — شمارشگر «N پاسخ» زیر سربرگ حذف شد (خواستهٔ مدیر) */ ?>
  <?php /* ۲.۲.۰ — بلوک «هنوز پاسخی ثبت نشده است» حذف شد (خواستهٔ مدیر) */ ?>
  <?php if (!$answers): ?>
  <div class="qa-answers-list qa-answers-empty" aria-hidden="true"></div>
  <?php else: ?>
  <div class="qa-answers-list">
    <?php foreach ($answers as $aIdx => $a):
        $isBest = $bestAnswerId > 0 && (int) $a['coid'] === $bestAnswerId && $a['status'] === 'approved';
        $aReported = !empty($a['qaReported']);
        // ۲.۲.۰ — فقط خود پاسخِ گزارش‌شده زرد می‌شود (رفتار اصلی بازگشت).
        $aHighlightReported = $aReported && $canManage;
        // ۲.۲.۰ — وضعیت «انجام شده»
        $aIsDone = ($a['status'] ?? 'approved') === 'done';
        // ۲.۲.۰ — شمارهٔ پست در کل تاپیک (پرسش = ۱، اولین پاسخ = ۲، …)
        // با صفحه‌بندی: شمارهٔ مطلق = offset صفحه + idx در صفحه + ۲
        $aNumber = $aStartOffset + $aIdx + 2;
        // ۲.۲.۰ — URL شمارنده: اگر پاسخ در صفحهٔ ۱ نیست، ?pa=N به URL اضافه می‌شود
        // تا کاربر با کلیک روی شمارنده، مستقیم به صفحهٔ حاوی پاسخ برود.
        $aCounterUrl = Plugin::threadUrl((int) $question['coid']);
        if ($aPage > 1) {
            $aCounterUrl .= '?pa=' . $aPage;
        }
        $aCounterUrl .= '#c' . (int) $a['coid'];
    ?>
    <article class="qa-answer<?php echo ($a['status'] !== 'approved' && !$aIsDone) ? ' is-waiting' : ''; ?><?php echo $aIsDone ? ' is-done' : ''; ?><?php echo $isBest ? ' is-best' : ''; ?><?php echo $aHighlightReported ? ' is-reported' : ''; ?>" id="c<?php echo Plugin::e($a['coid']); ?>">
      <?php if ($isBest): ?>
      <span class="qa-best-badge" data-tooltip="این پاسخ به‌عنوان بهترین پاسخ انتخاب شده است">
        <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
        بهترین پاسخ
      </span>
      <?php endif; ?>
      <header class="qa-answer-head">
        <?php echo Plugin::avatar((string) $a['author'], (string) $a['mail']); ?>
        <div class="qa-answer-id">
          <span class="qa-answer-author<?php echo (int) $a['authorId'] > 0 && (int) $a['authorId'] === (int) ($post['authorId'] ?? 0) ? ' is-staff' : ''; ?>"><?php echo Plugin::authorLink($a); ?> <?php echo Plugin::authorBadge((int) ($a['authorId'] ?? 0)); ?></span>
          <span class="qa-answer-meta">
            <time datetime="<?php echo Plugin::e(date('c', (int) $a['created'])); ?>"
                  data-tooltip="<?php echo Plugin::e(Plugin::jalali((int) $a['created']) . '، ' . Plugin::jalaliTime((int) $a['created'])); ?>">
              <?php echo Plugin::faRelative((int) $a['created']); ?>
            </time>
            <?php if ($aIsDone): ?>
            <span class="qa-badge is-done">انجام شده</span>
            <?php elseif ($a['status'] !== 'approved'): ?>
            <span class="qa-badge is-waiting">در انتظار تأیید</span>
            <?php endif; ?>
          </span>
        </div>
        <?php /* ۲.۲.۰ — شمارشگر پاسخ به هدر (سمت چپ) منتقل شد؛ کلیک = کپی پیوند */ ?>
        <button type="button" class="qa-post-counter qa-post-counter--head" data-copy-url="<?php echo Plugin::e($aCounterUrl); ?>"
                data-tooltip="کپی پیوند این پاسخ" aria-label="کپی پیوند این پاسخ">#<?php echo Plugin::faDigits($aNumber); ?></button>
        <?php /* ۲.۲.۰ — دکمه‌های کارت پاسخ به پابرگ منتقل شدند */ ?>
      </header>
      <div class="qa-answer-body">
        <?php echo Plugin::renderText((string) $a['text']); ?>
      </div>
      <?php echo qaEditForm($a, $token, $maxLen); ?>

      <?php /* ۲.۲.۰ — پابرگ کارت پاسخ: نوشتاری‌ها راست؛ گزارش/بهترین/شمارشگر چپ */ ?>
      <footer class="qa-answer-foot qa-card-foot">
        <div class="qa-foot-side qa-foot-right">
          <?php if ($canManage && $a['status'] !== 'approved'): ?>
          <!-- تأیید پاسخِ در انتظار — در همان صفحهٔ پرسش (۲.۰.۰) -->
          <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-approve-form">
            <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
            <input type="hidden" name="mode" value="approve">
            <input type="hidden" name="coid" value="<?php echo Plugin::e($a['coid']); ?>">
            <button type="submit" class="qa-post-action qa-approve-btn"
                    data-tooltip="تأیید و انتشار این پاسخ برای همه"
                    aria-label="تأیید این پاسخ">
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="m9 12 2 2 4-4"></path></svg>
              <span>تأیید</span>
            </button>
          </form>
          <?php endif; ?>
          <?php if (!empty($a['qaLikesOn'])): $aLiked = !empty($a['qaLiked']); ?>
          <!-- پسند پاسخ — فقط اعضای غیرنویسنده (۲.۰.۰) -->
          <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-like-form qa-like-form--answer" data-coid="<?php echo Plugin::e($a['coid']); ?>">
            <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
            <input type="hidden" name="mode" value="like">
            <input type="hidden" name="type" value="post">
            <input type="hidden" name="coid" value="<?php echo Plugin::e($a['coid']); ?>">
            <button type="submit" class="qa-post-action qa-like-btn<?php echo $aLiked ? ' is-liked' : ''; ?>"
                    data-tooltip="<?php echo $aLiked ? 'پسندیده‌اید — برای برداشتن کلیک کنید' : 'پسندیدن این پاسخ'; ?>"
                    aria-label="پسندیدن این پاسخ">
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path></svg>
              <span class="qa-like-count"><?php echo Plugin::faDigits((string) (int) $a['qaLikes']); ?></span>
            </button>
          </form>
          <?php elseif (!empty($a['qaLikesOwn'])): ?>
          <!-- نویسندهٔ پاسخ — نشان شمار پسندهای دریافتی (بدون امکان پسند) -->
          <span class="qa-post-action qa-like-badge" data-tooltip="پسندهای دریافتی پاسخ شما" aria-label="پسندهای دریافتی این پاسخ">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path></svg>
            <span class="qa-like-count"><?php echo Plugin::faDigits((string) (int) $a['qaLikes']); ?></span>
          </span>
          <?php endif; ?>
          <?php if ($canReply): ?>
          <button type="button" class="qa-post-action qa-quote-btn" data-quote-coid="<?php echo Plugin::e($a['coid']); ?>"
                  data-quote-author="<?php echo Plugin::e($a['author']); ?>" data-tooltip="نقل قول این پاسخ در پاسخ خود">
            <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
            <span>نقل قول</span>
          </button>
          <?php endif; ?>
          <?php echo qaEditToggle($a); ?>
          <?php if ($canManage || !empty($a['canEdit'])): ?>
          <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-delete-form qa-delete-form--answer"
                data-confirm="این پاسخ حذف شود؟ این عمل قابل بازگشت نیست."
                data-confirm-title="حذف پاسخ"
                data-confirm-variant="danger"
                data-confirm-ok="بله، حذف شود">
            <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
            <input type="hidden" name="mode" value="delete">
            <input type="hidden" name="coid" value="<?php echo Plugin::e($a['coid']); ?>">
            <button type="submit" class="qa-post-action qa-delete-btn"
                    data-tooltip="حذف این پاسخ"
                    aria-label="حذف این پاسخ">
              <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
              <span>حذف</span>
            </button>
          </form>
          <?php endif; ?>
        </div>

        <div class="qa-foot-side qa-foot-left">
          <?php if ($canMarkBest && $a['status'] === 'approved'): ?>
          <?php if ($isBest): ?>
          <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-best-form"
                data-confirm="انتخاب این پاسخ به‌عنوان بهترین پاسخ برداشته شود؟ پرسش دوباره باز می‌شود."
                data-confirm-title="برداشتن بهترین پاسخ"
                data-confirm-variant="warn"
                data-confirm-ok="بله، برداشته شود">
            <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
            <input type="hidden" name="mode" value="unbest">
            <input type="hidden" name="coid" value="<?php echo Plugin::e($a['coid']); ?>">
            <button type="submit" class="qa-post-action qa-best-toggle is-active" data-tooltip="برداشتن انتخاب بهترین پاسخ">
              <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
              <span>بهترین پاسخ</span>
            </button>
          </form>
          <?php else: ?>
          <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-best-form"
                data-confirm="این پاسخ به‌عنوان بهترین پاسخ انتخاب شود؟ پرسش قفل خواهد شد."
                data-confirm-title="انتخاب بهترین پاسخ"
                data-confirm-variant="ok"
                data-confirm-ok="بله، انتخاب شود">
            <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
            <input type="hidden" name="mode" value="best">
            <input type="hidden" name="coid" value="<?php echo Plugin::e($a['coid']); ?>">
            <button type="submit" class="qa-post-action qa-best-toggle" data-tooltip="انتخاب به‌عنوان بهترین پاسخ (پرسش قفل می‌شود)">
              <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
              <span>بهترین پاسخ</span>
            </button>
          </form>
          <?php endif; ?>
          <?php endif; ?>

          <?php if (!empty($a['qaFlagOn'])): ?>
          <!-- گزارش تخلف پاسخ — فقط اعضای غیرنویسنده (نویسنده/مهمان نمی‌بینند) -->
          <?php /* ۲.۲.۰ — data-flag-type="post" برای جلوگیری از تداخل با پرسش‌های هم‌coid */ ?>
          <button type="button" class="qa-post-action qa-flag-btn qa-flag-trigger<?php echo Plugin::hasFlagged((int) $a['coid'], 'post') ? ' is-flagged' : ''; ?>"
                  data-flag-coid="<?php echo Plugin::e($a['coid']); ?>"
                  data-flag-type="post"
                  data-flag-kind="پاسخ"
                  data-flag-token="<?php echo Plugin::e($token); ?>"
                  data-flag-already="<?php echo Plugin::hasFlagged((int) $a['coid'], 'post') ? '1' : '0'; ?>"
                  data-tooltip="<?php echo Plugin::hasFlagged((int) $a['coid'], 'post') ? 'گزارش داده‌اید' : 'گزارش تخلف'; ?>"
                  aria-label="گزارش تخلف">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path><line x1="4" y1="22" x2="4" y2="15"></line></svg>
          </button>
          <?php endif; ?>

          <?php if ($canManage): $aFlagCount = Plugin::flagCount((int) $a['coid'], 'post'); ?>
          <?php if ($aFlagCount > 0): ?>
          <span class="qa-flag-indicator" data-tooltip="<?php echo Plugin::faDigits($aFlagCount); ?> گزارش تخلف">
            <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path><line x1="4" y1="22" x2="4" y2="15"></line></svg>
            <?php echo Plugin::faDigits($aFlagCount); ?>
          </span>
          <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-clear-flags-form" style="display:inline-flex;"
                data-confirm="<?php echo Plugin::faDigits($aFlagCount); ?> گزارش تخلف ثبت‌شده برای این پاسخ رد شود؟ گزارش‌ها پاک می‌شوند ولی خود پاسخ باقی می‌ماند."
                data-confirm-title="رد کردن گزارش‌ها"
                data-confirm-variant="info"
                data-confirm-ok="بله، رد شود">
            <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
            <input type="hidden" name="mode" value="clear-flags">
            <input type="hidden" name="coid" value="<?php echo Plugin::e($a['coid']); ?>">
            <button type="submit" class="qa-post-action qa-clear-flags-btn" data-tooltip="رد کردن گزارش‌ها" aria-label="رد کردن گزارش‌ها">
              <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
            </button>
          </form>
          <?php endif; ?>
          <?php endif; ?>

          <?php /* ۲.۲.۰ — شمارشگر پاسخ به هدر منتقل شد (سمت چپ)؛ این بلوک خالی نگه داشته شده */ ?>
        </div>
      </footer>
    </article>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <?php /* ۲.۲.۰ — صفحه‌بندی پاسخ‌ها */ ?>
  <?php if ($aPages > 1): ?>
  <nav class="qa-pagination qa-answers-pagination" aria-label="صفحه‌بندی پاسخ‌ها">
    <?php
      $threadBaseUrl = Plugin::threadUrl((int) $question['coid']);
      $answersPageHref = static function (int $n) use ($threadBaseUrl): string {
        return $n <= 1 ? $threadBaseUrl : $threadBaseUrl . '?pa=' . $n;
      };
    ?>
    <?php if ($aPage > 1): ?>
    <a class="qa-page-btn" href="<?php echo Plugin::e($answersPageHref($aPage - 1)); ?>" rel="prev">
      <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 18 15 12 9 6"></polyline></svg>
      <span>قبلی</span>
    </a>
    <?php else: ?>
    <span class="qa-page-btn is-disabled" aria-hidden="true">
      <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 18 15 12 9 6"></polyline></svg>
      <span>قبلی</span>
    </span>
    <?php endif; ?>

    <?php
    $fromA = max(1, $aPage - 2);
    $toA = min($aPages, $fromA + 4);
    $fromA = max(1, $toA - 4);
    if ($fromA > 1): ?>
    <a class="qa-page-btn" href="<?php echo Plugin::e($answersPageHref(1)); ?>"><?php echo Plugin::faDigits(1); ?></a>
    <span class="qa-page-ellipsis" aria-hidden="true">…</span>
    <?php endif; ?>
    <?php for ($p = $fromA; $p <= $toA; $p++): ?>
    <?php if ($p == $aPage): ?>
    <span class="qa-page-btn is-current" aria-current="page"><?php echo Plugin::faDigits($p); ?></span>
    <?php else: ?>
    <a class="qa-page-btn" href="<?php echo Plugin::e($answersPageHref($p)); ?>"><?php echo Plugin::faDigits($p); ?></a>
    <?php endif; ?>
    <?php endfor; ?>
    <?php if ($toA < $aPages): ?>
    <span class="qa-page-ellipsis" aria-hidden="true">…</span>
    <a class="qa-page-btn" href="<?php echo Plugin::e($answersPageHref($aPages)); ?>"><?php echo Plugin::faDigits($aPages); ?></a>
    <?php endif; ?>

    <?php if ($aPage < $aPages): ?>
    <a class="qa-page-btn" href="<?php echo Plugin::e($answersPageHref($aPage + 1)); ?>" rel="next">
      <span>بعدی</span>
      <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 18 9 12 15 6"></polyline></svg>
    </a>
    <?php else: ?>
    <span class="qa-page-btn is-disabled" aria-hidden="true">
      <span>بعدی</span>
      <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 18 9 12 15 6"></polyline></svg>
    </span>
    <?php endif; ?>

    <span class="qa-page-info" aria-live="polite">
      <?php echo Plugin::faDigits($aPage); ?> / <?php echo Plugin::faDigits($aPages); ?>
      <span class="qa-page-info-sep" aria-hidden="true">•</span>
      <?php echo Plugin::faDigits($aTotal); ?> پاسخ
    </span>
  </nav>
  <?php elseif ($aTotal > 0): ?>
  <p class="qa-page-info qa-page-info--solo" aria-live="polite">
    <?php echo Plugin::faDigits($aTotal); ?> پاسخ در این پرسش
  </p>
  <?php endif; ?>
</section>

<?php if ($canReply): ?>
<section class="qa-reply" id="respond">
  <h2 class="qa-reply-title">پاسخ خود را بنویسید</h2>
  <?php if (!empty($canManage) && ($isLocked || !empty($qCatLocked))): ?>
  <p class="qa-reply-admin-note">
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
    <?php if ($isLocked): ?>این پرسش قفل است؛ اما شما مدیر هستید و می‌توانید در آن بنویسید.<?php else: ?>دستهٔ این پرسش قفل است؛ اما شما مدیر هستید و می‌توانید در آن بنویسید.<?php endif; ?>
  </p>
  <?php endif; ?>
  <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-form" id="qa-reply-form">
    <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
    <input type="hidden" name="parent" value="<?php echo Plugin::e($question['coid']); ?>">
    <input type="text" name="website" value="" class="qa-hp" tabindex="-1" autocomplete="off" aria-hidden="true">

    <?php if ($hasLogin): ?>
    <p class="qa-form-identity">
      <?php echo Plugin::avatar((string) $this->user->screenName, (string) $this->user->mail); ?>
      <span>ارسال با حساب <b><?php echo Plugin::e($this->user->screenName); ?></b></span>
    </p>
    <?php else: ?>
    <div class="qa-form-row">
      <div class="qa-field">
        <label for="qa-reply-author">نام <span class="qa-req">*</span></label>
        <input type="text" id="qa-reply-author" name="author" required maxlength="150"
               placeholder="نام شما" value="<?php echo Plugin::e($rememberAuthor); ?>">
      </div>
      <div class="qa-field">
        <label for="qa-reply-mail">ایمیل<?php if ($requireMail): ?> <span class="qa-req">*</span><?php endif; ?></label>
        <input type="email" id="qa-reply-mail" name="mail" dir="ltr" placeholder="you@example.com"
               <?php echo $requireMail ? 'required' : ''; ?> value="<?php echo Plugin::e($rememberMail); ?>">
      </div>
    </div>
    <?php endif; ?>

    <div class="qa-field">
      <label for="qa-reply-text">متن پاسخ <span class="qa-req">*</span></label>
      <?php $toolbarTarget = 'qa-reply-text'; include __DIR__ . '/toolbar.php'; ?>
      <textarea id="qa-reply-text" name="text" rows="4" required maxlength="<?php echo Plugin::e($maxLen); ?>"
                placeholder="پاسخ خود را بنویسید…"><?php echo Plugin::e((string) (\Typecho\Cookie::get('__typecho_remember_text') ?? '')); ?></textarea>
    </div>

    <div class="qa-form-actions">
      <button type="submit" class="qa-btn qa-btn-primary">ارسال پاسخ</button>
      <button type="button" class="qa-btn qa-btn-ghost qa-form-cancel" data-target="answers">لغو</button>
    </div>
  </form>
</section>
<?php elseif ($isLocked && empty($canManage)): ?>
<div class="qa-closed-note qa-locked-note">
  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
  <?php if ($autoLocked): ?>
  این پرسش به‌دلیل طولانی‌شدن زمان بدون فعالیت، به‌طور خودکار قفل شده است.
  <?php elseif ($bestAnswerId > 0): ?>
  این پرسش به‌دلیل انتخاب بهترین پاسخ، قفل شده است؛ امکان نوشتن پاسخ جدید نیست.
  <?php else: ?>
  این پرسش قفل شده است؛ امکان نوشتن پاسخ جدید نیست.
  <?php endif; ?>
</div>
<?php elseif (!empty($qCatLocked) && empty($canManage)): ?>
<div class="qa-closed-note qa-locked-note">
  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
  دستهٔ این پرسش قفل است؛ فقط مدیران می‌توانند پاسخ بنویسند.
</div>
<?php elseif (!empty($viewerBan)): ?>
<div class="qa-closed-note qa-locked-note">
  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"></line></svg>
  حساب شما <?php echo Plugin::e(Plugin::banUntilText($viewerBan)); ?> از نوشتن در انجمن مسدود است.
</div>
<?php elseif (!$commentsOpen): ?>
<p class="qa-closed-note">ارسال پاسخ برای این پرسش بسته شده است.</p>
<?php elseif (!$hasLogin): ?>
<p class="qa-closed-note">برای نوشتن پاسخ، <a href="<?php echo Plugin::e($loginUrl); ?>">وارد حساب خود شوید</a>.</p>
<?php endif; ?>

</div>

<?php /* ۲.۲.۰ — مودال دلیل گزارش تخلف (حداکثر ۱۶۰ کاراکتر) — روی کلیک پرچم باز می‌شود */ ?>
<div class="qa-flag-modal" id="qa-flag-modal" hidden role="dialog" aria-modal="true" aria-labelledby="qa-flag-modal-title">
  <div class="qa-flag-modal-backdrop" data-flag-close></div>
  <div class="qa-flag-modal-card" role="document">
    <div class="qa-flag-modal-head">
      <h3 class="qa-flag-modal-title" id="qa-flag-modal-title">
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path><line x1="4" y1="22" x2="4" y2="15"></line></svg>
        گزارش تخلف
      </h3>
      <button type="button" class="qa-flag-modal-close" data-flag-close aria-label="بستن">&times;</button>
    </div>
    <div class="qa-flag-modal-body">
      <p class="qa-flag-modal-intro" id="qa-flag-modal-intro">دلیل گزارش این <b id="qa-flag-modal-kind">پست</b> را بنویسید (حداکثر ۱۶۰ کاراکتر).</p>
      <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-flag-modal-form" id="qa-flag-modal-form">
        <input type="hidden" name="_" id="qa-flag-modal-token" value="">
        <input type="hidden" name="mode" value="flag">
        <input type="hidden" name="coid" id="qa-flag-modal-coid" value="">
        <input type="hidden" name="type" id="qa-flag-modal-type" value="">
        <textarea name="reason" id="qa-flag-modal-reason" rows="4" maxlength="160"
                  placeholder="مثلاً: حاوی توهین، هرزنامه، محتوای نامناسب برای عموم…"
                  aria-label="دلیل گزارش"></textarea>
        <div class="qa-flag-modal-counter">
          <span id="qa-flag-modal-counter">۰</span> / ۱۶۰ کاراکتر
        </div>
        <div class="qa-flag-modal-actions">
          <button type="button" class="qa-btn qa-btn-ghost" data-flag-close>انصراف</button>
          <button type="submit" class="qa-btn qa-btn-primary" id="qa-flag-modal-submit">ثبت گزارش</button>
        </div>
        <p class="qa-flag-modal-hint" id="qa-flag-modal-hint" hidden></p>
      </form>
    </div>
  </div>
</div>

<?php include __DIR__ . '/sidebar.php'; ?>
</div>