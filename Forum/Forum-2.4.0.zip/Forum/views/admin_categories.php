<?php

use TypechoPlugin\Forum\Plugin;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
?>
<?php
// سربرگ مشترک (۲.۰.۰) — با عنوان اختصاصی این صفحه؛ نوار مرتب‌سازی همیشه دیده می‌شود
$qaPageKind = 'categories';
$qaHeaderTitle = 'مدیریت دسته‌بندی‌ها';
$qaHeaderIntro = 'دسته‌های انجمن را ایجاد، ویرایش یا حذف کنید. هر دسته می‌تواند آیکون و رنگ اختصاصی داشته باشد.';
include __DIR__ . '/header.php';
include __DIR__ . '/sortbar.php';
?>
<div class="qa-layout">
<div class="qa-content">

<?php if ($banner !== null): ?>
<?php $bannerWait = isset($banner[2]) ? (int) $banner[2] : 0; ?>
<div class="qa-banner is-<?php echo Plugin::e($banner[1]); ?>" role="status"<?php echo $bannerWait > 0 ? ' data-wait-banner="' . $bannerWait . '"' : ''; ?>>
  <p>
    <?php echo Plugin::e($banner[0]); ?>
    <?php if ($bannerWait > 0): ?>
    <span class="qa-countdown" data-countdown="<?php echo $bannerWait; ?>" role="timer" aria-live="polite" aria-atomic="true">
      <?php echo Plugin::faDigits((string) sprintf('%02d:%02d', (int) floor($bannerWait / 60), $bannerWait % 60)); ?>
    </span>
    <?php endif; ?>
  </p>
  <button type="button" class="qa-banner-close" aria-label="بستن پیام"<?php echo $bannerWait > 0 ? ' disabled' : ''; ?>>&times;</button>
</div>
<?php endif; ?>

<section class="qa-cat-admin">
  <h2 class="qa-cat-admin-section-title">
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
    افزودن دستهٔ جدید
  </h2>
  <?php /* (۲.۳.۰) فهرست پیشنهادی آیکون‌های Lucide برای input های آیکون */ ?>
  <datalist id="qa-cat-icon-options">
    <?php foreach ($iconOptions as $key => $label): ?>
    <option value="<?php echo Plugin::e($key); ?>"><?php echo Plugin::e($label); ?></option>
    <?php endforeach; ?>
  </datalist>
  <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-form qa-cat-form">
    <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
    <input type="hidden" name="mode" value="cat-create">
    <div class="qa-form-row">
      <div class="qa-field">
        <label for="qa-cat-new-name">نام دسته <span class="qa-req">*</span></label>
        <input type="text" id="qa-cat-new-name" name="name" required maxlength="80" placeholder="مثلاً: پرسش‌های فنی">
      </div>
      <div class="qa-field qa-cat-icon-field">
        <label for="qa-cat-new-icon">آیکون</label>
        <input type="text" id="qa-cat-new-icon" name="icon" maxlength="32" autocomplete="off"
               list="qa-cat-icon-options" placeholder="مثلاً: 🚀 یا code یا lucide:code">
        <p class="qa-field-note">نام آیکون Lucide (code)، ایموجی (🚀) یا lucide:code — خالی = Folder.</p>
      </div>
      <div class="qa-field qa-cat-color-field">
        <label for="qa-cat-new-color">رنگ (اختیاری)</label>
        <input type="color" id="qa-cat-new-color" name="color" value="#7C3AED">
      </div>
      <div class="qa-field qa-cat-order-field">
        <label for="qa-cat-new-order">ترتیب نمایش</label>
        <input type="number" id="qa-cat-new-order" name="order" min="0" max="999" value="0">
      </div>
    </div>
    <div class="qa-form-actions">
      <button type="submit" class="qa-btn qa-btn-primary">افزودن دسته</button>
    </div>
  </form>
</section>

<section class="qa-cat-admin">
  <h2 class="qa-cat-admin-section-title">
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3.01" y2="6"></line><line x1="3" y1="12" x2="3.01" y2="12"></line><line x1="3" y1="18" x2="3.01" y2="18"></line></svg>
    دسته‌های موجود
    <span class="qa-cat-count">(<?php echo Plugin::faDigits(count($categories)); ?>)</span>
  </h2>

  <?php if (empty($categories)): ?>
  <div class="qa-empty">
    <p class="qa-empty-title">هنوز دسته‌ای ساخته نشده است</p>
    <p class="qa-empty-text">از فرم بالا اولین دسته را اضافه کنید.</p>
  </div>
  <?php else: ?>
  <div class="qa-cat-list">
    <?php foreach ($categories as $cat): ?>
      <?php
        $styleAttr = $cat['color'] !== '' ? ' style="--cat-color:' . Plugin::e($cat['color']) . '"' : '';
        $catIsLocked = !empty($cat['locked']);
      ?>
      <article class="qa-cat-item<?php echo $catIsLocked ? ' is-locked-cat' : ''; ?>"<?php echo $styleAttr; ?>>
        <header class="qa-cat-item-head">
          <span class="qa-cat-icon" aria-hidden="true"><?php echo $cat['iconSvg']; ?></span>
          <span class="qa-cat-name"><?php echo Plugin::e($cat['name']); ?></span>
          <span class="qa-cat-meta">
            <?php if ($catIsLocked): ?>
            <span class="qa-badge is-locked" data-tooltip="دستهٔ قفل‌شده — نوشتن فقط برای مدیر">
              <svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
              قفل
            </span>
            <?php endif; ?>
            <span class="qa-cat-count-badge" data-tooltip="شمار تاپیک‌های این دسته">
              <?php echo Plugin::faDigits((int) $cat['topicCount']); ?> تاپیک
            </span>
            <?php if ($cat['color'] !== ''): ?>
            <span class="qa-cat-color-dot" style="background:<?php echo Plugin::e($cat['color']); ?>" data-tooltip="رنگ دسته"></span>
            <?php endif; ?>
          </span>
        </header>

        <?php /* ۲.۲.۰ — قفل/بازکردن دسته: نوشتن فقط با مدیر */ ?>
        <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-cat-lock-form"
              data-confirm="<?php echo $catIsLocked
                  ? 'قفل این دسته باز شود؟ کاربران می‌توانند دوباره در آن پرسش و پاسخ بگذارند.'
                  : 'دستهٔ «' . Plugin::e($cat['name']) . '» قفل شود؟ فقط مدیران می‌توانند در آن پرسش یا پاسخ بنویسند.'; ?>"
              data-confirm-title="<?php echo $catIsLocked ? 'بازکردن قفل دسته' : 'قفل کردن دسته'; ?>"
              data-confirm-variant="warn"
              data-confirm-ok="<?php echo $catIsLocked ? 'بله، باز شود' : 'بله، قفل شود'; ?>">
          <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
          <input type="hidden" name="mode" value="<?php echo $catIsLocked ? 'cat-unlock' : 'cat-lock'; ?>">
          <input type="hidden" name="id" value="<?php echo Plugin::e($cat['id']); ?>">
          <button type="submit" class="qa-btn<?php echo $catIsLocked ? ' qa-btn-primary' : ' qa-btn-ghost'; ?> qa-cat-lock-btn">
            <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
            <?php echo $catIsLocked ? 'بازکردن قفل دسته' : 'قفل کردن دسته'; ?>
          </button>
        </form>

        <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-form qa-cat-edit-form">
          <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
          <input type="hidden" name="mode" value="cat-update">
          <input type="hidden" name="id" value="<?php echo Plugin::e($cat['id']); ?>">
          <div class="qa-form-row">
            <div class="qa-field">
              <label for="qa-cat-edit-name-<?php echo (int) $cat['id']; ?>">نام</label>
              <input type="text" id="qa-cat-edit-name-<?php echo (int) $cat['id']; ?>" name="name"
                     required maxlength="80" value="<?php echo Plugin::e($cat['name']); ?>">
            </div>
            <div class="qa-field qa-cat-icon-field">
              <label for="qa-cat-edit-icon-<?php echo (int) $cat['id']; ?>">آیکون</label>
              <input type="text" id="qa-cat-edit-icon-<?php echo (int) $cat['id']; ?>" name="icon" maxlength="32" autocomplete="off"
                     list="qa-cat-icon-options" placeholder="مثلاً: 🚀 یا code یا lucide:code"
                     value="<?php echo Plugin::e($cat['icon']); ?>">
              <p class="qa-field-note">نام آیکون Lucide (code)، ایموجی (🚀) یا lucide:code — خالی = Folder.</p>
            </div>
            <div class="qa-field qa-cat-color-field">
              <label for="qa-cat-edit-color-<?php echo (int) $cat['id']; ?>">رنگ</label>
              <input type="color" id="qa-cat-edit-color-<?php echo (int) $cat['id']; ?>" name="color"
                     value="<?php echo $cat['color'] !== '' ? Plugin::e($cat['color']) : '#7C3AED'; ?>">
            </div>
            <div class="qa-field qa-cat-order-field">
              <label for="qa-cat-edit-order-<?php echo (int) $cat['id']; ?>">ترتیب</label>
              <input type="number" id="qa-cat-edit-order-<?php echo (int) $cat['id']; ?>" name="order"
                     min="0" max="999" value="<?php echo (int) $cat['order']; ?>">
            </div>
          </div>
          <div class="qa-form-actions">
            <button type="submit" class="qa-btn qa-btn-primary">ذخیرهٔ تغییرات</button>
          </div>
        </form>

        <form method="post" action="<?php echo Plugin::e(Plugin::postUrl()); ?>" class="qa-cat-delete-form"
              data-confirm="دستهٔ «<?php echo Plugin::e($cat['name']); ?>» حذف شود؟ تاپیک‌های این دسته به گزینهٔ انتخاب‌شده منتقل می‌شوند."
              data-confirm-title="حذف دسته"
              data-confirm-variant="danger"
              data-confirm-ok="بله، حذف شود">
          <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
          <input type="hidden" name="mode" value="cat-delete">
          <input type="hidden" name="id" value="<?php echo Plugin::e($cat['id']); ?>">
          <div class="qa-form-row qa-cat-delete-row">
            <div class="qa-field qa-cat-reassign-field">
              <label for="qa-cat-reassign-<?php echo (int) $cat['id']; ?>">انتقال تاپیک‌ها به</label>
              <select id="qa-cat-reassign-<?php echo (int) $cat['id']; ?>" name="reassign">
                <option value="0">بدون دسته</option>
                <?php foreach ($categories as $other): ?>
                  <?php if ((int) $other['id'] !== (int) $cat['id']): ?>
                  <option value="<?php echo Plugin::e($other['id']); ?>"><?php echo Plugin::e($other['name']); ?></option>
                  <?php endif; ?>
                <?php endforeach; ?>
              </select>
            </div>
            <button type="submit" class="qa-btn qa-btn-danger">حذف دسته</button>
          </div>
        </form>
      </article>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</section>

</div>
<?php include __DIR__ . '/sidebar.php'; ?>
</div>
