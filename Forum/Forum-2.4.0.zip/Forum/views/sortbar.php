<?php

use TypechoPlugin\Forum\Plugin;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}


$qaSbKind = $qaPageKind ?? 'list';
$qaSbIsList = $qaSbKind === 'list';
$qaSbSort = isset($sort) ? (string) $sort : 'newest';
$qaSbSearch = isset($search) ? (string) $search : '';
$qaSbIsSearch = $qaSbSearch !== '';
$qaSbCanAsk = ($guestAsk || $hasLogin) && $commentsOpen;
$qaSbWidgets = is_array($sidebarWidgets ?? null) ? $sidebarWidgets : [];
// (اصلاح مهمان‌ها) سایدبار فقط زمانی دکمهٔ «پرسش جدید» را واقعاً نشان می‌دهد که
// بینندهٔ فعلی اجازهٔ پرسش داشته باشد: عضو واردشده، یا مهمانی که تنظیم
// «پرسش مهمان‌ها» برایش باز است. برای مهمانِ غیرمجاز سایدبار دکمهٔ «ورود به
// حساب» دارد؛ پس دکمهٔ ورود نوار بالا باید حفظ شود نه حذف.
$qaSbSidebarUser = !empty($showSidebar) && in_array('user', $qaSbWidgets, true);
$qaSbSidebarAsk = $qaSbSidebarUser && $qaSbCanAsk;
$qaSbAskOpen = $qaSbIsList && !empty($askOpen);
// خانه/جدیدترین پیش‌فرض: فعال وقتی نمای فهرست بدون جستجو و روی مرتب‌سازی پیش‌فرض است
$qaSbHomeActive = $qaSbIsList && !$qaSbIsSearch && $qaSbSort === 'newest';

// (۲.۳.۰ رفع) تب‌های مرتب‌سازی در همهٔ صفحات نمایش داده می‌شوند
// (فهرست، پروفایل، صفحهٔ تک‌پرسش، مدیریت دسته‌ها، پیام خصوصی و …).
$qaSbShowSorts = true;

// دادهٔ تب‌های مخفی — اینجا محاسبه می‌شود تا همهٔ صفحات (فهرست و پروفایل)
// بدون وابستگی به context صفحهٔ میزبان، همان شرط‌ها را داشته باشند:
//   «گزارش‌ها»: فقط مدیر و فقط وقتی گزارش فعالی هست؛
//   «در انتظار تأیید»: مدیر = کل صف؛ عضو = پرسش‌های در انتظارِ خودش.
$qaSbPendingShow = false;
$qaSbPendingBadge = 0;
$qaSbFlagged = 0;
if ($qaSbShowSorts) {
    $qaSbCanManage = !empty($canManage);
    if ($qaSbCanManage) {
        $qaSbFlagged = Plugin::totalFlagCount();
        $qaSbPendingBadge = Plugin::pendingCount();
    } elseif (Plugin::viewerUid() > 0) {
        $qaSbPendingBadge = Plugin::countWaitingTopics(Plugin::viewerUid());
    }
    $qaSbPendingShow = $qaSbPendingBadge > 0;
}
?>
<div class="qa-stats" role="status">
  <div class="qa-sort-bar">
    <a class="qa-sort-btn qa-sort-home<?php echo $qaSbHomeActive ? ' is-active' : ''; ?>"
       href="<?php echo Plugin::e(Plugin::forumUrl()); ?>"
       data-tooltip="خانه — جدیدترین پرسش‌ها" aria-label="خانه — جدیدترین پرسش‌ها">
      <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
    </a>
    <?php if ($qaSbShowSorts): ?>
    <a class="qa-sort-btn<?php echo $qaSbSort === 'popular' ? ' is-active' : ''; ?>"
       href="<?php echo Plugin::e(Plugin::forumUrl() . '?sort=popular' . ($qaSbSearch !== '' ? '&q=' . rawurlencode($qaSbSearch) : '')); ?>"
       data-tooltip="محبوب‌ترین پرسش‌ها" aria-label="محبوب‌ترین">
      <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"></path></svg>
      <span>محبوب‌ترین</span>
    </a>
    <a class="qa-sort-btn<?php echo $qaSbSort === 'unread' ? ' is-active' : ''; ?>"
       href="<?php echo Plugin::e(Plugin::forumUrl() . '?sort=unread' . ($qaSbSearch !== '' ? '&q=' . rawurlencode($qaSbSearch) : '')); ?>"
       data-tooltip="پرسش‌های خوانده‌نشده" aria-label="خوانده‌نشده">
      <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"></circle></svg>
      <span>خوانده‌نشده</span>
    </a>
    <?php if (!empty($qaSbPendingShow)): ?>
    <a class="qa-sort-btn qa-sort-btn--pending<?php echo $qaSbSort === 'pending' ? ' is-active' : ''; ?>"
       href="<?php echo Plugin::e(Plugin::forumUrl() . '?sort=pending'); ?>"
       data-tooltip="پیام‌های در انتظار تأیید" aria-label="در انتظار تأیید">
      <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 22h14"></path><path d="M5 2h14"></path><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"></path><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"></path></svg>
      <span>در انتظار تأیید</span>
      <span class="qa-sort-badge"><?php echo Plugin::faDigits((string) (int) $qaSbPendingBadge); ?></span>
    </a>
    <?php endif; ?>
    <?php if (!empty($canManage) && $qaSbFlagged > 0): ?>
    <a class="qa-sort-btn qa-sort-btn--flagged<?php echo $qaSbSort === 'reported' ? ' is-active' : ''; ?>"
       href="<?php echo Plugin::e(Plugin::forumUrl() . '?sort=reported'); ?>"
       data-tooltip="پرسش‌های گزارش‌شده" aria-label="گزارش‌ها">
      <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path><line x1="4" y1="22" x2="4" y2="15"></line></svg>
      <span>گزارش‌ها</span>
      <span class="qa-sort-badge"><?php echo Plugin::faDigits((int) $qaSbFlagged); ?></span>
    </a>
    <?php endif; ?>
    <?php endif; ?>
  </div>

  <?php if ($qaSbCanAsk && !$qaSbSidebarAsk): ?>
  <a class="qa-sort-ask qa-nav-ask<?php echo $qaSbAskOpen ? ' is-open' : ''; ?>"
     href="<?php echo Plugin::e($askUrl); ?>"
     aria-expanded="<?php echo $qaSbAskOpen ? 'true' : 'false'; ?>"
     data-tooltip="پرسش تازه بپرسید">
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
    <span>پرسش جدید</span>
  </a>
  <?php elseif (!$hasLogin && !$qaSbSidebarUser): ?>
  <a class="qa-sort-ask" href="<?php echo Plugin::e($loginUrl); ?>" data-tooltip="برای پرسیدن پرسش وارد شوید">
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path><polyline points="10 17 15 12 10 7"></polyline><line x1="15" y1="12" x2="3" y2="12"></line></svg>
    <span>ورود برای پرسش</span>
  </a>
  <?php endif; ?>

  <?php if ($qaSbIsList && !$qaSbIsSearch && !empty($catFilter)):
    $activeCat = Plugin::getCategory((int) $catFilter);
    if ($activeCat !== null):
  ?>
  <a class="qa-filter-chip" href="<?php echo Plugin::e(Plugin::forumUrl()); ?>"
     style="<?php echo $activeCat['color'] !== '' ? '--cat-color:' . Plugin::e($activeCat['color']) . ';' : ''; ?>"
     data-tooltip="نمایش همهٔ پرسش‌ها — حذف فیلتر دسته">
    <?php echo Plugin::categoryIconSvg($activeCat['icon'], 13); ?>
    <span><?php echo Plugin::e($activeCat['name']); ?></span>
    <span class="qa-filter-chip-x" aria-hidden="true">
      <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
    </span>
  </a>
  <?php endif; endif; ?>
  <?php if ($qaSbIsList && $qaSbIsSearch): ?>
  <a class="qa-filter-chip" href="<?php echo Plugin::e(Plugin::forumUrl()); ?>" data-tooltip="حذف جستجو">
    <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
    <span>نتایج «<?php echo Plugin::e($qaSbSearch); ?>» — <?php echo Plugin::faDigits(count($questions ?? [])); ?> مورد</span>
    <span class="qa-filter-chip-x" aria-hidden="true">
      <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
    </span>
  </a>
  <?php endif; ?>
</div>
