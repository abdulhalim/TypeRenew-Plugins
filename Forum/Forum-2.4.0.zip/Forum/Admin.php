<?php
/**
 * لایهٔ دادهٔ پنل مدیریت انجمن — نسخهٔ ۲ (۲.۰.۰)
 *
 * @package Forum
 */

namespace TypechoPlugin\Forum;

use Typecho\Db;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Admin
{
    /** آمار کلی برای سربرگ و تب نمای کلی */
    public static function overviewStats(): array
    {
        $stats = [
            'topics' => 0,
            'answers' => 0,
            'waiting' => 0,
            'spam' => 0,
            'flags' => 0,
            'categories' => 0,
            'members' => 0,
            'unanswered' => 0,
        ];

        try {
            $db = Db::get();

            $stats['topics'] = (int) $db->fetchObject(
                $db->select(['COUNT(id)' => 'n'])->from('table.forum_topics')->where('status = ?', 'approved')
            )->n;
            $stats['answers'] = (int) $db->fetchObject(
                $db->select(['COUNT(id)' => 'n'])->from('table.forum_posts')->where('status = ?', 'approved')
            )->n;
            $stats['waiting'] = (int) $db->fetchObject(
                $db->select(['COUNT(id)' => 'n'])->from('table.forum_topics')->where('status = ?', 'waiting')
            )->n + (int) $db->fetchObject(
                $db->select(['COUNT(id)' => 'n'])->from('table.forum_posts')->where('status = ?', 'waiting')
            )->n;
            $stats['spam'] = (int) $db->fetchObject(
                $db->select(['COUNT(id)' => 'n'])->from('table.forum_topics')->where('status = ?', 'spam')
            )->n + (int) $db->fetchObject(
                $db->select(['COUNT(id)' => 'n'])->from('table.forum_posts')->where('status = ?', 'spam')
            )->n;
            $stats['flags'] = Plugin::totalFlagCount();
            $stats['categories'] = count(Plugin::categories());
            $stats['members'] = (int) $db->fetchObject(
                $db->select(['COUNT(uid)' => 'n'])->from('table.users')
            )->n;

            // پرسش‌های بی‌پاسخ
            $answered = $db->fetchAll(
                $db->select('topic_id')->from('table.forum_posts')
                    ->where('status = ?', 'approved')->group('topic_id')
            );
            $answeredIds = array_map(static fn ($r) => (int) $r['topic_id'], $answered);
            $select = $db->select(['COUNT(id)' => 'n'])->from('table.forum_topics')->where('status = ?', 'approved');
            if (!empty($answeredIds)) {
                $select->where('id NOT IN ?', $answeredIds);
            }
            $stats['unanswered'] = (int) $db->fetchObject($select)->n;

            $stats['views'] = self::viewsTotal();
        } catch (\Throwable $e) {
        }

        return $stats;
    }

    /**
     * مجموع بازدید پرسش‌های تأییدشده (۲.۰.۰ — کارت نمای کلی)
     */
    public static function viewsTotal(): int
    {
        try {
            $db = Db::get();
            return (int) $db->fetchObject(
                $db->select(['COALESCE(SUM(views), 0)' => 'n'])
                    ->from('table.forum_topics')
                    ->where('status = ?', 'approved')
            )->n;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /**
     * روند فعالیت روزانهٔ N روز اخیر (۲.۰.۰ — نمودار نمای کلی)
     *
     * مرز روزها بر اساس منطقهٔ زمانی سایت (Utils\Zone) محاسبه می‌شود.
     * خروجی (قدیمی → جدید): [['label' => '۱ شهریور', 'key' => '2025-08-23', 'topics' => n, 'posts' => n], …]
     */
    public static function activitySeries(int $days = 14): array
    {
        $days = max(7, min(60, $days));

        // ساخت تقویم روزهای محلی
        $cursor = null;
        try {
            $cursor = \Utils\Zone::dateTime(time() - ($days - 1) * 86400);
        } catch (\Throwable $e) {
            $cursor = null;
        }
        if ($cursor === null) {
            try {
                $cursor = new \DateTime('@' . (time() - ($days - 1) * 86400));
            } catch (\Throwable $e) {
                return [];
            }
        }
        // Zone::dateTime مقدار DateTimeImmutable برمی‌گرداند؛ تغییرات
        // باید با گیراندن خروجی اعمال شوند (setTime/modify جدید می‌سازند).
        try {
            $cursor = $cursor->setTime(0, 0, 0);
        } catch (\Throwable $e) {
        }

        $out = [];
        $bounds = [];
        for ($i = 0; $i < $days; $i++) {
            $ts = (int) $cursor->getTimestamp();
            $bounds[] = $ts;
            $out[] = [
                'label'  => Plugin::jalaliDayLabel($ts),
                'key'    => $cursor->format('Y-m-d'),
                'topics' => 0,
                'posts'  => 0,
            ];
            $cursor = $cursor->modify('+1 day');
        }
        $bounds[] = (int) $cursor->getTimestamp();
        $from = $bounds[0];
        $to = $bounds[$days];

        $byKey = [];
        foreach ($out as $i => $day) {
            $byKey[$day['key']] = $i;
        }

        try {
            $db = Db::get();
            $rows = $db->fetchAll(
                $db->select('created')->from('table.forum_topics')
                    ->where('created >= ? AND created < ? AND status <> ?', $from, $to, 'spam')
            );
            foreach ($rows as $r) {
                $idx = self::dayIndex((int) $r['created'], $byKey);
                if ($idx !== null) {
                    $out[$idx]['topics']++;
                }
            }
            $rows = $db->fetchAll(
                $db->select('created')->from('table.forum_posts')
                    ->where('created >= ? AND created < ? AND status <> ?', $from, $to, 'spam')
            );
            foreach ($rows as $r) {
                $idx = self::dayIndex((int) $r['created'], $byKey);
                if ($idx !== null) {
                    $out[$idx]['posts']++;
                }
            }
        } catch (\Throwable $e) {
        }

        return $out;
    }

    /** شاخص روز محلی یک برچسب زمانی — یا null */
    private static function dayIndex(int $ts, array $byKey): ?int
    {
        try {
            $key = \Utils\Zone::dateTime($ts)->format('Y-m-d');
        } catch (\Throwable $e) {
            $key = date('Y-m-d', $ts);
        }
        return $byKey[$key] ?? null;
    }

    /**
     * توزیع ساعتی فعالیت (۲.۰.۰ — نمودار «ساعات شلوغی»)
     *
     * پرسش‌ها و پاسخ‌های ۱۸۰ روز اخیر بر اساس ساعتِ منطقهٔ زمانی سایت؛
     * خروجی: آرایهٔ ۲۴تایی از شمارها (اندیس ۰..۲۳).
     */
    public static function hourlyActivity(): array
    {
        $counts = array_fill(0, 24, 0);
        $from = time() - 180 * 86400;

        try {
            $db = Db::get();
            $rows = $db->fetchAll(
                $db->select('created')->from('table.forum_topics')
                    ->where('created >= ? AND status <> ?', $from, 'spam')
            );
            foreach ($rows as $r) {
                $h = self::localHour((int) $r['created']);
                if ($h >= 0 && $h < 24) {
                    $counts[$h]++;
                }
            }
            $rows = $db->fetchAll(
                $db->select('created')->from('table.forum_posts')
                    ->where('created >= ? AND status <> ?', $from, 'spam')
            );
            foreach ($rows as $r) {
                $h = self::localHour((int) $r['created']);
                if ($h >= 0 && $h < 24) {
                    $counts[$h]++;
                }
            }
        } catch (\Throwable $e) {
        }

        return $counts;
    }

    /** ساعت محلی سایت یک برچسب زمانی (۰..۲۳) */
    private static function localHour(int $ts): int
    {
        try {
            return (int) \Utils\Zone::dateTime($ts)->format('G');
        } catch (\Throwable $e) {
            return (int) date('G', $ts);
        }
    }

    /**
     * دسته‌های پرترافیک (۲.۰.۰ — نمای کلی)
     *
     * خروجی: [['name' => …, 'count' => n, 'color' => …, 'icon' => …], …] نزولی بر اساس شمار.
     */
    public static function topCategories(int $limit = 5): array
    {
        $out = [];
        foreach (Plugin::categoriesForTemplate(true) as $cat) {
            $out[] = [
                'name'  => (string) $cat['name'],
                'count' => (int) $cat['topicCount'],
                'color' => (string) $cat['color'],
                'icon'  => (string) $cat['icon'],
            ];
        }
        usort($out, static fn ($a, $b) => $b['count'] <=> $a['count']);
        return array_slice($out, 0, max(1, $limit));
    }

    /**
     * صف تأیید ترکیبی (۲.۰.۰ — تب «در انتظار تأیید»)
     *
     * پرسش‌ها و پاسخ‌های waiting به‌صورت یک فهرست واحد (جدید → قدیم).
     * هر ردیف کلید kind دارد: 'topic' یا 'post' (+ topic_title برای پاسخ‌ها).
     */
    public static function listPending(int $page, int $size): array
    {
        $db = Db::get();
        $rows = [];

        try {
            $topics = $db->fetchAll(
                $db->select()->from('table.forum_topics')
                    ->where('status = ?', 'waiting')
                    ->order('created', Db::SORT_DESC)
            );
            foreach ($topics as $t) {
                $t['kind'] = 'topic';
                $rows[] = $t;
            }

            $posts = $db->fetchAll(
                $db->select('table.forum_posts.*')->from('table.forum_posts')
                    ->where('table.forum_posts.status = ?', 'waiting')
                    ->order('table.forum_posts.created', Db::SORT_DESC)
            );
            $topicIds = array_values(array_unique(array_map(static fn ($r) => (int) $r['topic_id'], $posts)));
            $topicTitles = [];
            if (!empty($topicIds)) {
                $tRows = $db->fetchAll(
                    $db->select('id', 'text')->from('table.forum_topics')->where('id IN ?', $topicIds)
                );
                foreach ($tRows as $tr) {
                    $topicTitles[(int) $tr['id']] = (string) $tr['text'];
                }
            }
            foreach ($posts as $p) {
                $p['kind'] = 'post';
                $p['topic_title'] = $topicTitles[(int) $p['topic_id']] ?? '';
                $rows[] = $p;
            }
        } catch (\Throwable $e) {
            return ['rows' => [], 'page' => 1, 'pages' => 1, 'total' => 0];
        }

        usort($rows, static fn ($a, $b) => (int) $b['created'] <=> (int) $a['created']);

        $flagMap = Plugin::flagMap();
        foreach ($rows as &$r) {
            $r['flags'] = (int) ($flagMap[$r['kind'] . ':' . (int) $r['id']]['count'] ?? 0);
        }
        unset($r);

        $total = count($rows);
        $pages = max(1, (int) ceil($total / max(1, $size)));
        $slice = array_slice($rows, ($page - 1) * $size, $size);

        return ['rows' => $slice, 'page' => $page, 'pages' => $pages, 'total' => $total];
    }

    /** شمارش هر وضعیت برای تب‌ها — ['topics'=>[...], 'posts'=>[...]] */
    public static function statusCounts(): array
    {
        $out = ['topics' => [], 'posts' => []];
        try {
            $db = Db::get();
            foreach (['topics' => 'table.forum_topics', 'posts' => 'table.forum_posts'] as $key => $table) {
                $rows = $db->fetchAll(
                    $db->select('status', ['COUNT(id)' => 'n'])->from($table)->group('status')
                );
                foreach ($rows as $r) {
                    $out[$key][(string) $r['status']] = (int) $r['n'];
                }
            }
        } catch (\Throwable $e) {
        }
        return $out;
    }

    /** فهرست پرسش‌ها برای پنل */
    public static function listTopics(string $status, string $keyword, int $page, int $size): array
    {
        $db = Db::get();

        $select = $db->select()->from('table.forum_topics')->where('status = ?', $status);
        $count = $db->select(['COUNT(id)' => 'n'])->from('table.forum_topics')->where('status = ?', $status);

        if ($keyword !== '') {
            $kw = '%' . Plugin::likeEscape($keyword) . '%';
            $select->where('author_name LIKE ? OR text LIKE ? OR title LIKE ?', $kw, $kw, $kw);
            $count->where('author_name LIKE ? OR text LIKE ? OR title LIKE ?', $kw, $kw, $kw);
        }

        $total = (int) $db->fetchObject($count)->n;
        $pages = max(1, (int) ceil($total / max(1, $size)));

        $rows = $db->fetchAll(
            $select->order('created', Db::SORT_DESC)->page($page, $size)
        );

        // شمار گزارش هر آیتم
        $flagMap = Plugin::flagMap();
        $out = [];
        foreach ($rows as $r) {
            $r['flags'] = (int) ($flagMap['topic:' . (int) $r['id']]['count'] ?? 0);
            $out[] = $r;
        }

        return ['rows' => $out, 'page' => $page, 'pages' => $pages, 'total' => $total];
    }

    /** فهرست پاسخ‌ها برای پنل (همراه عنوان پرسش والد) */
    public static function listPosts(string $status, string $keyword, int $page, int $size): array
    {
        $db = Db::get();

        $select = $db->select('table.forum_posts.*')->from('table.forum_posts')->where('table.forum_posts.status = ?', $status);
        $count = $db->select(['COUNT(table.forum_posts.id)' => 'n'])->from('table.forum_posts')->where('table.forum_posts.status = ?', $status);

        if ($keyword !== '') {
            $kw = '%' . Plugin::likeEscape($keyword) . '%';
            $select->where('table.forum_posts.author_name LIKE ? OR table.forum_posts.text LIKE ?', $kw, $kw);
            $count->where('table.forum_posts.author_name LIKE ? OR table.forum_posts.text LIKE ?', $kw, $kw);
        }

        $total = (int) $db->fetchObject($count)->n;
        $pages = max(1, (int) ceil($total / max(1, $size)));

        $rows = $db->fetchAll(
            $select->order('table.forum_posts.created', Db::SORT_DESC)->page($page, $size)
        );

        // عنوان تاپیک والد برای هر پاسخ
        $topicIds = array_values(array_unique(array_map(static fn ($r) => (int) $r['topic_id'], $rows)));
        $topicTitles = [];
        if (!empty($topicIds)) {
            $tRows = $db->fetchAll(
                $db->select('id', 'text')->from('table.forum_topics')->where('id IN ?', $topicIds)
            );
            foreach ($tRows as $tr) {
                $topicTitles[(int) $tr['id']] = (string) $tr['text'];
            }
        }

        $flagMap = Plugin::flagMap();
        $out = [];
        foreach ($rows as $r) {
            $r['topic_title'] = $topicTitles[(int) $r['topic_id']] ?? '';
            $r['flags'] = (int) ($flagMap['post:' . (int) $r['id']]['count'] ?? 0);
            $out[] = $r;
        }

        return ['rows' => $out, 'page' => $page, 'pages' => $pages, 'total' => $total];
    }

    // ------------------------------------------------------------------
    //  کاربران و بلاک اداری — ۲.۲.۰
    // ------------------------------------------------------------------

    /**
     * فهرست کاربران برای تب «کاربران» پنل — همراه بلاک فعال.
     *
     * جستجو بر اساس نام نمایشی، نام کاربری یا ایمیل. خروجی:
     * ['rows'=>[...], 'page'=>n, 'pages'=>n, 'total'=>n, 'bannedCount'=>n]
     * هر ردیف: uid، name، mail، group، created، stats(پرسش/پاسخ)، ban(null|array)
     */
    public static function listUsers(string $keyword, int $page, int $size, string $filter = 'all'): array
    {
        $db = Db::get();
        $out = ['rows' => [], 'page' => 1, 'pages' => 1, 'total' => 0, 'bannedCount' => 0];

        try {
            $bans = Plugin::activeBans();

            $select = $db->select('uid', 'name', 'screenName', 'mail', 'group', 'created')->from('table.users');
            $count = $db->select(['COUNT(uid)' => 'n'])->from('table.users');

            if ($keyword !== '') {
                $kw = '%' . Plugin::likeEscape($keyword) . '%';
                $select->where('screenName LIKE ? OR name LIKE ? OR mail LIKE ?', $kw, $kw, $kw);
                $count->where('screenName LIKE ? OR name LIKE ? OR mail LIKE ?', $kw, $kw, $kw);
            }

            // فیلتر: فقط بلاک‌شده‌ها — همان کوئری اصلی با محدودیت uid ها
            if ($filter === 'banned') {
                $bannedIds = array_map('intval', array_keys($bans));
                if (empty($bannedIds)) {
                    return ['rows' => [], 'page' => 1, 'pages' => 1, 'total' => 0, 'bannedCount' => 0];
                }
                $select->where('uid IN ?', $bannedIds);
                $count->where('uid IN ?', $bannedIds);
            }

            $total = (int) $db->fetchObject($count)->n;
            $pages = max(1, (int) ceil($total / max(1, $size)));

            $rows = $db->fetchAll(
                $select->order('uid', Db::SORT_DESC)->page($page, $size)
            );

            // آمار نوشته‌های هر کاربر — در یک کوئری
            $qCounts = [];
            $aCounts = [];
            try {
                $r = $db->fetchAll(
                    $db->select('author_id', ['COUNT(id)' => 'n'])->from('table.forum_topics')
                        ->where('author_id > 0')->group('author_id')
                );
                foreach ($r as $x) {
                    $qCounts[(int) $x['author_id']] = (int) $x['n'];
                }
                $r = $db->fetchAll(
                    $db->select('author_id', ['COUNT(id)' => 'n'])->from('table.forum_posts')
                        ->where('author_id > 0')->group('author_id')
                );
                foreach ($r as $x) {
                    $aCounts[(int) $x['author_id']] = (int) $x['n'];
                }
            } catch (\Throwable $e) {
            }

            foreach ($rows as $u) {
                $uid = (int) $u['uid'];
                $ban = $bans[$uid] ?? null;
                $out['rows'][] = [
                    'uid'      => $uid,
                    'name'     => (string) ($u['screenName'] ?: $u['name']),
                    'mail'     => (string) ($u['mail'] ?? ''),
                    'group'    => (string) ($u['group'] ?? 'subscriber'),
                    'created'  => (int) ($u['created'] ?? 0),
                    'questions' => $qCounts[$uid] ?? 0,
                    'answers'   => $aCounts[$uid] ?? 0,
                    'ban'      => $ban,
                ];
            }

            // شمار کل بلاک‌های فعال (مستقل از فیلتر/صفحه)
            $out['bannedCount'] = count($bans);
            $out['total'] = $total;
            $out['page'] = $page;
            $out['pages'] = $pages;
        } catch (\Throwable $e) {
            return ['rows' => [], 'page' => 1, 'pages' => 1, 'total' => 0, 'bannedCount' => 0];
        }

        return $out;
    }

    /** یافتن یک کاربر برای مودال بلاک — یا null */
    public static function findUser(int $uid): ?array
    {
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('uid', 'name', 'screenName', 'mail', 'group')
                    ->from('table.users')->where('uid = ?', $uid)->limit(1)
            );
            if ($row === null) {
                return null;
            }
            return [
                'uid'   => (int) $row['uid'],
                'name'  => (string) ($row['screenName'] ?: $row['name']),
                'mail'  => (string) ($row['mail'] ?? ''),
                'group' => (string) ($row['group'] ?? 'subscriber'),
            ];
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** فهرست آیتم‌های گزارش‌شده برای پنل */
    public static function listFlagged(int $offset, int $page, int $size): array
    {
        $db = Db::get();

        try {
            $rows = $db->fetchAll(
                $db->select('item_type', 'item_id', ['COUNT(id)' => 'n'])
                    ->from('table.forum_flags')
                    ->group('item_type', 'item_id')
                    ->order('n', Db::SORT_DESC)
            );
        } catch (\Throwable $e) {
            return ['rows' => [], 'page' => 1, 'pages' => 1, 'total' => 0];
        }

        $items = [];
        foreach ($rows as $r) {
            $type = (string) $r['item_type'];
            $id = (int) $r['item_id'];
            $count = (int) $r['n'];

            $first = $db->fetchRow(
                $db->select('created')->from('table.forum_flags')
                    ->where('item_type = ? AND item_id = ?', $type, $id)
                    ->order('created', Db::SORT_ASC)->limit(1)
            );
            $created = (int) ($first['created'] ?? 0);

            $topicId = 0;
            $text = '';
            $authorName = '';
            $authorMail = '';
            if ($type === 'topic') {
                $topic = Plugin::topicById($id);
                if ($topic === null) {
                    continue; // مرده
                }
                $topicId = $id;
                $text = (string) $topic['text'];
                $authorName = (string) $topic['author_name'];
                $authorMail = (string) $topic['author_mail'];
            } else {
                $post = Plugin::postById($id);
                if ($post === null) {
                    continue; // مرده
                }
                $topicId = (int) $post['topic_id'];
                $text = (string) $post['text'];
                $authorName = (string) $post['author_name'];
                $authorMail = (string) $post['author_mail'];
            }

            $items[] = [
                'type' => $type,
                'item_id' => $id,
                'count' => $count,
                'created' => $created,
                'topic_id' => $topicId,
                'text' => $text,
                'author_name' => $authorName,
                'author_mail' => $authorMail,
            ];
        }

        $total = count($items);
        $pages = max(1, (int) ceil($total / max(1, $size)));
        $slice = array_slice($items, ($page - 1) * $size, $size);

        return ['rows' => $slice, 'page' => $page, 'pages' => $pages, 'total' => $total];
    }
}
