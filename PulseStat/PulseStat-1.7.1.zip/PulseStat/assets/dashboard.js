(function () {
    'use strict';

    function ready(fn) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', fn);
        } else {
            fn();
        }
    }

    function fmtNum(n) {
        n = parseInt(n, 10) || 0;
        return n.toLocaleString('en-US');
    }

    /**
     * ساخت ویجت «مقایسه با دوره قبل»
     */
    function buildComparisonWidget(data) {
        var i18n = data.i18n || {};
        var comp = data.comparison || {};
        var html = '';
        html += '<div class="ps-dash-card ps-dash-compare" dir="rtl">';
        html += '  <div class="ps-dash-head">';
        html += '    <h3 class="ps-dash-title">' + (i18n.compareTitle || 'مقایسه با دوره قبل') + '</h3>';
        if (data.panelUrl) {
            html += '    <a class="ps-dash-link" href="' + data.panelUrl + '">' + (i18n.viewDetail || 'مشاهده جزئیات') + '</a>';
        }
        html += '  </div>';
        html += '  <div class="ps-compare-rows">';

        // امروز/دیروز
        ['today', 'week', 'month'].forEach(function (key) {
            var c = comp[key];
            if (!c) return;
            html += buildCompareRow(c, i18n);
        });

        html += '  </div>';
        html += '</div>';
        return html;
    }

    /**
     * ساخت یک ردیف مقایسه
     */
    function buildCompareRow(c, i18n) {
        var label = c.label || '';
        var current = c.current || 0;
        var previous = c.previous || 0;
        var changePct = c.changePct;
        var uniqueCurrent = c.uniqueCurrent || 0;
        var uniquePrevious = c.uniquePrevious || 0;
        var uniqueChangePct = c.uniqueChangePct;

        var html = '';
        html += '<div class="ps-compare-row">';
        html += '  <span class="ps-compare-label">' + escapeHtml(label) + '</span>';
        html += '  <div class="ps-compare-values">';
        html += '    <div class="ps-compare-current">';
        html += '      <span class="ps-compare-num">' + fmtNum(current) + '</span>';
        html += '      <span class="ps-compare-sub">' + (i18n.unique || 'یکتا') + ': ' + fmtNum(uniqueCurrent) + '</span>';
        html += '    </div>';
        html += '    <div class="ps-compare-trend">' + buildTrendBadge(changePct, i18n) + '</div>';
        html += '    <div class="ps-compare-previous">';
        html += '      <span class="ps-compare-prev-num">' + fmtNum(previous) + '</span>';
        html += '      <span class="ps-compare-prev-sub">' + (i18n.previous || 'دوره قبل') + '</span>';
        html += '    </div>';
        html += '  </div>';
        html += '</div>';
        return html;
    }

    /**
     * ساخت نشانگر درصد تغییر (با فلش بالا/پایین)
     */
    function buildTrendBadge(pct, i18n) {
        if (pct === null || pct === undefined) {
            return '<span class="ps-trend ps-trend-none">' + (i18n.noData || 'بدون داده') + '</span>';
        }
        var cls = pct > 0 ? 'ps-trend-up' : (pct < 0 ? 'ps-trend-down' : 'ps-trend-flat');
        var arrow = pct > 0 ? '▲' : (pct < 0 ? '▼' : '●');
        var sign = pct > 0 ? '+' : '';
        return '<span class="ps-trend ' + cls + '">' + arrow + ' ' + sign + pct.toFixed(1) + '%</span>';
    }

    /**
     * ساخت ویجت «ساعات پربازدید»
     */
    function buildHoursWidget(data) {
        var i18n = data.i18n || {};
        var hours = data.hours || {};
        var labels = hours.labels || [];
        var values = hours.values || [];

        var html = '';
        html += '<div class="ps-dash-card ps-dash-hours" dir="rtl">';
        html += '  <div class="ps-dash-head">';
        html += '    <h3 class="ps-dash-title">' + (i18n.hoursTitle || 'ساعات پربازدید (۲۴ ساعت اخیر)') + '</h3>';
        html += '  </div>';

        // خلاصه آماری
        html += '  <div class="ps-hours-stats">';
        html += '    <div class="ps-hours-stat">';
        html += '      <span class="ps-hours-stat-label">' + (i18n.total24h || 'مجموع ۲۴ ساعت') + '</span>';
        html += '      <span class="ps-hours-stat-value">' + fmtNum(hours.total || 0) + '</span>';
        html += '    </div>';
        html += '    <div class="ps-hours-stat">';
        html += '      <span class="ps-hours-stat-label">' + (i18n.peakHour || 'ساعت پربازدید') + '</span>';
        html += '      <span class="ps-hours-stat-value accent">' + fmtNum(hours.peakHour || 0) + ':۰۰</span>';
        html += '    </div>';
        html += '  </div>';

        // نمودار میله‌ای
        if (values.length === 0 || (hours.total || 0) === 0) {
            html += '  <div class="ps-hours-empty">' + (i18n.noData || 'بدون داده') + '</div>';
        } else {
            html += buildHoursChart(values, labels, hours.peakHour || 0, i18n);
        }

        html += '</div>';
        return html;
    }

    /**
     * ساخت نمودار میله‌ای برای ساعات
     */
    function buildHoursChart(values, labels, peakHour, i18n) {
        var max = Math.max.apply(null, values);
        if (max <= 0) max = 1;

        var barCount = values.length;
        var chartWidth = 100;
        var gapPct = barCount > 1 ? 0.5 : 0;
        var barWidth = (chartWidth - (gapPct * (barCount - 1))) / barCount;
        var chartHeight = 100;

        var bars = '';

        for (var i = 0; i < barCount; i++) {
            var v = values[i];
            var h = (v / max) * chartHeight;
            var y = chartHeight - h;
            var x = i * (barWidth + gapPct);
            var isPeak = (i === peakHour && v > 0);

            // فقط هر ۳ ساعت برچسب نمایش می‌دهیم
            var showLabel = (i % 3 === 0) || (i === 23);

            var cls = 'ps-hours-bar';
            if (isPeak) cls += ' is-peak';

            bars += '<rect class="' + cls + '" '
                + 'x="' + x.toFixed(2) + '" '
                + 'y="' + y.toFixed(2) + '" '
                + 'width="' + barWidth.toFixed(2) + '" '
                + 'height="' + h.toFixed(2) + '" '
                + 'rx="1" '
                + 'data-value="' + v + '" '
                + 'data-label="' + escapeAttr(labels[i] || '') + '" '
                + '/>';
        }

        var svg = '<svg class="ps-hours-chart" '
            + 'viewBox="0 0 ' + chartWidth + ' ' + chartHeight + '" '
            + 'preserveAspectRatio="none" '
            + 'role="img" aria-label="' + escapeAttr(i18n.hoursTitle || 'ساعات پربازدید') + '">';
        svg += '<g class="ps-hours-bars">' + bars + '</g>';
        svg += '</svg>';

        // برچسب‌های ساعت به‌صورت HTML
        var labelHtml = '<div class="ps-hours-labels">';
        for (var j = 0; j < barCount; j++) {
            var showLabel = (j % 3 === 0) || (j === 23);
            if (showLabel) {
                var leftPct = j * (barWidth + gapPct) + (barWidth / 2);
                labelHtml += '<span class="ps-hours-label" style="left:' + leftPct.toFixed(2) + '%;">'
                    + escapeHtml(labels[j] || '')
                    + '</span>';
            }
        }
        labelHtml += '</div>';

        // tooltip
        var tooltip = '<div class="ps-hours-tooltip" hidden>'
            + '<span class="ps-hours-tooltip-label"></span>'
            + '<span class="ps-hours-tooltip-value"></span>'
            + '</div>';

        return '<div class="ps-hours-chart-wrap">' + svg + labelHtml + tooltip + '</div>';
    }

    function escapeHtml(str) {
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function escapeAttr(str) {
        return escapeHtml(str);
    }

    function findDashboardAnchor() {
        var grids = document.querySelectorAll('.body.container .tr-grid.cols-2');
        if (grids && grids.length) {
            return grids[0];
        }
        var main = document.querySelector('main.main .body.container');
        return main || null;
    }

    function inject() {
        var dataScript = document.getElementById('ps-dashboard-data');
        if (!dataScript) return;
        var raw = dataScript.textContent || '';
        if (!raw) return;
        var data;
        try { data = JSON.parse(raw); } catch (e) { return; }
        if (!data || typeof data !== 'object') return;

        var host = findDashboardAnchor();
        if (!host) return;

        // ویجت اول: مقایسه با دوره قبل
        var wrapper1 = document.createElement('div');
        wrapper1.className = 'tr-card ps-dash-wrap';
        wrapper1.innerHTML = '<div class="tr-card-b">' + buildComparisonWidget(data) + '</div>';

        // ویجت دوم: ساعات پربازدید
        var wrapper2 = document.createElement('div');
        wrapper2.className = 'tr-card ps-dash-wrap ps-dash-hours-wrap';
        wrapper2.innerHTML = '<div class="tr-card-b">' + buildHoursWidget(data) + '</div>';

        if (host.classList && host.classList.contains('tr-grid')) {
            host.appendChild(wrapper1);
            host.appendChild(wrapper2);
        } else {
            if (host.firstChild) {
                host.insertBefore(wrapper2, host.firstChild);
                host.insertBefore(wrapper1, host.firstChild);
            } else {
                host.appendChild(wrapper1);
                host.appendChild(wrapper2);
            }
        }

        // فعال‌سازی tooltip
        setupHoursTooltips();
    }

    function setupHoursTooltips() {
        var chartWrap = document.querySelector('.ps-hours-chart-wrap');
        if (!chartWrap) return;

        var tooltip = chartWrap.querySelector('.ps-hours-tooltip');
        var tooltipLabel = chartWrap.querySelector('.ps-hours-tooltip-label');
        var tooltipValue = chartWrap.querySelector('.ps-hours-tooltip-value');
        var bars = chartWrap.querySelectorAll('.ps-hours-bar');

        if (!tooltip || !bars.length) return;

        function showTip(bar) {
            var value = bar.getAttribute('data-value') || '0';
            var label = bar.getAttribute('data-label') || '';
            if (tooltipLabel) tooltipLabel.textContent = label + ':۰۰';
            if (tooltipValue) {
                tooltipValue.textContent = fmtNum(value) + ' بازدید';
            }
            tooltip.hidden = false;
            tooltip.classList.add('is-visible');

            var rect = bar.getBoundingClientRect();
            var wrapRect = chartWrap.getBoundingClientRect();
            var left = rect.left - wrapRect.left + (rect.width / 2);
            var top = rect.top - wrapRect.top - 8;
            tooltip.style.left = left + 'px';
            tooltip.style.top = top + 'px';
            tooltip.style.transform = 'translate(-50%, -100%)';
        }

        function hideTip() {
            tooltip.hidden = true;
            tooltip.classList.remove('is-visible');
        }

        bars.forEach(function (bar) {
            bar.addEventListener('mouseenter', function () { showTip(bar); });
            bar.addEventListener('mouseleave', hideTip);
            bar.addEventListener('focus', function () { showTip(bar); });
            bar.addEventListener('blur', hideTip);
        });
    }

    ready(inject);
})();
