(function () {
    'use strict';

    /* ===========================================================
     *  Gregorian → Jalali conversion (vanilla, self-contained)
     * ===========================================================
     *  Algorithm: jalaali-js (https://github.com/jalaali/jalaali-js)
     *  License: MIT
     *
     *  Returns [jy, jm, jd] for a given [gy, gm, gd].
     */
    function div(a, b) { return Math.floor(a / b); }

    function gregorianToJalali(gy, gm, gd) {
        var gDaysInMonth = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
        gy = gy | 0; gm = gm | 0; gd = gd | 0;
        var jy;
        if (gy <= 1600) {
            jy = 0;
            gy -= 621;
        } else {
            jy = 979;
            gy -= 1600;
        }
        var gy2 = (gm > 2) ? (gy - 1) : gy;
        var days = 365 * gy
            + div(gy2 + 3, 4)
            - div(gy2 + 99, 100)
            + div(gy2 + 399, 400)
            - 80
            + gd
            + gDaysInMonth[gm - 1];

        jy += 33 * div(days, 12053);
        days %= 12053;
        jy += 4 * div(days, 1461);
        days %= 1461;

        if (days > 365) {
            jy += div(days - 1, 365);
            days = (days - 1) % 365;
        }
        var jm = (days < 186)
            ? 1 + div(days, 31)
            : 7 + div(days - 186, 30);
        var jd = 1 + ((days < 186)
            ? (days % 31)
            : ((days - 186) % 30));
        return [jy, jm, jd];
    }

    /**
     * Converts a 'YYYY-MM-DD' Gregorian string into a Jalali-formatted string.
     * Returns the input unchanged if it doesn't match the expected format.
     *
     * @param {string} gregorian  Gregorian date in YYYY-MM-DD format.
     * @param {string} format     Format string. Tokens:
     *                              Y => Jalali year (4 digits)
     *                              y => 2-digit year
     *                              m => zero-padded month (01-12)
     *                              n => month (1-12)
     *                              d => zero-padded day (01-31)
     *                              j => day (1-31)
     *                              F => full Persian month name
     *                              M => short Persian month name
     * @return {string}
     */
    function toJalali(gregorian, format) {
        if (typeof gregorian !== 'string' || gregorian.length !== 10) {
            return gregorian;
        }
        var parts = gregorian.split('-');
        if (parts.length !== 3 || parts.some(function (p) { return isNaN(parseInt(p, 10)); })) {
            return gregorian;
        }
        var gy = parseInt(parts[0], 10);
        var gm = parseInt(parts[1], 10);
        var gd = parseInt(parts[2], 10);
        var j = gregorianToJalali(gy, gm, gd);
        return formatJalali(j[0], j[1], j[2], format || 'Y/m/d');
    }

    /** Persian month names (1-indexed). */
    var J_MONTHS = [
        'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
        'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
    ];
    var J_MONTHS_SHORT = [
        'فرو', 'ارد', 'خرد', 'تیر', 'مرد', 'شهر',
        'مهر', 'آبا', 'آذر', 'دی', 'بهم', 'اسف'
    ];

    function formatJalali(jy, jm, jd, format) {
        var out = '';
        for (var i = 0; i < format.length; i++) {
            var ch = format[i];
            switch (ch) {
                case 'Y': out += jy; break;
                case 'y': out += String(jy).slice(-2); break;
                case 'm': out += (jm < 10 ? '0' + jm : jm); break;
                case 'n': out += jm; break;
                case 'd': out += (jd < 10 ? '0' + jd : jd); break;
                case 'j': out += jd; break;
                case 'F': out += J_MONTHS[jm - 1] || ''; break;
                case 'M': out += J_MONTHS_SHORT[jm - 1] || ''; break;
                default: out += ch;
            }
        }
        return out;
    }

    /** Short Jalali label for chart X-axis ticks (MM/DD). */
    function toJalaliShort(gregorian) {
        return toJalali(gregorian, 'm/d');
    }

    /** Long Jalali label for chart tooltips (full date with month name). */
    function toJalaliLong(gregorian) {
        return toJalali(gregorian, 'd F Y');
    }

    /* ===========================================================
     *  Chart.js initialization
     * =========================================================== */

    /** Common Chart.js options shared by both charts. */
    function baseOptions(extra) {
        return Object.assign({
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        usePointStyle: true,
                        boxWidth: 8,
                        padding: 14,
                    },
                },
                tooltip: {
                    backgroundColor: 'rgba(15,23,42,0.95)',
                    padding: 10,
                    cornerRadius: 6,
                    rtl: true,
                    titleAlign: 'right',
                    bodyAlign: 'right',
                },
            },
        }, extra || {});
    }

    /** Initialize the 14-day line chart with Jalali X-axis labels. */
    function initVisitsChart() {
        var dataEl = document.getElementById('sr-chart-data');
        var canvas = document.getElementById('sr-chart-visits');
        if (!dataEl || !canvas || typeof Chart === 'undefined') {
            return;
        }
        var payload;
        try {
            payload = JSON.parse(dataEl.textContent || '{}');
        } catch (e) {
            console.error('[PulseStat] visits chart data parse failed:', e);
            return;
        }
        var ctx = canvas.getContext('2d');
        // Vertical gradient for the visits dataset fill.
        var gradient = ctx.createLinearGradient(0, 0, 0, 320);
        gradient.addColorStop(0, 'rgba(37,99,235,0.30)');
        gradient.addColorStop(1, 'rgba(37,99,235,0.00)');
        if (Array.isArray(payload.datasets) && payload.datasets[0]) {
            payload.datasets[0].backgroundColor = gradient;
        }
        new Chart(ctx, {
            type: 'line',
            data: payload,
            options: baseOptions({
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: {
                            maxRotation: 0,
                            color: '#64748b',
                            font: { size: 11 },
                            // Convert YYYY-MM-DD to Jalali MM/DD for the
                            // X-axis tick labels.
                            callback: function (_value, index) {
                                var label = (payload.labels || [])[index] || '';
                                return label.length === 10
                                    ? toJalaliShort(label)
                                    : label;
                            },
                        },
                    },
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: '#64748b',
                            font: { size: 11 },
                            precision: 0,
                        },
                        grid: { color: 'rgba(15,23,42,0.06)' },
                    },
                },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            usePointStyle: true,
                            boxWidth: 8,
                            padding: 14,
                        },
                    },
                    tooltip: {
                        backgroundColor: 'rgba(15,23,42,0.95)',
                        padding: 10,
                        cornerRadius: 6,
                        rtl: true,
                        titleAlign: 'right',
                        bodyAlign: 'right',
                        callbacks: {
                            // Show the full Jalali date in the tooltip title
                            // (e.g. "27 مهر 1404").
                            title: function (items) {
                                var label = items[0].label || '';
                                return label.length === 10
                                    ? toJalaliLong(label)
                                    : label;
                            },
                        },
                    },
                },
            }),
        });
    }

    /** Initialize the 24-hour peak-hours bar chart. */
    function initHoursChart() {
        var dataEl = document.getElementById('sr-chart-hours-data');
        var canvas = document.getElementById('sr-chart-hours');
        if (!dataEl || !canvas || typeof Chart === 'undefined') {
            return;
        }
        var payload;
        try {
            payload = JSON.parse(dataEl.textContent || '{}');
        } catch (e) {
            console.error('[PulseStat] hours chart data parse failed:', e);
            return;
        }

        // Highlight only the peak bar with the accent color.
        var data = (payload.datasets && payload.datasets[0] && payload.datasets[0].data) || [];
        var maxIndex = 0;
        var maxVal = -Infinity;
        for (var i = 0; i < data.length; i++) {
            if (data[i] > maxVal) {
                maxVal = data[i];
                maxIndex = i;
            }
        }
        var bgColors = data.map(function (_v, idx) {
            return idx === maxIndex && maxVal > 0
                ? 'rgba(37,99,235,0.95)'
                : 'rgba(37,99,235,0.35)';
        });
        if (payload.datasets[0]) {
            payload.datasets[0].backgroundColor = bgColors;
        }

        new Chart(canvas.getContext('2d'), {
            type: 'bar',
            data: payload,
            options: baseOptions({
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: 'rgba(15,23,42,0.95)',
                        padding: 10,
                        cornerRadius: 6,
                        rtl: true,
                        titleAlign: 'right',
                        bodyAlign: 'right',
                        callbacks: {
                            title: function (items) {
                                var label = items[0].label || '';
                                return 'ساعت ' + label;
                            },
                            label: function (item) {
                                return 'بازدید: ' + (item.parsed.y || 0);
                            },
                        },
                    },
                },
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: {
                            color: '#64748b',
                            font: { size: 10 },
                            autoSkip: true,
                            maxRotation: 0,
                            maxTicksLimit: 12,
                        },
                    },
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: '#64748b',
                            font: { size: 11 },
                            precision: 0,
                        },
                        grid: { color: 'rgba(15,23,42,0.06)' },
                    },
                },
            }),
        });
    }

    function init() {
        initVisitsChart();
        initHoursChart();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
