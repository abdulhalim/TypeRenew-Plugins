<?php
declare(strict_types=1);

namespace TypechoPlugin\PulseStat;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit('Access denied.');
}

/**
 * Detects known web crawlers / bots by their User-Agent.
 *
 * Strategy:
 *  1. Empty UA           => assume bot ("Unknown Bot").
 *  2. Exact brand tokens => friendly name (Googlebot, Bingbot, ...).
 *  3. Generic signals    => "Generic Crawler" (bot|crawler|spider|...).
 */
final class BotDetector
{
    /** Ordered list of (regex => friendly name). Order matters. */
    private const KNOWN_BOTS = [
        '/Googlebot(?:-News|-Images|-Video)?/i'         => 'Googlebot',
        '/Google-Read-Aloud/i'                          => 'Google Read Aloud',
        '/Mediapartners-Google/i'                       => 'Google AdSense',
        '/Bingbot/i'                                    => 'Bingbot',
        '/Slurp/i'                                      => 'Slurp (Yahoo)',
        '/DuckDuckBot/i'                                => 'DuckDuckGo Bot',
        '/YandexBot/i'                                  => 'YandexBot',
        '/YandexMetrika/i'                              => 'Yandex Metrika',
        '/Baiduspider/i'                                => 'Baidu Spider',
        '/Sogou web spider/i'                            => 'Sogou Spider',
        '/GPTBot/i'                                     => 'GPTBot',
        '/ClaudeBot/i'                                  => 'ClaudeBot',
        '/Claude-Web/i'                                 => 'Claude Web',
        '/CCBot/i'                                      => 'CCBot',
        '/Bytespider/i'                                 => 'Bytespider',
        '/Applebot/i'                                   => 'Applebot',
        '/facebookexternalhit/i'                        => 'Facebook Crawler',
        '/Twitterbot/i'                                 => 'Twitterbot',
        '/LinkedInBot/i'                                => 'LinkedIn Bot',
        '/WhatsApp/i'                                    => 'WhatsApp',
        '/Telegrambot/i'                                => 'Telegrambot',
        '/AhrefsBot/i'                                  => 'AhrefsBot',
        '/SemrushBot/i'                                 => 'SemrushBot',
        '/MJ12bot/i'                                    => 'Majestic Bot',
        '/PetalBot/i'                                   => 'PetalBot',
        '/SeznamBot/i'                                  => 'Seznam Bot',
        '/Coccocbot/i'                                  => 'Coccocbot',
        '/Crawlybot/i'                                  => 'Crawly',
    ];

    /** Generic crawler signal tokens. */
    private const GENERIC_TOKENS = [
        'bot', 'crawler', 'spider', 'slurp', 'scrape', 'crawl',
        'wget', 'curl', 'libwww', 'python-requests', 'httpx',
        'go-http-client', 'java/', 'okhttp', 'archive.org_bot',
        'monitoring', 'uptime', 'sitechecker', 'lighthouse',
    ];

    /**
     * Returns a non-empty bot name if the UA is identified as a bot,
     * or null if the request looks like a human visitor.
     */
    public function detect(?string $userAgent): ?string
    {
        $ua = trim((string) $userAgent);

        if ($ua === '' || strlen($ua) < 12) {
            return 'Unknown Bot';
        }

        foreach (self::KNOWN_BOTS as $pattern => $name) {
            if (preg_match($pattern, $ua)) {
                return $name;
            }
        }

        $uaLower = strtolower($ua);
        foreach (self::GENERIC_TOKENS as $token) {
            if (str_contains($uaLower, $token)) {
                return 'Generic Crawler';
            }
        }

        return null;
    }

    /** Convenience wrapper returning true/false. */
    public function isBot(?string $userAgent): bool
    {
        return $this->detect($userAgent) !== null;
    }
}
