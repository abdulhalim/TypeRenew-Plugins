<?php
declare(strict_types=1);

/**
 * آمارگیری سریع و امن برای TypeRenew، بدون سرویس‌های خارجی و با حفظ حریم خصوصی کاربران.
 *
 * @package  PulseStat
 * @author   پوردریایی
 * @link     https://pourdaryaei.ir
 * @version  1.7.1
 * @license  GPLv2
 */

namespace TypechoPlugin\PulseStat;

use Typecho\Db;
use Typecho\Plugin as Hook;
use Typecho\Plugin\PluginInterface;
use Typecho\Widget\Helper\Form;
use Utils\Helper;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit('Access denied.');
}

/**
 * Main plugin entry. Implements the TypeRenew/Typecho plugin interface.
 *
 * All plugin classes live in the same namespace (TypechoPlugin\PulseStat)
 * and are placed at the plugin root directory. This is the convention used
 * by TypeRenew's bundled plugins (RenewShield, RenewGo, etc.) and is
 * required because the framework's autoloader resolves
 * `TypechoPlugin\PulseStat\Foo` to `/usr/plugins/PulseStat/Foo.php`.
 */
class Plugin implements PluginInterface
{
    /** Plugin identifier. */
    public const NAME = 'PulseStat';

    /** Database table prefix applied after TypeRenew's configured table prefix. */
    public const TABLE_PREFIX = 'pulsestat_';

    /** Default site salt length (bytes) used for hashing IPs. */
    public const SALT_BYTES = 24;

    /** Default retention period (days) - approximately six months. */
    public const RETENTION_DAYS = 180;

    /** Timezone used for all date math (date_key, created_at, peak hours). */
    public const TIMEZONE = 'Asia/Tehran';

    /** Plugin version. */
    public const VERSION = '1.7.1';

    /**
     * Wired up by TypeRenew when the plugin is enabled.
     *
     * Returns a string status message shown to the administrator.
     */
    public static function activate(): string
    {
        // 1. Ensure DB tables exist.
        Migration::ensure(self::db());

        // 2. Hook: track on every front-end archive render. The `beforeRender`
        //    hook fires after the Archive widget is fully initialised, so we
        //    have direct access to the content metadata (cid, type, title).
        Hook::factory('Widget\Archive')->beforeRender = [Tracker::class, 'onArchiveRender'];

        // 2b. Inject dashboard widgets (comparison + peak hours).
        Hook::factory('admin/footer.php')->end = [Dashboard::class, 'render'];

        // 3. Register the admin panel under "Manage" (parent index 5).
        //    Icon 'i-activity' is the Lucide "activity" / pulse icon shipped
        //    with the TypeRenew admin sprite (admin/img/icons.svg#i-activity).
        Helper::removePanel(5, 'PulseStat/Panel.php');
        Helper::addPanel(
            5,
            'PulseStat/Panel.php',
            _t('آمار بازدید'),
            _t('پایش آمار'),
            'administrator',
            false,
            '',
            ['icon' => 'i-activity']
        );

        return _t('افزونه پایش آمار PulseStat فعال شد.');
    }

    /**
     * Wired up when the plugin is disabled. TypeRenew automatically detaches
     * the hooks we registered in `activate()`. Tables are preserved so that
     * re-enabling restores historical data.
     */
    public static function deactivate(): string
    {
        Helper::removePanel(5, 'PulseStat/Panel.php');
        return _t('افزونه پایش آمار PulseStat غیرفعال شد. جداول دیتابیس نگه‌داری شدند.');
    }

    /**
     * Plugin configuration form shown under "Settings" of the plugin.
     */
    public static function config(Form $form): void
    {
        $enabled = new Form\Element\Radio(
            'enabled',
            ['1' => _t('فعال'), '0' => _t('غیرفعال')],
            '1',
            _t('وضعیت ثبت آمار'),
            _t('در حالت غیرفعال، هیچ بازدیدی ثبت نمی‌شود.')
        );
        $form->addInput($enabled);

        $excluded = new Form\Element\Text(
            'excluded_paths',
            null,
            '/admin,/feed,/sitemap.xml',
            _t('مسیرهای مستثنی (با کاما جدا کنید)'),
            _t('درخواست‌هایی که با این مسیرها شروع می‌شوند ردیابی نمی‌شوند.')
        );
        $form->addInput($excluded);

        $trackAdmin = new Form\Element\Radio(
            'track_admin',
            ['0' => _t('خیر (پیشنهادی)'), '1' => _t('بله')],
            '0',
            _t('ثبت ورودی مدیران'),
            _t('اگر «بله» انتخاب شود، ورودی شما به پنل مدیریت نیز ثبت می‌شود.')
        );
        $form->addInput($trackAdmin);

        $hashSalt = new Form\Element\Text(
            'ip_salt',
            null,
            self::generateSalt(),
            _t('هش سالت IP'),
            _t('برای هش کردن IP بازدیدکنندگان استفاده می‌شود. بازتولید این مقدار، شمارش کاربران یکتا را از نو آغاز می‌کند.')
        );
        $form->addInput($hashSalt);

        $retention = new Form\Element\Text(
            'retention_days',
            null,
            (string) self::RETENTION_DAYS,
            _t('دوره نگه‌داری (روز، پیش‌فرض ۱۸۰ = حدود ۶ ماه)'),
            _t('بازدیدهای قدیمی‌تر از این تعداد روز به‌صورت خودکار حذف می‌شوند، روزی یک‌بار هنگام ورود مدیر به پنل آمار.')
        );
        $form->addInput($retention);
    }

    /** Personal config (per-user). Reserved for future per-author stats. */
    public static function personalConfig(Form $form): void
    {
        // intentionally empty.
    }

    /* -----------------------------------------------------------------
     *  Public helpers (used by Tracker, Repository, Panel)
     * ----------------------------------------------------------------- */

    /** Returns the DB instance shared with TypeRenew core. */
    public static function db(): Db
    {
        return Db::get();
    }

    /**
     * Reads this plugin's options from the TypeRenew options table.
     * Falls back to defaults if anything is missing.
     */
    public static function configMap(): array
    {
        $plugin = Helper::options()->plugin(self::NAME);
        $plugin = $plugin ?? new \stdClass();

        return [
            'enabled'         => (string)($plugin->enabled ?? '1') === '1',
            'excluded_paths'  => (string)($plugin->excluded_paths ?? '/admin,/feed,/sitemap.xml'),
            'track_admin'      => (string)($plugin->track_admin ?? '0') === '1',
            'ip_salt'          => (string)($plugin->ip_salt ?? self::generateSalt()),
            'retention_days'   => (int)($plugin->retention_days ?? self::RETENTION_DAYS),
        ];
    }

    /** Generate a fresh salt for IP hashing. */
    public static function generateSalt(): string
    {
        return bin2hex(random_bytes(self::SALT_BYTES));
    }

    /**
     * Returns a DateTimeZone for the configured plugin timezone (Tehran).
     * All date math (date_key, created_at, peak-hour grouping) uses this so
     * stats are reported in the user's wall-clock time, not the server's UTC.
     */
    public static function tz(): \DateTimeZone
    {
        try {
            return new \DateTimeZone(self::TIMEZONE);
        } catch (\Throwable $e) {
            return new \DateTimeZone('UTC');
        }
    }

    /**
     * Returns the current time in the configured timezone as a formatted string.
     * Default format: 'Y-m-d H:i:s' (compatible with MySQL DATETIME).
     */
    public static function now(string $format = 'Y-m-d H:i:s'): string
    {
        return (new \DateTime('now', self::tz()))->format($format);
    }

    /**
     * Formats a date relative to "now" in the configured timezone.
     * Example: self::relativeDate('-7 days', 'Y-m-d') => '2025-09-10'
     */
    public static function relativeDate(string $modifier, string $format = 'Y-m-d'): string
    {
        return (new \DateTime($modifier, self::tz()))->format($format);
    }

    /**
     * Converts Latin digits in a string to Persian digits (۰-۹).
     * Used for displaying numbers in the admin panel in a culturally
     * appropriate way (in addition to the Vazirmatn font's ss01/ss02/ss03
     * features, which already enable Persian digits).
     */
    public static function faNum(string|int|float $value): string
    {
        $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        $value   = is_scalar($value) ? (string) $value : '';
        return str_replace(['0','1','2','3','4','5','6','7','8','9'], $persian, $value);
    }

    /**
     * Converts a Gregorian date (YYYY-MM-DD) to a Jalali (Persian calendar)
     * date string. Uses the JalaliDate plugin if available, falls back to
     * a built-in algorithm, and finally returns the original Gregorian
     * date if both are unavailable.
     *
     * Output format examples:
     *   'Y/m/d'  => 1404/07/27
     *   'd F Y'  => 27 مهر 1404
     *   'Y-m-d'  => 1404-07-27
     *
     * @param string $gregorian Date in YYYY-MM-DD format.
     * @param string $format    Format string (similar to PHP date() + 'F' for full month name).
     */
    public static function toJalali(string $gregorian, string $format = 'Y/m/d'): string
    {
        // Parse the input.
        $parts = sscanf($gregorian, '%d-%d-%d');
        if (!is_array($parts) || count($parts) < 3 || $parts[0] === null) {
            return $gregorian;
        }
        [$gy, $gm, $gd] = $parts;

        // 1) Preferred: use the JalaliDate plugin if it's installed + active.
        if (class_exists('\TypechoPlugin\JalaliDate\JDate')) {
            try {
                $jDate = \TypechoPlugin\JalaliDate\JDate::toJalali((int)$gy, (int)$gm, (int)$gd);
                return self::formatJalali($jDate[0], $jDate[1], $jDate[2], $format);
            } catch (\Throwable $e) {
                // fall through to built-in algorithm.
            }
        }

        // 2) Built-in Gregorian-to-Jalali algorithm (based on jalaali-js,
        //    used by moment-jalaali). Self-contained so the plugin works
        //    even without JalaliDate installed.
        $jDate = self::builtinGregorianToJalali((int)$gy, (int)$gm, (int)$gd);
        return self::formatJalali($jDate[0], $jDate[1], $jDate[2], $format);
    }

    /**
     * Self-contained Gregorian-to-Jalali conversion (no external deps).
     * Returns [jy, jm, jd].
     *
     * Algorithm: jalaali-js (https://github.com/jalaali/jalaali-js), MIT.
     */
    private static function builtinGregorianToJalali(int $gy, int $gm, int $gd): array
    {
        // Days elapsed at the start of each Gregorian month (non-leap year).
        $gDaysInMonth = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
        $gy2 = ($gm > 2) ? ($gy - 1) : $gy;

        // Total days from a fixed epoch to the given Gregorian date.
        $days = 365 * $gy
            + (int) floor(($gy2 + 3) / 4)
            - (int) floor(($gy2 + 99) / 100)
            + (int) floor(($gy2 + 399) / 400)
            - 80
            + $gd
            + $gDaysInMonth[$gm - 1];

        // Convert the day-count into a Jalali year/month/day.
        $jy = ($gy <= 1600) ? 0 : 979;
        $gy -= ($gy <= 1600) ? 621 : 1600;

        $jy += 33 * (int) floor($days / 12053);
        $days %= 12053;
        $jy += 4 * (int) floor($days / 1461);
        $days %= 1461;

        if ($days > 365) {
            $jy += (int) floor(($days - 1) / 365);
            $days = ($days - 1) % 365;
        }

        $jm = ($days < 186)
            ? 1 + (int) floor($days / 31)
            : 7 + (int) floor(($days - 186) / 30);
        $jd = 1 + (($days < 186)
            ? ($days % 31)
            : (($days - 186) % 30));

        return [$jy, $jm, $jd];
    }

    /**
     * Formats a Jalali date (jy, jm, jd) using a format string.
     * Supported tokens: Y, y, m, n, d, j, F (full Persian month name), M (short Persian month name).
     */
    private static function formatJalali(int $jy, int $jm, int $jd, string $format): string
    {
        $months = [
            'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
            'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
        ];
        $monthsShort = [
            'فرو', 'ارد', 'خرد', 'تیر', 'مرد', 'شهر',
            'مهر', 'آبا', 'آذر', 'دی', 'بهم', 'اسف',
        ];

        $out = '';
        $len = strlen($format);
        for ($i = 0; $i < $len; $i++) {
            $ch = $format[$i];
            switch ($ch) {
                case 'Y': $out .= (string) $jy; break;
                case 'y': $out .= substr((string) $jy, -2); break;
                case 'm': $out .= str_pad((string) $jm, 2, '0', STR_PAD_LEFT); break;
                case 'n': $out .= (string) $jm; break;
                case 'd': $out .= str_pad((string) $jd, 2, '0', STR_PAD_LEFT); break;
                case 'j': $out .= (string) $jd; break;
                case 'F': $out .= $months[$jm - 1] ?? ''; break;
                case 'M': $out .= $monthsShort[$jm - 1] ?? ''; break;
                default:  $out .= $ch;
            }
        }
        return $out;
    }

    /** Append to a debug log file. Only used when debug mode is on. */
    public static function log(string $msg): void
    {
        $debug = defined('__TYPECHO_DEBUG_MODE__') && __TYPECHO_DEBUG_MODE__;
        if (!$debug) {
            return;
        }
        @file_put_contents(
            __DIR__ . '/debug.log',
            '[' . date('Y-m-d H:i:s') . '] ' . $msg . PHP_EOL,
            FILE_APPEND
        );
    }

    /** Returns the absolute public URL of an asset under the plugin folder. */
    public static function assetUrl(string $relative): string
    {
        return \Typecho\Common::url(
            self::NAME . '/' . ltrim($relative, '/'),
            (string) Helper::options()->pluginUrl,
        );
    }
}
