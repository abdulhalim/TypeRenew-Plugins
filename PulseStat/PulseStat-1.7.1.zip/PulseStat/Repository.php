<?php
declare(strict_types=1);

namespace TypechoPlugin\PulseStat;

use Typecho\Db;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit('Access denied.');
}

/**
 * Repository: read-side queries for the admin panel.
 *
 * All reads:
 *  - exclude bots by default (is_bot = 0)
 *  - return plain arrays so they can be JSON-serialised for the chart.
 *
 * Uses TypeRenew's Query Builder so the table prefix is applied automatically
 * and all values are properly escaped.
 *
 * @package PulseStat
 */
final class Repository
{
    private Db $db;
    private string $visitsTable;
    private Cache $cache;

    public function __construct()
    {
        $this->db          = Plugin::db();
        $this->visitsTable = 'table.' . Plugin::TABLE_PREFIX . 'visits';
        $this->cache       = new Cache();
    }

    /**
     * Returns true if the visits table exists. Used by Panel.php to decide
     * whether to attempt queries (and to show a notice when the user has
     * uninstalled the tables but still visits the panel URL).
     */
    public function tablesExist(): bool
    {
        return Migration::exists($this->db);
    }

    /**
     * Wraps a closure that builds + executes a Query Builder query in a
     * try/catch. If the visits table is missing (e.g. right after the user
     * clicked "Drop tables"), returns the provided default instead of
     * letting the fatal error surface to the page.
     *
     * This makes the panel degradable: when the tables aren't installed,
     * the user sees a notice + zero-valued tiles instead of a PDO crash.
     */
    private function safeQuery(callable $fn, mixed $default = null): mixed
    {
        try {
            return $fn();
        } catch (\Throwable $e) {
            Plugin::log('query error: ' . $e->getMessage());
            return $default;
        }
    }

    /* -----------------------------------------------------------------
     *  Summary stats
     * ----------------------------------------------------------------- */

    /**
     * Returns aggregated totals for the requested window.
     *
     * @param string $window 'today' | 'week' | 'month' | 'all'
     */
    public function totals(string $window): array
    {
        $key = 'pulsestat:totals:' . $window;
        return $this->cache->get($key, fn() => $this->computeTotals($window), 300);
    }

    private function computeTotals(string $window): array
    {
        return $this->safeQuery(function () use ($window): array {
            [$whereBots, $args] = $this->rangeWhere($window, excludeBots: true);

            $query = $this->db
                ->select([
                    'COUNT(*)'            => 'total_visits',
                    'COUNT(DISTINCT cid)' => 'unique_visitors',
                ])
                ->from($this->visitsTable)
                ->where($whereBots, ...$args);

            $row  = $this->db->fetchRow($query);
            $bots = $this->countBots($window);

            return [
                'window'          => $window,
                'total_visits'    => (int)($row['total_visits'] ?? 0),
                'unique_visitors' => (int)($row['unique_visitors'] ?? 0),
                'bot_visits'      => $bots,
            ];
        }, [
            'window'          => $window,
            'total_visits'    => 0,
            'unique_visitors' => 0,
            'bot_visits'      => 0,
        ]);
    }

    /** Counts bot-only visits in the window (separate from human visits). */
    private function countBots(string $window): int
    {
        return $this->safeQuery(function () use ($window): int {
            [$whereBots, $args] = $this->rangeWhere($window, excludeBots: false, botsOnly: true);
            $query = $this->db
                ->select(['COUNT(*)' => 'cnt'])
                ->from($this->visitsTable)
                ->where($whereBots, ...$args);
            $row = $this->db->fetchRow($query);
            return (int)($row['cnt'] ?? 0);
        }, 0);
    }

    /**
     * Returns the time-series for the chart.
     *
     * @param int $days Number of past days to return (default 14).
     */
    public function dailySeries(int $days = 14): array
    {
        $key = 'pulsestat:series:' . $days;
        return $this->cache->get($key, fn() => $this->computeDailySeries($days), 300);
    }

    private function computeDailySeries(int $days): array
    {
        return $this->safeQuery(function () use ($days): array {
            // Use Tehran timezone for the date cutoff.
            $start = Plugin::relativeDate("-{$days} days", 'Y-m-d');

            $query = $this->db
                ->select('date_key', ['COUNT(*)' => 'visits'], ['COUNT(DISTINCT cid)' => 'unique_visitors'])
                ->from($this->visitsTable)
                ->where('date_key >= ?', $start)
                ->where('is_bot = ?', 0)
                ->group('date_key')
                ->order('date_key', Db::SORT_ASC);

            $rows = $this->db->fetchAll($query);

            // Backfill missing days so the chart has no gaps.
            $byDate = [];
            foreach ($rows as $r) {
                $byDate[$r['date_key']] = $r;
            }

            $filled = [];
            // Walk backwards in Tehran time so the chart's rightmost point
            // is "today" in the user's wall-clock, not the DB server's UTC.
            for ($i = $days; $i >= 0; $i--) {
                $day = Plugin::relativeDate("-{$i} days", 'Y-m-d');
                $filled[] = [
                    'date_key'        => $day,
                    'visits'          => (int)($byDate[$day]['visits'] ?? 0),
                    'unique_visitors' => (int)($byDate[$day]['unique_visitors'] ?? 0),
                ];
            }
            return $filled;
        }, array_map(fn($i) => [
            'date_key'        => Plugin::relativeDate("-{$i} days", 'Y-m-d'),
            'visits'          => 0,
            'unique_visitors' => 0,
        ], range($days, 0)));
    }

    /* -----------------------------------------------------------------
     *  Top posts
     * ----------------------------------------------------------------- */

    /**
     * Returns up to N most-visited posts for the given window.
     *
     * Groups by `content_id` (the post's cid). Since v1.6.0 we ONLY
     * record single post views, so this query is accurate — no more
     * false positives from list pages.
     *
     * @param string $window 'today' | 'week' | 'month' | 'all'
     * @param int $limit    Max number of posts to return (default 10).
     * @return array<int, array{content_id:int,title:string,path:string,visits:int,unique_visitors:int}>
     */
    public function topPosts(string $window, int $limit = 10): array
    {
        return $this->cache->get(
            'pulsestat:topposts:' . $window . '_' . $limit,
            fn() => $this->computeTopPosts($window, $limit),
            300,
        );
    }

    private function computeTopPosts(string $window, int $limit): array
    {
        return $this->safeQuery(function () use ($window, $limit): array {
            [$where, $args] = $this->rangeWhere($window, excludeBots: true, contentOnly: true);

            $query = $this->db
                ->select(
                    'content_id',
                    ['MAX(title)'         => 'title'],
                    ['MAX(path)'          => 'path'],
                    ['COUNT(*)'           => 'visits'],
                    ['COUNT(DISTINCT cid)' => 'unique_visitors'],
                )
                ->from($this->visitsTable)
                ->where($where, ...$args)
                ->group('content_id')
                ->order('visits', Db::SORT_DESC)
                ->limit($limit);

            $rows = $this->db->fetchAll($query);
            return array_map(static function (array $r): array {
                return [
                    'content_id'      => (int)$r['content_id'],
                    'title'           => (string)($r['title'] ?: '(بدون عنوان)'),
                    'path'            => (string)$r['path'],
                    'visits'          => (int)$r['visits'],
                    'unique_visitors' => (int)$r['unique_visitors'],
                ];
            }, $rows);
        }, []);
    }

    /* -----------------------------------------------------------------
     *  Browser & OS breakdown
     * ----------------------------------------------------------------- */

    /**
     * Returns the top-N browser families by visit count (last 30 days).
     *
     * @param int $limit Max number of rows to return (default 8).
     * @return array<int, array{browser:string, visits:int, unique_visitors:int}>
     */
    public function browserStats(int $limit = 8): array
    {
        return $this->cache->get(
            'pulsestat:browsers:' . $limit,
            fn() => $this->computeBreakdown('browser', $limit),
            300,
        );
    }

    /**
     * Returns the top-N OS families by visit count (last 30 days).
     *
     * @param int $limit Max number of rows to return (default 6).
     * @return array<int, array{os:string, visits:int, unique_visitors:int}>
     */
    public function osStats(int $limit = 6): array
    {
        return $this->cache->get(
            'pulsestat:oses:' . $limit,
            fn() => $this->computeBreakdown('os', $limit),
            300,
        );
    }

    /**
     * Computes a top-N breakdown for a single column (browser or os).
     * Excludes bots (is_bot = 0) and only counts visits from the last 30
     * days (using the Tehran timezone for the cutoff).
     *
     * @param string $column 'browser' or 'os'
     * @param int $limit    Max rows to return.
     */
    private function computeBreakdown(string $column, int $limit): array
    {
        return $this->safeQuery(function () use ($column, $limit): array {
            $cutoff = Plugin::relativeDate('-30 days', 'Y-m-d');
            $colKey = $column;

            $query = $this->db
                ->select(
                    $colKey,
                    ['COUNT(*)'            => 'visits'],
                    ['COUNT(DISTINCT cid)' => 'unique_visitors'],
                )
                ->from($this->visitsTable)
                ->where('date_key >= ?', $cutoff)
                ->where('is_bot = ?', 0)
                ->group($colKey)
                ->order('visits', Db::SORT_DESC)
                ->limit($limit);

            $rows = $this->db->fetchAll($query);
            return array_map(static function (array $r) use ($column): array {
                return [
                    $column          => (string)$r[$column],
                    'visits'         => (int)$r['visits'],
                    'unique_visitors' => (int)$r['unique_visitors'],
                ];
            }, $rows);
        }, []);
    }

    /* -----------------------------------------------------------------
     *  Period-over-period comparison (simple widget)
     * ----------------------------------------------------------------- */

    /**
     * Returns a simple period-over-period comparison for the dashboard:
     *  - today vs. yesterday
     *  - this week (7 days) vs. previous week
     *  - this month (30 days) vs. previous month
     *
     * Each entry has:
     *   current:           visits in the current period
     *   previous:          visits in the previous period
     *   change_pct:        percentage change (-100..+∞, null when previous=0)
     *   unique_current:    unique visitors in current period
     *   unique_previous:   unique visitors in previous period
     *   unique_change_pct: percentage change for unique visitors
     *
     * This widget is intentionally minimal — just three rows of numbers
     * with up/down indicators. No complex charts, no grouping by URL.
     */
    public function comparisonStats(): array
    {
        return $this->cache->get(
            'pulsestat:comparison',
            fn() => $this->computeComparison(),
            300,
        );
    }

    private function computeComparison(): array
    {
        return [
            'today' => $this->comparePeriod(
                Plugin::relativeDate('-1 day', 'Y-m-d'),  // start of yesterday
                Plugin::now('Y-m-d'),                      // start of today
                Plugin::relativeDate('-2 days', 'Y-m-d'), // start of day before yesterday
                Plugin::relativeDate('-1 day', 'Y-m-d'),  // start of yesterday
            ),
            'week' => $this->comparePeriod(
                Plugin::relativeDate('-7 days', 'Y-m-d'),  // start of this week
                Plugin::now('Y-m-d'),                       // today
                Plugin::relativeDate('-14 days', 'Y-m-d'),  // start of last week
                Plugin::relativeDate('-7 days', 'Y-m-d'),   // start of this week
            ),
            'month' => $this->comparePeriod(
                Plugin::relativeDate('-30 days', 'Y-m-d'),  // start of this month window
                Plugin::now('Y-m-d'),                       // today
                Plugin::relativeDate('-60 days', 'Y-m-d'),  // start of last month window
                Plugin::relativeDate('-30 days', 'Y-m-d'),  // start of this month window
            ),
        ];
    }

    /**
     * Compares two date ranges: [curStart, curEnd] vs [prevStart, prevEnd].
     * All four arguments are inclusive lower bounds and exclusive upper
     * bounds (curEnd is today, so the upper bound is tomorrow — but since
     * date_key is DATE, we use '<' so today's rows are included).
     */
    private function comparePeriod(
        string $curStart, string $curEnd,
        string $prevStart, string $prevEnd,
    ): array {
        $cur = $this->countRange($curStart, $curEnd);
        $pre = $this->countRange($prevStart, $prevEnd);

        return [
            'current'           => $cur['visits'],
            'previous'          => $pre['visits'],
            'change_pct'        => $this->pctChange($cur['visits'], $pre['visits']),
            'unique_current'    => $cur['unique'],
            'unique_previous'   => $pre['unique'],
            'unique_change_pct' => $this->pctChange($cur['unique'], $pre['unique']),
        ];
    }

    /** Counts visits + unique visitors in [start, end) (end exclusive). */
    private function countRange(string $start, string $end): array
    {
        return $this->safeQuery(function () use ($start, $end): array {
            $query = $this->db
                ->select([
                    'COUNT(*)'            => 'visits',
                    'COUNT(DISTINCT cid)' => 'unique',
                ])
                ->from($this->visitsTable)
                ->where('date_key >= ?', $start)
                ->where('date_key < ?', $end)
                ->where('is_bot = ?', 0);
            $row = $this->db->fetchRow($query);
            return [
                'visits' => (int)($row['visits'] ?? 0),
                'unique' => (int)($row['unique'] ?? 0),
            ];
        }, ['visits' => 0, 'unique' => 0]);
    }

    /**
     * Returns the percentage change from $previous to $current.
     * Returns null when $previous is 0 (no previous data to compare).
     */
    private static function pctChange(int $current, int $previous): ?float
    {
        if ($previous === 0) {
            return null;
        }
        return round((($current - $previous) / $previous) * 100, 1);
    }

    /* -----------------------------------------------------------------
     *  Maintenance
     * ----------------------------------------------------------------- */

    /** Clears all cached stats reads. */
    public function clearCache(): void
    {
        foreach (['today', 'week', 'month', 'all'] as $w) {
            $this->cache->delete('pulsestat:totals:' . $w);
        }
        $this->cache->delete('pulsestat:series:14');
        $this->cache->delete('pulsestat:series:30');
        $this->cache->delete('pulsestat:hours:24');
        $this->cache->delete('pulsestat:comparison');
        $this->cache->delete('pulsestat:browsers:8');
        $this->cache->delete('pulsestat:oses:6');
        foreach (['today', 'week', 'month', 'all'] as $w) {
            $this->cache->delete('pulsestat:topposts:' . $w . '_10');
        }
    }

    /**
     * Truncates the visits table — useful when testing and you want to
     * start fresh without dropping the table itself.
     *
     * @return int Always returns 1 on success (TypeRenew's adapter does
     *             not consistently report affected rows for TRUNCATE).
     */
    public function resetAllVisits(): int
    {
        return $this->safeQuery(function (): int {
            $dialect = \Utils\Schema::dialect($this->db);
            $table   = $this->db->getPrefix() . Plugin::TABLE_PREFIX . 'visits';
            $tableQ  = \Utils\Schema::quote($table, $dialect);

            // SQLite doesn't support TRUNCATE; use DELETE (no WHERE = all rows).
            if ($dialect === 'sqlite') {
                $sql = sprintf('DELETE FROM %s', $tableQ);
                $this->db->query($sql, Db::WRITE, Db::DELETE);
                return 1;
            }

            // MySQL/MariaDB/PostgreSQL support TRUNCATE.
            $sql = sprintf('TRUNCATE TABLE %s', $tableQ);
            $this->db->query($sql, Db::WRITE, Db::DELETE);
            return 1;
        }, 0);
    }

    /* -----------------------------------------------------------------
     *  Helpers
     * ----------------------------------------------------------------- */

    /**
     * Builds the WHERE clause + bind args for the given window.
     * Returns [sql, args] tuple for use with $db->where($sql, ...$args).
     *
     * @param bool $excludeBots When true, exclude bots from the result set.
     * @param bool $botsOnly    When true, only count bots (overrides excludeBots).
     * @param bool $contentOnly When true, only count content rows (content_id > 0).
     */
    private function rangeWhere(
        string $window,
        bool $excludeBots = true,
        bool $botsOnly = false,
        bool $contentOnly = false,
    ): array {
        $parts = [];
        $args  = [];

        // Compute all date boundaries in Tehran time so "today" / "this week"
        // reflect the user's wall-clock rather than the DB server's UTC.
        $today    = Plugin::now('Y-m-d');
        $weekAgo  = Plugin::relativeDate('-7 days', 'Y-m-d');
        $monthAgo = Plugin::relativeDate('-30 days', 'Y-m-d');

        switch ($window) {
            case 'today':
                $parts[] = 'date_key = ?';
                $args[]  = $today;
                break;
            case 'week':
                $parts[] = 'date_key >= ?';
                $args[]  = $weekAgo;
                break;
            case 'month':
                $parts[] = 'date_key >= ?';
                $args[]  = $monthAgo;
                break;
            case 'all':
            default:
                // no date filter
                break;
        }

        if ($botsOnly) {
            $parts[] = 'is_bot = ?';
            $args[]  = 1;
        } elseif ($excludeBots) {
            $parts[] = 'is_bot = ?';
            $args[]  = 0;
        }

        if ($contentOnly) {
            $parts[] = 'content_id > ?';
            $args[]  = 0;
        }

        return [implode(' AND ', $parts) ?: '1=1', $args];
    }

    /**
     * Returns visits grouped by hour-of-day (0-23) for the last 24 hours.
     *
     * The result is a 24-element array of [hour => visits] tuples, in
     * ascending hour order. Missing hours are backfilled with 0.
     *
     * Uses the configured Tehran timezone for the date cutoff.
     *
     * @return array<int, array{hour:int,visits:int,unique_visitors:int}>
     */
    public function peakHours(): array
    {
        $key = 'pulsestat:hours:24';
        return $this->cache->get($key, fn() => $this->computePeakHours(), 300);
    }

    private function computePeakHours(): array
    {
        // Default: 24-element array of zeros (used when the query fails
        // because the table doesn't exist yet).
        $empty = array_map(
            fn($h) => ['hour' => $h, 'visits' => 0, 'unique_visitors' => 0],
            range(0, 23)
        );

        return $this->safeQuery(function () use ($empty): array {
            $cutoff = Plugin::relativeDate('-1 day', 'Y-m-d');

            // The HOUR() function is MySQL-only. SQLite uses strftime(), and
            // PostgreSQL uses EXTRACT(). Detect the dialect once and reuse.
            $dialect  = \Utils\Schema::dialect($this->db);
            $hourExpr = match ($dialect) {
                'sqlite' => "CAST(strftime('%H', created_at) AS INTEGER)",
                'pgsql'  => "EXTRACT(HOUR FROM created_at)::int",
                default  => "HOUR(created_at)",
            };

            $query = $this->db
                ->select(
                    [$hourExpr             => 'hour'],
                    ['COUNT(*)'            => 'visits'],
                    ['COUNT(DISTINCT cid)' => 'unique_visitors'],
                )
                ->from($this->visitsTable)
                ->where('date_key >= ?', $cutoff)
                ->where('is_bot = ?', 0)
                ->group('hour')
                ->order('hour', Db::SORT_ASC);

            $rows = $this->db->fetchAll($query);
            $byHour = [];
            foreach ($rows as $r) {
                $byHour[(int)$r['hour']] = $r;
            }

            $out = [];
            for ($h = 0; $h < 24; $h++) {
                $out[] = [
                    'hour'            => $h,
                    'visits'          => (int)($byHour[$h]['visits'] ?? 0),
                    'unique_visitors' => (int)($byHour[$h]['unique_visitors'] ?? 0),
                ];
            }
            return $out;
        }, $empty);
    }

    /**
     * Returns the top-N busiest hours sorted by visits descending.
     */
    public function topHours(int $limit = 5): array
    {
        $hours = $this->peakHours();
        usort($hours, fn($a, $b) => $b['visits'] <=> $a['visits']);
        return array_slice($hours, 0, $limit);
    }

    /**
     * Deletes ALL visits older than `retentionDays`.
     *
     * The cutoff is computed in Tehran time so retention is enforced based
     * on the user's wall-clock, not the DB server's UTC.
     *
     * The DELETE is batched on MySQL/MariaDB (uses `DELETE ... LIMIT 5000`
     * to avoid long table locks on large tables). On SQLite/PostgreSQL, the
     * single-statement DELETE is used because those engines don't support
     * LIMIT on DELETE directly.
     */
    public function prune(int $retentionDays): int
    {
        if ($retentionDays < 1) {
            return 0;
        }
        return $this->safeQuery(function () use ($retentionDays): int {
            $cutoff = Plugin::relativeDate("-{$retentionDays} days", 'Y-m-d');
            $dialect = \Utils\Schema::dialect($this->db);
            $table   = $this->db->getPrefix() . Plugin::TABLE_PREFIX . 'visits';
            $tableQ  = \Utils\Schema::quote($table, $dialect);

            // Use the dialect-appropriate column quoting (backticks for MySQL,
            // double-quotes for SQLite/PostgreSQL).
            $colDateKey = $dialect === 'mysql' ? '`date_key`' : '"date_key"';
            $cutoffVal  = $this->db->getAdapter()->quoteValue($cutoff);

            // For SQLite & PostgreSQL, run a single DELETE (no LIMIT support).
            if ($dialect !== 'mysql') {
                $sql = sprintf(
                    'DELETE FROM %s WHERE %s < %s',
                    $tableQ,
                    $colDateKey,
                    $cutoffVal,
                );
                return (int) $this->db->query($sql, Db::WRITE, Db::DELETE);
            }

            // For MySQL/MariaDB, run batched DELETEs to avoid long locks.
            $total      = 0;
            $maxBatches = 50; // hard cap = 250k rows per prune cycle
            for ($i = 0; $i < $maxBatches; $i++) {
                $sql = sprintf(
                    'DELETE FROM %s WHERE %s < %s LIMIT 5000',
                    $tableQ,
                    $colDateKey,
                    $cutoffVal,
                );
                $affected = (int) $this->db->query($sql, Db::WRITE, Db::DELETE);
                $total += $affected;
                if ($affected < 5000) {
                    break; // no more rows to delete
                }
            }
            return $total;
        }, 0);
    }
}
