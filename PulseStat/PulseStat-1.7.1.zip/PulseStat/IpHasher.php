<?php
declare(strict_types=1);

namespace TypechoPlugin\PulseStat;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit('Access denied.');
}

/**
 * Hashes visitor IPs with a per-site salt. The raw IP is NEVER persisted.
 *
 *  - cid = SHA-256(salt + IP + UA-fingerprint)
 *  - The cid is used to count "unique visitors" within a time window.
 */
final class IpHasher
{
    /** HMAC-length output truncated (collision-resistant for our scale). */
    private const CID_LENGTH = 64;

    public function __construct(
        private string $salt,
    ) {
        if ($salt === '') {
            throw new \InvalidArgumentException('Salt must not be empty.');
        }
    }

    /**
     * Resolves the visitor IP from common headers (static; doesn't need salt).
     * We trust only headers most commonly set by trusted edge networks.
     */
    public static function resolveIp(): string
    {
        // Cloudflare.
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            return trim(explode(',', (string) $_SERVER['HTTP_CF_CONNECTING_IP'])[0]);
        }
        // Trusted reverse proxy exposing X-Real-IP.
        if (!empty($_SERVER['HTTP_X_REAL_IP'])) {
            return trim((string) $_SERVER['HTTP_X_REAL_IP']);
        }
        return trim($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
    }

    /**
     * Builds the stable cid (client identifier) for a visitor.
     */
    public function cid(string $ip, ?string $userAgent = null): string
    {
        $ua = trim((string) $userAgent);
        $raw = $this->salt . '|' . $ip . '|' . $ua;
        $hash = hash('sha256', $raw);
        return substr($hash, 0, self::CID_LENGTH);
    }
}
