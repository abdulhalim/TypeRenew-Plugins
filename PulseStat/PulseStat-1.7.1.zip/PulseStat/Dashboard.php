<?php
declare(strict_types=1);

namespace TypechoPlugin\PulseStat;

use Typecho\Common;
use Typecho\Plugin as Hook;
use Utils\Helper;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit('Access denied.');
}

class Dashboard
{
    /**
     * رندر اسکریپت ویجت‌های آمار
     */
    public static function render(): void
    {
        // فقط روی صفحه اصلی داشبورد ادمین کار می‌کنیم
        $script = (string) ($_SERVER['SCRIPT_NAME'] ?? '');
        if ($script === '' || basename($script) !== 'index.php') {
            return;
        }

        if (!defined('__TYPECHO_ADMIN__')) {
            return;
        }

        // بررسی فعال بودن پلاگین
        $cfg = Plugin::configMap();
        if (!$cfg['enabled']) {
            return;
        }

        $repo = new Repository();

        // اگر جداول وجود نداشت، کاری نمی‌کنیم
        if (!$repo->tablesExist()) {
            return;
        }

        // داده‌های مقایسه دوره‌ها
        $comparison = $repo->comparisonStats();

        // داده‌های ساعات پربازدید (۲۴ ساعت)
        $peakHours = $repo->peakHours();

        // تبدیل داده‌های مقایسه برای ارسال به JS
        $comparisonData = [];
        foreach (['today' => 'امروز در برابر دیروز', 'week' => 'این هفته در برابر هفته قبل', 'month' => 'این ماه در برابر ماه قبل'] as $key => $label) {
            $c = $comparison[$key] ?? [];
            $comparisonData[$key] = [
                'label' => $label,
                'current' => (int) ($c['current'] ?? 0),
                'previous' => (int) ($c['previous'] ?? 0),
                'changePct' => $c['change_pct'] ?? null,
                'uniqueCurrent' => (int) ($c['unique_current'] ?? 0),
                'uniquePrevious' => (int) ($c['unique_previous'] ?? 0),
                'uniqueChangePct' => $c['unique_change_pct'] ?? null,
            ];
        }

        // تبدیل داده‌های ساعات برای ارسال به JS
        $hoursLabels = [];
        $hoursValues = [];
        $hoursUnique = [];
        foreach ($peakHours as $h) {
            $hour = (int) ($h['hour'] ?? 0);
            // تبدیل ساعت به اعداد فارسی
            $hoursLabels[] = Plugin::faNum(sprintf('%02d', $hour));
            $hoursValues[] = (int) ($h['visits'] ?? 0);
            $hoursUnique[] = (int) ($h['unique_visitors'] ?? 0);
        }

        // پیدا کردن ساعت پربازدید
        $maxHour = 0;
        $maxVisits = 0;
        foreach ($hoursValues as $i => $v) {
            if ($v > $maxVisits) {
                $maxVisits = $v;
                $maxHour = $i;
            }
        }

        // محاسبه مجموع بازدیدهای ۲۴ ساعت
        $total24h = array_sum($hoursValues);
        $unique24h = array_sum($hoursUnique);

        $panelUrl = Helper::url('PulseStat/Panel.php', (string) Helper::options()->adminUrl);

        $payload = [
            'panelUrl' => $panelUrl,
            'i18n' => [
                'compareTitle' => 'مقایسه با دوره قبل',
                'hoursTitle' => 'ساعات پربازدید (۲۴ ساعت اخیر)',
                'current' => 'دوره فعلی',
                'previous' => 'دوره قبل',
                'unique' => 'یکتا',
                'noData' => 'بدون داده',
                'viewDetail' => 'مشاهده جزئیات',
                'peakHour' => 'ساعت پربازدید',
                'total24h' => 'مجموع ۲۴ ساعت',
                'visits' => 'بازدید',
            ],
            'comparison' => $comparisonData,
            'hours' => [
                'labels' => $hoursLabels,
                'values' => $hoursValues,
                'unique' => $hoursUnique,
                'peakHour' => $maxHour,
                'peakVisits' => $maxVisits,
                'total' => $total24h,
                'uniqueTotal' => $unique24h,
            ],
        ];

        $json = Common::jsonEncode(
            $payload,
            JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT,
            '{}'
        );

        $cssUrl = Plugin::assetUrl('assets/dashboard.css');
        $jsUrl = Plugin::assetUrl('assets/dashboard.js');
        ?>
<link rel="stylesheet" href="<?php echo htmlspecialchars($cssUrl, ENT_QUOTES, 'UTF-8'); ?>">
<script id="ps-dashboard-data" type="application/json"><?php echo $json; ?></script>
<script src="<?php echo htmlspecialchars($jsUrl, ENT_QUOTES, 'UTF-8'); ?>" defer></script>
        <?php
    }
}
