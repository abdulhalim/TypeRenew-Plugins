<?php
declare(strict_types=1);

namespace TypechoPlugin\PulseStat;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit('Access denied.');
}

/**
 * Thin wrapper around TypeRenew's cache API with TTL + lazy-compute support.
 *
 * Two calling styles:
 *  - get($key, $default)        : plain default value
 *  - get($key, $callable, $ttl): lazy compute on miss (recommended)
 */
final class Cache
{
    public const TTL_DEFAULT = 300;

    public function get(string $key, mixed $default = null, int $ttl = self::TTL_DEFAULT): mixed
    {
        $bag = $this->driver();
        if ($bag !== null) {
            $hit = false;
            $value = $bag->get($key, $hit);
            if ($hit) {
                return $value;
            }
        }
        if (is_callable($default)) {
            $value = $default();
            $this->set($key, $value, $ttl);
            return $value;
        }
        return $default;
    }

    public function set(string $key, mixed $value, int $ttl = self::TTL_DEFAULT): bool
    {
        $bag = $this->driver();
        if ($bag === null) {
            return false;
        }
        try {
            return $bag->set($key, $value, $ttl);
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function delete(string $key): bool
    {
        $bag = $this->driver();
        if ($bag === null) {
            return false;
        }
        try {
            return $bag->delete($key);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Returns the TypeRenew cache driver if available, or null when no
     * cache backend is configured. Callers gracefully fall back to no-cache.
     */
    private function driver(): ?\Typecho\Cache
    {
        try {
            return \Typecho\Cache::getInstance();
        } catch (\Throwable $e) {
            return null;
        }
    }
}
