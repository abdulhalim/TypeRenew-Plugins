<?php
declare(strict_types=1);

namespace TypechoPlugin\PulseStat;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit('Access denied.');
}

/**
 * Lightweight, dependency-free User-Agent parser.
 *
 * Returns the browser family and operating system family for a given
 * User-Agent string. The detection is intentionally coarse-grained
 * (just the family, not the version) to keep the statistics readable.
 *
 * Browser order matters: Chromium-based browsers (Edge, Opera, Brave,
 * Vivaldi, Samsung) all contain "Chrome/" in their UA, so the more
 * specific tokens must be checked first.
 *
 * Inspired by h5bp/user-agent-patterns (MIT).
 */
final class UserAgentParser
{
    /**
     * Parses a User-Agent string and returns the browser + OS families.
     *
     * @return array{browser:string, os:string}
     */
    public static function parse(?string $userAgent): array
    {
        $ua = trim((string) $userAgent);
        if ($ua === '') {
            return ['browser' => 'Unknown', 'os' => 'Unknown'];
        }

        return [
            'browser' => self::detectBrowser($ua),
            'os'      => self::detectOs($ua),
        ];
    }

    /**
     * Detects the browser family from a User-Agent string.
     *
     * Chromium-based browsers (Edge, Opera, Brave, Vivaldi, Samsung) all
     * contain "Chrome/" in their UA — we must check the more specific
     * tokens BEFORE the generic "Chrome/" pattern.
     */
    private static function detectBrowser(string $ua): string
    {
        // Microsoft Edge (Chromium) — "Edg/120.0.0.0"
        if (preg_match('#\bEdg(?:e|A|iOS)?/[\d.]+#i', $ua)) {
            return 'Edge';
        }
        // Opera — "OPR/106.0.0.0" (newer) or "Opera/99.0" (older)
        if (preg_match('#\b(?:OPR|Opera)/[\d.]+#i', $ua)) {
            return 'Opera';
        }
        // Samsung Internet Browser — "SamsungBrowser/21.0"
        if (preg_match('#\bSamsungBrowser/[\d.]+#i', $ua)) {
            return 'Samsung';
        }
        // Vivaldi — "Vivaldi/6.1"
        if (preg_match('#\bVivaldi/[\d.]+#i', $ua)) {
            return 'Vivaldi';
        }
        // Brave — looks like Chrome but has "Brave" in the UA on desktop.
        if (preg_match('#\bBrave\b#i', $ua) || preg_match('#\bbrave\b#i', $ua)) {
            return 'Brave';
        }
        // UC Browser (mobile)
        if (preg_match('#\bUCBrowser/[\d.]+#i', $ua)) {
            return 'UC Browser';
        }
        // Firefox — "Firefox/120.0" or "FxiOS/120.0"
        if (preg_match('#\b(?:Firefox|FxiOS)/[\d.]+#i', $ua)) {
            return 'Firefox';
        }
        // Chrome on iOS — "CriOS/120.0.0.0"
        if (preg_match('#\bCriOS/[\d.]+#i', $ua)) {
            return 'Chrome';
        }
        // Safari — must come AFTER Chrome/Edge/Opera checks.
        // Safari's UA contains "Safari/" but NOT "Chrome/" or "Chromium/".
        // iOS Safari uses "Version/X.Y Mobile/Safari" pattern.
        if (preg_match('#\bSafari/[\d.]+#i', $ua) && !preg_match('#\b(?:Chrome|Chromium)/#i', $ua)) {
            return 'Safari';
        }
        // Chrome (desktop + Android) — "Chrome/120.0.0.0"
        if (preg_match('#\b(?:Chrome|CrMo|CrI)/[\d.]+#i', $ua)) {
            return 'Chrome';
        }
        // Internet Explorer — "Trident/7.0" or "MSIE 10.0"
        if (preg_match('#\b(?:MSIE|Trident)/[\d.]+#i', $ua)) {
            return 'IE';
        }
        // Bot/crawler fallback — BotDetector catches most, but as a last
        // resort, common bot tokens also indicate a non-human browser.
        if (preg_match('#\b(?:bot|crawler|spider|slurp|scrape|crawl)\b#i', $ua)) {
            return 'Bot';
        }

        return 'Other';
    }

    /**
     * Detects the operating system family from a User-Agent string.
     */
    private static function detectOs(string $ua): string
    {
        // Windows — "Windows NT 10.0"
        if (preg_match('#\bWindows NT [\d.]+#i', $ua)) {
            return 'Windows';
        }
        // Windows Phone (legacy)
        if (preg_match('#\bWindows Phone#i', $ua)) {
            return 'Windows Phone';
        }
        // iOS — "iPhone", "iPad", "iPod"
        if (preg_match('#\b(?:iPhone|iPad|iPod)#i', $ua)) {
            return 'iOS';
        }
        // Android — "Android 13.0"
        if (preg_match('#\bAndroid(?: [\d.]+)?#i', $ua)) {
            return 'Android';
        }
        // macOS — "Mac OS X 10_15_7" or "Macintosh"
        if (preg_match('#\bMac OS X#i', $ua) || preg_match('#\bMacintosh#i', $ua)) {
            return 'macOS';
        }
        // Chrome OS — "CrOS"
        if (preg_match('#\bCrOS\b#i', $ua)) {
            return 'Chrome OS';
        }
        // Linux (must come after Android, because Android also has "Linux" in UA)
        if (preg_match('#\bLinux\b#i', $ua)) {
            return 'Linux';
        }
        // FreeBSD / OpenBSD / NetBSD
        if (preg_match('#\b(?:Free|Open|Net)BSD#i', $ua)) {
            return 'BSD';
        }

        return 'Other';
    }
}
