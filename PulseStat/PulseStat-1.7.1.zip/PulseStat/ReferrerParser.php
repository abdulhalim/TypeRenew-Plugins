<?php
declare(strict_types=1);

namespace TypechoPlugin\PulseStat;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit('Access denied.');
}

/**
 * Extracts the referer's host (domain) from a request.
 *
 *  - No Referer header => "Direct" (analytics convention).
 *  - Referer host == current site's host => "Direct" (internal navigation).
 *  - Otherwise => lowercased host without "www.".
 */
final class ReferrerParser
{
    public const DIRECT = 'Direct';

    public function parse(string $siteHost, ?string $rawReferer): string
    {
        $ref = trim((string) $rawReferer);
        if ($ref === '') {
            return self::DIRECT;
        }

        $host = $this->extractHost($ref);
        if ($host === '' || $host === '0.0.0.0') {
            return self::DIRECT;
        }
        if ($this->normalize($host) === $this->normalize($siteHost)) {
            return self::DIRECT;
        }
        return $this->normalize($host);
    }

    private function extractHost(string $url): string
    {
        $url = ltrim($url, '/');
        if (!preg_match('#^https?://#i', $url)) {
            $url = 'http://' . $url;
        }
        $host = (string) parse_url($url, PHP_URL_HOST);
        return strtolower($host);
    }

    private function normalize(string $host): string
    {
        $host = strtolower($host);
        if (str_starts_with($host, 'www.')) {
            $host = substr($host, 4);
        }
        return $host;
    }
}
