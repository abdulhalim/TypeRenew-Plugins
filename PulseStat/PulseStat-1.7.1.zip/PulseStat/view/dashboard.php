<?php
declare(strict_types=1);

/**
 * Dashboard view — single-page layout (no tabs).
 *
 * Layout:
 *  1. KPI tiles (today / week / month / all)
 *  2. Comparison widget: today vs yesterday, week vs last week, month vs last month
 *  3. 14-day visits chart
 *  4. Peak-hours bar chart
 *  5. Maintenance section
 *
 * Available variables (set in Panel.php via extract):
 * @var array $viewData     Totals + series + peak_hours + comparison
 * @var array $cfg          Plugin config map
 * @var string $csrfToken   Action token
 * @var string $lastPrune   Last prune date (YYYY-MM-DD) or ''
 * @var callable $icon      Lucide icon helper
 * @var bool $tablesExist   Whether stats tables exist
 */

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit('Access denied.');
}

use TypechoPlugin\PulseStat\Plugin;

$totals     = $viewData['totals'];
$series     = $viewData['series'];
$hours      = $viewData['peak_hours'];
$comparison = $viewData['comparison'];
$browsers   = $viewData['browsers'] ?? [];
$oses       = $viewData['oses'] ?? [];
$topPosts   = $viewData['top_posts'] ?? ['today' => [], 'week' => [], 'month' => []];

// Compute totals for percentage bars
$browserTotal = array_sum(array_map(fn($r) => $r['visits'], $browsers));
$osTotal      = array_sum(array_map(fn($r) => $r['visits'], $oses));

// Chart data: 14-day series
$chartLabels = array_map(fn($r) => $r['date_key'], $series);
$chartVisits = array_map(fn($r) => $r['visits'], $series);
$chartUnique = array_map(fn($r) => $r['unique_visitors'], $series);

// Peak-hours chart data: 24 bars
$hoursLabels = array_map(fn($r) => Plugin::faNum((string)$r['hour']) . ':' . Plugin::faNum('00'), $hours);
$hoursData   = array_map(fn($r) => $r['visits'], $hours);

// Notice shown when the stats tables don't exist.
$showMissingNotice = isset($tablesExist) && !$tablesExist;

// Helper to render a trend arrow + percentage with the right color.
$trendBadge = function (?float $pct) use ($icon): string {
    if ($pct === null) {
        return '<span class="sr-trend sr-trend--none">' . _t('بدون داده') . '</span>';
    }
    $cls   = $pct > 0 ? 'sr-trend--up' : ($pct < 0 ? 'sr-trend--down' : 'sr-trend--flat');
    $icn   = $pct > 0 ? 'arrow-up' : ($pct < 0 ? 'arrow-down' : 'activity');
    $sign  = $pct > 0 ? '+' : '';
    return '<span class="sr-trend ' . $cls . '">' . $icon($icn)
        . ' ' . $sign . Plugin::faNum(number_format($pct, 1)) . '%</span>';
};
?>

<?php if ($showMissingNotice): ?>
<section class="sr-notice" role="status">
    <?= $icon('alert') ?>
    <div class="sr-notice__body">
        <strong><?= _t('جداول آمار نصب نشده‌اند.') ?></strong>
        <p>
            <?= _t('برای فعال‌سازی، افزونه PulseStat را در صفحه افزونه‌ها غیرفعال و سپس فعال کنید تا جداول دوباره ساخته شوند.') ?>
        </p>
    </div>
</section>
<?php endif; ?>

<!-- KPI tiles -->
<section class="tr-panel-kpis">
    <?php foreach ([
        'today' => _t('امروز'),
        'week'  => _t('۷ روز اخیر'),
        'month' => _t('۳۰ روز اخیر'),
        'all'   => _t('کل'),
    ] as $key => $label):
        $t = $totals[$key]; ?>
        <div class="tr-panel-kpi">
            <span><?= htmlspecialchars($label) ?></span>
            <strong><?= Plugin::faNum(number_format((int)$t['total_visits'])) ?></strong>
            <span class="sr-kpi-sub">
                <?= _t('یکتا') ?>: <?= Plugin::faNum(number_format((int)$t['unique_visitors'])) ?>
                &middot;
                <?= _t('ربات') ?>: <?= Plugin::faNum(number_format((int)$t['bot_visits'])) ?>
            </span>
        </div>
    <?php endforeach; ?>
</section>

<!-- Comparison widget: today vs yesterday, etc. -->
<section class="tr-card">
    <div class="tr-card-h">
        <div class="tr-panel-section-head">
            <h3><?= $icon('trending-up') ?> <?= _t('مقایسه با دوره قبل') ?></h3>
        </div>
    </div>
    <div class="tr-card-b">
        <div class="sr-comparison">
            <?php foreach ([
                'today' => _t('امروز در برابر دیروز'),
                'week'  => _t('این هفته در برابر هفته قبل'),
                'month' => _t('این ماه در برابر ماه قبل'),
            ] as $key => $label):
                $c = $comparison[$key]; ?>
                <div class="sr-comparison-row">
                    <div class="sr-comparison-row__label"><?= $label ?></div>
                    <div class="sr-comparison-row__main">
                        <div class="sr-comparison-row__current">
                            <span class="sr-comparison-row__current-num">
                                <?= Plugin::faNum(number_format((int)$c['current'])) ?>
                            </span>
                            <span class="sr-comparison-row__sub">
                                <?= _t('یکتا') ?>:
                                <?= Plugin::faNum(number_format((int)$c['unique_current'])) ?>
                            </span>
                        </div>
                        <div class="sr-comparison-row__trend">
                            <?= $trendBadge($c['change_pct']) ?>
                        </div>
                    </div>
                    <div class="sr-comparison-row__previous">
                        <?= _t('دوره قبل') ?>:
                        <?= Plugin::faNum(number_format((int)$c['previous'])) ?>
                        <span class="sr-comparison-row__sep">·</span>
                        <?= _t('یکتا') ?>:
                        <?= Plugin::faNum(number_format((int)$c['unique_previous'])) ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- 14-day visits chart -->
<section class="tr-card">
    <div class="tr-card-h">
        <div class="tr-panel-section-head">
            <h3><?= $icon('activity') ?> <?= _t('بازدید ۱۴ روز اخیر') ?></h3>
        </div>
    </div>
    <div class="tr-card-b">
        <div class="sr-chart-wrap">
            <canvas id="sr-chart-visits" height="120"></canvas>
        </div>
        <script type="application/json" id="sr-chart-data">
        <?= json_encode([
            'labels' => $chartLabels,
            'datasets' => [
                [
                    'label' => _t('بازدید'),
                    'data'  => $chartVisits,
                    'borderColor' => 'rgb(var(--tr-accent-rgb))',
                    'backgroundColor' => 'rgba(37,99,235,0.08)',
                    'fill'  => true,
                    'tension' => 0.35,
                    'pointRadius' => 3,
                    'pointHoverRadius' => 5,
                ],
                [
                    'label' => _t('کاربر یکتا'),
                    'data'  => $chartUnique,
                    'borderColor' => '#10b981',
                    'backgroundColor' => 'rgba(16,185,129,0.08)',
                    'fill'  => true,
                    'tension' => 0.35,
                    'pointRadius' => 2,
                    'pointHoverRadius' => 4,
                ],
            ],
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) ?>
        </script>
    </div>
</section>

<!-- Peak hours chart -->
<section class="tr-card">
    <div class="tr-card-h">
        <div class="tr-panel-section-head">
            <h3><?= $icon('clock') ?> <?= _t('ساعات پربازدید (۲۴ ساعت اخیر)') ?></h3>
        </div>
    </div>
    <div class="tr-card-b">
        <div class="sr-chart-wrap sr-chart-wrap--short">
            <canvas id="sr-chart-hours" height="80"></canvas>
        </div>
        <script type="application/json" id="sr-chart-hours-data">
        <?= json_encode([
            'labels' => $hoursLabels,
            'datasets' => [[
                'label' => _t('بازدید'),
                'data'  => $hoursData,
                'backgroundColor' => 'rgba(37,99,235,0.55)',
                'borderColor' => 'rgb(var(--tr-accent-rgb))',
                'borderWidth' => 1,
                'borderRadius' => 4,
                'maxBarThickness' => 24,
            ]],
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) ?>
        </script>
    </div>
</section>

<!-- Top posts (3 windows) -->
<section class="sr-grid sr-grid--3">
    <?php foreach ([
        'today' => _t('امروز'),
        'week'  => _t('۷ روز اخیر'),
        'month' => _t('۳۰ روز اخیر'),
    ] as $key => $label): ?>
        <article class="tr-card">
            <div class="tr-card-h">
                <div class="tr-panel-section-head">
                    <h3><?= $icon('file-text') ?> <?= $label ?></h3>
                </div>
            </div>
            <div class="tr-card-b">
                <?php if (empty($topPosts[$key])): ?>
                    <p class="sr-empty"><?= _t('هنوز داده‌ای ثبت نشده است.') ?></p>
                <?php else: ?>
                    <table class="sr-table sr-table--compact">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th><?= _t('عنوان پست') ?></th>
                                <th class="sr-num"><?= _t('بازدید') ?></th>
                                <th class="sr-num"><?= _t('یکتا') ?></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($topPosts[$key] as $i => $post): ?>
                            <tr>
                                <td><?= Plugin::faNum((string)($i + 1)) ?></td>
                                <td>
                                    <a href="<?= htmlspecialchars($post['path'] ?: '#') ?>" target="_blank" rel="noopener">
                                        <?= htmlspecialchars($post['title']) ?>
                                    </a>
                                </td>
                                <td class="sr-num"><?= Plugin::faNum(number_format((int)$post['visits'])) ?></td>
                                <td class="sr-num"><?= Plugin::faNum(number_format((int)$post['unique_visitors'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </article>
    <?php endforeach; ?>
</section>

<!-- Browser & OS breakdown -->
<section class="sr-grid sr-grid--2">
    <article class="tr-card">
        <div class="tr-card-h">
            <div class="tr-panel-section-head">
                <h3><?= $icon('monitor') ?> <?= _t('مرورگرها') ?></h3>
                <span class="sr-pill-num"><?= Plugin::faNum(number_format($browserTotal)) ?> <?= _t('بازدید') ?></span>
            </div>
        </div>
        <div class="tr-card-b">
            <?php if ($browsers === [] || $browserTotal === 0): ?>
                <p class="sr-empty"><?= _t('هنوز داده‌ای ثبت نشده است.') ?></p>
            <?php else: ?>
                <ul class="sr-breakdown">
                    <?php foreach ($browsers as $b):
                        $pct = $browserTotal > 0 ? ($b['visits'] / $browserTotal * 100) : 0;
                        ?>
                        <li>
                            <div class="sr-breakdown__row">
                                <span class="sr-breakdown__label"><?= htmlspecialchars($b['browser'] ?: _t('نامشخص')) ?></span>
                                <span class="sr-breakdown__count">
                                    <?= Plugin::faNum(number_format((int)$b['visits'])) ?>
                                    <span class="sr-breakdown__pct">(<?= Plugin::faNum(number_format($pct, 1)) ?>%)</span>
                                </span>
                            </div>
                            <div class="sr-bar">
                                <div class="sr-bar__fill" style="width: <?= Plugin::faNum(number_format($pct, 1)) ?>%"></div>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
    </article>

    <article class="tr-card">
        <div class="tr-card-h">
            <div class="tr-panel-section-head">
                <h3><?= $icon('settings') ?> <?= _t('سیستم‌عامل‌ها') ?></h3>
                <span class="sr-pill-num"><?= Plugin::faNum(number_format($osTotal)) ?> <?= _t('بازدید') ?></span>
            </div>
        </div>
        <div class="tr-card-b">
            <?php if ($oses === [] || $osTotal === 0): ?>
                <p class="sr-empty"><?= _t('هنوز داده‌ای ثبت نشده است.') ?></p>
            <?php else: ?>
                <ul class="sr-breakdown">
                    <?php foreach ($oses as $o):
                        $pct = $osTotal > 0 ? ($o['visits'] / $osTotal * 100) : 0;
                        ?>
                        <li>
                            <div class="sr-breakdown__row">
                                <span class="sr-breakdown__label"><?= htmlspecialchars($o['os'] ?: _t('نامشخص')) ?></span>
                                <span class="sr-breakdown__count">
                                    <?= Plugin::faNum(number_format((int)$o['visits'])) ?>
                                    <span class="sr-breakdown__pct">(<?= Plugin::faNum(number_format($pct, 1)) ?>%)</span>
                                </span>
                            </div>
                            <div class="sr-bar">
                                <div class="sr-bar__fill" style="width: <?= Plugin::faNum(number_format($pct, 1)) ?>%"></div>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
    </article>
</section>

<!-- Maintenance -->
<section class="tr-card">
    <div class="tr-card-h">
        <div class="tr-panel-section-head">
            <h3><?= $icon('settings') ?> <?= _t('نگه‌داری و پاکسازی') ?></h3>
        </div>
    </div>
    <div class="tr-card-b">
        <p class="sr-hint">
            <?= _t('سیاست نگه‌داری:') ?>
            <strong><?= Plugin::faNum((string)$cfg['retention_days']) ?> <?= _t('روز') ?></strong>
            (~<?= Plugin::faNum((string)round((int)$cfg['retention_days'] / 30)) ?> <?= _t('ماه') ?>).
            <?= _t('پاکسازی خودکار روزی یک‌بار هنگام ورود مدیر اجرا می‌شود.') ?>
            <?= _t('آخرین پاکسازی:') ?>
            <strong><?= $lastPrune ? Plugin::faNum(Plugin::toJalali($lastPrune, 'Y/m/d')) : _t('هرگز') ?></strong>.
        </p>
        <div class="tr-panel-actions">
            <a class="tr-pill tr-pill-btn"
               href="?panel=PulseStat/Panel.php&action=prune&token=<?= htmlspecialchars($csrfToken) ?>"
               onclick="return confirm('<?= _t('پاکسازی اکنون انجام شود؟ ردیف‌های قدیمی حذف می‌شوند.') ?>')">
                <?= $icon('trash') ?> <?= _t('پاکسازی اکنون') ?>
            </a>
            <a class="tr-pill tr-pill-btn"
               href="?panel=PulseStat/Panel.php&action=clear_cache&token=<?= htmlspecialchars($csrfToken) ?>">
                <?= $icon('refresh') ?> <?= _t('پاکسازی کش') ?>
            </a>
            <a class="tr-pill tr-pill-btn sr-pill-danger"
               href="?panel=PulseStat/Panel.php&action=reset_all&token=<?= htmlspecialchars($csrfToken) ?>"
               onclick="return confirm('<?= _t('تمام ردیف‌های بازدید پاک خواهد شد. این عمل بازگشت‌ناپذیر است. ادامه؟') ?>')">
                <?= $icon('trash') ?> <?= _t('ریست همه داده‌ها') ?>
            </a>
            <a class="tr-pill tr-pill-btn sr-pill-danger"
               href="?panel=PulseStat/Panel.php&action=uninstall&token=<?= htmlspecialchars($csrfToken) ?>"
               onclick="return confirm('<?= _t('تمام جداول آمار حذف خواهند شد. ادامه؟') ?>')">
                <?= $icon('trash') ?> <?= _t('حذف کامل (Drop tables)') ?>
            </a>
        </div>
    </div>
</section>
