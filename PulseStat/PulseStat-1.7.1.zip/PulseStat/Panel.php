<?php
declare(strict_types=1);

/**
 * PulseStat admin panel entry point.
 *
 * Loaded by TypeRenew when an admin visits
 *   /admin/extending.php?panel=PulseStat/Panel.php
 *
 * TypeRenew exposes:
 *   $user      - \Widget\User       (the authenticated administrator)
 *   $request   - \Widget\Request    (current request)
 *   $options   - \Widget\Options    (site options)
 *   $response  - \Widget\Response
 */

use TypechoPlugin\PulseStat\Migration;
use TypechoPlugin\PulseStat\Plugin;
use TypechoPlugin\PulseStat\Repository;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit('Access denied.');
}

$user->pass('administrator');

// 1. Run auto-prune (once per day). The state file lives in the plugin folder.
$stateFile   = __DIR__ . '/.state.json';
$today       = Plugin::now('Y-m-d');
$state       = is_file($stateFile)
    ? (json_decode((string) @file_get_contents($stateFile), true) ?: [])
    : [];
$lastPrune   = (string)($state['last_prune_date'] ?? '');

if ($lastPrune !== $today) {
    try {
        $cfg  = Plugin::configMap();
        $repo = new Repository();
        $repo->prune($cfg['retention_days']);
        $repo->clearCache();
        $state['last_prune_date'] = $today;
        @file_put_contents(
            $stateFile,
            json_encode($state, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
            LOCK_EX,
        );
        $lastPrune = $today;
    } catch (\Throwable $e) {
        Plugin::log('autoPrune error: ' . $e->getMessage());
    }
}

// 2. Handle manual actions (prune / clear_cache / uninstall).
$action = trim((string) $request->get('action'));
if ($action !== '') {
    // Simple per-session token: TypeRenew's panel URL is admin-protected,
    // so this token mainly defends against accidental click-through.
    $expected = hash('sha256', (string) session_id() . '|PulseStat');
    $token    = (string) $request->get('token');
    if (hash_equals($expected, $token)) {
        $repo = new Repository();
        try {
            switch ($action) {
                case 'clear_cache':
                    $repo->clearCache();
                    // PRG: back to the panel.
                    $response->redirect(\Utils\Helper::url('PulseStat/Panel.php'));
                    return;
                case 'prune':
                    $cfg = Plugin::configMap();
                    $repo->prune($cfg['retention_days']);
                    $repo->clearCache();
                    $state['last_prune_date'] = $today;
                    @file_put_contents(
                        $stateFile,
                        json_encode($state, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
                        LOCK_EX,
                    );
                    $lastPrune = $today;
                    // PRG: back to the panel.
                    $response->redirect(\Utils\Helper::url('PulseStat/Panel.php'));
                    return;
                case 'reset_all':
                    // Wipe all visits (useful when testing). Does not drop
                    // the table itself, only its rows.
                    $repo->resetAllVisits();
                    $repo->clearCache();
                    $response->redirect(\Utils\Helper::url('PulseStat/Panel.php'));
                    return;
                case 'uninstall':
                    Migration::drop(Plugin::db());
                    // After dropping the tables, the panel can no longer
                    // safely load (queries would crash). Redirect to the
                    // plugins list page (`plugins.php`) which is the standard
                    // admin URL for the plugin management screen.
                    try {
                        \Widget\Notice::alloc()->set(
                            _t('جداول آمار PulseStat حذف شدند. برای فعال‌سازی مجدد، افزونه را غیرفعال و سپس فعال کنید.'),
                            'notice'
                        );
                    } catch (\Throwable $e) {
                        // ignore - notice is best-effort.
                    }
                    // `plugins.php` is the actual file under /admin/ (not
                    // `manage-plugins.php` which doesn't exist).
                    $response->redirect(
                        \Typecho\Common::url('plugins.php', $options->adminUrl)
                    );
                    return;
            }
        } catch (\Throwable $e) {
            Plugin::log('action error (' . $action . '): ' . $e->getMessage());
        }
    }
}

// 4a. Check whether the tables exist. If the user has clicked "Drop
//     tables" the queries below would otherwise crash. We show a notice
//     instead of attempting to query the missing tables.
$repo = new Repository();
$tablesExist = $repo->tablesExist();

// 4. Build view data for the dashboard. When tables are missing we still
//    proceed (the Repository methods are try-catch wrapped and return zero
//    values on failure), but we display a notice in the dashboard view.
$cfg = Plugin::configMap();
if ($tablesExist) {
    $totals = [
        'today' => $repo->totals('today'),
        'week'  => $repo->totals('week'),
        'month' => $repo->totals('month'),
        'all'   => $repo->totals('all'),
    ];
    $series     = $repo->dailySeries(14);
    $hours      = $repo->peakHours();
    $comparison = $repo->comparisonStats();
    $browsers   = $repo->browserStats(8);
    $oses       = $repo->osStats(6);
    $topPosts   = [
        'today' => $repo->topPosts('today'),
        'week'  => $repo->topPosts('week'),
        'month' => $repo->topPosts('month'),
    ];
    $viewData = [
        'totals'     => $totals,
        'series'     => $series,
        'peak_hours' => $hours,
        'comparison' => $comparison,
        'browsers'   => $browsers,
        'oses'       => $oses,
        'top_posts'  => $topPosts,
    ];
} else {
    // Empty placeholders so the view still renders without crashing.
    $emptyTotals = [
        'today' => ['window' => 'today', 'total_visits' => 0, 'unique_visitors' => 0, 'bot_visits' => 0],
        'week'  => ['window' => 'week',  'total_visits' => 0, 'unique_visitors' => 0, 'bot_visits' => 0],
        'month' => ['window' => 'month', 'total_visits' => 0, 'unique_visitors' => 0, 'bot_visits' => 0],
        'all'   => ['window' => 'all',   'total_visits' => 0, 'unique_visitors' => 0, 'bot_visits' => 0],
    ];
    $emptySeries = array_map(
        fn($i) => [
            'date_key'        => Plugin::relativeDate("-{$i} days", 'Y-m-d'),
            'visits'          => 0,
            'unique_visitors' => 0,
        ],
        range(14, 0)
    );
    $emptyHours = array_map(
        fn($h) => ['hour' => $h, 'visits' => 0, 'unique_visitors' => 0],
        range(0, 23)
    );
    $emptyComparison = [
        'today' => ['current' => 0, 'previous' => 0, 'change_pct' => 0, 'unique_current' => 0, 'unique_previous' => 0, 'unique_change_pct' => 0],
        'week'  => ['current' => 0, 'previous' => 0, 'change_pct' => 0, 'unique_current' => 0, 'unique_previous' => 0, 'unique_change_pct' => 0],
        'month' => ['current' => 0, 'previous' => 0, 'change_pct' => 0, 'unique_current' => 0, 'unique_previous' => 0, 'unique_change_pct' => 0],
    ];
    $viewData = [
        'totals'     => $emptyTotals,
        'series'     => $emptySeries,
        'peak_hours' => $emptyHours,
        'comparison' => $emptyComparison,
        'browsers'   => [],
        'oses'       => [],
        'top_posts'  => ['today' => [], 'week' => [], 'month' => []],
    ];
}

// CSRF token for action links.
$csrfToken = hash('sha256', (string) session_id() . '|PulseStat');

// (no tabs anymore — the dashboard is now a single page)
?>
<link rel="stylesheet" href="<?= Plugin::assetUrl('assets/admin.css?v=' . Plugin::VERSION); ?>">

<?php
// Build the URL to the admin theme's Lucide SVG sprite once and reuse it.
// All icons rendered via <use href="...icons.svg#i-name"> in the panel.
$iconsUrl = (string) $options->adminStaticUrl('img', 'icons.svg', true);

// Helper to inline a Lucide icon from the admin sprite.
$icon = function (string $name) use ($iconsUrl): string {
    return '<svg class="tr-ico" aria-hidden="true">'
        . '<use href="' . htmlspecialchars($iconsUrl, ENT_QUOTES, 'UTF-8')
        . '#i-' . htmlspecialchars($name) . '"></use></svg>';
};

// Expose data + helpers to the dashboard view.
extract([
    'viewData'    => $viewData,
    'cfg'          => $cfg,
    'csrfToken'    => $csrfToken,
    'lastPrune'    => $lastPrune,
    'icon'         => $icon,
    'iconsUrl'    => $iconsUrl,
    'tablesExist' => $tablesExist,
], EXTR_SKIP);
?>

<div class="tr-panel pulsestat-panel" dir="rtl">
    <section class="tr-card">
        <div class="tr-card-b">
            <div class="tr-panel-head">
                <div class="tr-panel-heading">
                    <h2 class="tr-panel-title">
                        <?= $icon('activity') ?> <?= _t('آمار بازدید') ?>
                        <span class="sr-version-badge" title="PulseStat version">
                            PulseStat v<?= htmlspecialchars(Plugin::VERSION) ?>
                        </span>
                    </h2>
                </div>
                <div class="tr-panel-pills">
                    <span class="tr-pill <?= $cfg['enabled'] ? 'tr-pill-accent' : '' ?>">
                        <?= $cfg['enabled'] ? _t('فعال') : _t('غیرفعال') ?>
                    </span>
                    <span class="tr-pill">
                        <?= $icon('clock') ?>
                        <?= _t('نگه‌داری') ?>:
                        <?= Plugin::faNum((string)$cfg['retention_days']) ?> <?= _t('روز') ?>
                    </span>
                </div>
            </div>
        </div>
    </section>

    <div id="pulsestat-panel-dashboard"
         class="tr-panel-pane is-active"
         role="tabpanel"
         tabindex="0"
         data-tab="dashboard">
        <?php require __DIR__ . '/view/dashboard.php'; ?>
    </div>
</div>

<script src="<?= Plugin::assetUrl('assets/chart.min.js'); ?>"></script>
<script src="<?= Plugin::assetUrl('assets/admin.js?v=' . Plugin::VERSION); ?>"></script>
