<?php
declare(strict_types=1);

namespace TypechoPlugin\PulseStat;

use Typecho\Db;
use Utils\Helper;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit('Access denied.');
}

/**
 * Tracker: orchestrates the per-request visit recording.
 *
 * Design goals
 * ------------
 *  - Very hot path (runs on every front-end request).
 *  - One DB write per request, no SELECT-before-INSERT pattern.
 *  - Uses TypeRenew's Query Builder (Db::insert()->rows()) so the prefix
 *    is auto-applied and the query is parameterised.
 *  - All failures are swallowed: visitors must never see a stats error.
 *
 * Behavioural policy
 *  - Tracking is skipped for:
 *      * admin panel requests
 *      * POST / PUT / DELETE / PATCH methods
 *      * AJAX requests (X-Requested-With)
 *      * paths listed in `excluded_paths`
 *      * logged-in administrators when `track_admin` is off
 *  - Bots are recorded with is_bot=1 so they can be filtered on read.
 *  - The cid is computed once per request and reused.
 */
final class Tracker
{
    /** Methods that are never tracked. */
    private const NON_TRACK_METHODS = ['POST', 'PUT', 'DELETE', 'PATCH'];

    /**
     * Hook target: `Hook::factory('Widget\Archive')->beforeRender`.
     *
     * v1.7.1: We record visits to ALL pages (home, category, blog, search,
     * archive, single post, standalone page, etc.). The page type is
     * detected by `resolveContentMeta()` which uses BOTH the URL path
     * (most reliable) and the archive's `is()` method.
     *
     * The "Top Posts" widget in the dashboard filters by `content_id > 0`,
     * so it only shows actual post visits — list-page visits are recorded
     * but excluded from the Top Posts ranking.
     *
     * Any error is logged but never surfaced to the visitor.
     */
    public static function onArchiveRender(object $archive): void
    {
        try {
            $cfg = Plugin::configMap();
            if (!$cfg['enabled']) {
                return;
            }
            if (self::shouldSkipRequest($cfg)) {
                return;
            }

            // Resolve content metadata: type (home/category/tag/post/page/...),
            // content_id (only > 0 for real single post/page views), title, path.
            $meta = self::resolveContentMeta($archive);
            $path = $meta['path'];
            if ($path !== '' && self::isPathExcluded($path, $cfg['excluded_paths'])) {
                return;
            }

            $ua   = $_SERVER['HTTP_USER_AGENT'] ?? null;
            $ip   = self::resolveIp();
            $cid  = (new IpHasher($cfg['ip_salt']))->cid($ip, $ua);
            $bot  = (new BotDetector())->detect($ua);
            $ref  = (new ReferrerParser())->parse(
                self::siteHost(),
                $_SERVER['HTTP_REFERER'] ?? null,
            );
            $uaInfo = UserAgentParser::parse($ua);

            self::insertVisit([
                'cid'             => $cid,
                'content_id'      => $meta['content_id'],
                'content_type'    => $meta['content_type'],
                'title'           => $meta['title'],
                'path'            => mb_substr($path, 0, 512),
                'referrer_domain' => mb_substr($ref, 0, 255),
                'is_bot'          => $bot === null ? 0 : 1,
                'bot_name'         => $bot,
                'browser'         => $uaInfo['browser'],
                'os'               => $uaInfo['os'],
                // Use Tehran wall-clock time for both created_at (DATETIME)
                // and date_key (DATE) so all stats are reported in the user's
                // timezone regardless of the DB server's timezone setting.
                'created_at'      => Plugin::now('Y-m-d H:i:s'),
                'date_key'        => Plugin::now('Y-m-d'),
            ]);
        } catch (\Throwable $e) {
            Plugin::log('Tracker error: ' . $e->getMessage());
        }
    }

    /* -----------------------------------------------------------------
     *  Internal helpers
     * ----------------------------------------------------------------- */

    private static function shouldSkipRequest(array $cfg): bool
    {
        $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        if (in_array($method, self::NON_TRACK_METHODS, true)) {
            return true;
        }
        $xrw = strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '');
        if ($xrw === 'xmlhttprequest') {
            return true;
        }
        $script = $_SERVER['SCRIPT_NAME'] ?? '';
        if (str_contains($script, '/admin/')
            || str_ends_with($script, 'admin/index.php')
            || str_ends_with($script, 'install.php')) {
            return true;
        }
        if (!$cfg['track_admin']) {
            if (self::isAdminSession()) {
                return true;
            }
        }
        return false;
    }

    private static function isAdminSession(): bool
    {
        try {
            $user = \Widget\User::alloc();
            if ($user->hasLogin()) {
                $group = (string) $user->group;
                if (in_array($group, ['administrator', 'editor', 'contributor'], true)) {
                    return true;
                }
            }
        } catch (\Throwable $e) {
            // ignore - safest to treat as non-admin.
        }
        return false;
    }

    // (resolveContentMeta restored in v1.7.1 — see method below)

    private static function currentPath(): string
    {
        $uri  = $_SERVER['REQUEST_URI'] ?? '/';
        $path = parse_url($uri, PHP_URL_PATH) ?? '/';
        return '/' . ltrim($path, '/');
    }

    /**
     * Reads content metadata from the archive widget passed to the hook.
     *
     * Strategy (layered, most-reliable first):
     *
     *  1) URL PATH (primary signal): if the path is the home page ('/'
     *     or empty), record as 'home' regardless of what the archive flags
     *     say. This is the only way to robustly handle themes that use
     *     Terminal exceptions or override archiveType in their themeInit
     *     (e.g., the "renewal" theme bundled with TypeRenew 1.6).
     *
     *  2) archive->is() (secondary signal): for non-home URLs, use the
     *     TypeRenew archive's `is()` method (which reads internal flags
     *     archiveType and archiveSingle) to distinguish list pages
     *     (category, tag, search, archive) from single posts/pages.
     *
     *  3) FALLBACK: if neither path nor is() can classify the request,
     *     record cid=0 with content_type='other'.
     *
     * CRITICAL: we must NEVER use $archive->cid or $archive->title when
     * the request is a list page (home, blog, category, tag, search,
     * archive). On list pages, the Archive widget's "current" row
     * pointer is the FIRST post in the result set — using its cid+title
     * would attribute every list-page visit to one specific post, which
     * is exactly the bug reported on the renewal theme.
     */
    private static function resolveContentMeta(object $archive): array
    {
        $path = self::currentPath();
        $defaults = [
            'content_id'   => 0,
            'content_type' => 'other',
            'title'        => '',
            'path'         => $path,
        ];

        try {
            // -------- 1) URL-PATH based detection (most reliable) --------

            // Home page: path is exactly '/' or empty (or /index.php on
            // some configurations). Don't trust archive flags here because
            // themes like "renewal" might override them via themeInit or
            // Terminal exceptions.
            $normalizedPath = rtrim($path, '/');
            if ($normalizedPath === '' || $normalizedPath === '/index.php') {
                return [
                    'content_id'   => 0,
                    'content_type' => 'home',
                    'title'        => 'صفحه اصلی',
                    'path'         => $path,
                ];
            }

            // -------- 2) Archive flag based detection (specific) --------

            $hasIs = method_exists($archive, 'is');

            // HOME PAGE (via is()): a static front page returns true for
            // is('index') even though archiveType='page'. This catches that.
            if ($hasIs && $archive->is('index')) {
                return [
                    'content_id'   => 0,
                    'content_type' => 'home',
                    'title'        => 'صفحه اصلی',
                    'path'         => $path,
                ];
            }

            // SPECIFIC LIST TYPES — check before 'archive' catch-all
            // so the title reflects the specific kind.
            if ($hasIs && $archive->is('category')) {
                $title = trim((string)($archive->title ?? ''));
                return [
                    'content_id'   => 0,
                    'content_type' => 'category',
                    'title'        => mb_substr($title !== '' ? 'دسته: ' . $title : 'دسته‌بندی', 0, 255),
                    'path'         => $path,
                ];
            }
            if ($hasIs && $archive->is('tag')) {
                $title = trim((string)($archive->title ?? ''));
                return [
                    'content_id'   => 0,
                    'content_type' => 'tag',
                    'title'        => mb_substr($title !== '' ? 'برچسب: ' . $title : 'برچسب', 0, 255),
                    'path'         => $path,
                ];
            }
            if ($hasIs && $archive->is('search')) {
                $kw = trim((string)(
                    $archive->keywords ?? $archive->request?->get('keywords', '') ?? ''
                ));
                return [
                    'content_id'   => 0,
                    'content_type' => 'search',
                    'title'        => mb_substr('جستجو' . ($kw !== '' ? ': ' . $kw : ''), 0, 255),
                    'path'         => $path,
                ];
            }
            if ($hasIs && $archive->is('feed')) {
                return [
                    'content_id'   => 0,
                    'content_type' => 'feed',
                    'title'        => 'فید',
                    'path'         => $path,
                ];
            }

            // GENERIC ARCHIVE — catches the "posts page" (/blog/) where
            // archiveType='front' AND date archives. archiveSingle is false
            // on these pages so we MUST NOT use $archive->cid.
            if ($hasIs && $archive->is('archive')) {
                $title = trim((string)($archive->title ?? ''));
                return [
                    'content_id'   => 0,
                    'content_type' => 'archive',
                    'title'        => mb_substr($title !== '' ? 'آرشیو: ' . $title : 'آرشیو', 0, 255),
                    'path'         => $path,
                ];
            }

            // SINGLE POST / PAGE — only here do we safely use cid+title.
            // The static-front-page case has already been caught by is('index') above.
            if ($hasIs && $archive->is('single')) {
                $title  = trim((string)($archive->title ?? ''));
                $dbType = strtolower((string)($archive->type ?? 'post'));
                $type   = ($dbType === 'page') ? 'page' : 'post';
                return [
                    'content_id'   => (int)($archive->cid ?? 0),
                    'content_type' => $type,
                    'title'        => mb_substr($title !== '' ? $title : '(بدون عنوان)', 0, 255),
                    'path'         => $path,
                ];
            }

            // -------- 3) FALLBACK --------
            // We couldn't classify the page. To be safe, do NOT use
            // $archive->cid (it might be the wrong content for a list page).
            return $defaults;
        } catch (\Throwable $e) {
            return $defaults;
        }
    }

    private static function isPathExcluded(string $path, string $excluded): bool
    {
        $list = array_filter(array_map('trim', explode(',', $excluded)));
        foreach ($list as $ex) {
            $ex = '/' . ltrim($ex, '/');
            if ($ex !== '/' && str_starts_with($path, $ex)) {
                return true;
            }
        }
        return false;
    }

    private static function siteHost(): string
    {
        $h = $_SERVER['HTTP_HOST'] ?? '';
        if ($h === '') {
            $h = $_SERVER['SERVER_NAME'] ?? '';
        }
        return strtolower(trim($h));
    }

    private static function resolveIp(): string
    {
        return IpHasher::resolveIp();
    }

    /**
     * Performs a single INSERT into the visits table using TypeRenew's Query
     * Builder. The `table.` prefix is auto-replaced with the configured DB
     * prefix. Any error is logged but swallowed.
     */
    private static function insertVisit(array $row): void
    {
        try {
            $db = Plugin::db();
            $db->query(
                $db->insert('table.' . Plugin::TABLE_PREFIX . 'visits')->rows([
                    'cid'             => $row['cid'],
                    'content_id'      => $row['content_id'],
                    'content_type'    => $row['content_type'],
                    'title'           => $row['title'],
                    'path'            => $row['path'],
                    'referrer_domain' => $row['referrer_domain'],
                    'is_bot'          => $row['is_bot'],
                    'bot_name'        => $row['bot_name'],
                    'browser'         => $row['browser'] ?? '',
                    'os'              => $row['os'] ?? '',
                    'created_at'      => $row['created_at'],
                    'date_key'        => $row['date_key'],
                ]),
                Db::WRITE,
                Db::INSERT,
            );
        } catch (\Throwable $e) {
            Plugin::log('insertVisit error: ' . $e->getMessage());
        }
    }
}
