<?php
declare(strict_types=1);

namespace TypechoPlugin\PulseStat;

use Typecho\Db;
use Utils\Schema as CoreSchema;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit('Access denied.');
}

/**
 * Manages schema creation for PulseStat.
 *
 * Two tables:
 *  - {prefix}pulsestat_visits  : raw visit log, one row per request
 *  - {prefix}pulsestat_summary  : pre-aggregated daily totals (kept small)
 *
 * Designed to be portable across MySQL/MariaDB, PostgreSQL and SQLite
 * (mirroring the convention used by RenewShield's Schema class).
 *
 * @package PulseStat
 */
final class Migration
{
    /** Create tables if they do not exist. Idempotent. */
    public static function ensure(Db $db): void
    {
        $dialect = CoreSchema::dialect($db);
        $prefix  = $db->getPrefix();

        $visitsTable  = $prefix . Plugin::TABLE_PREFIX . 'visits';
        $summaryTable = $prefix . Plugin::TABLE_PREFIX . 'summary';

        $db->query(self::visitsSql($dialect, CoreSchema::quote($visitsTable, $dialect)), Db::WRITE);
        $db->query(self::summarySql($dialect, CoreSchema::quote($summaryTable, $dialect)), Db::WRITE);

        // For installs that pre-date v1.5.0, the visits table was created
        // without `browser` and `os` columns. ALTER TABLE to add them.
        self::ensureColumn($db, $visitsTable, 'browser', 'VARCHAR(50) NOT NULL DEFAULT \'\'');
        self::ensureColumn($db, $visitsTable, 'os',      'VARCHAR(50) NOT NULL DEFAULT \'\'');
    }

    /**
     * Adds a column to a table if it doesn't already exist.
     *
     * Wraps the ALTER TABLE in try/catch because all three supported
     * dialects (MySQL, SQLite, PostgreSQL) raise a SQL error when the
     * column is already present. We silently swallow that error.
     *
     * SQLite caveat: ALTER TABLE ADD COLUMN doesn't accept NOT NULL
     * without a default — that's why we include `DEFAULT ''` in the
     * column definition passed in by the caller.
     */
    private static function ensureColumn(Db $db, string $table, string $column, string $definition): void
    {
        $dialect = CoreSchema::dialect($db);
        $tableQ  = CoreSchema::quote($table, $dialect);
        $columnQ = $dialect === 'mysql'
            ? '`' . $column . '`'
            : '"' . $column . '"';

        $sql = sprintf('ALTER TABLE %s ADD COLUMN %s %s', $tableQ, $columnQ, $definition);

        try {
            $db->query($sql, Db::WRITE);
        } catch (\Throwable $e) {
            // Column already exists — this is the expected path for
            // installs that already ran this migration. Silently ignore.
        }
    }

    /** Drop tables. Called only from the explicit "Uninstall" button. */
    public static function drop(Db $db): void
    {
        $dialect = CoreSchema::dialect($db);
        $prefix  = $db->getPrefix();
        $visits  = CoreSchema::quote($prefix . Plugin::TABLE_PREFIX . 'visits', $dialect);
        $summary = CoreSchema::quote($prefix . Plugin::TABLE_PREFIX . 'summary', $dialect);

        $db->query("DROP TABLE IF EXISTS {$visits}",  Db::WRITE);
        $db->query("DROP TABLE IF EXISTS {$summary}", Db::WRITE);
    }

    /**
     * Returns true if the visits table exists.
     * Used to decide whether to attempt queries (and to show a notice
     * in the admin panel when the user has uninstalled the tables).
     *
     * Portable across MySQL, SQLite and PostgreSQL.
     */
    public static function exists(Db $db): bool
    {
        $dialect = CoreSchema::dialect($db);
        $prefix  = $db->getPrefix();
        $table   = $prefix . Plugin::TABLE_PREFIX . 'visits';

        try {
            // A trivial SELECT that touches the table. Wrapped in try/catch
            // because SQLite/PDO throws on a missing table.
            $db->fetchRow("SELECT 1 FROM " . CoreSchema::quote($table, $dialect) . " LIMIT 1");
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Returns the CREATE TABLE statement for the visits table.
     *
     * Notes:
     *  - cid      : SHA-256 hash of salted IP + UA fingerprint, fixed 64 chars.
     *  - date_key : DATE column for fast range scans with a covering index.
     *  - title    : cached at insertion time; never updated later.
     *  - is_bot / bot_name : bot-flag + name detected by BotDetector.
     */
    private static function visitsSql(string $dialect, string $name): string
    {
        return match ($dialect) {
            'sqlite' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" INTEGER PRIMARY KEY AUTOINCREMENT,'
                . '"cid" TEXT NOT NULL DEFAULT \'\','
                . '"content_id" INTEGER NOT NULL DEFAULT 0,'
                . '"content_type" TEXT NOT NULL DEFAULT \'other\','
                . '"title" TEXT NOT NULL DEFAULT \'\','
                . '"path" TEXT NOT NULL DEFAULT \'\','
                . '"referrer_domain" TEXT NOT NULL DEFAULT \'Direct\','
                . '"is_bot" INTEGER NOT NULL DEFAULT 0,'
                . '"bot_name" TEXT,'
                . '"browser" TEXT NOT NULL DEFAULT \'\','
                . '"os" TEXT NOT NULL DEFAULT \'\','
                . '"created_at" TEXT NOT NULL,'
                . '"date_key" TEXT NOT NULL'
                . ');'
                . 'CREATE INDEX IF NOT EXISTS idx_sr_v_date ON ' . $name . '("date_key");'
                . 'CREATE INDEX IF NOT EXISTS idx_sr_v_content ON ' . $name . '("content_id","date_key");'
                . 'CREATE INDEX IF NOT EXISTS idx_sr_v_cid ON ' . $name . '("cid","date_key");'
                . 'CREATE INDEX IF NOT EXISTS idx_sr_v_bot ON ' . $name . '("is_bot","date_key");'
                . 'CREATE INDEX IF NOT EXISTS idx_sr_v_ref ON ' . $name . '("referrer_domain","date_key");'
                . 'CREATE INDEX IF NOT EXISTS idx_sr_v_browser ON ' . $name . '("browser");'
                . 'CREATE INDEX IF NOT EXISTS idx_sr_v_os ON ' . $name . '("os");',
            'pgsql' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" BIGSERIAL PRIMARY KEY,'
                . '"cid" VARCHAR(64) NOT NULL DEFAULT \'\','
                . '"content_id" INTEGER NOT NULL DEFAULT 0,'
                . '"content_type" VARCHAR(20) NOT NULL DEFAULT \'other\','
                . '"title" VARCHAR(255) NOT NULL DEFAULT \'\','
                . '"path" VARCHAR(512) NOT NULL DEFAULT \'\','
                . '"referrer_domain" VARCHAR(255) NOT NULL DEFAULT \'Direct\','
                . '"is_bot" SMALLINT NOT NULL DEFAULT 0,'
                . '"bot_name" VARCHAR(50),'
                . '"browser" VARCHAR(50) NOT NULL DEFAULT \'\','
                . '"os" VARCHAR(50) NOT NULL DEFAULT \'\','
                . '"created_at" TIMESTAMP NOT NULL,'
                . '"date_key" DATE NOT NULL'
                . ');'
                . 'CREATE INDEX IF NOT EXISTS idx_sr_v_date ON ' . $name . '("date_key");'
                . 'CREATE INDEX IF NOT EXISTS idx_sr_v_content ON ' . $name . '("content_id","date_key");'
                . 'CREATE INDEX IF NOT EXISTS idx_sr_v_cid ON ' . $name . '("cid","date_key");'
                . 'CREATE INDEX IF NOT EXISTS idx_sr_v_bot ON ' . $name . '("is_bot","date_key");'
                . 'CREATE INDEX IF NOT EXISTS idx_sr_v_ref ON ' . $name . '("referrer_domain","date_key");'
                . 'CREATE INDEX IF NOT EXISTS idx_sr_v_browser ON ' . $name . '("browser");'
                . 'CREATE INDEX IF NOT EXISTS idx_sr_v_os ON ' . $name . '("os");',
            default => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '`id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,'
                . '`cid` CHAR(64) NOT NULL DEFAULT \'\','
                . '`content_id` INT UNSIGNED NOT NULL DEFAULT 0,'
                . '`content_type` VARCHAR(20) NOT NULL DEFAULT \'other\','
                . '`title` VARCHAR(255) NOT NULL DEFAULT \'\','
                . '`path` VARCHAR(512) NOT NULL DEFAULT \'\','
                . '`referrer_domain` VARCHAR(255) NOT NULL DEFAULT \'Direct\','
                . '`is_bot` TINYINT(1) NOT NULL DEFAULT 0,'
                . '`bot_name` VARCHAR(50) NULL DEFAULT NULL,'
                . '`browser` VARCHAR(50) NOT NULL DEFAULT \'\','
                . '`os` VARCHAR(50) NOT NULL DEFAULT \'\','
                . '`created_at` DATETIME NOT NULL,'
                . '`date_key` DATE NOT NULL,'
                . 'PRIMARY KEY (`id`),'
                . 'KEY `idx_sr_v_date` (`date_key`),'
                . 'KEY `idx_sr_v_content` (`content_id`, `date_key`),'
                . 'KEY `idx_sr_v_cid` (`cid`, `date_key`),'
                . 'KEY `idx_sr_v_bot` (`is_bot`, `date_key`),'
                . 'KEY `idx_sr_v_ref` (`referrer_domain`, `date_key`),'
                . 'KEY `idx_sr_v_browser` (`browser`),'
                . 'KEY `idx_sr_v_os` (`os`)'
                . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;',
        };
    }

    /** Returns the CREATE TABLE statement for the daily summary table. */
    private static function summarySql(string $dialect, string $name): string
    {
        return match ($dialect) {
            'sqlite' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"date_key" TEXT NOT NULL,'
                . '"total_visits" INTEGER NOT NULL DEFAULT 0,'
                . '"unique_visitors" INTEGER NOT NULL DEFAULT 0,'
                . '"bot_visits" INTEGER NOT NULL DEFAULT 0,'
                . '"updated_at" TEXT NOT NULL,'
                . 'PRIMARY KEY ("date_key")'
                . ');',
            'pgsql' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"date_key" DATE PRIMARY KEY,'
                . '"total_visits" INTEGER NOT NULL DEFAULT 0,'
                . '"unique_visitors" INTEGER NOT NULL DEFAULT 0,'
                . '"bot_visits" INTEGER NOT NULL DEFAULT 0,'
                . '"updated_at" TIMESTAMP NOT NULL'
                . ');',
            default => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '`date_key` DATE NOT NULL,'
                . '`total_visits` INT UNSIGNED NOT NULL DEFAULT 0,'
                . '`unique_visitors` INT UNSIGNED NOT NULL DEFAULT 0,'
                . '`bot_visits` INT UNSIGNED NOT NULL DEFAULT 0,'
                . '`updated_at` DATETIME NOT NULL,'
                . 'PRIMARY KEY (`date_key`)'
                . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;',
        };
    }
}
