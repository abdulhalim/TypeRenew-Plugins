(function (factory) {
    if (typeof define === 'function' && define.amd) {
        define(['jquery'], factory);
    } else {
        factory(jQuery);
    }
}(function ($) {
    'use strict';

    var JalaliDatePlugin = {
        // Current state
        currentInput: null,
        picker: null,
        pickerOpen: false,
        currentView: 'days', // 'days', 'months', 'years'
        currentYear: 0,
        currentMonth: 0,
        currentDay: 0,
        currentHour: 0,
        currentMinute: 0,

        // Persian month names
        monthNames: ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
                     'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'],
        dayNames: ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه'],
        dayShortNames: ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'],

        // Persian digits
        faDigits: ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'],

        /* آستانه تشخیص تقویم (رفع باگ سال ۲۶۴۷):
         * سالهای چهاررقمیِ >= 1700 «میلادی» و سالهای کمتر «شمسی» تلقی
         * می‌شوند. سالهای شمسیِ متعارف ۱۳۰۰ تا ۱۶۰۰ هستند، پس این مرز
         * برای تاریخ‌های واقعی وبلاگ (میلادی ۱۹۷۰+ و شمسی ۱۳xx–۱۵xx)
         * هرگز مبهم نیست. */
        gregorianYearMin: 1700,

        /* آستانه تاریخِ خراب (رفع باگ «۲۶ آبان ۲۰۲۶»):
         * سالهای میلادی ۲۳۰۰ به بالا هرگز تاریخ واقعی وبلاگ نیستند؛
         * این بازه فقط نتیجهٔ دوبار تبدیل‌شدن تاریخ توسط باگ نسخه‌های
         * قبل است (۲۰۲۶+۶۲۱=۲۶۴۷ و مشابه آن). چنین مقداری هنگام نمایش
         * به تاریخ درست بازیابی می‌شود. */
        corruptedYearMin: 2300,

        // نسخهٔ اسکریپت — با پیام کنسول نیز اعلام می‌شود تا پس از
        // به‌روزرسانی، اجرای نسخهٔ جدید (نه نسخهٔ کش‌شدهٔ مرورگر) قابل
        // تأیید باشد: در DevTools Console باید «[JalaliDate] v1.3.1»
        // دیده شود.
        VERSION: '1.3.0',

        /**
         * Initialize the date picker on a given input selector
         */
        init: function (selector) {
            var self = this;

            // Wait for Typecho's default datepicker to be initialized, then disable it
            setTimeout(function () {
                self.replacePicker(selector);
            }, 100);
        },

        /**
         * Replace the existing Gregorian datetimepicker with Jalali picker
         */
        replacePicker: function (selector) {
            var self = this;
            var $input = $(selector);

            if ($input.length === 0) {
                return;
            }

            // Disable the existing jQuery UI datepicker if initialized
            try {
                if ($input.hasClass('hasDatepicker')) {
                    $input.datepicker('destroy');
                }
            } catch (e) {
                // ignore
            }

            // Remove the mask
            try { $input.unmask && $input.unmask(); } catch (e) {}
            $input.off('blur.timepicker').off('focus.timepicker');

            // Convert initial value from Gregorian to Jalali for display
            var gregorianValue = $input.val();
            if (gregorianValue) {
                var jalaliValue = self.gregorianToJalaliString(gregorianValue);
                if (jalaliValue && jalaliValue !== gregorianValue) {
                    $input.val(jalaliValue);
                }
            }

            // Update display value
            self.updateDisplay($input);

            // Attach click handler (use mousedown to prevent blur)
            $input.off('mousedown.jalali click.jalali').on('mousedown.jalali click.jalali', function (e) {
                e.preventDefault();
                e.stopPropagation();
                if (!self.pickerOpen) {
                    self.openPicker($(this));
                }
                return false;
            });

            // Allow manual editing - don't auto-clear on keypress
            // فقط هنگام blur (خروج از فیلد) مقدار را بررسی و تصحیح کن
            $input.off('blur.jalali').on('blur.jalali', function (e) {
                // اگر picker باز است، blur را نادیده بگیر
                if (self.pickerOpen) {
                    return;
                }
                var val = $(this).val();
                if (val) {
                    // تلاش برای parse کردن مقدار وارد شده
                    var parsed = self.parseJalaliInput(val);
                    if (parsed && parsed !== val) {
                        $(this).val(parsed);
                    }
                    self.updateDisplay($(this));
                }
            });

            // Hook into form submit to convert back to Gregorian
            $input.closest('form').off('submit.jalali').on('submit.jalali', function () {
                var greg = self.convertOnSubmit($input);

                // اگر ارسال فرم توسط هسته لغو شود (مثلاً آپلود در جریان
                // است) نمایش شمسی پس از لحظه‌ای برگردانده می‌شود؛ اگر فرم
                // واقعاً ارسال شود، صفحه هدایت می‌شود و این تایمر بی‌اثر
                // می‌ماند (داده‌ها هنگام submit سریال‌سازی شده‌اند).
                setTimeout(function () {
                    self.restoreDisplay($input, greg);
                }, 1200);
            });

            // Also hook into Typecho's AJAX saves (auto-save, preview, uploads)
            // هم savePost و هم ensureCid باید قبل از ساخت FormData مقدار
            // را میلادی کنند و بلافاصله پس از ارسال، نمایش شمسی را
            // برگردانند تا ذخیره‌های بعدی دوباره تبدیل نکنند.
            if (typeof Typecho !== 'undefined') {
                self.hookAjaxSave('savePost');
                self.hookAjaxSave('ensureCid');
            }
        },

        /**
         * Wrap Typecho.savePost / Typecho.ensureCid so the Jalali value is
         * converted to Gregorian before the AJAX payload is built, and the
         * Jalali display is restored right after the request has been sent.
         *
         * نکته: FormData داخل requestSave به‌صورت همگام ساخته و ارسال
         * می‌شود، بنابراین در تِیک بعدی بازگردانی نمایش امن است.
         */
        hookAjaxSave: function (name) {
            var self = this;
            var fn = Typecho[name];

            if (typeof fn !== 'function' || fn._jalaliHooked) {
                return;
            }

            var wrapped = function () {
                var converted = [];
                // فیلدهای فقط‌نمایشی (readonly مثل جعبهٔ نمایش شمسی) تبدیل نمی‌شوند
                $('.typecho-date:not([readonly])').each(function () {
                    var $input = $(this);
                    var greg = self.convertOnSubmit($input);
                    if (greg !== null) {
                        converted.push([$input, greg]);
                    }
                });

                var result = fn.apply(this, arguments);

                setTimeout(function () {
                    for (var i = 0; i < converted.length; i++) {
                        self.restoreDisplay(converted[i][0], converted[i][1]);
                    }
                }, 0);

                return result;
            };

            wrapped._jalaliHooked = true;
            Typecho[name] = wrapped;
        },

        /**
         * Parse user input - accepts both Jalali and Gregorian
         * Returns formatted Jalali string (Persian digits) or null if can't parse
         *
         * ابهام‌زدایی (رفع باگ سال ۲۶۴۷): سالِ چهاررقمیِ ۱۷۰۰ به بالا
         * «میلادی» تلقی شده و برای نمایش به شمسی تبدیل می‌شود؛ سالهای
         * کمتر شمسی در نظر گرفته می‌شوند. به این ترتیب مقدار میلادیِ
         * Y-m-d (که مثلاً پس از ذخیرهٔ خودکار در فیلد مانده) دیگر
         * با سال میلادی به‌صورت «۲۰۲۶/۰۸/۲۷» شمسی‌سازی نمی‌شود.
         */
        parseJalaliInput: function (val) {
            var self = this;
            if (!val) return null;

            val = self.toEnglishDigits(val).trim();

            // Y/m/d یا Y-m-d (+ ساعت اختیاری)
            var match = val.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})(?:[ T](\d{1,2}):(\d{1,2}))?/);
            if (!match) {
                return null;
            }

            var year = parseInt(match[1], 10);
            var month = parseInt(match[2], 10);
            var day = parseInt(match[3], 10);
            var hour = match[4] ? parseInt(match[4], 10) : 0;
            var minute = match[5] ? parseInt(match[5], 10) : 0;

            if (hour < 0 || hour > 23 || minute < 0 || minute > 59) {
                return null;
            }

            if (year >= self.gregorianYearMin) {
                // ورودی میلادی است → برای نمایش به شمسی تبدیل کن
                // (اگر تاریخِ خرابِ ۲۳۰۰+ باشد ابتدا اصلاح می‌شود)
                var r = self.repairCorrupted(year, month, day);
                var j = self.toJalali(r[0], r[1], r[2]);
                return self.toPersianDigits(
                    j[0] + '/' + self.pad(j[1]) + '/' + self.pad(j[2]) +
                    ' ' + self.pad(hour) + ':' + self.pad(minute)
                );
            }

            // ورودی شمسی است → اعتبارسنجی و نرمال‌سازی
            if (month >= 1 && month <= 12 && day >= 1 && day <= self.daysInMonth(year, month)) {
                return self.toPersianDigits(
                    year + '/' + self.pad(month) + '/' + self.pad(day) +
                    ' ' + self.pad(hour) + ':' + self.pad(minute)
                );
            }

            return null;
        },

        /**
         * Convert Gregorian "Y-m-d H:i" string to Jalali "Y/m/d H:i" string
         * اگر سال ورودی از قبل شمسی باشد (کمتر از ۱۷۰۰) همان مقدار
         * بدون تغییر برگردانده می‌شود.
         */
        gregorianToJalaliString: function (gregorianStr) {
            var self = this;
            if (!gregorianStr) return gregorianStr;

            var str = self.toEnglishDigits(String(gregorianStr)).trim();
            var match = str.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})(?:[ T](\d{1,2}):(\d{1,2}))?/);
            if (!match) {
                return gregorianStr;
            }

            var gy = parseInt(match[1], 10);
            var gm = parseInt(match[2], 10);
            var gd = parseInt(match[3], 10);
            var hour = match[4] ? parseInt(match[4], 10) : 0;
            var minute = match[5] ? parseInt(match[5], 10) : 0;

            if (gy < self.gregorianYearMin) {
                // سال شمسی است — از قبل جلالی است، دست نمی‌زنیم
                return gregorianStr;
            }

            // تاریخ خراب‌شده توسط باگ نسخه‌های قبل؟ (سال ۲۳۰۰ به بالا
            // هرگز تاریخ واقعی نیست) → بازیابی تاریخ درست
            var repaired = self.repairCorrupted(gy, gm, gd);
            gy = repaired[0]; gm = repaired[1]; gd = repaired[2];

            var jalali = self.toJalali(gy, gm, gd);
            return self.toPersianDigits(
                jalali[0] + '/' + self.pad(jalali[1]) + '/' + self.pad(jalali[2]) +
                ' ' + self.pad(hour) + ':' + self.pad(minute)
            );
        },

        /**
         * Convert Jalali "Y/m/d H:i" string to Gregorian "Y-m-d H:i" string
         *
         * یک‌بار‌اثر (رفع باگ سال ۲۶۴۷): اگر سال ورودی >= ۱۷۰۰ باشد،
         * مقدار از قبل میلادی است و فقط جداکننده‌ها به «-» نرمال
         * می‌شود؛ هیچ تبدیل شمسی→میلادی انجام نمی‌گیرد.
         */
        jalaliToGregorianString: function (jalaliStr) {
            var self = this;
            if (!jalaliStr) return '';

            // Convert Persian digits to English
            var str = self.toEnglishDigits(String(jalaliStr)).trim();

            // Support both / and - separators
            var match = str.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})(?:[ T](\d{1,2}):(\d{1,2}))?/);
            if (!match) {
                return jalaliStr;
            }

            var jy = parseInt(match[1], 10);
            var jm = parseInt(match[2], 10);
            var jd = parseInt(match[3], 10);
            var hour = match[4] ? parseInt(match[4], 10) : 0;
            var minute = match[5] ? parseInt(match[5], 10) : 0;

            if (jy >= self.gregorianYearMin) {
                // از قبل میلادی است — فقط نرمال‌سازی جداکننده‌ها برای سرور.
                // تاریخِ خراب (سال >= ۲۳۰۰) پیش از ارسال به سرور اصلاح می‌شود.
                var fixed = self.repairCorrupted(jy, jm, jd);
                return fixed[0] + '-' + self.pad(fixed[1]) + '-' + self.pad(fixed[2]) +
                       ' ' + self.pad(hour) + ':' + self.pad(minute);
            }

            var gregorian = self.toGregorian(jy, jm, jd);
            return gregorian[0] + '-' + self.pad(gregorian[1]) + '-' + self.pad(gregorian[2]) +
                   ' ' + self.pad(hour) + ':' + self.pad(minute);
        },

        /**
         * بازیابی تاریخِ خراب‌شده (باگ دوتایی نسخه‌های قبل).
         *
         * خرابی وقتی رخ داده که یک تاریخ میلادی (مثل 2026-08-26) به‌اشتباه
         * «شمسی» فرض و دوباره به میلادی تبدیل شده (+۶۲۱ سال → 2647-08-10).
         * بازگرداندن آن دقیقاً عکس همین عمل است: تاریخِ ذخیره‌شده را شمسی
         * می‌کنیم و همان اعداد، تاریخ میلادیِ درست‌اند (2026-08-26).
         * حلقه برای مواقعی است که باگ چند بار اجرا شده باشد (۲۶۴۷ → ۳۲۶۸ …).
         */
        repairCorrupted: function (gy, gm, gd) {
            var guard = 0;
            while (gy >= this.corruptedYearMin && guard < 5) {
                var j = this.toJalali(gy, gm, gd);
                gy = j[0]; gm = j[1]; gd = j[2];
                guard++;
            }
            return [gy, gm, gd];
        },

        /**
         * Parse the field value into a NORMALIZED Jalali state.
         * ابهام‌زدایی تقویم (هماهنگ با jalaliToGregorianString):
         *  - سال >= ۲۳۰۰: تاریخ خرابِ دوبار-تبدیل‌شده → اصلاح می‌شود
         *  - سال >= ۱۷۰۰: میلادی → به شمسی تبدیل می‌شود
         *  - سال <  ۱۷۰۰: شمسی → همان‌طور قبول می‌شود
         * خروجی: {jy, jm, jd, hour, minute} یا null
         */
        parseFieldValue: function (value) {
            var self = this;
            if (!value) {
                return null;
            }

            value = self.toEnglishDigits(String(value)).trim();
            var match = value.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})(?:[ T](\d{1,2}):(\d{1,2}))?/);
            if (!match) {
                return null;
            }

            var y = parseInt(match[1], 10);
            var mo = parseInt(match[2], 10);
            var d = parseInt(match[3], 10);
            var hour = match[4] ? parseInt(match[4], 10) : 0;
            var minute = match[5] ? parseInt(match[5], 10) : 0;

            if (y >= self.corruptedYearMin) {
                // تاریخ خراب → ابتدا به میلادیِ درست بازیابی می‌شود،
                // سپس (مثل شاخهٔ زیر) به شمسی تبدیل می‌شود.
                var r = self.repairCorrupted(y, mo, d);
                y = r[0]; mo = r[1]; d = r[2];
            }
            if (y >= self.gregorianYearMin) {
                var j = self.toJalali(y, mo, d);
                y = j[0]; mo = j[1]; d = j[2];
            }

            return { jy: y, jm: mo, jd: d, hour: hour, minute: minute };
        },

        /**
         * Open the date picker
         */
        openPicker: function ($input) {
            var self = this;
            self.currentInput = $input;

            // Parse current value
            var value = $input.val() || '';
            var now = new Date();
            var jy, jm, jd, hour, minute;

            if (value) {
                // ابهام‌زدایی تقویم (رفع باگ «۲۶ آبان ۲۰۲۶»): اگر فیلد
                // لحظه‌ای مقدار میلادی/خراب داشته باشد، وضعیت تقویم به
                // ماه و سالِ شمسیِ درست نرمال می‌شود.
                var parsed = self.parseFieldValue(value);
                if (parsed) {
                    jy = parsed.jy; jm = parsed.jm; jd = parsed.jd;
                    hour = parsed.hour; minute = parsed.minute;
                } else {
                    var nowJ = self.toJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
                    jy = nowJ[0]; jm = nowJ[1]; jd = nowJ[2];
                    hour = now.getHours(); minute = now.getMinutes();
                }
            } else {
                var nowJ2 = self.toJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
                jy = nowJ2[0]; jm = nowJ2[1]; jd = nowJ2[2];
                hour = now.getHours(); minute = now.getMinutes();
            }

            self.currentYear = jy;
            self.currentMonth = jm;
            self.currentDay = jd;
            self.currentHour = hour;
            self.currentMinute = minute;
            self.currentView = 'days';

            // Create picker
            self.createPicker();
            self.positionPicker($input);
            self.renderPicker();
            self.pickerOpen = true;
        },

        /**
         * Create the picker DOM element
         */
        createPicker: function () {
            var self = this;
            self.closePicker(); // close any existing

            self.picker = $('<div class="jdp-container" style="position:absolute;"></div>');
            $('body').append(self.picker);

            // Click outside to close - but ignore clicks inside the picker itself
            // Use mousedown event with a delay to allow picker buttons to work
            setTimeout(function () {
                self._documentClickHandler = function (e) {
                    // اگر کلیک داخل picker یا input است، بسته نشود
                    if ($(e.target).closest('.jdp-container').length > 0) {
                        return; // کلیک داخل picker
                    }
                    if ($(e.target).hasClass('typecho-date') || $(e.target).closest('.typecho-date').length > 0) {
                        return; // کلیک روی input
                    }
                    self.closePicker();
                };
                $(document).on('mousedown.jalali-picker', self._documentClickHandler);
            }, 100);

            // Escape to close
            $(document).on('keydown.jalali-picker', function (e) {
                if (e.keyCode === 27) {
                    self.closePicker();
                }
            });
        },

        /**
         * Position the picker relative to the input
         */
        positionPicker: function ($input) {
            var self = this;
            var offset = $input.offset();
            var inputHeight = $input.outerHeight();
            self.picker.css({
                top: offset.top + inputHeight + 4,
                left: offset.left
            });
        },

        /**
         * Render the picker content based on current view
         */
        renderPicker: function () {
            var self = this;
            self.picker.empty();

            if (self.currentView === 'days') {
                self.renderDaysView();
            } else if (self.currentView === 'months') {
                self.renderMonthsView();
            } else if (self.currentView === 'years') {
                self.renderYearsView();
            }
        },

        /**
         * Render the days view
         */
        renderDaysView: function () {
            var self = this;
            var header = $(
                '<div class="jdp-header">' +
                '  <button type="button" class="jdp-nav jdp-prev" title="ماه قبل">‹</button>' +
                '  <span class="jdp-title"></span>' +
                '  <button type="button" class="jdp-nav jdp-next" title="ماه بعد">›</button>' +
                '</div>'
            );

            var title = self.monthNames[self.currentMonth - 1] + ' ' + self.toPersianDigits(String(self.currentYear));
            header.find('.jdp-title').text(title);

            // استفاده از mousedown برای دکمه‌های ناوبری + stopPropagation
            header.find('.jdp-prev').on('mousedown', function (e) {
                e.preventDefault();
                e.stopPropagation();
                if (self.currentMonth === 1) {
                    self.currentMonth = 12;
                    self.currentYear--;
                } else {
                    self.currentMonth--;
                }
                self.renderPicker();
                return false;
            }).on('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            });

            header.find('.jdp-next').on('mousedown', function (e) {
                e.preventDefault();
                e.stopPropagation();
                if (self.currentMonth === 12) {
                    self.currentMonth = 1;
                    self.currentYear++;
                } else {
                    self.currentMonth++;
                }
                self.renderPicker();
                return false;
            }).on('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            });

            header.find('.jdp-title').on('mousedown', function (e) {
                e.preventDefault();
                e.stopPropagation();
                self.currentView = 'months';
                self.renderPicker();
                return false;
            }).on('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            });

            self.picker.append(header);

            // Day name headers (شنبه first)
            var table = $('<table class="jdp-grid"><thead></thead><tbody></tbody></table>');
            var thead = table.find('thead');
            var tr = $('<tr></tr>');
            $.each(self.dayShortNames, function (i, name) {
                tr.append($('<th>').text(name));
            });
            thead.append(tr);

            // Calculate days
            var daysInMonth = self.daysInMonth(self.currentYear, self.currentMonth);
            var firstDayJalali = new Date(self.toGregorian(self.currentYear, self.currentMonth, 1).join('-'));
            // 0=Sunday (یکشنبه), but we want شنبه first so adjust
            // شنبه = Saturday = JS day 6
            // یکشنبه = Sunday = JS day 0
            // ما شنبه را به عنوان روز اول هفته می‌خواهیم
            var firstDayOfWeek = firstDayJalali.getDay(); // 0-6 (Sun-Sat)
            // تبدیل: شنبه=0, یکشنبه=1, دوشنبه=2, ...
            var startOffset = (firstDayOfWeek + 1) % 7;

            var tbody = table.find('tbody');
            var row = $('<tr></tr>');
            var cellCount = 0;

            // Empty cells before first day
            for (var i = 0; i < startOffset; i++) {
                row.append($('<td class="jdp-disabled"></td>').text(''));
                cellCount++;
            }

            // Days of month
            var todayJ = self.toJalali(new Date().getFullYear(), new Date().getMonth() + 1, new Date().getDate());
            for (var d = 1; d <= daysInMonth; d++) {
                var td = $('<td></td>').text(self.toPersianDigits(String(d)));

                if (self.currentYear === todayJ[0] && self.currentMonth === todayJ[1] && d === todayJ[2]) {
                    td.addClass('jdp-today');
                }
                if (d === self.currentDay) {
                    td.addClass('jdp-selected');
                }

                (function (day) {
                    td.on('mousedown', function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        self.currentDay = day;
                        self.updateInputValue();
                        self.closePicker();
                        return false;
                    }).on('click', function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        return false;
                    });
                })(d);

                row.append(td);
                cellCount++;
                if (cellCount % 7 === 0) {
                    tbody.append(row);
                    row = $('<tr></tr>');
                }
            }

            // Fill remaining cells
            if (cellCount % 7 !== 0) {
                while (cellCount % 7 !== 0) {
                    row.append($('<td class="jdp-disabled"></td>').text(''));
                    cellCount++;
                }
                tbody.append(row);
            }

            self.picker.append(table);

            // Time row
            self.appendTimeRow();
        },

        /**
         * Render the months view
         */
        renderMonthsView: function () {
            var self = this;
            var header = $(
                '<div class="jdp-header">' +
                '  <button type="button" class="jdp-nav jdp-prev" title="سال قبل">‹</button>' +
                '  <span class="jdp-title"></span>' +
                '  <button type="button" class="jdp-nav jdp-next" title="سال بعد">›</button>' +
                '</div>'
            );

            var title = self.toPersianDigits(String(self.currentYear));
            header.find('.jdp-title').text(title);

            header.find('.jdp-prev').on('mousedown', function (e) {
                e.preventDefault();
                e.stopPropagation();
                self.currentYear--;
                self.renderPicker();
                return false;
            }).on('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            });
            header.find('.jdp-next').on('mousedown', function (e) {
                e.preventDefault();
                e.stopPropagation();
                self.currentYear++;
                self.renderPicker();
                return false;
            }).on('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            });
            header.find('.jdp-title').on('mousedown', function (e) {
                e.preventDefault();
                e.stopPropagation();
                self.currentView = 'years';
                self.renderPicker();
                return false;
            }).on('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            });

            self.picker.append(header);

            var monthsDiv = $('<div class="jdp-months-view"></div>');
            $.each(self.monthNames, function (i, name) {
                var monthDiv = $('<div class="jdp-month"></div>').text(name);
                if (i + 1 === self.currentMonth) {
                    monthDiv.addClass('jdp-selected');
                }
                monthDiv.on('mousedown', function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    self.currentMonth = i + 1;
                    self.currentView = 'days';
                    self.renderPicker();
                    return false;
                }).on('click', function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    return false;
                });
                monthsDiv.append(monthDiv);
            });
            self.picker.append(monthsDiv);
        },

        /**
         * Render the years view
         */
        renderYearsView: function () {
            var self = this;
            var startYear = Math.floor(self.currentYear / 12) * 12;

            var header = $(
                '<div class="jdp-header">' +
                '  <button type="button" class="jdp-nav jdp-prev" title="دوره قبل">‹</button>' +
                '  <span class="jdp-title"></span>' +
                '  <button type="button" class="jdp-nav jdp-next" title="دوره بعد">›</button>' +
                '</div>'
            );

            var title = self.toPersianDigits(String(startYear)) + ' - ' + self.toPersianDigits(String(startYear + 11));
            header.find('.jdp-title').text(title);

            header.find('.jdp-prev').on('mousedown', function (e) {
                e.preventDefault();
                e.stopPropagation();
                self.currentYear -= 12;
                self.renderPicker();
                return false;
            }).on('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            });
            header.find('.jdp-next').on('mousedown', function (e) {
                e.preventDefault();
                e.stopPropagation();
                self.currentYear += 12;
                self.renderPicker();
                return false;
            }).on('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            });

            self.picker.append(header);

            var yearsDiv = $('<div class="jdp-years-view"></div>');
            for (var y = startYear; y < startYear + 12; y++) {
                var yearDiv = $('<div class="jdp-year"></div>').text(self.toPersianDigits(String(y)));
                if (y === self.currentYear) {
                    yearDiv.addClass('jdp-selected');
                }
                (function (year) {
                    yearDiv.on('mousedown', function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        self.currentYear = year;
                        self.currentView = 'months';
                        self.renderPicker();
                        return false;
                    }).on('click', function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        return false;
                    });
                })(y);
                yearsDiv.append(yearDiv);
            }
            self.picker.append(yearsDiv);
        },

        /**
         * Append time row to picker
         */
        appendTimeRow: function () {
            var self = this;
            var timeRow = $('<div class="jdp-time-row"></div>');

            var hourSelect = $('<select id="jdp-hour"></select>');
            for (var h = 0; h < 24; h++) {
                hourSelect.append($('<option></option>').val(h).text(self.toPersianDigits(self.pad(h))));
            }
            hourSelect.val(self.currentHour);
            hourSelect.on('mousedown', function (e) {
                e.stopPropagation();
            }).on('change', function () {
                self.currentHour = parseInt($(this).val(), 10);
                self.updateInputValue();
            });

            var minuteSelect = $('<select id="jdp-minute"></select>');
            for (var m = 0; m < 60; m++) {
                minuteSelect.append($('<option></option>').val(m).text(self.toPersianDigits(self.pad(m))));
            }
            minuteSelect.val(self.currentMinute);
            minuteSelect.on('mousedown', function (e) {
                e.stopPropagation();
            }).on('change', function () {
                self.currentMinute = parseInt($(this).val(), 10);
                self.updateInputValue();
            });

            timeRow.append('<span>ساعت:</span>').append(hourSelect)
                   .append('<span>دقیقه:</span>').append(minuteSelect);

            self.picker.append(timeRow);

            // دکمهٔ «اکنون» — تاریخ و زمان را به لحظهٔ حال می‌برد
            self.appendNowButton();
        },

        /**
         * Append a "Now" button that jumps the picker state to the
         * current Gregorian moment (converted to Jalali) — both date
         * (year/month/day) and time (hour/minute) — and applies the
         * value to the underlying input before closing the picker.
         *
         * نسخهٔ 1.2.8: این متد صرفاً یک دکمهٔ جدید به تقویم اضافه می‌کند؛
         * هیچ‌یک از متدهای دیگر پلاگین دست نخورده‌اند.
         */
        appendNowButton: function () {
            var self = this;
            var nowRow = $('<div class="jdp-now-row"></div>');
            var nowBtn = $(
                '<button type="button" class="jdp-now-btn" title="تنظیم به زمان حال">اکنون</button>'
            );

            nowBtn.on('mousedown', function (e) {
                e.preventDefault();
                e.stopPropagation();
                var now = new Date();
                var nowJ = self.toJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
                self.currentYear  = nowJ[0];
                self.currentMonth = nowJ[1];
                self.currentDay   = nowJ[2];
                self.currentHour    = now.getHours();
                self.currentMinute  = now.getMinutes();
                self.updateInputValue();
                self.closePicker();
                return false;
            }).on('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            });

            nowRow.append(nowBtn);
            self.picker.append(nowRow);
        },

        /**
         * Update input value with current selection
         */
        updateInputValue: function () {
            var self = this;
            if (!self.currentInput) return;

            var value = self.currentYear + '/' + self.pad(self.currentMonth) + '/' + self.pad(self.currentDay) +
                        ' ' + self.pad(self.currentHour) + ':' + self.pad(self.currentMinute);

            value = self.toPersianDigits(value);

            self.currentInput.val(value);
            self.updateDisplay(self.currentInput);
        },

        /**
         * Update the display field showing Jalali date
         * نمایش همیشه شمسی است؛ اگر مقدار فیلد لحظه‌ای میلادی باشد
         * (وسط فرایند ارسال) فقط برای این فیلدِ فقط‌نمایشی به شمسی
         * تبدیل می‌شود.
         */
        updateDisplay: function ($input) {
            var self = this;
            var value = $input.val();
            var $display = $('#jalali-date-display');
            if ($display.length) {
                if (!value) {
                    $display.val('');
                } else {
                    var shown = value;
                    var en = self.toEnglishDigits(value).trim();
                    var m = en.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})/);
                    if (m && parseInt(m[1], 10) >= self.gregorianYearMin) {
                        shown = self.gregorianToJalaliString(en);
                    }
                    $display.val(shown);
                }
            }
            $('#jalali-date-display-section').show();
        },

        /**
         * بازگرداندن نمایش شمسی فیلد پس از ارسال مقدار میلادی به سرور.
         * فقط وقتی اجرا می‌شود که کاربر در این فاصله مقدار فیلد را
         * تغییر نداده باشد (expectedGregorian هنوز مقدار فعلی فیلد است).
         */
        restoreDisplay: function ($input, expectedGregorian) {
            var self = this;
            var current = $input.val();
            if (!current) {
                return;
            }
            if (expectedGregorian && current !== expectedGregorian) {
                return; // مقدار در این میان تغییر کرده — احترام به ورودی کاربر
            }

            var en = self.toEnglishDigits(current).trim();
            var m = en.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})/);
            if (!m) {
                return;
            }

            if (parseInt(m[1], 10) >= self.gregorianYearMin) {
                var jalali = self.gregorianToJalaliString(en);
                if (jalali && jalali !== current) {
                    $input.val(jalali);
                }
                self.updateDisplay($input);
            }
        },

        /**
         * Convert input value back to Gregorian for submission (idempotent).
         *
         * رفع باگ سال ۲۶۴۷: این متد «یک‌بار‌اثر» است — قبلاً هر بار
         * اجرای مجدد آن روی مقدار میلادیِ Y-m-d، آن را دوباره شمسی فرض
         * کرده و حدود ۶۲۱ سال به سال اضافه می‌کرد. خروجی: مقدار میلادی
         * نهایی که باید به سرور برود (یا null اگر فیلد خالی است).
         */
        convertOnSubmit: function ($input) {
            var self = this;
            var raw = $input.val();
            if (!raw) {
                return null;
            }

            var gregorianValue = self.jalaliToGregorianString(raw);
            if (gregorianValue === raw) {
                // قابل تبدیل نبود یا از قبل میلادیِ نرمال بود — دست نمی‌زنیم
                return gregorianValue;
            }

            $input.val(gregorianValue);
            return gregorianValue;
        },

        /**
         * Close the picker
         */
        closePicker: function () {
            var self = this;
            if (self.picker) {
                self.picker.remove();
                self.picker = null;
            }
            if (self._documentClickHandler) {
                $(document).off('mousedown.jalali-picker', self._documentClickHandler);
                self._documentClickHandler = null;
            }
            $(document).off('keydown.jalali-picker');
            self.pickerOpen = false;
        },

        /**
         * Pad a number with leading zero
         */
        pad: function (n) {
            return (n < 10 ? '0' : '') + n;
        },

        /**
         * Convert English digits to Persian
         */
        toPersianDigits: function (str) {
            var self = this;
            str = String(str);
            for (var i = 0; i < 10; i++) {
                str = str.replace(new RegExp(i, 'g'), self.faDigits[i]);
            }
            return str;
        },

        /**
         * Convert Persian digits to English
         */
        toEnglishDigits: function (str) {
            var self = this;
            str = String(str);
            for (var i = 0; i < 10; i++) {
                str = str.replace(new RegExp(self.faDigits[i], 'g'), String(i));
            }
            return str;
        },

        /**
         * Get days in a Jalali month
         */
        daysInMonth: function (jy, jm) {
            if (jm <= 6) return 31;
            if (jm <= 11) return 30;
            return this.isLeapYear(jy) ? 30 : 29;
        },

        /**
         * Verified Jalali leap years table (from time.ir astronomical data)
         * Covers years 1288 to 1614
         */
        leapYearsSet: {
            1288:1, 1292:1, 1296:1, 1300:1, 1304:1, 1309:1, 1313:1, 1317:1,
            1321:1, 1325:1, 1329:1, 1333:1, 1337:1, 1342:1, 1346:1, 1350:1,
            1354:1, 1358:1, 1362:1, 1366:1, 1370:1, 1375:1, 1379:1, 1383:1,
            1387:1, 1391:1, 1395:1, 1399:1, 1403:1, 1407:1, 1411:1, 1415:1,
            1420:1, 1424:1, 1428:1, 1432:1, 1436:1, 1440:1, 1445:1, 1449:1,
            1453:1, 1457:1, 1461:1, 1465:1, 1469:1, 1474:1, 1478:1, 1482:1,
            1486:1, 1490:1, 1494:1, 1498:1, 1503:1, 1507:1, 1511:1, 1515:1,
            1519:1, 1523:1, 1527:1, 1531:1, 1536:1, 1540:1, 1544:1, 1548:1,
            1552:1, 1556:1, 1560:1, 1564:1, 1569:1, 1573:1, 1577:1, 1581:1,
            1585:1, 1589:1, 1593:1, 1597:1, 1602:1, 1606:1, 1610:1, 1614:1
        },

        /**
         * Check if a Jalali year is a leap year
         */
        isLeapYear: function (jy) {
            return !!this.leapYearsSet[jy];
        },

        /**
         * Convert Gregorian to Jalali using day-count from Unix epoch
         * Reference: 1970-01-01 G = 1348-10-11 J
         */
        toJalali: function (gy, gm, gd) {
            var date = new Date(Date.UTC(gy, gm - 1, gd));
            var epoch = new Date(Date.UTC(1970, 0, 1));
            var daysSinceEpoch = Math.round((date - epoch) / 86400000);

            var jy = 1348, jm = 10, jd = 11;
            var remaining = daysSinceEpoch;

            if (remaining > 0) {
                while (remaining > 0) {
                    var dim = this.daysInMonth(jy, jm);
                    if (jd + remaining <= dim) {
                        jd += remaining;
                        remaining = 0;
                    } else {
                        remaining -= (dim - jd + 1);
                        jd = 1;
                        if (jm < 12) {
                            jm++;
                        } else {
                            jm = 1;
                            jy++;
                        }
                    }
                }
            } else if (remaining < 0) {
                while (remaining < 0) {
                    if (jd + remaining >= 1) {
                        jd += remaining;
                        remaining = 0;
                    } else {
                        remaining += jd;
                        if (jm > 1) {
                            jm--;
                        } else {
                            jm = 12;
                            jy--;
                        }
                        jd = this.daysInMonth(jy, jm);
                    }
                }
            }
            return [jy, jm, jd];
        },

        /**
         * Convert Jalali to Gregorian by walking from reference (1348-10-11 J)
         */
        toGregorian: function (jy, jm, jd) {
            var cy = 1348, cm = 10, cd = 11;
            var days = 0;

            while (cy < jy || (cy === jy && cm < jm) || (cy === jy && cm === jm && cd < jd)) {
                days++;
                cd++;
                var dim = this.daysInMonth(cy, cm);
                if (cd > dim) {
                    cd = 1;
                    if (cm < 12) {
                        cm++;
                    } else {
                        cm = 1;
                        cy++;
                    }
                }
            }

            var epoch = new Date(Date.UTC(1970, 0, 1));
            var target = new Date(epoch.getTime() + days * 86400000);
            return [target.getUTCFullYear(), target.getUTCMonth() + 1, target.getUTCDate()];
        }
    };

    // Export
    window.JalaliDatePlugin = JalaliDatePlugin;

    // نشانگر نسخه — برای اطمینان از اجرای نسخهٔ جدید (نه کشِ قدیمی)
    // در DevTools Console این پیام را ببینید: [JalaliDate] v1.2.8
    try {
        if (window.console && console.info) {
            console.info('[JalaliDate] datepicker v' + JalaliDatePlugin.VERSION + ' loaded');
        }
    } catch (e) { /* noop */ }

    return JalaliDatePlugin;
}));
