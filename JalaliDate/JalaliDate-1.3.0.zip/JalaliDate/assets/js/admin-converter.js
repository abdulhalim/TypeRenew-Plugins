/* JalaliDate Plugin - Admin Display Converter (TypeRenew 1.6.1-compatible)
 *
 * تبدیل تاریخ‌های نمایشی پنل مدیریت به شمسی
 *
 * این اسکریپت روی صفحه‌های مختلف پنل اجرا می‌شود:
 *  - manage-posts, manage-pages, manage-comments, manage-medias, manage-users
 *  - dashboard (index.php)
 *  - profile, write-post, write-page
 *
 * تغییرات نسخه TypeRenew:
 *  ۱) پشتیبانی از خروجی Zone::word زبان چینی TypeRenew:
 *     «刚刚»، «N秒前»، «N分钟前»، «N小时前»، «昨天 HH:MM»،
 *     «N天前»، «N月J日»، «Y年m月d日»
 *  ۲) پشتیبانی از کلاس‌های اختصاصی TypeRenew:
 *     .tr-subtext, .tr-profile-sub, .comment-date,
 *     .edit-draft-notice-text, .tr-td و …
 *  ۳) تبدیل مقدار داخل <input type="text"> که توسط datepicker شمسی
 *     پوشش داده نشده باشد (مثل فیلدهای timepicker اضافی قالب).
 *  ۴) تبدیل رشته‌های ISO 8601 کوتاه (YYYY-MM-DDTHH:MM) که گاهی در
 *     attribute های datetime تگ <time> ظاهر می‌شوند (فقط متن، نه attribute).
 *
 * نسخه 1.2.0: تنظیمات «نوع اعداد» و «زبان نام ماه» حذف شدند؛
 * نمایش همیشه با اعداد فارسی و نام ماه‌های فارسی انجام می‌شود.
 *
 * نسخه 1.3.0 (بهینه‌سازی برای TypeRenew 1.6.1):
 *   در TypeRenew 1.6.1، فایل زبان fa_IR.mo به‌صورت بومی همه رشته‌های
 *   چینیِ تاریخ‌نما را به فارسی ترجمه می‌کند:
 *     - «刚刚» → «همین حالا»
 *     - «N秒前/N分钟前/N小时前/N天前» → «N ثانیه/دقیقه/ساعت/روز پیش»
 *     - «昨天 HH:MM» → «دیروز HH:MM»
 *     - «Y年m月d日» → «Y/m/d» (یعنی تاریخ میلادی به فرمت YYYY/MM/DD)
 *     - «n月j日» → «j/n» (یعنی تاریخ میلادی به فرمت D/M)
 *     - «%d年%d月%d日» → «%3$d/%2$d/%1$d» (یعنی DD/MM/YYYY)
 *
 *   مشکل: این تاریخ‌ها میلادی هستند نه شمسی، و الگوهای قدیمی فقط چینی
 *   را تشخیص می‌دادند. این نسخه الگوهای فارسی جدید را نیز پشتیبانی می‌کند
 *   و آن‌ها را به شمسی تبدیل می‌کند. الگوهای چینی نیز حفظ شده‌اند تا
 *   سایت‌های zh_CN هم پشتیبانی شوند.
 */

(function ($) {
    'use strict';

    var AdminConverter = {
        // ماه‌های میلادی - برای تشخیص رشته‌های تاریخ میلادی
        gregorianMonths: {
            'january': 1, 'february': 2, 'march': 3, 'april': 4, 'may': 5, 'june': 6,
            'july': 7, 'august': 8, 'september': 9, 'october': 10, 'november': 11, 'december': 12,
            'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'jun': 6, 'jul': 7,
            'aug': 8, 'sep': 9, 'sept': 9, 'oct': 10, 'nov': 11, 'dec': 12
        },

        faDigits: ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'],

        // نقشه اعداد فارسی/عربی به انگلیسی برای normalize
        faToEnDigitsMap: {
            '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4',
            '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9',
            '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4',
            '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9'
        },

        monthNamesFa: ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
                        'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'],

        init: function () {
            var self = this;

            $(function () {
                self.convertAllDates();
            });

            // Re-run for AJAX-loaded content (auto-save replies, etc.)
            if (typeof MutationObserver !== 'undefined') {
                var observer = new MutationObserver(function (mutations) {
                    var needsConvert = false;
                    mutations.forEach(function (m) {
                        if (m.addedNodes.length > 0) needsConvert = true;
                    });
                    if (needsConvert) {
                        setTimeout(function () { self.convertAllDates(); }, 50);
                    }
                });
                observer.observe(document.body, { childList: true, subtree: true });
            }
        },

        /**
         * Normalize digits - تبدیل اعداد فارسی/عربی به انگلیسی برای پردازش
         */
        normalizeDigits: function (str) {
            var self = this;
            str = String(str);
            for (var fa in self.faToEnDigitsMap) {
                if (self.faToEnDigitsMap.hasOwnProperty(fa)) {
                    str = str.split(fa).join(self.faToEnDigitsMap[fa]);
                }
            }
            return str;
        },

        /**
         * Find and convert all Gregorian / Chinese date strings in the page
         */
        convertAllDates: function () {
            var self = this;

            // 1. Date strings in TD cells of manage tables
            $('td').each(function () {
                self.convertTextNode(this);
            });

            // 2. Date strings in <time> elements (text only, not datetime attr)
            $('time').each(function () {
                var $time = $(this);
                var text = $time.text();
                var converted = self.tryConvertDateString(text);
                if (converted) {
                    $time.text(converted);
                }
            });

            // 3. Comments/pages/posts meta strings (Typecho classic + TypeRenew classes)
            $('.response, .comment-meta, .meta, .comment-date, .tr-subtext, .tr-profile-sub, .edit-draft-notice-text').each(function () {
                self.convertTextNode(this);
            });

            // 4. Description text containing dates (used in write-post/page "最后更新于" and similar)
            $('.description').each(function () {
                self.convertTextNode(this);
            });

            // 5. Strong tags often contain dates in admin
            $('strong').each(function () {
                self.convertTextNode(this);
            });

            // 6. Span tags containing date-like strings
            $('span').each(function () {
                if (!$(this).find('*').length) {
                    self.convertTextNode(this);
                }
            });

            // 7. Paragraph tags that may contain dates (write-post "最后更新于" lives in <p>)
            $('p').each(function () {
                if (!$(this).find('*').length) {
                    self.convertTextNode(this);
                }
            });

            // 8. Generic container for TypeRenew dashboard tiles
            $('.tr-td, .tr-pill, .tr-empty').each(function () {
                self.convertTextNode(this);
            });

            // 9. Text inputs (not the date picker itself, which is handled by jalali-datepicker.js)
            //    فقط روی input هایی که کلاس typecho-date ندارند کار می‌کنیم تا با datepicker
            //    تداخل نداشته باشد.
            $('input[type="text"]').each(function () {
                var $input = $(this);
                if ($input.hasClass('typecho-date') || $input.hasClass('hasDatepicker')) {
                    return;
                }
                if ($input.data('jalali-converted')) {
                    return;
                }
                var val = $input.val();
                if (!val || val.trim().length < 4) {
                    return;
                }
                var converted = self.tryConvertDateString(val.trim());
                if (converted && converted !== val.trim()) {
                    $input.val(converted);
                    $input.data('jalali-converted', true);
                }
            });
        },

        /**
         * Convert text node content of an element
         */
        convertTextNode: function (element) {
            var self = this;
            var $el = $(element);
            if ($el.hasClass('jalali-converted-date') || $el.data('jalali-converted')) {
                return;
            }

            // Only convert direct text content (no nested elements)
            var textNodes = $el.contents().filter(function () {
                return this.nodeType === 3;
            });

            var text = textNodes.text();
            if (!text || text.trim().length < 2) return;

            var trimmed = text.trim();
            var converted = self.tryConvertDateString(trimmed);
            if (converted && converted !== trimmed) {
                // Replace just the text part inside each text node
                textNodes.each(function () {
                    if (this.nodeValue && this.nodeValue.indexOf(trimmed) !== -1) {
                        this.nodeValue = this.nodeValue.replace(trimmed, converted);
                    } else if (this.nodeValue && this.nodeValue.trim() === trimmed) {
                        this.nodeValue = this.nodeValue.replace(trimmed, converted);
                    }
                });
                $el.addClass('jalali-converted-date');
                $el.data('jalali-converted', true);
            }
        },

        /**
         * Try to convert a date string to Jalali.
         * Supports:
         *  - Gregorian: "2024-03-15 14:30", "2024/03/15", "March 15, 2024", "15 Mar 2024"
         *  - Chinese relative (TypeRenew Zone::word with zh_CN):
         *    "刚刚", "3秒前", "5分钟前", "2小时前", "昨天 14:30",
         *    "3天前", "3月15日", "2024年03月15日"
         *  - Persian relative (TypeRenew Zone::word with fa_IR, NEW in 1.6.1):
         *    "همین حالا", "۳ ثانیه پیش", "۵ دقیقه پیش", "۲ ساعت پیش",
         *    "دیروز ۱۴:۳۰", "۳ روز پیش"
         *  - Persian absolute Gregorian (TypeRenew Zone::word with fa_IR, NEW in 1.6.1):
         *    "2024/03/15" (Y/m/d), "15/03/2024" (d/m/Y), "15/3" (j/n),
         *    "03/2024" (m/Y), "سال 2024" (سال %d)
         */
        tryConvertDateString: function (str) {
            var self = this;
            if (!str) return null;
            var original = str;
            // کار با کپی نرمالایز شده برای تشخیص الگوهای فارسی
            var normalized = self.normalizeDigits(str).trim();

            // ----------------------------------------------------------------
            // Pattern 1: "2024-03-15 14:30" or "2024-03-15" or with seconds
            // Also handles Persian-digit variant: "۱۴۰۲-۱۲-۲۵"
            // ----------------------------------------------------------------
            var match = normalized.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T](\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?$/);
            if (match) {
                var y = parseInt(match[1], 10);
                var m = parseInt(match[2], 10);
                var d = parseInt(match[3], 10);
                // Disambiguate: if year is Gregorian (>= 1700), treat as Gregorian
                // If year is Jalali (1300-1600 range), it's already Persian-format Gregorian being misread as Jalali
                // Persian-digit format '۱۴۰۲-۱۲-۲۵' is the Jalali format, not Gregorian
                // Gregorian Y-m-d always has year >= 1970 (Unix epoch) for blog content
                if (y >= 1700) {
                    return self.formatJalali(
                        y,
                        m,
                        d,
                        match[4] ? parseInt(match[4], 10) : null,
                        match[5] ? parseInt(match[5], 10) : null
                    );
                }
                // Year < 1700 - this is a Jalali date, just normalize digits
                // (likely already in Persian format, but ensure digits are Persian)
                return self.toFa(y + '-' + self.pad(m) + '-' + self.pad(d) +
                    (match[4] ? ' ' + self.pad(parseInt(match[4], 10)) + ':' + self.pad(parseInt(match[5], 10)) : ''));
            }

            // ----------------------------------------------------------------
            // Pattern 1b: m/d or d/m format (no year)
            //
            // === مهم: تشخیص هوشمند تاریخ شمسی در برابر میلادی ===
            // این الگو می‌تواند از دو منبع باشد:
            //
            // 1. خروجی PHP-side (JalaliDate::format('m/d')) که همیشه اعداد شمسی
            //    با "صفر پیشوند" تولید می‌کند (مثلاً "07/03" برای ۳ مهر).
            //    این تاریخ از قبل شمسی است و نباید دوباره تبدیل شود.
            //
            // 2. خروجی Zone::word() با fa_IR translation که فرمت "j/n" را
            //    بدون صفر پیشوند تولید می‌کند (مثلاً "3/7" برای ۳ ژوئیه).
            //    این تاریخ میلادی است و باید به شمسی تبدیل شود.
            //
            // راه تشخیص: بررسی "صفر پیشوند"
            // - اگر یکی از اجزا صفر پیشوند داشته باشد (مثل "07" یا "03")
            //   → خروجی PHP-side است → تاریخ شمسی → فقط قالب‌بندی به «D نام‌ماه»
            // - اگر هیچ صفر پیشوندی نباشد (مثل "3/7" یا "15/3")
            //   → خروجی fa_IR است → تاریخ میلادی → تبدیل به شمسی
            // ----------------------------------------------------------------
            match = normalized.match(/^(\d{1,2})\/(\d{1,2})$/);
            if (match) {
                var p1str = match[1];
                var p2str = match[2];
                var p1 = parseInt(p1str, 10);
                var p2 = parseInt(p2str, 10);

                // تشخیص صفر پیشوند (مثلاً "07" دارد، "12" ندارد)
                var p1HasLeadingZero = p1str.length === 2 && p1str.charAt(0) === '0';
                var p2HasLeadingZero = p2str.length === 2 && p2str.charAt(0) === '0';

                if (p1HasLeadingZero || p2HasLeadingZero) {
                    // حالت ۱: خروجی PHP-side - تاریخ شمسی با فرمت MM/DD
                    // فقط قالب‌بندی به «D نام‌ماه» (بدون تبدیل اضافی)
                    // مثلاً "07/03" → m=7 (مهر)، d=3 → «۳ مهر»
                    // مثلاً "04/12" → m=4 (تیر)، d=12 → «۱۲ تیر»
                    if (p1 >= 1 && p1 <= 12 && p2 >= 1 && p2 <= 31) {
                        return self.faMaybe(self.faNum(p2) + ' ' + self.monthNamesFa[p1 - 1]);
                    }
                    // fallback: اگر m/d نامعتبر بود، d/m را امتحان کن
                    if (p1 >= 1 && p1 <= 31 && p2 >= 1 && p2 <= 12) {
                        return self.faMaybe(self.faNum(p1) + ' ' + self.monthNamesFa[p2 - 1]);
                    }
                } else {
                    // حالت ۲: خروجی fa_IR - تاریخ میلادی با فرمت j/n (روز/ماه)
                    // تبدیل میلادی → شمسی
                    // مثلاً "3/7" → day=3، month=7 (ژوئیه) → تبدیل → «۱۲ تیر»
                    // مثلاً "15/3" → day=15، month=3 (مارس) → تبدیل → «۲۵ اسفند»
                    var day = p1;
                    var month = p2;
                    if (day >= 1 && day <= 31 && month >= 1 && month <= 12) {
                        var now = new Date();
                        var gy = now.getFullYear();
                        var j = self.toJalali(gy, month, day);
                        return self.faMaybe(self.faNum(j[2]) + ' ' + self.monthNamesFa[j[1] - 1]);
                    }
                }
            }

            // ----------------------------------------------------------------
            // Pattern 2: "2024/03/15" - YYYY/MM/DD format (after fa_IR translation)
            // This is the main format from "Y年m月d日" → "Y/m/d"
            // ----------------------------------------------------------------
            match = normalized.match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})(?:\s+(\d{1,2}):(\d{1,2}))?$/);
            if (match) {
                var y = parseInt(match[1], 10);
                var m = parseInt(match[2], 10);
                var d = parseInt(match[3], 10);
                if (y >= 1700) {
                    // Gregorian
                    return self.formatJalali(y, m, d,
                        match[4] ? parseInt(match[4], 10) : null,
                        match[5] ? parseInt(match[5], 10) : null);
                }
                // Year < 1700 - likely already Jalali, just normalize digits
                return self.toFa(y + '/' + self.pad(m) + '/' + self.pad(d) +
                    (match[4] ? ' ' + self.pad(parseInt(match[4], 10)) + ':' + self.pad(parseInt(match[5], 10)) : ''));
            }

            // ----------------------------------------------------------------
            // Pattern 3: "15/03/2024" - DD/MM/YYYY format (from "%d年%d月%d日" → "%3$d/%2$d/%1$d")
            // This is the day-month-year format used by archive title
            // ----------------------------------------------------------------
            match = normalized.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:\s+(\d{1,2}):(\d{1,2}))?$/);
            if (match) {
                // First check if it's a valid DD/MM/YYYY (day first)
                var day = parseInt(match[1], 10);
                var month = parseInt(match[2], 10);
                var year = parseInt(match[3], 10);
                // Day 1-31 and month 1-12 with day-first interpretation
                if (day >= 1 && day <= 31 && month >= 1 && month <= 12) {
                    return self.formatJalali(
                        year,
                        month,
                        day,
                        match[4] ? parseInt(match[4], 10) : null,
                        match[5] ? parseInt(match[5], 10) : null
                    );
                }
            }

            // ----------------------------------------------------------------
            // Pattern 4: "March 15, 2024" or "Mar 15, 2024"
            // ----------------------------------------------------------------
            match = str.match(/^([A-Za-z]+)\s+(\d{1,2}),?\s+(\d{4})(?:\s+(\d{1,2}):(\d{1,2}))?$/);
            if (match) {
                var month = self.gregorianMonths[match[1].toLowerCase()];
                if (month) {
                    return self.formatJalali(
                        parseInt(match[3], 10),
                        month,
                        parseInt(match[2], 10),
                        match[4] ? parseInt(match[4], 10) : null,
                        match[5] ? parseInt(match[5], 10) : null
                    );
                }
            }

            // ----------------------------------------------------------------
            // Pattern 5: "15 March 2024" or "15 Mar 2024"
            // ----------------------------------------------------------------
            match = str.match(/^(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})(?:\s+(\d{1,2}):(\d{1,2}))?$/);
            if (match) {
                var month2 = self.gregorianMonths[match[2].toLowerCase()];
                if (month2) {
                    return self.formatJalali(
                        parseInt(match[3], 10),
                        month2,
                        parseInt(match[1], 10),
                        match[4] ? parseInt(match[4], 10) : null,
                        match[5] ? parseInt(match[5], 10) : null
                    );
                }
            }

            // ----------------------------------------------------------------
            // Pattern 6: TypeRenew Zone::word() - Chinese relative time (zh_CN)
            //   "刚刚"          -> لحظاتی پیش
            //   "N秒前"         -> N ثانیه پیش
            //   "N分钟前"       -> N دقیقه پیش
            //   "N小时前"       -> N ساعت پیش
            //   "昨天 HH:MM"    -> دیروز HH:MM
            //   "N天前"         -> N روز پیش
            //   "N月J日"        -> J نام‌ماه (همان‌سال)
            //   "Y年m月d日"     -> d نام‌ماه Y
            // ----------------------------------------------------------------

            // 6a: 刚刚 (just now)
            if (str === '刚刚' || str === '剛剛') {
                return self.faMaybe('لحظاتی پیش');
            }

            // 6b: N秒前 (N seconds ago)
            match = str.match(/^(\d+)秒前$/);
            if (match) {
                var secs = parseInt(match[1], 10);
                if (secs === 1) {
                    return self.faMaybe('یک ثانیه پیش');
                }
                return self.faMaybe(self.faNum(secs) + ' ثانیه پیش');
            }

            // 6c: N分钟前 (N minutes ago)
            match = str.match(/^(\d+)分钟前$/);
            if (match) {
                var mins = parseInt(match[1], 10);
                if (mins === 1) {
                    return self.faMaybe('یک دقیقه پیش');
                }
                return self.faMaybe(self.faNum(mins) + ' دقیقه پیش');
            }

            // 6d: N小时前 (N hours ago)
            match = str.match(/^(\d+)小时前$/);
            if (match) {
                var hours = parseInt(match[1], 10);
                if (hours === 1) {
                    return self.faMaybe('یک ساعت پیش');
                }
                return self.faMaybe(self.faNum(hours) + ' ساعت پیش');
            }

            // 6e: 昨天 HH:MM (yesterday at time)
            match = str.match(/^昨天\s+(\d{1,2}):(\d{2})$/);
            if (match) {
                var hh = self.pad(parseInt(match[1], 10));
                var mm = self.pad(parseInt(match[2], 10));
                return self.faMaybe('دیروز ' + hh + ':' + mm);
            }

            // 6f: N天前 (N days ago)
            match = str.match(/^(\d+)天前$/);
            if (match) {
                var days = parseInt(match[1], 10);
                if (days === 1) {
                    return self.faMaybe('دیروز');
                }
                return self.faMaybe(self.faNum(days) + ' روز پیش');
            }

            // 6g: N月J日 (same year, Chinese)
            match = str.match(/^(\d{1,2})月(\d{1,2})日$/);
            if (match) {
                var gm = parseInt(match[1], 10);
                var gd = parseInt(match[2], 10);
                var now = new Date();
                var gy = now.getFullYear();
                var j = self.toJalali(gy, gm, gd);
                return self.faMaybe(j[2] + ' ' + self.monthNamesFa[j[1] - 1]);
            }

            // 6h: Y年m月d日 (full Chinese date)
            match = str.match(/^(\d{4})年(\d{1,2})月(\d{1,2})日$/);
            if (match) {
                var cgy = parseInt(match[1], 10);
                var cgm = parseInt(match[2], 10);
                var cgd = parseInt(match[3], 10);
                var cj = self.toJalali(cgy, cgm, cgd);
                return self.faMaybe(cj[2] + ' ' + self.monthNamesFa[cj[1] - 1] + ' ' + cj[0]);
            }

            // ----------------------------------------------------------------
            // Pattern 7: Persian relative time (fa_IR translations from TypeRenew 1.6.1)
            //   "همین حالا"     -> لحظاتی پیش
            //   "N ثانیه پیش"   -> N ثانیه پیش (already Jalali-formatted, just normalize digits)
            //   "N دقیقه پیش"   -> N دقیقه پیش
            //   "N ساعت پیش"    -> N ساعت پیش
            //   "دیروز HH:MM"   -> دیروز HH:MM (already formatted)
            //   "N روز پیش"     -> N روز پیش
            //   Note: These are RELATIVE times, so they're already correct
            //   We just need to make sure digits are Persian (they already are).
            //   We pass these through unchanged.
            // ----------------------------------------------------------------

            // 7a: همین حالا (just now) - fa_IR translation of "刚刚"
            if (normalized === 'همین حالا' || normalized === 'همين حالا' || str === 'همین حالا') {
                return self.faMaybe('لحظاتی پیش');
            }

            // 7b: N ثانیه پیش (N seconds ago) - fa_IR translation of "N秒前"
            // Note: N can be Persian or English digits
            match = normalized.match(/^(\d+)\s*ثانیه\s*پیش$/);
            if (match) {
                var secs = parseInt(match[1], 10);
                if (secs === 1) {
                    return self.faMaybe('یک ثانیه پیش');
                }
                return self.faMaybe(self.faNum(secs) + ' ثانیه پیش');
            }

            // 7c: N دقیقه پیش (N minutes ago) - fa_IR translation of "N分钟前"
            match = normalized.match(/^(\d+)\s*دقیقه\s*پیش$/);
            if (match) {
                var mins = parseInt(match[1], 10);
                if (mins === 1) {
                    return self.faMaybe('یک دقیقه پیش');
                }
                return self.faMaybe(self.faNum(mins) + ' دقیقه پیش');
            }

            // 7d: N ساعت پیش (N hours ago) - fa_IR translation of "N小时前"
            match = normalized.match(/^(\d+)\s*ساعت\s*پیش$/);
            if (match) {
                var hours = parseInt(match[1], 10);
                if (hours === 1) {
                    return self.faMaybe('یک ساعت پیش');
                }
                return self.faMaybe(self.faNum(hours) + ' ساعت پیش');
            }

            // 7e: دیروز HH:MM (yesterday at time) - fa_IR translation of "昨天 HH:MM"
            match = normalized.match(/^دیروز\s+(\d{1,2}):(\d{2})$/);
            if (match) {
                var hh = self.pad(parseInt(match[1], 10));
                var mm = self.pad(parseInt(match[2], 10));
                return self.faMaybe('دیروز ' + hh + ':' + mm);
            }

            // 7f: N روز پیش (N days ago) - fa_IR translation of "N天前"
            match = normalized.match(/^(\d+)\s*روز\s*پیش$/);
            if (match) {
                var days = parseInt(match[1], 10);
                if (days === 1) {
                    return self.faMaybe('دیروز');
                }
                return self.faMaybe(self.faNum(days) + ' روز پیش');
            }

            // 7g: (removed - now handled by Pattern 1b above which tries m/d then d/m)

            // 7h: "سال YYYY" - fa_IR translation of "%d年" (year only)
            match = normalized.match(/^سال\s*(\d{4})$/);
            if (match) {
                var gy = parseInt(match[1], 10);
                var j = self.toJalali(gy, 1, 1);
                return self.faMaybe('سال ' + j[0]);
            }

            // 7i: MM/YYYY format - fa_IR translation of "%d年%d月" with reversed order
            // This is "%2$d/%1$d" which produces "MM/YYYY"
            match = normalized.match(/^(\d{1,2})\/(\d{4})$/);
            if (match) {
                var gm = parseInt(match[1], 10);
                var gy = parseInt(match[2], 10);
                if (gm >= 1 && gm <= 12) {
                    var j = self.toJalali(gy, gm, 1);
                    return self.faMaybe(self.monthNamesFa[j[1] - 1] + ' ' + j[0]);
                }
            }

            // 7j: Chinese year/month "YYYY年MM月" (zh_CN format, NEW for completeness)
            match = str.match(/^(\d{4})年(\d{1,2})月$/);
            if (match) {
                var gy = parseInt(match[1], 10);
                var gm = parseInt(match[2], 10);
                var j = self.toJalali(gy, gm, 1);
                return self.faMaybe(self.monthNamesFa[j[1] - 1] + ' ' + j[0]);
            }

            // 7k: Chinese year only "YYYY年" (zh_CN format, NEW for completeness)
            match = str.match(/^(\d{4})年$/);
            if (match) {
                var gy = parseInt(match[1], 10);
                var j = self.toJalali(gy, 1, 1);
                return self.faMaybe('سال ' + j[0]);
            }

            // 7l: (removed - duplicate of 7j above)

            // ----------------------------------------------------------------
            // Pattern 8: Embedded dates inside strings like
            //   "保存于 3小时前"            -> "保存于 ۳ ساعت پیش"
            //   "最后更新于 2024年03月15日" -> "最后更新于 ۱۵ اسفند ۱۴۰۲"
            //   "最后登录 昨天 14:30"        -> "最后登录 دیروز ۱۴:۳۰"
            //   "当前内容将于 2024-03-15 14:30 定时发布"
            //   "ذخیره‌شده در ۲ ساعت پیش"   (fa_IR translated)
            //   "آخرین به‌روزرسانی در 2024/03/15"   (fa_IR translated)
            //   "آخرین ورود دیروز 14:30"   (fa_IR translated)
            //
            // This handles cases where dates are embedded in localized
            // sentences. We find the date substring and replace just it.
            // ----------------------------------------------------------------
            var embedded = self.convertEmbeddedDates(str);
            if (embedded !== null && embedded !== original) {
                return embedded;
            }

            return null;
        },

        /**
         * Find and convert date substrings embedded in larger strings.
         * Returns the converted full string, or null if no date was found.
         */
        convertEmbeddedDates: function (str) {
            var self = this;
            var modified = str;
            var changed = false;
            var normalized = self.normalizeDigits(str);

            // Helper: replace first occurrence of a regex match with replacement
            function tryReplace(regex, replacer) {
                var m = modified.match(regex);
                if (m) {
                    var replacement = replacer(m);
                    if (replacement !== null && replacement !== m[0]) {
                        modified = modified.replace(m[0], replacement);
                        changed = true;
                        return true;
                    }
                }
                return false;
            }

            // Helper: works on normalized string but replaces in original
            function tryReplaceNormalized(regex, replacer) {
                var m = normalized.match(regex);
                if (m) {
                    var replacement = replacer(m);
                    if (replacement !== null) {
                        // Find the matching substring in the original (might have Persian digits)
                        var originalSubstr = self.findOriginalSubstring(normalized, m.index, m[0].length, modified);
                        if (originalSubstr !== null && originalSubstr !== replacement) {
                            modified = modified.replace(originalSubstr, replacement);
                            changed = true;
                            return true;
                        }
                    }
                }
                return false;
            }

            // ISO-like: 2024-03-15 14:30  (only when embedded, not standalone)
            // Note: Skip if year is < 1700 (likely already Jalali format)
            tryReplace(/(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T](\d{1,2}):(\d{1,2}))?/, function (m) {
                var y = parseInt(m[1], 10);
                if (y < 1700) {
                    return null;  // skip - likely already Jalali
                }
                return self.formatJalali(
                    y,
                    parseInt(m[2], 10),
                    parseInt(m[3], 10),
                    m[4] ? parseInt(m[4], 10) : null,
                    m[5] ? parseInt(m[5], 10) : null
                );
            });

            // YYYY/MM/DD format (from "Y年m月d日" → "Y/m/d" in fa_IR)
            tryReplaceNormalized(/(\d{4})\/(\d{1,2})\/(\d{1,2})(?:\s+(\d{1,2}):(\d{1,2}))?/, function (m) {
                var y = parseInt(m[1], 10);
                if (y < 1700) {
                    return null;  // skip - likely already Jalali
                }
                return self.formatJalali(
                    y,
                    parseInt(m[2], 10),
                    parseInt(m[3], 10),
                    m[4] ? parseInt(m[4], 10) : null,
                    m[5] ? parseInt(m[5], 10) : null
                );
            });

            // DD/MM/YYYY format (from "%d年%d月%d日" → "%3$d/%2$d/%1$d" in fa_IR)
            tryReplaceNormalized(/(\d{1,2})\/(\d{1,2})\/(\d{4})/, function (m) {
                var day = parseInt(m[1], 10);
                var month = parseInt(m[2], 10);
                var year = parseInt(m[3], 10);
                if (year < 1700) {
                    return null;  // skip - likely already Jalali
                }
                if (day >= 1 && day <= 31 && month >= 1 && month <= 12) {
                    return self.formatJalali(year, month, day, null, null);
                }
                return null;
            });

            // Chinese full date: Y年m月d日 (zh_CN)
            tryReplace(/(\d{4})年(\d{1,2})月(\d{1,2})日/, function (m) {
                var gy = parseInt(m[1], 10);
                var gm = parseInt(m[2], 10);
                var gd = parseInt(m[3], 10);
                var j = self.toJalali(gy, gm, gd);
                return j[2] + ' ' + self.monthNamesFa[j[1] - 1] + ' ' + j[0];
            });

            // Chinese same-year date: N月J日 (zh_CN)
            tryReplace(/(\d{1,2})月(\d{1,2})日/, function (m) {
                var gm = parseInt(m[1], 10);
                var gd = parseInt(m[2], 10);
                var now = new Date();
                var gy = now.getFullYear();
                var j = self.toJalali(gy, gm, gd);
                return j[2] + ' ' + self.monthNamesFa[j[1] - 1];
            });

            // Chinese relative: N小时前 / N分钟前 / N秒前 / N天前
            tryReplace(/(\d+)小时前/, function (m) {
                var h = parseInt(m[1], 10);
                return h === 1 ? self.faMaybe('یک ساعت پیش') : self.faMaybe(self.faNum(h) + ' ساعت پیش');
            });
            tryReplace(/(\d+)分钟前/, function (m) {
                var mi = parseInt(m[1], 10);
                return mi === 1 ? self.faMaybe('یک دقیقه پیش') : self.faMaybe(self.faNum(mi) + ' دقیقه پیش');
            });
            tryReplace(/(\d+)秒前/, function (m) {
                var s = parseInt(m[1], 10);
                return s === 1 ? self.faMaybe('یک ثانیه پیش') : self.faMaybe(self.faNum(s) + ' ثانیه پیش');
            });
            tryReplace(/(\d+)天前/, function (m) {
                var d = parseInt(m[1], 10);
                return d === 1 ? self.faMaybe('دیروز') : self.faMaybe(self.faNum(d) + ' روز پیش');
            });
            tryReplace(/昨天\s+(\d{1,2}):(\d{2})/, function (m) {
                return self.faMaybe('دیروز ' + self.pad(parseInt(m[1], 10)) + ':' + self.pad(parseInt(m[2], 10)));
            });
            tryReplace(/刚刚/, function () {
                return self.faMaybe('لحظاتی پیش');
            });

            // Persian relative (fa_IR translations): N ساعت/دقیقه/ثانیه/روز پیش
            // Note: these are already in Persian, just make sure digits are Persian
            tryReplaceNormalized(/(\d+)\s*ساعت\s*پیش/, function (m) {
                var h = parseInt(m[1], 10);
                return h === 1 ? self.faMaybe('یک ساعت پیش') : self.faMaybe(self.faNum(h) + ' ساعت پیش');
            });
            tryReplaceNormalized(/(\d+)\s*دقیقه\s*پیش/, function (m) {
                var mi = parseInt(m[1], 10);
                return mi === 1 ? self.faMaybe('یک دقیقه پیش') : self.faMaybe(self.faNum(mi) + ' دقیقه پیش');
            });
            tryReplaceNormalized(/(\d+)\s*ثانیه\s*پیش/, function (m) {
                var s = parseInt(m[1], 10);
                return s === 1 ? self.faMaybe('یک ثانیه پیش') : self.faMaybe(self.faNum(s) + ' ثانیه پیش');
            });
            tryReplaceNormalized(/(\d+)\s*روز\s*پیش/, function (m) {
                var d = parseInt(m[1], 10);
                return d === 1 ? self.faMaybe('دیروز') : self.faMaybe(self.faNum(d) + ' روز پیش');
            });
            tryReplaceNormalized(/دیروز\s+(\d{1,2}):(\d{2})/, function (m) {
                return self.faMaybe('دیروز ' + self.pad(parseInt(m[1], 10)) + ':' + self.pad(parseInt(m[2], 10)));
            });
            tryReplaceNormalized(/همین\s*حالا/, function () {
                return self.faMaybe('لحظاتی پیش');
            });

            return changed ? modified : null;
        },

        /**
         * Find the original (un-normalized) substring corresponding to a normalized match.
         * Useful for converting Persian-digit dates embedded in Persian text.
         */
        findOriginalSubstring: function (normalized, index, length, original) {
            // Simple approach: map character by character
            // Since normalizeDigits is 1:1 char mapping, we can walk character by character
            var normIdx = 0;
            var origIdx = 0;
            var origLen = original.length;
            var startOrigIdx = -1;
            var endOrigIdx = -1;

            while (origIdx <= origLen && normIdx <= index + length) {
                if (normIdx === index) {
                    startOrigIdx = origIdx;
                }
                if (normIdx === index + length) {
                    endOrigIdx = origIdx;
                    break;
                }
                if (origIdx >= origLen) {
                    break;
                }
                // Move one char in original
                var origChar = original.charAt(origIdx);
                origIdx++;
                // Check if it normalizes to a single char
                if (this.faToEnDigitsMap.hasOwnProperty(origChar)) {
                    normIdx++;
                } else {
                    normIdx++;
                }
            }
            if (startOrigIdx >= 0 && endOrigIdx >= 0) {
                return original.substring(startOrigIdx, endOrigIdx);
            }
            return null;
        },

        /**
         * Format a Jalali date string
         */
        formatJalali: function (gy, gm, gd, hour, minute) {
            var self = this;
            var j = self.toJalali(gy, gm, gd);
            var result = '';

            if (hour !== null && minute !== null) {
                result = j[0] + '/' + self.pad(j[1]) + '/' + self.pad(j[2]) +
                         ' ' + self.pad(hour) + ':' + self.pad(minute);
            } else {
                result = j[2] + ' ' + self.monthNamesFa[j[1] - 1] + ' ' + j[0];
            }

            return self.toFa(result);
        },

        /**
         * Pad number with leading zero
         */
        pad: function (n) {
            return (n < 10 ? '0' : '') + n;
        },

        /**
         * Convert a number to Persian digits
         */
        faNum: function (n) {
            var self = this;
            return self.toFa(String(n));
        },

        /**
         * Apply Persian digit conversion (always enabled)
         */
        faMaybe: function (str) {
            var self = this;
            return self.toFa(str);
        },

        /**
         * Convert digits to Persian
         */
        toFa: function (str) {
            var self = this;
            str = String(str);
            for (var i = 0; i < 10; i++) {
                str = str.replace(new RegExp(String(i), 'g'), self.faDigits[i]);
            }
            return str;
        },

        /**
         * Verified Jalali leap years table (from time.ir)
         */
        leapYearsSet: {
            1288:1, 1292:1, 1296:1, 1300:1, 1304:1, 1309:1, 1313:1, 1317:1,
            1321:1, 1325:1, 1329:1, 1333:1, 1337:1, 1342:1, 1346:1, 1350:1,
            1354:1, 1358:1, 1362:1, 1366:1, 1370:1, 1375:1, 1379:1, 1383:1,
            1387:1, 1391:1, 1395:1, 1399:1, 1403:1, 1407:1, 1411:1, 1415:1,
            1420:1, 1424:1, 1428:1, 1432:1, 1436:1, 1440:1, 1445:1, 1449:1,
            1453:1, 1457:1, 1461:1, 1465:1, 1469:1, 1474:1, 1478:1, 1482:1,
            1486:1, 1490:1, 1494:1, 1498:1, 1503:1, 1507:1, 1511:1, 1515:1,
            1519:1, 1523:1, 1527:1, 1531:1, 1536:1, 1540:1, 1544:1, 1548:1,
            1552:1, 1556:1, 1560:1, 1564:1, 1569:1, 1573:1, 1577:1, 1581:1,
            1585:1, 1589:1, 1593:1, 1597:1, 1602:1, 1606:1, 1610:1, 1614:1
        },

        isLeap: function (jy) {
            return !!this.leapYearsSet[jy];
        },

        daysInMonth: function (jy, jm) {
            if (jm <= 6) return 31;
            if (jm <= 11) return 30;
            return this.isLeap(jy) ? 30 : 29;
        },

        /**
         * Convert Gregorian to Jalali using day-count from Unix epoch
         * Reference: 1970-01-01 G = 1348-10-11 J
         */
        toJalali: function (gy, gm, gd) {
            var date = new Date(Date.UTC(gy, gm - 1, gd));
            var epoch = new Date(Date.UTC(1970, 0, 1));
            var daysSinceEpoch = Math.round((date - epoch) / 86400000);

            var jy = 1348, jm = 10, jd = 11;
            var remaining = daysSinceEpoch;

            if (remaining > 0) {
                while (remaining > 0) {
                    var dim = this.daysInMonth(jy, jm);
                    if (jd + remaining <= dim) {
                        jd += remaining;
                        remaining = 0;
                    } else {
                        remaining -= (dim - jd + 1);
                        jd = 1;
                        if (jm < 12) jm++; else { jm = 1; jy++; }
                    }
                }
            } else if (remaining < 0) {
                while (remaining < 0) {
                    if (jd + remaining >= 1) {
                        jd += remaining;
                        remaining = 0;
                    } else {
                        remaining += jd;
                        if (jm > 1) jm--; else { jm = 12; jy--; }
                        jd = this.daysInMonth(jy, jm);
                    }
                }
            }
            return [jy, jm, jd];
        }
    };

    $(function () {
        AdminConverter.init();
    });

})(jQuery);
