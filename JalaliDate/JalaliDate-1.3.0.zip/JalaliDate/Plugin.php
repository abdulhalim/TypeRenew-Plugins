<?php
namespace TypechoPlugin\JalaliDate;

use Typecho\Plugin\PluginInterface;
use Typecho\Plugin as TypechoPlugin;
use Typecho\Widget\Helper\Form;
use Typecho\Widget\Helper\Form\Element\Radio;
use Typecho\Widget\Helper\Form\Element\Text;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

// بارگذاری فایل کمکی JDate (بدون وابستگی به Typecho\Date)
require_once __DIR__ . '/lib/JDate.php';

/**
 * 
 * پلاگین تبدیل تاریخ میلادی به شمسی (تقویم جلالی)
 * @package JalaliDate
 * @author  پوردریایی
 * @link    https://pourdaryaei.ir
 * @since   1.6.0
 * @version 1.3.0
 *
 * 
 */
class Plugin implements PluginInterface
{
    /**
     * نسخه پلاگین
     */
    const VERSION = '1.3.0';

    /**
     * فعال‌سازی پلاگین
     */
    public static function activate()
    {
        // تبدیل تاریخ نمایش پست‌ها و صفحات
        TypechoPlugin::factory('Widget\\Base\\Contents')->filter = [__CLASS__, 'contentsFilter'];

        // تبدیل تاریخ نظرات
        TypechoPlugin::factory('Widget\\Base\\Comments')->filter = [__CLASS__, 'commentsFilter'];

        // تبدیل تاریخ کاربران
        TypechoPlugin::factory('Widget\\Base\\Users')->filter = [__CLASS__, 'usersFilter'];

        // تبدیل عنوان آرشیو تاریخ
        TypechoPlugin::factory('Widget\\Archive')->dateHandle = [__CLASS__, 'archiveDateHandle'];

        // تزریق JS و CSS برای Date Picker شمسی در پنل مدیریت
        TypechoPlugin::factory('admin/write-js.php')->write = [__CLASS__, 'injectDatePicker'];
        TypechoPlugin::factory('admin/header.php')->header = [__CLASS__, 'injectAdminAssets'];

        // تزریق JS برای تبدیل تاریخ‌های نمایشی در پنل مدیریت
        TypechoPlugin::factory('admin/footer.php')->end = [__CLASS__, 'injectFooterScript'];

        // تزریق فیلد نمایش شمسی در کنار Date Picker
        TypechoPlugin::factory('admin/write-post.php')->option = [__CLASS__, 'adminPostOption'];
        TypechoPlugin::factory('admin/write-page.php')->option = [__CLASS__, 'adminPostOption'];

        return _t('پلاگین تاریخ شمسی فعال شد. تاریخ‌های بخش مدیریت و کاربری به تقویم جلالی تبدیل می‌شوند. (نسخه 1.3.1 - سازگار با TypeRenew 1.6.1)');
    }

    /**
     * غیرفعال‌سازی پلاگین
     */
    public static function deactivate()
    {
        return _t('پلاگین تاریخ شمسی غیرفعال شد.');
    }

    /**
     * پنل تنظیمات پلاگین
     */
    public static function config(Form $form)
    {
        /*
         * توجه: تنظیمات «نوع اعداد» و «زبان نام ماه و روز» حذف شدند.
         * اعداد و نام ماه‌ها/روزها همیشه به‌صورت فارسی نمایش داده می‌شوند تا از
         * به‌هم‌ریختگی تاریخ در حالت لاتین (نمایش اشتباه و شکست انتشار پست)
         * جلوگیری شود.
         */

        $dateFormat = new Text(
            'postDateFormat',
            null,
            'j F Y',
            _t('فرمت تاریخ پست‌ها'),
            _t('فرمت پیش‌فرض تاریخ پست‌ها. کاراکترها: Y=سال، m=ماه، d=روز، F=نام ماه، l=نام روز، H=ساعت، i=دقیقه')
        );
        $form->addInput($dateFormat);

        $commentFormat = new Text(
            'commentDateFormat',
            null,
            'j F Y، H:i',
            _t('فرمت تاریخ نظرات'),
            _t('فرمت پیش‌فرض تاریخ نظرات')
        );
        $form->addInput($commentFormat);

        $adminConversion = new Radio(
            'adminConversion',
            ['1' => _t('بله، تمام تاریخ‌های پنل مدیریت'), '0' => _t('فقط Date Picker و فرم انتشار')],
            '1',
            _t('تبدیل تاریخ پنل مدیریت'),
            _t('آیا تمام تاریخ‌های نمایشی پنل مدیریت به شمسی تبدیل شوند؟')
        );
        $form->addInput($adminConversion);

        $convertPicker = new Radio(
            'convertPicker',
            ['1' => _t('بله، Date Picker شمسی جایگزین شود'), '0' => _t('خیر، Date Picker میلادی بماند')],
            '1',
            _t('تبدیل Date Picker مدیریت'),
            _t('آیا Date Picker فرم انتشار پست با تقویم شمسی جایگزین شود؟')
        );
        $form->addInput($convertPicker);
    }

    /**
     * پنل تنظیمات شخصی
     */
    public static function personalConfig(Form $form)
    {
        // بدون تنظیمات شخصی
    }

    /**
     * فیلتر محتوای پست - جایگزینی Date object با JalaliDate wrapper
     *
     * این متد به جای جایگزینی Date object (که نیازمند ارث‌بری است)،
     * از wrapper استفاده می‌کند که در زمان فراخوانی format() تبدیل را انجام می‌دهد.
     */
    public static function contentsFilter($value, $widget)
    {
        if (isset($value['created']) && $value['created'] > 0) {
            // Date object موجود را با یک wrapper شمسی جایگزین می‌کنیم
            $value['date'] = self::createJalaliDateWrapper($value['created']);
        }
        return $value;
    }

    /**
     * فیلتر نظرات
     */
    public static function commentsFilter($value, $widget)
    {
        if (isset($value['created']) && $value['created'] > 0) {
            $value['date'] = self::createJalaliDateWrapper($value['created']);
        }
        return $value;
    }

    /**
     * فیلتر کاربران
     */
    public static function usersFilter($value, $widget)
    {
        if (!isset($value['date']) || !method_exists($value['date'], 'format')) {
            $time = isset($value['logged']) ? $value['logged'] : (isset($value['created']) ? $value['created'] : null);
            if ($time && $time > 0) {
                $value['date'] = self::createJalaliDateWrapper($time);
            }
        }
        return $value;
    }

    /**
     * ایجاد یک JalaliDate wrapper - از Typecho\Date ارث می‌برد.
     *
     * نکته مهم: فایل lib/JalaliDate.php را فقط در زمان اجرا require می‌کنیم،
     * نه در زمان require Plugin.php. دلیل: این کلاس از Typecho\Date ارث می‌برد
     * و باید Typecho\Date قبل از آن بارگذاری شده باشد. در زمان فعال‌سازی پلاگین
     * توسط Typecho، Typecho\Date قبلاً بارگذاری شده است، اما در زمان require
     * اولیه Plugin.php ممکن است هنوز بارگذاری نشده باشد.
     */
    private static function createJalaliDateWrapper($timestamp)
    {
        // Typecho\Date باید بارگذاری شده باشد
        if (!class_exists('\Typecho\Date')) {
            // در شرایط عادی نباید اینجا برسیم
            return new \stdClass();
        }

        // اطمینان از اینکه timestamp یک عدد صحیح است
        if ($timestamp === null || $timestamp === '' || $timestamp === 0) {
            $timestamp = time();
        }
        $timestamp = (int) $timestamp;

        // بارگذاری lazy کلاس JalaliDate
        if (!class_exists(__NAMESPACE__ . '\\JalaliDate')) {
            require_once __DIR__ . '/lib/JalaliDate.php';
        }

        // فعال‌سازی جایگزینی فرمت پیش‌فرض انگلیسی هسته برای سایت‌های فارسی:
        // فقط همان رشتهٔ مشخص «F jS, Y \a\t h:i a» (پیش‌فرض نصب commentDateFormat)
        // با فرمت فارسی تنظیمات همین افزونه عوض می‌شود؛ فرمت سفارشی مدیر دست‌نخورده است.
        $lang = '';
        try {
            $lang = (string) \Widget\Options::alloc()->lang;
        } catch (\Throwable $e) {
            $lang = '';
        }
        if (str_starts_with($lang, 'fa')) {
            JalaliDate::$formatOverrides['F jS, Y \\a\\t h:i a'] = self::getOption('commentDateFormat', 'j F Y، ساعت H:i');
        }

        try {
            return new JalaliDate($timestamp);
        } catch (\Throwable $e) {
            // لایه محافظتی: هیچ‌گاه اجازه نمی‌دهیم مشکل نمایش تاریخ، صفحه
            // مدیریت یا سایت را کاملاً از دسترس خارج کند؛ به آبجکت اصلی هسته برمی‌گردیم.
            return new \Typecho\Date($timestamp);
        }
    }

    /**
     * تبدیل عنوان آرشیو تاریخ به شمسی
     */
    public static function archiveDateHandle($archive, $select)
    {
        $year = (int) $archive->request->filter('int')->get('year');
        $month = (int) $archive->request->filter('int')->get('month');
        $day = (int) $archive->request->filter('int')->get('day');

        if (!$year) {
            return;
        }

        if ($year && $month && $day) {
            list($jy, $jm, $jd) = JDate::toJalali($year, $month, $day);
            $title = self::faDigits($jd) . ' ' . JDate::$jMonthNamesFa[$jm - 1] . ' ' . self::faDigits($jy);
            $archive->setArchiveTitle($title);
        } elseif ($year && $month) {
            list($jy, $jm) = JDate::toJalali($year, $month, 1);
            $title = JDate::$jMonthNamesFa[$jm - 1] . ' ' . self::faDigits($jy);
            $archive->setArchiveTitle($title);
        } else {
            list($jy) = JDate::toJalali($year, 1, 1);
            $title = self::faDigits($jy);
            $archive->setArchiveTitle($title);
        }
    }

    /**
     * تزریق Date Picker شمسی در فرم انتشار پست/صفحه
     */
    public static function injectDatePicker()
    {
        $convertPicker = self::getOption('convertPicker', '1');
        if ($convertPicker !== '1') {
            return;
        }

        $pluginUrl = self::getPluginUrl();
        // پارامتر ?v= برای بی‌اعتبار کردن کشِ مرورگر پس از هر ارتقاء
        ?>
        <link rel="stylesheet" href="<?php echo $pluginUrl; ?>/assets/css/jalali-datepicker.css?v=<?php echo self::VERSION; ?>" />
        <script src="<?php echo $pluginUrl; ?>/assets/js/jalali-datepicker.js?v=<?php echo self::VERSION; ?>"></script>
        <script>
        (function($) {
            $(function() {
                if (typeof JalaliDatePlugin !== 'undefined') {
                    JalaliDatePlugin.init('#date');
                }
            });
        })(jQuery);
        </script>
        <?php
    }

    /**
     * تزریق CSS و JS کلی پنل مدیریت
     */
    public static function injectAdminAssets($header)
    {
        $adminConversion = self::getOption('adminConversion', '1');
        if ($adminConversion !== '1') {
            return $header;
        }

        $pluginUrl = self::getPluginUrl();
        $header .= '<link rel="stylesheet" href="' . $pluginUrl . '/assets/css/admin-fixes.css?v=' . self::VERSION . '" />' . "\n";
        return $header;
    }

    /**
     * تزریق اسکریپت پایین صفحه مدیریت
     */
    public static function injectFooterScript()
    {
        $adminConversion = self::getOption('adminConversion', '1');
        if ($adminConversion !== '1') {
            return;
        }

        $pluginUrl = self::getPluginUrl();
        ?>
        <script src="<?php echo $pluginUrl; ?>/assets/js/admin-converter.js?v=<?php echo self::VERSION; ?>"></script>
        <?php
    }

    /**
     * تزریق فیلد نمایش شمسی (+ هشدار تاریخ خراب‌شده)
     */
    public static function adminPostOption($post)
    {
        // تشخیص تاریخِ خراب‌شده توسط باگ نسخه‌های قبل: دوبار تبدیل شدن
        // تاریخ حدود ۶۲۱ سال به آن اضافه کرده است (میلادی ۲۳۰۰+)؛ چنین
        // سالی هرگز تاریخ واقعی وبلاگ نیست.
        $corruptedYear = 0;
        try {
            $created = isset($post) && $post ? (int) $post->created : 0;
            if ($created > 0) {
                $year = (int) date('Y', $created);
                if ($year >= 2300) {
                    $corruptedYear = $year;
                }
            }
        } catch (\Throwable $e) {
            $corruptedYear = 0;
        }

        if ($corruptedYear > 0) {
            ?>
            <section class="typecho-post-option" id="jalali-date-repair-notice">
                <p style="margin:0;padding:10px 12px;border-radius:6px;background:#fdecea;border:1px solid #f5c6c2;color:#a4271b;font-size:13px;line-height:2;">
                    <strong>⚠ هشدار: تاریخ این مطلب خراب است.</strong><br />
                    تاریخ ذخیره‌شده به‌دلیل باگ دوبار-تبدیلیِ نسخهٔ قبلی افزونه معتبر
                    نیست (سال <?php echo self::faDigits($corruptedYear); ?>). افزونه تاریخ درست را در فیلد
                    زیر بازیابی کرده است؛ برای اصلاح نهایی <strong>یک‌بار مطلب را ذخیره کنید</strong>
                    (می‌توانید پیش از ذخیره، تاریخ را از تقویم نیز بررسی کنید).
                </p>
            </section>
            <?php
        }
        ?>
        <section class="typecho-post-option" id="jalali-date-display-section" style="display:none;">
            <label for="jalali-date-display" class="typecho-label">تاریخ شمسی</label>
            <p><input class="typecho-date w-100" type="text" id="jalali-date-display" readonly autocomplete="off" /></p>
            <p class="description">نمایش شمسی تاریخ انتشار. برای ویرایش، از تقویم بالا استفاده کنید.</p>
        </section>
        <?php
    }

    /**
     * تبدیل عدد به اعداد فارسی (همیشه فعال)
     */
    public static function faDigits($num)
    {
        return JDate::toPersianDigits($num);
    }

    /**
     * دریافت تنظیمات پلاگین با پیش‌فرض
     */
    private static function getOption($key, $default = '')
    {
        try {
            $options = \Widget\Options::alloc()->plugin('JalaliDate');
            $val = $options->$key;
            return $val !== null ? $val : $default;
        } catch (\Throwable $e) {
            return $default;
        }
    }

    /**
     * دریافت URL پلاگین
     */
    public static function getPluginUrl()
    {
        $options = \Widget\Options::alloc();
        return rtrim($options->pluginUrl, '/') . '/JalaliDate';
    }
}
