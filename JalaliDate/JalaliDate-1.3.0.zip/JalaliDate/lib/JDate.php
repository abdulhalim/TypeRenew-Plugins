<?php
namespace TypechoPlugin\JalaliDate;

class JDate
{
    /**
     * نام ماه‌های شمسی (فارسی)
     */
    public static $jMonthNamesFa = [
        'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
        'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
    ];

    /**
     * نام کوتاه ماه‌های شمسی (فارسی)
     */
    public static $jMonthShortNamesFa = [
        'فرو', 'ارد', 'خرد', 'تیر', 'مرد', 'شهر',
        'مهر', 'آبا', 'آذر', 'دی', 'بهم', 'اسف'
    ];

    /**
     * نام روزهای هفته (فارسی) - ایندکس 0 = یکشنبه
     */
    public static $jDayNamesFa = [
        'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'
    ];

    /**
     * نام کوتاه روزهای هفته (فارسی)
     */
    public static $jDayShortNamesFa = [
        'ی', 'د', 'س', 'چ', 'پ', 'ج', 'ش'
    ];

    /**
     * نقشه‌ی اعداد فارسی
     */
    public static $faDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

    /**
     * جدول سال‌های کبیسه شمسی (تأییدشده از time.ir)
     * برای سال‌های 1288 تا 1614
     */
    public static $leapYearsSet = [
        1288, 1292, 1296, 1300, 1304, 1309, 1313, 1317,
        1321, 1325, 1329, 1333, 1337, 1342, 1346, 1350,
        1354, 1358, 1362, 1366, 1370, 1375, 1379, 1383,
        1387, 1391, 1395, 1399, 1403, 1407, 1411, 1415,
        1420, 1424, 1428, 1432, 1436, 1440, 1445, 1449,
        1453, 1457, 1461, 1465, 1469, 1474, 1478, 1482,
        1486, 1490, 1494, 1498, 1503, 1507, 1511, 1515,
        1519, 1523, 1527, 1531, 1536, 1540, 1544, 1548,
        1552, 1556, 1560, 1564, 1569, 1573, 1577, 1581,
        1585, 1589, 1593, 1597, 1602, 1606, 1610, 1614,
    ];

    /**
     * آیا سال شمسی کبیسه است؟
     */
    public static function isLeap($jy)
    {
        return in_array((int)$jy, self::$leapYearsSet, true);
    }

    /**
     * تعداد روزهای ماه شمسی
     */
    public static function daysInMonth($jy, $jm)
    {
        $jy = (int)$jy;
        $jm = (int)$jm;
        if ($jm <= 6) {
            return 31;
        }
        if ($jm <= 11) {
            return 30;
        }
        return self::isLeap($jy) ? 30 : 29;
    }

    /**
     * روز سال شمسی (1-366)
     */
    public static function dayOfYear($jy, $jm, $jd)
    {
        $days = 0;
        for ($m = 1; $m < $jm; $m++) {
            $days += self::daysInMonth($jy, $m);
        }
        return $days + $jd;
    }

    /**
     * تبدیل تاریخ میلادی به شمسی
     *
     * الگوریتم: محاسبه تعداد روز از 1970-01-01 میلادی (= 1348-10-11 شمسی)
     *
     * @param int $gy سال میلادی
     * @param int $gm ماه میلادی (1-12)
     * @param int $gd روز میلادی (1-31)
     * @return array [سال، ماه، روز] شمسی
     */
    public static function toJalali($gy, $gm, $gd)
    {
        $gy = (int)$gy;
        $gm = (int)$gm;
        $gd = (int)$gd;

        // محاسبه تعداد روز از 1970-01-01 میلادی
        $date = gmmktime(0, 0, 0, $gm, $gd, $gy);
        $epoch = gmmktime(0, 0, 0, 1, 1, 1970);
        $daysSinceEpoch = (int) round(($date - $epoch) / 86400);

        // 1970-01-01 میلادی = 1348-10-11 شمسی
        $jy = 1348;
        $jm = 10;
        $jd = 11;
        $remaining = $daysSinceEpoch;

        if ($remaining > 0) {
            while ($remaining > 0) {
                $dim = self::daysInMonth($jy, $jm);
                if ($jd + $remaining <= $dim) {
                    $jd += $remaining;
                    $remaining = 0;
                } else {
                    $remaining -= ($dim - $jd + 1);
                    $jd = 1;
                    if ($jm < 12) {
                        $jm++;
                    } else {
                        $jm = 1;
                        $jy++;
                    }
                }
            }
        } elseif ($remaining < 0) {
            while ($remaining < 0) {
                if ($jd + $remaining >= 1) {
                    $jd += $remaining;
                    $remaining = 0;
                } else {
                    $remaining += $jd;
                    if ($jm > 1) {
                        $jm--;
                    } else {
                        $jm = 12;
                        $jy--;
                    }
                    $jd = self::daysInMonth($jy, $jm);
                }
            }
        }

        return [$jy, $jm, $jd];
    }

    /**
     * تبدیل تاریخ شمسی به میلادی
     *
     * @param int $jy سال شمسی
     * @param int $jm ماه شمسی (1-12)
     * @param int $jd روز شمسی (1-31)
     * @return array [سال، ماه، روز] میلادی
     */
    public static function toGregorian($jy, $jm, $jd)
    {
        $jy = (int)$jy;
        $jm = (int)$jm;
        $jd = (int)$jd;

        // قدم زدن از 1348-10-11 شمسی به جلو
        $cy = 1348;
        $cm = 10;
        $cd = 11;
        $days = 0;

        while ($cy < $jy || ($cy === $jy && $cm < $jm) || ($cy === $jy && $cm === $jm && $cd < $jd)) {
            $days++;
            $cd++;
            $dim = self::daysInMonth($cy, $cm);
            if ($cd > $dim) {
                $cd = 1;
                if ($cm < 12) {
                    $cm++;
                } else {
                    $cm = 1;
                    $cy++;
                }
            }
        }

        // محاسبه تاریخ میلادی
        $target = gmmktime(0, 0, 0, 1, 1, 1970) + $days * 86400;
        return [
            (int) gmdate('Y', $target),
            (int) gmdate('n', $target),
            (int) gmdate('j', $target),
        ];
    }

    /**
     * تبدیل اعداد انگلیسی به فارسی
     */
    public static function toPersianDigits($str)
    {
        return str_replace(range(0, 9), self::$faDigits, (string) $str);
    }

    /**
     * تبدیل اعداد فارسی به انگلیسی
     */
    public static function toEnglishDigits($str)
    {
        return str_replace(self::$faDigits, range(0, 9), (string) $str);
    }

    /**
     * فرمت‌دهی تاریخ شمسی معادل date() در PHP
     *
     * @param string $format
     * @param int|null $timestamp
     * @return string
     */
    public static function date($format, $timestamp = null)
    {
        $timestamp = $timestamp === null ? time() : (int)$timestamp;

        // برای فرمت‌های c و r که باید میلادی بمانند
        if ($format === 'c') {
            return date('c', $timestamp);
        }
        if ($format === 'r') {
            return date('r', $timestamp);
        }
        if ($format === 'U') {
            return (string) $timestamp;
        }

        $gregorian = getdate($timestamp);

        return self::dateFormat(
            $format,
            (int) $gregorian['year'],
            (int) $gregorian['mon'],
            (int) $gregorian['mday'],
            (int) $gregorian['hours'],
            (int) $gregorian['minutes'],
            (int) $gregorian['seconds'],
            (int) $gregorian['wday'],
            $timestamp
        );
    }

    /**
     * موتور فرمت‌دهی شمسی بر اساس اجزای میلادی داده‌شده
     *
     * مستقل از timezone سرور؛ اجزا باید از قبل بر اساس منطقه زمانیِ سایت
     * محاسبه شده باشند (مثلاً از DateTimeImmutable واقع در Typecho\Date).
     *
     * @param string $format قالب تاریخ
     * @param int $gy سال میلادی
     * @param int $gm ماه میلادی (1-12)
     * @param int $gd روز میلادی
     * @param int $hour24 ساعت (0-23)
     * @param int $minute دقیقه
     * @param int $second ثانیه
     * @param int $dow روز هفته (0=یکشنبه)
     * @param int|null $timestamp فقط برای توکن‌های خاص مثل W/O/T
     * @return string
     */
    public static function dateFormat(
        string $format,
        int $gy,
        int $gm,
        int $gd,
        int $hour24,
        int $minute,
        int $second,
        int $dow,
        ?int $timestamp = null
    ): string {
        list($jy, $jm, $jd) = self::toJalali($gy, $gm, $gd);

        $hour12 = $hour24 % 12;
        if ($hour12 === 0) {
            $hour12 = 12;
        }

        // برای توکن‌های بدون معادل شمسی؛ در صورت نبود timestamp از زمان جاری استفاده می‌شود
        if ($timestamp === null) {
            $timestamp = time();
        }

        $isLeap = self::isLeap($jy);
        $dayOfYear = self::dayOfYear($jy, $jm, $jd) - 1;
        $daysInMonth = self::daysInMonth($jy, $jm);

        $output = '';
        $len = strlen($format);
        $escape = false;

        for ($i = 0; $i < $len; $i++) {
            $char = $format[$i];

            if ($escape) {
                $output .= $char;
                $escape = false;
                continue;
            }

            if ($char === '\\') {
                $escape = true;
                continue;
            }

            switch ($char) {
                case 'Y':
                    $output .= sprintf('%04d', $jy);
                    break;
                case 'y':
                    $output .= sprintf('%02d', $jy % 100);
                    break;
                case 'm':
                    $output .= sprintf('%02d', $jm);
                    break;
                case 'n':
                    $output .= $jm;
                    break;
                case 'd':
                    $output .= sprintf('%02d', $jd);
                    break;
                case 'j':
                    $output .= $jd;
                    break;
                case 'F':
                    $output .= self::$jMonthNamesFa[$jm - 1];
                    break;
                case 'M':
                    $output .= self::$jMonthShortNamesFa[$jm - 1];
                    break;
                case 'l':
                    $output .= self::$jDayNamesFa[$dow];
                    break;
                case 'D':
                    $output .= self::$jDayShortNamesFa[$dow];
                    break;
                case 'H':
                    $output .= sprintf('%02d', $hour24);
                    break;
                case 'G':
                    $output .= $hour24;
                    break;
                case 'h':
                    $output .= sprintf('%02d', $hour12);
                    break;
                case 'g':
                    $output .= $hour12;
                    break;
                case 'i':
                    $output .= sprintf('%02d', $minute);
                    break;
                case 's':
                    $output .= sprintf('%02d', $second);
                    break;
                case 'A':
                    $output .= ($hour24 < 12 ? 'قبل از ظهر' : 'بعد از ظهر');
                    break;
                case 'a':
                    $output .= ($hour24 < 12 ? 'ق.ظ' : 'ب.ظ');
                    break;
                case 't':
                    $output .= $daysInMonth;
                    break;
                case 'L':
                    $output .= $isLeap ? '1' : '0';
                    break;
                case 'z':
                    $output .= $dayOfYear;
                    break;
                case 'w':
                    $output .= $dow;
                    break;
                case 'N':
                    $output .= $dow === 0 ? '7' : $dow;
                    break;
                case 'S':
                    $output .= '';
                    break;
                case 'o':
                case 'W':
                    $output .= date($char, $timestamp);
                    break;
                case 'B':
                case 'I':
                case 'O':
                case 'P':
                case 'T':
                case 'Z':
                    $output .= date($char, $timestamp);
                    break;
                default:
                    $output .= $char;
                    break;
            }
        }

        // اعداد همیشه به‌صورت فارسی نمایش داده می‌شوند
        return self::toPersianDigits($output);
    }

    /**
     * تبدیل رشته تاریخ شمسی به Unix timestamp
     *
     * @param string $jdate
     * @return int|false
     */
    public static function strtotime($jdate)
    {
        $jdate = trim(self::toEnglishDigits($jdate));

        if (preg_match('/^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})(?:[ T](\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?$/', $jdate, $m)) {
            $jy = (int) $m[1];
            $jm = (int) $m[2];
            $jd = (int) $m[3];
            $h = isset($m[4]) ? (int) $m[4] : 0;
            $i = isset($m[5]) ? (int) $m[5] : 0;
            $s = isset($m[6]) ? (int) $m[6] : 0;

            list($gy, $gm, $gd) = self::toGregorian($jy, $jm, $jd);
            return mktime($h, $i, $s, $gm, $gd, $gy);
        }
        return false;
    }

    /**
     * زمان نسبی شمسی («۲۵ دقیقه پیش») هم‌ساز با Utils\Zone::word
     *
     * طبقه‌بندی، آستانه‌ها و مقایسه روز تقویمی دقیقاً مطابق Zone::word انجام
     * می‌شود تا عدد نمایشی با حالت غیرفعال بودن پلاگین یکسان بماند؛ فقط خروجی
     * فارسی + اعداد فارسی + تاریخ جلالی است.
     *
     * @param int $from timestamp مبدأ
     * @param int $now timestamp اکنون (هر دو خام، بدون جابجایی offset)
     */
    public static function relativeWord(int $from, int $now, ?string $timezoneId = null, int $fallbackOffset = 0): string
    {
        $between = $now - $from;

        if (!class_exists('\Utils\Zone')) {
            // Typecho کلاسیک: بدون لایه Zone، همان روال ساده مقایسه دو timestamp خام
            $text = null;

            if ($between < 60) {
                $text = 'لحظاتی پیش';
            } elseif ($between < 3600) {
                $mins = (int) floor($between / 60);
                $text = $mins . ' دقیقه پیش';
            } elseif ($between < 86400) {
                $hours = (int) floor($between / 3600);
                $text = $hours . ' ساعت پیش';
            } elseif ($between < 172800) {
                $text = 'دیروز ' . self::date('H:i', $from);
            } elseif ($between < 604800) {
                $days = (int) floor($between / 86400);
                $text = $days === 1 ? 'دیروز' : $days . ' روز پیش';
            }

            if ($text !== null) {
                return self::toPersianDigits($text);
            }

            $lj = self::toJalali((int) date('Y', $from), (int) date('n', $from), (int) date('j', $from));
            $nj = self::toJalali((int) date('Y', $now), (int) date('n', $now), (int) date('j', $now));

            if ($lj[0] === $nj[0]) {
                return self::toPersianDigits($lj[2] . ' ' . self::$jMonthNamesFa[$lj[1] - 1]);
            }

            return self::toPersianDigits($lj[2] . ' ' . self::$jMonthNamesFa[$lj[1] - 1] . ' ' . $lj[0]);
        }

        // TypeRenew: منطق طبقات دقیقاً مطابق Utils\Zone::word تا خروجی با حالت غیرفعال بودن پلاگین همخوان باشد
        $fromDate = \Utils\Zone::dateTime($from, $timezoneId, $fallbackOffset);
        $nowDate = \Utils\Zone::dateTime($now, $timezoneId, $fallbackOffset);

        if ($between >= 0 && $between < 86400 && $fromDate->format('Y-m-d') === $nowDate->format('Y-m-d')) {
            if ($between < 3600) {
                if ($between < 60) {
                    if ($between === 0) {
                        return self::toPersianDigits('همین حالا');
                    }
                    return self::toPersianDigits($between . ' ثانیه پیش');
                }
                $min = (int) floor($between / 60);
                return self::toPersianDigits($min . ' دقیقه پیش');
            }

            $hour = (int) floor($between / 3600);
            return self::toPersianDigits($hour . ' ساعت پیش');
        }

        if ($between > 0 && $between < 172800 && $fromDate->modify('+1 day')->format('Y-m-d') === $nowDate->format('Y-m-d')) {
            return self::toPersianDigits('دیروز ' . $fromDate->format('H:i'));
        }

        if ($between > 0 && $between < 604800) {
            $day = (int) floor($between / 86400);
            return self::toPersianDigits($day === 1 ? 'دیروز' : $day . ' روز پیش');
        }

        list($fy, $fm, $fd) = self::toJalali(
            (int) $fromDate->format('Y'),
            (int) $fromDate->format('n'),
            (int) $fromDate->format('j')
        );

        if ($fromDate->format('Y') === $nowDate->format('Y')) {
            return self::toPersianDigits($fd . ' ' . self::$jMonthNamesFa[$fm - 1]);
        }

        return self::toPersianDigits($fd . ' ' . self::$jMonthNamesFa[$fm - 1] . ' ' . $fy);
    }
}
