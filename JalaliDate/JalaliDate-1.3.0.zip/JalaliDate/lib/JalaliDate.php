<?php
namespace TypechoPlugin\JalaliDate;

use Typecho\Date;
use Utils\Zone;

class JalaliDate extends Date
{
    /**
     * نگاشت فرمت‌های انگلیسی پیش‌فرض هسته به معادل فارسی.
     *
     * هسته TypeRenew در زمان نصب، فرمت تاریخ دیدگاه را با مقدار پیش‌فرض
     * انگلیسی «F jS, Y \a\t h:i a» ذخیره می‌کند که واژهٔ لاتین «at» را به‌صورت
     * متن لفظی (نه توکن تاریخ) در خروجی می‌گذارد؛ در نتیجه خروجی شمسی چیزی
     * شبیه «شهریور ۶, ۱۴۰۵ at ۰۹:۰۲ ق.ظ» می‌شد. این نگاشت فقط برای همین
     * فرمتِ مشخص و فقط در سایت‌های فارسی فعال می‌شود و فرمت‌های سفارشیِ مدیر
     * هرگز تغییر نمی‌کنند.
     *
     * @var array<string, string>
     */
    public static array $formatOverrides = [];

    /**
     * آبجکت تاریخ هماهنگ با منطقه زمانی سایت — متعلق به همین کلاس فرزند،
     * بدون تکیه بر فیلد خصوصی والد.
     *
     * @var \DateTimeImmutable|null
     */
    private ?\DateTimeImmutable $siteTime = null;

    /**
     * سازنده
     *
     * @param integer|null $time زمان
     */
    public function __construct(?int $time = null)
    {
        parent::__construct($time);

        // دقیقاً همان مسیری که خودِ والد برای ساخت تاریخ داخلی طی می‌کند:
        // Zone::dateTime($timestamp, timezoneId, fallbackOffset)
        try {
            $this->siteTime = Zone::dateTime(
                $this->timeStamp,
                self::$timezoneId,
                self::$timezoneOffset
            );
        } catch (\Throwable $e) {
            // هرگز نباید رخ دهد (والد موفق شده Zone را صدا بزند)؛ ولی فالبک امن UTC
            $this->siteTime = new \DateTimeImmutable('@' . $this->timeStamp);
        }

        // بازنویسی year/month/day با مقادیر شمسی، برگرفته از siteTime هماهنگ با منطقه زمانی سایت
        list($jy, $jm, $jd) = JDate::toJalali(
            (int) $this->siteTime->format('Y'),
            (int) $this->siteTime->format('n'),
            (int) $this->siteTime->format('j')
        );

        $this->year = sprintf('%04d', $jy);
        $this->month = sprintf('%02d', $jm);
        $this->day = sprintf('%02d', $jd);
    }

    /**
     * فرمت‌دهی تاریخ
     *
     * @param string $format فرمت
     * @return string
     */
    public function format(string $format): string
    {
        // فرمت‌های ISO 8601 و RFC 822 باید میلادی بمانند
        if ($format === 'c' || $format === 'r') {
            return parent::format($format);
        }

        // جایگزینی فرمت پیش‌فرض انگلیسی هسته با معادل فارسی (فقط برای همان
        // فرمتِ مشخص؛ فرمت‌های سفارشی مدیر دست‌نخورده می‌مانند)
        if (isset(self::$formatOverrides[$format])) {
            $format = self::$formatOverrides[$format];
        }

        // timestamp خام عددی و بدون تبدیل
        if ($format === 'U') {
            return (string) $this->timeStamp;
        }

        return JDate::dateFormat(
            $format,
            (int) $this->siteTime->format('Y'),
            (int) $this->siteTime->format('n'),
            (int) $this->siteTime->format('j'),
            (int) $this->siteTime->format('G'),
            (int) $this->siteTime->format('i'),
            (int) $this->siteTime->format('s'),
            (int) $this->siteTime->format('w'),
            $this->timeStamp
        );
    }

    /**
     * کلمه نسبی زمان شمسی («۲۵ دقیقه پیش»)
     *
     * منطق آستانه‌ها عیناً مطابق Zone::word است تا اختلاف نمایش داده‌شده
     * با هسته یکسان بماند؛ فقط خروجی فارسی/جلالی است.
     *
     * @return string
     */
    public function word(): string
    {
        return JDate::relativeWord(
            $this->timeStamp,
            self::time(),
            self::$timezoneId,
            self::$timezoneOffset
        );
    }
}
