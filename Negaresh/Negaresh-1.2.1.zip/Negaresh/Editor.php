<?php
declare(strict_types=1);

namespace TypechoPlugin\Negaresh;

use Typecho\Plugin as Hook;
use Utils\Helper;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Editor
{
    public static function richEditor($content): bool
    {
        // Returning true (or just being plugged) makes write-foot.php skip the
        // default editor-js.php. We still inject our own assets via the bottom hook.
        return true;
    }

    public static function injectAssets($content): void
    {
        try {
            $settings = Settings::load();
        } catch (\Throwable $e) {
            // اگر بارگذاری تنظیمات شکست خورد، از پیش‌فرض‌ها استفاده می‌کنیم
            // تا از کار افتادن ویرایشگر جلوگیری شود.
            $settings = Settings::defaults();
        }

        if (($settings['enabled'] ?? '1') !== '1') {
            return;
        }

        $assetUrl = Settings::assetUrl('assets/');

        // Bootstrap config passed to the editor module via window.__NEGARESH_EDITOR__.
        $config = [
            'assetsUrl' => $assetUrl,
            // کش‌شکن ماژول‌ها: بیشینه‌ی زمان تغییر فایل‌های assets/modules —
            // تا اگر نسخه بین دو ساخت تغییر نکرد، فایل تازه از کش رد نشود.
            'moduleRev' => self::moduleRev(),
            'version' => Plugin::VERSION,
            'settings' => $settings,
            'isMarkdown' => self::isMarkdown($content),
            'strings' => self::strings(),
            'siteUrl' => Settings::siteUrl(),
            'upload' => [
                // The real upload action (Widget\\Upload) — same endpoint the core
                // file-upload-js.php and MediaManager's picker use.
                'url' => self::uploadUrl(),
            ],
        ];

        // The HyperDown + DOMPurify parsers are NOT loaded by default
        // because we are replacing the editor. Load them ourselves.
        // The admin already ships purify.js. We use it.
        //
        // نکته‌ی نسخه‌ی 1.2.1 (سازگار با TypeRenew 1.6.1):
        // در TypeRenew 1.6.1، متد adminStaticUrl('js', '') با $file خالی
        // یک رشته برمی‌گرداند (return می‌کند، نه echo). اما در برخی پیکربندی‌ها
        // ممکن است مقدار خالی برگرداند. برای اطمینان، یک fallback مستقل
        // از adminStaticUrl اضافه شده است که مستقیماً URL را از siteUrl و
        // __TYPECHO_ADMIN_DIR__ می‌سازد.
        $adminStaticUrl = self::resolveAdminJsUrl();

        ?>
<script>
window.__NEGARESH_EDITOR__ = <?php echo json_encode($config, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;
</script>
<script src="<?php echo htmlspecialchars($adminStaticUrl . '/hyperdown.js', ENT_QUOTES, 'UTF-8'); ?>"></script>
<script src="<?php echo htmlspecialchars($adminStaticUrl . '/purify.js', ENT_QUOTES, 'UTF-8'); ?>"></script>
<link rel="stylesheet" href="<?php echo htmlspecialchars($assetUrl . 'editor.css?' . Settings::assetRev('assets/editor.css'), ENT_QUOTES, 'UTF-8'); ?>">
<script type="module" src="<?php echo htmlspecialchars($assetUrl . 'editor.js?' . Settings::assetRev('assets/editor.js'), ENT_QUOTES, 'UTF-8'); ?>"></script>
        <?php
    }

    private static function resolveAdminJsUrl(): string
    {
        $url = '';

        // ۱) تلاش با adminStaticUrl
        try {
            $options = Helper::options();
            if ($options && method_exists($options, 'adminStaticUrl')) {
                $url = (string) $options->adminStaticUrl('js', '');
                $url = rtrim($url, '/');
                if ($url === '' || filter_var($url, FILTER_VALIDATE_URL) === false) {
                    $url = '';
                }
            }
        } catch (\Throwable $e) {
            $url = '';
        }

        // ۲) تلاش با adminUrl
        if ($url === '') {
            try {
                $options = Helper::options();
                if ($options && method_exists($options, 'adminUrl')) {
                    // adminUrl('js', true) مقدار را return می‌کند (نه echo)
                    $url = rtrim((string) $options->adminUrl('js', true), '/');
                }
            } catch (\Throwable $e) {
                $url = '';
            }
        }

        // ۳) fallback نهایی: مستقیم از siteUrl و __TYPECHO_ADMIN_DIR__
        if ($url === '') {
            $adminDir = defined('__TYPECHO_ADMIN_DIR__') ? __TYPECHO_ADMIN_DIR__ : '/admin/';
            $adminDir = '/' . trim($adminDir, '/') . '/';
            $url = rtrim(Settings::siteUrl(), '/') . $adminDir . 'js';
        }

        // بازنویسی پروتکل با پروتکل واقعی درخواست (رفع مشکل CORS)
        return self::normalizeUrlProtocol($url);
    }

    /**
     * بازنویسی پروتکل URL با پروتکل واقعی درخواست
     *
     * این متد مشکل CORS را برطرف می‌کند: اگر siteUrl در دیتابیس https://
     * باشد و کاربر از http:// دسترسی داشته باشد (یا برعکس)، URL به پروتکل
     * درخواست تبدیل می‌شود تا مرورگر ES module‌ها را same-origin ببیند.
     *
     * @param string $url URL که باید پروتکل آن بازنویسی شود
     * @return string URL با پروتکل صحیح
     */
    private static function normalizeUrlProtocol(string $url): string
    {
        return Settings::normalizeUrlProtocol($url);
    }

    /**
     * بیشینه‌ی زمان تغییر ماژول‌های assets/modules (کش‌شکن ماژول‌ها)
     */
    private static function moduleRev(): int
    {
        $max = 0;
        $files = glob(__DIR__ . '/assets/modules/*.js') ?: [];
        foreach ($files as $file) {
            $mtime = (int) @filemtime($file);
            if ($mtime > $max) {
                $max = $mtime;
            }
        }
        return $max;
    }

    public static function markdownEditor($content): void
    {
        // Forward compatibility: do nothing for now.
        // Other plugins can still hook this point to extend the editor.
    }

    private static function isMarkdown($content): bool
    {
        if (!$content || !method_exists($content, 'have') || !$content->have()) {
            return true;
        }
        if (isset($content->isMarkdown)) {
            return (bool) $content->isMarkdown;
        }
        return true;
    }

    private static function strings(): array
    {
        return [
            // Toolbar
            'bold' => 'پررنگ',
            'italic' => 'کج',
            'strike' => 'خط‌خورده',
            'h1' => 'سرتیتر ۱',
            'h2' => 'سرتیتر ۲',
            'h3' => 'سرتیتر ۳',
            'link' => 'پیوند',
            'image' => 'تصویر',
            'code' => 'کد',
            'codeBlock' => 'بلوک کد',
            'quote' => 'نقل قول',
            'ul' => 'فهرست نقطه‌ای',
            'ol' => 'فهرست عددی',
            'hr' => 'خط جداکننده',
            'more' => 'بیشتر (خلاصه)',
            'table' => 'جدول',
            'footnote' => 'پانوشت',
            'zwnj' => 'نیم‌فاصله',
            'persianQuotes' => 'گیومه فارسی',
            'undo' => 'بازگرد',
            'redo' => 'از نو',
            'find' => 'جست‌وجو',
            'fullscreen' => 'تمام‌صفحه',
            'exitFullscreen' => 'خروج از تمام‌صفحه',
            'mobileTools' => 'ابزارها',

            // Text alignment (toolbar)
            'alignRight' => 'راست‌چین',
            'alignCenter' => 'وسط‌چین',
            'alignLeft' => 'چپ‌چین',
            'alignJustify' => 'تراز دوطرفه (جاستیفای)',
            'alignSkipped' => 'تراز فقط روی پاراگراف‌های ساده اعمال می‌شود (سرتیتر/فهرست/کد رد شد).',
            'alignNoChange' => 'چیزی برای تراز نیست.',

            // جهت نوشتن — کل ادیتور (وقتی کیبورد انگلیسی/کدنویسی می‌شود)
            'dirRtl' => 'نوشتن راست‌به‌چپ (فارسی)',
            'dirLtr' => 'نوشتن چپ‌به‌راست (انگلیسی/کد)',
            'dirSwitchedRtl' => 'جهت ویرایشگر: راست‌به‌چپ',
            'dirSwitchedLtr' => 'جهت ویرایشگر: چپ‌به‌راست',

            // Fullscreen rail (actions + attachments)
            'fsRailToggle' => 'اکشن‌ها و کتابخانه',
            'saveDraft' => 'ذخیره پیش‌نویس',
            'publish' => 'انتشار مطلب',
            'savingDraft' => 'در حال ذخیره…',
            'attachments' => 'پیوست‌های نوشته',
            'close' => 'بستن',

            // Tabs
            'write' => 'ویرایش',
            'preview' => 'پیش‌نمایش',

            // Status bar
            'words' => 'واژه',
            'chars' => 'نویسه',
            'readingTime' => 'دقیقه مطالعه',

            // Modal: link
            'linkUrl' => 'نشانی پیوند',
            'linkText' => 'متن پیوند',
            'linkTitle' => 'عنوان (اختیاری)',

            // Modal: image
            'imageUrl' => 'نشانی تصویر',
            'imageAlt' => 'متن جایگزین',
            'imageTitle' => 'عنوان (اختیاری)',
            'imageUpload' => 'آپلود فایل',
            'orPasteUrl' => 'یا نشانی را بچسبانید',

            // Modal: table
            'tableRows' => 'تعداد ردیف',
            'tableCols' => 'تعداد ستون',
            'tableHeader' => 'با سرتیتر',
            'tableAlign' => 'تراز',

            // Modal: code
            'codeLanguage' => 'زبان کد',
            'codePlaceholder' => 'کد را اینجا بنویسید…',

            // Modal: footnote
            'footnoteId' => 'شناسه پانوشت',

            // Video embeds + emoji (Phase 6)
            'video' => 'درج ویدئو',
            'videoUrl' => 'نشانی ویدیو',
            'videoHint' => 'لینک ویدیو را بچسبانید: یوتیوب، آپارات، ویمیو، اینستاگرام، تلگرام یا لینک مستقیم فایل (mp4 / webm). با چسباندن یا تایپ لینک و فشردن Enter هم به‌صورت خودکار به پخش‌کننده تبدیل می‌شود.',
            'videoDetected' => 'پخش‌کننده:',
            'videoNotRecognized' => 'نشانی ویدیو شناسایی نشد — از یوتیوب، آپارات، ویمیو، اینستاگرام، تلگرام یا لینک مستقیم mp4/webm استفاده کنید.',
            'pvYoutube' => 'یوتیوب',
            'pvAparat' => 'آپارات',
            'pvVimeo' => 'ویمیو',
            'pvInstagram' => 'اینستاگرام',
            'pvTelegram' => 'تلگرام',
            'pvDirect' => 'فایل ویدیویی مستقیم',
            'emoji' => 'شکلک',

            // Buttons
            'ok' => 'تأیید',
            'cancel' => 'انصراف',
            'insert' => 'درج',

            // Other
            'confirmMarkdown' => 'این نوشته با مارکدون ساخته نشده است. ادامه می‌دهید؟',
            'autosaveRestored' => 'پیش‌نویس ذخیره‌شده بازیابی شد',

            // Media (Phase 1 — media.js module)
            'library' => 'کتابخانه رسانه',
            'dropHere' => 'فایل‌ها را اینجا رها کنید',
            'uploading' => 'در حال آپلود',
            'uploadFailed' => 'آپلود ناموفق بود',
            'mmUnavailable' => 'برای دسترسی به کتابخانه رسانه، افزونه «مدیا منیجر» و گزینه «انتخابگر رسانه در ویرایشگر» آن باید فعال باشد.',
            // کادر آپلود ریل تمام‌صفحه (v1.1)
            'uploadFile' => 'آپلود فایل',
            'railUploadHint' => 'فایل را اینجا رها کنید یا کلیک کنید',

            // Save / draft (core + draft.js module — Phase 2)
            'unsaved' => 'ذخیره‌نشده',
            'saved' => 'ذخیره شد',
            'draftFound' => 'یک پیش‌نویس ذخیره‌شده‌ی محلی',
            'draftFoundHint' => 'یافت شد که با محتوای فعلی تفاوت دارد.',
            'draftRestore' => 'بازیابی',
            'draftDismiss' => 'دور انداختن',
            'draftRestored' => 'پیش‌نویس بازیابی شد',
            'localDraftSaved' => 'پیش‌نویس محلی',

            // Outline (outline.js module — Phase 2)
            'outline' => 'فهرست مطالب',
            'outlineEmpty' => 'سرتیتری یافت نشد',

            // Focus mode (focus.js module — Phase 2)
            'focusMode' => 'حالت تمرکز',
            'enabled' => 'فعال',
            'disabled' => 'غیرفعال',

            // Advanced table (table.js module — Phase 2; clearer verbs in v1.1)
            'tableAddRowAbove' => 'افزودن ردیف در بالا',
            'tableAddRowBelow' => 'افزودن ردیف در پایین',
            'tableDelRow' => 'حذف ردیف',
            'tableAddColBefore' => 'افزودن ستون سمت راست',
            'tableAddColAfter' => 'افزودن ستون سمت چپ',
            'tableDelCol' => 'حذف ستون',
            'tableAlignLeft' => 'تراز چپ',
            'tableAlignCenter' => 'تراز وسط',
            'tableAlignRight' => 'تراز راست',
            'tableDelete' => 'حذف جدول',

            // Advanced links (links.js module — Phase 2)
            'linkFromAttachments' => 'از پیوست‌های این نوشته',
            'fromLibrary' => 'از کتابخانه رسانه',

            // Colored content blocks (blocks.js module — v1.1 add-on)
            'coloredBlocks' => 'بلاک‌های رنگی',
            'blockSuccess' => 'بلاک موفقیت',
            'blockWarning' => 'بلاک هشدار',
            'blockInfo' => 'بلاک اطلاعات',
            'blockDanger' => 'بلاک خطا',

            // Writing assistant (assistant.js module — Phase 3)
            'assistant' => 'دستیار نگارش فارسی',
            'fixAutocorrect' => 'تصحیح خودکار کلمات (می‌شود، تقریباً، ی/ک)',
            'fixZwnj' => 'اصلاح نیم‌فاصله‌ها',
            'fixArabicChars' => 'تبدیل ي/ك عربی به ی/ک فارسی',
            'fixDigits' => 'تبدیل ارقام انگلیسی به فارسی',
            'fixQuotes' => 'گیومه‌های مستقیم به «»',
            'fixSpaces' => 'حذف فاصله‌های تکراری',
            'fixPunctuation' => 'فاصله‌گذاری علائم نگارشی',
            'applyToSelection' => 'فقط روی انتخاب',
            'applyToAll' => 'روی کل نوشته',
            'apply' => 'اعمال',
            'applied' => 'اعمال شد',

            // Typography checker (typography.js module — Phase 3)
            'typography' => 'بازبین تایپوگرافی',
            'issues' => 'مورد',
            'noIssues' => 'مشکلی یافت نشد',

            // Content analyzer (analyzer.js module — Phase 3)
            'analyzer' => 'تحلیل محتوا',

            // SEO tools (seo.js module — Phase 3)
            'seoTools' => 'ابزارهای سئو',
            'focusKeyword' => 'کلیدواژه‌ی کانونی',
        ];
    }

    private static function uploadUrl(): string
    {
        $security = \Widget\Security::alloc();
        return $security->getIndex('/action/upload');
    }
}
