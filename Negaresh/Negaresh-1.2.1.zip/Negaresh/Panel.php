<?php
declare(strict_types=1);

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

use TypechoPlugin\Negaresh\Settings;
use TypechoPlugin\Negaresh\Text;

$user->pass('administrator');
$settings = Settings::loadFresh();
$assetUrl = Settings::assetUrl('assets/');
$bundleSize = is_file(__DIR__ . '/assets/codemirror/codemirror.bundle.js')
    ? round(filesize(__DIR__ . '/assets/codemirror/codemirror.bundle.js') / 1024, 1) . ' KB'
    : '—';

// Action URL — must point to /action/plugins-edit?config=Negaresh
$security = \Widget\Security::alloc();
$actionUrl = $security->getIndex('/action/plugins-edit?config=Negaresh');
?>

<link rel="stylesheet" href="<?php echo Text::e($assetUrl . 'panel.css?' . Settings::assetRev('assets/panel.css')); ?>">
<div class="tr-panel tr-panel-editor" dir="rtl">
    <section class="tr-card">
        <div class="tr-card-b">
            <div class="tr-panel-head">
                <div class="tr-panel-heading">
                    <h2 class="tr-panel-title">ویرایشگر نگارش</h2>
                    <p class="tr-panel-desc">ویرایشگر مارک‌داون فارسی با پیش‌نمایش زنده، تصحیح خودکار نگارش و نیم‌فاصله، فهرست مطالب، جدول پیشرفته، درج ویدئو و بلاک‌های رنگی.</p>
                </div>
                <div class="tr-panel-pills">
                    <span class="tr-pill<?php echo $settings['enabled'] === '1' ? ' tr-pill-accent' : ''; ?>">افزونه <?php echo $settings['enabled'] === '1' ? 'فعال است' : 'غیرفعال است'; ?></span>
                    <span class="tr-pill">باندل: <?php echo Text::e($bundleSize); ?></span>
                </div>
            </div>
        </div>
    </section>

    <form method="post" action="<?php echo Text::e($actionUrl); ?>" class="tr-editor-form" autocomplete="off">
        <?php $security->render(); ?>

        <section class="tr-card">
            <div class="tr-card-b">
                <h3 class="tr-section-title">چیدمان</h3>

                <div class="tr-field">
                    <label class="tr-label">وضعیت افزونه</label>
                    <div class="tr-radio-row">
                        <label><input type="radio" name="enabled" value="1" <?php echo $settings['enabled'] === '1' ? 'checked' : ''; ?>> فعال</label>
                        <label><input type="radio" name="enabled" value="0" <?php echo $settings['enabled'] !== '1' ? 'checked' : ''; ?>> غیرفعال</label>
                    </div>
                </div>

                <div class="tr-field">
                    <p class="tr-panel-desc">
                        پیش‌نمایش فقط در تب «پیش‌نمایش» خود ویرایشگر رندر می‌شود (نمایش زنده‌ی کنارِ ادیتور در نسخه‌ی ۲.۱ حذف شد تا فضای نوشتن کامل باشد).
                    </p>
                </div>

                <div class="tr-field tr-checkbox-row">
                    <?php
                    $checkboxesLayout = [
                        'wordWrap' => 'شکست خط بلند',
                        'lineNumbers' => 'نمایش شماره‌ی خط',
                    ];
                    foreach ($checkboxesLayout as $key => $label):
                    ?>
                    <label>
                        <input type="hidden" name="<?php echo $key; ?>" value="0">
                        <input type="checkbox" name="<?php echo $key; ?>" value="1" <?php echo $settings[$key] === '1' ? 'checked' : ''; ?>> <?php echo Text::e($label); ?>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <section class="tr-card">
            <div class="tr-card-b">
                <h3 class="tr-section-title">کمک‌های فارسی</h3>

                <div class="tr-field tr-checkbox-row">
                    <?php
                    $checkboxesFa = [
                        'zwnjButton' => 'دکمه‌ی نیم‌فاصله (‌) در تولبار',
                        'autoPunctuate' => 'تبدیل خودکار ; به ؛ و ? به ؟ و &gt;&gt; به «»',
                        'persianQuotes' => 'دکمه‌ی گیومه‌ی فارسی «»',
                        'autoCorrect' => 'تصحیح خودکار هنگام تایپ (میشود/می شود → می‌شود، تقریبا → تقریباً، تبدیل ي/ك عربی)',
                    ];
                    foreach ($checkboxesFa as $key => $label):
                    ?>
                    <label>
                        <input type="hidden" name="<?php echo $key; ?>" value="0">
                        <input type="checkbox" name="<?php echo $key; ?>" value="1" <?php echo $settings[$key] === '1' ? 'checked' : ''; ?>> <?php echo $label; ?>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <section class="tr-card">
            <div class="tr-card-b">
                <h3 class="tr-section-title">امکانات ویرایشگر</h3>

                <div class="tr-field tr-checkbox-row">
                    <?php
                    $checkboxesFeats = [
                        'visualTable' => 'جدول بصری با دیالوگ',
                        'showCount' => 'شمارش واژه و نویسه',
                        'countReadingTime' => 'تخمین زمان مطالعه',
                        'autoCloseBrackets' => 'بستن خودکار پرانتز و گیومه',
                    ];
                    foreach ($checkboxesFeats as $key => $label):
                    ?>
                    <label>
                        <input type="hidden" name="<?php echo $key; ?>" value="0">
                        <input type="checkbox" name="<?php echo $key; ?>" value="1" <?php echo $settings[$key] === '1' ? 'checked' : ''; ?>> <?php echo $label; ?>
                    </label>
                    <?php endforeach; ?>
                </div>

                <div class="tr-field">
                    <label class="tr-label" for="tabSize">عرض Tab</label>
                    <select id="tabSize" name="tabSize" class="tr-select">
                        <?php foreach ([2, 4, 8] as $v): ?>
                            <option value="<?php echo $v; ?>" <?php echo (int) $settings['tabSize'] === $v ? 'selected' : ''; ?>><?php echo $v; ?> فاصله</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="tr-field">
                    <label class="tr-label" for="fontSize">اندازه‌ی فونت: <strong id="fontSizeValue"><?php echo (int) $settings['fontSize']; ?>px</strong></label>
                    <input type="range" id="fontSize" name="fontSize" min="12" max="22" step="1" value="<?php echo (int) $settings['fontSize']; ?>" class="tr-range">
                </div>
            </div>
        </section>

        <section class="tr-card">
            <div class="tr-card-b">
                <h3 class="tr-section-title">پیش‌نویس و ویرایش</h3>

                <div class="tr-field tr-checkbox-row">
                    <?php
                    $checkboxesDraft = [
                        'localDraft' => 'بازیابی پیش‌نویس محلی (ذخیره‌ی دوره‌ای در مرورگر)',
                        'outline' => 'فهرست مطالب بر اساس سرتیترها',
                        'focusMode' => 'حالت تمرکز (مات‌کردن بقیه‌ی پاراگراف‌ها)',
                        'advancedTable' => 'جدول پیشرفته (انتخابگر بصری + ابزارهای ویرایش جدول)',
                        'advancedLinks' => 'پیوندهای پیشرفته (عنوان + پیوست‌های نوشته + کتابخانه) + مودال تصویر ۳ فیلدی (URL/alt/title)',
                        'coloredBlocks' => 'بلاک‌های رنگی (موفقیت/هشدار/اطلاعات/خطا) با منوی پاپ‌آپ',
                        'blockIcons' => 'نمایش آیکون Lucide در بلاک‌های رنگی (سمت پوسته و پیش‌نمایش)',
                    ];
                    foreach ($checkboxesDraft as $key => $label):
                    ?>
                    <label>
                        <input type="hidden" name="<?php echo $key; ?>" value="0">
                        <input type="checkbox" name="<?php echo $key; ?>" value="1" <?php echo $settings[$key] === '1' ? 'checked' : ''; ?>> <?php echo $label; ?>
                    </label>
                    <?php endforeach; ?>
                </div>

                <div class="tr-field">
                    <label class="tr-label" for="draftInterval">فاصله‌ی ذخیره‌ی پیش‌نویس محلی</label>
                    <select id="draftInterval" name="draftInterval" class="tr-select">
                        <?php
                        $current = (int) $settings['draftInterval'];
                        foreach ([0, 60, 120, 180, 300, 600, 900] as $sec):
                            $selected = $current === $sec ? 'selected' : '';
                            $label = $sec === 0
                                ? 'غیرفعال (فقط هنگام ترک صفحه)'
                                : ((int) ($sec / 60)) . ' دقیقه';
                        ?>
                        <option value="<?php echo $sec; ?>" <?php echo $selected; ?>><?php echo Text::e($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p class="tr-panel-desc" style="margin-top: 6px;">
                        هر چند وقت یک‌بار از نوشته در مرورگر نسخه‌ی پشتیبان گرفته می‌شود؛ اگر بدون ذخیره از صفحه خارج شوید، یک نسخه‌ی اضطراری هم ثبت می‌شود و بعداً با بنر «بازیابی پیش‌نویس» برمی‌گردد.
                    </p>
                </div>

                <div class="tr-field">
                    <p class="tr-panel-desc" style="margin-top: 8px;">
                        ذخیره‌ی خودکار روی سرور، هشدار «ذخیره‌نشده» و میانبر Ctrl+S به‌صورت خودکار با هسته‌ی TypeRenew یکپارچه شده است (نیازی به تنظیم ندارد).
                    </p>
                </div>
            </div>
        </section>

        <section class="tr-card">
            <div class="tr-card-b">
                <h3 class="tr-section-title">رسانه و آپلود</h3>

                <div class="tr-field">
                    <p class="tr-panel-desc" style="margin-bottom: 10px;">
                        برای دکمه‌ی «کتابخانه رسانه»، افزونه‌ی «مدیا منیجر» باید فعال باشد و در تنظیمات آن گزینه‌ی «انتخابگر رسانه در ویرایشگر» روشن باشد.
                    </p>
                </div>

                <div class="tr-field tr-checkbox-row">
                    <?php
                    $checkboxesMedia = [
                        'mediaBridge' => 'اتصال به کتابخانه رسانه مدیا منیجر (دکمه کتابخانه + درج مستقیم در ادیتور)',
                        'pasteUpload' => 'آپلود خودکار فایل چسبانده‌شده (Paste)',
                        'dropUpload' => 'آپلود با کشیدن و رها کردن فایل روی ادیتور (Drag &amp; Drop)',
                    ];
                    foreach ($checkboxesMedia as $key => $label):
                    ?>
                    <label>
                        <input type="hidden" name="<?php echo $key; ?>" value="0">
                        <input type="checkbox" name="<?php echo $key; ?>" value="1" <?php echo $settings[$key] === '1' ? 'checked' : ''; ?>> <?php echo $label; ?>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <section class="tr-card">
            <div class="tr-card-b">
                <h3 class="tr-section-title">دیکشنری نگارش</h3>

                <div class="tr-field">
                    <p class="tr-panel-desc" style="margin-bottom: 10px;">
                        ویرایشگر نگارش با دیکشنری داخلی جامع کار می‌کند — بیش از ۲۰۰ کلمه و عبارت پرکاربرد فارسی
                        (اصلاح ی/ک عربی، نیم‌فاصله، تنوین، افعال می/نمی) به‌صورت خودکار هنگام تایپ اصلاح می‌شوند.
                        برای فعال/غیرفعال‌کردن، تیک «تصحیح خودکار هنگام تایپ» را در بخش «کمک‌های فارسی» مدیریت کنید.
                    </p>
                </div>
            </div>
        </section>

        <section class="tr-card">
            <div class="tr-card-b">
                <h3 class="tr-section-title">تم</h3>

                <div class="tr-field">
                    <label class="tr-label">تم بصری ادیتور</label>
                    <div class="tr-radio-row">
                        <label><input type="radio" name="theme" value="auto" <?php echo $settings['theme'] === 'auto' ? 'checked' : ''; ?>> خودکار (هماهنگ با تم TypeRenew)</label>
                        <label><input type="radio" name="theme" value="light" <?php echo $settings['theme'] === 'light' ? 'checked' : ''; ?>> روشن</label>
                        <label><input type="radio" name="theme" value="dark" <?php echo $settings['theme'] === 'dark' ? 'checked' : ''; ?>> تیره</label>
                    </div>
                </div>
            </div>
        </section>

        <div class="tr-form-actions">
            <button type="submit" class="btn primary">ذخیره‌ی تنظیمات</button>
            <a href="<?php echo Text::e(\Typecho\Common::url('options-plugin.php?config=Negaresh', Helper::options()->adminUrl)); ?>" class="btn btn-link">بازگشت</a>
        </div>
    </form>
</div>

<script src="<?php echo Text::e($assetUrl . 'panel.js?' . Settings::assetRev('assets/panel.js')); ?>"></script>
