// Negaresh admin panel — small interactions
(() => {
  const $ = (sel) => document.querySelector(sel);
  if (!$) return;

  // Live label updates for range inputs
  const sliders = [
    { id: 'fontSize', suffix: 'px', target: 'fontSizeValue' },
  ];
  sliders.forEach(({ id, suffix, target }) => {
    const input = document.getElementById(id);
    const out = document.getElementById(target);
    if (!input || !out) return;
    input.addEventListener('input', () => {
      out.textContent = input.value + suffix;
    });
  });
})();
