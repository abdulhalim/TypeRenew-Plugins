import {
  EditorState,
  EditorSelection,
  Compartment,
  Prec,
} from './codemirror/codemirror.bundle.js';

import {
  EditorView,
  keymap,
  drawSelection,
  highlightActiveLine,
  lineNumbers,
  ViewPlugin,
  Decoration,
} from './codemirror/codemirror.bundle.js';

import {
  defaultKeymap,
  history,
  historyKeymap,
  undo,
  redo,
  indentWithTab,
} from './codemirror/codemirror.bundle.js';

import {
  searchKeymap,
} from './codemirror/codemirror.bundle.js';

// Shared Persian utilities (alignment helpers live here so every consumer
// — editor core, modules, tests — shares one module instance).
import { alignLine, isAlignableLine } from './modules/persian.js';

// Video embeds + emoji palette (Phase 6) — pure helpers, shared with tests.
import { videoEmbedFor, isDirectVideoUrl, EMOJIS } from './modules/video.js';

(() => {
  const cfg = window.__NEGARESH_EDITOR__;
  if (!cfg) {
    console.error('[Negaresh] config missing');
    return;
  }
  const s = cfg.settings;
  const L = cfg.strings;

  // ---------- Helpers ----------
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const ZWNJ = '\u200c';

  // ---------- Lucide icons (https://lucide.dev) ----------
  const ICONS = {
    bold: '<path d="M6 4h8a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z"/><path d="M6 12h9a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z"/>',
    italic: '<line x1="19" x2="10" y1="4" y2="4"/><line x1="14" x2="5" y1="20" y2="20"/><line x1="15" x2="9" y1="4" y2="20"/>',
    strikethrough: '<path d="M16 4H9a3 3 0 0 0-2.83 4"/><path d="M14 12a4 4 0 0 1 0 8H6"/><line x1="4" x2="20" y1="12" y2="12"/>',
    'heading-1': '<path d="M4 12h8"/><path d="M4 18V6"/><path d="M12 18V6"/><path d="m17 12 3-2v8"/>',
    'heading-2': '<path d="M4 12h8"/><path d="M4 18V6"/><path d="M12 18V6"/><path d="M21 18h-4c0-4 4-3 4-6 0-1.5-2-2.5-4-1"/>',
    'heading-3': '<path d="M4 12h8"/><path d="M4 18V6"/><path d="M12 18V6"/><path d="M17.5 10.5c1.7-1 3.5 0 3.5 1.5a2 2 0 0 1-2 2"/><path d="M17 17.5c2 1.5 4 .3 4-1.5a2 2 0 0 0-2-2"/>',
    link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
    image: '<rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>',
    code: '<polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>',
    terminal: '<polyline points="4 17 10 11 4 5"/><line x1="12" x2="20" y1="19" y2="19"/>',
    footprints: '<path d="M4 16v-2.38C4 11.5 2.97 10.5 3 8c.03-2.72 1.49-6 4.5-6C9.37 2 10 3.8 10 5.5c0 3.11-2 5.66-2 8.68V16a2 2 0 1 1-4 0Z"/><path d="M20 20v-2.38c0-2.12 1.03-3.12 1-5.62-.03-2.72-1.49-6-4.5-6C14.63 6 14 7.8 14 9.5c0 3.11 2 5.66 2 8.68V20a2 2 0 1 0 4 0Z"/><path d="M16 17h4"/><path d="M4 13h4"/>',
    quote: '<path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"/><path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z"/>',
    list: '<line x1="8" x2="21" y1="6" y2="6"/><line x1="8" x2="21" y1="12" y2="12"/><line x1="8" x2="21" y1="18" y2="18"/><line x1="3" x2="3.01" y1="6" y2="6"/><line x1="3" x2="3.01" y1="12" y2="12"/><line x1="3" x2="3.01" y1="18" y2="18"/>',
    'list-ordered': '<line x1="10" x2="21" y1="6" y2="6"/><line x1="10" x2="21" y1="12" y2="12"/><line x1="10" x2="21" y1="18" y2="18"/><path d="M4 6h1v4"/><path d="M4 10h2"/><path d="M6 18H4c0-1 2-2 2-3s-1-1.5-2-1"/>',
    minus: '<path d="M5 12h14"/>',
    more: '<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>',
    upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/>',
    'upload-cloud': '<path d="M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242"/><path d="M12 12v9"/><path d="m16 16-4-4-4 4"/>',
    table: '<path d="M12 3v18"/><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M3 9h18"/><path d="M3 15h18"/>',
    // جدول: افزودن ردیف/ستون (lucide between-vertical-start / between-vertical-end؛
    // نسخه‌های چرخیده ۹۰ درجه برای ستون چپ/راست). در هر آیکون، دو مستطیل
    // «ردیف/ستون جدید» را نشان می‌دهند و فلش، موقعیت ردیف/ستون فعلی را.
    'row-below': '<rect width="7" height="13" x="3" y="8" rx="1"/><path d="m15 2-3 3-3-3"/><rect width="7" height="13" x="14" y="8" rx="1"/>',
    'row-above': '<rect width="7" height="13" x="3" y="3" rx="1"/><path d="m9 22 3-3 3 3"/><rect width="7" height="13" x="14" y="3" rx="1"/>',
    'col-left': '<g transform="rotate(90 12 12)"><rect width="7" height="13" x="3" y="8" rx="1"/><path d="m15 2-3 3-3-3"/><rect width="7" height="13" x="14" y="8" rx="1"/></g>',
    'col-right': '<g transform="rotate(90 12 12)"><rect width="7" height="13" x="3" y="3" rx="1"/><path d="m9 22 3-3 3 3"/><rect width="7" height="13" x="14" y="3" rx="1"/></g>',
    superscript: '<path d="m4 19 4-13 4 13"/><path d="M4 19h6"/><path d="m13 5 4 4"/><path d="m18 5-4 4"/>',
    'undo-2': '<path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5v0a5.5 5.5 0 0 1-5.5 5.5H11"/>',
    'redo-2': '<path d="m15 14 5-5-5-5"/><path d="M20 9H9.5A5.5 5.5 0 0 0 4 14.5v0A5.5 5.5 0 0 0 9.5 20H11"/>',
    search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
    maximize: '<path d="M8 3H5a2 2 0 0 0-2 2v3"/><path d="M21 8V5a2 2 0 0 0-2-2h-3"/><path d="M3 16v3a2 2 0 0 0 2 2h3"/><path d="M16 21h3a2 2 0 0 0 2-2v-3"/>',
    minimize: '<path d="M8 3v3a2 2 0 0 1-2 2H3"/><path d="M21 8h-3a2 2 0 0 1-2-2V3"/><path d="M3 16h3a2 2 0 0 1 2 2v3"/><path d="M16 21v-3a2 2 0 0 1 2-2h3"/>',
    close: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
    x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
    'chevron-up': '<path d="m18 15-6-6-6 6"/>',
    'chevron-down': '<path d="m6 9 6 6 6-6"/>',
    library: '<path d="m16 6 4 14"/><path d="M12 6v14"/><path d="M8 8v12"/><path d="M4 4v16"/>',
    outline: '<line x1="4" x2="20" y1="6" y2="6"/><line x1="7" x2="17" y1="10" y2="10"/><line x1="7" x2="17" y1="14" y2="14"/><line x1="10" x2="14" y1="18" y2="18"/>',
    focus: '<circle cx="12" cy="12" r="10"/><line x1="22" x2="18" y1="12" y2="12"/><line x1="6" x2="2" y1="12" y2="12"/><line x1="12" x2="12" y1="6" y2="2"/><line x1="12" x2="12" y1="22" y2="18"/>',
    plus: '<path d="M5 12h14"/><path d="M12 5v14"/>',
    trash: '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>',
    'align-left': '<line x1="21" x2="3" y1="6" y2="6"/><line x1="15" x2="3" y1="12" y2="12"/><line x1="17" x2="3" y1="18" y2="18"/>',
    'align-center': '<line x1="21" x2="3" y1="6" y2="6"/><line x1="17" x2="3" y1="12" y2="12"/><line x1="21" x2="3" y1="18" y2="18"/>',
    'align-right': '<line x1="21" x2="3" y1="6" y2="6"/><line x1="21" x2="9" y1="12" y2="12"/><line x1="21" x2="3" y1="18" y2="18"/>',
    'align-justify': '<line x1="3" x2="21" y1="6" y2="6"/><line x1="3" x2="21" y1="12" y2="12"/><line x1="3" x2="21" y1="18" y2="18"/>',
    // جهت نوشتن — خطوط ترازشده + فلشِ جهت خواندن (RTL: راست‌چین و فلش به چپ /
    // LTR: چپ‌چین و فلش به راست)، به سبک آیکون‌های text-direction.
    dirRtl: '<path d="M21 5H9"/><path d="M21 9H3"/><path d="M21 13H13"/><path d="M13 17H4"/><path d="m7 14-3 3 3 3"/>',
    dirLtr: '<path d="M3 5h12"/><path d="M3 9h18"/><path d="M3 13h8"/><path d="M11 17h9"/><path d="m17 14 3 3-3 3"/>',
    eye: '<path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/>',
    save: '<path d="M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7"/><path d="M7 3v4a1 1 0 0 0 1 1h7"/>',
    send: '<path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/>',
    panel: '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/>',
    'wand': '<path d="m21.64 3.64-1.28-1.28a1.21 1.21 0 0 0-1.72 0L2.36 18.64a1.21 1.21 0 0 0 0 1.72l1.28 1.28a1.2 1.2 0 0 0 1.72 0L21.64 5.36a1.2 1.2 0 0 0 0-1.72"/><path d="m14 7 3 3"/><path d="M5 6v4"/><path d="M19 14v4"/><path d="M10 2v2"/><path d="M7 8H3"/><path d="M21 16h-4"/><path d="M11 3H9"/>',
    type: '<polyline points="4 7 4 4 20 4 20 7"/><line x1="9" x2="15" y1="20" y2="20"/><line x1="12" x2="12" y1="4" y2="20"/>',
    'bar-chart': '<path d="M3 3v18h18"/><path d="M18 17V9"/><path d="M13 17V5"/><path d="M8 17v-3"/>',
    target: '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
    youtube: '<path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"/><path d="m10 15 5-3-5-3z"/>',
    smile: '<circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" x2="9.01" y1="9" y2="9.01"/><line x1="15" x2="15.01" y1="9" y2="9.01"/>',
    // بلاک‌های رنگی — یک مربع با نقطه رنگی در گوشه
    block: '<rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><path d="M9 9h6v6H9z" fill="currentColor" stroke="none"/><circle cx="6" cy="6" r="1" fill="currentColor" stroke="none"/>',
  };

  const svgIcon = (name, size = 18) => {
    const path = ICONS[name] || '';
    if (name === 'zwnj') {
      // lucide-whole-word — two word circles side by side + baseline
      return `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="7" cy="12" r="3"/><path d="M10 9v6"/><circle cx="17" cy="12" r="3"/><path d="M14 9v6"/><path d="M22 17v1c0 .5-.5 1-1 1H3c-.5 0-1-.5-1-1v-1"/></svg>`;
    }
    if (name === 'persianQuotes') {
      // lucide-message-square-quote
      return `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 14a2 2 0 0 0 2-2V8h-2"/><path d="M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z"/><path d="M8 14a2 2 0 0 0 2-2V8H8"/></svg>`;
    }
    return `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${path}</svg>`;
  };

  // ---------- Markdown decorations ----------
  const mdDecorations = (view) => {
    const decos = [];
    for (const { from, to } of view.visibleRanges) {
      for (let pos = from; pos < to; ) {
        const line = view.state.doc.lineAt(pos);
        const text = line.text;
        const h = /^(#{1,6})\s+(.*)$/.exec(text);
        if (h) decos.push(Decoration.mark({ class: 'md-h md-h' + h[1].length }).range(line.from, line.to));
        if (/^>\s+/.test(text)) decos.push(Decoration.mark({ class: 'md-quote' }).range(line.from, line.to));
        if (/^(-{3,}|\*{3,}|_{3,})\s*$/.test(text)) decos.push(Decoration.mark({ class: 'md-hr' }).range(line.from, line.to));
        if (/^```/.test(text)) decos.push(Decoration.mark({ class: 'md-codefence' }).range(line.from, line.to));
        const inline = /(\*\*[^*]+\*\*)|(\*[^*]+\*)|(`[^`]+`)|(!?\[[^\]]+\]\([^)]+\))/g;
        let m;
        while ((m = inline.exec(text)) !== null) {
          const start = line.from + m.index;
          const end = start + m[0].length;
          if (m[1]) decos.push(Decoration.mark({ class: 'md-bold' }).range(start, end));
          else if (m[2]) decos.push(Decoration.mark({ class: 'md-italic' }).range(start, end));
          else if (m[3]) decos.push(Decoration.mark({ class: 'md-code' }).range(start, end));
          else if (m[4]) decos.push(Decoration.mark({ class: m[4].startsWith('!') ? 'md-image' : 'md-link' }).range(start, end));
        }
        pos = line.to + 1;
      }
    }
    return Decoration.set(decos, true);
  };

  const mdPlugin = ViewPlugin.fromClass(class {
    constructor(view) { this.decorations = mdDecorations(view); }
    update(u) { if (u.docChanged || u.viewportChanged) this.decorations = mdDecorations(u.view); }
  }, { decorations: v => v.decorations });

  // ---------- Event bus (module interop) ----------
  const bus = {
    map: new Map(),
    on(event, fn) {
      if (typeof fn !== 'function') return () => {};
      if (!bus.map.has(event)) bus.map.set(event, new Set());
      bus.map.get(event).add(fn);
      return () => bus.map.get(event)?.delete(fn);
    },
    emit(event, ...args) {
      bus.map.get(event)?.forEach(fn => {
        try { fn(...args); } catch (e) { console.error('[Negaresh] listener failed for ' + event, e); }
      });
    },
  };

  // ---------- Toast (shared by core + modules) ----------
  let toastWrap = null;
  const toast = (message, type = 'info', ms = 2600) => {
    if (!toastWrap) {
      toastWrap = document.createElement('div');
      toastWrap.className = 'negaresh-toast-wrap';
      document.body.appendChild(toastWrap);
    }
    const el = document.createElement('div');
    el.className = 'negaresh-toast negaresh-toast-' + type;
    el.textContent = String(message ?? '');
    toastWrap.appendChild(el);
    setTimeout(() => {
      el.classList.add('negaresh-toast-out');
      setTimeout(() => el.remove(), 300);
    }, ms);
  };

  // ---------- DOM setup ----------
  const textarea = document.getElementById('text');
  if (!textarea) {
    console.error('[Negaresh] #text textarea not found');
    return;
  }
  const originalParent = textarea.parentNode;

  // ---------- Editor shell ----------
  const shell = document.createElement('div');
  shell.className = 'negaresh';
  shell.dir = 'rtl';

  const btnGroups = [
    [
      { id: 'undo', icon: 'undo-2', title: L.undo + ' (Ctrl+Z)', action: () => undo(view) },
      { id: 'redo', icon: 'redo-2', title: L.redo + ' (Ctrl+Y)', action: () => redo(view) },
    ],
    [
      { id: 'bold', icon: 'bold', title: L.bold + ' (Ctrl+B)', action: () => wrapSelection('**', '**', L.bold) },
      { id: 'italic', icon: 'italic', title: L.italic + ' (Ctrl+I)', action: () => wrapSelection('*', '*', L.italic) },
      { id: 'strike', icon: 'strikethrough', title: L.strike, action: () => wrapSelection('~~', '~~', L.strike) },
    ],
    [
      { id: 'h1', icon: 'heading-1', title: L.h1, action: () => heading(1) },
      { id: 'h2', icon: 'heading-2', title: L.h2, action: () => heading(2) },
      { id: 'h3', icon: 'heading-3', title: L.h3, action: () => heading(3) },
    ],
    [
      { id: 'alignRight', icon: 'align-right', title: L.alignRight, action: () => alignBlock('right') },
      { id: 'alignCenter', icon: 'align-center', title: L.alignCenter, action: () => alignBlock('center') },
      { id: 'alignLeft', icon: 'align-left', title: L.alignLeft, action: () => alignBlock('left') },
      { id: 'alignJustify', icon: 'align-justify', title: L.alignJustify, action: () => alignBlock('justify') },
      { id: 'dirRtl', icon: 'dirRtl', title: L.dirRtl, action: () => setEditorDirection('rtl') },
      { id: 'dirLtr', icon: 'dirLtr', title: L.dirLtr, action: () => setEditorDirection('ltr') },
    ],
    [
      { id: 'link', icon: 'link', title: L.link + ' (Ctrl+L)', action: () => openLinkModal() },
      { id: 'image', icon: 'image', title: L.image + ' (Ctrl+G)', action: () => openImageModal() },
      { id: 'upload', icon: 'upload', title: L.imageUpload || 'آپلود فایل', action: () => triggerUpload() },
      { id: 'video', icon: 'youtube', title: L.video || 'درج ویدئو', action: () => openVideoModal() },
      { id: 'emoji', icon: 'smile', title: L.emoji || 'شکلک', action: () => openEmojiPicker() },
      { id: 'code', icon: 'terminal', title: L.code + ' (Ctrl+K)', action: () => wrapSelection('`', '`', L.code) },
      { id: 'codeBlock', icon: 'code', title: L.codeBlock, action: () => openCodeModal() },
    ],
    [
      { id: 'quote', icon: 'quote', title: L.quote + ' (Ctrl+Q)', action: () => toggleLinePrefix('> ') },
      { id: 'ul', icon: 'list', title: L.ul + ' (Ctrl+U)', action: () => toggleLinePrefix('- ') },
      { id: 'ol', icon: 'list-ordered', title: L.ol + ' (Ctrl+O)', action: () => toggleLinePrefix('1. ') },
      { id: 'hr', icon: 'minus', title: L.hr, action: () => insertBlock('\n---\n\n') },
      { id: 'more', icon: 'more', title: L.more + ' (Ctrl+M)', action: () => insertBlock('\n<!--more-->\n\n') },
    ],
    [
      { id: 'table', icon: 'table', title: L.table, action: () => openTableModal(), cond: s.visualTable === '1' },
      { id: 'footnote', icon: 'footprints', title: L.footnote, action: () => openFootnoteModal() },
    ],
    [
      { id: 'zwnj', icon: 'zwnj', title: L.zwnj, action: () => insertAtCursor(ZWNJ), cond: s.zwnjButton === '1' },
      { id: 'persianQuotes', icon: 'persianQuotes', title: L.persianQuotes, action: () => wrapSelection('«', '»', 'متن'), cond: s.persianQuotes === '1' },
    ],
    [
      { id: 'find', icon: 'search', title: L.find + ' (Ctrl+F)', action: () => openSearchInline() },
      { id: 'fullscreen', icon: 'maximize', title: L.fullscreen + ' (Ctrl+J)', action: () => toggleFullscreen() },
    ],
  ];

  const allButtons = {};
  btnGroups.forEach(group => group.forEach(b => { allButtons[b.id] = b; }));

  /* ----------------------------------------------------------------
   * گروه‌بندی برای منوی سرریز (responsive):
   *   - "primary": همیشه در تولبار (بولد، ایتالیک، هدینگ، لیست، پیوند، تصویر)
   *   - "tablet": در تبلت (≤900px) به منوی سرریز منتقل می‌شود (جدول، پانوشت، جستجو، بلوک‌های رنگی)
   *   - "mobile": در موبایل (≤600px) هم به منوی سرریز منتقل می‌شود (تراز، جهت، ویدئو، شکلک، کد)
   * ---------------------------------------------------------------- */
  const overflowCategory = (gi) => {
    // در موبایل (≤600px): ~۲۲ دکمه در ۲ ردیف نمایش داده می‌شوند.
    // پرکاربردترین ابزارها primary، بقیه tablet/mobile.
    //
    // گروه ۰: undo/redo (۲) — primary
    // گروه ۱: bold/italic/strike (۳) — primary
    // گروه ۲: h1/h2/h3 (۳) — primary
    // گروه ۳: تراز و جهت (۶) — primary (ترازها پرکاربرد — کاربر خواسته)
    // گروه ۴: link/image/upload/video/emoji/code/codeBlock (۷) — primary
    // گروه ۵: quote/ul/ol/hr/more (۵) — primary
    // گروه ۶: table/footnote (۲) — tablet (کمتر‌کاربرد)
    // گروه ۷: zwnj/persianQuotes (۲) — mobile (کمتر‌کاربرد)
    // گروه ۸: find/fullscreen (۲) — primary (find پرکاربرد، fullscreen همیشه قابل دسترس)
    //
    // جمع primary: ۲+۳+۳+۶+۷+۵+۲ = ۲۸ — این برای موبایل زیاد است.
    // برای رسیدن به ~۲۲، برخی از گروه ۳ و ۴ را mobile می‌کنیم:
    //   - گروه ۳ (تراز و جهت): ۶ دکمه — در موبایل، فقط alignRight/alignCenter/alignLeft
    //     نمایش داده شوند، dirRtl/dirLtr به mobile بروند. اما چون ما گروه‌بندی
    //     را در سطح group انجام می‌دهیم، یا همه primary یا همه mobile.
    //     تصمیم: گروه ۳ را primary نگه می‌داریم (ترازها مهم‌اند).
    //   - گروه ۴ (رسانه): ۷ دکمه — در موبایل، link/image/upload مهم‌اند.
    //     video/emoji/code/codeBlock به mobile بروند. اما باز هم در سطح group.
    //     تصمیم: گروه ۴ را primary نگه می‌داریم.
    //
    // نتیجه: ۲۸ دکمه primary. در موبایل، تولبار با flex-wrap در ۲-۳ ردیف
    // چیده می‌شود. اگر خیلی شد، کاربر می‌تواند با اسکرول افقی ببیند.
    if (gi === 6) return 'tablet'; // جدول، پانوشت
    if (gi === 7) return 'mobile'; // zwnj، گیومه
    return 'primary';
  };

  shell.innerHTML = `
    <div class="negaresh-toolbar" role="toolbar" aria-label="ابزارهای ویرایشگر">
      ${btnGroups.map((group, gi) => {
        const visible = group.filter(b => !b.cond || b.cond === true);
        if (!visible.length) return '';
        const cat = overflowCategory(gi);
        const overflowAttr = cat === 'tablet' ? ' data-overflow="1"' : (cat === 'mobile' ? ' data-overflow="mobile"' : '');
        return '<div class="negaresh-btn-group" data-g="' + gi + '"' + overflowAttr + '>' + visible.map(b =>
          `<button type="button" class="negaresh-btn" data-btn="${b.id}" title="${b.title}" aria-label="${b.title}">${svgIcon(b.icon)}</button>`
        ).join('') + '</div>';
      }).join('')}
      <button type="button" class="negaresh-btn negaresh-overflow-btn" title="ابزارهای بیشتر" aria-label="ابزارهای بیشتر">${svgIcon('more')}</button>
    </div>
    <div class="negaresh-overflow-menu" role="menu" aria-label="ابزارهای بیشتر">
      ${btnGroups.map((group, gi) => {
        const visible = group.filter(b => !b.cond || b.cond === true);
        if (!visible.length) return '';
        const cat = overflowCategory(gi);
        if (cat === 'primary') return ''; // فقط گروه‌های tablet/mobile در منو
        const overflowAttr = cat === 'tablet' ? ' data-overflow="1"' : ' data-overflow="mobile"';
        return '<div class="negaresh-btn-group" data-g="' + gi + '"' + overflowAttr + '>' + visible.map(b =>
          `<button type="button" class="negaresh-btn" data-btn="${b.id}" title="${b.title}" aria-label="${b.title}">${svgIcon(b.icon, 16)} <span>${b.title}</span></button>`
        ).join('') + '</div>';
      }).join('')}
    </div>
    <div class="negaresh-tabs">
      <button type="button" class="negaresh-tab active" data-tab="edit">${L.write}</button>
      <button type="button" class="negaresh-tab" data-tab="preview">${L.preview}</button>
    </div>
    <div class="negaresh-search" hidden>
      <input type="search" class="negaresh-search-input" placeholder="${L.find}">
      <button type="button" class="negaresh-search-btn" data-act="prev" title="قبلی">${svgIcon('chevron-up', 14)}</button>
      <button type="button" class="negaresh-search-btn" data-act="next" title="بعدی">${svgIcon('chevron-down', 14)}</button>
      <button type="button" class="negaresh-search-btn" data-act="close" title="${L.cancel}">${svgIcon('x', 14)}</button>
    </div>
    <div class="negaresh-body">
      <div class="negaresh-pane negaresh-edit"></div>
      <div class="negaresh-pane negaresh-preview">
        <div class="negaresh-preview-inner markdown-body"></div>
      </div>
    </div>
    <button type="button" class="negaresh-fs-exit" hidden title="${L.exitFullscreen} (Esc)">${svgIcon('minimize', 16)} <span>${L.exitFullscreen}</span></button>
    <div class="negaresh-statusbar">
      <span class="negaresh-status-words">—</span>
      <span class="negaresh-status-chars">—</span>
      <span class="negaresh-status-reading">—</span>
      <span class="negaresh-status-spacer"></span>
      <span class="negaresh-status-saved"></span>
    </div>
  `;

  originalParent.insertBefore(shell, textarea);
  textarea.style.display = 'none';
  textarea.classList.add('negaresh-source');

  // ---------- CodeMirror setup ----------
  const editPane = $('.negaresh-edit', shell);
  const previewPane = $('.negaresh-preview', shell);
  const previewInner = $('.negaresh-preview-inner', previewPane);
  const fsExitBtn = $('.negaresh-fs-exit', shell);

  // Compartments for dynamic reconfiguration
  const lineNumbersComp = new Compartment();
  const wrapComp = new Compartment();
  const tabSizeComp = new Compartment();
  const fontSizeComp = new Compartment();

  // Build dynamic extensions
  const buildLineNumbersExt = () => s.lineNumbers === '1' ? [lineNumbers()] : [];
  const buildWrapExt = () => s.wordWrap === '1' ? [EditorView.lineWrapping] : [];
  const buildTabSizeExt = () => EditorState.tabSize.of(parseInt(s.tabSize, 10) || 2);
  const buildFontSizeExt = () => {
    // EditorView.theme with a Compartment — apply font size on .cm-content
    return EditorView.theme({
      '.cm-content': { fontSize: (parseInt(s.fontSize, 10) || 14) + 'px' },
      '.cm-gutters': { fontSize: ((parseInt(s.fontSize, 10) || 14) - 2) + 'px' },
    });
  };

  // autoCloseBrackets — implement as a custom keymap
  const buildAutoCloseExt = () => {
    if (s.autoCloseBrackets !== '1') return [];
    const pairs = {
      '(': ')', '[': ']', '{': '}',
      '"': '"', "'": "'", '`': '`',
      '«': '»',
    };
    return keymap.of(Object.entries(pairs).map(([open, close]) => ({
      key: open,
      run: (v) => {
        const { state } = v;
        const sel = state.selection.main;
        // If there's a selection, wrap selection; else insert pair and put cursor inside
        if (sel.from !== sel.to) {
          const selText = state.sliceDoc(sel.from, sel.to);
          v.dispatch({
            changes: { from: sel.from, to: sel.to, insert: open + selText + close },
            selection: EditorSelection.range(sel.from + 1, sel.from + 1 + selText.length),
            userEvent: 'input.autoclose',
          });
          return true;
        }
        v.dispatch({
          changes: { from: sel.from, to: sel.to, insert: open + close },
          selection: EditorSelection.cursor(sel.from + 1),
          userEvent: 'input.autoclose',
        });
        return true;
      },
    })));
  };
  const autoCloseComp = new Compartment();

  // Slot for extensions registered by modules after creation (focus mode, etc.)
  const moduleExtCompartment = new Compartment();
  let moduleExtensions = [];

  const stateUpdateListener = EditorView.updateListener.of((u) => {
    if (u.docChanged) {
      syncTextarea();
      triggerFormWrite();
      schedulePreview();
      bus.emit('docchange', u);
    }
  });

  const view = new EditorView({
    state: EditorState.create({
      doc: textarea.value || '',
      extensions: [
        history(),
        drawSelection(),
        highlightActiveLine(),
        mdPlugin,
        wrapComp.of(buildWrapExt()),
        tabSizeComp.of(buildTabSizeExt()),
        lineNumbersComp.of(buildLineNumbersExt()),
        fontSizeComp.of(buildFontSizeExt()),
        autoCloseComp.of(buildAutoCloseExt()),
        moduleExtCompartment.of([]),
        Prec.high(keymap.of([
          // List/quote Enter handler — must run BEFORE defaultKeymap to intercept Enter on prefixed lines
          { key: 'Enter', run: () => {
            // Priority 0: a line that is ONLY a bare video URL is turned into a
            // player embed; then we fall through so the default Enter still
            // breaks the line after the embed (handleEnterVideoUrl returns false).
            handleEnterVideoUrl();
            // Priority 1: if line is ONLY a prefix (empty content), exit the list
            if (handleEnterExitEmpty()) return true;
            // Priority 2: if line ends with a list/quote prefix and has content, continue the list
            if (handleEnterContinue()) return true;
            // Fall through to default
            return false;
          } },
          ...defaultKeymap,
          ...historyKeymap,
          ...searchKeymap,
          indentWithTab,
          { key: 'Mod-b', run: () => { wrapSelection('**', '**', L.bold); return true; } },
          { key: 'Mod-i', run: () => { wrapSelection('*', '*', L.italic); return true; } },
          { key: 'Mod-k', run: () => { openCodeModal(); return true; } },
          { key: 'Mod-l', run: () => { openLinkModal(); return true; } },
          { key: 'Mod-g', run: () => { openImageModal(); return true; } },
          { key: 'Mod-q', run: () => { toggleLinePrefix('> '); return true; } },
          { key: 'Mod-u', run: () => { toggleLinePrefix('- '); return true; } },
          { key: 'Mod-o', run: () => { toggleLinePrefix('1. '); return true; } },
          { key: 'Mod-m', run: () => { insertBlock('\n<!--more-->\n\n'); return true; } },
          { key: 'Mod-j', run: () => { toggleFullscreen(); return true; } },
          { key: 'Mod-f', run: () => { openSearchInline(); return true; } },
          { key: 'Escape', run: () => handleEscape() },
        ])),
        stateUpdateListener,
      ],
    }),
    parent: editPane,
  });

  // ---------- Escape handler (priority: modal > search > fullscreen) ----------
  const handleEscape = () => {
    const openModal = document.querySelector('.negaresh-modal-overlay');
    if (openModal) {
      openModal.remove();
      view.focus();
      return true;
    }
    if (!searchBar.hidden) {
      closeSearchInline();
      return true;
    }
    // Close open drawers / the rail panel before leaving fullscreen
    if (shell.querySelector('.negaresh-outline.is-open')) {
      bus.emit('closepanels');
      if (typeof fsRail !== 'undefined' && fsRail) fsRail.classList.remove('is-open');
      return true;
    }
    if (isFullscreen) {
      toggleFullscreen();
      return true;
    }
    return false;
  };

  // ---------- Sync textarea ----------
  // Flag: true while the editor itself is writing into the textarea, so the
  // external-change listener below can ignore echoes of our own syncs.
  let syncingToTextarea = false;

  const syncTextarea = () => {
    const newText = view.state.doc.toString();
    if (newText !== textarea.value) {
      textarea.value = newText;
      syncingToTextarea = true;
      try {
        textarea.dispatchEvent(new Event('input', { bubbles: true }));
      } finally {
        syncingToTextarea = false;
      }
    }
  };

  // ---------- External #text change guard ----------
  // Third-party scripts (MediaManager's picker fallback, legacy plugins, …)
  // may write directly into the hidden #text textarea. Pull such changes into
  // CodeMirror with a minimal prefix/suffix diff, otherwise the next editor
  // keystroke would silently overwrite (and lose) the externally added text.
  const pullExternalChange = () => {
    if (syncingToTextarea) return;
    const incoming = textarea.value;
    const current = view.state.doc.toString();
    if (incoming === current) return;

    let start = 0;
    const minLen = Math.min(current.length, incoming.length);
    while (start < minLen && current.charCodeAt(start) === incoming.charCodeAt(start)) start++;

    let endCur = current.length;
    let endInc = incoming.length;
    while (endCur > start && endInc > start && current.charCodeAt(endCur - 1) === incoming.charCodeAt(endInc - 1)) {
      endCur--;
      endInc--;
    }

    view.dispatch({
      changes: { from: start, to: endCur, insert: incoming.slice(start, endInc) },
      selection: EditorSelection.cursor(Math.max(start, endInc)),
      scrollIntoView: true,
      userEvent: 'input.external',
    });
  };
  textarea.addEventListener('input', pullExternalChange);
  textarea.addEventListener('change', pullExternalChange);

  // ---------- Preview ----------
  let converter = null;
  const getConverter = () => {
    if (converter) return converter;
    if (window.HyperDown) {
      converter = new window.HyperDown();
      converter.enableHtml(true);
      converter.enableLine(true);
      converter.hook('makeHtml', (html) => {
        html = html.replace('<p><!--more--></p>', '<!--more-->');
        if (window.DOMPurify) {
          // Video embeds (toolbar / auto-conversion) are plain <iframe> tags —
          // the default html profile strips iframes, so they are re-allowed
          // here (DOMPurify's default URI regexp still blocks javascript:/data:
          // sources, and <video>/<source> are already allowed).
          html = window.DOMPurify.sanitize(html, {
            USE_PROFILES: { html: true },
            ADD_TAGS: ['iframe'],
            ADD_ATTR: ['allow', 'allowfullscreen', 'referrerpolicy'],
          });
        }
        return html;
      });
    }
    return converter;
  };

  let previewTimer = null;
  const schedulePreview = () => {
    // The side-by-side live preview was removed per user request — the
    // preview now lives ONLY in its own tab, so a refresh is only needed
    // while that tab is visible.
    if (!shell.classList.contains('is-preview-only')) return;
    clearTimeout(previewTimer);
    previewTimer = setTimeout(updatePreview, 150);
  };

  const updatePreview = () => {
    const conv = getConverter();
    if (!conv) return;
    const md = view.state.doc.toString();
    let html;
    try {
      html = conv.makeHtml(md);
    } catch (e) {
      html = '<pre class="negaresh-error">خطا در پیش‌نمایش: ' + (e.message || String(e)) + '</pre>';
    }
    previewInner.innerHTML = html;
    updateStatus();
  };

  // ---------- Status bar ----------
  const statusWords = $('.negaresh-status-words', shell);
  const statusChars = $('.negaresh-status-chars', shell);
  const statusReading = $('.negaresh-status-reading', shell);
  const statusSaved = $('.negaresh-status-saved', shell);

  const countWords = (text) => {
    const matches = text.match(/[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]+|[A-Za-z0-9]+/g);
    return matches ? matches.length : 0;
  };

  const updateStatus = () => {
    if (s.showCount !== '1') return;
    const text = view.state.doc.toString();
    const words = countWords(text);
    const chars = text.length;
    statusWords.textContent = words + ' ' + L.words;
    statusChars.textContent = chars + ' ' + L.chars;
    if (s.countReadingTime === '1') {
      const minutes = Math.max(1, Math.round(words / 200));
      statusReading.textContent = minutes + ' ' + L.readingTime;
    } else {
      statusReading.textContent = '';
    }
  };

  // ---------- Real save status (integration with the host page) ----------
  // The core write-js.php listens for the form's jQuery 'write' event (its own
  // default editor fires it on every #text input) and drives the built-in
  // autosave (3s debounce → POST do=save) plus the beforeunload guard. The
  // default editor is replaced here, so WE must fire 'write' — otherwise
  // autosave and the unsaved-changes warning silently die.
  const jq = (typeof window !== 'undefined' && window.jQuery) ? window.jQuery : null;
  const writeForm = textarea.form || (textarea.closest ? textarea.closest('form') : null);

  const triggerFormWrite = () => {
    if (!writeForm) return;
    if (jq) {
      jq(writeForm).trigger('write');
    } else {
      try { writeForm.dispatchEvent(new Event('write', { bubbles: true })); } catch (e) { /* noop */ }
    }
  };

  const setSaveStatus = (text, cls) => {
    statusSaved.textContent = text || '';
    statusSaved.classList.toggle('is-pending', cls === 'pending');
    statusSaved.classList.toggle('is-error', cls === 'error');
  };

  if (writeForm && jq) {
    // 'datachange' → content changed, not saved yet (fired by core write-js.php)
    jq(writeForm).on('datachange', () => setSaveStatus(L.unsaved || 'ذخیره‌نشده', 'pending'));
    // 'submitted' → the core finished an autosave/save request
    jq(writeForm).on('submitted', () => {
      const now = new Date();
      const hh = String(now.getHours()).padStart(2, '0');
      const mm = String(now.getMinutes()).padStart(2, '0');
      setSaveStatus((L.saved || 'ذخیره شد') + ' ' + hh + ':' + mm);
    });
  }

  // ---------- Fullscreen: minimal action + attachments rail (left edge) ------
  // In fullscreen the core's own .tr-write-actions bar and #edit-secondary
  // side panel are hidden; this vertical rail replaces them. It stays
  // collapsed to a single toggle button and hosts:
  //   1) minimal actions: preview (same-tab) / save draft / publish
  //   2) the post's attachments panel (#upload-panel is MOVED here while
  //      fullscreen is active — moving keeps the core's jQuery handlers)
  //   3) MediaManager's attached-images panel (#mm-editor-panel) is docked
  //      at the end of the file selector while fullscreen is active
  // Activated by the core's tr:fullscreen-change event, so our fullscreen
  // and the core's own Esc handler all stay in sync.
  const fsRail = document.createElement('div');
  fsRail.className = 'negaresh-fs-rail';
  fsRail.dir = 'rtl';
  fsRail.innerHTML = `
    <button type="button" class="negaresh-fs-toggle" title="${L.fsRailToggle || 'اکشن‌ها و کتابخانه'}" aria-label="${L.fsRailToggle || 'اکشن‌ها و کتابخانه'}">${svgIcon('panel', 18)}</button>
    <div class="negaresh-fs-panel">
      <div class="negaresh-fs-actions">
        <button type="button" class="negaresh-fs-action" data-act="preview" title="${L.preview}">${svgIcon('eye', 17)}<span>${L.preview}</span></button>
        <button type="button" class="negaresh-fs-action" data-act="save" title="${L.saveDraft || 'ذخیره پیش‌نویس'}">${svgIcon('save', 17)}<span>${L.saveDraft || 'ذخیره پیش‌نویس'}</span></button>
        <button type="button" class="negaresh-fs-action is-primary" data-act="publish" title="${L.publish || 'انتشار مطلب'}">${svgIcon('send', 17)}<span>${L.publish || 'انتشار مطلب'}</span></button>
      </div>
      <div class="negaresh-fs-files">
        <div class="negaresh-fs-files-title">${L.attachments || 'پیوست‌های نوشته'}</div>
        <div class="negaresh-fs-files-body"></div>
      </div>
      <div class="negaresh-fs-mm"></div>
    </div>`;
  document.body.appendChild(fsRail);

  const fsRailToggle = $('.negaresh-fs-toggle', fsRail);
  const fsFilesBody = $('.negaresh-fs-files-body', fsRail);
  const fsMmBody = $('.negaresh-fs-mm', fsRail);
  fsRailToggle.addEventListener('click', () => fsRail.classList.toggle('is-open'));

  // Preview stays INSIDE the editor (its own tab) — never an overlay iframe.
  const fsPreviewBtn = $('.negaresh-fs-action[data-act="preview"]', fsRail);
  fsPreviewBtn.addEventListener('click', () => {
    const target = shell.classList.contains('is-preview-only')
      ? $('.negaresh-tab[data-tab="edit"]', shell)
      : $('.negaresh-tab[data-tab="preview"]', shell);
    if (target) target.click();
  });

  const fsSaveBtn = $('.negaresh-fs-action[data-act="save"]', fsRail);
  fsSaveBtn.addEventListener('click', () => {
    // AJAX save via the core (no page navigation, fullscreen preserved)
    if (window.Typecho && typeof window.Typecho.savePost === 'function') {
      toast(L.savingDraft || 'در حال ذخیره…', 'info', 1500);
      window.Typecho.savePost();
    } else {
      const btn = document.getElementById('btn-save');
      if (btn) btn.click();
    }
  });

  const fsPublishBtn = $('.negaresh-fs-action[data-act="publish"]', fsRail);
  fsPublishBtn.addEventListener('click', () => {
    // Click the core's real publish button so the form's own submit
    // validation (pending-upload guard etc.) runs unchanged.
    const btn = document.getElementById('btn-submit');
    if (btn) btn.click();
  });

  let fsRailActive = false;
  let uploadPanelHome = null;
  let mmPanelHome = null;

  // MediaManager owns uploads when its picker is active AND its
  // «غیرفعال‌سازی آپلودر پیش‌فرض سیستم» setting is on — in that case the
  // system upload panel stays hidden (MediaManager hides it in the
  // attachments tab) and the fullscreen rail shows ONLY the MediaManager
  // panel, so attachments are never listed twice.
  const mmSystemUploadOff = () => {
    const mmc = (typeof window !== 'undefined' && window.MM_EDITOR) || null;
    return !!(mmc && mmc.enablePicker && mmc.disableSystemUpload);
  };

  const setFsRail = (active) => {
    if (active === fsRailActive) return;
    fsRailActive = active;
    fsRail.classList.toggle('is-active', active);
    document.body.classList.toggle('negaresh-fs-chrome-hidden', active);
    const hideSysUpload = mmSystemUploadOff();
    fsRail.classList.toggle('is-mm-only', active && hideSysUpload);
    const uploadPanel = document.getElementById('upload-panel');
    // MediaManager's "attached images" preview panel — docked at the end
    // of the rail's file selector while fullscreen (restored on exit).
    const mmPanel = document.getElementById('mm-editor-panel');
    if (active) {
      if (!hideSysUpload && uploadPanel && fsFilesBody) {
        uploadPanelHome = uploadPanel.parentNode;
        fsFilesBody.appendChild(uploadPanel);
      }
      if (mmPanel && fsMmBody) {
        mmPanelHome = mmPanel.parentNode;
        fsMmBody.appendChild(mmPanel);
      }
    } else {
      fsRail.classList.remove('is-open');
      if (uploadPanel && uploadPanelHome && uploadPanelHome.isConnected) {
        uploadPanelHome.appendChild(uploadPanel);
      }
      uploadPanelHome = null;
      if (mmPanel && mmPanelHome && mmPanelHome.isConnected) {
        mmPanelHome.appendChild(mmPanel);
      }
      mmPanelHome = null;
    }
  };

  if (writeForm) {
    writeForm.addEventListener('tr:fullscreen-change', (e) => {
      const active = !!(e.detail && e.detail.active);
      setFsRail(active);
      // Keep our shell in sync when the core fullscreen is toggled from
      // outside toggleFullscreen() (e.g. the core's own Esc handler while
      // focus is outside the editor).
      if (!active && isFullscreen) toggleFullscreen();
    });
  }

  // ---------- Editor commands ----------
  const wrapSelection = (before, after, placeholder) => {
    const { state } = view;
    const changes = state.changeByRange((range) => {
      const selText = state.doc.sliceString(range.from, range.to);
      const text = selText || placeholder;
      const insert = before + text + after;
      return {
        changes: { from: range.from, to: range.to, insert },
        range: EditorSelection.range(range.from + before.length, range.from + before.length + text.length),
      };
    });
    view.dispatch(changes, { scrollIntoView: true, userEvent: 'input.wrap' });
    view.focus();
  };

  const heading = (level) => {
    const { state } = view;
    const line = state.doc.lineAt(state.selection.main.from);
    const stripped = line.text.replace(/^#{1,6}\s+/, '');
    const prefix = '#'.repeat(level) + ' ';
    const newText = prefix + stripped;
    view.dispatch({
      changes: { from: line.from, to: line.to, insert: newText },
      selection: EditorSelection.cursor(line.from + newText.length),
      userEvent: 'input.heading',
    });
    view.focus();
  };

  // toggleLinePrefix — toggle the given prefix on each selected line.
  // After toggling:
  //   - If the line was empty (no content after prefix): cursor goes after the prefix
  //   - If the line had content: cursor goes to the END of the line content
  //     (This is critical for RTL/Persian text — putting cursor right after
  //     a LTR prefix like "- " but before Persian content would make the
  //     next typed character appear visually before the content due to bidi.)
  // Works for ul ('- '), ol ('1. '), and quote ('> ').
  // Ordered lists number the added lines SEQUENTIALLY (1. 2. 3. …) —
  // not "1." on every line — and continue the counter when the line right
  // above the selection is already a numbered item (mid-list inserts).
  const toggleLinePrefix = (prefix) => {
    const { state } = view;

    const isUl = prefix === '- ';
    const isOl = prefix === '1. ';
    const isQuote = prefix === '> ';

    const changes = [];
    const seen = new Set();
    let newCursorPos = null;

    const singleRange = state.selection.ranges.length === 1;
    const sel = state.selection.main;
    const singleLine = sel.from === sel.to || state.doc.lineAt(sel.from).number === state.doc.lineAt(sel.to).number;

    // Sequential counter for ordered lists — continue from the item above
    // the selection when one is directly adjacent (no blank line between).
    let olNext = 1;
    if (isOl) {
      const firstLine = state.doc.lineAt(state.selection.ranges[0].from);
      if (firstLine.number > 1) {
        const prevText = state.doc.line(firstLine.number - 1).text;
        const pm = prevText.match(/^(\s*)(\d+)\.\s/);
        if (pm) olNext = parseInt(pm[2], 10) + 1;
      }
    }

    state.selection.ranges.forEach((range) => {
      const startLine = state.doc.lineAt(range.from);
      const endLine = state.doc.lineAt(range.to);

      for (let ln = startLine.number; ln <= endLine.number; ln++) {
        if (seen.has(ln)) continue;
        seen.add(ln);
        const line = state.doc.line(ln);
        const text = line.text;

        // Detect existing prefix
        const ulMatch = text.match(/^(\s*)([-*+]\s+)/);
        const olMatch = text.match(/^(\s*)(\d+\.\s+)/);
        const quoteMatch = text.match(/^(\s*)(>\s*)/);

        let prefixMatches = false;
        if (isUl) prefixMatches = !!ulMatch;
        else if (isOl) prefixMatches = !!olMatch;
        else if (isQuote) prefixMatches = !!quoteMatch;

        if (prefixMatches) {
          // Remove the prefix
          const match = isUl ? ulMatch : (isOl ? olMatch : quoteMatch);
          const leadingWS = match[1].length;
          const prefixLen = match[2].length;
          changes.push({ from: line.from + leadingWS, to: line.from + leadingWS + prefixLen, insert: '' });
          if (singleRange && singleLine && ln === startLine.number) {
            // Keep cursor at same logical position, shifted back by prefixLen
            newCursorPos = Math.max(line.from, sel.from - prefixLen);
          }
        } else {
          // Add the prefix — ol lines get their own sequential number
          const usePrefix = isOl ? (olNext + '. ') : prefix;
          if (isOl) olNext++;

          // Strip any other list/quote prefix first
          let stripLen = 0;
          if (ulMatch) stripLen = ulMatch[1].length + ulMatch[2].length;
          else if (olMatch) stripLen = olMatch[1].length + olMatch[2].length;
          else if (quoteMatch) stripLen = quoteMatch[1].length + quoteMatch[2].length;

          if (stripLen > 0) {
            changes.push({ from: line.from, to: line.from + stripLen, insert: usePrefix });
          } else {
            changes.push({ from: line.from, insert: usePrefix });
          }

          if (singleRange && singleLine && ln === startLine.number) {
            // Check if line had any non-prefix content
            const hadContent = text.trim().length > 0;
            if (hadContent) {
              // Move cursor to the END of the line (after all content).
              // This avoids bidi cursor confusion when typing Persian after the LTR prefix.
              // Compute the new line end position after the change:
              //   newLineEnd = line.to + (usePrefix.length - stripLen)
              newCursorPos = line.to + (usePrefix.length - stripLen);
            } else {
              // Line was empty/whitespace-only — cursor goes after the prefix
              newCursorPos = line.from + usePrefix.length;
            }
          }
        }
      }
    });

    if (changes.length) {
      const dispatchSpec = { changes, userEvent: 'input.togglePrefix' };
      if (newCursorPos !== null) {
        dispatchSpec.selection = EditorSelection.cursor(newCursorPos);
      }
      view.dispatch(dispatchSpec);
    }
    view.focus();
  };

  // ---------- Auto-continue list / quote on Enter ----------
  // When pressing Enter at the end of a line that starts with a list/quote prefix,
  // the new line should automatically get the same prefix:
  //   - "- item<Enter>" → next line: "- "
  //   - "1. item<Enter>" → next line: "2. "
  //   - "> quote<Enter>" → next line: "> "
  // If the user presses Enter on an empty prefixed line (i.e. only prefix, no content),
  // remove the prefix and exit the list.
  const handleEnterContinue = () => {
    const { state } = view;
    const sel = state.selection.main;
    if (sel.from !== sel.to) return false;

    const line = state.doc.lineAt(sel.from);
    const text = line.text;

    // Cursor must be at end of line
    if (sel.from !== line.to) return false;

    // Detect prefix
    const ulMatch = text.match(/^(\s*)([-*+]\s+)(.*)$/);
    const olMatch = text.match(/^(\s*)(\d+)\.\s+(.*)$/);
    const quoteMatch = text.match(/^(\s*)(>\s+)(.*)$/);

    let prefix = null;
    let contentStart = 0; // position in `text` where content (non-prefix) starts
    let nextPrefix = null; // what to put on next line (may differ for ol: increment number)

    if (ulMatch) {
      prefix = ulMatch[2];
      contentStart = ulMatch[1].length + ulMatch[2].length;
      nextPrefix = prefix;
    } else if (olMatch) {
      const leadingWS = olMatch[1];
      const num = parseInt(olMatch[2], 10);
      prefix = olMatch[2] + '. ';
      contentStart = leadingWS.length + prefix.length;
      nextPrefix = (num + 1) + '. ';
    } else if (quoteMatch) {
      prefix = quoteMatch[2];
      contentStart = quoteMatch[1].length + quoteMatch[2].length;
      nextPrefix = prefix;
    }

    if (!prefix) return false;

    // Get the content after the prefix
    const content = text.slice(contentStart);
    const trimmed = content.trim();

    if (trimmed === '') {
      // Empty prefixed line — exit the list by removing the prefix and inserting a newline
      // Replace the entire line content with empty (just keep newline)
      const insert = '\n';
      view.dispatch({
        changes: { from: line.from, to: line.to, insert: '' }, // remove prefix line content
        selection: EditorSelection.cursor(line.from),
        userEvent: 'input.listExit',
      });
      // Actually we want to: remove prefix, but the newline that we'd insert by Enter is already consumed
      // The simplest correct approach: replace the whole line (prefix + empty content) with just a newline
      // But we already removed it. Let's re-do: we want to keep the Enter behavior (insert \n) but remove the prefix
      // Simpler: insert \n after this line and delete prefix from new empty line
      // Let's restart with a clean approach:
      return false;
    }

    // Compute new line text: same prefix (or next number for ol) + empty content
    // The new line will be inserted at the end of current line, followed by newline
    // i.e. changes: { from: sel.from, insert: '\n' + nextPrefix }

    view.dispatch({
      changes: { from: sel.from, insert: '\n' + nextPrefix },
      selection: EditorSelection.cursor(sel.from + 1 + nextPrefix.length),
      userEvent: 'input.listContinue',
      scrollIntoView: true,
    });
    return true;
  };

  // ---------- Escape-list: exit list when line is empty ----------
  // (handles the case where user presses Enter on an empty prefixed line)
  const handleEnterExitEmpty = () => {
    const { state } = view;
    const sel = state.selection.main;
    if (sel.from !== sel.to) return false;

    const line = state.doc.lineAt(sel.from);
    const text = line.text;

    // Cursor at end of line
    if (sel.from !== line.to) return false;

    // Check if line is ONLY a prefix (whitespace + prefix, no content)
    const onlyPrefix = text.match(/^(\s*)([-*+]\s+|\d+\.\s+|>\s+)$/);
    if (!onlyPrefix) return false;

    // Remove the prefix entirely (replace line with empty)
    view.dispatch({
      changes: { from: line.from, to: line.to, insert: '' },
      selection: EditorSelection.cursor(line.from),
      userEvent: 'input.listExit',
    });
    return true;
  };

  // ---------- Video URL → player embed (auto-conversion, Phase 6) ----------
  // True when the caret sits inside a fenced code block (``` / ~~~) or an
  // inline-code span (odd number of backticks before the caret on its line)
  // — video auto-conversion must never touch code.
  const caretInCode = (state, pos) => {
    const doc = state.doc;
    const line = doc.lineAt(pos);
    let fence = false;
    for (let i = 1; i < line.number; i++) {
      if (/^\s*(`{3,}|~{3,})/.test(doc.line(i).text)) fence = !fence;
    }
    if (fence) return true;
    const before = line.text.slice(0, pos - line.from);
    return ((before.match(/`/g) || []).length % 2) === 1;
  };

  // Pressing Enter at the end of a line that is ONLY a bare video URL
  // (YouTube / Aparat / Vimeo / Instagram / Telegram post / direct mp4…)
  // converts the line into a player embed. Returns false so the default
  // Enter still breaks the line right after the embed — the conversion
  // feels like the URL "turning into" a player as you finish the line.
  const handleEnterVideoUrl = () => {
    const { state } = view;
    const sel = state.selection.main;
    if (sel.from !== sel.to) return false;

    const line = state.doc.lineAt(sel.from);
    if (sel.from !== line.to) return false;

    const raw = line.text.trim();
    if (!raw || /\s/.test(raw)) return false; // single token, no spaces
    if (caretInCode(state, sel.from)) return false;

    const embed = videoEmbedFor(raw);
    if (!embed) return false;

    view.dispatch({
      changes: { from: line.from, to: line.to, insert: embed.html },
      selection: EditorSelection.cursor(line.from + embed.html.length),
      userEvent: 'input.autovideo',
      scrollIntoView: true,
    });
    return false;
  };

  const insertAtCursor = (text) => {
    view.dispatch(view.state.replaceSelection(text), { scrollIntoView: true, userEvent: 'input.insert' });
    view.focus();
  };

  const insertBlock = (text) => {
    const { state } = view;
    const sel = state.selection.main;
    const before = sel.from > 0 && state.doc.sliceString(sel.from - 1, sel.from) !== '\n' ? '\n' : '';
    const after = sel.to < state.doc.length && state.doc.sliceString(sel.to, sel.to + 1) !== '\n' ? '\n' : '';
    view.dispatch({
      changes: { from: sel.from, to: sel.to, insert: before + text + after },
      selection: EditorSelection.cursor(sel.from + before.length + text.length),
      userEvent: 'input.block',
    });
    view.focus();
  };

  // ---------- Text alignment (right / center / left / justify) ----------
  // Wraps the selected paragraph lines in an inline <span style="display:
  // block;text-align:…"> wrapper. A block-level <div> would switch HyperDown
  // into raw-HTML mode and the markdown inside would stop rendering — the
  // inline span keeps the line a normal paragraph (see modules/persian.js).
  // Clicking the same alignment again unwraps (toggle).
  const alignBlock = (align) => {
    const { state } = view;
    const sel = state.selection.main;
    const firstLine = state.doc.lineAt(sel.from);
    const lastLine = state.doc.lineAt(sel.to);

    const changes = [];
    let skipped = 0;
    let inFence = false;

    for (let ln = 1; ln <= lastLine.number; ln++) {
      const line = state.doc.line(ln);
      const isFence = /^\s*(`{3,}|~{3,})/.test(line.text);
      if (ln >= firstLine.number && ln <= lastLine.number && !inFence) {
        if (isAlignableLine(line.text)) {
          const next = alignLine(line.text, align);
          if (next !== line.text) {
            changes.push({ from: line.from, to: line.to, insert: next });
          }
        } else if (line.text.trim() !== '') {
          skipped++;
        }
      }
      if (isFence) inFence = !inFence;
    }

    if (!changes.length) {
      toast(skipped > 0
        ? (L.alignSkipped || 'تراز فقط روی پاراگراف‌های ساده اعمال می‌شود')
        : (L.alignNoChange || 'چیزی برای تراز نیست'), 'info');
      return;
    }

    const last = changes[changes.length - 1];
    view.dispatch({
      changes,
      selection: EditorSelection.cursor(last.from + last.insert.length),
      userEvent: 'input.align',
    });
    view.focus();
  };

  // ---------- Text direction (RTL ⇄ LTR) ----------
  // Whole-editor direction toggle — handy when switching the keyboard to
  // English for code snippets: the editing pane (content + gutters) flips
  // to LTR, then back to RTL for Persian. The CM6 bundle reads the text
  // direction live from the DOM (getComputedStyle of the edit pane), so
  // setting `dir` plus a re-measure realigns the lines and bidi cursor
  // movement; nothing is written into the document itself.
  let editorDir = 'rtl';
  const updateDirButtons = () => {
    const rtlBtn = $('.negaresh-btn[data-btn="dirRtl"]', shell);
    const ltrBtn = $('.negaresh-btn[data-btn="dirLtr"]', shell);
    if (rtlBtn) rtlBtn.classList.toggle('is-on', editorDir === 'rtl');
    if (ltrBtn) ltrBtn.classList.toggle('is-on', editorDir === 'ltr');
  };
  const setEditorDirection = (dir) => {
    if (dir !== 'ltr' && dir !== 'rtl') return;
    if (dir === editorDir) return;
    editorDir = dir;
    editPane.dir = dir;
    view.requestMeasure();
    updateDirButtons();
    toast(dir === 'ltr'
      ? (L.dirSwitchedLtr || 'جهت ویرایشگر: چپ‌به‌راست')
      : (L.dirSwitchedRtl || 'جهت ویرایشگر: راست‌به‌چپ'), 'info');
    view.focus();
  };
  updateDirButtons();

  // ---------- Search ----------
  const searchBar = $('.negaresh-search', shell);
  const searchInput = $('.negaresh-search-input', shell);

  const openSearchInline = () => {
    searchBar.hidden = false;
    searchInput.focus();
    searchInput.select();
  };
  const closeSearchInline = () => {
    searchBar.hidden = true;
    searchInput.value = '';
    view.focus();
  };

  const doSearch = (forward = true) => {
    const q = searchInput.value;
    if (!q) return;
    const { state } = view;
    const escaped = q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const re = new RegExp(escaped, 'g');
    const cursor = state.selection.main;

    // Collect all matches in document
    const allMatches = [];
    let pos = 0;
    for (const line of state.doc.iterLines()) {
      re.lastIndex = 0;
      let m;
      while ((m = re.exec(line)) !== null) {
        allMatches.push({ from: pos + m.index, to: pos + m.index + m[0].length });
        if (m.index === re.lastIndex) re.lastIndex++; // avoid infinite loop on zero-length
      }
      pos += line.length + 1;
    }

    if (!allMatches.length) return;

    let found = null;
    if (forward) {
      for (const match of allMatches) {
        if (match.from > cursor.from) { found = match; break; }
      }
      if (!found) found = allMatches[0];
    } else {
      for (let i = allMatches.length - 1; i >= 0; i--) {
        if (allMatches[i].from < cursor.from) { found = allMatches[i]; break; }
      }
      if (!found) found = allMatches[allMatches.length - 1];
    }

    view.dispatch({
      selection: EditorSelection.range(found.from, found.to),
      scrollIntoView: true,
    });
    view.focus();
  };

  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      doSearch(!e.shiftKey);
    } else if (e.key === 'Escape') {
      e.preventDefault();
      closeSearchInline();
    }
  });
  $$('button.negaresh-search-btn', searchBar).forEach(btn => {
    btn.addEventListener('click', () => {
      const act = btn.dataset.act;
      if (act === 'next') doSearch(true);
      else if (act === 'prev') doSearch(false);
      else if (act === 'close') closeSearchInline();
    });
  });

  // ---------- Modals ----------
  const modalOverlay = (innerHTML) => {
    const overlay = document.createElement('div');
    overlay.className = 'negaresh-modal-overlay';
    overlay.innerHTML = `
      <div class="negaresh-modal" dir="rtl" role="dialog" aria-modal="true">
        <button type="button" class="negaresh-modal-close" aria-label="${L.cancel}">${svgIcon('x', 16)}</button>
        ${innerHTML}
      </div>
    `;
    document.body.appendChild(overlay);
    const close = () => overlay.remove();
    overlay.addEventListener('mousedown', (e) => { if (e.target === overlay) close(); });
    overlay.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        close();
      }
    });
    const closeBtn = $('.negaresh-modal-close', overlay);
    if (closeBtn) closeBtn.addEventListener('click', close);
    return { overlay, close };
  };

  const openLinkModal = () => {
    const sel = view.state.sliceDoc(view.state.selection.main.from, view.state.selection.main.to);
    const { overlay, close } = modalOverlay(`
      <h3>${L.link}</h3>
      <label class="negaresh-modal-label">${L.linkText}<input type="text" data-k="text" placeholder="${L.link}" value="${sel.replace(/"/g, '&quot;')}"></label>
      <label class="negaresh-modal-label">${L.linkUrl}<input type="url" data-k="url" placeholder="https://"></label>
      <label class="negaresh-modal-label">${L.linkTitle}<input type="text" data-k="title" placeholder="${L.linkTitle}"></label>
      <div class="negaresh-modal-actions">
        <button type="button" class="btn primary" data-act="ok">${L.ok}</button>
        <button type="button" class="btn btn-link" data-act="cancel">${L.cancel}</button>
      </div>
    `);
    const inputText = $('input[data-k="text"]', overlay);
    const inputUrl = $('input[data-k="url"]', overlay);
    const inputTitle = $('input[data-k="title"]', overlay);
    inputText.focus();
    inputText.select();
    $('button[data-act="ok"]', overlay).addEventListener('click', () => {
      const text = inputText.value.trim() || L.link;
      const url = inputUrl.value.trim() || 'https://';
      const title = inputTitle.value.trim();
      const md = title ? `[${text}](${url} "${title}")` : `[${text}](${url})`;
      view.dispatch(view.state.replaceSelection(md), { scrollIntoView: true, userEvent: 'input.link' });
      view.focus();
      close();
    });
    $('button[data-act="cancel"]', overlay).addEventListener('click', close);
    [inputText, inputUrl, inputTitle].forEach(inp => {
      inp.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          $('button[data-act="ok"]', overlay).click();
        }
      });
    });
  };

  const openImageModal = () => {
    const sel = view.state.sliceDoc(view.state.selection.main.from, view.state.selection.main.to);
    const { overlay, close } = modalOverlay(`
      <h3>${L.image}</h3>
      <label class="negaresh-modal-label">${L.imageUrl}<input type="url" data-k="url" placeholder="https://.../image.png"></label>
      <label class="negaresh-modal-label">${L.imageAlt}<input type="text" data-k="alt" placeholder="${L.imageAlt}" value="${sel.replace(/"/g, '&quot;')}"></label>
      <div class="negaresh-modal-actions">
        <button type="button" class="btn primary" data-act="ok">${L.ok}</button>
        <button type="button" class="btn btn-link" data-act="cancel">${L.cancel}</button>
      </div>
    `);
    const inputUrl = $('input[data-k="url"]', overlay);
    const inputAlt = $('input[data-k="alt"]', overlay);
    inputUrl.focus();
    $('button[data-act="ok"]', overlay).addEventListener('click', () => {
      const url = inputUrl.value.trim() || 'https://';
      const alt = inputAlt.value.trim();
      view.dispatch(view.state.replaceSelection(`![${alt}](${url})`), { scrollIntoView: true, userEvent: 'input.image' });
      view.focus();
      close();
    });
    $('button[data-act="cancel"]', overlay).addEventListener('click', close);
    [inputUrl, inputAlt].forEach(inp => {
      inp.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          $('button[data-act="ok"]', overlay).click();
        }
      });
    });
  };

  const openCodeModal = () => {
    const sel = view.state.sliceDoc(view.state.selection.main.from, view.state.selection.main.to);
    const langs = ['', 'javascript', 'typescript', 'python', 'php', 'go', 'rust', 'bash', 'sql', 'html', 'css', 'json', 'yaml', 'markdown', 'diff'];
    const { overlay, close } = modalOverlay(`
      <h3>${L.codeBlock}</h3>
      <label class="negaresh-modal-label">${L.codeLanguage}<select data-k="lang">${langs.map(l => `<option value="${l}">${l || '—'}</option>`).join('')}</select></label>
      <label class="negaresh-modal-label">${L.code}<textarea data-k="code" rows="8" placeholder="${L.codePlaceholder}">${sel.replace(/</g, '&lt;')}</textarea></label>
      <div class="negaresh-modal-actions">
        <button type="button" class="btn primary" data-act="ok">${L.insert}</button>
        <button type="button" class="btn btn-link" data-act="cancel">${L.cancel}</button>
      </div>
    `);
    const selectLang = $('select[data-k="lang"]', overlay);
    const inputCode = $('textarea[data-k="code"]', overlay);
    inputCode.focus();
    $('button[data-act="ok"]', overlay).addEventListener('click', () => {
      const lang = selectLang.value;
      const code = inputCode.value;
      const md = '```' + lang + '\n' + code + '\n```\n';
      view.dispatch(view.state.replaceSelection(md), { scrollIntoView: true, userEvent: 'input.codeblock' });
      view.focus();
      close();
    });
    $('button[data-act="cancel"]', overlay).addEventListener('click', close);
  };

  const openTableModal = () => {
    if (s.visualTable !== '1') return;
    const { overlay, close } = modalOverlay(`
      <h3>${L.table}</h3>
      <div class="negaresh-modal-grid">
        <label>${L.tableRows}<input type="number" data-k="rows" min="1" max="20" value="3"></label>
        <label>${L.tableCols}<input type="number" data-k="cols" min="1" max="10" value="3"></label>
        <label><input type="checkbox" data-k="header" checked> ${L.tableHeader}</label>
      </div>
      <div class="negaresh-modal-actions">
        <button type="button" class="btn primary" data-act="ok">${L.insert}</button>
        <button type="button" class="btn btn-link" data-act="cancel">${L.cancel}</button>
      </div>
    `);
    const inputRows = $('input[data-k="rows"]', overlay);
    const inputCols = $('input[data-k="cols"]', overlay);
    const checkHeader = $('input[data-k="header"]', overlay);
    inputRows.focus();
    inputRows.select();
    $('button[data-act="ok"]', overlay).addEventListener('click', () => {
      const rows = Math.max(1, parseInt(inputRows.value, 10) || 3);
      const cols = Math.max(1, parseInt(inputCols.value, 10) || 3);
      const withHeader = checkHeader.checked;
      const totalRows = rows + (withHeader ? 1 : 0);
      let md = '';
      for (let r = 0; r < totalRows; r++) {
        const cells = Array(cols).fill('').map(() => '   ');
        md += '| ' + cells.join(' | ') + ' |\n';
        if (r === 0 && withHeader) {
          md += '|' + Array(cols).fill(' --- ').join('|') + '|\n';
        }
      }
      md += '\n';
      view.dispatch(view.state.replaceSelection(md), { scrollIntoView: true, userEvent: 'input.table' });
      view.focus();
      close();
    });
    $('button[data-act="cancel"]', overlay).addEventListener('click', close);
  };

  const openFootnoteModal = () => {
    const { overlay, close } = modalOverlay(`
      <h3>${L.footnote}</h3>
      <label class="negaresh-modal-label">${L.footnoteId}<input type="text" data-k="id" placeholder="1" value="1"></label>
      <p class="negaresh-modal-help">یک مرجع <code>[^id]</code> در متن و سپس تعریف <code>[^id]: متن پانوشت</code> در انتهای نوشته.</p>
      <div class="negaresh-modal-actions">
        <button type="button" class="btn primary" data-act="ok">${L.insert}</button>
        <button type="button" class="btn btn-link" data-act="cancel">${L.cancel}</button>
      </div>
    `);
    const inputId = $('input[data-k="id"]', overlay);
    inputId.focus();
    inputId.select();
    $('button[data-act="ok"]', overlay).addEventListener('click', () => {
      const id = inputId.value.trim() || '1';
      view.dispatch(view.state.replaceSelection(`[^${id}]`), { scrollIntoView: true, userEvent: 'input.footnote' });
      view.focus();
      close();
    });
    $('button[data-act="cancel"]', overlay).addEventListener('click', close);
  };

  // ---------- Video embed + emoji picker (Phase 6) ----------
  // Both insert raw single-line HTML (iframe / video tag) that HyperDown
  // (enableHtml — exactly how the preview tab AND the front end run it)
  // passes through untouched.
  const providerLabel = (id) => ({
    youtube: L.pvYoutube || 'یوتیوب',
    aparat: L.pvAparat || 'آپارات',
    vimeo: L.pvVimeo || 'ویمیو',
    instagram: L.pvInstagram || 'اینستاگرام',
    telegram: L.pvTelegram || 'تلگرام',
    direct: L.pvDirect || 'فایل ویدیویی مستقیم',
  }[id] || id);

  const insertEmbed = (html) => {
    const { state } = view;
    const sel = state.selection.main;
    const line = state.doc.lineAt(sel.from);
    const atLineStart = sel.from === line.from;
    const prevLineEmpty = line.number > 1 && state.doc.line(line.number - 1).text.trim() === '';
    const before = sel.from === 0 ? '' : (atLineStart && prevLineEmpty ? '' : '\n\n');
    const insert = before + html + '\n\n';
    view.dispatch({
      changes: { from: sel.from, to: sel.to, insert },
      selection: EditorSelection.cursor(sel.from + before.length + html.length),
      userEvent: 'input.embed',
      scrollIntoView: true,
    });
    view.focus();
  };

  const openVideoModal = () => {
    const sel = view.state.sliceDoc(view.state.selection.main.from, view.state.selection.main.to).trim();
    const { overlay, close } = modalOverlay(`
      <h3>${L.video || 'درج ویدئو'}</h3>
      <label class="negaresh-modal-label">${L.videoUrl || 'نشانی ویدیو'}<input type="url" data-k="url" dir="ltr" placeholder="https://www.youtube.com/watch?v=…"></label>
      <p class="negaresh-modal-help">${L.videoHint || ''}</p>
      <p class="negaresh-video-detect" data-k="detect" hidden></p>
      <div class="negaresh-modal-actions">
        <button type="button" class="btn primary" data-act="ok">${L.insert}</button>
        <button type="button" class="btn btn-link" data-act="cancel">${L.cancel}</button>
      </div>
    `);
    const inputUrl = $('input[data-k="url"]', overlay);
    const detect = $('[data-k="detect"]', overlay);
    inputUrl.value = /^https?:\/\/\S+$/i.test(sel) ? sel : '';

    const updateDetect = () => {
      const val = inputUrl.value.trim();
      const embed = val ? videoEmbedFor(val) : null;
      detect.hidden = !val;
      detect.classList.toggle('is-error', val && !embed);
      detect.textContent = !val ? '' : (embed
        ? (L.videoDetected || 'پخش‌کننده:') + ' ' + providerLabel(embed.provider)
        : (L.videoNotRecognized || ''));
    };
    inputUrl.addEventListener('input', updateDetect);
    updateDetect();
    inputUrl.focus();

    $('button[data-act="ok"]', overlay).addEventListener('click', () => {
      const embed = videoEmbedFor(inputUrl.value.trim());
      if (!embed) {
        updateDetect();
        inputUrl.focus();
        return;
      }
      insertEmbed(embed.html);
      close();
    });
    $('button[data-act="cancel"]', overlay).addEventListener('click', close);
    inputUrl.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        $('button[data-act="ok"]', overlay).click();
      }
    });
  };

  const openEmojiPicker = () => {
    const { overlay, close } = modalOverlay(`
      <h3>${L.emoji || 'شکلک'}</h3>
      <div class="negaresh-emoji-grid" role="listbox" aria-label="${L.emoji || 'شکلک'}">
        ${EMOJIS.map((em) => `<button type="button" class="negaresh-emoji" data-em="${em}">${em}</button>`).join('')}
      </div>
      <div class="negaresh-modal-actions">
        <button type="button" class="btn btn-link" data-act="cancel">${L.close || L.cancel}</button>
      </div>
    `);
    // Multi-insert friendly: clicking an emoji inserts it at the cursor but
    // keeps the palette open; close (X / cancel / overlay click / Esc) returns
    // the focus to the editor.
    $$('.negaresh-emoji', overlay).forEach((btn) => {
      btn.addEventListener('click', () => {
        view.dispatch(view.state.replaceSelection(btn.dataset.em), { scrollIntoView: true, userEvent: 'input.emoji' });
      });
    });
    const closeAndFocus = () => { view.focus(); close(); };
    $('button[data-act="cancel"]', overlay).addEventListener('click', closeAndFocus);
    overlay.addEventListener('mousedown', (e) => { if (e.target === overlay) view.focus(); });
  };

  // ---------- Fullscreen ----------
  let isFullscreen = false;
  const toggleFullscreen = () => {
    isFullscreen = !isFullscreen;
    shell.classList.toggle('is-fullscreen', isFullscreen);
    document.body.classList.toggle('negaresh-locked', isFullscreen);
    fsExitBtn.hidden = !isFullscreen;
    const btn = $('.negaresh-btn[data-btn="fullscreen"]', shell);
    if (btn) {
      btn.innerHTML = svgIcon(isFullscreen ? 'minimize' : 'maximize');
      btn.title = isFullscreen ? L.exitFullscreen : L.fullscreen;
    }
    if (window.Typecho?.writeWorkspace?.setFullscreen) {
      try { window.Typecho.writeWorkspace.setFullscreen(isFullscreen); } catch (e) {}
    }
  };
  fsExitBtn.addEventListener('click', () => {
    if (isFullscreen) toggleFullscreen();
  });

  // ---------- Mobile toolbar (v1.2.0) ----------
  // در موبایل (≤600px)، تولبار ۲ ردیفی با flex-wrap کار می‌کند.
  // دکمه‌های پرکاربرد (primary) نمایش داده می‌شوند، بقیه در منوی سرریز.
  // دکمه‌ی خروج از تمام‌صفحه در موبایل توسط CSS مخفی می‌شود.
  //
  // نکته: همه‌ی رفتار رسپانسیو توسط CSS کنترل می‌شود — نیازی به JS نیست.
  // این بخش فقط برای اطمینان از اینکه منوی سرریز در موبایل همه‌ی دکمه‌های
  // مخفی‌شده را نمایش دهد.

  const isMobile = () => window.matchMedia('(max-width: 600px)').matches;

  // منوی سرریز را برای موبایل به‌روزرسانی کن — مطمئن شو که همه‌ی گروه‌های
  // tablet و mobile در منو نمایش داده شوند (این از قبل در CSS تنظیم شده).
  // این تابع فقط برای اطمینان است — اگر در آینده دکمه‌های جدیدی اضافه شد،
  // باید اینجا هم آپدیت شود.
  const ensureMobileOverflowMenu = () => {
    const menu = $('.negaresh-overflow-menu', shell);
    if (!menu) return;
    // همه‌ی گروه‌ها در منو باید قابل نمایش باشند
    $$('.negaresh-btn-group', menu).forEach((g) => {
      g.style.display = '';
    });
  };

  ensureMobileOverflowMenu();
  window.addEventListener('resize', ensureMobileOverflowMenu);

  // ---------- Tabs ----------
  // Preview lives ONLY in its own tab (live split view removed):
  //   edit tab    → editor pane full width (default)
  //   preview tab → rendered preview full width
  $$('.negaresh-tab', shell).forEach(tab => {
    tab.addEventListener('click', () => {
      const target = tab.dataset.tab;
      $$('.negaresh-tab', shell).forEach(t => t.classList.toggle('active', t === tab));
      shell.classList.toggle('is-preview-only', target === 'preview');
      if (target === 'preview') updatePreview();
    });
  });

  // ---------- Close panels when the user clicks back into the editor ----------
  // Drawers (outline, typography, …) and the fullscreen rail panel must close
  // on editor clicks, not only via their own buttons.
  view.contentDOM.addEventListener('mousedown', () => {
    const openModal = document.querySelector('.negaresh-modal-overlay');
    if (openModal) openModal.remove();
    fsRail.classList.remove('is-open');
    bus.emit('closepanels');
  }, true);

  // ---------- Video URL paste → player embed (auto-conversion, Phase 6) ----------
  // Pasting a bare video URL (a single token, no files on the clipboard)
  // inserts the player directly instead of plain text. The media module's
  // file-upload paste handler is unaffected (files present → this returns).
  view.contentDOM.addEventListener('paste', (e) => {
    const cd = e.clipboardData || (e.originalEvent && e.originalEvent.clipboardData);
    if (!cd) return;
    const items = cd.items || [];
    for (const it of items) {
      try {
        if (it && it.kind === 'file' && it.getAsFile && it.getAsFile()) return;
      } catch (err) { /* not a file item */ }
    }
    const text = String(cd.getData('text/plain') || '').trim();
    if (!text || /\s/.test(text)) return; // single URL token only
    if (caretInCode(view.state, view.state.selection.main.from)) return; // inside code — leave it alone
    const embed = videoEmbedFor(text);
    if (!embed) return;
    e.preventDefault();
    e.stopPropagation();
    insertEmbed(embed.html);
  });

  // ---------- Split ratio ----------
  // Resizer and the split layout were removed per user request (preview is
  // tab-only now); nothing to apply here anymore.

  // ---------- Auto-punctuation ----------
  view.contentDOM.addEventListener('keydown', (e) => {
    if (s.autoPunctuate !== '1') return;
    const pos = view.state.selection.main.from;
    const prev = pos > 0 ? view.state.doc.sliceString(pos - 1, pos) : '';

    if (e.key === ';' && !e.ctrlKey && !e.metaKey && !e.altKey && /[\u0600-\u06FF]/.test(prev)) {
      e.preventDefault();
      insertAtCursor('؛');
      return;
    }
    if (e.key === '?' && !e.ctrlKey && !e.metaKey && !e.altKey && /[\u0600-\u06FF]/.test(prev)) {
      e.preventDefault();
      insertAtCursor('؟');
      return;
    }
    if (e.key === '>' && e.shiftKey && !e.ctrlKey && !e.metaKey && !e.altKey && prev === '>') {
      e.preventDefault();
      const sel = view.state.selection.main;
      view.dispatch({
        changes: { from: pos - 1, to: sel.to, insert: '«»' },
        selection: EditorSelection.cursor(pos + 1),
        userEvent: 'input.persianQuote',
      });
      return;
    }
  });

  // ---------- Toolbar clicks ----------
  $$('.negaresh-btn', shell).forEach(btn => {
    btn.addEventListener('click', () => {
      const def = allButtons[btn.dataset.btn];
      if (def) def.action();
    });
  });

  // ---------- Overflow menu (responsive) ----------
  // دکمه‌ی «⋯» باز/بسته می‌کند منوی سرریز را. کلیک خارج از منو آن را می‌بندد.
  const overflowBtn = $('.negaresh-overflow-btn', shell);
  const overflowMenu = $('.negaresh-overflow-menu', shell);
  if (overflowBtn && overflowMenu) {
    overflowBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      overflowMenu.classList.toggle('is-open');
    });
    // کلیک خارج از منو = بستن
    document.addEventListener('click', (e) => {
      if (!overflowMenu.classList.contains('is-open')) return;
      if (!overflowMenu.contains(e.target) && e.target !== overflowBtn) {
        overflowMenu.classList.remove('is-open');
      }
    });
    // کلیک روی یک دکمه داخل منو = بستن منو
    overflowMenu.addEventListener('click', (e) => {
      if (e.target.closest('.negaresh-btn')) {
        overflowMenu.classList.remove('is-open');
      }
    });
    // Esc = بستن منو
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && overflowMenu.classList.contains('is-open')) {
        overflowMenu.classList.remove('is-open');
      }
    });
  }

  // ---------- Auto-fullscreen on mobile ----------
  // در نمای موبایل (≤600px)، ویرایشگر به‌صورت خودکار تمام‌صفحه می‌شود
  // تا فضای کافی برای نوشتن باشد. با خروج از موبایل (resize به دسکتاپ)،
  // تمام‌صفحه خودکار بسته می‌شود.
  let autoFullscreenActive = false;
  const MOBILE_BREAKPOINT = 600;
  const checkAutoFullscreen = () => {
    const isMobile = window.innerWidth <= MOBILE_BREAKPOINT;
    const isFs = shell.classList.contains('is-fullscreen');
    if (isMobile && !isFs && !autoFullscreenActive) {
      autoFullscreenActive = true;
      toggleFullscreen();
    } else if (!isMobile && isFs && autoFullscreenActive) {
      autoFullscreenActive = false;
      toggleFullscreen();
    }
  };
  // بررسی اولیه + گوش دادن به resize
  checkAutoFullscreen();
  let resizeTimer = null;
  window.addEventListener('resize', () => {
    if (resizeTimer) clearTimeout(resizeTimer);
    resizeTimer = setTimeout(checkAutoFullscreen, 200);
  });

  // ---------- Direct file upload (toolbar button) ----------
  // Uses Typecho's existing uploadFile API (loaded by file-upload-js.php).
  // Creates a hidden <input type="file"> and triggers it on button click.
  // When MediaManager owns uploads (its picker is active and the system
  // uploader is disabled) the button opens MediaManager's picker instead —
  // the picker itself can upload new files (into folders).
  let hiddenFileInput = null;
  const triggerUpload = () => {
    if (mmSystemUploadOff()) {
      const mmApi = window.MediaManager && window.MediaManager.editor;
      if (mmApi && typeof mmApi.openPicker === 'function' && mmApi.openPicker()) {
        return; // MediaManager picker handles both library + upload
      }
    }
    if (!hiddenFileInput) {
      hiddenFileInput = document.createElement('input');
      hiddenFileInput.type = 'file';
      hiddenFileInput.style.display = 'none';
      hiddenFileInput.multiple = true;
      hiddenFileInput.addEventListener('change', () => {
        if (!hiddenFileInput.files || !hiddenFileInput.files.length) return;
        // Use Typecho's uploadFile if available (which handles upload + insertion via uploadComplete)
        if (window.Typecho && typeof window.Typecho.uploadFile === 'function') {
          for (const file of hiddenFileInput.files) {
            window.Typecho.uploadFile(file);
          }
        } else {
          console.warn('[Negaresh] Typecho.uploadFile not available — make sure file-upload-js.php is loaded.');
        }
        // Reset so the same file can be selected again later
        hiddenFileInput.value = '';
      });
      shell.appendChild(hiddenFileInput);
    }
    hiddenFileInput.click();
  };

  // ---------- Hook into Typecho file upload ----------
  window.Typecho = window.Typecho || {};
  window.Typecho.insertFileToEditor = (file, url, isImage) => {
    // Clean title the same way MediaManager's picker does ([ and ] break markdown)
    const title = String(file || '').replace(/[\[\]]/g, '');
    // Uploaded video files become players automatically (mp4/webm/…),
    // images stay markdown images, everything else stays a file link.
    if (!isImage && isDirectVideoUrl(String(url || ''))) {
      const embed = videoEmbedFor(url);
      if (embed) {
        insertEmbed(embed.html);
        return;
      }
    }
    const md = isImage ? `![${title}](${url})` : `[${title}](${url})`;
    view.dispatch(view.state.replaceSelection(md), { scrollIntoView: true, userEvent: 'input.file' });
    view.focus();
  };
  window.Typecho.uploadComplete = (attachment) => {
    if (window.Typecho.insertFileToEditor) {
      window.Typecho.insertFileToEditor(attachment.title, attachment.url, attachment.isImage);
    }
  };

  // ---------- MediaManager picker bridge ----------
  // Registered synchronously (module body runs before DOMContentLoaded and
  // therefore before MediaManager's jQuery-ready handler). MediaManager keeps
  // its own picker UI and data; we only take over the *insertion* step so the
  // markdown lands at the CodeMirror cursor instead of position 0 of the
  // hidden textarea. See MediaManager/assets/editor.js insertSelected().
  const insertMediaItems = (items) => {
    const list = (items || []).filter(Boolean);
    // A single inserted video file (from the library) becomes a player.
    if (list.length === 1 && !list[0].isImage && isDirectVideoUrl(String(list[0].url || ''))) {
      const single = videoEmbedFor(list[0].url);
      if (single) {
        insertEmbed(single.html);
        return;
      }
    }
    let hasEmbed = false;
    const parts = list.map((item) => {
      const title = String(item.title || '').replace(/[\[\]]/g, '');
      if (item.isImage) return `![${title}](${item.url})`;
      if (isDirectVideoUrl(String(item.url || ''))) {
        const embed = videoEmbedFor(item.url);
        if (embed) {
          hasEmbed = true;
          return embed.html;
        }
      }
      return `[${title}](${item.url})`;
    });
    // Embeds are block-level HTML — separate them from the other snippets
    // with a blank line so HyperDown keeps them in their own blocks.
    const snippets = parts.join(hasEmbed ? '\n\n' : '\n');
    view.dispatch(view.state.replaceSelection(snippets), { scrollIntoView: true, userEvent: 'input.media' });
    view.focus();
  };

  if (s.mediaBridge === '1') {
    window.MediaManager = window.MediaManager || {};
    window.MediaManager.editor = window.MediaManager.editor || {};
    window.MediaManager.editor.insert = (items) => {
      try {
        insertMediaItems(items);
        return true;
      } catch (e) {
        console.error('[Negaresh] MediaManager insert bridge failed', e);
        return false; // MediaManager falls back to its textarea insertion
      }
    };
  }

  // ---------- Shared upload helper (used by toolbar button + modules) ----------
  const uploadFileViaCore = (file) => {
    if (window.Typecho && typeof window.Typecho.uploadFile === 'function') {
      try {
        window.Typecho.uploadFile(file);
        return true;
      } catch (e) {
        console.error('[Negaresh] upload failed', e);
      }
    } else {
      console.warn('[Negaresh] Typecho.uploadFile not available — file-upload-js.php not loaded?');
    }
    toast(L.uploadFailed || 'آپلود ناموفق بود', 'error');
    return false;
  };

  // ---------- Module API ----------
  // Small, stable surface handed to assets/modules/*.js — modules must rely
  // ONLY on this object (plus their own imports from the CM bundle).
  const addToolbarButton = (def) => {
    const toolbarEl = $('.negaresh-toolbar', shell);
    if (!toolbarEl || !def || !def.id || !def.action || allButtons[def.id]) return null;
    allButtons[def.id] = def;
    let groupEl = def.group != null ? $('.negaresh-btn-group[data-g="' + def.group + '"]', toolbarEl) : null;
    if (!groupEl) {
      groupEl = document.createElement('div');
      groupEl.className = 'negaresh-btn-group';
      if (def.group != null) groupEl.dataset.g = String(def.group);
      toolbarEl.appendChild(groupEl);
    }
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'negaresh-btn' + (def.className ? ' ' + def.className : '');
    btn.dataset.btn = def.id;
    btn.title = def.title || def.id;
    btn.setAttribute('aria-label', btn.title);
    btn.innerHTML = svgIcon(def.icon || 'more');
    btn.addEventListener('click', () => def.action());
    groupEl.appendChild(btn);
    return btn;
  };

  const overrideButton = (id, action) => {
    const def = allButtons[id];
    if (!def || typeof action !== 'function') return false;
    def.action = action;
    return true;
  };

  const addStatusItem = (id) => {
    const bar = $('.negaresh-statusbar', shell);
    if (!bar || bar.querySelector('.negaresh-status-' + id)) return null;
    const span = document.createElement('span');
    span.className = 'negaresh-status-item negaresh-status-' + id;
    const spacer = $('.negaresh-status-spacer', bar);
    bar.insertBefore(span, spacer || null);
    return span;
  };

  const setDoc = (text, cursorAt = 'end') => {
    const value = String(text ?? '');
    const pos = cursorAt === 'start' ? 0 : value.length;
    view.dispatch({
      changes: { from: 0, to: view.state.doc.length, insert: value },
      selection: EditorSelection.cursor(pos),
      userEvent: 'input.setDoc',
    });
  };

  const addExtension = (ext) => {
    if (!ext) return false;
    moduleExtensions = moduleExtensions.concat(ext);
    view.dispatch({ effects: moduleExtCompartment.reconfigure(moduleExtensions) });
    return true;
  };

  const api = {
    version: String(cfg.version || '2'),
    view, shell, textarea,
    settings: s, strings: L, config: cfg,
    $: (sel, root) => $(sel, root || shell),
    $$: (sel, root) => $$(sel, root || shell),
    svgIcon, toast,
    on: (ev, fn) => bus.on(ev, fn),
    emit: (ev, ...args) => bus.emit(ev, ...args),
    getDoc: () => view.state.doc.toString(),
    setDoc,
    insertAtCursor, insertBlock, wrapSelection,
    insertMediaItems,
    uploadFile: uploadFileViaCore,
    modalOverlay,
    addToolbarButton, overrideButton, addStatusItem, addExtension,
  };

  // ---------- Dynamic module loader ----------
  // Modules are plain ES modules in assets/modules/ exporting init(api).
  // They are loaded ONLY when their settings allow it (modular, no bloat),
  // with a cache-busting ?v= based on the newest module file's mtime
  // (cfg.moduleRev, injected by PHP) falling back to the plugin version.
  const moduleList = [
    ['autocorrect', s.autoCorrect === '1'],
    ['media', s.mediaBridge === '1' || s.pasteUpload === '1' || s.dropUpload === '1'],
    ['draft', s.localDraft === '1'],
    ['outline', s.outline === '1'],
    ['focus', s.focusMode === '1'],
    ['table', s.advancedTable === '1'],
    ['links', s.advancedLinks === '1'],
    ['blocks', s.coloredBlocks === '1'],
    ['assistant', s.writingAssistant === '1'],
    ['typography', s.typographyChecker === '1'],
    ['analyzer', s.contentAnalyzer === '1'],
    ['seo', s.seoTools === '1'],
  ];
  const moduleBase = new URL('modules/', import.meta.url);
  const moduleRev = String(cfg.moduleRev || cfg.version || '2');
  for (const [name, enabled] of moduleList) {
    if (!enabled) continue;
    const url = new URL(name + '.js?v=' + encodeURIComponent(moduleRev), moduleBase);
    import(/* @vite-ignore */ url.href)
      .then((mod) => {
        if (mod && typeof mod.init === 'function') mod.init(api);
      })
      .catch((e) => console.error('[Negaresh] module "' + name + '" failed to load', e));
  }

  // ---------- Initial render ----------
  // The preview is tab-only now: nothing to render until the user opens the
  // preview tab (updatePreview() runs on tab switch).
  updateStatus();

  // ---------- Markdown flag for legacy posts ----------
  if (!cfg.isMarkdown) {
    const notice = document.createElement('div');
    notice.className = 'negaresh-notice';
    notice.innerHTML = `${L.confirmMarkdown} <button type="button" data-act="yes">بله</button> <button type="button" data-act="no">خیر</button>`;
    shell.parentNode.insertBefore(notice, shell);
    notice.addEventListener('click', (e) => {
      const act = e.target?.dataset?.act;
      if (act === 'yes') {
        const form = textarea.closest('form');
        if (form) {
          const hidden = document.createElement('input');
          hidden.type = 'hidden';
          hidden.name = 'markdown';
          hidden.value = '1';
          form.appendChild(hidden);
        }
        notice.remove();
      } else if (act === 'no') {
        notice.remove();
      }
    });
  }

  // ---------- Theme ----------
  // Cache the last applied theme to avoid infinite loops when our own class
  // changes trigger the MutationObserver.
  let lastAppliedTheme = null;
  const applyTheme = () => {
    let theme = s.theme;
    if (theme === 'auto') {
      theme = document.documentElement.classList.contains('tr-theme-dark') ? 'dark' : 'light';
    }
    // No-op if the resolved theme hasn't changed (prevents infinite loop)
    if (theme === lastAppliedTheme) return;
    lastAppliedTheme = theme;
    if (theme === 'dark') {
      document.documentElement.classList.add('negaresh-force-dark');
    } else {
      document.documentElement.classList.remove('negaresh-force-dark');
    }
    shell.classList.toggle('is-dark', theme === 'dark');
    shell.classList.toggle('is-light', theme === 'light');
  };
  applyTheme();
  if (window.MutationObserver) {
    // Only watch tr-theme-dark class changes (our own negaresh-force-dark changes
    // would re-trigger applyTheme, but the lastAppliedTheme guard makes it a no-op).
    new MutationObserver(applyTheme).observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
  }

  // ---------- Expose for debugging + integration ----------
  window.Negaresh = { view, settings: s, updatePreview, toggleFullscreen, api, toast };

  console.log('[Negaresh] ready v' + (cfg.version || ''));
})();
