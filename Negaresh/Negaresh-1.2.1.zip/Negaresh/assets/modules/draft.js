/**
 * Negaresh draft module — Phase 2 (interval-based since v1.1)
 * ------------------------------------------------------------------
 *  - Local draft recovery (localStorage): snapshots are taken on a fixed
 *    interval (default: every 5 minutes — user-configurable via the
 *    «فاصله‌ی ذخیره‌ی پیش‌نویس محلی» setting) and are offered for
 *    restoration after a crash / accidental close.
 *  - EMERGENCY snapshot: when the page is being left (pagehide /
 *    beforeunload) with unsaved changes, one last snapshot is written
 *    synchronously so nothing is lost between intervals.
 *  - Ctrl/Cmd+S → the core Typecho.savePost() (same as the default editor).
 *  - A subtle status item shows when the local snapshot was taken.
 *
 * Server autosave itself is NOT implemented here — it already exists in the
 * core write-js.php and is revived by the editor firing the 'write' event
 * (see editor.js stateUpdateListener). This module is the extra safety net
 * for the window between autosaves / when autosave is disabled.
 */

const LS_PREFIX = 'negaresh:draft:';
const MAX_AGE_MS = 14 * 24 * 60 * 60 * 1000; // prune snapshots older than 14d

const readSnapshot = (key) => {
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return null;
    const data = JSON.parse(raw);
    if (!data || typeof data.x !== 'string') return null;
    return data;
  } catch (e) {
    return null;
  }
};

const writeSnapshot = (key, data) => {
  try {
    window.localStorage.setItem(key, JSON.stringify(data));
    return true;
  } catch (e) {
    return false; // quota / private mode — silently skip
  }
};

const dropSnapshot = (key) => {
  try { window.localStorage.removeItem(key); } catch (e) { /* noop */ }
};

const pruneStaleSnapshots = () => {
  try {
    const now = Date.now();
    const stale = [];
    for (let i = 0; i < window.localStorage.length; i++) {
      const k = window.localStorage.key(i);
      if (!k || !k.startsWith(LS_PREFIX)) continue;
      const snap = readSnapshot(k);
      if (!snap || !snap.at || now - snap.at > MAX_AGE_MS) stale.push(k);
    }
    stale.forEach(dropSnapshot);
  } catch (e) { /* noop */ }
};

const fmtTime = (ts) => {
  const d = new Date(ts);
  const p = (n) => String(n).padStart(2, '0');
  return p(d.getHours()) + ':' + p(d.getMinutes());
};

export function init(api) {
  const L = api.strings || {};
  const s = api.settings;
  const textarea = api.textarea;
  const form = textarea.form || (textarea.closest ? textarea.closest('form') : null);
  if (!form) return;

  const titleInput = document.getElementById('title');
  const cidInput = form.querySelector('input[name=cid]');
  const jq = window.jQuery || null;

  const storeKey = LS_PREFIX + (form.getAttribute('name') || 'post') + ':'
    + ((cidInput && parseInt(cidInput.value, 10) > 0) ? String(cidInput.value) : 'new');

  // Baseline = the content the server handed us on page load
  const initialText = api.getDoc();
  const initialTitle = titleInput ? String(titleInput.value || '') : '';

  // فاصله‌ی اسنپ‌شات‌ها بر حسب ثانیه (پیش‌فرض: ۵ دقیقه). 0 = خاموش.
  const intervalSec = (() => {
    const v = parseInt(s && s.draftInterval, 10);
    if (!isFinite(v) || v < 0) return 300;
    return Math.min(3600, v);
  })();

  pruneStaleSnapshots();

  /* ----------------------------------------------------------------
   * 1) Recovery banner (only when the local snapshot is newer/different)
   * ---------------------------------------------------------------- */
  const snap = readSnapshot(storeKey);
  if (snap && (snap.x !== initialText || String(snap.t || '') !== initialTitle) && snap.x.trim() !== '') {
    const banner = document.createElement('div');
    banner.className = 'negaresh-notice negaresh-recovery';
    const when = snap.at ? fmtTime(snap.at) : '';
    banner.innerHTML =
      '<span class="negaresh-recovery-text">' +
      (L.draftFound || 'یک پیش‌نویس ذخیره‌شده‌ی محلی') + (when ? ' (' + when + ')' : '') +
      ' ' + (L.draftFoundHint || 'یافت شد که با محتوای فعلی تفاوت دارد.') + '</span> ';

    const btnRestore = document.createElement('button');
    btnRestore.type = 'button';
    btnRestore.className = 'btn btn-s primary';
    btnRestore.textContent = L.draftRestore || 'بازیابی';
    const btnDiscard = document.createElement('button');
    btnDiscard.type = 'button';
    btnDiscard.className = 'btn btn-s';
    btnDiscard.textContent = L.draftDismiss || 'دور انداختن';

    banner.appendChild(btnRestore);
    banner.appendChild(btnDiscard);
    api.shell.parentNode && api.shell.parentNode.insertBefore(banner, api.shell);

    const restore = () => {
      api.setDoc(snap.x, 'end');
      if (titleInput && typeof snap.t === 'string') {
        titleInput.value = snap.t;
        if (jq) {
          jq(titleInput).trigger('change');
        } else {
          titleInput.dispatchEvent(new Event('change', { bubbles: true }));
        }
      }
      banner.remove();
      api.toast(L.draftRestored || L.autosaveRestored || 'پیش‌نویس بازیابی شد', 'success');
    };

    btnRestore.addEventListener('click', restore);
    btnDiscard.addEventListener('click', () => {
      dropSnapshot(storeKey);
      banner.remove();
    });
  }

  /* ----------------------------------------------------------------
   * 2) Local snapshots — on a fixed interval (default 5 minutes) + an
   *    emergency write when the page is left with unsaved changes
   * ---------------------------------------------------------------- */
  let statusEl = null;
  let statusTimer = null;
  let dirty = false;
  let emergencyDone = false;

  const flashStatus = (time) => {
    if (!statusEl) statusEl = api.addStatusItem('draft');
    if (!statusEl) return;
    statusEl.textContent = (L.localDraftSaved || 'پیش‌نویس محلی') + ' ' + time;
    statusEl.classList.add('is-active');
    if (statusTimer) clearTimeout(statusTimer);
    statusTimer = setTimeout(() => {
      statusEl.textContent = '';
      statusEl.classList.remove('is-active');
    }, 2200);
  };

  const takeSnapshot = (silent) => {
    const data = {
      x: api.getDoc(),
      t: titleInput ? String(titleInput.value || '') : '',
      at: Date.now(),
    };
    if (data.x.trim() === '' && data.t.trim() === '') {
      return; // nothing meaningful to keep
    }
    if (writeSnapshot(storeKey, data)) {
      dirty = false;
      if (!silent) flashStatus(fmtTime(data.at));
    }
  };

  const markDirty = () => { dirty = true; };

  api.on('docchange', markDirty);
  if (titleInput) {
    titleInput.addEventListener('input', markDirty);
  }

  if (intervalSec > 0) {
    window.setInterval(() => {
      if (dirty) takeSnapshot();
    }, intervalSec * 1000);
  }

  // ذخیره‌ی اضطراری هنگام ترک صفحه بدون ذخیره (pagehide + beforeunload):
  // نوشتن localStorage همگام است و در لحظه‌ی خروج هم به‌موقع انجام می‌شود.
  const emergencySave = () => {
    if (emergencyDone) return;
    emergencyDone = true;
    if (dirty) takeSnapshot(true);
  };
  window.addEventListener('pagehide', emergencySave);
  window.addEventListener('beforeunload', emergencySave);

  // After each successful server save (autosave included) the snapshot is
  // refreshed so it always represents the newest state.
  if (jq) {
    jq(form).on('submitted', () => {
      takeSnapshot();
    });
  }

  /* ----------------------------------------------------------------
   * 3) Ctrl/Cmd+S → core save (Typecho.savePost from write-js.php)
   * ---------------------------------------------------------------- */
  document.addEventListener('keydown', (e) => {
      if (e.defaultPrevented) return; // CodeMirror already handled this key
    if (!(e.ctrlKey || e.metaKey) || e.altKey || e.shiftKey) return;
    if (String(e.key || '').toLowerCase() !== 's') return;
    if (window.Typecho && typeof window.Typecho.savePost === 'function') {
      e.preventDefault();
      e.stopPropagation();
      window.Typecho.savePost();
    }
  });
}
