/**
 * Negaresh outline module — Phase 2
 * ------------------------------------------------------------------
 * Live document outline built from Markdown headings (# … ######),
 * shown in a collapsible drawer. Clicking an item moves the caret and
 * scrolls to that heading; the active heading is highlighted while
 * scrolling. Fenced code blocks (```) are skipped while parsing.
 */

const HEADING_RE = /^(#{1,6})\s+(.+?)\s*#*\s*$/;

const parseHeadings = (text) => {
  const out = [];
  const lines = text.split('\n');
  let offset = 0;
  let inFence = false;
  let fenceMarker = '';
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const fence = line.match(/^\s*(`{3,}|~{3,})/);
    if (fence) {
      if (!inFence) {
        inFence = true;
        fenceMarker = fence[1][0];
      } else if (fence[1][0] === fenceMarker) {
        inFence = false;
      }
      offset += line.length + 1;
      continue;
    }
    if (!inFence) {
      const m = line.match(HEADING_RE);
      if (m) {
        out.push({
          level: m[1].length,
          text: m[2],
          line: i,
          from: offset,
        });
      }
    }
    offset += line.length + 1;
  }
  return out;
};

export function init(api) {
  const L = api.strings || {};
  const s = api.settings;
  let headings = [];
  let items = [];
  let open = false;
  let updateTimer = null;

  /* ---------- Drawer ---------- */
  const drawer = document.createElement('nav');
  drawer.className = 'negaresh-outline';
  drawer.setAttribute('aria-label', L.outline || 'فهرست مطالب');
  drawer.innerHTML =
    '<div class="negaresh-outline-head">' +
    '<span class="negaresh-outline-title">' + (L.outline || 'فهرست مطالب') + '</span>' +
    '<button type="button" class="negaresh-outline-close" aria-label="' + (L.close || 'بستن') + '">' + api.svgIcon('x', 15) + '</button>' +
    '</div>' +
    '<div class="negaresh-outline-body" role="list"></div>';
  api.shell.appendChild(drawer);

  const bodyEl = drawer.querySelector('.negaresh-outline-body');
  const closeDrawer = () => {
    open = false;
    drawer.classList.remove('is-open');
    toggleBtn && toggleBtn.classList.remove('is-on');
  };
  drawer.querySelector('.negaresh-outline-close').addEventListener('click', closeDrawer);
  // clicking inside the editor closes the drawer (see editor.js closepanels)
  api.on('closepanels', closeDrawer);

  const jumpTo = (h) => {
    api.view.dispatch({
      selection: { anchor: h.from },
      scrollIntoView: true,
    });
    api.view.focus();
  };

  const render = () => {
    items = [];
    bodyEl.textContent = '';
    if (!headings.length) {
      const empty = document.createElement('div');
      empty.className = 'negaresh-outline-empty';
      empty.textContent = L.outlineEmpty || 'سرتیتری یافت نشد';
      bodyEl.appendChild(empty);
      return;
    }
    headings.forEach((h, i) => {
      const it = document.createElement('button');
      it.type = 'button';
      it.className = 'negaresh-outline-item negaresh-outline-l' + h.level;
      it.setAttribute('role', 'listitem');
      it.textContent = h.text || ('H' + h.level);
      it.title = h.text;
      it.addEventListener('click', () => jumpTo(h));
      bodyEl.appendChild(it);
      items.push(it);
    });
    updateActive();
  };

  const refresh = () => {
    headings = parseHeadings(api.getDoc());
    render();
  };

  const scheduleRefresh = () => {
    if (updateTimer) clearTimeout(updateTimer);
    updateTimer = setTimeout(refresh, 250);
  };

  /* ---------- Active heading while scrolling ---------- */
  let activeIdx = -1;
  const setActive = (idx) => {
    if (idx === activeIdx) return;
    activeIdx = idx;
    items.forEach((it, i) => it.classList.toggle('is-active', i === idx));
    const active = items[idx];
    if (active && open) {
      const bodyRect = bodyEl.getBoundingClientRect();
      const r = active.getBoundingClientRect();
      if (r.top < bodyRect.top || r.bottom > bodyRect.bottom) {
        active.scrollIntoView({ block: 'center', behavior: 'smooth' });
      }
    }
  };

  const updateActive = () => {
    const scroller = api.view.scrollDOM;
    if (!scroller || !headings.length) return setActive(-1);
    const top = scroller.getBoundingClientRect().top;
    let visible = null;
    try {
      const block = api.view.lineBlockAtHeight(scroller.scrollTop + 8);
      visible = block.from;
    } catch (e) {
      visible = null;
    }
    if (visible == null) return setActive(-1);
    let idx = -1;
    for (let i = 0; i < headings.length; i++) {
      if (headings[i].from <= visible) idx = i; else break;
    }
    setActive(idx);
  };

  let scrollTimer = null;
  api.view.scrollDOM.addEventListener('scroll', () => {
    if (!open) return;
    if (scrollTimer) return;
    scrollTimer = setTimeout(() => {
      scrollTimer = null;
      updateActive();
    }, 120);
  });

  /* ---------- Toggle ---------- */
  const toggle = () => {
    open = !open;
    drawer.classList.toggle('is-open', open);
    toggleBtn && toggleBtn.classList.toggle('is-on', open);
    if (open) {
      refresh();
      updateActive();
    }
  };

  const toggleBtn = api.addToolbarButton({
    id: 'outline',
    icon: 'outline',
    title: (L.outline || 'فهرست مطالب') + ' (Ctrl+Shift+O)',
    group: 2,
    action: toggle,
  });

  document.addEventListener('keydown', (e) => {
      if (e.defaultPrevented) return; // CodeMirror already handled this key
    if (!(e.ctrlKey || e.metaKey) || !e.shiftKey || e.altKey) return;
    if (String(e.key || '').toLowerCase() !== 'o') return;
    e.preventDefault();
    toggle();
  });

  api.on('docchange', scheduleRefresh);
  refresh();
}
