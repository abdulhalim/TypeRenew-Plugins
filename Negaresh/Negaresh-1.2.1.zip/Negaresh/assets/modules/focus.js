/**
 * Negaresh focus module — Phase 2
 * ------------------------------------------------------------------
 *  Focus Mode — dims everything except the paragraph block around the
 *              caret (a CodeMirror line decoration, RTL-safe).
 *
 * Requires: settings.focusMode (Phase 2 settings).
 */

import {
  EditorView,
  ViewPlugin,
  Decoration,
} from '../codemirror/codemirror.bundle.js';

export function init(api) {
  const L = api.strings || {};
  const s = api.settings;
  const shell = api.shell;
  const view = api.view;

  /* ----------------------------------------------------------------
   * Focus Mode
   * ---------------------------------------------------------------- */
  let focusOn = false;

  // The block around the caret = contiguous non-blank lines (paragraph /
  // list / quote chunk). Blank lines terminate blocks.
  const activeBlockRange = (state) => {
    const sel = state.selection.main;
    let start = state.doc.lineAt(sel.from).number;
    let end = state.doc.lineAt(sel.to).number;

    while (start > 1 && state.doc.line(start - 1).text.trim() !== '') start--;
    const total = state.doc.lines;
    while (end < total && state.doc.line(end + 1).text.trim() !== '') end++;

    return [start, end];
  };

  const focusDecorations = (v) => {
    if (!focusOn) return Decoration.none;
    const [start, end] = activeBlockRange(v.state);
    const decos = [];
    for (const { from, to } of v.visibleRanges) {
      for (let pos = from; pos <= to; ) {
        const line = v.state.doc.lineAt(pos);
        if (line.number < start || line.number > end) {
          decos.push(Decoration.line({ class: 'negaresh-focus-dim' }).range(line.from));
        } else {
          decos.push(Decoration.line({ class: 'negaresh-focus-active' }).range(line.from));
        }
        if (pos > line.to) break; // safety guard against pathological loops
        pos = line.to + 1;
      }
    }
    return Decoration.set(decos, true);
  };

  const focusPlugin = ViewPlugin.fromClass(class {
    constructor(v) { this.decorations = focusDecorations(v); }
    update(u) {
      if (u.docChanged || u.selectionSet || u.viewportChanged) {
        this.decorations = focusDecorations(u.view);
      }
    }
  }, { decorations: (v) => v.decorations });

  if (s.focusMode === '1') {
    api.addExtension(focusPlugin);

    const toggleFocus = () => {
      focusOn = !focusOn;
      shell.classList.toggle('is-focus', focusOn);
      focusBtn && focusBtn.classList.toggle('is-on', focusOn);
      // Force decoration recompute (a fresh selection object sets selectionSet)
      const cur = view.state.selection.main;
      view.dispatch({ selection: { anchor: cur.anchor, head: cur.head } });
      api.toast(focusOn ? (L.focusMode || 'حالت تمرکز') + ': ' + (L.enabled || 'فعال')
        : (L.focusMode || 'حالت تمرکز') + ': ' + (L.disabled || 'غیرفعال'), 'info', 1400);
    };

    const focusBtn = api.addToolbarButton({
      id: 'focus',
      icon: 'focus',
      title: (L.focusMode || 'حالت تمرکز') + ' (Ctrl+Shift+F)',
      group: 8,
      action: toggleFocus,
    });

    document.addEventListener('keydown', (e) => {
      if (e.defaultPrevented) return; // CodeMirror already handled this key
      if (!(e.ctrlKey || e.metaKey) || !e.shiftKey || e.altKey) return;
      if (String(e.key || '').toLowerCase() !== 'f') return;
      e.preventDefault();
      toggleFocus();
    });
  }
}
