/**
 * Negaresh content analyzer — Phase 3
 * ------------------------------------------------------------------
 * Snapshot statistics of the document: counts, structure, sentence lengths,
 * top frequent words (Persian stopwords excluded) and warnings — each
 * clickable item jumps to its source position.
 */

const PERSIAN_WORD = /[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF\u200c]+|[A-Za-z0-9]+/g;

const STOPWORDS = new Set([
  'از', 'به', 'با', 'در', 'که', 'را', 'این', 'آن', 'های', 'و', 'بر', 'برای', 'است', 'بود',
  'شد', 'شده', 'می', 'نمی', 'هم', 'نیز', 'تا', 'یا', 'اما', 'اگر', 'پس', 'چون', 'را',
  'وی', 'او', 'ما', 'شما', 'آنها', 'ایشان', 'خود', 'یک', 'دو', 'چه', 'هر', 'همه', 'بین',
  'روی', 'زیر', 'بالا', 'بی', 'من', 'کن', 'کند', 'کنیم', 'کنند', 'باید', 'شده', 'دارد',
  'دارند', 'داشت', 'بودند', 'هستند', 'خواهد', 'خواهند', 'شدند', 'شود', 'شوند', 'تواند',
  'توانند', 'اینکه', 'آنکه', 'بدون', 'درباره', 'مثل', 'مانند', 'سایر', 'دیگر', 'فقط',
  'بیشتر', 'کمتر', 'خیلی', 'بسیار', 'the', 'and', 'for', 'with', 'that', 'this', 'of', 'to',
  'in', 'is', 'are', 'a', 'an', 'on', 'it', 'be', 'as',
]);

const faNum = (n) => String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[+d]);

const countWords = (text) => {
  const m = text.match(PERSIAN_WORD);
  return m ? m.length : 0;
};

const analyze = (text) => {
  const lines = text.split('\n');
  const stats = {
    words: countWords(text),
    chars: text.length,
    charsNoSpace: text.replace(/\s/g, '').length,
    paragraphs: 0,
    sentences: 0,
    headings: [],
    images: 0,
    imagesNoAlt: 0,
    links: 0,
    linksInternal: 0,
    linksExternal: 0,
    codeBlocks: 0,
    listItems: 0,
    quotes: 0,
    longestSentence: null,
    sentenceLengths: [],
    frequent: [],
  };

  let offset = 0;
  let inFence = false;
  let fenceMarker = '';
  let paragraphLines = 0;

  const endParagraph = () => {
    if (paragraphLines > 0) {
      stats.paragraphs++;
      paragraphLines = 0;
    }
  };

  lines.forEach((line) => {
    const fence = line.match(/^\s*(`{3,}|~{3,})/);
    if (fence) {
      if (!inFence) {
        inFence = true;
        fenceMarker = fence[1][0];
        stats.codeBlocks++;
        endParagraph();
      } else if (fence[1][0] === fenceMarker) {
        inFence = false;
      }
      offset += line.length + 1;
      return;
    }
    if (inFence) {
      offset += line.length + 1;
      return;
    }

    const h = line.match(/^(#{1,6})\s+(.*)$/);
    if (h) {
      stats.headings.push({ level: h[1].length, text: h[2], from: offset });
      endParagraph();
    } else if (/^\s*>\s?/.test(line)) {
      stats.quotes++;
      paragraphLines++;
    } else if (/^\s*[-*+]\s+/.test(line) || /^\s*\d+\.\s+/.test(line)) {
      stats.listItems++;
      paragraphLines++;
    } else if (line.trim() === '') {
      endParagraph();
    } else {
      paragraphLines++;
    }

    // inline images / links (one pass, classified by the leading '!')
    const anyRe = /(!?)\[([^\]]*)\]\(([^)]+)\)/g;
    let m;
    while ((m = anyRe.exec(line)) !== null) {
      if (m[1] === '!') {
        stats.images++;
        if (!m[2].trim()) stats.imagesNoAlt++;
      } else if (m[2].trim() !== '') {
        stats.links++;
        const url = m[3].trim();
        if (/^(https?:)?\/\//i.test(url) || url.startsWith('//')) {
          stats.linksExternal++;
        } else {
          stats.linksInternal++;
        }
      }
    }

    offset += line.length + 1;
  });
  endParagraph();

  // sentences (very rough but useful for Persian prose): split on . ! ؟ … ؛
  const prose = text
    .split('\n').filter((l) => !/^\s*#{1,6}\s/.test(l) && !/^\s*(```|~~~)/.test(l)).join(' ');
  const rawSentences = prose.split(/[.!؟…؛]+/).map((s) => s.trim()).filter((s) => s.length > 1);
  stats.sentences = rawSentences.length;
  const docBase = 0; // positions below refer to prose-relative offsets; jumps use approximate positions
  rawSentences.forEach((s) => {
    const w = countWords(s);
    stats.sentenceLengths.push(w);
    if (!stats.longestSentence || w > stats.longestSentence.words) {
      const idx = text.indexOf(s);
      stats.longestSentence = { words: w, text: s, from: idx >= 0 ? idx : docBase };
    }
  });

  // frequent words
  const freq = new Map();
  const wm = text.match(PERSIAN_WORD) || [];
  wm.forEach((w) => {
    const k = w.replace(/\u200c/g, '\u200c').toLowerCase();
    if (k.length < 3 || STOPWORDS.has(k)) return;
    freq.set(k, (freq.get(k) || 0) + 1);
  });
  stats.frequent = Array.from(freq.entries())
    .sort((a, b) => b[1] - a[1]).slice(0, 5)
    .map(([word, n]) => ({ word, n, pct: Math.round((n / Math.max(1, stats.words)) * 1000) / 10 }));

  return stats;
};

export function init(api) {
  const L = api.strings || {};
  const view = api.view;

  const openAnalyzer = () => {
    const st = analyze(api.getDoc());
    const avg = st.sentences ? Math.round((st.sentenceLengths.reduce((a, b) => a + b, 0)) / st.sentences) : 0;

    const warn = [];
    const longSentences = st.sentenceLengths.filter((n) => n > 35).length;
    if (longSentences > 0) warn.push(faNum(longSentences) + ' ' + (L.warnLongSentence || 'جمله بلندتر از ۳۵ واژه'));
    if (st.headings.length) {
      const levels = st.headings.map((h) => h.level);
      let skip = false;
      for (let i = 1; i < levels.length; i++) {
        if (levels[i] - levels[i - 1] > 1) { skip = true; break; }
      }
      if (skip) warn.push(L.warnHeadingSkip || 'پرش سطح سرتیتر (مثلاً H1 به H3)');
    }
    if (st.imagesNoAlt > 0) warn.push(faNum(st.imagesNoAlt) + ' ' + (L.warnNoAlt || 'تصویر بدون متن جایگزین'));
    const overused = st.frequent.filter((f) => f.pct >= 4 && f.n >= 5);
    if (overused.length) warn.push(L.warnOverused || 'تکرار زیاد واژه: ' + overused.map((f) => f.word).join('، '));

    const row = (k, v, cls) =>
      '<div class="negaresh-stat' + (cls ? ' ' + cls : '') + '"><span class="negaresh-stat-k">' + k + '</span><strong class="negaresh-stat-v">' + v + '</strong></div>';

    const { overlay, close } = api.modalOverlay(`
      <h3>${L.analyzer || 'تحلیل محتوا'}</h3>
      <div class="negaresh-stats">
        ${row(L.words || 'واژه', faNum(st.words))}
        ${row(L.chars || 'نویسه', faNum(st.chars))}
        ${row((L.chars || 'نویسه') + ' (' + (L.noSpaces || 'بدون فاصله') + ')', faNum(st.charsNoSpace))}
        ${row(L.sentences || 'جمله', faNum(st.sentences))}
        ${row(L.paragraphs || 'پاراگراف', faNum(st.paragraphs))}
        ${row(L.avgSentence || 'میانگین طول جمله', faNum(avg))}
        ${row(L.headings || 'سرتیتر', faNum(st.headings.length))}
        ${row(L.images || 'تصویر', faNum(st.images))}
        ${row(L.links || 'پیوند', faNum(st.links) + ' (' + faNum(st.linksInternal) + '/' + faNum(st.linksExternal) + ')')}
        ${row(L.codeBlocks || 'بلوک کد', faNum(st.codeBlocks))}
        ${row(L.listItems || 'آیتم فهرست', faNum(st.listItems))}
        ${row(L.quotes || 'نقل‌قول', faNum(st.quotes))}
      </div>
      ${st.longestSentence ? '<div class="negaresh-modal-label"><button type="button" class="btn btn-s negaresh-longest">' + (L.longestSentence || 'بلندترین جمله') + ' (' + faNum(st.longestSentence.words) + ' ' + (L.words || 'واژه') + ')</button></div>' : ''}
      ${st.frequent.length ? '<div class="negaresh-modal-label negaresh-freq">' + (L.topWords || 'پرتکرارترین واژه‌ها') + ': ' + st.frequent.map((f) => f.word + ' (' + faNum(f.n) + ')').join('، ') + '</div>' : ''}
      ${warn.length ? '<div class="negaresh-warns">' + warn.map((w) => '<div class="negaresh-warn">' + w + '</div>').join('') + '</div>' : ''}
      <div class="negaresh-modal-actions">
        <button type="button" class="btn primary" data-act="ok">${L.ok || 'تأیید'}</button>
      </div>
    `);

    const longBtn = overlay.querySelector('.negaresh-longest');
    if (longBtn && st.longestSentence && st.longestSentence.from >= 0) {
      longBtn.addEventListener('click', () => {
        view.dispatch({
          selection: {
            anchor: st.longestSentence.from,
            head: st.longestSentence.from + st.longestSentence.text.length,
          },
          scrollIntoView: true,
        });
        close();
        view.focus();
      });
    }

    overlay.querySelector('button[data-act="ok"]').addEventListener('click', close);
  };

  api.addToolbarButton({
    id: 'analyzer',
    icon: 'bar-chart',
    title: L.analyzer || 'تحلیل محتوا',
    group: 7,
    action: openAnalyzer,
  });
}
