/**
 * Negaresh colored blocks module — v1.1 add-on
 * ------------------------------------------------------------------
 * یک دکمه به تولبار اضافه می‌کند که با کلیک، یک منوی پاپ‌آپ (نه مودال
 * کامل) باز می‌شود و ۴ نوع بلاک رنگی را نمایش می‌دهد:
 *   success / warning / info / danger
 *
 * خروجی Markdown-compatible (HyperDown):
 *
 *   <div class="tr-block tr-success" dir="auto">
 *
 *   محتوای شما اینجا — می‌توانید مارک‌داون بنویسید.
 *
 *   </div>
 *
 * خطوط خالی قبل و بعد محتوا الزامی‌اند تا HyperDown محتوای داخل بلاک
 * را به‌عنوان پاراگراف‌های جداگانه رندر کند. اگر خط خالی نباشد، همه‌ی
 * متن به‌صورت یک پاراگراف نمایش داده می‌شود.
 *
 * استایل بلاک‌ها در editor.css و در سمت پوسته با کلاس‌های tr-block
 * و tr-success/tr-warning/tr-info/tr-danger قابل تنظیم است.
 */

const esc = (str) => String(str ?? '')
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

const BLOCK_TYPES = [
  { id: 'success', label: 'موفقیت', color: '#16a34a', bg: '#dcfce7' },
  { id: 'warning', label: 'هشدار',   color: '#d97706', bg: '#fef3c7' },
  { id: 'info',    label: 'اطلاعات', color: '#2563eb', bg: '#dbeafe' },
  { id: 'danger',  label: 'خطا',     color: '#dc2626', bg: '#fee2e2' },
];

const buildBlockMarkdown = (type, content) => {
  const inner = String(content || '').trim();
  return `<div class="tr-block tr-${type}" dir="auto">\n\n${inner || ''}\n\n</div>`;
};

export function init(api) {
  const L = api.strings || {};
  const view = api.view;
  const shell = api.shell;

  if (!view || !shell) {
    console.warn('[Negaresh/blocks] missing api.view or api.shell');
    return;
  }

  /* ----------------------------------------------------------------
   * 1) Toolbar button + popup menu
   * ----------------------------------------------------------------
   * نکته: `addToolbarButton` در editor.js از `() => def.action()` استفاده
   * می‌کند — یعنی `this` داخل action برابر `undefined` است (strict mode).
   * بنابراین نمی‌توانیم از `this` برای گرفتن دکمه استفاده کنیم. در عوض،
   * دکمه را با `api.$` از روی data-btn پیدا می‌کنیم.
   ---------------------------------------------------------------- */
  let myBtn = null;
  const getButton = () => {
    if (myBtn && myBtn.isConnected) return myBtn;
    // data-btn روی خود دکمه توسط addToolbarButton تنظیم می‌شود
    myBtn = api.$('.negaresh-btn[data-btn="color-block"]')
         || api.$('.negaresh-btn-blocks');
    return myBtn;
  };

  const openPopup = () => {
    // اگر پاپ‌آپ از قبل باز است، ببند
    const existing = document.querySelector('.negaresh-blocks-popup');
    if (existing) { existing.remove(); return; }

    const anchorBtn = getButton();
    if (!anchorBtn) {
      console.warn('[Negaresh/blocks] toolbar button not found');
      return;
    }

    const popup = document.createElement('div');
    popup.className = 'negaresh-blocks-popup';
    popup.setAttribute('dir', 'rtl');
    popup.setAttribute('role', 'menu');
    popup.innerHTML = BLOCK_TYPES.map((t) => {
      const title = L['block' + (t.id.charAt(0).toUpperCase() + t.id.slice(1))] || t.label;
      return (
        '<button type="button" class="negaresh-blocks-item" data-type="' + t.id + '" '
        + 'style="--block-color:' + t.color + ';--block-bg:' + t.bg + '">'
        + '<span class="negaresh-blocks-dot" style="background:' + t.color + '"></span>'
        + '<span class="negaresh-blocks-label">' + esc(title) + '</span>'
        + '</button>'
      );
    }).join('');

    // جانمایی پاپ‌آپ زیر دکمه
    document.body.appendChild(popup);
    positionPopup(popup, anchorBtn);
    // force reflow
    popup.offsetHeight; // eslint-disable-line
    popup.classList.add('is-visible');

    // کلیک خارج = بستن
    const onDocClick = (e) => {
      if (!popup.contains(e.target) && e.target !== anchorBtn && !anchorBtn.contains(e.target)) {
        closePopup();
      }
    };
    const onEsc = (e) => {
      if (e.key === 'Escape') { e.preventDefault(); closePopup(); }
    };
    const closePopup = () => {
      popup.classList.remove('is-visible');
      setTimeout(() => { if (popup.parentNode) popup.remove(); }, 150);
      document.removeEventListener('mousedown', onDocClick);
      document.removeEventListener('keydown', onEsc);
      window.removeEventListener('scroll', reposition, true);
      window.removeEventListener('resize', reposition);
    };
    const reposition = () => positionPopup(popup, anchorBtn);
    document.addEventListener('mousedown', onDocClick);
    document.addEventListener('keydown', onEsc);
    window.addEventListener('scroll', reposition, true);
    window.addEventListener('resize', reposition);

    // کلیک روی هر بلاک → درج
    popup.querySelectorAll('.negaresh-blocks-item').forEach((btn) => {
      btn.addEventListener('click', () => {
        const type = btn.getAttribute('data-type');
        insertBlock(type);
        closePopup();
      });
    });
  };

  const positionPopup = (popup, anchorBtn) => {
    if (!anchorBtn || typeof anchorBtn.getBoundingClientRect !== 'function') return;
    const rect = anchorBtn.getBoundingClientRect();
    const popupRect = popup.getBoundingClientRect();
    const viewportH = window.innerHeight;
    // اگر در پایین جا نیست، بالا دکمه باز کن
    const spaceBelow = viewportH - rect.bottom;
    const top = spaceBelow < popupRect.height + 12 && rect.top > popupRect.height + 12
      ? rect.top + window.scrollY - popupRect.height - 6
      : rect.bottom + window.scrollY + 6;
    const left = rect.left + window.scrollX;
    popup.style.top = top + 'px';
    popup.style.left = left + 'px';
  };

  /* ----------------------------------------------------------------
   * 2) Insert block at cursor position
   * ---------------------------------------------------------------- */
  const insertBlock = (type) => {
    if (BLOCK_TYPES.findIndex((t) => t.id === type) === -1) return;

    const sel = view.state.selection.main;
    const selectedText = view.state.sliceDoc(sel.from, sel.to);
    const md = buildBlockMarkdown(type, selectedText);

    // اگر خط فعلی خالی نیست، قبل از بلاک یک خط خالی اضافه کن تا بلاک
    // در یک بلاک جدا قرار گیرد (HyperDown به این نیاز دارد).
    const lineFrom = view.state.doc.lineAt(sel.from).from;
    const lineText = view.state.sliceDoc(lineFrom, sel.from);
    const prefix = lineText.trim() === '' ? '' : '\n\n';

    view.dispatch({
      changes: { from: sel.from, to: sel.to, insert: prefix + md },
      selection: { anchor: sel.from + prefix.length + md.length },
      scrollIntoView: true,
      userEvent: 'input.block',
    });
    view.focus();
  };

  // دکمه تولبار (گروه ۴ = گروه ابزارها، بعد از جدول)
  api.addToolbarButton({
    id: 'color-block',
    icon: 'block',
    title: (L.coloredBlocks || 'بلاک‌های رنگی') + ' — success / warning / info / danger',
    group: 4,
    action: openPopup,
    className: 'negaresh-btn-blocks',
  });
}
