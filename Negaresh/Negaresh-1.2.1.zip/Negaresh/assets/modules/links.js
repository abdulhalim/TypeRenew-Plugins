/**
 * Negaresh advanced links module — Phase 2
 * ------------------------------------------------------------------
 * Upgrades the link & image dialogs with:
 *  - title field (markdown `«[text](url "title")»` — HyperDown compatible)
 *  - a quick-pick list of THIS post's attachments (from the core #file-list,
 *    whose li items carry data-url / data-image / .insert title)
 *  - a "from media library" button that opens MediaManager's picker
 *    (insertion flows back through the Negaresh bridge)
 */

const esc = (str) => String(str ?? '')
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

const collectAttachments = () => {
  const out = [];
  document.querySelectorAll('#file-list li[data-url]').forEach((li) => {
    const insertBtn = li.querySelector('.insert');
    out.push({
      title: insertBtn ? insertBtn.textContent.trim() : (li.getAttribute('data-cid') || ''),
      url: li.getAttribute('data-url') || '',
      isImage: li.getAttribute('data-image') === '1',
    });
  });
  return out.filter((a) => a.url);
};

export function init(api) {
  const L = api.strings || {};
  const view = api.view;

  const attachmentButtonsHtml = () => {
    const items = collectAttachments();
    if (!items.length) return '';
    const btns = items.slice(0, 12).map((a) =>
      '<button type="button" class="btn btn-s negaresh-attach-pick" data-url="' + esc(a.url) + '" '
      + 'data-title="' + esc(a.title) + '" data-image="' + (a.isImage ? '1' : '0') + '">'
      + (a.isImage ? api.svgIcon('image', 13) + ' ' : '')
      + esc(a.title) + '</button>'
    ).join('');
    return (
      '<div class="negaresh-modal-label negaresh-attach-block"><span class="negaresh-attach-title">'
      + (L.linkFromAttachments || 'از پیوست‌های این نوشته') + ':</span><div class="negaresh-attach-list">' + btns + '</div></div>'
    );
  };

  const libraryButtonHtml = () => {
    const mmCfg = (typeof window !== 'undefined' && window.MM_EDITOR) || null;
    if (!(mmCfg && mmCfg.enablePicker)) return '';
    return '<button type="button" class="btn btn-s negaresh-library-open">' + (L.fromLibrary || 'از کتابخانه رسانه') + '</button>';
  };

  const wireCommon = (overlay, apply) => {
    // Attachment quick-pick
    overlay.querySelectorAll('.negaresh-attach-pick').forEach((btn) => {
      btn.addEventListener('click', () => apply({
        url: btn.getAttribute('data-url') || '',
        title: btn.getAttribute('data-title') || '',
        isImage: btn.getAttribute('data-image') === '1',
      }));
    });
    // Media library (MediaManager picker)
    const libBtn = overlay.querySelector('.negaresh-library-open');
    if (libBtn) {
      libBtn.addEventListener('click', () => {
        const mmApi = window.MediaManager && window.MediaManager.editor;
        if (mmApi && typeof mmApi.openPicker === 'function') {
          overlay.remove(); // close our modal; picker takes over
          mmApi.openPicker();
        }
      });
    }
  };

  /* ---------------- Link dialog ---------------- */
  const openAdvancedLinkModal = () => {
    const sel = view.state.sliceDoc(view.state.selection.main.from, view.state.selection.main.to);
    const { overlay, close } = api.modalOverlay(`
      <h3>${L.link || 'پیوند'}</h3>
      <label class="negaresh-modal-label">${L.linkText || 'متن پیوند'}<input type="text" data-k="text" value="${esc(sel)}"></label>
      <label class="negaresh-modal-label">${L.linkUrl || 'نشانی پیوند'}<input type="url" data-k="url" placeholder="https://"></label>
      <label class="negaresh-modal-label">${L.linkTitle || 'عنوان (اختیاری)'}<input type="text" data-k="title"></label>
      ${attachmentButtonsHtml()}
      <div class="negaresh-modal-actions">
        ${libraryButtonHtml()}
        <span class="negaresh-actions-spacer"></span>
        <button type="button" class="btn primary" data-act="ok">${L.ok || 'تأیید'}</button>
        <button type="button" class="btn btn-link" data-act="cancel">${L.cancel || 'انصراف'}</button>
      </div>
    `);

    const inputText = overlay.querySelector('input[data-k="text"]');
    const inputUrl = overlay.querySelector('input[data-k="url"]');
    const inputTitle = overlay.querySelector('input[data-k="title"]');
    inputText.focus();
    inputText.select();

    const apply = ({ url, title }) => {
      inputUrl.value = url;
      if (!inputText.value.trim()) inputText.value = title;
      inputUrl.focus();
    };
    wireCommon(overlay, apply);

    const insert = () => {
      const text = inputText.value.trim() || (L.link || 'پیوند');
      const url = inputUrl.value.trim() || 'https://';
      const title = inputTitle.value.trim();
      const md = title ? `[${text}](${url} "${title}")` : `[${text}](${url})`;
      view.dispatch(view.state.replaceSelection(md), { scrollIntoView: true, userEvent: 'input.link' });
      view.focus();
      close();
    };
    overlay.querySelector('button[data-act="ok"]').addEventListener('click', insert);
    overlay.querySelector('button[data-act="cancel"]').addEventListener('click', close);
    [inputText, inputUrl, inputTitle].forEach((inp) => {
      inp.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); insert(); }
      });
    });
  };

  /* ---------------- Image dialog ----------------
   * سه فیلد: نشانی تصویر + متن جایگزین + عنوان (اختیاری).
   * خروجی: ![alt](url "title") — HyperDown-compatible.
   * اگر عنوان خالی باشد، فقط ![alt](url) تولید می‌شود.
   */
  const openAdvancedImageModal = () => {
    const sel = view.state.sliceDoc(view.state.selection.main.from, view.state.selection.main.to);
    const { overlay, close } = api.modalOverlay(`
      <h3>${L.image || 'تصویر'}</h3>
      <label class="negaresh-modal-label">${L.imageUrl || 'نشانی تصویر'}<input type="url" data-k="url" placeholder="https://.../image.png"></label>
      <label class="negaresh-modal-label">${L.imageAlt || 'متن جایگزین'}<input type="text" data-k="alt" value="${esc(sel)}"></label>
      <label class="negaresh-modal-label">${L.imageTitle || 'عنوان (اختیاری)'}<input type="text" data-k="title" placeholder="عنوان tooltip — خالی می‌ماند"></label>
      ${attachmentButtonsHtml()}
      <div class="negaresh-modal-actions">
        ${libraryButtonHtml()}
        <span class="negaresh-actions-spacer"></span>
        <button type="button" class="btn primary" data-act="ok">${L.ok || 'تأیید'}</button>
        <button type="button" class="btn btn-link" data-act="cancel">${L.cancel || 'انصراف'}</button>
      </div>
    `);

    const inputUrl = overlay.querySelector('input[data-k="url"]');
    const inputAlt = overlay.querySelector('input[data-k="alt"]');
    const inputTitle = overlay.querySelector('input[data-k="title"]');
    inputUrl.focus();

    const apply = ({ url, title, isImage }) => {
      inputUrl.value = url;
      if (isImage && !inputAlt.value.trim()) inputAlt.value = title;
      inputUrl.focus();
    };
    wireCommon(overlay, apply);

    const insert = () => {
      const url = inputUrl.value.trim() || 'https://';
      const alt = inputAlt.value.trim();
      const title = inputTitle.value.trim();
      // HyperDown: ![alt](url "title") — اگر title خالی است، فقط ![alt](url)
      const md = title ? `![${alt}](${url} "${title}")` : `![${alt}](${url})`;
      view.dispatch(view.state.replaceSelection(md), { scrollIntoView: true, userEvent: 'input.image' });
      view.focus();
      close();
    };
    overlay.querySelector('button[data-act="ok"]').addEventListener('click', insert);
    overlay.querySelector('button[data-act="cancel"]').addEventListener('click', close);
    [inputUrl, inputAlt, inputTitle].forEach((inp) => {
      inp.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); insert(); }
      });
    });
  };

  api.overrideButton('link', openAdvancedLinkModal);
  api.overrideButton('image', openAdvancedImageModal);
}
