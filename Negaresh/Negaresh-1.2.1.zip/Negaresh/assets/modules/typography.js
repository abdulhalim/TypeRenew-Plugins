/**
 * Negaresh typography checker — Phase 3
 * ------------------------------------------------------------------
 * Scans the document (code-aware) for common Persian typography issues and
 * lists them in a side drawer. Each item jumps to its position; safe issues
 * can be fixed in one click via the assistant's fixers.
 */

import { segmentDoc, applyFixers } from './persian.js';

const AR = /[يك]/;
const PERSIAN = /[\u0600-\u06FF]/;

const faNum = (n) => String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[+d]);

export function init(api) {
  const L = api.strings || {};
  const view = api.view;
  let open = false;
  let updateTimer = null;

  /* ---------- Drawer ---------- */
  const drawer = document.createElement('nav');
  drawer.className = 'negaresh-outline negaresh-typo';
  drawer.setAttribute('aria-label', L.typography || 'بازبین تایپوگرافی');
  drawer.innerHTML =
    '<div class="negaresh-outline-head"><span class="negaresh-outline-title">'
    + (L.typography || 'بازبین تایپوگرافی') + '</span>'
    + '<button type="button" class="negaresh-outline-close" aria-label="' + (L.close || 'بستن') + '">' + api.svgIcon('x', 15) + '</button></div>'
    + '<div class="negaresh-outline-body"></div>'
    + '<div class="negaresh-typo-foot"><button type="button" class="btn btn-s primary" data-act="fix">'
    + (L.fixSafe || 'اصلاح موارد امن') + '</button></div>';
  api.shell.appendChild(drawer);
  const bodyEl = drawer.querySelector('.negaresh-outline-body');

  const closeDrawer = () => {
    open = false;
    drawer.classList.remove('is-open');
    toggleBtn && toggleBtn.classList.remove('is-on');
  };
  drawer.querySelector('.negaresh-outline-close').addEventListener('click', closeDrawer);
  // clicking inside the editor closes the drawer (see editor.js closepanels)
  api.on('closepanels', closeDrawer);

  const jumpTo = (from, length) => {
    view.dispatch({
      selection: { anchor: from, head: from + length },
      scrollIntoView: true,
    });
    view.focus();
  };

  const scan = () => {
    const doc = view.state.doc;
    const text = doc.toString();
    const issues = [];
    let offset = 0;

    segmentDoc(text).forEach((seg) => {
      if (seg.code) {
        offset += seg.text.length;
        return;
      }
      const segText = seg.text;
      const lines = segText.split('\n');
      let pos = 0;
      lines.forEach((line, i) => {
        // 1. Arabic characters
        let m;
        const arRe = /[يك]/g;
        while ((m = arRe.exec(line)) !== null) {
          issues.push({
            from: offset + pos + m.index,
            len: 1,
            msg: L.issueArabic || 'حرف عربی (ي/ك) به‌جای ی/ک فارسی',
          });
        }
        // 2. space before ، ؛ ؟ ! or latin comma
        const spRe = / +([،؛؟!,])/g;
        while ((m = spRe.exec(line)) !== null) {
          issues.push({
            from: offset + pos + m.index,
            len: m[0].length,
            msg: L.issueSpaceBefore || 'فاصله‌ی اضافی قبل از علامت نگارشی',
          });
        }
        // 3. missing space after ، ؛ ؟ !
        const afRe = /([،؛؟!])(?=[^\s\d\)\]\}»"'\.,،؛؟!])/g;
        while ((m = afRe.exec(line)) !== null) {
          issues.push({
            from: offset + pos + m.index,
            len: 1,
            msg: L.issueSpaceAfter || 'نبود فاصله بعد از علامت نگارشی',
          });
        }
        // 4. double spaces between words (not leading indent)
        const dblRe = / {2,}/g;
        while ((m = dblRe.exec(line)) !== null) {
          const before = m.index > 0 ? line[m.index - 1] : '';
          const after = line[m.index + m[0].length] || '';
          if (/\S/.test(before) && /\S/.test(after)) {
            issues.push({
              from: offset + pos + m.index,
              len: m[0].length,
              msg: L.issueDoubleSpace || 'فاصله‌ی تکراری',
            });
          }
        }
        // 5. straight quotes on Persian lines
        if (PERSIAN.test(line)) {
          const qRe = /"[^"\n]{1,120}"/g;
          while ((m = qRe.exec(line)) !== null) {
            issues.push({
              from: offset + pos + m.index,
              len: m[0].length,
              msg: L.issueQuotes || 'گیومه‌ی مستقیم — بهتر است از «» استفاده شود',
            });
          }
        }
        // 6. Latin digits on Persian lines (informational)
        if (PERSIAN.test(line)) {
          const dRe = /[0-9]+/g;
          while ((m = dRe.exec(line)) !== null) {
            issues.push({
              from: offset + pos + m.index,
              len: m[0].length,
              msg: L.issueDigits || 'رقم انگلیسی در متن فارسی',
              soft: true,
            });
          }
        }
        // 7. ZWNJ candidates: "می /" pattern
        const zRe = /(^|\s)(ن?می) [^\s\u200c]/g;
        while ((m = zRe.exec(line)) !== null) {
          issues.push({
            from: offset + pos + m.index,
            len: m[0].length,
            msg: L.issueZwnj || 'کاندید نیم‌فاصله (می/نمی جدا نوشته شده)',
          });
        }
        // 8. repeated ؟؟ / !!
        const repRe = /([؟!])\1+/g;
        while ((m = repRe.exec(line)) !== null) {
          issues.push({
            from: offset + pos + m.index,
            len: m[0].length,
            msg: L.issueRepeat || 'تکرار علامت نگارشی',
          });
        }
        pos += line.length + 1;
      });
      offset += seg.text.length;
    });

    return issues.slice(0, 200); // keep the drawer responsive
  };

  const render = () => {
    const issues = scan();
    bodyEl.textContent = '';
    drawer.querySelector('[data-act="fix"]').hidden = issues.length === 0;

    if (!issues.length) {
      const empty = document.createElement('div');
      empty.className = 'negaresh-outline-empty';
      empty.textContent = L.noIssues || 'مشکلی یافت نشد';
      bodyEl.appendChild(empty);
      api.toast((L.typography || 'تایپوگرافی') + ': ' + (L.noIssues || 'مشکلی یافت نشد'), 'success');
      return;
    }

    const head = document.createElement('div');
    head.className = 'negaresh-typo-count';
    head.textContent = faNum(issues.length) + ' ' + (L.issues || 'مورد');
    bodyEl.appendChild(head);

    issues.forEach((iss) => {
      const it = document.createElement('button');
      it.type = 'button';
      it.className = 'negaresh-outline-item negaresh-typo-item' + (iss.soft ? ' is-soft' : '');
      it.textContent = iss.msg;
      it.title = iss.msg;
      it.addEventListener('click', () => jumpTo(iss.from, iss.len));
      bodyEl.appendChild(it);
    });
  };

  const scheduleRender = () => {
    if (!open) return;
    if (updateTimer) clearTimeout(updateTimer);
    updateTimer = setTimeout(render, 300);
  };

  const toggle = () => {
    open = !open;
    drawer.classList.toggle('is-open', open);
    toggleBtn && toggleBtn.classList.toggle('is-on', open);
    if (open) render();
  };

  const toggleBtn = api.addToolbarButton({
    id: 'typography',
    icon: 'type',
    title: L.typography || 'بازبین تایپوگرافی',
    group: 7,
    action: toggle,
  });

  drawer.querySelector('[data-act="fix"]').addEventListener('click', () => {
    // Safe one-click fixes (Arabic chars, spaces, punctuation spacing, quotes)
    const text = api.getDoc();
    const fixed = applyFixers(text, ['arabic', 'spaces', 'punct', 'quotes']);
    if (fixed !== text) {
      api.setDoc(fixed, 'end');
      api.toast(L.applied || 'اعمال شد', 'success');
    } else {
      api.toast(L.noIssues || 'تغییری لازم نبود', 'info');
    }
    render();
  });

  api.on('docchange', scheduleRender);
}
