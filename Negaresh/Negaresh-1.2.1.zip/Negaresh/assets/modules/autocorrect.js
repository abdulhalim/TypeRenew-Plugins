/**
 * Negaresh as-you-type autocorrect — Phase 4
 * ------------------------------------------------------------------
 * When the user presses SPACE, the word that was just completed (plus,
 * when relevant, the word before it) is checked against small curated
 * rule sets (see ./persian.js):
 *
 *   می شود   →  می‌شود      (ZWNJ merge with می / نمی + verb tail)
 *   میشود   →  می‌شود      (wrongly-glued form → ZWNJ)
 *   کتاب ها  →  کتاب‌ها     (ZWNJ merge with ها / های / هایی)
 *   تقریبا   →  تقریباً     (تنوین نصب for known -a adverbs)
 *   كتاب     →  کتاب        (Arabic ي / ك → Persian ی / ک)
 *
 * The check runs ONLY on the word ending at the caret — zero cost on
 * every other keystroke. Code fences and inline code are protected.
 * Nothing is corrected inside ``` blocks or `spans`.
 */

import { autocorrectWord, autocorrectMerge, applyFixers } from './persian.js';
import { EditorSelection, Prec, keymap } from '../codemirror/codemirror.bundle.js';

/** True when the caret sits inside a fenced block or inline code. */
const insideCode = (state, pos) => {
  const doc = state.doc;
  const line = doc.lineAt(pos);
  let fence = false;
  for (let i = 1; i < line.number; i++) {
    if (/^\s*(`{3,}|~{3,})/.test(doc.line(i).text)) fence = !fence;
  }
  if (fence) return true;
  const before = line.text.slice(0, pos - line.from);
  return ((before.match(/`/g) || []).length % 2) === 1;
};

/**
 * Compute the pending autocorrect for the word ending at the caret.
 * Returns { from, to, insert } or null. (Exported for tests.)
 */
export const computeAutocorrect = (state) => {
  const sel = state.selection.main;
  if (sel.from !== sel.to) return null; // only while typing, not over selections
  const pos = sel.head;
  const doc = state.doc;

  // word ending at the caret
  let start = pos;
  while (start > 0 && !/[\s]/.test(doc.sliceString(start - 1, start))) start--;
  if (start === pos) return null; // no word before the caret
  const word = doc.sliceString(start, pos);
  if (!/[\u0600-\u06FF]/.test(word) && !/[يك]/.test(word)) return null; // Persian only
  if (insideCode(state, pos)) return null;

  // 1) word-level fixes (تنوین / ي / ك)
  const fixed = autocorrectWord(word);
  if (fixed !== null) {
    return { from: start, to: pos, insert: fixed };
  }

  // 2) two-word merges (می شود / کتاب ها) — needs a single space before the word
  if (start > 0 && doc.sliceString(start - 1, start) === ' ') {
    let pstart = start - 1;
    while (pstart > 0 && !/\s/.test(doc.sliceString(pstart - 1, pstart))) pstart--;
    const prev = doc.sliceString(pstart, start - 1);
    if (prev) {
      const merged = autocorrectMerge(prev, word);
      if (merged !== null) {
        return { from: pstart, to: pos, insert: merged };
      }
    }
  }

  return null;
};

export function init(api) {
  const s = api.settings;
  if (s.autoCorrect !== '1') return;

  api.addExtension(
    Prec.high(
      keymap.of([{
        key: ' ',
        run: (view) => {
          const fix = computeAutocorrect(view.state);
          if (!fix) return false; // let CodeMirror insert the space
          view.dispatch({
            changes: { from: fix.from, to: fix.to, insert: fix.insert + ' ' },
            selection: EditorSelection.cursor(fix.from + fix.insert.length + 1),
            userEvent: 'input.autocorrect',
          });
          return true;
        },
      }])
    )
  );

  /* ----------------------------------------------------------------
   * Paste handler — برای متن کپی‌شده.
   *
   * وقتی کاربر متنی را کپی و paste می‌کند، متن معمولاً شامل کلمات
   * چسبیده‌ی غلط (مثل «میرسد» به‌جای «می‌رسد») یا ی/ک عربی یا تنوین
   * نیامده است. این هندلر متن paste‌شده را قبل از درج، با همان
   * fixer‌های دستیار نگارش (autocorrect, zwnj, arabic, digits) تصحیح
   * می‌کند، تا متن کپی‌شده هم مثل تایپ‌شده تصحیح شود.
   *
   * فقط اگر autoCorrect روشن باشد فعال می‌شود.
   * ---------------------------------------------------------------- */
  const view = api.view;
  if (view && view.contentDOM) {
    view.contentDOM.addEventListener('paste', (e) => {
      // فقط متن را می‌گیریم — تصاویر و فایل‌ها توسط media.js مدیریت می‌شوند
      const text = (e.clipboardData || {}).getData('text/plain');
      if (!text || text.length < 2) return;

      // اعمال fixer‌های انتخابی: autocorrect (تصحیح کلمات) + zwnj (نیم‌فاصله)
      // + arabic (ی/ک). digits و quotes و spaces را اعمال نمی‌کنیم چون
      // ممکن است متن کپی‌شده عمداً ارقام انگلیسی یا گیومه‌ی مستقیم داشته
      // باشد (مثلاً کد).
      const fixed = applyFixers(text, ['autocorrect', 'zwnj', 'arabic']);
      if (fixed === text) return; // تغییری لازم نبود

      // جلوگیری از paste پیش‌فرض، و درج متن تصحیح‌شده
      e.preventDefault();
      e.stopPropagation();

      const sel = view.state.selection.main;
      view.dispatch({
        changes: { from: sel.from, to: sel.to, insert: fixed },
        selection: { anchor: sel.from + fixed.length },
        scrollIntoView: true,
        userEvent: 'input.paste.autocorrect',
      });
    }, true); // capture phase — قبل از CodeMirror
  }
}
