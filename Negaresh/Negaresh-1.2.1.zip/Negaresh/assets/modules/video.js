/**
 * Negaresh video embeds + emoji palette — Phase 6
 * ------------------------------------------------------------------
 * Pure, DOM-free helpers shared by the editor core (toolbar buttons,
 * paste / Enter auto-conversion, file-insertion paths) and the test
 * suite. Imported WITHOUT a query string by every consumer so the
 * browser keeps a single module instance (same contract as persian.js).
 *
 * Supported players:
 *   - YouTube   (watch?v= / youtu.be / shorts / live / embed)
 *   - Aparat    (aparat.com/v/… — the Iranian video service)
 *   - Vimeo     (vimeo.com/…)
 *   - Instagram (p / reel / tv)
 *   - Telegram  (t.me/channel/123 post widget)
 *   - Direct video files (.mp4 .webm .ogv .m4v .mov) → <video> tag
 *
 * Output is single-line raw HTML. HyperDown (with enableHtml, exactly how
 * the front end and the preview tab configure it) passes <iframe> block
 * lines through untouched and keeps inline <video> tags inside the
 * paragraph — so the markdown stays HyperDown/TypeRenew compatible.
 *
 * No lookbehind regexes anywhere (Safari 15 safe).
 */

/* ------------------------------------------------------------------ */
/* Video providers                                                     */
/* ------------------------------------------------------------------ */

const PROVIDERS = [
  {
    id: 'youtube',
    match(url) {
      let m = url.match(/^(?:https?:)?\/\/(?:www\.|m\.)?youtube\.com\/watch\?(?:[^#\s]*&)?v=([A-Za-z0-9_-]{6,})/i);
      if (!m) m = url.match(/^(?:https?:)?\/\/(?:www\.)?youtu\.be\/([A-Za-z0-9_-]{6,})/i);
      if (!m) m = url.match(/^(?:https?:)?\/\/(?:www\.|m\.)?youtube\.com\/(?:shorts|live|embed)\/([A-Za-z0-9_-]{6,})/i);
      return m ? 'https://www.youtube-nocookie.com/embed/' + m[1] : null;
    },
    wide: true,
  },
  {
    id: 'aparat',
    match(url) {
      let m = url.match(/^(?:https?:)?\/\/(?:www\.)?aparat\.com\/v\/([A-Za-z0-9]+)/i);
      if (!m) m = url.match(/^(?:https?:)?\/\/(?:www\.)?aparat\.com\/video\/video\/embed\/videohash\/([A-Za-z0-9]+)/i);
      return m ? 'https://www.aparat.com/video/video/embed/videohash/' + m[1] + '/vt/frame' : null;
    },
    wide: true,
  },
  {
    id: 'vimeo',
    match(url) {
      let m = url.match(/^(?:https?:)?\/\/(?:www\.)?vimeo\.com\/(\d+)/i);
      if (!m) m = url.match(/^(?:https?:)?\/\/player\.vimeo\.com\/video\/(\d+)/i);
      return m ? 'https://player.vimeo.com/video/' + m[1] : null;
    },
    wide: true,
  },
  {
    id: 'instagram',
    match(url) {
      const m = url.match(/^(?:https?:)?\/\/(?:www\.)?instagram\.com\/(p|reel|reels|tv)\/([A-Za-z0-9_-]+)/i);
      if (!m) return null;
      const kind = m[1].toLowerCase() === 'reels' ? 'reel' : m[1].toLowerCase();
      return 'https://www.instagram.com/' + kind + '/' + m[2] + '/embed';
    },
    wide: false,
  },
  {
    id: 'telegram',
    match(url) {
      const m = url.match(/^(?:https?:)?\/\/(?:t\.me|telegram\.me)\/([A-Za-z0-9_]{3,})\/(\d+)(?:[?&#]\S*)?$/i);
      return m ? 'https://t.me/' + m[1] + '/' + m[2] + '?embed=1&mode=tme' : null;
    },
    wide: false,
  },
];

/** Direct (self-hosted / uploaded) video file URLs — absolute or root-relative. */
const VIDEO_FILE_RE = /^(?:(?:https?:)?\/\/|\/)[^\s"'<>]+\.(mp4|webm|ogv|m4v|mov)(?:[?#][^\s"'<>]*)?$/i;

export const DIRECT_VIDEO = 'direct';

export const isDirectVideoUrl = (url) =>
  VIDEO_FILE_RE.test(String(url || '').trim());

/**
 * Build the player embed for a bare video URL.
 * Returns { provider, html } or null when nothing matches.
 */
export const videoEmbedFor = (rawUrl) => {
  const url = String(rawUrl || '').trim();
  if (!url || /\s/.test(url)) return null; // single URL token only
  if (!/^(?:https?:)?\/\//i.test(url) && url.charAt(0) !== '/') return null;

  for (const p of PROVIDERS) {
    const src = p.match(url);
    if (src) {
      const dims = p.wide ? 'width="560" height="315"' : 'width="420" height="595"';
      return {
        provider: p.id,
        html: '<iframe src="' + src + '" ' + dims +
          ' allowfullscreen loading="lazy" style="max-width:100%;border:0"></iframe>',
      };
    }
  }

  if (VIDEO_FILE_RE.test(url)) {
    return {
      provider: DIRECT_VIDEO,
      html: '<video src="' + url + '" controls playsinline preload="metadata" style="max-width:100%"></video>',
    };
  }

  return null;
};

/* ------------------------------------------------------------------ */
/* Emoji palette (50 common emojis)                                     */
/* ------------------------------------------------------------------ */

export const EMOJIS = [
  '😀', '😁', '😂', '🤣', '😊', '😍', '🥰', '😘', '😎', '🤔',
  '😉', '😅', '😭', '😢', '😡', '🤯', '😱', '🥳', '🤗', '😴',
  '👍', '👎', '👏', '🙏', '🤝', '💪', '✌️', '👌', '🙌', '👀',
  '❤️', '💔', '🔥', '✨', '⭐', '🌹', '🌷', '🍀', '🎁', '🎉',
  '☕', '🍕', '✈️', '🚗', '🏠', '📱', '💻', '📚', '⚽', '🎧',
];
