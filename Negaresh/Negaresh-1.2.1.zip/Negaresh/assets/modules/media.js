/**
 * Negaresh media module — Phase 1 (updated in v1.1)
 * ------------------------------------------------------------------
 *  1) Library button  → opens MediaManager's own picker (its API/Picker,
 *     no copied logic). Falls back to the core attachments tab.
 *     + MM upload box in the fullscreen rail (mm-upload-area style):
 *     click → picker, drag&drop → upload inside the picker.
 *  2) Paste image     → files on the clipboard are uploaded through the
 *     core Typecho.uploadFile queue (which also triggers MediaManager's
 *     WebP conversion hook server-side).
 *  3) Drag & drop     → drop files anywhere on the editor shell; the
 *     markdown is inserted at the exact drop position.
 *
 * Markdown output is HyperDown-compatible: ![alt](url) / [title](url).
 */

export function init(api) {
  const s = api.settings;
  const L = api.strings || {};

  /* ----------------------------------------------------------------
   * 1) Library button (MediaManager picker)
   * ---------------------------------------------------------------- */
  // MM's inline config (window.MM_EDITOR) is injected by a classic script
  // before this module runs, so availability is known at init time.
  const mmCfg = (typeof window !== 'undefined' && window.MM_EDITOR) || null;
  const pickerAvailable = !!(mmCfg && mmCfg.enablePicker);
  // MediaManager owns uploads when its picker is active AND its
  // «غیرفعال‌سازی آپلودر پیش‌فرض سیستم» setting is on.
  const mmOwnsUploads = !!(mmCfg && mmCfg.enablePicker && mmCfg.disableSystemUpload);

  const openLibrary = () => {
    const mmApi = window.MediaManager && window.MediaManager.editor;
    if (mmApi && typeof mmApi.openPicker === 'function' && mmApi.openPicker()) {
      return;
    }
    // Fallback: core attachments panel
    if (window.Typecho && window.Typecho.writeWorkspace
      && typeof window.Typecho.writeWorkspace.showPanel === 'function') {
      window.Typecho.writeWorkspace.showPanel('#tab-files');
      api.toast(L.mmUnavailable || 'کتابخانه رسانه در دسترس نیست؛ تب پیوست‌ها باز شد.', 'error', 4000);
      return;
    }
    const tabsBtn = document.getElementById('tab-files-btn');
    if (tabsBtn) tabsBtn.click();
  };

  // Upload through MM's picker (opens it + enqueues into its current
  // folder). Falls back to the core upload queue (root folder).
  const uploadViaMm = (files) => {
    const mmApi = window.MediaManager && window.MediaManager.editor;
    if (mmApi && typeof mmApi.uploadFiles === 'function' && mmApi.uploadFiles(files)) {
      return;
    }
    Array.from(files || []).forEach(upload);
  };

  if (s.mediaBridge === '1') {
    // دکمه‌ی «کتابخانه رسانه» از تولبار حذف شد — دکمه‌ی آپلود موجود
    // هم کتابخانه را باز می‌کند و دکمه‌ی جداگانه‌ای لازم نبود.
    // میانبر Ctrl+Shift+G همچون فعال است تا کتابخانه سریع باز شود.
    document.addEventListener('keydown', (e) => {
        if (e.defaultPrevented) return; // CodeMirror already handled this key
    if (!(e.ctrlKey || e.metaKey) || !e.shiftKey || e.altKey) return;
      if (String(e.key || '').toLowerCase() !== 'g') return;
      e.preventDefault();
      e.stopPropagation();
      openLibrary();
    });
  }

  /* ----------------------------------------------------------------
   * 1b) MM upload box in the fullscreen rail (mm-upload-area look)
   * ---------------------------------------------------------------- */
  const buildRailUploadBox = () => {
    const host = document.querySelector('.negaresh-fs-rail .negaresh-fs-mm');
    if (!host || host.querySelector('.mm-upload-box')) return;

    const box = document.createElement('div');
    box.className = 'mm-upload-box negaresh-rail-upload';
    box.setAttribute('role', 'button');
    box.setAttribute('tabindex', '0');
    box.setAttribute('aria-label', L.uploadFile || 'آپلود فایل');

    box.innerHTML =
      '<svg class="mm-ico" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242"/><path d="M12 12v9"/><path d="m16 16-4-4-4 4"/></svg>' +
      '<p class="mm-upload-box-title"></p>' +
      '<p class="mm-upload-box-hint"></p>';
    box.querySelector('.mm-upload-box-title').textContent = L.uploadFile || 'آپلود فایل';
    box.querySelector('.mm-upload-box-hint').textContent = L.railUploadHint || 'فایل را اینجا رها کنید یا کلیک کنید';

    box.addEventListener('click', openLibrary);
    box.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        openLibrary();
      }
    });

    let depth = 0;
    const hasFiles = (e) => {
      const dt = e.dataTransfer;
      return !!(dt && Array.from(dt.types || []).includes('Files'));
    };

    box.addEventListener('dragenter', (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      depth++;
      box.classList.add('mm-dragover');
    });
    box.addEventListener('dragover', (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      e.stopPropagation();
      box.classList.add('mm-dragover');
    });
    box.addEventListener('dragleave', (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      depth = Math.max(0, depth - 1);
      if (depth === 0) box.classList.remove('mm-dragover');
    });
    box.addEventListener('dragend', () => {
      depth = 0;
      box.classList.remove('mm-dragover');
    });
    box.addEventListener('drop', (e) => {
      depth = 0;
      box.classList.remove('mm-dragover');
      const files = e.dataTransfer ? Array.from(e.dataTransfer.files || []) : [];
      if (!files.length) return;
      e.preventDefault();
      e.stopPropagation();
      uploadViaMm(files);
    });

    host.appendChild(box);
  };

  if (mmOwnsUploads) {
    buildRailUploadBox();
  }

  /* ----------------------------------------------------------------
   * Upload status pill (shared by paste & drop)
   * ---------------------------------------------------------------- */
  let statusEl = null;
  let pollTimer = null;

  const ensureStatus = () => {
    if (statusEl) return statusEl;
    statusEl = api.addStatusItem('upload');
    return statusEl;
  };

  const pendingCount = () => {
    if (window.Typecho && typeof window.Typecho.getUploadPending === 'function') {
      try {
        return parseInt(window.Typecho.getUploadPending() || '0', 10) || 0;
      } catch (e) { /* noop */ }
    }
    return 0;
  };

  const trackUploads = () => {
    const el = ensureStatus();
    if (!el) return;
    if (pollTimer) return;
    const tick = () => {
      const n = pendingCount();
      if (n > 0) {
        el.textContent = (L.uploading || 'در حال آپلود') + '… ' + String(n);
        el.classList.add('is-active');
      } else {
        el.textContent = '';
        el.classList.remove('is-active');
        if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
      }
    };
    pollTimer = setInterval(tick, 400);
    tick();
  };

  /* ----------------------------------------------------------------
   * Shared upload entry
   * ---------------------------------------------------------------- */
  const upload = (file) => {
    let f = file;
    // Pasted files often have no name (or a generic "image.png"); give them
    // a stable, unique name the way the core editor did.
    if (!f.name || /^(image|unknown)\.png$/i.test(f.name)) {
      try {
        const type = String(f.type || '');
        const ext = (type.split('/')[1] || 'png').replace('jpeg', 'jpg').replace('quicktime', 'mov');
        f = new File([f], 'pasted-' + new Date().toISOString().replace(/[:.]/g, '-') + '.' + ext, { type: type || f.type });
      } catch (e) { /* keep original file object */ }
    }
    if (api.uploadFile(f)) trackUploads();
  };

  /* ----------------------------------------------------------------
   * 2) Paste image (files only — plain text paste is untouched)
   * ---------------------------------------------------------------- */
  if (s.pasteUpload === '1') {
    api.view.contentDOM.addEventListener('paste', (e) => {
      const items = (e.clipboardData || (e.originalEvent && e.originalEvent.clipboardData) || {}).items;
      if (!items) return;
      const files = [];
      for (const item of items) {
        if (item && item.kind === 'file') {
          const file = item.getAsFile();
          if (file && file.size > 0) files.push(file);
        }
      }
      if (!files.length) return; // normal text paste
      e.preventDefault();
      e.stopPropagation();
      files.forEach(upload);
    });
  }

  /* ----------------------------------------------------------------
   * 3) Drag & drop on the editor shell
   * ---------------------------------------------------------------- */
  if (s.dropUpload === '1') {
    let overlay = null;
    let depth = 0;

    const hasFiles = (e) => {
      const dt = e.dataTransfer;
      if (!dt) return false;
      const types = Array.from(dt.types || []);
      return types.includes('Files');
    };

    const showOverlay = () => {
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.className = 'negaresh-dropzone';
        overlay.innerHTML = '<span>' + (L.dropHere || 'فایل‌ها را اینجا رها کنید') + '</span>';
        api.shell.appendChild(overlay);
      }
      overlay.classList.add('is-visible');
    };
    const hideOverlay = () => {
      if (overlay) overlay.classList.remove('is-visible');
    };

    api.shell.addEventListener('dragenter', (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      depth++;
      showOverlay();
    });
    api.shell.addEventListener('dragover', (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      e.stopPropagation();
      showOverlay();
    });
    api.shell.addEventListener('dragleave', (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      depth = Math.max(0, depth - 1);
      if (depth === 0) hideOverlay();
    });
    api.shell.addEventListener('dragend', () => {
      depth = 0;
      hideOverlay();
    });
    api.shell.addEventListener('drop', (e) => {
      depth = 0;
      hideOverlay();
      const files = e.dataTransfer ? Array.from(e.dataTransfer.files || []) : [];
      if (!files.length) return; // let CodeMirror handle text drops natively
      e.preventDefault();
      e.stopPropagation();
      // Place the caret exactly where the file was dropped, so the inserted
      // markdown (via Typecho.uploadComplete) lands there.
      const pos = api.view.posAtCoords({ x: e.clientX, y: e.clientY });
      if (pos != null) {
        api.view.dispatch({ selection: { anchor: pos, head: pos } });
      }
      files.forEach(upload);
      api.view.focus();
    });
  }
}
