/**
 * Negaresh SEO writing tools — Phase 3
 * ------------------------------------------------------------------
 * Focus-keyword panel computed live from REAL page fields:
 *   - document text (editor), #title, #slug (same inputs the core submits)
 * Checks: occurrences & density, presence in title/slug/first paragraph/
 * headings, title length, internal vs external links, images without alt,
 * and a sentence-based readability label. No invented APIs — pure client
 * statistics over the fields already on the write page.
 */

const PERSIAN_WORD = /[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF\u200c]+|[A-Za-z0-9]+/g;

const faNum = (n) => String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[+d]);
const esc = (str) => String(str ?? '')
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;');

const countWords = (text) => {
  const m = text.match(PERSIAN_WORD);
  return m ? m.length : 0;
};

const countOccurrences = (haystack, needle) => {
  if (!needle) return 0;
  const h = String(haystack || '').toLowerCase();
  const n = String(needle).trim().toLowerCase().replace(/["'«»]/g, '');
  if (!n) return 0;
  let count = 0;
  let idx = h.indexOf(n);
  while (idx !== -1) {
    count++;
    idx = h.indexOf(n, idx + n.length);
  }
  return count;
};

const normalizeSlug = (slug) => String(slug || '').replace(/[-_]+/g, ' ').trim();

export function init(api) {
  const L = api.strings || {};
  const view = api.view;
  const titleInput = document.getElementById('title');
  const slugInput = document.getElementById('slug');

  const storageKey = 'negaresh:seo-keyword:'
    + ((api.textarea.form && api.textarea.form.getAttribute('name')) || 'post');

  const loadKeyword = () => {
    try { return window.sessionStorage.getItem(storageKey) || ''; } catch (e) { return ''; }
  };
  const saveKeyword = (kw) => {
    try { window.sessionStorage.setItem(storageKey, kw); } catch (e) { /* noop */ }
  };

  const compute = (kw) => {
    const text = api.getDoc();
    const title = titleInput ? String(titleInput.value || '') : '';
    const slug = slugInput ? String(slugInput.value || '') : '';
    const words = countWords(text);
    const occurrences = countOccurrences(text, kw);
    const lines = text.split('\n');
    const headings = [];
    let firstPara = [];
    let collected = 0;
    let inFence = false;

    let images = 0, imagesNoAlt = 0, links = 0, linksInternal = 0, linksExternal = 0;

    lines.forEach((line) => {
      if (/^\s*(`{3,}|~{3,})/.test(line)) { inFence = !inFence; return; }
      if (inFence) return;
      const h = line.match(/^(#{1,6})\s+(.*)$/);
      if (h) headings.push(h[2]);
      else if (line.trim() !== '' && collected < 120) { firstPara.push(line); collected += line.length; }

      const anyRe = /(!?)\[([^\]]*)\]\(([^)]+)\)/g;
      let m;
      while ((m = anyRe.exec(line)) !== null) {
        if (m[1] === '!') {
          images++;
          if (!m[2].trim()) imagesNoAlt++;
        } else if (m[2].trim() !== '') {
          links++;
          if (/^(https?:)?\/\//i.test(m[3].trim())) linksExternal++;
          else linksInternal++;
        }
      }
    });

    const prose = lines.filter((l) => !/^\s*(```|~~~)/.test(l)).join(' ');
    const sentences = prose.split(/[.!؟…؛]+/).map((s) => s.trim()).filter((s) => s.length > 1);
    const avgLen = sentences.length
      ? sentences.reduce((a, s) => a + countWords(s), 0) / sentences.length : 0;

    return {
      words, occurrences,
      density: words ? Math.round((occurrences / words) * 1000) / 10 : 0,
      inTitle: countOccurrences(title, kw) > 0,
      inSlug: countOccurrences(normalizeSlug(slug), kw) > 0,
      inFirstPara: countOccurrences(firstPara.join(' '), kw) > 0,
      inHeadings: headings.filter((h) => countOccurrences(h, kw) > 0).length,
      headingsCount: headings.length,
      titleLen: title.length,
      slugLen: slug.length,
      images, imagesNoAlt, linksInternal, linksExternal,
      avgLen: Math.round(avgLen * 10) / 10,
      title: title.trim(),
    };
  };

  const check = (label, ok, hint) =>
    '<div class="negaresh-seo-row' + (ok ? ' is-ok' : '') + '">'
    + '<span class="negaresh-seo-label">' + label + '</span>'
    + '<span class="negaresh-seo-val">' + (ok ? '✓' : '✗') + (hint ? ' <small>' + hint + '</small>' : '') + '</span></div>';

  const openSeo = () => {
    let kw = loadKeyword();
    const { overlay, close } = api.modalOverlay(`
      <h3>${L.seoTools || 'ابزارهای سئو'}</h3>
      <label class="negaresh-modal-label">${L.focusKeyword || 'کلیدواژه‌ی کانونی'}
        <input type="text" data-k="kw" value="${esc(kw)}" placeholder="${esc(L.focusKeyword || 'کلیدواژه')}">
      </label>
      <div class="negaresh-seo-report"></div>
      <div class="negaresh-modal-actions">
        <button type="button" class="btn primary" data-act="ok">${L.ok || 'تأیید'}</button>
      </div>
    `);

    const input = overlay.querySelector('input[data-k="kw"]');
    const report = overlay.querySelector('.negaresh-seo-report');
    input.focus();

    const render = () => {
      kw = input.value.trim();
      saveKeyword(kw);
      const r = compute(kw);
      const hasKw = kw.length > 1;
      const readable = r.avgLen === 0 ? '' : (r.avgLen <= 18 ? (L.easy || 'ساده') : (r.avgLen <= 25 ? (L.medium || 'متوسط') : (L.hard || 'دشوار')));

      let html = '';
      if (hasKw) {
        html += '<div class="negaresh-seo-kw">'
          + faNum(r.occurrences) + '× ' + esc(kw)
          + ' — ' + (L.density || 'تراکم') + ' ' + faNum(r.density) + '٪'
          + '</div>';
        html += check(L.kwInTitle || 'در عنوان', r.inTitle, faNum(r.titleLen) + ' ' + (L.chars || 'نویسه'));
        html += check(L.kwInSlug || 'در نامک', r.inSlug);
        html += check(L.kwInIntro || 'در پاراگراف اول', r.inFirstPara);
        html += check(L.kwInHeadings || 'در سرتیترها (' + faNum(r.inHeadings) + '/' + faNum(r.headingsCount) + ')', r.inHeadings > 0);
      } else {
        html += '<div class="negaresh-seo-kw negaresh-seo-hint">' + (L.seoHint || 'برای شروع تحلیل، کلیدواژه‌ای بنویسید.') + '</div>';
      }
      const titleOk = r.titleLen >= 30 && r.titleLen <= 60;
      html += check((L.titleLength || 'طول عنوان') + ' (' + faNum(r.titleLen) + ')', titleOk, '۳۰–۶۰');
      html += check(L.imagesWithAlt || 'متن جایگزین تصاویر', r.images === 0 || r.imagesNoAlt === 0,
        faNum(r.images - r.imagesNoAlt) + '/' + faNum(r.images));
      html += '<div class="negaresh-seo-row"><span class="negaresh-seo-label">' + (L.links || 'پیوندها') + '</span><span class="negaresh-seo-val">'
        + (L.internal || 'داخلی') + ' ' + faNum(r.linksInternal) + ' / ' + (L.external || 'خارجی') + ' ' + faNum(r.linksExternal)
        + '</span></div>';
      if (readable) {
        html += '<div class="negaresh-seo-row"><span class="negaresh-seo-label">' + (L.readability || 'خوانایی') + '</span><span class="negaresh-seo-val">'
          + readable + ' (' + (L.avgSentence || 'میانگین جمله') + ' ' + faNum(r.avgLen) + ')</span></div>';
      }
      report.innerHTML = html;
    };

    let t = null;
    input.addEventListener('input', () => {
      if (t) clearTimeout(t);
      t = setTimeout(render, 250);
    });
    api.on('docchange', () => { if (overlay.isConnected) render(); });
    render();

    overlay.querySelector('button[data-act="ok"]').addEventListener('click', close);
  };

  api.addToolbarButton({
    id: 'seo',
    icon: 'target',
    title: L.seoTools || 'ابزارهای سئو',
    group: 7,
    action: openSeo,
  });
}
