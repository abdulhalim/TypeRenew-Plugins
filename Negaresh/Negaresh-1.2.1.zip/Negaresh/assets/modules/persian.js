/**
 * Negaresh shared Persian text utilities — Phase 3
 * ------------------------------------------------------------------
 * Code-aware fixers and segmentation shared by the writing assistant
 * (assistant.js) and the typography checker (typography.js).
 * Also hosts the as-you-type autocorrect data + logic (autocorrect.js)
 * and the text-alignment line helper used by the editor toolbar.
 * This module is imported WITHOUT a query string by all consumers so
 * the browser keeps a single module instance.
 */

const ZWNJ = '\u200c';
const TANWEEN = '\u064b'; // ً
const FA_LETTER = /[\u0621-\u064A\u0679-\u06D3]/;

// High-confidence compound words (Persian orthography guides)
const ZWNJ_DICTIONARY = [
  // --- به + X ---
  ['به علاوه', 'به\u200cعلاوه'],
  ['به عوان', 'به\u200cعنوان'],           // common typo
  ['به عنوان', 'به\u200cعنوان'],
  ['به صورت', 'به\u200cصورت'],
  ['به شرط', 'به\u200cشرط'],
  ['به طوری که', 'به\u200cطوری\u200cکه'],
  ['به طوری', 'به\u200cطوری'],
  ['به طور', 'به\u200cطور'],
  ['به دنبال', 'به\u200cدنبال'],
  ['به جا', 'به\u200cجا'],
  ['به جز', 'به\u200cجز'],
  ['به کمک', 'به\u200cکمک'],
  ['به یاد', 'به\u200cیاد'],
  ['به وجد', 'به\u200cوجد'],
  ['به وجود آمد', 'به\u200cوجود آمد'],
  ['به کار', 'به\u200cکار'],
  ['به دست', 'به\u200cدست'],
  ['به روی', 'به\u200cروی'],
  ['به همراه', 'به\u200cهمراه'],
  ['به مراتب', 'به\u200cمراتب'],
  ['به تدریج', 'به\u200cتدریج'],
  ['به سرعت', 'به\u200cسرعت'],
  ['به سادگی', 'به\u200cسادگی'],
  ['به آسانی', 'به\u200cآسانی'],
  ['به سختی', 'به\u200cسختی'],
  ['به زیبایی', 'به\u200cزیبایی'],
  ['به وضوح', 'به\u200cوضوح'],
  ['به راحتی', 'به\u200cراحتی'],
  ['به دقت', 'به\u200cدقت'],
  ['به تازگی', 'به\u200cتازگی'],
  ['به اشتباه', 'به\u200cاشتباه'],
  ['به اصطلاح', 'به\u200cاصطلاح'],
  ['به عین', 'به\u200cعین'],
  // --- غیر + X (بسته می‌شود) ---
  ['غیر ممکن', 'غیرممکن'],
  ['غیر قابل', 'غیرقابل'],
  ['غیر فعال', 'غیرفعال'],
  ['غیر رایگان', 'غیررایگان'],
  ['غیر مجاز', 'غیرمجاز'],
  ['غیر رسمی', 'غیررسمی'],
  ['غیر طبیعی', 'غیرطبیعی'],
  ['غیر عادی', 'غیرعادی'],
  ['غیر ضروری', 'غیرضروری'],
  ['غیر منطقی', 'غیرمنطقی'],
  ['غیر مستقیم', 'غیرمستقیم'],
  ['غیر دولتی', 'غیردولتی'],
  ['غیر نظامی', 'غیرنظامی'],
  ['غیر انسانی', 'غیرانسانی'],
  ['غیر واقعی', 'غیرواقعی'],
  ['غیر قابل قبول', 'غیرقابل قبول'],
  ['غیر قابل تحمل', 'غیرقابل تحمل'],
  ['غیر قابل باور', 'غیرقابل باور'],
  ['غیر قابل حل', 'غیرقابل حل'],
  // --- هر / هم / آن ---
  ['هر کس', 'هرکس'],
  ['هر چه', 'هرچه'],
  ['هر گاه', 'هرگاه'],
  ['هر چند', 'هرچند'],
  ['هر که', 'هر\u200cکه'],
  ['هم چنین', 'همچنین'],
  ['هم زمان', 'هم\u200cزمان'],
  ['هم چپ', 'هم\u200cچپ'],
  ['هم راستا', 'هم\u200cراستا'],
  ['هم فکر', 'هم\u200cفکر'],
  ['هم کار', 'هم\u200cکار'],
  ['هم سن', 'هم\u200cسن'],
  ['هم کلاس', 'هم\u200cکلاس'],
  ['هم مدرسه ای', 'هم\u200cمدرسه\u200cای'],
  ['هم اکنون', 'هم\u200cاکنون'],
  ['هم وزن', 'هم\u200cوزن'],
  ['هم تراز', 'هم\u200cتراز'],
  ['هم اندازه', 'هم\u200cاندازه'],
  ['هم نوع', 'هم\u200cنوع'],
  ['هم قواره', 'هم\u200cقواره'],
  ['همین که', 'همین\u200cکه'],
  ['آن که', 'آن\u200cکه'],
  ['همان که', 'همان\u200cکه'],
  ['چنان که', 'چنان\u200cکه'],
  ['چون که', 'چون\u200cکه'],
  ['وقتی که', 'وقتی\u200cکه'],
  ['در حالی که', 'در\u200cحالی\u200cکه'],
  ['حالی که', 'حالی\u200cکه'],
  ['چه بسا', 'چه\u200cبسا'],
  // --- بن بست و ترکیب‌های بسته/نیم‌بسته دیگر ---
  ['بن بست', 'بن\u200cبست'],
  ['بی حد', 'بی\u200cحد'],
  ['بی نهایت', 'بی\u200cنهایت'],
  ['بی نظیر', 'بی\u200cنظیر'],
  ['بی سابقه', 'بی\u200cسابقه'],
  ['بی توجه', 'بی\u200cتوجه'],
  ['بی دقت', 'بی\u200cدقت'],
  ['بی دردسر', 'بی\u200cدردسر'],
  ['بی ارتباط', 'بی\u200cارتباط'],
  ['بی نقص', 'بی\u200cنقص'],
  ['بی ربط', 'بی\u200cربط'],
  ['بی ارزش', 'بی\u200cارزش'],
  ['بی معنی', 'بی\u200cمعنی'],
  ['بی تردید', 'بی\u200cتردید'],
  ['بی شک', 'بی\u200cشک'],
  ['بی درنگ', 'بی\u200cدرنگ'],
  ['بی جهت', 'بی\u200cجهت'],
  ['بی حاصل', 'بی\u200cحاصل'],
  ['بی مزه', 'بی\u200cمزه'],
  ['بی حال', 'بی\u200cحال'],
  ['بی خیال', 'بی\u200cخیال'],
  ['بی صدا', 'بی\u200cصدا'],
  ['بی توجهی', 'بی\u200cتوجهی'],
  ['بی علاقه', 'بی\u200cعلاقه'],
  ['بی تحرک', 'بی\u200cتحرک'],
  ['بی ثبات', 'بی\u200cثبات'],
  ['بی اندازه', 'بی\u200cاندازه'],
  ['دوباره کاری', 'دوباره\u200cکاری'],
  ['چند برابر', 'چند\u200cبرابر'],
  ['چهار برابر', 'چهار\u200cبرابر'],
  ['پانزده خرداد', 'پانزده\u200cخرداد'],
  ['کم کاری', 'کم\u200cکاری'],
  ['کم آبی', 'کم\u200cآبی'],
  ['کم تجربه', 'کم\u200cتجربه'],
  ['کم خوابی', 'کم\u200cخوابی'],
  ['نیم ساعت', 'نیم\u200cساعت'],
  ['نیم میلیون', 'نیم\u200cمیلیون'],
  ['نیم کره', 'نیم\u200cکره'],
  ['بین المللی', 'بین\u200cالمللی'],
  ['راه آهن', 'راه\u200cآهن'],
  ['گفت وگو', 'گفت\u200cوگو'],
  ['گفت و گو', 'گفت\u200cوگو'],
  ['داد و ستد', 'داد\u200cوستد'],
  ['رفت و آمد', 'رفت\u200cوآمد'],
  ['خواه و نخواه', 'خواه\u200cونخواه'],
  ['آمد و شد', 'آمد\u200cوشد'],
  ['جای جای', 'جای\u200cجای'],
  ['گه گاهی', 'گه\u200cگاهی'],
  ['گاه گاهی', 'گاه\u200cگاهی'],
  ['شانه به شانه', 'شانه\u200cبه\u200cشانه'],
  ['رو به رو', 'رو\u200cبه\u200cرو'],
  ['رو در رو', 'رو\u200cدر\u200cرو'],
  ['سر به سر', 'سر\u200cبه\u200cسر'],
  ['پای به پای', 'پای\u200cبه\u200cپای'],
  ['دست به دست', 'دست\u200cبه\u200cدست'],
  ['پشت سر هم', 'پشت\u200cسر\u200cهم'],
  ['بر اساس', 'بر\u200cاساس'],
  ['بر خلاف', 'برخلاف'],
  ['بر علاوه', 'برعلاوه'],
  ['بر روی', 'بر\u200cروی'],
  ['برابر با', 'برابر\u200cبا'],
  ['در ضمن', 'در\u200cضمن'],
  ['در عین حال', 'در\u200cعین\u200cحال'],
  ['بدین صورت', 'بدین\u200cصورت'],
  ['بدین ترتیب', 'بدین\u200cترتیب'],
  ['بدین وسیله', 'بدین\u200cوسیله'],
  ['بدین منظور', 'بدین\u200cمنظور'],
  ['بدین دلیل', 'بدین\u200cدلیل'],
  ['بدین سان', 'بدین\u200cسان'],
  ['چه طور', 'چطور'],
  ['چه گونه', 'چگونه'],
  ['من جمله', 'من\u200cجمله'],
  // --- اشکال چسبیده‌ی غلط «می‌…» (باید نیم‌فاصله باشد) ---
  ['میشود', 'می\u200cشود'],
  ['میشد', 'می\u200cشد'],
  ['میشوم', 'می\u200cشوم'],
  ['میشوند', 'می\u200cشوند'],
  ['میباشد', 'می\u200cباشد'],
  ['میباشند', 'می\u200cباشند'],
  ['میکند', 'می\u200cکند'],
  ['میکنم', 'می\u200cکنم'],
  ['میتوان', 'می\u200cتوان'],
  ['میتواند', 'می\u200cتواند'],
  ['میتوانند', 'می\u200cتوانند'],
  ['میخواه', 'می\u200cخواه'],
  ['میخواهد', 'می\u200cخواهد'],
  ['میخواهم', 'می\u200cخواهم'],
  ['میدهد', 'می\u200cدهد'],
  ['میداد', 'می\u200cداد'],
  ['میرود', 'می\u200cرود'],
  ['میرفت', 'می\u200cرفت'],
  ['میآید', 'می\u200cآید'],
  ['میآورد', 'می\u200cآورد'],
  ['میدانم', 'می\u200cدانم'],
  ['میدانند', 'می\u200cدانند'],
  ['میرسد', 'می\u200cرسد'],
  ['میرسند', 'می\u200cرسند'],
  ['میگردد', 'می\u200cگردد'],
  ['میشناخت', 'می\u200cشناخت'],
  ['میگفت', 'می\u200cگفت'],
  ['میگرفت', 'می\u200cگرفت'],
  // --- ترکیب‌های بسته‌ی «هیچ» ---
  ['هیچ کس', 'هیچ\u200cکس'],
  ['هیچ چیز', 'هیچ\u200cچیز'],
  ['هیچ وقت', 'هیچ\u200cوقت'],
  ['هیچ گاه', 'هیچ\u200cگاه'],
  ['هیچ کدام', 'هیچ\u200cکدام'],
  ['هیچ وجه', 'هیچ\u200cوجه'],
  ['هیچ عنوان', 'هیچ\u200cعنوان'],
  // --- ترکیب‌های «به + هر/هیچ» ---
  ['به هیچ وجه', 'به\u200cهیچ\u200cوجه'],
  ['به هیچ عنوان', 'به\u200cهیچ\u200cعنوان'],
  ['به هر صورت', 'به\u200cهر\u200cصورت'],
  ['به هر حال', 'به\u200cهر\u200cحال'],
  // --- ترکیب‌های «در / با + …» ---
  ['در صورتی که', 'در\u200cصورتی\u200cکه'],
  ['در حالی که', 'در\u200cحالی\u200cکه'],
  ['به گونه‌ای', 'به\u200cگونه\u200cای'],
  ['با توجه به', 'با\u200cتوجه\u200cبه'],
  ['با این وجود', 'با\u200cاین\u200cوجود'],
  ['با این حال', 'با\u200cاین\u200cحال'],
  ['از این جهت', 'از\u200cاین\u200cجهت'],
  ['از این نظر', 'از\u200cاین\u200cنظر'],
  ['از این رو', 'از\u200cاین\u200cرو'],
  ['در واقع', 'در\u200cواقع'],
  ['در حال', 'در\u200cحال'],
  ['در نتیجه', 'در\u200cنتیجه'],
  ['با وجود', 'با\u200cوجود'],
  ['بدون شک', 'بدون\u200cشک'],
  ['بدون تردید', 'بدون\u200cتردید'],
  // --- «غیر + …» (بسته می‌شود) ---
  ['غیر قانونی', 'غیرقانونی'],
  ['غیر انتفاعی', 'غیرانتفاعی'],
  ['غیر مسقف', 'غیرمسقف'],
  // --- «هم + …» ---
  ['هم چنین', 'همچنین'],
  ['هم اکنون', 'هم\u200cاکنون'],
  ['هم زمان', 'هم\u200cزمان'],
  ['هم نوع', 'هم\u200cنوع'],
  ['هم وطن', 'هم\u200cوطن'],
  ['هم کار', 'هم\u200cکار'],
  ['هم کلاسی', 'هم\u200cکلاسی'],
  ['هم دانشگاهی', 'هم\u200cدانشگاهی'],
  // --- ضمایر و اشاره‌ها ---
  ['آن ها', 'آن\u200cها'],
  ['آنها', 'آن\u200cها'],
  ['این ها', 'این\u200cها'],
  ['اینها', 'این\u200cها'],
  ['آن گونه', 'آن\u200cگونه'],
  ['این گونه', 'این\u200cگونه'],
  ['آن طور', 'آن\u200cطور'],
  ['این طور', 'این\u200cطور'],
  ['آن جا', 'آن\u200cجا'],
  ['این جا', 'این\u200cجا'],
  ['آنجا', 'آن\u200cجا'],
  ['اینجا', 'این\u200cجا'],
  // --- جمع‌بندی با «ها» ---
  ['کتاب ها', 'کتاب\u200cها'],
  ['کتابها', 'کتاب\u200cها'],
  ['مردم ها', 'مردم\u200cها'],
  ['مردمها', 'مردم\u200cها'],
  ['دختر ها', 'دختر\u200cها'],
  ['دخترها', 'دختر\u200cها'],
  ['پسر ها', 'پسر\u200cها'],
  ['پسرها', 'پسر\u200cها'],
  ['خانه ها', 'خانه\u200cها'],
  ['خانهها', 'خانه\u200cها'],
  ['مدرسه ها', 'مدرسه\u200cها'],
  ['مدرسهها', 'مدرسه\u200cها'],
  // --- به + قید ---
  ['به موقع', 'به\u200cموقع'],
  ['به اندازه', 'به\u200cاندازه'],
  ['به حدی', 'به\u200cحدی'],
  ['به نحوی', 'به\u200cنحوی'],
  ['به آرامی', 'به\u200cآرامی'],
];

const ARABIC_CHAR_MAP = { 'ي': 'ی', 'ك': 'ک' };
const DIGIT_MAP = { '0': '۰', '1': '۱', '2': '۲', '3': '۳', '4': '۴', '5': '۵', '6': '۶', '7': '۷', '8': '۸', '9': '۹' };

/* ================================================================
 * As-you-type autocorrect (autocorrect.js) — data
 * ================================================================
 * Curated rule sets only (a few KB, zero per-keystroke cost).
 */

// Continuatives that safely merge with می/نمی ("می شود" → "می‌شود").
// Conservative on purpose — only forms where the merged spelling is
// the standard modern verb orthography.
const VERB_TAILS = new Set([
  // بودن / شدن
  'شد', 'شدم', 'شدی', 'شوم', 'شوی', 'شود', 'شوند', 'شدیم', 'شدند',
  'بود', 'بودم', 'بودی', 'بودیم', 'بودند', 'باشد', 'باشی', 'باشم', 'باشیم', 'باشید', 'باشند',
  // کرد
  'کرد', 'کردم', 'کردی', 'کردیم', 'کردند', 'کنم', 'کنی', 'کند', 'کنیم', 'کنند', 'کنید',
  // رفتن
  'رود', 'روم', 'روی', 'رویم', 'روند', 'رفت', 'رفتم', 'رفتی', 'رفتیم', 'رفتند',
  // آمدن / آوردن
  'آید', 'آیم', 'آیی', 'آییم', 'آیند', 'آمد', 'آمدم', 'آمدی', 'آمدیم', 'آمدند',
  'آورد', 'آوردم', 'آوردی', 'آوردیم', 'آوردند', 'آورم', 'آوری', 'آوریم', 'آورند',
  // داشتن
  'داشت', 'داشتم', 'داشتی', 'داشتیم', 'داشتند', 'دارد', 'دارم', 'داریم', 'دارید', 'دارند',
  // دادن
  'داد', 'دادم', 'دادی', 'دادیم', 'دادند', 'دهد', 'دهید', 'دهم', 'دهیم', 'دهند',
  // خوردن / نوشیدن
  'خورد', 'خوردم', 'خوردی', 'خوردیم', 'خوردند', 'خورم', 'خوری', 'خوریم', 'خورند',
  'نوشت', 'نوشتم', 'نوشتی', 'نوشتیم', 'نوشتند', 'نوشید', 'نوشیدم', 'نوشیدی', 'نوشیدیم', 'نوشیدند',
  // دیدن / دانستن / توانستن / خواستن
  'دید', 'دیدم', 'دیدی', 'دیدیم', 'دیدند', 'دانست', 'دانستم', 'دانستی', 'دانستیم', 'دانستند',
  'توانست', 'توانستم', 'توانستی', 'توانستیم', 'توانستند', 'خواست', 'خواستم', 'خواستی', 'خواستیم', 'خواستند',
  // گفتن / گرفتن
  'گفت', 'گفتم', 'گفتی', 'گفتیم', 'گفتند', 'گرفت', 'گرفتم', 'گرفتی', 'گرفتیم', 'گرفتند',
  'گیرم', 'گیری', 'گیریم', 'گیرند',
  // ساخت
  'ساخت', 'ساختم', 'ساختی', 'ساختیم', 'ساختند', 'سازد', 'سازند', 'سازم', 'سازی', 'سازیم', 'سازید',
  // رفتارهای پرکاربرد دیگر
  'خواند', 'خواندم', 'خواندی', 'خواندیم', 'خواندند', 'خوانم', 'خوانی', 'خوانیم',
  'راند', 'راندم', 'راندی', 'راندیم', 'راندند', 'شنید', 'شنیدم', 'شنیدی', 'شنیدیم', 'شنیدند',
  'خوابید', 'خوابیدم', 'خوابیدی', 'خوابیدیم', 'خوابیدند', 'خندید', 'خندیدم', 'خندیدی', 'خندیدیم', 'خندیدند',
  'ترسید', 'ترسیدم', 'ترسیدی', 'ترسیدیم', 'ترسیدند', 'گریست', 'گریستم', 'گریستی', 'گریستیم', 'گریستند',
  'فهمید', 'فهمیدم', 'فهمیدی', 'فهمیدیم', 'فهمیدند', 'نشست', 'نشستم', 'نشستی', 'نشستیم', 'نشستند',
  'برخاست', 'برخاستم', 'برخاستی', 'برخاستیم', 'برخاستند', 'پذیرفت', 'پذیرفتم', 'پذیرفتی', 'پذیرفتیم', 'پذیرفتند',
  'دوید', 'دویدم', 'دویدی', 'دویدیم', 'دویدند', 'آزمود', 'آزمودم', 'آزمودی', 'آزمودیم', 'آزمودند',
  'ماند', 'ماندم', 'ماندی', 'ماندیم', 'ماندند', 'یافت', 'یافتم', 'یافتی', 'یافتیم', 'یافتند',
  'شناخت', 'شناختم', 'شناختی', 'شناختیم', 'شناختند', 'شکست', 'شکستم', 'شکستی', 'شکستیم', 'شکستند',
  'ریخت', 'ریختم', 'ریختی', 'ریختیم', 'ریختند', 'انداخت', 'انداختم', 'انداختی', 'انداختیم', 'انداختند', 'اندازد', 'اندازم',
  'برد', 'بردم', 'بردی', 'بردیم', 'بردند', 'بست', 'بستم', 'بستند',
  // فعل‌های حال (می‌شنوم، می‌گویم، …)
  'گویم', 'گویی', 'گویند', 'دانم', 'دانی', 'دانیم', 'دانند',
  'نویسم', 'نویسی', 'نویسیم', 'نویسند', 'شنوم', 'شنوی', 'شنویم', 'شنویند',
  'بینم', 'بینی', 'بینیم', 'بینند', 'بیند', 'توانم', 'توانی', 'توانیم', 'توانند',
  // خواستن / داعی
  'خواهد', 'خواهم', 'خواهی', 'خواهیم', 'خواهید', 'خواهند',
  // متعدی کمتر‌کاربرد
  'پرسید', 'پرسیدم', 'پرسیدند', 'سوخت', 'سوختند', 'گریخت', 'گریختند',
  'کوشید', 'کوشیدند', 'لرزید', 'لرزیدند', 'نالید', 'نالیدند', 'جنگید', 'جنگیدند',
  'جست', 'جستند', 'زد', 'زدند', 'وزید', 'تابید', 'خزید', 'رویید', 'رنجید',
  'درید', 'دریدند', 'اندیشید', 'اندیشیدند', 'پنداشت', 'پنداشتند', 'انگاشت',
  'گسترد', 'گستردند', 'سپرد', 'سپردند', 'پرورد', 'نواخت', 'نواختند', 'فرمود', 'فرمودند',
  'بخشید', 'بخشیدم', 'بخشیدی', 'بخشیدیم', 'بخشیدند', 'بخشد',
  'شمارد', 'بارید', 'باریدم', 'باریدند', 'پرید', 'پریدم', 'پریدی', 'پریدیم', 'پریدند',
  'جنبید', 'جنبیدند', 'چرخید', 'چرخیدند', 'زیست', 'زیستم', 'زیستند',
  'پوشید', 'پوشیدم', 'پوشیدند', 'افزود', 'افزودم', 'افزودند', 'نمود', 'نمودم', 'نمودند',
  'نهاد', 'نهادم', 'نهادند', 'فرستاد', 'فرستادم', 'فرستادی', 'فرستادیم', 'فرستادند',
  'رسید', 'رسیدم', 'رسیدی', 'رسیدیم', 'رسیدند', 'رساند', 'رساندند',
  'بازگردد', 'فتد', 'افتم', 'افتی', 'افتیم', 'افتند',
  // متفاوت / ادبی
  'گردد', 'گردند', 'بایستد', 'بایست', 'شناسد', 'شناسند', 'شناسیم',
  'رقصید', 'رقصیدند', 'بخندد',
].filter(Boolean));

// Common Arabic-loan adverbs that must carry تنوین نصب ("تقریبا" → "تقریباً").
const TANWEEN_WORDS = new Set([
  'حتما', 'قطعا', 'مثلا', 'تقریبا', 'معمولا', 'احتمالا', 'واقعا', 'خصوصا', 'عمدتا',
  'مجددا', 'مستقلا', 'موقتا', 'عمدا', 'صرفا', 'ناگزیرا', 'اتفاقا', 'اساسا', 'اصولا',
  'اولا', 'ثانیا', 'ثالثا', 'رابعا', 'فعلا', 'نسبتا', 'مسلما', 'کلا', 'انفرادا',
  'مجموعا', 'تخمینا', 'دقیقا', 'سریعا', 'کاملا', 'مطلقا', 'علنا', 'بدوا', 'تدریجا',
  'غالبا', 'شخصا', 'رسمیا', 'قاطعا', 'احتراما', 'جزئیا', 'مکررا',
  'یقینا', 'لزوما', 'اکثرا', 'اقلا', 'نهایتا', 'عملا', 'طبعا', 'ظاهرا', 'محققا',
  'ترتیبا', 'جزما', 'دوما', 'ذاتا', 'مستقیما', 'مرتبا', 'رسما', 'سابقا', 'حرفیا',
  'مجانا', 'مشخصا', 'اختصاصا', 'ضمنا', 'تماما', 'مفصلا', 'تفصیلا', 'محسوسا', 'جمعا',
  'ایضا', 'تعجبا', 'انصافا', 'امتنانا', 'ختما', 'قیاسا', 'فورا', 'ایجمالا', 'تحقیقا',
  'البتها', 'مشترکا', 'استنادا', 'تعمدا', 'ناچارا', 'اخیرا', 'بعضا', 'گاها',
  // --- کلمات پرکاربرد دیگر ---
  'لطفا', 'مطمئنا', 'باطنا', 'عقلا', 'شرعا', 'عرفا', 'قانونا',
  'سرا', 'جهرا', 'اجبارا', 'اختیارا', 'فرعا', 'عرضا', 'نوعا', 'جنسا',
  'مقدارا', 'کیفا', 'کمیتا', 'شکلا', 'مفهوما', 'لفظا', 'کتابتا', 'نطقا',
  'نظریا', 'علمیا', 'فنیا', 'اقتصادیا', 'سیاسیا', 'اجتماعیا', 'فرهنگیا',
  'تاریخیا', 'جغرافیایا', 'ریاضیا', 'فیزیکیا', 'شیمیا', 'زیستیا',
  'طبيا', 'مهندسیا', 'هنریا', 'ادبیا', 'عرفانیا', 'فلسفیا', 'منطقیا',
  'اخلاقیا', 'روانیا',
]);

/**
 * Split the text into segments; code segments are marked and left untouched.
 * Recognizes fenced blocks (``` or ~~~, opening & closing lines) and inline
 * code spans (`…`) — enough for a writing assistant.
 */
export const segmentDoc = (text) => {  const segments = [];
  const lines = text.split('\n');
  let offset = 0;
  let i = 0;
  let buffer = [];

  const flush = (isCode) => {
    if (!buffer.length) return;
    segments.push({ code: isCode, text: buffer.join('\n') });
    buffer = [];
  };

  let inFence = false;
  let fenceMarker = '';
  while (i < lines.length) {
    const line = lines[i];
    const fence = line.match(/^\s*(`{3,}|~{3,})/);
    if (fence) {
      if (!inFence) {
        flush(false);
        inFence = true;
        fenceMarker = fence[1][0];
        buffer.push(line);
      } else if (fence[1][0] === fenceMarker) {
        buffer.push(line);
        flush(true);
        inFence = false;
      } else {
        buffer.push(line);
      }
    } else {
      buffer.push(line);
    }
    i++;
  }
  flush(inFence);

  // Now split non-code segments on inline code spans
  const final = [];
  segments.forEach((seg) => {
    if (seg.code) {
      final.push(seg);
      return;
    }
    let rest = seg.text;
    const re = /(`+)([^`]|[\s\S]*?[^`])\1(?!`)/g;
    let last = 0;
    let m;
    while ((m = re.exec(rest)) !== null) {
      if (m.index > last) final.push({ code: false, text: rest.slice(last, m.index) });
      final.push({ code: true, text: m[0] });
      last = m.index + m[0].length;
    }
    if (last < rest.length) final.push({ code: false, text: rest.slice(last) });
  });
  return final;
};

/* ================================================================
 * Protected spans — URLs, raw HTML, footnote refs (fixer exclusions)
 * ================================================================
 * Fixers (digits, quotes, …) must never touch:
 *  - markdown link/image destinations and their optional titles
 *    (![alt](img-2024.png "Title") / [text](https://site.com/1))
 *  - reference-style definitions ([label]: https://… / [^1]: …)
 *  - inline footnote refs ([^1]) — the label must stay verbatim
 *  - raw HTML tags (iframe/video/img/a — attributes keep digits/quotes)
 *    and autolinks (<https://…>)
 *  - bare http(s)/ftp URLs (video embeds, pasted links)
 *  - numeric HTML entities (&#169; / &#xA9;)
 * Otherwise a "1" inside a URL would become "۱" and the link breaks.
 *
 * Implementation: each protected span is replaced by a sentinel token
 * (\u0001 + bijective-base-26 letters + \u0001) that no fixer can alter
 * (letters only — fixDigits never touches them), then the original text
 * is restored after the fixers ran.
 */

const SENTINEL = '\u0001';

const indexToLetters = (n) => {
  let s = '';
  let x = n;
  do {
    s = String.fromCharCode(97 + (x % 26)) + s;
    x = Math.floor(x / 26) - 1;
  } while (x >= 0);
  return s;
};

const lettersToIndex = (letters) => {
  let x = 0;
  for (let i = 0; i < letters.length; i++) {
    x = x * 26 + (letters.charCodeAt(i) - 96);
  }
  return x - 1;
};

const maskProtectedSpans = (text) => {
  if (text.indexOf(SENTINEL) !== -1) {
    // Document already contains the control char — masking would be unsafe;
    // run the fixers unprotected (same behaviour as before this guard).
    return { masked: text, spans: null };
  }
  const spans = [];
  const mask = (s) => {
    spans.push(s);
    return SENTINEL + indexToLetters(spans.length - 1) + SENTINEL;
  };
  let out = text;
  // 1) markdown link/image destination (+ optional quoted title);
  //    single balanced parens inside URLs (Wikipedia-style) are kept
  out = out.replace(/(!?\[[^\]\n]*\]\()((?:[^()\n]|\([^()\n]*\))*)(\))/g,
    (m, open, dest, close) => open + mask(dest) + close);
  // 2) reference definitions — [label]: destination …
  out = out.replace(/^([ \t]*\[[^\]\n]+\]:[ \t]*)(\S+)([^\n]*)$/gm,
    (m, head, dest, tail) => head + mask(dest) + tail);
  // 3) inline footnote refs — [^1] must stay verbatim to match its definition
  out = out.replace(/\[\^[^\]\n]+\]/g, mask);
  // 4) raw HTML tags + autolinks — attributes keep their digits and quotes
  out = out.replace(/<[a-zA-Z/!][^<>\n]*>/g, mask);
  // 5) bare URLs — video/file links (own line or inline)
  out = out.replace(/\b(?:https?|ftp):\/\/[^\s<>\u200c]+/gi, mask);
  // 6) numeric HTML entities
  out = out.replace(/&#\d+;|&#x[0-9a-f]+;/gi, mask);
  return { masked: out, spans };
};

const restoreProtectedSpans = (text, spans) => {
  if (!spans || text.indexOf(SENTINEL) === -1) return text;
  let out = '';
  let rest = text;
  let guard = 0;
  while (true) {
    const at = rest.indexOf(SENTINEL);
    if (at === -1) break;
    out += rest.slice(0, at);
    rest = rest.slice(at + 1);
    const m = /^[a-z]+/.exec(rest);
    if (!m) break; // corrupted token — bail out conservatively
    rest = rest.slice(m[0].length + (rest.charAt(m[0].length) === SENTINEL ? 1 : 0));
    const idx = lettersToIndex(m[0]);
    out += (idx >= 0 && idx < spans.length) ? spans[idx] : '';
    if (guard++ > 100000) break;
  }
  return out + rest;
};

const fixZwnj = (t) => {
  let out = t;
  for (const [wrong, right] of ZWNJ_DICTIONARY) {
    out = out.replace(new RegExp('(^|[\\s\\(\\[«])' + wrong.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '($|[\\s\\.,،؛؟!:\\)\\]»])', 'g'), '$1' + right + '$2');
  }
  // می / نمی + space + verb → ZWNJ
  out = out.replace(/(^|\s)(ن?می) ([^\s\u200c])/g, '$1$2\u200c$3');
  // word + space + ها / های /هایی → ZWNJ
  out = out.replace(/(^|\s)(\S{1,20}?[^\s\u200c]) های(?=[\s،.؛؟!:\)\]»]|$)/g, '$1$2\u200cهای');
  out = out.replace(/(^|\s)(\S{1,20}?[^\s\u200c]) هایی(?=[\s،.؛؟!:\)\]»]|$)/g, '$1$2\u200cهایی');
  out = out.replace(/(^|\s)(\S{1,20}?[^\s\u200c]) ها(?=[\s،.؛؟!:\)\]»]|$)/g, '$1$2\u200cها');
  return out;
};

const fixArabicChars = (t) => t.replace(/[يك]/g, (c) => ARABIC_CHAR_MAP[c] || c);

const fixDigits = (t) => t.replace(/[0-9]/g, (d) => DIGIT_MAP[d]);

/**
 * Batch autocorrect — برای متن کپی‌شده (paste).
 *
 * این تابع همان منطق autocorrectWord و autocorrectMerge را روی همه‌ی
 * کلمات متن اعمال می‌کند، تا متن‌های کپی‌شده هم مثل تایپ‌شده تصحیح شوند.
 *
 * کار می‌کند:
 *   ۱) روی هر کلمه، autocorrectWord را صدا می‌زند (CLOSED_AUTOFIX، TANWEEN، ی/ک).
 *   ۲) بررسی می‌کند که آیا کلمه در ZWNJ_DICTIONARY هست (مثل «اینها» → «این‌ها»).
 *   ۳) روی هر جفت کلمه متوالی، autocorrectMerge را صدا می‌زند (می + فعل، کلمه + ها).
 *   ۴) اگر تغییری رخ داد، آن را اعمال می‌کند.
 *
 * نکته: این تابع «جابه‌جایی» نمی‌کند — فقط اگر کلمه با دیکشنری مطابقت داشت
 * تصحیح می‌کند. پس خطر اشتباه پایین است.
 */
const fixAutocorrectBatch = (text) => {
  if (!text) return text;
  // تقسیم به توکن‌ها (کلمه + فاصله/علائم)
  const tokens = text.split(/(\s+)/); // حفظ فاصله‌ها
  if (!tokens.length) return text;

  // ساخت یک Map از ZWNJ_DICTIONARY برای جستجوی سریع کلمه‌ی منفرد
  // (مثل «اینها» → «این‌ها»، «کتابها» → «کتاب‌ها»، «هیچکس» → «هیچ‌کس»)
  if (!ZWNJ_LOOKUP) {
    ZWNJ_LOOKUP = {};
    for (const [wrong, right] of ZWNJ_DICTIONARY) {
      // فقط ورودی‌هایی که کلیدشان یک کلمه‌ی منفرد است (بدون فاصله)
      if (!/\s/.test(wrong)) {
        ZWNJ_LOOKUP[wrong] = right;
      }
    }
  }

  let changed = false;
  const out = [];

  for (let i = 0; i < tokens.length; i++) {
    const tok = tokens[i];
    if (/^\s+$/.test(tok) || tok === '') { out.push(tok); continue; }

    // جدا کردن کلمه از علائم نگارشی دنباله
    const m = tok.match(/^([^،.!؟;:\s…]*)([،.!؟;:\s…]*)$/);
    if (!m || !m[1]) { out.push(tok); continue; }
    const core = m[1];
    const tail = m[2] || '';

    // ۱) autocorrectWord روی کلمه (CLOSED_AUTOFIX, TANWEEN, ی/ک)
    const fixed = autocorrectWord(tok);
    if (fixed !== null) {
      out.push(fixed);
      changed = true;
      continue;
    }

    // ۲) بررسی ZWNJ_DICTIONARY برای کلمه‌ی منفرد (مثل «اینها»)
    const cleaned = cleanArabic(core);
    if (ZWNJ_LOOKUP[cleaned]) {
      out.push(ZWNJ_LOOKUP[cleaned] + tail);
      changed = true;
      continue;
    }

    // ۳) autocorrectMerge با کلمه‌ی قبلی (اگر فاصله‌ی معمولی بینشان بود)
    if (i >= 2 && /^\s+$/.test(tokens[i - 1]) && !/[،.!؟;:]/.test(tokens[i - 1])) {
      const prevTok = tokens[i - 2];
      if (prevTok && !/^\s+$/.test(prevTok)) {
        const pm = prevTok.match(/^([^،.!؟;:\s…]*)([،.!؟;:\s…]*)$/);
        if (pm && pm[1]) {
          const merged = autocorrectMerge(pm[1], core);
          if (merged !== null) {
            out[out.length - 2] = merged + tail;
            out.pop(); // فاصله
            out.push(''); // کلمه‌ی فعلی
            changed = true;
            continue;
          }
        }
      }
    }

    out.push(tok);
  }

  if (!changed) return text;
  return out.join('');
};

// کش برای جستجوی سریع ZWNJ_DICTIONARY (ساخته‌شده در اولین فراخوانی)
let ZWNJ_LOOKUP = null;

const fixQuotes = (t) => {
  // Paired straight double quotes → «…»
  let out = '';
  let open = false;
  for (const ch of t) {
    if (ch === '"') {
      out += open ? '»' : '«';
      open = !open;
    } else {
      out += ch;
    }
  }
  return out;
};

const fixSpaces = (t) => {
  // Collapse runs of 2+ spaces between words — keep leading indent (lists,
  // code-like blocks) and trailing spaces (markdown hard line breaks).
  return t.split('\n').map((line) => {
    const lead = (line.match(/^[\t ]*/) || [''])[0];
    const trail = (line.match(/[\t ]*$/) || [''])[0];
    const mid = line.slice(lead.length, line.length - trail.length);
    return lead + mid.replace(/ {2,}/g, ' ') + trail;
  }).join('\n');
};

const fixPunctuation = (t) => {
  let out = t;
  // no space before Persian punctuation
  out = out.replace(/ +([،؛؟!])/g, '$1');
  // one space after ، ؛ ؟ ! when followed by a letter (not another punct/end);
  // "[" is excluded from the lookahead so the markdown image opener
  // ![alt](url) is never split into "! [alt](url)"
  out = out.replace(/([،؛؟!])(?=[^\s\d\)\]\}»"'\.,،؛؟!\n\[])/g, '$1 ');
  // ellipsis …
  out = out.replace(/\.\.\./g, '…');
  return out;
};

export const FIXERS = [
  { id: 'autocorrect', safe: true, fn: fixAutocorrectBatch },
  { id: 'zwnj', safe: true, fn: fixZwnj },
  { id: 'arabic', safe: true, fn: fixArabicChars },
  { id: 'digits', safe: true, fn: fixDigits },
  { id: 'quotes', safe: true, fn: fixQuotes },
  { id: 'spaces', safe: true, fn: fixSpaces },
  { id: 'punct', safe: true, fn: fixPunctuation },
];

/** Apply the given fixer ids to text (code segments, URLs and raw HTML untouched). */
export const applyFixers = (text, ids) => {
  const enabled = FIXERS.filter((f) => ids.includes(f.id));
  return segmentDoc(text).map((seg) => {
    if (seg.code) return seg.text;
    const { masked, spans } = maskProtectedSpans(seg.text);
    const fixed = enabled.reduce((acc, f) => f.fn(acc), masked);
    return restoreProtectedSpans(fixed, spans);
  }).join('');
};

/** Count how many characters each fixer would change. */
export const previewFixers = (text, ids) => {
  const counts = {};
  const enabled = FIXERS.filter((f) => ids.includes(f.id));
  segmentDoc(text).forEach((seg) => {
    if (seg.code) return;
    const { masked } = maskProtectedSpans(seg.text);
    enabled.forEach((f) => {
      const fixed = f.fn(masked);
      counts[f.id] = (counts[f.id] || 0) + Math.abs(fixed.length - masked.length)
        + diffChars(masked, fixed);
    });
  });
  return counts;
};

const diffChars = (a, b) => {
  // count positional differences for same-length replacements
  let n = 0;
  const min = Math.min(a.length, b.length);
  for (let i = 0; i < min; i++) if (a[i] !== b[i]) n++;
  return Math.max(0, n - Math.abs(a.length - b.length));
};

/* ================================================================
 * As-you-type autocorrect — pure functions (autocorrect.js)
 * ================================================================ */

const cleanArabic = (t) => t.replace(/[يك]/g, (c) => ARABIC_CHAR_MAP[c] || c);

// Wrongly-glued "می…" forms typed without the ZWNJ — the single most common
// Persian typing slip ("میشود" must be "می‌شود").
const CLOSED_AUTOFIX = {
  // --- افعال چسبیده‌ی غلط «می…» (باید نیم‌فاصله باشد) ---
  'میشود': 'می\u200cشود', 'میشد': 'می\u200cشد', 'میشوم': 'می\u200cشوم', 'میشوند': 'می\u200cشوند',
  'میباشد': 'می\u200cباشد', 'میباشند': 'می\u200cباشند', 'میباشم': 'می\u200cباشم',
  'میکند': 'می\u200cکند', 'میکنم': 'می\u200cکنم', 'میکنند': 'می\u200cکنند',
  'میتوان': 'می\u200cتوان', 'میتواند': 'می\u200cتواند', 'میتوانند': 'می\u200cتوانند', 'میتوانم': 'می\u200cتوانم',
  'میتوانی': 'می\u200cتوانی', 'میتوانیم': 'می\u200cتوانیم',
  'میخواه': 'می\u200cخواه', 'میخواهد': 'می\u200cخواهد', 'میخواهم': 'می\u200cخواهم', 'میخواهند': 'می\u200cخواهند',
  'میخواهی': 'می\u200cخواهی',
  'میدهد': 'می\u200cدهد', 'میداد': 'می\u200cداد', 'میداند': 'می\u200cداند',
  'میدانم': 'می\u200cدانم', 'میدانی': 'می\u200cدانی', 'میدانند': 'می\u200cدانند',
  'میرود': 'می\u200cرود', 'میرفت': 'می\u200cرفت', 'میرسد': 'می\u200cرسد', 'میرسند': 'می\u200cرسند',
  'میروم': 'می\u200cروم', 'میروی': 'می\u200cروی', 'میرویم': 'می\u200cرویم', 'میروند': 'می\u200cروند',
  'میآید': 'می\u200cآید', 'میآورد': 'می\u200cآورد', 'میآورم': 'می\u200cآورم',
  'میآی': 'می\u200cآی', 'میآیم': 'می\u200cآیم', 'میآیی': 'می\u200cآیی', 'میآیند': 'می\u200cآیند',
  'میاید': 'می\u200cآید', 'میای': 'می\u200cآی', 'میایم': 'می\u200cآیم', 'میایی': 'می\u200cآیی', 'میایند': 'می\u200cآیند',
  'میدوم': 'می\u200cدوم', 'میدویم': 'می\u200cدویم',
  'میگردد': 'می\u200cگردد', 'میگفت': 'می\u200cگفت', 'میگرفت': 'می\u200cگرفت',
  'میگوید': 'می\u200cگوید', 'میگویند': 'می\u200cگویند',
  'میگیرد': 'می\u200cگیرد', 'میگیرند': 'می\u200cگیرند',
  'میافتد': 'می\u200cافتد', 'میماند': 'می\u200cماند',
  'میخورند': 'می\u200cخورند', 'میکوشند': 'می\u200cکوشند',
  'نمیشود': 'نمی\u200cشود', 'نمیکند': 'نمی\u200cکند', 'نمیتوان': 'نمی\u200cتوان', 'نمیباشد': 'نمی\u200cباشد',
  'نمیکند': 'نمی\u200cکند', 'نمیکنند': 'نمی\u200cکنند',
  'نمیتوانم': 'نمی\u200cتوانم', 'نمیتوانی': 'نمی\u200cتوانی',
  'نمیداند': 'نمی\u200cداند', 'نمیدانم': 'نمی\u200cدانم', 'نمیدانی': 'نمی\u200cدانی', 'نمیدانند': 'نمی\u200cدانند',
  'نمیرود': 'نمی\u200cرود', 'نمیرسد': 'نمی\u200cرسد', 'نمیرسند': 'نمی\u200cرسند',
  'نمیگوید': 'نمی\u200cگوید', 'نمیگویند': 'نمی\u200cگویند',
  'نمیدهد': 'نمی\u200cدهد', 'نمیآید': 'نمی\u200cآید',
  // --- ی/ک عربی → فارسی ---
  'كتاب': 'کتاب', 'كي': 'کی', 'يك': 'یک', 'بكار': 'بکار', 'بيشتر': 'بیشتر',
  'كيك': 'کیک', 'كوچك': 'کوچک', 'كجا': 'کجا', 'كدام': 'کدام', 'كسي': 'کسی',
  'كساني': 'کسانی', 'چيزي': 'چیزی', 'چيزها': 'چیزها',
  'اين': 'این', 'اينها': 'این‌ها', 'اينگونه': 'این‌گونه', 'اينجوري': 'این‌جوری',
  'همين': 'همین', 'همينطور': 'همین‌طور', 'همچنين': 'همچنین', 'چنين': 'چنین',
  'خير': 'خیر', 'بلي': 'بلی', 'متشكرم': 'متشکرم',
  'هيچ': 'هیچ', 'هيچكس': 'هیچ‌کس', 'هيچچيز': 'هیچ‌چیز', 'هيچوقت': 'هیچ‌وقت', 'هيچگاه': 'هیچ‌گاه',
  'هميشه': 'همیشه', 'گاهي': 'گاهی', 'بعضي': 'بعضی', 'بسياري': 'بسیاری',
  'اكثر': 'اکثر', 'اكثريت': 'اکثریت', 'اقليت': 'اقلیت', 'جمعي': 'جمعی',
  'تك': 'تک', 'تكي': 'تکی', 'دوتايي': 'دوتایی', 'سهتايي': 'سه‌تایی', 'چهارتايي': 'چهارتایی',
  // --- تنوین کلمات پرکاربرد ---
  'لطفا': 'لطفاً', 'حتما': 'حتماً', 'واقعا': 'واقعاً', 'قطعا': 'قطعاً',
  'مطمئنا': 'مطمئناً', 'اصلا': 'اصلاً', 'تقريبا': 'تقریباً', 'طبعا': 'طبعاً', 'مثلا': 'مثلاً',
  // --- املای دیگر ---
  'انشاالله': 'ان‌شاءالله',
  'منون': 'ممنون',
};

/**
 * Fix a word the user just finished typing (before the space is inserted).
 * Applies: wrongly-glued "می…" → ZWNJ form, Arabic ي/ك → Persian ی/ک, and
 * تنوین for known -a adverbs ("تقریبا" → "تقریباً"). Trailing punctuation
 * is preserved. Returns the corrected word, or null when nothing changed.
 */
export const autocorrectWord = (rawWord) => {
  const m = String(rawWord || '').match(/^([^،.!؟;:\s…][^،.!؟;:\s…]*)([،.!؟;:\s…]*)$/);
  if (!m) return null;
  let core = m[1];
  const tail = m[2] || '';
  const fixed = cleanArabic(core);
  if (CLOSED_AUTOFIX[fixed]) {
    return CLOSED_AUTOFIX[fixed] + tail;
  }
  if (TANWEEN_WORDS.has(fixed)) {
    return fixed + TANWEEN + tail;
  }
  if (fixed !== core) {
    return fixed + tail;
  }
  return null;
};

/**
 * Merge the previous word with the word just typed:
 *   ("می"|"نمی", verb tail) → می‌شود / نمی‌کند   (ZWNJ)
 *   (persian word, "ها"|"های"|"هایی") → کتاب‌ها   (ZWNJ)
 * Returns the merged string or null when no rule applies.
 */
export const autocorrectMerge = (prev, word) => {
  const p = String(prev || '');
  const w = cleanArabic(String(word || '').replace(/([،.!؟;:])$/, ''));
  if (!w || !FA_LETTER.test(w)) return null;
  const pc = cleanArabic(p);

  if (w === 'ها' || w === 'های' || w === 'هایی') {
    return FA_LETTER.test(pc) && !/\u200c$/.test(pc) ? pc + ZWNJ + w : null;
  }
  if ((pc === 'می' || pc === 'نمی') && VERB_TAILS.has(w)) {
    return pc + ZWNJ + w;
  }
  return null;
};

/* ================================================================
 * Text alignment — line helper (editor toolbar)
 * ================================================================
 * HyperDown passes block-level HTML through raw WITHOUT parsing the
 * markdown inside, so a <div> wrapper would disable the markdown of
 * the wrapped paragraph. An inline <span> keeps the line a normal
 * paragraph (markdown inside still rendered) and "display:block" makes
 * it a block so text-align applies. Verified against the bundled
 * JS parser AND var/Utils/HyperDown.php (both use blockHtmlTags).
 */

const ALIGN_RE = /^(\s*)<span style="display:block;text-align:(right|center|left|justify);?">([\s\S]*)<\/span>(\s*)$/;

export const ALIGNMENTS = ['right', 'center', 'left', 'justify'];

/**
 * Wrap / re-align / unwrap one line for the given alignment.
 * Returns the new line text (same reference when unchanged).
 */
export const alignLine = (line, align) => {
  const m = String(line).match(ALIGN_RE);
  if (m) {
    if (m[2] === align) return m[1] + m[3] + m[4]; // toggle off
    return m[1] + '<span style="display:block;text-align:' + align + '">' + m[3] + '</span>' + m[4];
  }
  return '<span style="display:block;text-align:' + align + '">' + line + '</span>';
};

/** True when a line can carry an alignment wrapper (plain prose only). */
export const isAlignableLine = (line) => {
  const t = String(line);
  if (t.trim() === '') return false;
  return !/^(\s*)(#{1,6}\s|[-*+]\s|\d+\.\s|>\s?|```|~~~|\||!\[|<[a-z])/i.test(t);
};

