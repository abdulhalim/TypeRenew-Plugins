/**
 * Negaresh Persian writing assistant — Phase 3
 * ------------------------------------------------------------------
 * One-click, code-aware Persian text fixes (نیم‌فاصله، حروف عربی، ارقام،
 * گیومه، فاصله‌ها و علائم نگارشی). Scope: whole document or selection.
 * The fixer implementations live in ./persian.js (shared).
 */

import { FIXERS, applyFixers, previewFixers } from './persian.js';

export function init(api) {
  const L = api.strings || {};
  const view = api.view;

  const FIXER_LABELS = {
    autocorrect: L.fixAutocorrect || 'تصحیح خودکار کلمات (می‌شود، تقریباً، ی/ک)',
    zwnj: L.fixZwnj || 'اصلاح نیم‌فاصله‌ها',
    arabic: L.fixArabicChars || 'تبدیل ي/ك عربی به ی/ک فارسی',
    digits: L.fixDigits || 'تبدیل ارقام انگلیسی به فارسی',
    quotes: L.fixQuotes || 'گیومه‌های مستقیم به «»',
    spaces: L.fixSpaces || 'حذف فاصله‌های تکراری',
    punct: L.fixPunctuation || 'فاصله‌گذاری علائم نگارشی',
  };

  const openAssistant = () => {
    const { state } = view;
    const sel = state.selection.main;
    const hasSelection = sel.from !== sel.to;
    const scope = hasSelection ? state.sliceDoc(sel.from, sel.to) : api.getDoc();

    // Persian digits for the per-fixer change counts
    const faNum = (n) => String(n).replace(/[0-9]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d]);

    const { overlay, close } = api.modalOverlay(`
      <h3>${L.assistant || 'دستیار نگارش فارسی'}</h3>
      <p class="negaresh-modal-help">${hasSelection ? (L.applyToSelection || 'فقط روی انتخاب') : (L.applyToAll || 'روی کل نوشته')}</p>
      <div class="negaresh-assist-list">
        ${FIXERS.map((f) => `
          <label class="negaresh-check"><input type="checkbox" data-fix="${f.id}" checked> <span>${FIXER_LABELS[f.id] || f.id}</span>
          <span class="negaresh-fix-count" data-count="${f.id}"></span></label>
        `).join('')}
      </div>
      <div class="negaresh-modal-actions">
        <button type="button" class="btn primary" data-act="ok">${L.apply || 'اعمال'}</button>
        <button type="button" class="btn btn-link" data-act="cancel">${L.cancel || 'انصراف'}</button>
      </div>
    `);

    const boxes = Array.from(overlay.querySelectorAll('input[data-fix]'));
    const selectedIds = () => boxes.filter((b) => b.checked).map((b) => b.dataset.fix);

    const updatePreview = () => {
      const counts = previewFixers(scope, selectedIds());
      boxes.forEach((b) => {
        const el = overlay.querySelector(`[data-count="${b.dataset.fix}"]`);
        if (el) el.textContent = counts[b.dataset.fix]
          ? faNum(counts[b.dataset.fix]) + ' ' + (L.issues || 'مورد') : '';
      });
    };
    boxes.forEach((b) => b.addEventListener('change', updatePreview));
    updatePreview();

    const apply = () => {
      const ids = selectedIds();
      if (!ids.length) return close();
      const fixed = applyFixers(scope, ids);
      if (fixed === scope) {
        api.toast(L.noIssues || 'تغییری لازم نبود', 'info');
        close();
        return;
      }
      if (hasSelection) {
        view.dispatch({
          changes: { from: sel.from, to: sel.to, insert: fixed },
          userEvent: 'input.assistant',
        });
      } else {
        api.setDoc(fixed, 'end');
      }
      view.focus();
      api.toast(L.applied || 'اعمال شد', 'success');
      close();
    };

    overlay.querySelector('button[data-act="ok"]').addEventListener('click', apply);
    overlay.querySelector('button[data-act="cancel"]').addEventListener('click', close);
  };

  api.addToolbarButton({
    id: 'assistant',
    icon: 'wand',
    title: L.assistant || 'دستیار نگارش فارسی',
    group: 7,
    action: openAssistant,
  });
}
