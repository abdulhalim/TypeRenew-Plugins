/**
 * Negaresh advanced table module — Phase 2
 * ------------------------------------------------------------------
 *  - Replaces the basic table dialog with a visual size-picker grid
 *    (hover to choose rows × columns), optional header row and per-table
 *    alignment (HyperDown supports `:---`, `:---:`, `---:`).
 *  - While the caret is inside a pipe table, a context toolbar offers:
 *    insert/delete row & column, per-column alignment, delete table.
 *
 * All operations are plain text transforms on the markdown source — the
 * output stays 100% HyperDown-compatible.
 */

const isTableRow = (line) => /^\s*\|.*\|\s*$/.test(line) || /^\s*\|/.test(line);
const isSeparator = (cells) => cells.length > 0 && cells.every((c) => /^:?-{2,}:?$/.test(c.trim()));

const splitRow = (line) => {
  let t = line.trim();
  if (t.startsWith('|')) t = t.slice(1);
  if (t.endsWith('|')) t = t.slice(0, -1);
  // Split on unescaped pipes (merge cells whose pipe is escaped \|)
  const parts = t.split('|');
  const out = [];
  let cur = null;
  for (const p of parts) {
    cur = cur === null ? p : cur + '|' + p;
    const tb = (cur.match(/\\+$/) || [''])[0].length;
    if (tb % 2 === 0) {
      out.push(cur.trim());
      cur = null;
    }
  }
  if (cur !== null) out.push(cur.trim());
  return out;
};

const alignMarker = (align, width) => {
  const d = '-'.repeat(Math.max(3, width - 2));
  if (align === 'left') return ':' + '-'.repeat(Math.max(2, width - 1));
  if (align === 'right') return '-'.repeat(Math.max(2, width - 1)) + ':';
  if (align === 'center') return ':' + d + ':';
  return '-'.repeat(Math.max(3, width));
};

const cellWidth = (cells, i) => Math.max(3, ...cells.map((r) => String(r[i] ?? '').length));

const padCell = (text, width, align) => {
  let t = String(text ?? '');
  if (t.length > width) return t;
  if (align === 'center') {
    const left = Math.floor((width - t.length) / 2);
    return ' '.repeat(left) + t + ' '.repeat(width - t.length - left);
  }
  if (align === 'right') return ' '.repeat(width - t.length) + t;
  return t + ' '.repeat(width - t.length);
};

export function init(api) {
  const L = api.strings || {};
  const view = api.view;

  /* ================================================================
   * Table model helpers
   * ================================================================ */
  const findTable = (state) => {
    const pos = state.selection.main.head;
    const doc = state.doc;
    const line = doc.lineAt(pos);

    if (!isTableRow(line.text)) return null;

    let start = line.number;
    let end = line.number;
    while (start > 1 && isTableRow(doc.line(start - 1).text)) start--;
    while (end < doc.lines && isTableRow(doc.line(end + 1).text)) end++;

    // Drop a trailing separator-only line or a leading separator
    const lines = [];
    for (let n = start; n <= end; n++) lines.push(doc.line(n).text);

    let hasHeader = false;
    const rows = [];
    lines.forEach((text, i) => {
      const cells = splitRow(text);
      if (isSeparator(cells)) {
        if (rows.length === 1 && !hasHeader) hasHeader = true; // separator right after first row
      } else {
        rows.push(cells);
      }
    });

    // Parse current alignments from the separator line (2nd line if header)
    const aligns = [];
    if (hasHeader && lines.length >= 2) {
      splitRow(lines[1]).forEach((c) => {
        const t = c.trim();
        if (t.startsWith(':') && t.endsWith(':')) aligns.push('center');
        else if (t.endsWith(':')) aligns.push('right');
        else if (t.startsWith(':')) aligns.push('left');
        else aligns.push('none');
      });
    }

    return { start, end, lines, rows, hasHeader, aligns };
  };

  const renderTable = (table) => {
    const rows = table.rows;
    if (!rows.length) return '';
    const cols = Math.max(...rows.map((r) => r.length));
    const aligns = [];
    for (let c = 0; c < cols; c++) {
      aligns.push(table.aligns[c] || 'none');
    }
    const widths = [];
    for (let c = 0; c < cols; c++) widths.push(cellWidth(rows, c));

    const out = [];
    rows.forEach((cells, r) => {
      const cs = [];
      for (let c = 0; c < cols; c++) cs.push(padCell(cells[c] ?? '', widths[c], aligns[c]));
      out.push('| ' + cs.join(' | ') + ' |');
      if (r === 0 && table.hasHeader) {
        out.push('| ' + aligns.map((a, c) => alignMarker(a, widths[c])).join(' | ') + ' |');
      }
    });
    return out.join('\n');
  };

  const replaceTable = (table, newRows, hasHeader, aligns) => {
    const next = { rows: newRows, hasHeader: hasHeader, aligns: aligns || table.aligns };
    const text = renderTable(next);
    const from = view.state.doc.line(table.start).from;
    const to = view.state.doc.line(table.end).to;
    view.dispatch({
      changes: { from, to, insert: text },
      selection: { anchor: from },
      scrollIntoView: true,
      userEvent: 'input.tableEdit',
    });
    view.focus();
  };

  /* ================================================================
   * Context toolbar (visible while caret is inside a table)
   * ================================================================ */
  const bar = document.createElement('div');
  bar.className = 'negaresh-table-tools';
  bar.setAttribute('hidden', '');
  const mkBtn = (title, icon, fn) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'negaresh-table-tool';
    b.title = title;
    b.setAttribute('aria-label', title);
    b.innerHTML = api.svgIcon(icon, 15);
    b.addEventListener('click', fn);
    return b;
  };

  const withTable = (fn) => () => {
    const t = findTable(view.state);
    if (t) fn(t);
  };

  // Map the caret's raw document line (inside the table block) to an index
  // into `rows` (which excludes separator lines).
  const rowIndexOf = (t, rawIdx) => {
    if (!t.hasHeader) return rawIdx;
    if (rawIdx <= 1) return 0; // header line or separator → header row
    return rawIdx - 1; // body lines come after header+separator
  };

  const opInsertRow = (offset) => withTable((t) => {
    const rawIdx = view.state.doc.lineAt(view.state.selection.main.head).number - t.start;
    const at = Math.min(Math.max(rowIndexOf(t, rawIdx) + offset, 0), t.rows.length);
    const cols = Math.max(...t.rows.map((r) => r.length));
    const blank = Array(cols).fill('');
    const rows = t.rows.slice();
    rows.splice(at, 0, blank);
    replaceTable(t, rows, t.hasHeader, t.aligns);
  });

  const opDeleteRow = () => withTable((t) => {
    if (t.rows.length <= 1) return;
    const rawIdx = view.state.doc.lineAt(view.state.selection.main.head).number - t.start;
    const bodyIdx = Math.min(Math.max(rowIndexOf(t, rawIdx), 0), t.rows.length - 1);
    const rows = t.rows.slice();
    rows.splice(bodyIdx, 1);
    replaceTable(t, rows, t.hasHeader, t.aligns);
  });

  const currentCol = (t) => {
    const line = view.state.doc.lineAt(view.state.selection.main.head);
    const before = line.text.slice(0, view.state.selection.main.head - line.from);
    return Math.max(0, (before.match(/\|/g) || []).length - 1);
  };

  const opInsertCol = (offset) => withTable((t) => {
    const at = currentCol(t) + offset;
    const rows = t.rows.map((r) => {
      const nr = r.slice();
      nr.splice(Math.min(at, nr.length), 0, '');
      return nr;
    });
    const aligns = t.aligns.slice();
    aligns.splice(Math.min(at, aligns.length), 0, 'none');
    replaceTable(t, rows, t.hasHeader, aligns);
  });

  const opDeleteCol = () => withTable((t) => {
    const cols = Math.max(...t.rows.map((r) => r.length));
    if (cols <= 1) return;
    const at = Math.min(currentCol(t), cols - 1);
    const rows = t.rows.map((r) => {
      const nr = r.slice();
      nr.splice(at, 1);
      return nr;
    });
    const aligns = t.aligns.slice();
    aligns.splice(at, 1);
    replaceTable(t, rows, t.hasHeader, aligns);
  });

  const opAlign = (align) => withTable((t) => {
    const at = currentCol(t);
    const aligns = t.aligns.slice();
    while (aligns.length < at) aligns.push('none');
    aligns[at] = aligns[at] === align ? 'none' : align; // toggle
    replaceTable(t, t.rows, t.hasHeader, aligns);
  });

  const opDeleteTable = () => withTable((t) => {
    const from = view.state.doc.line(t.start).from;
    const to = view.state.doc.line(Math.min(t.end + 1, view.state.doc.lines)).to;
    view.dispatch({
      changes: { from, to, insert: '' },
      selection: { anchor: from },
      userEvent: 'input.tableDelete',
    });
    view.focus();
  });

  // آیکون‌ها: افزودن ردیف/ستون با آیکون‌های اختصاصی (between-vertical-*) —
  // دو مستطیل، ردیف/ستونِ جدید را نشان می‌دهند و فلش، موقعیت فعلی را؛
  // نسخه‌های ۹۰ درجه چرخیده برای ستون چپ/راست. (درج «قبل» = سمت راست
  // و درج «بعد» = سمت چپ، چون جدول در فارسی راست‌به‌چپ رندر می‌شود.)
  bar.appendChild(mkBtn(L.tableAddRowAbove || 'افزودن ردیف در بالا', 'row-above', opInsertRow(0)));
  bar.appendChild(mkBtn(L.tableAddRowBelow || 'افزودن ردیف در پایین', 'row-below', opInsertRow(1)));
  bar.appendChild(mkBtn(L.tableDelRow || 'حذف ردیف', 'trash', opDeleteRow));
  bar.appendChild(document.createElement('span')).className = 'negaresh-table-sep';
  bar.appendChild(mkBtn(L.tableAddColBefore || 'افزودن ستون سمت راست', 'col-right', opInsertCol(0)));
  bar.appendChild(mkBtn(L.tableAddColAfter || 'افزودن ستون سمت چپ', 'col-left', opInsertCol(1)));
  bar.appendChild(mkBtn(L.tableDelCol || 'حذف ستون', 'trash', opDeleteCol));
  bar.appendChild(document.createElement('span')).className = 'negaresh-table-sep';
  bar.appendChild(mkBtn(L.tableAlignLeft || 'تراز چپ', 'align-left', opAlign('left')));
  bar.appendChild(mkBtn(L.tableAlignCenter || 'تراز وسط', 'align-center', opAlign('center')));
  bar.appendChild(mkBtn(L.tableAlignRight || 'تراز راست', 'align-right', opAlign('right')));
  bar.appendChild(mkBtn(L.tableDelete || 'حذف جدول', 'trash', opDeleteTable));
  api.shell.appendChild(bar);

  let toolsTimer = null;
  const updateTools = () => {
    if (toolsTimer) return;
    toolsTimer = setTimeout(() => {
      toolsTimer = null;
      const inside = !!findTable(view.state);
      bar.hidden = !inside;
    }, 150);
  };
  api.on('docchange', updateTools);
  view.dom.addEventListener('click', updateTools);
  view.dom.addEventListener('keyup', updateTools);

  /* ================================================================
   * Advanced insert dialog (visual size picker)
   * ================================================================ */
  const openAdvancedTableModal = () => {
    const MAX_R = 10, MAX_C = 8;
    let selR = 3, selC = 3, withHeader = true, align = 'none';

    const { overlay, close } = api.modalOverlay(`
      <h3>${L.table || 'جدول'}</h3>
      <div class="negaresh-modal-grid negaresh-table-picker" dir="rtl"></div>
      <p class="negaresh-modal-help negaresh-table-size"></p>
      <div class="negaresh-modal-grid">
        <label class="negaresh-check"><input type="checkbox" data-k="header" checked> ${L.tableHeader || 'با سرتیتر'}</label>
        <label>${L.tableAlign || 'تراز ستون‌ها'}
          <select data-k="align" class="tr-select" style="width:auto">
            <option value="none">—</option>
            <option value="left">${L.tableAlignLeft || 'چپ'}</option>
            <option value="center">${L.tableAlignCenter || 'وسط'}</option>
            <option value="right">${L.tableAlignRight || 'راست'}</option>
          </select>
        </label>
      </div>
      <div class="negaresh-modal-actions">
        <button type="button" class="btn primary" data-act="ok">${L.insert || 'درج'}</button>
        <button type="button" class="btn btn-link" data-act="cancel">${L.cancel || 'انصراف'}</button>
      </div>
    `);

    const grid = overlay.querySelector('.negaresh-table-picker');
    const sizeLabel = overlay.querySelector('.negaresh-table-size');
    const cells = [];
    for (let r = 1; r <= MAX_R; r++) {
      for (let c = 1; c <= MAX_C; c++) {
        const cell = document.createElement('button');
        cell.type = 'button';
        cell.className = 'negaresh-tcell';
        cell.dataset.r = String(r);
        cell.dataset.c = String(c);
        cell.addEventListener('mouseenter', () => highlight(r, c));
        cell.addEventListener('click', () => {
          selR = r; selC = c;
          insert();
        });
        grid.appendChild(cell);
        cells.push(cell);
      }
    }

    const highlight = (r, c) => {
      cells.forEach((cell) => {
        const on = parseInt(cell.dataset.r, 10) <= r && parseInt(cell.dataset.c, 10) <= c;
        cell.classList.toggle('is-on', on);
      });
      selR = r; selC = c;
      sizeLabel.textContent = fa(r) + ' × ' + fa(c);
    };

    const fa = (n) => String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[+d]);

    const checkHeader = overlay.querySelector('input[data-k="header"]');
    const selectAlign = overlay.querySelector('select[data-k="align"]');
    checkHeader.addEventListener('change', () => { withHeader = checkHeader.checked; });
    selectAlign.addEventListener('change', () => { align = selectAlign.value; });

    highlight(3, 3);

    const insert = () => {
      const rows = [];
      for (let r = 0; r < selR; r++) rows.push(Array(selC).fill(''));
      const aligns = Array(selC).fill(align);
      const text = renderTable({ rows, hasHeader: withHeader, aligns }) + '\n';
      view.dispatch(view.state.replaceSelection('\n' + text), { scrollIntoView: true, userEvent: 'input.table' });
      view.focus();
      close();
    };

    overlay.querySelector('button[data-act="ok"]').addEventListener('click', insert);
    overlay.querySelector('button[data-act="cancel"]').addEventListener('click', close);
  };

  const s = api.settings;
  if (s.visualTable === '1') {
    api.overrideButton('table', openAdvancedTableModal);
  } else {
    // visualTable is off → the stock table button is hidden; add our own
    api.addToolbarButton({
      id: 'tableAdv',
      icon: 'table',
      title: L.table || 'جدول',
      group: 5,
      action: openAdvancedTableModal,
    });
  }
}
