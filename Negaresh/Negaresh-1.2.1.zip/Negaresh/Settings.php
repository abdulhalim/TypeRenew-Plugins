<?php
declare(strict_types=1);

namespace TypechoPlugin\Negaresh;

use Typecho\Common;
use Typecho\Plugin\Exception as PluginException;
use Utils\Helper;
use Utils\Pref;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Settings
{
    public const NAME = 'Negaresh';
    public const CACHE_KEY = 'negaresh:settings:v4';
    public const CACHE_VERSION = 4;

    private static ?array $runtime = null;

    public static function defaults(): array
    {
        return [
            'enabled' => '1',

            // Layout — the side-by-side live preview was removed in v2.1
            // (preview lives only in its own tab), so the old split /
            // previewSync settings no longer exist.

            // Persian
            'zwnjButton' => '1',          // show نیم‌فاصله button
            'autoPunctuate' => '1',       // ; → ؛, ? → ؟, >> → «
            'persianQuotes' => '1',       // "" → «»
            'autoCorrect' => '1',         // as-you-type: می‌شود, تقریباً, ی/ک

            // Editor features
            'lineNumbers' => '0',         // CodeMirror line numbers
            'autoCloseBrackets' => '0',
            'tabSize' => '2',
            'wordWrap' => '1',
            'fontSize' => '14',           // px
            'visualTable' => '1',          // show the table toolbar button

            // Media integration (media.js module — Phase 1)
            'mediaBridge' => '1',         // MediaManager picker bridge + library button
            'pasteUpload' => '1',          // upload images pasted into the editor
            'dropUpload' => '1',           // upload files dropped on the editor

            // Draft & editor (draft/outline/focus/table/links modules — Phase 2)
            'localDraft' => '1',           // localStorage draft recovery
            'draftInterval' => '300',      // snapshot interval in seconds (v1.1; 0 = off)
            'outline' => '1',              // heading outline drawer
            'focusMode' => '1',            // dim non-active paragraphs
            'advancedTable' => '1',        // advanced table dialog + context tools
            'advancedLinks' => '1',        // advanced link/image dialogs
            'coloredBlocks' => '1',        // colored content blocks (success/warning/info/danger)
            'blockIcons' => '1',           // show Lucide icons in colored blocks

            // Writing & analysis (Phase 3)
            'writingAssistant' => '1',     // Persian writing assistant
            'typographyChecker' => '1',    // typography issue checker
            'contentAnalyzer' => '1',      // content statistics
            'seoTools' => '1',             // SEO writing tools

            // Theme
            'theme' => 'auto',           // auto | light | dark

            // Status bar
            'showCount' => '1',           // word/char count
            'countReadingTime' => '1',   // estimate reading time
        ];
    }

    public static function boolKeys(): array
    {
        return [
            'enabled',
            'zwnjButton',
            'autoPunctuate',
            'persianQuotes',
            'autoCorrect',
            'lineNumbers',
            'autoCloseBrackets',
            'wordWrap',
            'visualTable',
            'showCount',
            'countReadingTime',
            'mediaBridge',
            'pasteUpload',
            'dropUpload',
            'localDraft',
            'outline',
            'focusMode',
            'advancedTable',
            'advancedLinks',
            'coloredBlocks',
            'blockIcons',
            'writingAssistant',
            'typographyChecker',
            'contentAnalyzer',
            'seoTools',
        ];
    }

    public static function load(): array
    {
        return Pref::load(
            self::$runtime,
            self::CACHE_KEY,
            self::defaults(),
            static fn(): array => self::readStored('load.read'),
            [self::class, 'normalize'],
            [self::class, 'ensureStored'],
            [self::class, 'report']
        );
    }

    public static function loadFresh(): array
    {
        $raw = self::readStored('fresh.read');
        if ($raw === []) {
            self::ensureStored();
            $raw = self::readStored('fresh.retry');
        }

        return self::normalize(array_merge(self::defaults(), $raw));
    }

    public static function normalize(array $settings): array
    {
        $d = self::defaults();
        $settings = array_merge($d, $settings);

        foreach (self::boolKeys() as $key) {
            $settings[$key] = self::bool($settings[$key] ?? ($d[$key] ?? '0'));
        }

        $settings['tabSize'] = self::int($settings['tabSize'] ?? 2, 2, 8, 2);
        $settings['fontSize'] = self::int($settings['fontSize'] ?? 14, 12, 22, 14);
        $settings['draftInterval'] = self::int($settings['draftInterval'] ?? 300, 0, 3600, 300);
        $settings['theme'] = in_array((string) $settings['theme'], ['auto', 'light', 'dark'], true)
            ? (string) $settings['theme'] : 'auto';

        return $settings;
    }

    public static function store(array $settings): void
    {
        $settings = self::normalize($settings);
        \Widget\Plugins\Edit::configPlugin(self::NAME, $settings);
        self::clear();
    }

    public static function ensureStored(): void
    {
        Pref::sync(
            self::NAME,
            self::defaults(),
            [self::class, 'normalize'],
            [self::class, 'report'],
            null,
            static fn(): array => self::readStored('ensure.read')
        );
        self::clear();
    }

    public static function clear(): void
    {
        Pref::forget(self::$runtime, self::CACHE_KEY, [self::class, 'report']);
    }

    public static function panelUrl(): string
    {
        return Helper::url(self::NAME . '/Panel.php');
    }

    public static function assetUrl(string $path): string
    {
        // نکته‌ی نسخه‌ی 1.2.1: استفاده از try/catch برای اطمینان از
        // بازگرداندن URL معتبر حتی اگر Helper::options() استثنا پرتاب کند.
        try {
            $options = Helper::options();
            $base = (string) ($options->pluginUrl ?? '');
        } catch (\Throwable $e) {
            $base = '';
        }

        if ($base === '') {
            $base = Common::url('usr/plugins/', self::siteUrl());
        }

        $url = Common::url(self::NAME . '/' . ltrim($path, '/'), $base);

        // نکته‌ی نسخه‌ی 1.2.1: بازنویسی پروتکل URL با پروتکل واقعی درخواست
        // برای رفع مشکل CORS. اگر siteUrl در دیتابیس https:// باشد و کاربر
        // از http:// دسترسی داشته باشد، URL به http:// تبدیل می‌شود.
        return self::normalizeUrlProtocol($url);
    }

    /**
     * پارامتر کش‌شکن فایل asset — نسخه + زمان آخرین تغییر خود فایل
     *
     * اگر شماره‌ی نسخه بین دو ساخت یکسان بماند (مثلاً اصلاح باگ بدون
     * تغییر نسخه)، زمان تغییر خود فایل تضمین می‌کند که مرورگر نسخه‌ی
     * قدیمیِ کش‌شده را به‌جای فایل تازه بازنخواند.
     */
    public static function assetRev(string $relPath): string
    {
        $mtime = @filemtime(__DIR__ . '/' . ltrim($relPath, '/'));
        return 'v=' . rawurlencode(Plugin::VERSION . ($mtime ? '.' . (string) $mtime : ''));
    }

    /**
     * URL سایت با پروتکلِ درخواست فعلی
     *
     * نکته‌ی نسخه‌ی 1.2.1 (رفع مشکل CORS در TypeRenew 1.6.1):
     * در TypeRenew 1.6.1، Options::siteUrl() فقط در صورتی که درخواست
     * secure باشد، http:// را به https:// تبدیل می‌کند. اما برعکس این
     * کار را نمی‌کند — یعنی اگر siteUrl در دیتابیس https:// باشد و
     * کاربر از http:// دسترسی داشته باشد، siteUrl همچنان https://
     * برمی‌گردد. این باعث می‌شود URL پلاگین با پروتکل متفاوت از صفحه
     * ساخته شود و مرورگر ES module‌ها را به‌عنوان cross-origin ببیند
     * و block کند (CORS error).
     *
     * راه‌حل: siteUrl را با پروتکل واقعی درخواست بازنویسی می‌کنیم.
     * اگه درخواست HTTP باشه و siteUrl با https:// شروع بشه، آن را به
     * http:// تبدیل می‌کنیم. اگه درخواست HTTPS باشه و siteUrl با
     * http:// شروع بشه، آن را به https:// تبدیل می‌کنیم (این بخش
     * قبلاً توسط TypeRenew انجام می‌شد، اما برای اطمینان اینجا هم
     * تکرار شده است).
     *
     * @return string
     */
    public static function siteUrl(): string
    {
        try {
            $url = rtrim((string) Helper::options()->siteUrl, '/') . '/';
        } catch (\Throwable $e) {
            // fallback: از ساخت مستقیم URL استفاده می‌کنیم
            return self::detectRequestRoot() . '/';
        }

        // تشخیص پروتکل واقعی درخواست
        $isSecure = self::isRequestSecure();

        // اگه درخواست secure باشه و siteUrl با http:// شروع بشه، به https:// تبدیل کن
        if ($isSecure && 0 === strpos($url, 'http://')) {
            $url = 'https://' . substr($url, 7);
        }

        // اگه درخواست secure نباشه (HTTP) و siteUrl با https:// شروع بشه، به http:// تبدیل کن
        // این مورد اصلی مشکل CORS است: کاربر از HTTP دسترسی دارد اما siteUrl در DB روی HTTPS است.
        if (!$isSecure && 0 === strpos($url, 'https://')) {
            $url = 'http://' . substr($url, 8);
        }

        return $url;
    }

    /**
     * بازنویسی پروتکل URL با پروتکل واقعی درخواست
     *
     * این متد مشکل CORS را برطرف می‌کند: اگر siteUrl در دیتابیس https://
     * باشد و کاربر از http:// دسترسی داشته باشد (یا برعکس)، URL به پروتکل
     * درخواست تبدیل می‌شود تا مرورگر ES module‌ها را same-origin ببیند.
     *
     * @param string $url URL که باید پروتکل آن بازنویسی شود
     * @return string URL با پروتکل صحیح
     */
    public static function normalizeUrlProtocol(string $url): string
    {
        if ($url === '') {
            return $url;
        }

        $isSecure = self::isRequestSecure();

        if ($isSecure && 0 === strpos($url, 'http://')) {
            return 'https://' . substr($url, 7);
        }

        if (!$isSecure && 0 === strpos($url, 'https://')) {
            return 'http://' . substr($url, 8);
        }

        return $url;
    }

    /**
     * تشخیص آیا درخواست فعلی از طریق HTTPS انجام شده است
     *
     * این متد همان منطق TypeRenew\Request::isSecure() را دنبال می‌کند،
     * اما مستقل از کلاس Request اجرا می‌شود تا در صورت عدم دسترسی
     * به Request هم کار کند.
     *
     * @return bool
     */
    private static function isRequestSecure(): bool
    {
        // ۱) HTTPS متغیر سرور
        if (!empty($_SERVER['HTTPS']) && 'off' !== strtolower((string) $_SERVER['HTTPS'])) {
            return true;
        }

        // ۲) SERVER_PORT = 443
        if (!empty($_SERVER['SERVER_PORT']) && 443 === (int) $_SERVER['SERVER_PORT']) {
            return true;
        }

        // ۳) X-Forwarded-Proto header (برای پروکسی‌ها و CDNها)
        $forwardedProto = '';
        if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO'])) {
            $forwardedProto = strtolower((string) $_SERVER['HTTP_X_FORWARDED_PROTO']);
        }

        if ($forwardedProto === 'https' || $forwardedProto === 'quic') {
            return true;
        }

        // ۴) X-Forwarded-Port = 443
        if (!empty($_SERVER['HTTP_X_FORWARDED_PORT']) && 443 === (int) $_SERVER['HTTP_X_FORWARDED_PORT']) {
            return true;
        }

        // ۵) REQUEST_SCHEME = https
        if (!empty($_SERVER['REQUEST_SCHEME']) && 'https' === strtolower((string) $_SERVER['REQUEST_SCHEME'])) {
            return true;
        }

        return false;
    }

    /**
     * ساخت ریشه‌ی URL درخواست از متغیرهای سرور
     *
     * این متد فقط به‌عنوان fallback استفاده می‌شود وقتی Helper::options()
     * در دسترس نیست. در شرایط عادی، از siteUrl دیتابیس استفاده می‌شود.
     *
     * @return string
     */
    private static function detectRequestRoot(): string
    {
        $scheme = self::isRequestSecure() ? 'https' : 'http';

        $host = '';
        if (!empty($_SERVER['HTTP_HOST'])) {
            $host = (string) $_SERVER['HTTP_HOST'];
        } elseif (!empty($_SERVER['SERVER_NAME'])) {
            $host = (string) $_SERVER['SERVER_NAME'];
            if (!empty($_SERVER['SERVER_PORT']) && 80 !== (int) $_SERVER['SERVER_PORT'] && 443 !== (int) $_SERVER['SERVER_PORT']) {
                $host .= ':' . $_SERVER['SERVER_PORT'];
            }
        }

        // مسیر نسبی (مثلاً /typerenew/)
        $path = '';
        if (!empty($_SERVER['SCRIPT_NAME'])) {
            $scriptName = (string) $_SERVER['SCRIPT_NAME'];
            $dir = dirname($scriptName);
            // حذف /admin از انتهای مسیر (اگر در پنل مدیریت باشیم)
            if (str_ends_with($dir, '/admin') || str_ends_with($dir, '/admin/')) {
                $dir = dirname($dir);
            }
            $path = rtrim(str_replace('\\', '/', $dir), '/');
        }

        return $scheme . '://' . $host . $path;
    }

    public static function report(string $scope, \Throwable $e): void
    {
        error_log('Negaresh.' . $scope . ': ' . $e->getMessage());
    }

    private static function readStored(string $scope): array
    {
        try {
            return (array) Helper::options()->plugin(self::NAME)->toArray();
        } catch (PluginException) {
            return [];
        } catch (\Throwable $e) {
            self::report($scope, $e);
            return [];
        }
    }

    private static function bool($value): string
    {
        return in_array((string) $value, ['1', 'true', 'on', 'yes'], true) ? '1' : '0';
    }

    private static function int($value, int $min, int $max, int $default): int
    {
        $value = filter_var($value, FILTER_VALIDATE_INT);
        if ($value === false) {
            return $default;
        }
        return max($min, min($max, (int) $value));
    }
}
