<?php
declare(strict_types=1);

namespace TypechoPlugin\Negaresh;

use Typecho\Plugin as Hook;
use Typecho\Plugin\PluginInterface;
use Typecho\Widget\Helper\Form;
use Typecho\Widget\Helper\Form\Element\Hidden;
use Typecho\Widget\Helper\Form\Element\Radio;
use Typecho\Widget\Helper\Form\Element\Select;
use Typecho\Widget\Helper\Form\Element\Text as FormText;
use Utils\Helper;
use Utils\NoPersonal;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
* نگارش — ویرایشگر مارک‌داون فارسی با پیش‌نمایش زنده، تصحیح خودکار نگارش و نیم‌فاصله، فهرست مطالب، جدول پیشرفته و درج ویدئو و شکلک.
 *
 * @package Negaresh
 * @author پوردریایی
 * @link https://pourdaryaei.ir/
 * @version 1.2.1
 * @since 1.6.0
 *
 */
class Plugin implements PluginInterface
{
    use NoPersonal;

    public const NAME = 'Negaresh';

    public const VERSION = '1.2.1';

    public static function activate(): string
    {
        Settings::ensureStored();
        self::registerHooks();

        Helper::removePanel(3, 'Negaresh/Panel.php');
        Helper::addPanel(
            3,
            'Negaresh/Panel.php',
            'ویرایشگر نگارش',
            'ویرایشگر نگارش',
            'administrator',
            false,
            '',
            ['icon' => 'i-edit']
        );
        return _t('افزونه‌ی ویرایشگر نگارش فعال شد. به پنل «ویرایشگر نگارش» بروید.');
    }

    public static function deactivate(): string
    {
        Helper::removePanel(3, 'Negaresh/Panel.php');
        Settings::clear();
        return _t('افزونه‌ی ویرایشگر نگارش غیرفعال شد.');
    }

    public static function config(Form $form): void
    {
        $settings = Settings::load();

        $enabled = new Radio(
            'enabled',
            ['1' => _t('فعال'), '0' => _t('غیرفعال')],
            $settings['enabled'] ?? '1',
            _t('وضعیت افزونه'),
            _t('برای تنظیمات کامل به پنل «ویرایشگر نگارش» بروید.')
        );
        $form->addInput($enabled);

        foreach (Settings::defaults() as $key => $value) {
            if ($key === 'enabled') {
                continue;
            }
            $form->addInput(new Hidden($key, null, (string) ($settings[$key] ?? $value)));
        }
    }

    public static function configHandle(array $settings, bool $_isInit): void
    {
        $current = Settings::load();
        Settings::store(array_merge($current, $settings));
    }

    private static function registerHooks(): void
    {
        // Replace the default rich editor completely.
        Hook::factory('admin/write-post.php')->richEditor = [Editor::class, 'richEditor'];
        Hook::factory('admin/write-page.php')->richEditor = [Editor::class, 'richEditor'];

        // Inject the editor assets into the page bottom (after jQuery is loaded).
        Hook::factory('admin/write-post.php')->bottom = [Editor::class, 'injectAssets'];
        Hook::factory('admin/write-page.php')->bottom = [Editor::class, 'injectAssets'];

        // Allow other plugins to extend the editor (e.g. add buttons).
        Hook::factory('admin/editor-js.php')->markdownEditor = [Editor::class, 'markdownEditor'];

        // تزریق استایل بلاک‌های رنگی به سمت پوسته (front-end) — بدون این
        // هوک، بلاک‌های tr-block به‌صورت متن معمولی نمایش داده می‌شوند.
        Hook::factory('Widget\Archive')->header = [Front::class, 'injectStyles'];
    }
}
