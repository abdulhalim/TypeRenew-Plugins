<?php
declare(strict_types=1);

namespace TypechoPlugin\Negaresh;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class Front
{
    /**
     * تزریق استایل سمت پوسته (داخل <head>)
     *
     * @param mixed $header  محتوای فعلی header (از هوک)
     * @param mixed $archive نمونه‌ی Widget\Archive
     */
    public static function injectStyles($header, $archive): void
    {
        $settings = Settings::load();

        // فقط اگر بلاک‌های رنگی فعال باشند، CSS تزریق شود
        if (($settings['coloredBlocks'] ?? '0') !== '1') {
            return;
        }

        $assetUrl = Settings::assetUrl('assets/');
        $cssUrl = $assetUrl . 'blocks-front.css?' . Settings::assetRev('assets/blocks-front.css');

        echo '<link rel="stylesheet" href="' . Text::e($cssUrl) . '">' . "\n";

        // اگر آیکون‌ها غیرفعال هستند، یک inline style تزریق کن تا ::before مخفی شود
        // و padding-right بلاک به حالت عادی برگردد (بدون فضای اضافی برای آیکون).
        if (($settings['blockIcons'] ?? '1') !== '1') {
            echo '<style>'
                . '.tr-block::before { display: none !important; }'
                . '.tr-block { padding-right: 18px !important; }'
                . '</style>' . "\n";
        }
    }
}
