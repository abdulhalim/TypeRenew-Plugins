<?php
namespace TypechoPlugin\Booking;

use Typecho\Db;
use Typecho\Widget\Exception as WidgetException;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * صفحهٔ جزئیات یک رزرو — برای اعضای واردشده با دسترسی مدیریت.
 * نشانی: /booking/[coid]
 *
 * در این صفحه اعضا می‌توانند:
 *  - جزئیات کامل رزرو را ببینند
 *  - یادداشت داخلی اضافه کنند
 *  - رزرو را تأیید کنند (status -> approved)
 *  - رزرو را رد کنند (status -> spam)
 *  - رزرو را حذف کنند (DELETE)
 *
 * @package Booking
 */
class BookingDetail extends BookingPage
{
    protected function pageTitle(): string
    {
        $reservation = $this->reservation();
        $name = $reservation['author'] ?? 'رزرو';
        return 'رزرو — ' . $name;
    }

    protected function pageDescription(): string
    {
        return 'جزئیات رزرو — برای اعضای واردشده.';
    }

    protected function pageUrl(): string
    {
        $coid = (int) ($this->request->get('coid') ?: 0);
        return $coid > 0 ? Plugin::detailUrl($coid) : Plugin::listUrl();
    }

    public function render(): void
    {
        // دسترسی‌پذیری: فقط اعضای مجاز
        if (!Plugin::canManage()) {
            $loginUrl = (string) $this->options->loginUrl;
            $coid = (int) ($this->request->get('coid') ?: 0);
            $referer = $coid > 0 ? Plugin::detailUrl($coid) : Plugin::listUrl();
            $this->response->redirect($loginUrl . '?referer=' . rawurlencode($referer));
            return;
        }
        $this->renderBookingPage('detail.php');
    }

    /** واکشی رزرو موردنظر — کش‌شده در طول درخواست */
    private function reservation(): array
    {
        static $cache = null;
        if ($cache !== null) {
            return $cache;
        }

        $coid = (int) ($this->request->get('coid') ?: 0);
        if ($coid < 1) {
            throw new WidgetException(_t('رزرو یافت نشد'), 404);
        }

        $post = $this->bookingPost();
        $cid = (int) $post['cid'];

        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select()->from('table.comments')
                    ->where('coid = ? AND cid = ? AND parent = 0 AND type = ?', $coid, $cid, 'comment')
                    ->limit(1)
            );
            if (!$row) {
                throw new WidgetException(_t('رزرو یافت نشد'), 404);
            }

            // بررسی این‌که واقعاً یک رزرو است (نه یک دیدگاه عادی دیگر)
            if (!Plugin::isReservation($row)) {
                throw new WidgetException(_t('این یک رزرو نیست'), 404);
            }

            $payload = Plugin::decodePayload((string) $row['text']);
            $cache = [
                'coid'           => (int) $row['coid'],
                'cid'            => (int) $row['cid'],
                'created'        => (int) $row['created'],
                'author'         => (string) $row['author'],
                'mail'           => (string) $row['mail'],
                'phone'          => (string) $row['url'],
                'ip'             => (string) $row['ip'],
                'agent'          => (string) $row['agent'],
                'status'         => (string) $row['status'],
                'statusLabel'    => Plugin::statusLabel((string) $row['status']),
                'statusClass'    => Plugin::statusClass((string) $row['status']),
                'preferredDate'  => (string) ($payload['preferred_date'] ?? ''),
                'preferredTime'  => (string) ($payload['preferred_time'] ?? ''),
                'description'    => (string) ($payload['description'] ?? ''),
                'nationalId'     => (string) ($payload['national_id'] ?? ''),
                'age'            => (string) ($payload['age'] ?? ''),
                'gender'         => (string) ($payload['gender'] ?? ''),
                'mailField'      => (string) ($payload['mail'] ?? ''),
                'createdJalali'  => Plugin::jalaliDate((int) $row['created']),
                'createdRelative' => Plugin::relativeTime((int) $row['created']),
                'detailUrl'      => Plugin::detailUrl((int) $row['coid']),
                'listUrl'        => Plugin::listUrl(),
            ];
        } catch (WidgetException $e) {
            throw $e;
        } catch (\Throwable $e) {
            throw new WidgetException(_t('خطا در بازیابی رزرو'), 500);
        }

        return $cache;
    }

    protected function prepareContext(): array
    {
        $reservation = $this->reservation();

        // یادداشت‌های داخلی روی این رزرو
        $notes = [];
        foreach (Plugin::notesFor((int) $reservation['coid']) as $n) {
            $notes[] = [
                'coid'      => (int) $n['coid'],
                'created'   => (int) $n['created'],
                'author'    => (string) $n['author'],
                'authorId'  => (int) ($n['authorId'] ?? 0),
                'text'      => (string) $n['text'],
                'createdJalali' => Plugin::jalaliDate((int) $n['created']),
                'createdRelative' => Plugin::relativeTime((int) $n['created']),
            ];
        }

        // پیام‌های خطا/موفقیت از پارامترهای URL
        $errorMsg = '';
        $errCode = (string) $this->request->get('err', '');
        if ($errCode !== '') {
            $errorMsg = match ($errCode) {
                'note_empty' => 'متن یادداشت خالی است.',
                'note_save'  => 'خطا در ذخیرهٔ یادداشت.',
                'status'     => 'خطا در تغییر وضعیت رزرو.',
                'delete'     => 'خطا در حذف رزرو.',
                'unknown'    => 'خطای ناشناخته.',
                default       => '',
            };
        }
        $okMsg = '';
        $okCode = (string) $this->request->get('ok', '');
        if ($okCode !== '') {
            $okMsg = match ($okCode) {
                'note'    => 'یادداشت اضافه شد.',
                'approve' => 'رزرو تأیید شد.',
                'reject'  => 'رزرو رد شد.',
                'delete'  => 'رزرو حذف شد.',
                default    => '',
            };
        }

        return $this->commonContext() + [
            'reservation' => $reservation,
            'notes'       => $notes,
            'noteCount'   => count($notes),
            'errorMsg'    => $errorMsg,
            'okMsg'       => $okMsg,
        ];
    }
}
