/**
 * Booking plugin — اسکریپت‌های رابط
 * نسخهٔ ۱.۱.۰ — اضافه‌شدن Jalali Date Picker سبک
 *
 * کارکرد:
 *  - بستن خودکار پیام‌های اعلان بعد از ۶ ثانیه
 *  - اعتبارسنجی فرم رزرو در سمت کلاینت
 *  - تبدیل ارقام فارسی به انگلیسی در فیلدهای عددی قبل از ارسال
 *  - Jalali Date Picker سبک (بدون وابستگی خارجی) برای فیلد تاریخ
 */
(function () {
    'use strict';

    // ================================================================
    //  ابزارهای عمومی
    // ================================================================

    /** تبدیل ارقام فارسی/عربی به انگلیسی */
    function toEnglishDigits(s) {
        return String(s || '').replace(/[۰-۹٠-٩]/g, function (d) {
            var c = d.charCodeAt(0);
            if (c >= 0x06F0 && c <= 0x06F9) return String(c - 0x06F0);
            if (c >= 0x0660 && c <= 0x0669) return String(c - 0x0660);
            return d;
        });
    }

    /** تبدیل ارقام انگلیسی به فارسی */
    function toPersianDigits(s) {
        return String(s || '').replace(/[0-9]/g, function (d) {
            return String.fromCharCode(d.charCodeAt(0) + 0x06C0);
        });
    }

    /**
     * خواندن حالت رنگ از data-bk-theme روی .bk-main
     * برمی‌گرداند: 'is-light' | 'is-dark' (پیش‌فرض is-light)
     */
    function getPickerThemeClass() {
        var main = document.querySelector('.bk-main[data-bk-theme]');
        if (!main) return 'is-light';
        var t = main.getAttribute('data-bk-theme');
        if (t === 'dark') return 'is-dark';
        return 'is-light';
    }

    /** آیا شماره تلفن معتبر است؟ */
    function isValidPhone(phone) {
        var clean = (phone || '').replace(/[\s\-()]/g, '');
        if (!/^\+?\d+$/.test(clean)) return false;
        var len = clean.replace(/\D/g, '').length;
        return len >= 7 && len <= 15;
    }

    /** آیا کد ملی معتبر است؟ */
    function isValidNationalId(id) {
        id = toEnglishDigits(id || '').trim();
        if (!/^\d{10}$/.test(id)) return false;
        var digits = id.split('').map(Number);
        var check = digits.pop();
        var sum = digits.reduce(function (acc, d, i) {
            return acc + d * (10 - i);
        }, 0);
        var rem = sum % 11;
        var expected = rem < 2 ? rem : 11 - rem;
        return check === expected;
    }

    /** نمایش خطای موقت زیر یک فیلد */
    function showFieldError(input, message) {
        var existing = input.parentNode.querySelector('.bk-field-error');
        if (existing) existing.remove();

        input.setAttribute('aria-invalid', 'true');
        input.classList.add('bk-input-error');
        var err = document.createElement('p');
        err.className = 'bk-field-error';
        err.style.cssText = 'color:var(--bk-danger);font-size:0.78rem;margin:0.25rem 0 0;';
        err.textContent = message;
        input.parentNode.appendChild(err);

        setTimeout(function () {
            if (err.parentNode) err.remove();
            input.classList.remove('bk-input-error');
            input.removeAttribute('aria-invalid');
        }, 4000);
    }

    // ================================================================
    //  Jalali Date Picker (سبک، بدون وابستگی)
    //  الگوریتم تبدیل بر اساس یک نسخهٔ متداول و سبک از jDays
    // ================================================================

    /** نام ماه‌های شمسی */
    var J_MONTHS = [
        'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
        'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
    ];

    /** نام روزهای هفته (شنبه اول) */
    var J_WEEKDAYS = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];

    /** روزهای هفته (مخفف) برای هدر */
    var J_WEEKDAYS_SHORT = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];

    /** آیا سال شمسی کبیسه است؟ (الگوریتم استاندارد تقویم جلالی) */
    function isLeapJalali(jy) {
        var breaks = [
            -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181,
            1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394,
            2456, 3178
        ];
        var jp = jy - 60 * Math.floor((jy + 60) / 60);
        var a = breaks.findIndex(function (_, i) {
            return i % 2 === 0 && breaks[i] <= jp && (breaks[i + 1] === undefined || jp < breaks[i + 1]);
        });
        // روش جایگزین: استفاده از فرمول ساده
        var cycle = Math.floor((jy + 38) / 33);
        var remains = (jy + 38) % 33;
        var leap = (remains % 4 === 0 && remains !== 32) || (remains === 32 && cycle % 4 === 0);
        return !!leap;
    }

    /** تعداد روزهای هر ماه شمسی */
    function daysInJalaliMonth(jy, jm) {
        if (jm <= 6) return 31;
        if (jm <= 11) return 30;
        return isLeapJalali(jy) ? 30 : 29;
    }

    /** تبدیل میلادی به شمسی — خروجی: [jy, jm, jd] */
    function toJalali(gy, gm, gd) {
        var g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
        var jy = (gy <= 1600) ? 0 : 979;
        gy -= (gy <= 1600) ? 621 : 1600;
        var gy2 = (gm > 2) ? (gy + 1) : gy;
        var days = (365 * gy) + (Math.floor((gy2 + 3) / 4)) - (Math.floor((gy2 + 99) / 100))
            + (Math.floor((gy2 + 399) / 400)) - 80 + gd + g_d_m[gm - 1];
        jy += 33 * (Math.floor(days / 12053));
        days %= 12053;
        jy += 4 * (Math.floor(days / 1461));
        days %= 1461;
        if (days > 365) {
            jy += Math.floor((days - 1) / 365);
            days = (days - 1) % 365;
        }
        var jm = (days < 186) ? (1 + Math.floor(days / 31)) : (7 + Math.floor((days - 186) / 30));
        var jd = 1 + ((days < 186) ? (days % 31) : ((days - 186) % 30));
        return [jy, jm, jd];
    }

    /** تبدیل شمسی به میلادی — خروجی: [gy, gm, gd] */
    function toGregorian(jy, jm, jd) {
        var gy = (jy <= 979) ? 621 : 1600;
        jy -= (jy <= 979) ? 0 : 979;
        var days = (365 * jy) + (Math.floor(jy / 33) * 8)
            + (Math.floor((jy % 33 + 3) / 4))
            + 78 + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30 + 186));
        gy += 400 * Math.floor(days / 146097);
        days %= 146097;
        if (days > 36524) {
            gy += 100 * Math.floor(--days / 36524);
            days %= 36524;
            if (days >= 365) days++;
        }
        gy += 4 * Math.floor(days / 1461);
        days %= 1461;
        if (days > 365) {
            gy += Math.floor((days - 1) / 365);
            days = (days - 1) % 365;
        }
        var gd = days + 1;
        var sal_a = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0)) ? 29 : 28,
            31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        var gm = 0;
        for (gm = 0; gm < 13 && gd > sal_a[gm]; gm++) {
            gd -= sal_a[gm];
        }
        return [gy, gm, gd];
    }

    /** روز هفته برای تاریخ شمسی (شنبه=0, جمعه=6) */
    function jalaliWeekday(jy, jm, jd) {
        var g = toGregorian(jy, jm, jd);
        // getDay() در JavaScript: یکشنبه=0, شنبه=6
        // ما می‌خواهیم: شنبه=0, جمعه=6
        var jsDay = new Date(g[0], g[1] - 1, g[2]).getDay();
        return (jsDay + 1) % 7;
    }

    /** قالب‌بندی تاریخ شمسی به YYYY/MM/DD فارسی */
    function formatJalali(jy, jm, jd) {
        var y = String(jy).padStart(4, '0');
        var m = String(jm).padStart(2, '0');
        var d = String(jd).padStart(2, '0');
        return toPersianDigits(y + '/' + m + '/' + d);
    }

    /** parse رشتهٔ شمسی به [jy, jm, jd] یا null */
    function parseJalaliString(str) {
        if (!str) return null;
        str = toEnglishDigits(str).trim().replace(/[\-\.]/g, '/');
        var parts = str.split('/');
        if (parts.length !== 3) return null;
        var jy = parseInt(parts[0], 10);
        var jm = parseInt(parts[1], 10);
        var jd = parseInt(parts[2], 10);
        if (isNaN(jy) || isNaN(jm) || isNaN(jd)) return null;
        if (jy < 1300 || jy > 1700) return null;
        if (jm < 1 || jm > 12) return null;
        if (jd < 1 || jd > daysInJalaliMonth(jy, jm)) return null;
        return [jy, jm, jd];
    }

    // ================================================================
    //  Jalali Date Picker — کلاس اصلی
    // ================================================================

    var JalaliDatePicker = {
        currentInput: null,
        picker: null,
        pickerOpen: false,
        currentYear: 0,
        currentMonth: 0,
        currentView: 'days', // 'days' | 'months' | 'years'
        yearPageStart: 0,

        /** راه‌اندازی روی یک یا چند input (انتخابگر CSS) */
        init: function (selector) {
            var self = this;
            var inputs = document.querySelectorAll(selector);
            inputs.forEach(function (input) {
                // اگر مقدار اولیه دارد، به شمسی تبدیل‌اش کن
                var val = input.value.trim();
                if (val && !/^[۰-۹]/.test(val) && /^\d{4}\/\d{1,2}\/\d{1,2}$/.test(toEnglishDigits(val))) {
                    // مقدار میلادی — به شمسی تبدیل
                    var parts = toEnglishDigits(val).split('/').map(Number);
                    if (parts.length === 3) {
                        var j = toJalali(parts[0], parts[1], parts[2]);
                        input.value = formatJalali(j[0], j[1], j[2]);
                    }
                }

                input.addEventListener('focus', function (e) {
                    e.preventDefault();
                    self.openPicker(input);
                });

                input.addEventListener('click', function (e) {
                    e.preventDefault();
                    if (!self.pickerOpen) {
                        self.openPicker(input);
                    }
                });

                input.addEventListener('keydown', function (e) {
                    if (e.key === 'Escape' && self.pickerOpen) {
                        self.closePicker();
                    } else if (e.key === 'Enter' && self.pickerOpen) {
                        e.preventDefault();
                        // تأیید تاریخ فعلی نمایش‌داده‌شده
                        self.closePicker();
                    }
                });
            });

            // بستن picker با کلیک خارج
            document.addEventListener('mousedown', function (e) {
                if (!self.pickerOpen) return;
                if (self.picker && self.picker.contains(e.target)) return;
                if (self.currentInput && self.currentInput.contains(e.target)) return;
                self.closePicker();
            });
        },

        /** باز کردن picker روی یک input */
        openPicker: function (input) {
            var self = this;
            this.currentInput = input;

            // تاریخ شروع: از مقدار فعلی یا امروز
            var initial = parseJalaliString(input.value);
            if (initial) {
                this.currentYear = initial[0];
                this.currentMonth = initial[1];
            } else {
                var now = new Date();
                var j = toJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
                this.currentYear = j[0];
                this.currentMonth = j[1];
            }
            this.currentView = 'days';

            this.buildPicker();
            this.positionPicker(input);
            this.pickerOpen = true;
        },

        /** بستن picker */
        closePicker: function () {
            if (this.picker && this.picker.parentNode) {
                this.picker.parentNode.removeChild(this.picker);
            }
            this.picker = null;
            this.pickerOpen = false;
            this.currentInput = null;
        },

        /** ساخت picker و درج در DOM */
        buildPicker: function () {
            var self = this;
            if (this.picker) {
                this.picker.remove();
            }
            this.picker = document.createElement('div');
            this.picker.className = 'bk-jdate-picker ' + getPickerThemeClass();
            this.picker.setAttribute('dir', 'rtl');
            this.picker.setAttribute('role', 'dialog');
            this.picker.setAttribute('aria-modal', 'false');
            document.body.appendChild(this.picker);
            this.renderDays();
        },

        /** موقع‌دهی picker زیر input */
        positionPicker: function (input) {
            if (!this.picker) return;
            var rect = input.getBoundingClientRect();
            var pickerRect = this.picker.getBoundingClientRect();
            var top = rect.bottom + window.scrollY + 4;
            var left = rect.left + window.scrollX;

            // اگر به پایین صفحه می‌رسد، بالا نشان بده
            if (top + pickerRect.height > window.innerHeight + window.scrollY) {
                top = rect.top + window.scrollY - pickerRect.height - 4;
            }
            // اگر از راست بیرون می‌زند
            if (left + pickerRect.width > window.innerWidth + window.scrollX) {
                left = window.innerWidth + window.scrollX - pickerRect.width - 8;
            }

            this.picker.style.top = top + 'px';
            this.picker.style.left = left + 'px';
        },

        /** رندر نمای روزها */
        renderDays: function () {
            var self = this;
            this.currentView = 'days';
            var html = '';

            // خواندن تنظیمات از window.BK_CONFIG (اگر موجود باشد)
            var config = window.BK_CONFIG || { holidays: [], todayJalali: '' };
            var holidays = config.holidays || [];
            var todayJalaliStr = config.todayJalali || '';

            // هدر
            html += '<div class="bk-jdate-header">';
            html += '<button type="button" class="bk-jdate-nav" data-nav="prev" aria-label="ماه قبل">&rsaquo;</button>';
            html += '<button type="button" class="bk-jdate-title">' + J_MONTHS[this.currentMonth - 1] + ' ' + toPersianDigits(String(this.currentYear)) + '</button>';
            html += '<button type="button" class="bk-jdate-nav" data-nav="next" aria-label="ماه بعد">&lsaquo;</button>';
            html += '</div>';

            // نام روزهای هفته
            html += '<div class="bk-jdate-weekdays">';
            for (var i = 0; i < 7; i++) {
                html += '<span class="bk-jdate-weekday">' + J_WEEKDAYS_SHORT[i] + '</span>';
            }
            html += '</div>';

            // روزهای ماه
            var dim = daysInJalaliMonth(this.currentYear, this.currentMonth);
            var firstWeekday = jalaliWeekday(this.currentYear, this.currentMonth, 1);
            var today = new Date();
            var jToday = toJalali(today.getFullYear(), today.getMonth() + 1, today.getDate());
            // تاریخ امروز به‌صورت YYYY/MM/DD برای مقایسه
            var todayStr = todayJalaliStr || (String(jToday[0]) + '/' + String(jToday[1]).padStart(2, '0') + '/' + String(jToday[2]).padStart(2, '0'));

            html += '<div class="bk-jdate-days">';
            // سلول‌های خالی پیش از روز اول
            for (var k = 0; k < firstWeekday; k++) {
                html += '<span class="bk-jdate-day is-empty"></span>';
            }
            for (var d = 1; d <= dim; d++) {
                var classes = 'bk-jdate-day';
                var dayStr = String(this.currentYear) + '/' + String(this.currentMonth).padStart(2, '0') + '/' + String(d).padStart(2, '0');
                var isPast = dayStr < todayStr;
                var isHoliday = holidays.indexOf(dayStr) !== -1;
                var isToday = dayStr === todayStr;

                if (isToday) {
                    classes += ' is-today';
                }
                if (isPast) {
                    classes += ' is-disabled';
                }
                if (isHoliday) {
                    classes += ' is-holiday';
                }
                // آیا تاریخ انتخاب‌شده است؟
                if (this.currentInput) {
                    var sel = parseJalaliString(this.currentInput.value);
                    if (sel && sel[0] === this.currentYear && sel[1] === this.currentMonth && sel[2] === d) {
                        classes += ' is-selected';
                    }
                }
                var attrs = isPast || isHoliday ? ' disabled aria-disabled="true"' : '';
                html += '<button type="button" class="' + classes + '" data-day="' + d + '"' + attrs + '>' + toPersianDigits(String(d)) + '</button>';
            }
            html += '</div>';

            // فوتر
            html += '<div class="bk-jdate-footer">';
            html += '<button type="button" class="bk-jdate-today" data-today="1">امروز</button>';
            html += '<button type="button" class="bk-jdate-clear" data-clear="1">پاک‌کردن</button>';
            html += '</div>';

            this.picker.innerHTML = html;
            this.attachDayEvents();
        },

        /** اتصال رویدادها به دکمه‌های نمای روز */
        attachDayEvents: function () {
            var self = this;
            // دکمه‌های ناوبری
            this.picker.querySelectorAll('[data-nav]').forEach(function (btn) {
                btn.addEventListener('click', function (e) {
                    e.preventDefault();
                    var dir = btn.getAttribute('data-nav');
                    if (dir === 'prev') {
                        self.currentMonth--;
                        if (self.currentMonth < 1) {
                            self.currentMonth = 12;
                            self.currentYear--;
                        }
                    } else {
                        self.currentMonth++;
                        if (self.currentMonth > 12) {
                            self.currentMonth = 1;
                            self.currentYear++;
                        }
                    }
                    self.renderDays();
                    self.positionPicker(self.currentInput);
                });
            });

            // روزها
            this.picker.querySelectorAll('[data-day]').forEach(function (btn) {
                btn.addEventListener('click', function (e) {
                    e.preventDefault();
                    // اگر روز غیرفعال است (گذشته یا تعطیل)، کاری نکن
                    if (btn.disabled || btn.classList.contains('is-disabled') || btn.classList.contains('is-holiday')) {
                        return;
                    }
                    var d = parseInt(btn.getAttribute('data-day'), 10);
                    if (self.currentInput) {
                        self.currentInput.value = formatJalali(self.currentYear, self.currentMonth, d);
                        // رویداد change برای اعتبارسنجی و به‌روزرسانی ساعت‌یاب
                        self.currentInput.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                    self.closePicker();
                });
            });

            // دکمهٔ امروز
            var todayBtn = this.picker.querySelector('[data-today]');
            if (todayBtn) {
                // اگر امروز تعطیل است، دکمه را غیرفعال کن
                var config = window.BK_CONFIG || { holidays: [] };
                var holidays = config.holidays || [];
                var now = new Date();
                var j = toJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
                var todayStr = String(j[0]) + '/' + String(j[1]).padStart(2, '0') + '/' + String(j[2]).padStart(2, '0');
                if (holidays.indexOf(todayStr) !== -1) {
                    todayBtn.disabled = true;
                    todayBtn.classList.add('is-disabled');
                    todayBtn.title = 'امروز تعطیل است';
                }

                todayBtn.addEventListener('click', function (e) {
                    e.preventDefault();
                    if (todayBtn.disabled) return;
                    if (self.currentInput) {
                        self.currentInput.value = formatJalali(j[0], j[1], j[2]);
                        self.currentInput.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                    self.closePicker();
                });
            }

            // دکمهٔ پاک‌کردن
            var clearBtn = this.picker.querySelector('[data-clear]');
            if (clearBtn) {
                clearBtn.addEventListener('click', function (e) {
                    e.preventDefault();
                    if (self.currentInput) {
                        self.currentInput.value = '';
                        self.currentInput.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                    self.closePicker();
                });
            }
        }
    };

    // ================================================================
    //  Time Picker — انتخاب ساعت نیم‌ساعتی
    //  بازهٔ کاری ۹:۰۰ تا ۲۱:۳۰ — نیم ساعت به نیم ساعت
    // ================================================================

    var TimePicker = {
        currentInput: null,
        picker: null,
        pickerOpen: false,
        bookedSlots: [],     // ساعت‌های رزروشده برای تاریخ انتخاب‌شده
        currentDate: '',     // تاریخ انتخاب‌شده (YYYY/MM/DD شمسی)

        /** راه‌اندازی روی فیلدهای با کلاس bk-jtime */
        init: function (selector) {
            var self = this;
            var inputs = document.querySelectorAll(selector);
            inputs.forEach(function (input) {
                input.addEventListener('focus', function (e) {
                    e.preventDefault();
                    self.openPicker(input);
                });
                input.addEventListener('click', function (e) {
                    e.preventDefault();
                    if (!self.pickerOpen) {
                        self.openPicker(input);
                    }
                });
                input.addEventListener('keydown', function (e) {
                    if (e.key === 'Escape' && self.pickerOpen) {
                        self.closePicker();
                    }
                });
            });

            // بستن picker با کلیک خارج
            document.addEventListener('mousedown', function (e) {
                if (!self.pickerOpen) return;
                if (self.picker && self.picker.contains(e.target)) return;
                if (self.currentInput && self.currentInput.contains(e.target)) return;
                self.closePicker();
            });
        },

        /** به‌روزرسانی ساعت‌های رزروشده وقتی تاریخ تغییر می‌کند */
        refreshForDate: function (dateStr) {
            this.currentDate = dateStr || '';
            this.bookedSlots = [];
            var self = this;
            var config = window.BK_CONFIG || {};

            // اگر جلوگیری از رزرو تکراری فعال است و URL موجود است، ساعت‌های گرفته‌شده را واکشی کن
            if (config.preventDuplicate && config.bookedSlotsUrl && this.currentDate) {
                try {
                    fetch(config.bookedSlotsUrl + '&date=' + encodeURIComponent(this.currentDate), {
                        method: 'GET',
                        headers: { 'X-Requested-With': 'XMLHttpRequest' }
                    })
                    .then(function (r) { return r.json(); })
                    .then(function (data) {
                        if (data && data.ok && Array.isArray(data.slots)) {
                            self.bookedSlots = data.slots;
                            // اگر picker باز است، دوباره رندر کن
                            if (self.pickerOpen) {
                                self.buildPicker();
                            }
                        }
                    })
                    .catch(function () {});
                } catch (e) {}
            }
        },

        /** باز کردن picker */
        openPicker: function (input) {
            this.currentInput = input;
            // خواندن تاریخ انتخاب‌شده از فیلد تاریخ
            var dateInput = document.querySelector('[name="preferred_date"]');
            if (dateInput && dateInput.value) {
                var parsed = parseJalaliString(dateInput.value);
                if (parsed) {
                    this.currentDate = String(parsed[0]) + '/' + String(parsed[1]).padStart(2, '0') + '/' + String(parsed[2]).padStart(2, '0');
                }
            }
            this.buildPicker();
            this.positionPicker(input);
            this.pickerOpen = true;
        },

        /** بستن picker */
        closePicker: function () {
            if (this.picker && this.picker.parentNode) {
                this.picker.parentNode.removeChild(this.picker);
            }
            this.picker = null;
            this.pickerOpen = false;
            this.currentInput = null;
        },

        /** ساخت picker و درج در DOM */
        buildPicker: function () {
            var self = this;
            if (this.picker) {
                this.picker.remove();
            }
            this.picker = document.createElement('div');
            this.picker.className = 'bk-jtime-picker ' + getPickerThemeClass();
            this.picker.setAttribute('dir', 'rtl');
            this.picker.setAttribute('role', 'dialog');
            document.body.appendChild(this.picker);

            // هدر
            var header = document.createElement('div');
            header.className = 'bk-jtime-header';
            header.textContent = 'انتخاب ساعت';
            this.picker.appendChild(header);

            // هشدار اگر تاریخ انتخاب نشده
            if (!this.currentDate) {
                var warn = document.createElement('p');
                warn.className = 'bk-jtime-warn';
                warn.textContent = 'ابتدا تاریخ را انتخاب کنید.';
                this.picker.appendChild(warn);

                var footer = document.createElement('div');
                footer.className = 'bk-jtime-footer';
                var clearBtn = document.createElement('button');
                clearBtn.type = 'button';
                clearBtn.className = 'bk-jtime-clear';
                clearBtn.textContent = 'بستن';
                clearBtn.addEventListener('click', function (e) {
                    e.preventDefault();
                    self.closePicker();
                });
                footer.appendChild(clearBtn);
                this.picker.appendChild(footer);
                return;
            }

            // لیست slot‌ها
            var slotsWrap = document.createElement('div');
            slotsWrap.className = 'bk-jtime-slots';
            var slots = this.generateSlots();
            var currentValue = (self.currentInput && self.currentInput.value) ? this.normalizeTime(self.currentInput.value) : '';

            if (slots.length === 0) {
                var empty = document.createElement('p');
                empty.className = 'bk-jtime-warn';
                empty.textContent = 'ساعت کاری برای این روز تعریف نشده.';
                this.picker.appendChild(empty);
            } else {
                slots.forEach(function (slot) {
                    var btn = document.createElement('button');
                    btn.type = 'button';
                    btn.className = 'bk-jtime-slot';
                    var isBooked = self.bookedSlots.indexOf(slot) !== -1;
                    if (slot === currentValue) {
                        btn.classList.add('is-selected');
                    }
                    if (isBooked) {
                        btn.classList.add('is-booked');
                        btn.disabled = true;
                        btn.title = 'این ساعت قبلاً رزرو شده';
                    }
                    btn.textContent = toPersianDigits(slot);
                    btn.addEventListener('click', function (e) {
                        e.preventDefault();
                        if (btn.disabled) return;
                        if (self.currentInput) {
                            self.currentInput.value = toPersianDigits(slot);
                            self.currentInput.dispatchEvent(new Event('change', { bubbles: true }));
                        }
                        self.closePicker();
                    });
                    slotsWrap.appendChild(btn);
                });
            }
            this.picker.appendChild(slotsWrap);

            // اسکرول به slot انتخاب‌شده
            if (currentValue) {
                var sel = slotsWrap.querySelector('.is-selected');
                if (sel) {
                    sel.scrollIntoView({ block: 'center' });
                }
            }

            // فوتر
            var footer = document.createElement('div');
            footer.className = 'bk-jtime-footer';

            var nowBtn = document.createElement('button');
            nowBtn.type = 'button';
            nowBtn.className = 'bk-jtime-now';
            nowBtn.textContent = 'اکنون';
            nowBtn.addEventListener('click', function (e) {
                e.preventDefault();
                var now = new Date();
                var h = now.getHours();
                var m = now.getMinutes();
                if (m < 15) m = 0;
                else if (m < 45) m = 30;
                else { h++; m = 0; }
                // اگر خارج از بازه کاری بود، به اولین slot برسان
                if (slots.length > 0) {
                    var nowStr = self.formatTime(h, m);
                    var found = null;
                    for (var i = 0; i < slots.length; i++) {
                        if (slots[i] >= nowStr && self.bookedSlots.indexOf(slots[i]) === -1) {
                            found = slots[i];
                            break;
                        }
                    }
                    if (!found) found = slots[0];
                    if (self.currentInput) {
                        self.currentInput.value = toPersianDigits(found);
                        self.currentInput.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                }
                self.closePicker();
            });
            footer.appendChild(nowBtn);

            var clearBtn = document.createElement('button');
            clearBtn.type = 'button';
            clearBtn.className = 'bk-jtime-clear';
            clearBtn.textContent = 'پاک‌کردن';
            clearBtn.addEventListener('click', function (e) {
                e.preventDefault();
                if (self.currentInput) {
                    self.currentInput.value = '';
                    self.currentInput.dispatchEvent(new Event('change', { bubbles: true }));
                }
                self.closePicker();
            });
            footer.appendChild(clearBtn);

            this.picker.appendChild(footer);
        },

        /**
         * تولید لیست ساعت‌ها بر اساس بازه‌های کاری.
         * اگر تاریخ امروز باشد، فقط slot‌های بعد از الان را نشان می‌دهد.
         */
        generateSlots: function () {
            var config = window.BK_CONFIG || { workHours: [[9, 21]] };
            var workHours = config.workHours || [[9, 21]];
            var slots = [];

            // اگر تاریخ امروز است، ساعت فعلی را برای فیلتر کردن استفاده کن
            var todayStr = config.todayJalali || '';
            var isToday = this.currentDate === todayStr;
            var nowH = 0, nowM = 0;
            if (isToday) {
                var now = new Date();
                nowH = now.getHours();
                nowM = now.getMinutes();
            }

            workHours.forEach(function (range) {
                var start = range[0];
                var end = range[1];
                for (var h = start; h < end; h++) {
                    // slot 00
                    var slot1 = String(h).padStart(2, '0') + ':00';
                    if (!isToday || h > nowH || (h === nowH && nowM <= 0)) {
                        slots.push(slot1);
                    }
                    // slot 30
                    var slot2 = String(h).padStart(2, '0') + ':30';
                    if (!isToday || h > nowH || (h === nowH && nowM <= 30)) {
                        slots.push(slot2);
                    }
                }
                // ساعت آخر (مثلاً 13:00 اگر بازه 9-13 است) هم اضافه کن
                var lastSlot = String(end).padStart(2, '0') + ':00';
                if (!isToday || end > nowH) {
                    slots.push(lastSlot);
                }
            });

            // مرتب‌سازی و حذف تکراری‌ها
            slots.sort();
            slots = slots.filter(function (v, i, arr) {
                return i === 0 || v !== arr[i - 1];
            });

            return slots;
        },

        /** قالب‌بندی ساعت به HH:MM */
        formatTime: function (h, m) {
            var hh = String(h).padStart(2, '0');
            var mm = String(m).padStart(2, '0');
            return hh + ':' + mm;
        },

        /** نرمال‌سازی ورودی کاربر — تبدیل ارقام فارسی و قالب‌بندی */
        normalizeTime: function (val) {
            if (!val) return '';
            val = toEnglishDigits(val).trim();
            var m = val.match(/^(\d{1,2})[:.\s]?(\d{0,2})$/);
            if (!m) return '';
            var h = parseInt(m[1], 10);
            var min = m[2] ? parseInt(m[2], 10) : 0;
            if (min < 15) min = 0;
            else if (min < 45) min = 30;
            else { h++; min = 0; }
            if (h < 0 || h > 23) return '';
            return this.formatTime(h, min);
        },

        /** موقع‌دهی picker زیر input */
        positionPicker: function (input) {
            if (!this.picker) return;
            var rect = input.getBoundingClientRect();
            var pickerRect = this.picker.getBoundingClientRect();
            var top = rect.bottom + window.scrollY + 4;
            var left = rect.left + window.scrollX;

            if (top + pickerRect.height > window.innerHeight + window.scrollY) {
                top = rect.top + window.scrollY - pickerRect.height - 4;
            }
            if (left + pickerRect.width > window.innerWidth + window.scrollX) {
                left = window.innerWidth + window.scrollX - pickerRect.width - 8;
            }
            if (left < window.scrollX + 8) {
                left = window.scrollX + 8;
            }

            this.picker.style.top = top + 'px';
            this.picker.style.left = left + 'px';
        }
    };

    // ================================================================
    //  بستن خودکار آلرت‌ها
    // ================================================================

    function autoDismissAlerts() {
        var alerts = document.querySelectorAll('.bk-banner, .bk-alert-success');
        alerts.forEach(function (alert) {
            setTimeout(function () {
                if (alert && alert.parentNode) {
                    alert.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
                    alert.style.opacity = '0';
                    alert.style.transform = 'translateY(-6px)';
                    setTimeout(function () {
                        if (alert.parentNode) alert.remove();
                    }, 400);
                }
            }, 6000);
        });

        // دکمهٔ بستن روی بنرها
        var closeBtns = document.querySelectorAll('.bk-banner-close');
        closeBtns.forEach(function (btn) {
            btn.addEventListener('click', function () {
                var banner = btn.closest('.bk-banner');
                if (banner) {
                    banner.style.opacity = '0';
                    setTimeout(function () {
                        if (banner.parentNode) banner.remove();
                    }, 200);
                }
            });
        });
    }

    // ================================================================
    //  اعتبارسنجی فرم رزرو
    // ================================================================

    function setupFormValidation() {
        var form = document.querySelector('.bk-form');
        if (!form) return;

        form.addEventListener('submit', function (e) {
            var author = form.querySelector('[name="author"]');
            var phone = form.querySelector('[name="phone"]');
            var mail = form.querySelector('[name="mail"]');
            var natId = form.querySelector('[name="national_id"]');
            var mailRequired = mail && mail.hasAttribute('required');
            var natIdRequired = natId && natId.hasAttribute('required');

            var errors = [];

            // نام
            if (!author || !author.value.trim()) {
                if (author) showFieldError(author, 'نام و نام خانوادگی الزامی است.');
                errors.push('author');
            } else if (author.value.trim().length > 150) {
                showFieldError(author, 'نام بیش از حد طولانی است.');
                errors.push('author');
            }

            // تلفن
            if (!phone || !isValidPhone(phone.value)) {
                if (phone) showFieldError(phone, 'شماره تلفن معتبر نیست.');
                errors.push('phone');
            }

            // ایمیل
            if (mail) {
                var mailVal = mail.value.trim();
                if (mailVal !== '' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mailVal)) {
                    showFieldError(mail, 'نشانی ایمیل معتبر نیست.');
                    errors.push('mail');
                } else if (mailRequired && mailVal === '') {
                    showFieldError(mail, 'ایمیل الزامی است.');
                    errors.push('mail');
                }
            }

            // کد ملی
            if (natId) {
                var natVal = toEnglishDigits(natId.value.trim());
                if (natVal !== '' && !isValidNationalId(natVal)) {
                    showFieldError(natId, 'کد ملی باید ۱۰ رقم معتبر باشد.');
                    errors.push('national');
                } else if (natIdRequired && natVal === '') {
                    showFieldError(natId, 'کد ملی الزامی است.');
                    errors.push('national');
                }
            }

            // تبدیل ارقام فارسی به انگلیسی در فیلدهای عددی (به جز تاریخ که شمسی است)
            ['national_id', 'age'].forEach(function (name) {
                var field = form.querySelector('[name="' + name + '"]');
                if (field && field.value) {
                    field.value = toEnglishDigits(field.value);
                }
            });

            if (errors.length > 0) {
                e.preventDefault();
                var firstError = form.querySelector('.bk-input-error, [aria-invalid="true"]');
                if (firstError) {
                    firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    setTimeout(function () { firstError.focus(); }, 300);
                }
                return false;
            }
        });

        // پاک‌کردن خطای فیلد با تایپ مجدد
        form.querySelectorAll('input, textarea, select').forEach(function (field) {
            field.addEventListener('input', function () {
                field.classList.remove('bk-input-error');
                field.removeAttribute('aria-invalid');
                var err = field.parentNode.querySelector('.bk-field-error');
                if (err) err.remove();
            });
        });
    }

    // ================================================================
    //  شمارندهٔ کاراکتر برای فیلدهای با data-counter
    //  نمایش "n/max" با رنگ‌گذاری هوشمند (سبز در تکمیل، نارنجی نزدیک پایان)
    // ================================================================

    function setupCounters() {
        var counters = document.querySelectorAll('.bk-counter[data-counter-for]');
        counters.forEach(function (counter) {
            var fieldName = counter.getAttribute('data-counter-for');
            var field = document.querySelector('[name="' + fieldName + '"]');
            if (!field) return;

            var fieldWrap = field.closest('.bk-field-counter');
            var max = fieldWrap ? parseInt(fieldWrap.getAttribute('data-max') || '0', 10) : 0;
            if (!max) return;

            function update() {
                // فقط ارقام انگلیسی/فارسی را بشمار (نه فاصله یا - یا +)
                var raw = field.value || '';
                var digits = toEnglishDigits(raw).replace(/\D/g, '');
                var count = digits.length;
                var remaining = max - count;

                // نمایش به‌صورت "n/max" یا "باقیمانده: x"
                counter.textContent = toPersianDigits(String(count)) + '/' + toPersianDigits(String(max));

                // رنگ‌گذاری
                counter.classList.remove('is-warning', 'is-ok', 'is-error');
                if (count === 0) {
                    // حالت پیش‌فرض — خاکستری
                } else if (count === max) {
                    counter.classList.add('is-ok');
                } else if (count > max) {
                    counter.classList.add('is-error');
                } else if (remaining <= 2) {
                    counter.classList.add('is-warning');
                }
            }

            // فقط اجازه تایپ ارقام
            field.addEventListener('input', function () {
                var raw = field.value || '';
                var clean = toEnglishDigits(raw).replace(/\D/g, '');
                if (clean.length > max) {
                    clean = clean.substring(0, max);
                }
                if (raw !== clean) {
                    // حفظ محل مکان‌نما
                    var pos = field.selectionStart;
                    var diff = raw.length - clean.length;
                    field.value = clean;
                    try {
                        field.setSelectionRange(Math.max(0, pos - diff), Math.max(0, pos - diff));
                    } catch (e) {}
                }
                update();
            });

            // به‌روزرسانی اولیه
            update();
        });
    }

    // ================================================================
    //  به‌روزرسانی ساعت‌یاب هنگام تغییر تاریخ
    // ================================================================

    function setupDateChangeHandler() {
        var dateInput = document.querySelector('[name="preferred_date"]');
        var timeInput = document.querySelector('[name="preferred_time"]');
        if (!dateInput) return;

        dateInput.addEventListener('change', function () {
            // پاک‌کردن ساعت قبلی چون ممکن است برای تاریخ جدید معتبر نباشد
            if (timeInput && timeInput.value) {
                timeInput.value = '';
            }
            // درخواست ساعت‌های رزروشده برای تاریخ جدید
            var parsed = parseJalaliString(dateInput.value);
            if (parsed) {
                var dateStr = String(parsed[0]) + '/' + String(parsed[1]).padStart(2, '0') + '/' + String(parsed[2]).padStart(2, '0');
                TimePicker.refreshForDate(dateStr);
            } else {
                TimePicker.refreshForDate('');
            }
        });

        // به‌روزرسانی اولیه اگر تاریخ از قبل تنظیم شده
        if (dateInput.value) {
            var parsed = parseJalaliString(dateInput.value);
            if (parsed) {
                var dateStr = String(parsed[0]) + '/' + String(parsed[1]).padStart(2, '0') + '/' + String(parsed[2]).padStart(2, '0');
                TimePicker.refreshForDate(dateStr);
            }
        }
    }

    // ================================================================
    //  راه‌اندازی هنگام بارگذاری DOM
    // ================================================================

    function init() {
        autoDismissAlerts();
        setupFormValidation();
        setupCounters();
        setupDateChangeHandler();
        // راه‌اندازی picker روی همهٔ فیلدهای با کلاس bk-jdate و bk-jtime
        JalaliDatePicker.init('.bk-jdate');
        TimePicker.init('.bk-jtime');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
