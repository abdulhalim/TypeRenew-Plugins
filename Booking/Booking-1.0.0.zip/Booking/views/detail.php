<?php
/**
 * صفحهٔ جزئیات یک رزرو — شامل اطلاعات کامل، یادداشت‌ها و دکمه‌های مدیریت
 *
 * @package Booking
 */
use TypechoPlugin\Booking\Plugin;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$r = $reservation; // کوتاه‌سازی برای استفاده در قالب
?>
<div class="bk-wrap bk-detail-wrap">

<?php if (!empty($okMsg)): ?>
<div class="bk-alert bk-alert-success" role="status">
    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="20 6 9 17 4 12"></polyline></svg>
    <span><?php echo Plugin::e($okMsg); ?></span>
</div>
<?php endif; ?>

<?php if (!empty($errorMsg)): ?>
<div class="bk-alert bk-alert-error" role="alert">
    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
    <span><?php echo Plugin::e($errorMsg); ?></span>
</div>
<?php endif; ?>

<div class="bk-detail-head">
    <div class="bk-detail-head-main">
        <a class="bk-back-link" href="<?php echo Plugin::e($r['listUrl']); ?>">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 18 9 12 15 6"></polyline></svg>
            <span>بازگشت به فهرست</span>
        </a>
        <h1 class="bk-detail-title">
            <?php echo Plugin::e($r['author']); ?>
        </h1>
        <div class="bk-detail-meta">
            <span class="bk-status-badge <?php echo Plugin::e($r['statusClass']); ?>">
                <?php echo Plugin::e($r['statusLabel']); ?>
            </span>
            <span class="bk-meta-item">
                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                <span title="<?php echo Plugin::e(Plugin::faDigits($r['createdJalali'])); ?>">ثبت شده <?php echo Plugin::e($r['createdRelative']); ?></span>
            </span>
        </div>
    </div>

    <div class="bk-detail-actions bk-actions-row">
        <?php if ($r['status'] !== 'approved'): ?>
        <form method="post" action="<?php echo Plugin::e($postUrl); ?>" class="bk-action-form bk-action-flex">
            <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
            <input type="hidden" name="action" value="<?php echo Plugin::e(Plugin::ACTION_NAME); ?>">
            <input type="hidden" name="mode" value="approve">
            <input type="hidden" name="coid" value="<?php echo (int) $r['coid']; ?>">
            <button type="submit" class="bk-btn bk-btn-success bk-btn-block">
                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="20 6 9 17 4 12"></polyline></svg>
                <span>تأیید نوبت</span>
            </button>
        </form>
        <?php endif; ?>

        <?php if ($r['status'] !== 'spam'): ?>
        <form method="post" action="<?php echo Plugin::e($postUrl); ?>" class="bk-action-form bk-action-flex">
            <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
            <input type="hidden" name="action" value="<?php echo Plugin::e(Plugin::ACTION_NAME); ?>">
            <input type="hidden" name="mode" value="reject">
            <input type="hidden" name="coid" value="<?php echo (int) $r['coid']; ?>">
            <button type="submit" class="bk-btn bk-btn-warning bk-btn-block">
                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>
                <span>لغو نوبت</span>
            </button>
        </form>
        <?php endif; ?>

        <form method="post" action="<?php echo Plugin::e($postUrl); ?>" class="bk-action-form bk-action-flex"
            onsubmit="return confirm('آیا این رزرو به‌طور کامل حذف شود؟ این عمل قابل بازگشت نیست.');">
            <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
            <input type="hidden" name="action" value="<?php echo Plugin::e(Plugin::ACTION_NAME); ?>">
            <input type="hidden" name="mode" value="delete">
            <input type="hidden" name="coid" value="<?php echo (int) $r['coid']; ?>">
            <button type="submit" class="bk-btn bk-btn-danger bk-btn-block">
                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6l-2 14a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2L5 6"></path><path d="M10 11v6M14 11v6"></path><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"></path></svg>
                <span>حذف نوبت</span>
            </button>
        </form>
    </div>
</div>

<div class="bk-detail-grid">
    <div class="bk-detail-main">
        <section class="bk-card bk-card-info">
            <h2 class="bk-card-title">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                <span>اطلاعات مراجعه‌کننده</span>
            </h2>
            <dl class="bk-info-list">
                <div class="bk-info-row">
                    <dt>نام و نام خانوادگی</dt>
                    <dd><?php echo Plugin::e($r['author']); ?></dd>
                </div>
                <div class="bk-info-row">
                    <dt>شماره تلفن</dt>
                    <dd><a class="bk-tel-link" href="tel:<?php echo Plugin::e($r['phone']); ?>"><?php echo Plugin::faDigits(Plugin::e($r['phone'])); ?></a></dd>
                </div>
                <?php if ($r['mailField'] !== ''): ?>
                <div class="bk-info-row">
                    <dt>ایمیل</dt>
                    <dd><a class="bk-mail-link" href="mailto:<?php echo Plugin::e($r['mailField']); ?>"><?php echo Plugin::e($r['mailField']); ?></a></dd>
                </div>
                <?php endif; ?>
                <?php if ($r['nationalId'] !== ''): ?>
                <div class="bk-info-row">
                    <dt>کد ملی</dt>
                    <dd><?php echo Plugin::faDigits(Plugin::e($r['nationalId'])); ?></dd>
                </div>
                <?php endif; ?>
                <?php if ($r['age'] !== ''): ?>
                <div class="bk-info-row">
                    <dt>سن</dt>
                    <dd><?php echo Plugin::faDigits(Plugin::e($r['age'])); ?> سال</dd>
                </div>
                <?php endif; ?>
                <?php if ($r['gender'] !== ''): ?>
                <div class="bk-info-row">
                    <dt>جنسیت</dt>
                    <dd><?php
                        echo match ($r['gender']) {
                            'male'   => 'آقا',
                            'female' => 'خانم',
                            'other'  => 'ترجیح نداده',
                            default  => Plugin::e($r['gender']),
                        };
                    ?></dd>
                </div>
                <?php endif; ?>
            </dl>
        </section>

        <section class="bk-card bk-card-service">
            <h2 class="bk-card-title">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                <span>جزئیات رزرو</span>
            </h2>
            <dl class="bk-info-list">
                <div class="bk-info-row">
                    <dt>تاریخ پیشنهادی</dt>
                    <dd>
                        <?php if ($r['preferredDate'] !== ''): ?>
                        <span><?php echo Plugin::faDigits(Plugin::e($r['preferredDate'])); ?></span>
                        <?php else: ?>
                        <span class="bk-mute">مشخص نشده</span>
                        <?php endif; ?>
                    </dd>
                </div>
                <div class="bk-info-row">
                    <dt>ساعت پیشنهادی</dt>
                    <dd>
                        <?php if ($r['preferredTime'] !== ''): ?>
                        <span><?php echo Plugin::faDigits(Plugin::e($r['preferredTime'])); ?></span>
                        <?php else: ?>
                        <span class="bk-mute">مشخص نشده</span>
                        <?php endif; ?>
                    </dd>
                </div>
            </dl>

            <?php if ($r['description'] !== ''): ?>
            <div class="bk-desc-block">
                <h3 class="bk-desc-title">توضیحات مراجعه‌کننده</h3>
                <p class="bk-desc-text"><?php echo nl2br(Plugin::e($r['description'])); ?></p>
            </div>
            <?php endif; ?>
        </section>

        <?php if (!empty($notes)): ?>
        <section class="bk-card bk-card-notes">
            <h2 class="bk-card-title">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                <span>یادداشت‌های داخلی (<?php echo Plugin::faDigits(count($notes)); ?>)</span>
            </h2>
            <ul class="bk-notes-list">
                <?php foreach ($notes as $n): ?>
                <li class="bk-note">
                    <div class="bk-note-head">
                        <span class="bk-note-author"><?php echo Plugin::e($n['author']); ?></span>
                        <span class="bk-note-time" title="<?php echo Plugin::e(Plugin::faDigits($n['createdJalali'])); ?>"><?php echo Plugin::e($n['createdRelative']); ?></span>
                    </div>
                    <p class="bk-note-text"><?php echo nl2br(Plugin::e($n['text'])); ?></p>
                </li>
                <?php endforeach; ?>
            </ul>
        </section>
        <?php endif; ?>

        <section class="bk-card bk-card-add-note">
            <h2 class="bk-card-title">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                <span>افزودن یادداشت داخلی</span>
            </h2>
            <form class="bk-note-form" method="post" action="<?php echo Plugin::e($postUrl); ?>">
                <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
                <input type="hidden" name="action" value="<?php echo Plugin::e(Plugin::ACTION_NAME); ?>">
                <input type="hidden" name="mode" value="note">
                <input type="hidden" name="coid" value="<?php echo (int) $r['coid']; ?>">
                <textarea name="text" class="bk-textarea" rows="3"
                    placeholder="یادداشت داخلی — فقط برای اعضای مجاز قابل مشاهده است…"
                    maxlength="2000" required></textarea>
                <div class="bk-note-form-actions">
                    <p class="bk-hint">یادداشت با نام «<?php echo Plugin::e($currentName); ?>» ثبت خواهد شد.</p>
                    <button type="submit" class="bk-btn bk-btn-primary">
                        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
                        <span>ثبت یادداشت</span>
                    </button>
                </div>
            </form>
        </section>
    </div>

    <aside class="bk-detail-side">
        <section class="bk-card bk-card-meta">
            <h2 class="bk-card-title">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
                <span>اطلاعات سیستم</span>
            </h2>
            <dl class="bk-info-list bk-info-list-compact">
                <div class="bk-info-row">
                    <dt>کد رزرو</dt>
                    <dd>#<?php echo Plugin::faDigits((int) $r['coid']); ?></dd>
                </div>
                <div class="bk-info-row">
                    <dt>تاریخ ثبت</dt>
                    <dd><?php echo Plugin::e(Plugin::faDigits($r['createdJalali'])); ?></dd>
                </div>
                <div class="bk-info-row">
                    <dt>وضعیت</dt>
                    <dd>
                        <span class="bk-status-badge <?php echo Plugin::e($r['statusClass']); ?>"><?php echo Plugin::e($r['statusLabel']); ?></span>
                    </dd>
                </div>
                <?php if (!empty($r['ip'])): ?>
                <div class="bk-info-row">
                    <dt>آدرس IP</dt>
                    <dd><?php echo Plugin::e($r['ip']); ?></dd>
                </div>
                <?php endif; ?>
            </dl>
        </section>

        <?php if ($r['mailField'] !== '' || $r['phone'] !== ''): ?>
        <section class="bk-card bk-card-contact">
            <h2 class="bk-card-title">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                <span>تماس سریع</span>
            </h2>
            <div class="bk-contact-actions">
                <?php if ($r['phone'] !== ''): ?>
                <a class="bk-btn bk-btn-success bk-btn-block bk-call-btn" href="tel:<?php echo Plugin::e($r['phone']); ?>">
                    <span class="bk-call-phone"><?php echo Plugin::faDigits(Plugin::e($r['phone'])); ?></span>
                </a>
                <?php endif; ?>
                <?php if ($r['mailField'] !== ''): ?>
                <a class="bk-btn bk-btn-ghost bk-btn-block" href="mailto:<?php echo Plugin::e($r['mailField']); ?>">
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                    <span>ارسال ایمیل</span>
                </a>
                <?php endif; ?>
            </div>
        </section>
        <?php endif; ?>
    </aside>
</div>

</div>
