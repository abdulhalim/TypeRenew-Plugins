<?php
/**
 * صفحهٔ فهرست رزروها — برای اعضای واردشده
 *
 * @package Booking
 */
use TypechoPlugin\Booking\Plugin;
use TypechoPlugin\Booking\BookingList;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$services = isset($services) ? $services : [];
?>
<div class="bk-wrap bk-list-wrap">

<?php if (!empty($banner)): ?>
<div class="bk-banner is-<?php echo Plugin::e($banner[1]); ?>" role="status">
    <p><?php echo Plugin::e($banner[0]); ?></p>
    <button type="button" class="bk-banner-close" aria-label="بستن">&times;</button>
</div>
<?php endif; ?>

<?php
$okCode = (string) ($this->request->get('ok') ?? '');
if ($okCode === 'delete'):
?>
<div class="bk-alert bk-alert-success" role="status">
    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="20 6 9 17 4 12"></polyline></svg>
    <span>رزرو با موفقیت حذف شد.</span>
</div>
<?php endif; ?>

<div class="bk-list-head">
    <div class="bk-list-head-main">
        <h1 class="bk-list-title">
            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
            <span>فهرست رزروها</span>
        </h1>
        <p class="bk-list-sub">در مجموع <?php echo Plugin::faDigits($totalCount); ?> رزرو ثبت شده است.</p>
    </div>
    <div class="bk-list-head-side">
        <a class="bk-btn bk-btn-ghost" href="<?php echo Plugin::e($formUrl); ?>">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
            <span>فرم رزرو</span>
        </a>
    </div>
</div>

<div class="bk-stats-bar">
    <a class="bk-stat-chip<?php echo $filterStatus === '' ? ' is-active' : ''; ?>"
       href="<?php echo Plugin::e(Plugin::listUrl()); ?>">
        <span class="bk-stat-num"><?php echo Plugin::faDigits($totalCount); ?></span>
        <span class="bk-stat-label">همه</span>
    </a>
    <a class="bk-stat-chip bk-stat-pending<?php echo $filterStatus === 'waiting' ? ' is-active' : ''; ?>"
       href="<?php echo Plugin::e(BookingList::pagedUrl(1, $search, 'waiting')); ?>">
        <span class="bk-stat-num"><?php echo Plugin::faDigits($pendingCount); ?></span>
        <span class="bk-stat-label">در انتظار</span>
    </a>
    <a class="bk-stat-chip bk-stat-approved<?php echo $filterStatus === 'approved' ? ' is-active' : ''; ?>"
       href="<?php echo Plugin::e(BookingList::pagedUrl(1, $search, 'approved')); ?>">
        <span class="bk-stat-num"><?php echo Plugin::faDigits($approvedCount); ?></span>
        <span class="bk-stat-label">تأیید شده</span>
    </a>
    <a class="bk-stat-chip bk-stat-rejected<?php echo $filterStatus === 'spam' ? ' is-active' : ''; ?>"
       href="<?php echo Plugin::e(BookingList::pagedUrl(1, $search, 'spam')); ?>">
        <span class="bk-stat-num"><?php echo Plugin::faDigits($rejectedCount); ?></span>
        <span class="bk-stat-label">رد شده</span>
    </a>
</div>

<form class="bk-search" method="get" action="<?php echo Plugin::e(Plugin::listUrl()); ?>">
    <div class="bk-search-input">
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
        <input type="text" name="q" value="<?php echo Plugin::e($search); ?>"
            placeholder="جستجو بر اساس نام، تلفن، ایمیل یا توضیحات…"
            maxlength="100" inputmode="search">
    </div>
    <button type="submit" class="bk-btn bk-btn-ghost">جستجو</button>
    <?php if ($search !== ''): ?>
    <a class="bk-btn bk-btn-text" href="<?php echo Plugin::e(BookingList::pagedUrl(1, '', $filterStatus)); ?>">حذف فیلتر</a>
    <?php endif; ?>
</form>

<?php if (empty($items)): ?>
<div class="bk-empty">
    <svg viewBox="0 0 24 24" width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
    <p>هیچ رزروایی برای نمایش نیست.</p>
    <?php if ($search !== '' || $filterStatus !== ''): ?>
    <p class="bk-empty-sub">با فیلترهای فعلی نتیجه‌ای یافت نشد.</p>
    <a class="bk-btn bk-btn-ghost" href="<?php echo Plugin::e(Plugin::listUrl()); ?>">نمایش همه</a>
    <?php endif; ?>
</div>
<?php else: ?>

<div class="bk-table-wrap">
<table class="bk-table">
    <thead>
        <tr>
            <th class="bk-col-status">وضعیت</th>
            <th class="bk-col-name">نام مراجعه‌کننده</th>
            <th class="bk-col-phone">تلفن</th>
            <th class="bk-col-date">تاریخ پیشنهادی</th>
            <th class="bk-col-created">زمان ثبت</th>
            <th class="bk-col-notes">یادداشت</th>
            <th class="bk-col-actions">عملیات</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($items as $it): ?>
        <tr class="bk-row bk-row-<?php echo Plugin::e($it['statusClass']); ?>">
            <td class="bk-cell-status">
                <span class="bk-status-badge <?php echo Plugin::e($it['statusClass']); ?>">
                    <?php echo Plugin::e($it['statusLabel']); ?>
                </span>
            </td>
            <td class="bk-cell-name">
                <a class="bk-name-link" href="<?php echo Plugin::e($it['detailUrl']); ?>">
                    <?php echo Plugin::e($it['author']); ?>
                </a>
            </td>
            <td class="bk-cell-phone">
                <span class="bk-phone"><?php echo Plugin::faDigits(Plugin::e($it['phone'])); ?></span>
            </td>
            <td class="bk-cell-date">
                <?php if ($it['preferredDate'] !== ''): ?>
                <span><?php echo Plugin::faDigits(Plugin::e($it['preferredDate'])); ?></span>
                <?php if ($it['preferredTime'] !== ''): ?>
                <span class="bk-time"><?php echo Plugin::faDigits(Plugin::e($it['preferredTime'])); ?></span>
                <?php endif; ?>
                <?php else: ?>
                <span class="bk-mute">—</span>
                <?php endif; ?>
            </td>
            <td class="bk-cell-created">
                <span class="bk-relative" title="<?php echo Plugin::e(Plugin::faDigits($it['createdJalali'])); ?>"><?php echo Plugin::e($it['createdRelative']); ?></span>
            </td>
            <td class="bk-cell-notes">
                <?php if ($it['noteCount'] > 0): ?>
                <span class="bk-note-chip" title="<?php echo Plugin::faDigits($it['noteCount']); ?> یادداشت">
                    <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                    <?php echo Plugin::faDigits($it['noteCount']); ?>
                </span>
                <?php else: ?>
                <span class="bk-mute">—</span>
                <?php endif; ?>
            </td>
            <td class="bk-cell-actions">
                <a class="bk-btn bk-btn-sm bk-btn-primary" href="<?php echo Plugin::e($it['detailUrl']); ?>">
                    <span>مشاهده</span>
                </a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</div>

<?php if ($pages > 1): ?>
<nav class="bk-pagination" aria-label="صفحه‌بندی">
    <?php for ($i = 1; $i <= $pages; $i++): ?>
        <?php if ($i == $page): ?>
        <span class="bk-page bk-page-current"><?php echo Plugin::faDigits($i); ?></span>
        <?php elseif ($i == 1 || $i == $pages || abs($i - $page) <= 2): ?>
        <a class="bk-page" href="<?php echo Plugin::e(BookingList::pagedUrl($i, $search, $filterStatus)); ?>"><?php echo Plugin::faDigits($i); ?></a>
        <?php elseif ($i == 2 || $i == $pages - 1): ?>
        <span class="bk-page-ellipsis">…</span>
        <?php endif; ?>
    <?php endfor; ?>
</nav>
<?php endif; ?>

<?php endif; ?>

</div>
