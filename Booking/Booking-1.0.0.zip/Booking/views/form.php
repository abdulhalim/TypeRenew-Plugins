<?php
/**
 * صفحهٔ فرم رزرو نوبت — فرم عمومی برای ثبت درخواست
 *
 * @package Booking
 */
use TypechoPlugin\Booking\Plugin;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$rememberName = isset($rememberName) ? $rememberName : '';
$rememberMail = isset($rememberMail) ? $rememberMail : '';
$requireMail = isset($requireMail) ? $requireMail : false;
$requireNatId = isset($requireNatId) ? $requireNatId : false;
$todayJalali = isset($todayJalali) ? $todayJalali : Plugin::todayJalali();
$workHours = isset($workHours) ? $workHours : [[9, 21]];
$holidays = isset($holidays) ? $holidays : [];
$preventDuplicate = isset($preventDuplicate) ? $preventDuplicate : true;
$bookedSlotsUrl = isset($bookedSlotsUrl) ? $bookedSlotsUrl : '';

// تبدیل آرایه‌های PHP به JSON برای JavaScript
$workHoursJson = json_encode($workHours, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$holidaysJson = json_encode($holidays, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>
<div class="bk-wrap bk-form-wrap">
<script>
window.BK_CONFIG = {
    workHours: <?php echo $workHoursJson; ?>,
    holidays: <?php echo $holidaysJson; ?>,
    preventDuplicate: <?php echo $preventDuplicate ? 'true' : 'false'; ?>,
    bookedSlotsUrl: <?php echo json_encode($bookedSlotsUrl, JSON_UNESCAPED_SLASHES); ?>,
    todayJalali: <?php echo json_encode(Plugin::normalizeJalaliDate($todayJalali), JSON_UNESCAPED_SLASHES); ?>
};
</script>

<?php if (!empty($banner)): ?>
<div class="bk-banner is-<?php echo Plugin::e($banner[1]); ?>" role="status">
    <p><?php echo Plugin::e($banner[0]); ?></p>
    <button type="button" class="bk-banner-close" aria-label="بستن">&times;</button>
</div>
<?php endif; ?>

<?php if (!empty($errorMsg)): ?>
<div class="bk-alert bk-alert-error" role="alert">
    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
    <span><?php echo Plugin::e($errorMsg); ?></span>
</div>
<?php endif; ?>

<?php if (!empty($justSubmitted)): ?>
<div class="bk-success-card" role="status">
    <svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
    <div class="bk-success-body">
        <h2><?php echo Plugin::e($successMsg); ?></h2>
        <?php if ($submittedName !== ''): ?>
        <p>کاربر گرامی <strong><?php echo Plugin::e($submittedName); ?></strong>، درخواست شما در سیستم ثبت شد.</p>
        <?php endif; ?>
        <p class="bk-success-note">همکاران ما در اولین فرصت برای هماهنگی نوبت با شما تماس خواهند گرفت.</p>
        <a class="bk-btn bk-btn-ghost" href="<?php echo Plugin::e($formUrl); ?>">ثبت رزرو جدید</a>
    </div>
</div>
<?php else: ?>

<div class="bk-hero">
    <h1 class="bk-hero-title"><?php echo Plugin::e($formTitle); ?></h1>
    <?php if (!empty($formIntro)): ?>
    <p class="bk-hero-intro"><?php echo Plugin::e($formIntro); ?></p>
    <?php endif; ?>
</div>

<?php if (!empty($errorMsg)): ?>
<div class="bk-alert bk-alert-error" role="alert">
    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
    <span><?php echo Plugin::e($errorMsg); ?></span>
</div>
<?php endif; ?>

<form class="bk-form" method="post" action="<?php echo Plugin::e($postUrl); ?>" novalidate>
    <?php /* توکن امنیتی CSRF */ ?>
    <input type="hidden" name="_" value="<?php echo Plugin::e($token); ?>">
    <input type="hidden" name="action" value="<?php echo Plugin::e(Plugin::ACTION_NAME); ?>">

    <!-- تلهٔ اسپم — فیلد پنهان که ربات‌ها پر می‌کنند -->
    <div class="bk-honeypot" aria-hidden="true">
        <label>وب‌سایت (خالی بگذارید)<input type="text" name="website" tabindex="-1" autocomplete="off"></label>
    </div>

    <div class="bk-grid bk-grid-2">
        <div class="bk-field">
            <label for="bk-author" class="bk-label">
                نام و نام خانوادگی <span class="bk-req" aria-hidden="true">*</span>
            </label>
            <input type="text" id="bk-author" name="author" class="bk-input"
                value="<?php echo Plugin::e($rememberName); ?>"
                placeholder="مثلاً: محمد محمدی"
                required maxlength="150"
                autocomplete="name">
        </div>

        <div class="bk-field bk-field-counter" data-max="11" data-counter="phone">
            <label for="bk-phone" class="bk-label">
                شماره تلفن <span class="bk-req" aria-hidden="true">*</span>
            </label>
            <input type="tel" id="bk-phone" name="phone" class="bk-input"
                placeholder="مثلاً: 09121234567"
                required inputmode="numeric"
                autocomplete="tel"
                maxlength="11"
                pattern="[0-9]{7,15}">
            <span class="bk-counter" data-counter-for="phone">۰/۱۱</span>
        </div>
    </div>

    <div class="bk-grid bk-grid-2">
        <div class="bk-field">
            <label for="bk-date" class="bk-label">تاریخ پیشنهادی</label>
            <input type="text" id="bk-date" name="preferred_date" class="bk-input bk-jdate"
                placeholder="مثلاً: ۱۴۰۳/۰۶/۱۵"
                value=""
                maxlength="20"
                autocomplete="off"
                readonly>
            <p class="bk-hint">تاریخ امروز: <?php echo Plugin::faDigits($todayJalali); ?> — برای انتخاب، روی فیلد کلیک کنید.</p>
        </div>

        <div class="bk-field">
            <label for="bk-time" class="bk-label">ساعت پیشنهادی</label>
            <input type="text" id="bk-time" name="preferred_time" class="bk-input bk-jtime"
                placeholder="مثلاً: ۱۰:۰۰"
                value=""
                maxlength="5"
                autocomplete="off"
                readonly>
            <p class="bk-hint">ساعت‌های کاری ۹ تا ۲۱ — نیم ساعت به نیم ساعت.</p>
        </div>
    </div>

    <div class="bk-grid bk-grid-3">
        <div class="bk-field">
            <label for="bk-mail" class="bk-label">
                ایمیل
                <?php if ($requireMail): ?><span class="bk-req" aria-hidden="true">*</span><?php endif; ?>
            </label>
            <input type="email" id="bk-mail" name="mail" class="bk-input"
                value="<?php echo Plugin::e($rememberMail); ?>"
                placeholder="example@email.com"
                <?php echo $requireMail ? 'required' : ''; ?>
                autocomplete="email">
        </div>

        <div class="bk-field bk-field-counter" data-max="10" data-counter="national_id">
            <label for="bk-nat" class="bk-label">
                کد ملی
                <?php if ($requireNatId): ?><span class="bk-req" aria-hidden="true">*</span><?php endif; ?>
            </label>
            <input type="text" id="bk-nat" name="national_id" class="bk-input"
                placeholder="۱۰ رقم"
                maxlength="10"
                inputmode="numeric"
                pattern="\d{10}"
                <?php echo $requireNatId ? 'required' : ''; ?>
                autocomplete="off">
            <span class="bk-counter" data-counter-for="national_id">۰/۱۰</span>
        </div>

        <div class="bk-field">
            <label for="bk-age" class="bk-label">سن</label>
            <input type="text" id="bk-age" name="age" class="bk-input"
                placeholder="مثلاً: ۳۰"
                maxlength="5"
                inputmode="numeric"
                autocomplete="off">
        </div>
    </div>

    <div class="bk-field">
        <label class="bk-label">جنسیت</label>
        <div class="bk-radio-row">
            <label class="bk-radio-option">
                <input type="radio" name="gender" value="male">
                <span>آقا</span>
            </label>
            <label class="bk-radio-option">
                <input type="radio" name="gender" value="female">
                <span>خانم</span>
            </label>
            <label class="bk-radio-option">
                <input type="radio" name="gender" value="other">
                <span>ترجیح می‌دهم نگویم</span>
            </label>
        </div>
    </div>

    <div class="bk-field">
        <label for="bk-desc" class="bk-label">توضیحات</label>
        <textarea id="bk-desc" name="description" class="bk-textarea"
            rows="4"
            placeholder="در صورت تمایل، مشکل یا درخواست خود را شرح دهید…"
            maxlength="2000"></textarea>
        <p class="bk-hint">حداکثر ۲۰۰۰ نویسه.</p>
    </div>

    <div class="bk-form-actions">
        <button type="submit" class="bk-btn bk-btn-primary">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 11l3 3L22 4"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>
            <span>ثبت درخواست رزرو</span>
        </button>
    </div>

    <p class="bk-form-foot">
        اطلاعات شما محرمانه است و فقط توسط همکاران مجاز سایت قابل مشاهده است.
    </p>
</form>

<?php if ($canManage): ?>
<div class="bk-member-link">
    <a class="bk-btn bk-btn-ghost" href="<?php echo Plugin::e($listUrl); ?>">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18M3 12h18M3 18h18"></path></svg>
        <span>فهرست رزروها (<?php echo Plugin::faDigits(Plugin::pendingCount()); ?> در انتظار)</span>
    </a>
</div>
<?php endif; ?>

<?php endif; ?>

</div>
