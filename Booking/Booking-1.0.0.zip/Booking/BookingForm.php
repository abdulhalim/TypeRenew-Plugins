<?php
namespace TypechoPlugin\Booking;

use Typecho\Db;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * صفحهٔ فرم رزرو — فرم عمومی که هر بازدیدکننده‌ای می‌تواند آن را پر کند.
 * نشانی: /booking
 *
 * داده‌های فرم توسط Post.php پردازش و در جدول comments با وضعیت
 * 'waiting' ذخیره می‌شوند — یعنی هرگز به‌صورت عمومی نمایش داده نمی‌شوند.
 *
 * @package Booking
 */
class BookingForm extends BookingPage
{
    protected function pageTitle(): string
    {
        return (string) Plugin::opt('formTitle', 'فرم ثبت رزرو نوبت');
    }

    protected function pageDescription(): string
    {
        $intro = trim((string) Plugin::opt('formIntro', ''));
        return $intro !== '' ? $intro : (string) $this->options->description;
    }

    protected function pageUrl(): string
    {
        return Plugin::formUrl();
    }

    public function render(): void
    {
        $this->renderBookingPage('form.php');
    }

    protected function prepareContext(): array
    {
        // نمایش پیام موفقیت اگر رزروی تازه ثبت شده
        $justSubmitted = ($this->request->get('ok') === '1');
        $submittedName = trim((string) $this->request->get('name', ''));

        // تلاش برای بازیابی مقادیر فرم از کوکی در صورت خطا
        $rememberName = (string) (\Typecho\Cookie::get('__typecho_remember_author') ?? '');
        $rememberMail = (string) (\Typecho\Cookie::get('__typecho_remember_mail') ?? '');

        // اخطار خطای ثبت (اگر پارامتر err وجود داشته باشد)
        $errorMsg = '';
        $errCode = (string) $this->request->get('err', '');
        if ($errCode !== '') {
            $errorMsg = match ($errCode) {
                'name'       => 'نام و نام خانوادگی الزامی است.',
                'phone'      => 'شماره تلفن معتبر نیست.',
                'mail'       => 'نشانی ایمیل معتبر نیست.',
                'national'   => 'کد ملی معتبر نیست — باید ۱۰ رقم و طبق الگوریتم کد ملی ایران صحیح باشد.',
                'past_date'  => 'تاریخ انتخاب‌شده در گذشته است — لطفاً امروز یا روز آینده را انتخاب کنید.',
                'holiday'    => 'تاریخ انتخاب‌شده تعطیل است — لطفاً روز دیگری را انتخاب کنید.',
                'out_of_hours' => 'ساعت انتخاب‌شده خارج از ساعات کاری است — لطفاً از بین ساعات موجود انتخاب کنید.',
                'taken'      => 'این ساعت قبلاً توسط شخص دیگری رزرو شده — لطفاً ساعت دیگری را انتخاب کنید.',
                'spam'       => 'درخواست شما به‌عنوان اسپم شناسایی شد. اگر اشتباه است، چند دقیقه بعد دوباره تلاش کنید.',
                'captcha'    => 'بررسی امنیتی شکست خورد؛ دوباره تلاش کنید.',
                'interval'   => 'ارسال‌ها بیش از حد نزدیک است؛ چند دقیقه بعد دوباره تلاش کنید.',
                'closed'     => 'ثبت رزرو هم‌اکنون بسته شده است.',
                'unknown'    => 'خطای ناشناخته هنگام ثبت رزرو. دوباره تلاش کنید.',
                default       => '',
            };
        }

        return $this->commonContext() + [
            'justSubmitted' => $justSubmitted,
            'submittedName'  => $submittedName,
            'errorMsg'       => $errorMsg,
            'rememberName'   => $rememberName,
            'rememberMail'   => $rememberMail,
            'requireMail'    => Plugin::opt('requireMail', '0') === '1',
            'requireNatId'   => Plugin::opt('requireNationalId', '0') === '1',
            'workHours'      => Plugin::workHours(),
            'holidays'       => Plugin::holidays(),
            'preventDuplicate' => Plugin::preventDuplicate(),
            'bookedSlotsUrl' => Plugin::postUrl() . '?mode=booked-slots',
        ];
    }
}
