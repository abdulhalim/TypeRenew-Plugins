<?php
namespace TypechoPlugin\Booking;

use Typecho\Db;
use Typecho\Router;
use Typecho\Plugin\PluginInterface;
use Utils\Helper;
use Widget\Options;
use Widget\User;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * سیستم ثبت رزرو نوبت — بر پایهٔ سیستم دیدگاه داخلی TypeRenew؛ رزروها پنهان ذخیره و فقط برای اعضای مجاز نمایش داده می‌شوند.
 *
 * @package Booking
 * @author  پوردریایی
 * @link    https://pourdaryaei.ir
 * @since   1.0.0
 * @version 1.2.1
 */
class Plugin implements PluginInterface
{
    public const VERSION = '1.2.1';

    /** نامک نوشتهٔ پشتیبان رزروها */
    public const POST_SLUG = 'booking-archive';

    /** نام مسیرها */
    public const ROUTE_FORM = 'booking_form';
    public const ROUTE_LIST = 'booking_list';
    public const ROUTE_LIST_PAGE = 'booking_list_page';
    public const ROUTE_DETAIL = 'booking_detail';

    /** نام اکشن ثبت و مدیریت رزرو */
    public const ACTION_NAME = 'booking';

    /** پیشوند گزینه‌های ذخیره‌شده در جدول options */
    public const OPTION_PREFIX = 'ext:Booking-';

    /** نشانگر متن رزرو در فیلد text دیدگاه */
    public const TEXT_MARKER = '<!--booking-->';

    /** کش نوشتهٔ پشتیبان رزروها در طول درخواست */
    private static ?array $postCache = null;

    /** نگاشت ماه‌های شمسی (برای نمایش تاریخ) */
    private const J_MONTHS = [
        1 => 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
        'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
    ];

    // (فیلد نوع خدمت حذف شد — نسخهٔ ۱.۱.۰)

    // ====================================================================
    //  فعال‌سازی و غیرفعال‌سازی
    // ====================================================================

    public static function activate()
    {
        // پاک‌سازی مسیرها هنگام فعال‌سازی مجدد
        Helper::removeRoute(self::ROUTE_FORM);
        Helper::removeRoute(self::ROUTE_LIST);
        Helper::removeRoute(self::ROUTE_LIST_PAGE);
        Helper::removeRoute(self::ROUTE_DETAIL);

        // ثبت مسیرها — به‌ترتیب اولویت پس از مسیر do
        Helper::addRoute(self::ROUTE_FORM, '/booking', '\TypechoPlugin\Booking\BookingForm', 'render', 'do');
        Helper::addRoute(self::ROUTE_LIST, '/booking/list', '\TypechoPlugin\Booking\BookingList', 'render', 'do');
        Helper::addRoute(self::ROUTE_LIST_PAGE, '/booking/list/page/[page:digital]', '\TypechoPlugin\Booking\BookingList', 'render', 'do');
        Helper::addRoute(self::ROUTE_DETAIL, '/booking/[coid:digital]', '\TypechoPlugin\Booking\BookingDetail', 'render', 'do');

        Helper::removeAction(self::ACTION_NAME);
        Helper::addAction(self::ACTION_NAME, '\TypechoPlugin\Booking\Post');

        // اطمینان از وجود نوشتهٔ پشتیبان رزروها
        if (empty(self::getBookingPost())) {
            self::createBookingPost();
        }

        $link = Router::url(self::ROUTE_FORM, [], Options::alloc()->index);

        return _t('افزونهٔ ثبت رزرو فعال شد. نشانی فرم رزرو:')
            . ' <a href="' . htmlspecialchars($link, ENT_QUOTES, 'UTF-8') . '">'
            . htmlspecialchars($link, ENT_QUOTES, 'UTF-8') . '</a><br>'
            . _t('فهرست رزروها برای اعضای واردشده در نشانی /booking/list در دسترس است.');
    }

    public static function deactivate()
    {
        Helper::removeRoute(self::ROUTE_FORM);
        Helper::removeRoute(self::ROUTE_LIST);
        Helper::removeRoute(self::ROUTE_LIST_PAGE);
        Helper::removeRoute(self::ROUTE_DETAIL);
        Helper::removeAction(self::ACTION_NAME);

        return _t('افزونهٔ ثبت رزرو غیرفعال شد. رزروهای ثبت‌شده به‌عنوان دیدگاه در دیتابیس باقی می‌مانند.');
    }

    // ====================================================================
    //  تنظیمات افزونه
    // ====================================================================

    /**
     * فرم تنظیمات افزونه
     *
     * توجه: راهنمای مدیر (نشانی فرم رزرو و کد پیوند «رزرو نوبت») در ابتدای همین
     * متد به بالای فرم تنظیمات اضافه می‌شود تا فقط در بخش مدیریت سایت دیده شود —
     * این پیام پیش‌تر در فرم عمومی رزرو (بخش کاربری) نمایش داده می‌شد و مهمان‌ها
     * نیز آن را می‌دیدند.
     */
    public static function config(\Typecho\Widget\Helper\Form $form)
    {
        // ---------- راهنمای مدیر — در بالای تنظیمات افزونه ----------
        $form->addItem(self::adminGuideStyle());
        $form->addItem(self::adminGuideNote());

        $title = new \Typecho\Widget\Helper\Form\Element\Text(
            'formTitle',
            null,
            'فرم ثبت رزرو نوبت',
            _t('عنوان فرم'),
            _t('عنوانی که بالای فرم رزرو نمایش داده می‌شود.')
        );
        $form->addInput($title);

        $intro = new \Typecho\Widget\Helper\Form\Element\Textarea(
            'formIntro',
            null,
            'برای ثبت نوبت، فرم زیر را پر کنید. همکاران ما در اولین فرصت با شما تماس می‌گیرند.',
            _t('متن معرفی فرم'),
            _t('یک جملهٔ کوتاه که زیر عنوان فرم نمایش داده می‌شود. خالی بگذارید تا حذف شود.')
        );
        $form->addInput($intro);

        $pageSize = new \Typecho\Widget\Helper\Form\Element\Text(
            'pageSize',
            null,
            '20',
            _t('تعداد رزرو در هر صفحه'),
            _t('عدد بین ۵ تا ۱۰۰ — تعداد رزروهایی که در هر صفحه از فهرست اعضا نمایش داده می‌شود.')
        );
        $form->addInput($pageSize);

        $notifyMail = new \Typecho\Widget\Helper\Form\Element\Radio(
            'notifyMail',
            ['1' => _t('بله، اعلان ایمیل فرستاده شود'), '0' => _t('خیر، بدون اعلان ایمیل')],
            '1',
            _t('اعلان ایمیل به مدیر'),
            _t('هنگام ثبت رزرو جدید، یک ایمیل اعلان به نشانی ایمیل مدیر سایت ارسال شود. برای این کار باید تنظیمات ایمیل TypeRenew پیکربندی شده باشد.')
        );
        $form->addInput($notifyMail);

        $notifyAddress = new \Typecho\Widget\Helper\Form\Element\Text(
            'notifyAddress',
            null,
            '',
            _t('نشانی دریافت اعلان (اختیاری)'),
            _t('نشانی ایمیل جایگزین برای دریافت اعلان رزروهای جدید. خالی بگذارید تا ایمیل پیش‌فرض سایت استفاده شود.')
        );
        $form->addInput($notifyAddress);

        $requireMail = new \Typecho\Widget\Helper\Form\Element\Radio(
            'requireMail',
            ['1' => _t('بله، ایمیل الزامی باشد'), '0' => _t('خیر، ایمیل اختیاری')],
            '0',
            _t('الزامی‌بودن ایمیل'),
            _t('اگر «بله» باشد، کاربر باید نشانی ایمیل معتبر وارد کند.')
        );
        $form->addInput($requireMail);

        $requireNationalId = new \Typecho\Widget\Helper\Form\Element\Radio(
            'requireNationalId',
            ['1' => _t('بله، کد ملی الزامی باشد'), '0' => _t('خیر، کد ملی اختیاری')],
            '0',
            _t('الزامی‌بودن کد ملی'),
            _t('اگر «بله» باشد، کاربر باید کد ملی را وارد کند.')
        );
        $form->addInput($requireNationalId);

        $successMsg = new \Typecho\Widget\Helper\Form\Element\Textarea(
            'successMsg',
            null,
            'درخواست رزرو شما با موفقیت ثبت شد. همکاران ما در اولین فرصت با شما تماس می‌گیرند.',
            _t('پیام موفقیت'),
            _t('پیامی که پس از ثبت موفق رزرو به کاربر نمایش داده می‌شود.')
        );
        $form->addInput($successMsg);

        $theme = new \Typecho\Widget\Helper\Form\Element\Radio(
            'pickerTheme',
            [
                'light'  => _t('روشن (حالت روز) — همیشه رنگ روشن'),
                'dark'   => _t('تیره (حالت شب) — همیشه رنگ تیره'),
            ],
            'light',
            _t('حالت رنگ افزونه'),
            _t('تمام بخش‌های افزونه (فرم، فهرست، جزئیات، تقویم و ساعت‌یاب) با این حالت نمایش داده می‌شوند.')
        );
        $form->addInput($theme);

        $workHours = new \Typecho\Widget\Helper\Form\Element\Textarea(
            'workHours',
            null,
            "9-13\n16-20",
            _t('ساعت‌های کاری'),
            _t('هر خط یک بازهٔ زمانی به فرمت «HH-HH». مثلاً «9-13» یعنی صبح ۹ تا ۱۳ و «16-20» یعنی عصر ۱۶ تا ۲۰. این بازه‌ها در انتخاب ساعت نمایش داده می‌شوند.')
        );
        $form->addInput($workHours);

        $holidays = new \Typecho\Widget\Helper\Form\Element\Textarea(
            'holidays',
            null,
            '',
            _t('روزهای تعطیل (تاریخ شمسی)'),
            _t('هر خط یک تاریخ شمسی به فرمت YYYY/MM/DD. مثلاً «1403/06/15». این روزها در تقویم غیرفعال می‌شوند.')
        );
        $form->addInput($holidays);

        $preventDuplicate = new \Typecho\Widget\Helper\Form\Element\Radio(
            'preventDuplicate',
            ['1' => _t('بله، ساعت‌های رزروشده غیرفعال شوند'), '0' => _t('خیر، امکان ثبت تکراری باشد')],
            '1',
            _t('جلوگیری از رزرو تکراری'),
            _t('اگر برای یک تاریخ+ساعت رزرو تأییدشده یا در انتظار وجود داشته باشد، آن slot در انتخاب ساعت غیرفعال می‌شود.')
        );
        $form->addInput($preventDuplicate);
    }

    public static function personalConfig(\Typecho\Widget\Helper\Form $form)
    {
    }

    /**
     * باکس راهنمای مدیر — بالای صفحهٔ تنظیمات افزونه (بخش مدیریت).
     *
     * این پیام جایگزین باکس bk-info-box شد که پیش‌تر در فرم عمومی رزرو
     * (views/form.php) نمایش داده می‌شد و برای همهٔ بازدیدکنندگان — حتی
     * مهمان‌ها — قابل مشاهده بود. اکنون فقط مدیر در تنظیمات افزونه آن را می‌بیند.
     *
     * توجه: نشانی فرم رزرو با گریز امن (self::e) فرار داده می‌شود؛ کد نمونهٔ
     * پیوند عمداً به‌صورت موجودیت HTML ساخته می‌شود تا در صفحه نمایش یابد.
     */
    private static function adminGuideNote(): \Typecho\Widget\Helper\Layout
    {
        $formUrl = self::formUrl();

        $icon = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor"'
            . ' stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
            . '<circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line>'
            . '<line x1="12" y1="8" x2="12.01" y2="8"></line></svg>';

        $html = '<span class="bk-admin-note-icon">' . $icon . '</span>'
            . '<div class="bk-admin-note-body">'
            . '<strong>توجه مدیر سایت:</strong> '
            . 'نشانی فرم رزرو نوبت: <code>' . self::e($formUrl) . '</code> — '
            . 'برای نمایش پیوند «رزرو نوبت» در منوی اصلی پوسته، کد زیر را در فایل منو (مثلاً <code>header.php</code>) قرار دهید: '
            . '<br><code class="bk-admin-note-code">&lt;a href="' . self::e($formUrl) . '"&gt;رزرو نوبت&lt;/a&gt;</code>'
            . '</div>';

        $note = new \Typecho\Widget\Helper\Layout('div', ['class' => 'bk-admin-note', 'role' => 'note']);
        $note->html($html);
        return $note;
    }

    /**
     * استایل باکس راهنمای مدیر — هم‌راستا با طراحی بخش مدیریت TypeRenew
     * (از متغیرهای CSS خود پنل مدیریت استفاده می‌کند تا با حالت روشن/تیره هماهنگ بماند).
     */
    private static function adminGuideStyle(): \Typecho\Widget\Helper\Layout
    {
        $css = <<<'CSS'
.bk-admin-note {
    display: flex; align-items: flex-start; gap: 10px;
    margin: 0 0 18px; padding: 12px 14px;
    background: var(--tr-accent-soft);
    border: 1px solid rgb(var(--tr-accent-rgb) / 0.35);
    border-radius: var(--tr-radius);
    color: var(--tr-text-1);
    font-size: 13.5px; line-height: 2;
}
.bk-admin-note-icon {
    flex-shrink: 0; color: var(--tr-accent);
    line-height: 0; padding-top: 7px;
}
.bk-admin-note-body { flex: 1; min-width: 0; }
.bk-admin-note-body strong { color: var(--tr-accent-strong); }
.bk-admin-note code {
    direction: ltr; unicode-bidi: embed;
    background: var(--tr-surface);
    border: 1px solid var(--tr-border);
    border-radius: 6px; padding: 1px 8px;
    font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    font-size: 12px; word-break: break-all;
}
.bk-admin-note .bk-admin-note-code {
    display: inline-block; margin-top: 4px; user-select: all;
}
CSS;

        $style = new \Typecho\Widget\Helper\Layout('style');
        $style->html($css);
        return $style;
    }

    // ====================================================================
    //  ابزارهای مشترک
    // ====================================================================

    /**
     * خواندن تنظیمات افزونه با مقدار پیش‌فرض
     */
    public static function opt(string $key, $default = '')
    {
        try {
            $options = Options::alloc()->plugin('Booking');
            $value = $options->{$key};
            return ($value === null || $value === '') ? $default : $value;
        } catch (\Throwable $e) {
            return $default;
        }
    }

    /**
     * نوشتهٔ پشتیبان رزروها (یا null) — کش‌شده در طول درخواست
     */
    public static function getBookingPost(): ?array
    {
        if (self::$postCache !== null) {
            return self::$postCache;
        }
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('cid', 'authorId', 'allowComment', 'status', 'title')
                    ->from('table.contents')
                    ->where('slug = ? AND type = ?', self::POST_SLUG, 'post')
                    ->limit(1)
            );
            self::$postCache = $row ?: null;
        } catch (\Throwable $e) {
            self::$postCache = null;
        }
        return self::$postCache;
    }

    /**
     * ساخت نوشتهٔ پشتیبان رزروها (پنهان؛ فقط برای چسباندن دیدگاه‌ها)
     */
    public static function createBookingPost(): array
    {
        $db = Db::get();

        try {
            $user = User::alloc();
            $uid = ($user->hasLogin() && $user->uid) ? (int) $user->uid : 1;
        } catch (\Throwable $e) {
            $uid = 1;
        }

        $now = time();

        $cid = (int) $db->query($db->insert('table.contents')->rows([
            'title'        => 'آرشیو رزروها',
            'slug'         => self::POST_SLUG,
            'created'      => $now,
            'modified'     => $now,
            'text'         => '<!--booking-archive-->آرشیو رزروهای سایت. این نوشته پشتیبان افزونه رزرو است و نمایش عمومی ندارد.',
            'order'        => 0,
            'authorId'     => $uid,
            'template'     => null,
            'type'         => 'post',
            'status'       => 'hidden',
            'password'     => null,
            'commentsNum'  => 0,
            'allowComment' => 1,
            'allowPing'    => 0,
            'allowFeed'    => 0,
            'parent'       => 0,
        ]));

        // پیوند با دستهٔ پیش‌فرض
        try {
            $defaultMid = (int) ($db->fetchRow(
                $db->select('mid')->from('table.metas')
                    ->where('type = ? AND parent = ?', 'category', 0)
                    ->order('mid', Db::SORT_ASC)->limit(1)
            )['mid'] ?? 0);
            if ($defaultMid > 0) {
                $db->query($db->insert('table.relationships')->rows([
                    'cid' => $cid,
                    'mid' => $defaultMid,
                ]));
            }
        } catch (\Throwable $e) {
            // بدون دسته هم کار می‌کند
        }

        self::$postCache = [
            'cid'          => $cid,
            'authorId'     => $uid,
            'allowComment' => 1,
            'status'       => 'hidden',
            'title'        => 'آرشیو رزروها',
        ];
        return self::$postCache;
    }

    /** نشانی فرم رزرو */
    public static function formUrl(): string
    {
        return Router::url(self::ROUTE_FORM, [], Options::alloc()->index);
    }

    /** نشانی فهرست رزروها (برای اعضا) */
    public static function listUrl(): string
    {
        return Router::url(self::ROUTE_LIST, [], Options::alloc()->index);
    }

    /** نشانی صفحهٔ جزئیات یک رزرو */
    public static function detailUrl(int $coid): string
    {
        return Router::url(self::ROUTE_DETAIL, ['coid' => $coid], Options::alloc()->index);
    }

    /** نشانی اکشن ثبت و مدیریت رزرو */
    public static function postUrl(): string
    {
        return Router::url('do', ['action' => self::ACTION_NAME], Options::alloc()->index);
    }

    /** گریز امن خروجی */
    public static function e($str): string
    {
        return htmlspecialchars((string) $str, ENT_QUOTES, 'UTF-8');
    }

    /** تبدیل ارقام به فارسی */
    public static function faDigits($str): string
    {
        return strtr((string) $str, [
            '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
            '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
        ]);
    }

    /** خروجی JSON و پایان اجرا */
    public static function jsonOut(array $payload): void
    {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        echo json_encode($payload, JSON_UNESCAPED_UNICODE);
        exit;
    }

    /** تبدیل ارقام فارسی/عربی به انگلیسی */
    public static function toEnglishDigits(string $s): string
    {
        return strtr($s, [
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
        ]);
    }

    // (توابع services / serviceLabel / serviceIcon در نسخهٔ ۱.۱.۰ حذف شدند —
    //  فیلد «نوع خدمت» دیگر در فرم رزرو پرسیده نمی‌شود.)

    /** گریز از نویسه‌های ویژه LIKE در SQL (\, %, _) */
    public static function likeEscape(string $kw): string
    {
        return addcslashes($kw, "\\%_");
    }

    /**
     * حالت رنگ افزونه را برمی‌گرداند: 'light' | 'dark'
     * از تنظیمات افزونه خوانده می‌شود (پیش‌فرض: light).
     */
    public static function pickerTheme(): string
    {
        $t = (string) self::opt('pickerTheme', 'light');
        return in_array($t, ['light', 'dark'], true) ? $t : 'light';
    }

    /**
     * بازه‌های ساعت کاری را برمی‌گرداند: آرایه‌ای از [start, end] (عدد ساعت).
     * مثلاً [[9, 13], [16, 20]].
     */
    public static function workHours(): array
    {
        $raw = (string) self::opt('workHours', "9-13\n16-20");
        $out = [];
        foreach (explode("\n", $raw) as $line) {
            $line = trim(self::toEnglishDigits($line));
            if ($line === '' || !str_contains($line, '-')) {
                continue;
            }
            $parts = explode('-', $line, 2);
            $start = (int) trim($parts[0]);
            $end = (int) trim($parts[1]);
            if ($start < 0 || $start > 23 || $end < 0 || $end > 23 || $end <= $start) {
                continue;
            }
            $out[] = [$start, $end];
        }
        if (empty($out)) {
            $out = [[9, 21]];
        }
        return $out;
    }

    /**
     * فهرست روزهای تعطیل را برمی‌گرداند: آرایه‌ای از رشته‌های «YYYY/MM/DD» شمسی.
     */
    public static function holidays(): array
    {
        $raw = (string) self::opt('holidays', '');
        $out = [];
        foreach (explode("\n", $raw) as $line) {
            $line = trim(self::toEnglishDigits($line));
            if ($line === '') {
                continue;
            }
            // نرمال‌سازی به YYYY/MM/DD
            $parts = explode('/', $line);
            if (count($parts) !== 3) {
                continue;
            }
            $y = (int) trim($parts[0]);
            $m = (int) trim($parts[1]);
            $d = (int) trim($parts[2]);
            if ($y < 1300 || $y > 1700 || $m < 1 || $m > 12 || $d < 1 || $d > 31) {
                continue;
            }
            $out[] = sprintf('%04d/%02d/%02d', $y, $m, $d);
        }
        return array_values(array_unique($out));
    }

    /** آیا تاریخ شمسی داده‌شده تعطیل است؟ */
    public static function isHoliday(string $jalaliDate): bool
    {
        $normalized = self::normalizeJalaliDate($jalaliDate);
        if ($normalized === '') {
            return false;
        }
        return in_array($normalized, self::holidays(), true);
    }

    /** نرمال‌سازی تاریخ شمسی به YYYY/MM/DD یا '' اگر نامعتبر است */
    public static function normalizeJalaliDate(string $date): string
    {
        $date = self::toEnglishDigits(trim($date));
        $date = str_replace(['.', '-'], '/', $date);
        $parts = explode('/', $date);
        if (count($parts) !== 3) {
            return '';
        }
        $y = (int) trim($parts[0]);
        $m = (int) trim($parts[1]);
        $d = (int) trim($parts[2]);
        if ($y < 1300 || $y > 1700 || $m < 1 || $m > 12 || $d < 1 || $d > 31) {
            return '';
        }
        return sprintf('%04d/%02d/%02d', $y, $m, $d);
    }

    /**
     * ساعت‌های رزرو شده برای یک تاریخ شمسی را برمی‌گرداند.
     * فقط رزروهای با وضعیت waiting یا approved.
     * @return string[] آرایه‌ای از HH:MM
     */
    public static function bookedSlotsForDate(string $jalaliDate): array
    {
        $normalized = self::normalizeJalaliDate($jalaliDate);
        if ($normalized === '') {
            return [];
        }
        try {
            $post = self::getBookingPost();
            if (!$post) {
                return [];
            }
            $cid = (int) $post['cid'];
            $db = Db::get();
            // واکشی همهٔ رزروها (دیدگاه‌های سطح‌بالا با parent=0)
            $rows = $db->fetchAll(
                $db->select('text', 'status')->from('table.comments')
                    ->where('cid = ? AND parent = 0 AND type = ? AND status IN (?, ?)',
                        $cid, 'comment', 'waiting', 'approved')
            );
            $slots = [];
            foreach ($rows as $r) {
                $payload = self::decodePayload((string) $r['text']);
                $date = self::normalizeJalaliDate((string) ($payload['preferred_date'] ?? ''));
                $time = trim((string) ($payload['preferred_time'] ?? ''));
                if ($date === $normalized && $time !== '') {
                    // نرمال‌سازی ساعت به HH:MM
                    $t = self::normalizeTime($time);
                    if ($t !== '') {
                        $slots[] = $t;
                    }
                }
            }
            return array_values(array_unique($slots));
        } catch (\Throwable $e) {
            return [];
        }
    }

    /** نرمال‌سازی ساعت به HH:MM یا '' */
    public static function normalizeTime(string $time): string
    {
        $time = self::toEnglishDigits(trim($time));
        if (!preg_match('/^(\d{1,2}):(\d{2})$/', $time, $m)) {
            return '';
        }
        $h = (int) $m[1];
        $min = (int) $m[2];
        if ($h < 0 || $h > 23 || $min < 0 || $min > 59) {
            return '';
        }
        return sprintf('%02d:%02d', $h, $min);
    }

    /** آیا جلوگیری از رزرو تکراری فعال است؟ */
    public static function preventDuplicate(): bool
    {
        return self::opt('preventDuplicate', '1') !== '0';
    }

    // ====================================================================
    //  مدیریت دسترسی
    // ====================================================================

    /** آیا بازدیدکنندهٔ فعلی اجازهٔ دیدن و مدیریت رزروها را دارد؟ */
    public static function canManage(): bool
    {
        try {
            $user = User::alloc();
            if (!$user->hasLogin()) {
                return false;
            }
            // administrator و editor به‌طور پیش‌فرض اجازه دارند
            if ($user->pass('editor', true)) {
                return true;
            }
            return false;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** آیا کاربر واردشده است؟ */
    public static function isLoggedIn(): bool
    {
        try {
            return User::alloc()->hasLogin();
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** شناسهٔ کاربر فعلی (یا ۰) */
    public static function currentUid(): int
    {
        try {
            $user = User::alloc();
            return $user->hasLogin() ? (int) $user->uid : 0;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /** نام نمایشی کاربر فعلی */
    public static function currentName(): string
    {
        try {
            $user = User::alloc();
            return $user->hasLogin() ? (string) ($user->screenName ?: $user->name) : '';
        } catch (\Throwable $e) {
            return '';
        }
    }

    // ====================================================================
    //  تبدیل و ذخیرهٔ اطلاعات رزرو
    // ====================================================================

    /**
     * تبدیل آرایهٔ اطلاعات رزرو به متن قابل ذخیره در فیلد text.
     * ساختار: <!--booking-->{json}
     */
    public static function encodePayload(array $data): string
    {
        $clean = [];
        foreach ($data as $k => $v) {
            $clean[$k] = is_string($v) ? trim($v) : $v;
        }
        return self::TEXT_MARKER . json_encode($clean, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    /**
     * بازیابی آرایهٔ اطلاعات رزرو از فیلد text.
     * اگر متن با نشانگر شروع نشود، یک آرایهٔ خالی برمی‌گرداند.
     */
    public static function decodePayload(string $text): array
    {
        if (!str_starts_with($text, self::TEXT_MARKER)) {
            return [];
        }
        $json = substr($text, strlen(self::TEXT_MARKER));
        $arr = json_decode($json, true);
        return is_array($arr) ? $arr : [];
    }

    /**
     * خلاصهٔ کوتاه برای نمایش در فهرست — از روی متن رزرو.
     */
    public static function summary(string $text, int $max = 80): string
    {
        $payload = self::decodePayload($text);
        $desc = trim((string) ($payload['description'] ?? ''));
        if ($desc === '') {
            $desc = trim((string) ($payload['note'] ?? ''));
        }
        $desc = preg_replace('/\s+/u', ' ', $desc);
        if (mb_strlen($desc) > $max) {
            $desc = mb_substr($desc, 0, $max) . '…';
        }
        return $desc;
    }

    // ====================================================================
    //  وضعیت رزرو
    // ====================================================================

    /** برچسب فارسی وضعیت */
    public static function statusLabel(string $status): string
    {
        return match ($status) {
            'waiting'  => 'در انتظار بررسی',
            'approved' => 'تأیید شد',
            'spam'     => 'رد شد',
            default    => $status,
        };
    }

    /** کلاس CSS وضعیت برای نشان رنگی */
    public static function statusClass(string $status): string
    {
        return match ($status) {
            'waiting'  => 'bk-status-waiting',
            'approved' => 'bk-status-approved',
            'spam'     => 'bk-status-rejected',
            default    => 'bk-status-other',
        };
    }

    /** آیا این دیدگاه یک رزرو است؟ */
    public static function isReservation(array $row): bool
    {
        $text = (string) ($row['text'] ?? '');
        return str_starts_with($text, self::TEXT_MARKER);
    }

    /** آیا این دیدگاه یک یادداشت داخلی است؟ (فرزند یک رزرو با authorId>0) */
    public static function isNote(array $row): bool
    {
        return (int) ($row['parent'] ?? 0) > 0
            && (int) ($row['authorId'] ?? 0) > 0;
    }

    // ====================================================================
    //  کوئری‌های رزرو
    // ====================================================================

    /** تعداد کل رزروها (مستقل از وضعیت) */
    public static function totalCount(): int
    {
        try {
            $post = self::getBookingPost();
            if (!$post) {
                return 0;
            }
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select(['COUNT(coid)' => 'n'])->from('table.comments')
                    ->where('cid = ? AND parent = 0 AND type = ?', (int) $post['cid'], 'comment')
            );
            return (int) ($row['n'] ?? 0);
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /** تعداد رزروهای در انتظار */
    public static function pendingCount(): int
    {
        try {
            $post = self::getBookingPost();
            if (!$post) {
                return 0;
            }
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select(['COUNT(coid)' => 'n'])->from('table.comments')
                    ->where('cid = ? AND parent = 0 AND status = ? AND type = ?', (int) $post['cid'], 'waiting', 'comment')
            );
            return (int) ($row['n'] ?? 0);
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /** تعداد رزروهای تأییدشده */
    public static function approvedCount(): int
    {
        try {
            $post = self::getBookingPost();
            if (!$post) {
                return 0;
            }
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select(['COUNT(coid)' => 'n'])->from('table.comments')
                    ->where('cid = ? AND parent = 0 AND status = ? AND type = ?', (int) $post['cid'], 'approved', 'comment')
            );
            return (int) ($row['n'] ?? 0);
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /** تعداد رزروهای ردشده */
    public static function rejectedCount(): int
    {
        try {
            $post = self::getBookingPost();
            if (!$post) {
                return 0;
            }
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select(['COUNT(coid)' => 'n'])->from('table.comments')
                    ->where('cid = ? AND parent = 0 AND status = ? AND type = ?', (int) $post['cid'], 'spam', 'comment')
            );
            return (int) ($row['n'] ?? 0);
        } catch (\Throwable $e) {
            return 0;
        }
    }

    // ====================================================================
    //  تاریخ شمسی — همیشه به وقت تهران
    // ====================================================================

    /**
     * DateTimeImmutable با منطقهٔ زمانی Asia/Tehran — مستقل از تنظیمات سرور.
     *
     * تمام نمایش‌های تاریخ و ساعت افزونه (از جمله «تاریخ ثبت» در کارت اطلاعات
     * سیستم صفحهٔ جزئیات) با منطقهٔ زمانی تهران محاسبه می‌شوند؛ بنابراین حتی
     * اگر سرور روی UTC یا منطقهٔ دیگری باشد، ساعت‌ها همیشه به وقت ایران‌اند.
     * (ایران از سال ۱۴۰۱ تغییر ساعت ندارد؛ DateTimeZone قواعد تاریخی DST را هم درست رعایت می‌کند.)
     */
    private static function tehran(int $timestamp): \DateTimeImmutable
    {
        static $tz = null;
        try {
            if ($tz === null) {
                $tz = new \DateTimeZone('Asia/Tehran');
            }
            return (new \DateTimeImmutable('@' . $timestamp))->setTimezone($tz);
        } catch (\Throwable $e) {
            return new \DateTimeImmutable('@' . $timestamp);
        }
    }

    /** میلادی → جلالی (الگوریتم استاندارد) */
    private static function gregorianToJalali(int $gy, int $gm, int $gd): array
    {
        $g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
        $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
        $days = 355666 + (365 * $gy) + ((int) (($gy2 + 3) / 4)) - ((int) (($gy2 + 99) / 100))
            + ((int) (($gy2 + 399) / 400)) + $gd + $g_d_m[$gm - 1];
        $jy = -1595 + (33 * ((int) ($days / 12053)));
        $days %= 12053;
        $jy += 4 * ((int) ($days / 1461));
        $days %= 1461;
        if ($days > 365) {
            $jy += (int) (($days - 1) / 365);
            $days = ($days - 1) % 365;
        }
        if ($days < 186) {
            $jm = 1 + (int) ($days / 31);
            $jd = 1 + ($days % 31);
        } else {
            $jm = 7 + (int) (($days - 186) / 30);
            $jd = 1 + (($days - 186) % 30);
        }
        return [$jy, $jm, $jd];
    }

    /**
     * تبدیل timestamp به تاریخ شمسی خوانا — همیشه به وقت تهران.
     *
     * پیاده‌سازی کاملاً خودکفا: اجزای میلادی از DateTime منطقهٔ تهران خوانده و
     * با الگوریتم استاندارد به جلالی تبدیل می‌شوند؛ هیچ وابستگی به منطقهٔ
     * زمانی سرور یا افزونهٔ JalaliDate (که ساعت را به وقت سرور می‌دهد) ندارد.
     *
     * توکن‌های پشتیبانی‌شده: Y y m n d j F H i
     * خروجی با ارقام لاتین است تا برای تنظیمات Date Picker هم قابل‌استفاده باشد؛
     * نمایش‌های کاربر در قالب‌ها با faDigits() فارسی می‌شوند.
     */
    public static function jalaliDate(int $timestamp, string $format = 'Y/m/d H:i'): string
    {
        if ($timestamp <= 0) {
            return '';
        }
        $dt = self::tehran($timestamp);
        [$jy, $jm, $jd] = self::gregorianToJalali(
            (int) $dt->format('Y'),
            (int) $dt->format('n'),
            (int) $dt->format('j')
        );

        $out = $format;
        $out = str_replace('Y', (string) $jy, $out);
        $out = str_replace('y', substr((string) $jy, -2), $out);
        $out = str_replace('m', str_pad((string) $jm, 2, '0', STR_PAD_LEFT), $out);
        $out = str_replace('n', (string) $jm, $out);
        $out = str_replace('d', str_pad((string) $jd, 2, '0', STR_PAD_LEFT), $out);
        $out = str_replace('j', (string) $jd, $out);
        $out = str_replace('F', self::J_MONTHS[$jm], $out);
        $out = str_replace('H', $dt->format('H'), $out);
        $out = str_replace('i', $dt->format('i'), $out);
        return $out;
    }

    /** فقط تاریخ (بدون ساعت) */
    public static function jalaliDay(int $timestamp): string
    {
        return self::jalaliDate($timestamp, 'Y/m/d');
    }

    /** فقط ساعت */
    public static function jalaliTime(int $timestamp): string
    {
        return self::jalaliDate($timestamp, 'H:i');
    }

    /** نمایش «نسبی» زمان — «چند دقیقه پیش» و مانند آن */
    public static function relativeTime(int $timestamp): string
    {
        if ($timestamp <= 0) {
            return '';
        }
        $diff = time() - $timestamp;
        if ($diff < 60) {
            return 'هم‌اکنون';
        }
        if ($diff < 3600) {
            $m = (int) floor($diff / 60);
            return self::faDigits($m) . ' دقیقه پیش';
        }
        if ($diff < 86400) {
            $h = (int) floor($diff / 3600);
            return self::faDigits($h) . ' ساعت پیش';
        }
        if ($diff < 604800) {
            $d = (int) floor($diff / 86400);
            return self::faDigits($d) . ' روز پیش';
        }
        return self::jalaliDay($timestamp);
    }

    /** تاریخ امروز به شمسی — برای placeholder فرم */
    public static function todayJalali(): string
    {
        return self::jalaliDay(time());
    }

    // ====================================================================
    //  ابزارهای اعتبارسنجی
    // ====================================================================

    /** آیا شماره تلفن معتبر است؟ (ایران: ۰۹XXXXXXXXX یا ۹XXXXXXXXX یا با کد بین‌المللی) */
    public static function isValidPhone(string $phone): bool
    {
        $phone = trim($phone);
        if ($phone === '') {
            return false;
        }
        // حذف فاصله‌ها، خط تیره و پرانتز
        $clean = preg_replace('/[\s\-\(\)]/', '', $phone);
        // فقط ارقام و علامت +
        if (!preg_match('/^\+?\d+$/', $clean)) {
            return false;
        }
        // حداقل ۷ و حداکثر ۱۵ رقم
        $len = strlen(preg_replace('/\D/', '', $clean));
        return $len >= 7 && $len <= 15;
    }

    /**
     * آیا کد ملی معتبر است؟ (الگوریتم استاندارد ایران)
     *
     * الگوریتم:
     * ۱) کد ملی باید دقیقاً ۱۰ رقم باشد.
     * ۲) رقم کنترل (آخرین رقم) با فرمول زیر محاسبه می‌شود:
     *    جمع حاصل‌ضرب ارقام ۹ تای اول در ضرایب ۱۰ تا ۲، تقسیم بر ۱۱.
     *    اگر باقی‌مانده < ۲ باشد، رقم کنترل همان باقی‌مانده است.
     *    در غیر این صورت، رقم کنترل برابر ۱۱ − باقی‌مانده است.
     * ۳) همهٔ ارقام یکسان (مثل 1111111111) کد ملی معتبر نیستند.
     *
     * منبع: استاندارد سازمان ثبت احوال ایران.
     */
    public static function isValidNationalId(string $id): bool
    {
        $id = self::toEnglishDigits(trim($id));
        if (!preg_match('/^\d{10}$/', $id)) {
            return false;
        }
        // رد کردن کدهای همه‌رقم‌یکسان (مثل 0000000000, 1111111111, ...)
        $unique = count(array_unique(str_split($id)));
        if ($unique === 1) {
            return false;
        }
        $digits = array_map('intval', str_split($id));
        $check = array_pop($digits);
        $sum = 0;
        foreach ($digits as $i => $d) {
            $sum += $d * (10 - $i);
        }
        $rem = $sum % 11;
        $expected = $rem < 2 ? $rem : 11 - $rem;
        return $check === $expected;
    }

    /** نرمال‌سازی شماره تلفن — حذف فاصله و خط تیره */
    public static function normalizePhone(string $phone): string
    {
        return preg_replace('/[\s\-\(\)]/', '', trim($phone));
    }

    // ====================================================================
    //  گزینه‌های عمومی (ext:Booking-* در جدول options)
    // ====================================================================

    /** خواندن یک گزینهٔ متنی از جدول options */
    public static function readOption(string $name): string
    {
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('value')->from('table.options')
                    ->where('name = ?', $name)->limit(1)
            );
            return (string) ($row['value'] ?? '');
        } catch (\Throwable $e) {
            return '';
        }
    }

    /** نوشتن یک گزینهٔ متنی در جدول options */
    public static function writeOption(string $name, string $value): void
    {
        try {
            $db = Db::get();
            $exists = $db->fetchRow(
                $db->select('name')->from('table.options')
                    ->where('name = ?', $name)->limit(1)
            );
            if ($exists) {
                $db->query(
                    $db->update('table.options')->rows(['value' => $value])
                        ->where('name = ?', $name)
                );
            } else {
                $db->query(
                    $db->insert('table.options')
                        ->rows(['name' => $name, 'value' => $value, 'user' => 0])
                );
            }
        } catch (\Throwable $e) {
            // خطا نباید صفحه را بگذراند
        }
    }

    /** حذف یک گزینه از جدول options */
    public static function deleteOption(string $name): void
    {
        try {
            $db = Db::get();
            $db->query(
                $db->delete('table.options')->where('name = ?', $name)
            );
        } catch (\Throwable $e) {
        }
    }

    // ====================================================================
    //  یادداشت‌های داخلی (یادداشت روی رزرو)
    // ====================================================================

    /** یادداشت‌های داخلی یک رزرو (مرتب بر اساس زمان صعودی) */
    public static function notesFor(int $reservationCoid): array
    {
        if ($reservationCoid < 1) {
            return [];
        }
        try {
            $db = Db::get();
            $rows = $db->fetchAll(
                $db->select()->from('table.comments')
                    ->where('parent = ? AND type = ?', $reservationCoid, 'comment')
                    ->order('created', Db::SORT_ASC)
            );
            $out = [];
            foreach ($rows as $r) {
                // یادداشت‌ها دیدگاه‌های فرزند با authorId>0 هستند
                if ((int) ($r['authorId'] ?? 0) > 0) {
                    $out[] = $r;
                }
            }
            return $out;
        } catch (\Throwable $e) {
            return [];
        }
    }

    /** شمار یادداشت‌های یک رزرو */
    public static function noteCount(int $reservationCoid): int
    {
        return count(self::notesFor($reservationCoid));
    }

    // ====================================================================
    //  اعلان ایمیل به مدیر
    // ====================================================================

    /** ارسال ایمیل اعلان به مدیر سایت هنگام ثبت رزرو جدید */
    public static function notifyAdmin(array $reservation): void
    {
        if (self::opt('notifyMail', '1') !== '1') {
            return;
        }
        try {
            // نشانی گیرنده: نشانی تنظیم‌شده در افزونه یا ایمیل پیش‌فرض سایت
            $to = trim((string) self::opt('notifyAddress', ''));
            if ($to === '') {
                $to = (string) (Options::alloc()->adminMail ?? '');
            }
            if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
                return;
            }

            $siteName = (string) (Options::alloc()->title ?? 'سایت');
            $name = trim((string) ($reservation['author'] ?? ''));
            $phone = trim((string) ($reservation['url'] ?? ''));
            $payload = $reservation['payload'] ?? [];
            $date = trim((string) ($payload['preferred_date'] ?? ''));
            $time = trim((string) ($payload['preferred_time'] ?? ''));
            $desc = trim((string) ($payload['description'] ?? ''));
            $link = self::detailUrl((int) $reservation['coid']);

            $subject = '[رزرو جدید] ' . $name;

            $text = "رزرو جدیدی ثبت شد.\n\n"
                . "نام: {$name}\n"
                . "تلفن: {$phone}\n";
            if ($date !== '') {
                $text .= "تاریخ پیشنهادی: {$date}\n";
            }
            if ($time !== '') {
                $text .= "ساعت پیشنهادی: {$time}\n";
            }
            if (!empty($payload['mail'])) {
                $text .= "ایمیل: {$payload['mail']}\n";
            }
            if (!empty($payload['national_id'])) {
                $text .= "کد ملی: {$payload['national_id']}\n";
            }
            if (!empty($payload['age'])) {
                $text .= "سن: {$payload['age']}\n";
            }
            if (!empty($payload['gender'])) {
                $text .= "جنسیت: {$payload['gender']}\n";
            }
            if ($desc !== '') {
                $text .= "\nتوضیحات:\n{$desc}\n";
            }
            $text .= "\nبرای مشاهده و مدیریت رزرو:\n{$link}\n";

            // نسخهٔ HTML ساده
            $html = '<div dir="rtl" style="font-family:Tahoma,sans-serif;direction:rtl;text-align:right;">'
                . '<h2 style="color:#4f46e5;">رزرو جدید ثبت شد</h2>'
                . '<p><strong>نام:</strong> ' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '</p>'
                . '<p><strong>تلفن:</strong> ' . htmlspecialchars($phone, ENT_QUOTES, 'UTF-8') . '</p>';
            if ($date !== '') {
                $html .= '<p><strong>تاریخ پیشنهادی:</strong> ' . htmlspecialchars($date, ENT_QUOTES, 'UTF-8') . '</p>';
            }
            if ($time !== '') {
                $html .= '<p><strong>ساعت پیشنهادی:</strong> ' . htmlspecialchars($time, ENT_QUOTES, 'UTF-8') . '</p>';
            }
            if ($desc !== '') {
                $html .= '<p><strong>توضیحات:</strong><br>' . nl2br(htmlspecialchars($desc, ENT_QUOTES, 'UTF-8')) . '</p>';
            }
            $html .= '<hr><p><a href="' . htmlspecialchars($link, ENT_QUOTES, 'UTF-8') . '">مشاهده و مدیریت رزرو</a></p>'
                . '</div>';

            // استفاده از سیستم ایمیل TypeRenew (Typecho\Mail\Queue)
            if (class_exists('\Typecho\Mail\Message') && class_exists('\Typecho\Mail\Queue')) {
                $from = (string) (Options::alloc()->mailFrom ?? $to);
                if ($from === '') {
                    $from = 'noreply@' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
                }
                $message = new \Typecho\Mail\Message(
                    $to,        // to
                    $subject,   // subject
                    $html,      // html body
                    $from,      // from
                    $siteName,  // fromName
                    $name,      // toName
                    $text       // text body
                );
                \Typecho\Mail\Queue::enqueue('booking', $message, Db::get(), Options::alloc());
            }
        } catch (\Throwable $e) {
            // خطای ایمیل نباید ثبت رزرو را متوقف کند
        }
    }

    // ====================================================================
    //  آمار کلی (برای ویجت سایدبار)
    // ====================================================================

    /** آمار کلی رزروها */
    public static function stats(): array
    {
        return [
            'total'    => self::totalCount(),
            'pending'  => self::pendingCount(),
            'approved' => self::approvedCount(),
            'rejected' => self::rejectedCount(),
        ];
    }
}
