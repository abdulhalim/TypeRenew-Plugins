<?php
namespace TypechoPlugin\Booking;

use Typecho\Config;
use Typecho\Db;
use Typecho\Widget\Exception as WidgetException;
use Widget\Archive;
use Widget\Options;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * کلاس پایهٔ صفحات رزرو — ویجتی Archiveگونه تا صفحات افزونه با همان
 * پوستهٔ سایت (سرآیه، منو، پابرگ و اسکریپت‌های پوسته) رندر شوند.
 *
 * سازوکار:
 *  - با ارث‌بری از Widget\Archive همهٔ متدهای موردنیاز قالب‌های پوسته
 *    (need، header، footer، is، archiveTitle و…) در دسترس است.
 *  - execute() کوئری محتوای آرشیو هسته را اجرا نمی‌کند؛ در عوض
 *    functions.php پوسته را بار می‌کند (مثل هسته)، themeInit را صدا
 *    می‌زند و سپس داده‌های اختصاصی رزرو را از prepareContext() می‌گیرد.
 *  - renderBookingPage() خروجی را داخل header/footer پوستهٔ فعلی سایت می‌ریزد.
 *
 * @package Booking
 */
abstract class BookingPage extends Archive
{
    /** داده‌های قالب — توسط prepareContext() پر می‌شود */
    protected ?array $bookingContext = null;

    protected function initComponents(int &$components)
    {
        $components = self::INIT_OPTIONS | self::INIT_USER | self::INIT_SECURITY;
    }

    protected function initParameter(Config $parameter)
    {
        try {
            parent::initParameter($parameter);
        } catch (WidgetException $e) {
            $parameter->setDefault(['pageSize' => 20, 'type' => 'booking']);
            $this->setThemeDir(
                rtrim((string) $this->options->themeFile((string) $this->options->theme), '/') . '/'
            );
        }
    }

    public function execute()
    {
        if ($this->bookingContext !== null) {
            return; // idempotent
        }

        // بارگذاری functions.php پوستهٔ فعلی — همانند Archive::execute هسته
        $functionsFile = (string) $this->getThemeDir() . 'functions.php';
        if (file_exists($functionsFile)) {
            try {
                require_once $functionsFile;
                if (function_exists('themeInit')) {
                    themeInit($this);
                }
            } catch (\Throwable $e) {
                // اگر themeInit بیندازد، هسته نمی‌بلعد — پس خودمان می‌بلعیم
            }
        }

        // فرادادهٔ آرشیو (عنوان/توضیح/پیوندها)
        $this->setupArchiveMeta();

        // داده‌های اختصاصی صفحه
        $this->bookingContext = $this->prepareContext();
    }

    /**
     * فرادادهٔ آرشیو برای سرآیهٔ پوسته
     */
    protected function setupArchiveMeta(): void
    {
        $this->setArchiveType('booking');
        $this->setArchiveSlug('');
        $this->setArchiveTitle($this->pageTitle());
        $this->setArchiveDescription($this->pageDescription());
        $this->setArchiveKeywords((string) $this->options->keywords);
        $this->setArchiveUrl($this->pageUrl());
        // سه ویژگی تایپ‌شدهٔ string باید حتماً مقداردهی شوند تا header() خطا ندهد
        $this->setArchiveFeedUrl((string) $this->options->feedUrl);
        $this->setArchiveFeedRssUrl((string) $this->options->feedRssUrl);
        $this->setArchiveFeedAtomUrl((string) $this->options->feedAtomUrl);
    }

    /** عنوان صفحه (برای <title> و سرآیه) */
    abstract protected function pageTitle(): string;

    /** توضیح صفحه (برای meta description) */
    abstract protected function pageDescription(): string;

    /** نشانی canonical صفحهٔ فعلی */
    abstract protected function pageUrl(): string;

    /**
     * داده‌های موردنیاز قالب — هر زیرکلاس کوئری‌های خودش را اجرا می‌کند.
     * استثناهای 404 نیز از همین‌جا پرتاب می‌شوند (پیش از هر خروجی).
     */
    abstract protected function prepareContext(): array;

    /**
     * متغیرهای مشترک همهٔ قالب‌های رزرو
     */
    protected function commonContext(): array
    {
        $post = $this->bookingPost();

        return [
            'post'        => $post,
            'formTitle'   => (string) Plugin::opt('formTitle', 'فرم ثبت رزرو نوبت'),
            'formIntro'   => trim((string) Plugin::opt('formIntro', '')),
            'successMsg'  => trim((string) Plugin::opt('successMsg', 'درخواست رزرو شما با موفقیت ثبت شد.')),
            'token'       => $this->security->getToken($this->request->getRequestUrl()),
            'postUrl'     => Plugin::postUrl(),
            'formUrl'     => Plugin::formUrl(),
            'listUrl'     => Plugin::listUrl(),
            'hasLogin'    => Plugin::isLoggedIn(),
            'canManage'   => Plugin::canManage(),
            'currentUid'  => Plugin::currentUid(),
            'currentName' => Plugin::currentName(),
            'loginUrl'    => (string) $this->options->loginUrl,
            'logoutUrl'   => (string) $this->options->logoutUrl,
            'todayJalali' => Plugin::todayJalali(),
            'pickerTheme' => Plugin::pickerTheme(),
            // (services در نسخهٔ ۱.۱.۰ حذف شد)
            'stats'       => Plugin::stats(),
            'banner'      => $this->statusBanner(),
        ];
    }

    /**
     * نوار اعلان برای اعضای واردشده — نشان‌دهندهٔ تعداد رزروهای در انتظار
     */
    protected function statusBanner(): ?array
    {
        if (!Plugin::canManage()) {
            return null;
        }
        $pending = Plugin::pendingCount();
        if ($pending <= 0) {
            return null;
        }
        return [
            Plugin::faDigits($pending) . ' رزرو در انتظار بررسی — در فهرست رزروها بررسی کنید',
            'pending',
        ];
    }

    /**
     * رندر نهایی: خروجی قالب را داخل پوستهٔ سایت می‌نشاند
     *
     * @param string $view نام فایل قالب داخل views/
     */
    protected function renderBookingPage(string $view): void
    {
        $this->execute();

        $context = $this->bookingContext;
        extract($context, EXTR_SKIP);

        ob_start();
        require __DIR__ . '/views/' . $view;
        $body = (string) ob_get_clean();

        $pluginUrl = rtrim((string) $this->options->pluginUrl, '/') . '/Booking';
        $assetBase = Plugin::e($pluginUrl) . '/assets';
        $v = Plugin::e(Plugin::VERSION);

        // کلاس حالت تاریک/روشن برای bk-main (و picker‌ها که داخل body اضافه می‌شوند)
        $theme = Plugin::pickerTheme();
        $themeAttr = $theme === 'auto' ? '' : ' data-bk-theme="' . Plugin::e($theme) . '"';

        $this->need('header.php');

        echo '<link rel="stylesheet" href="' . $assetBase . '/booking.css?v=' . $v . '">' . "\n";
        echo '<div class="bk-main"' . $themeAttr . '>' . "\n" . $body . "\n" . '</div>' . "\n";
        echo '<script src="' . $assetBase . '/booking.js?v=' . $v . '" defer></script>' . "\n";

        $this->need('footer.php');
    }

    // ------------------------------------------------------------------
    //  کوئری‌های مشترک
    // ------------------------------------------------------------------

    /** نوشتهٔ پشتیبان رزروها (خودترمیم) */
    protected function bookingPost(): array
    {
        $post = Plugin::getBookingPost();
        if (empty($post)) {
            $post = Plugin::createBookingPost();
        }
        return $post;
    }
}
