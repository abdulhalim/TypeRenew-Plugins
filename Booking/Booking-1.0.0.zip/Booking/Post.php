<?php
namespace TypechoPlugin\Booking;

use Typecho\Cookie;
use Typecho\Db;
use Typecho\Validate;
use Utils\Helper;
use Widget\ActionInterface;
use Widget\Base\Comments;
use Widget\Feedback;
use Widget\Options;
use Widget\User;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * اکشن ثبت و مدیریت رزرو.
 *
 * حالت‌ها:
 *  - ثبت رزرو جدید (حالت پیش‌فرض، فرم عمومی)
 *  - mode=note    : افزودن یادداشت داخلی به یک رزرو (عضو)
 *  - mode=approve : تأیید رزرو (عضو) — status -> approved
 *  - mode=reject  : رد رزرو (عضو) — status -> spam
 *  - mode=delete  : حذف رزرو (عضو) — حذف دیدگاه و یادداشت‌هایش
 *
 * منطق امنیتی همان سازوکار هسته (توکن، فاصلهٔ ارسال، ضداسپم) است.
 *
 * @package Booking
 */
class Post extends Comments implements ActionInterface
{
    public function action()
    {
        if (!$this->request->isPost()) {
            $this->response->redirect(Plugin::formUrl());
        }

        $mode = (string) $this->request->get('mode', '');

        // حالت AJAX: واکشی ساعت‌های گرفته‌شده برای یک تاریخ — عمومی، بدون توکن
        if ($mode === 'booked-slots') {
            $this->handleBookedSlots();
            return;
        }

        // حالت‌های مدیریتی — نیاز به عضو مجاز دارند
        if (in_array($mode, ['note', 'approve', 'reject', 'delete'], true)) {
            if (!Plugin::canManage()) {
                $this->response->redirect(
                    (string) $this->options->loginUrl . '?referer=' . rawurlencode(Plugin::listUrl())
                );
            }

            $this->security->protect();

            if ($mode === 'note') {
                $this->handleAddNote();
            } elseif ($mode === 'approve') {
                $this->handleApprove();
            } elseif ($mode === 'reject') {
                $this->handleReject();
            } elseif ($mode === 'delete') {
                $this->handleDelete();
            }
            return;
        }

        // در غیر این صورت: ثبت رزرو جدید (فرم عمومی)
        $this->handleNewReservation();
    }

    /**
     * پاسخ AJAX: ساعت‌های رزروشده برای یک تاریخ شمسی را برمی‌گرداند.
     * فقط اگر جلوگیری از رزرو تکراری فعال باشد.
     */
    private function handleBookedSlots(): void
    {
        $date = (string) $this->request->get('date', '');
        $slots = [];
        $holidays = [];
        $workHours = [];
        $preventDuplicate = Plugin::preventDuplicate();

        if ($preventDuplicate) {
            $slots = Plugin::bookedSlotsForDate($date);
        }

        // اطلاعات ساعت کاری و روزهای تعطیل هم ارسال می‌شود
        foreach (Plugin::workHours() as $range) {
            $workHours[] = [$range[0], $range[1]];
        }
        $holidays = Plugin::holidays();

        Plugin::jsonOut([
            'ok' => true,
            'date' => Plugin::normalizeJalaliDate($date),
            'slots' => $slots,
            'workHours' => $workHours,
            'holidays' => $holidays,
            'preventDuplicate' => $preventDuplicate,
        ]);
    }

    // ====================================================================
    //  ثبت رزرو جدید
    // ====================================================================

    private function handleNewReservation(): void
    {
        // توکن امنیتی
        $this->security->enable((bool) $this->options->commentsAntiSpam);
        $this->security->protect();

        // تلهٔ اسپم (فیلد پنهان که ربات‌ها پر می‌کنند)
        if (trim((string) $this->request->get('website')) !== '') {
            $this->response->redirect(Plugin::formUrl());
        }

        $post = Plugin::getBookingPost();
        if (empty($post)) {
            $post = Plugin::createBookingPost();
        }
        $cid = (int) $post['cid'];
        $ownerId = (int) $post['authorId'];

        if ((int) ($post['allowComment'] ?? 1) !== 1) {
            $this->backWithError('closed');
        }

        // فاصلهٔ زمانی ارسال — همان منطق هسته
        if (
            !$this->user->pass('editor', true) && $ownerId !== (int) $this->user->uid &&
            $this->options->commentsPostIntervalEnable
        ) {
            $latest = $this->db->fetchRow(
                $this->db->select('created')->from('table.comments')
                    ->where('cid = ? AND ip = ?', $cid, $this->request->getIp())
                    ->order('created', Db::SORT_DESC)
                    ->limit(1)
            );
            if (
                $latest
                && $this->options->time - (int) $latest['created'] >= 0
                && $this->options->time - (int) $latest['created'] < (int) $this->options->commentsPostInterval
            ) {
                $this->backWithError('interval');
            }
        }

        // خواندن و اعتبارسنجی فیلدها — ارقام فارسی به انگلیسی تبدیل می‌شوند
        $name = trim((string) $this->request->filter('trim')->get('author'));
        $phone = Plugin::normalizePhone(Plugin::toEnglishDigits((string) $this->request->get('phone')));
        $mail = trim((string) $this->request->filter('trim')->get('mail'));
        $preferredDate = Plugin::toEnglishDigits(trim((string) $this->request->get('preferred_date')));
        $preferredTime = Plugin::toEnglishDigits(trim((string) $this->request->get('preferred_time')));
        $description = trim((string) $this->request->get('description'));
        $nationalId = Plugin::toEnglishDigits(trim((string) $this->request->get('national_id')));
        $age = Plugin::toEnglishDigits(trim((string) $this->request->get('age')));
        $gender = trim((string) $this->request->get('gender'));

        // اعتبارسنجی نام
        if ($name === '' || mb_strlen($name) > 150) {
            $this->backWithError('name');
        }

        // اعتبارسنجی شماره تلفن
        if (!Plugin::isValidPhone($phone)) {
            $this->backWithError('phone');
        }

        // اعتبارسنجی ایمیل (اگر پر شده یا الزامی است)
        $requireMail = Plugin::opt('requireMail', '0') === '1';
        if ($mail !== '' && !filter_var($mail, FILTER_VALIDATE_EMAIL)) {
            $this->backWithError('mail');
        }
        if ($requireMail && $mail === '') {
            $this->backWithError('mail');
        }

        // اعتبارسنجی کد ملی (اگر پر شده یا الزامی است)
        $requireNatId = Plugin::opt('requireNationalId', '0') === '1';
        if ($nationalId !== '' && !Plugin::isValidNationalId($nationalId)) {
            $this->backWithError('national');
        }
        if ($requireNatId && $nationalId === '') {
            $this->backWithError('national');
        }

        // نرمال‌سازی تاریخ و ساعت پیشنهادی
        $preferredDate = Plugin::normalizeJalaliDate($preferredDate);
        $preferredTime = Plugin::normalizeTime($preferredTime);

        // اعتبارسنجی تاریخ: نباید در گذشته باشد
        if ($preferredDate !== '') {
            // تبدیل تاریخ شمسی به timestamp برای مقایسه
            $today = Plugin::todayJalali();
            $todayNorm = Plugin::normalizeJalaliDate($today);
            if (strcmp($preferredDate, $todayNorm) < 0) {
                $this->backWithError('past_date');
            }
        }

        // اعتبارسنجی: آیا تاریخ تعطیل است؟
        if ($preferredDate !== '' && Plugin::isHoliday($preferredDate)) {
            $this->backWithError('holiday');
        }

        // اعتبارسنجی: آیا ساعت در بازه کاری است؟
        if ($preferredDate !== '' && $preferredTime !== '') {
            $workRanges = Plugin::workHours();
            $inRange = false;
            foreach ($workRanges as $range) {
                $h = (int) substr($preferredTime, 0, 2);
                $m = (int) substr($preferredTime, 3, 2);
                if ($h >= $range[0] && ($h < $range[1] || ($h === $range[1] && $m === 0))) {
                    // فقط نیم‌ساعتی‌ها قابل قبول هستند
                    if ($m === 0 || $m === 30) {
                        $inRange = true;
                        break;
                    }
                }
            }
            if (!$inRange) {
                $this->backWithError('out_of_hours');
            }
        }

        // اعتبارسنجی: جلوگیری از رزرو تکراری
        if ($preferredDate !== '' && $preferredTime !== '' && Plugin::preventDuplicate()) {
            $booked = Plugin::bookedSlotsForDate($preferredDate);
            if (in_array($preferredTime, $booked, true)) {
                $this->backWithError('taken');
            }
        }

        // برش طولانی‌ها
        $preferredDate = mb_substr($preferredDate, 0, 20);
        $preferredTime = mb_substr($preferredTime, 0, 10);
        $description = mb_substr($description, 0, 2000);
        $nationalId = mb_substr($nationalId, 0, 10);
        $age = mb_substr($age, 0, 5);
        $gender = mb_substr($gender, 0, 20);

        // ساخت payload برای ذخیره در فیلد text
        $payload = [
            'preferred_date'   => $preferredDate,
            'preferred_time'   => $preferredTime,
            'description'      => $description,
            'national_id'      => $nationalId,
            'age'              => $age,
            'gender'           => $gender,
            'mail'             => $mail,
        ];

        // ساخت رکورد دیدگاه
        $comment = [
            'cid'      => $cid,
            'created'  => $this->options->time,
            'agent'    => $this->request->getAgent(),
            'ip'       => $this->request->getIp(),
            'ownerId'  => $ownerId,
            'type'     => 'comment',
            'parent'   => 0,
            'author'   => $name,
            'mail'     => $mail,
            'url'      => $phone, // ذخیرهٔ شماره تلفن در فیلد url (استفادهٔ مجدد)
            'text'     => Plugin::encodePayload($payload),
            'status'   => 'waiting', // هرگز به‌صورت عمومی نمایش داده نمی‌شود
        ];

        // کوکی‌های یادآوری
        $expireAt = time() + 30 * 24 * 3600;
        Cookie::set('__typecho_remember_author', $name, $expireAt);
        if ($mail !== '') {
            Cookie::set('__typecho_remember_mail', $mail, $expireAt);
        }

        // هوک ضداسپم افزونه‌های دیگر (نقطهٔ اتصال Widget\Feedback)
        // این هوک به افزونه‌هایی مثل RenewShield اجازه می‌دهد رزرو را بررسی کنند
        // و در صورت تشخیص اسپم، آن را رد یا به‌روزرسانی کنند.
        $contentWidget = null;
        try {
            $contentWidget = Helper::widgetById('contents', $cid);
        } catch (\Throwable $e) {
            $contentWidget = null;
        }

        try {
            $comment = Feedback::pluginHandle()->filter('comment', $comment, $contentWidget);
        } catch (\Typecho\Exception $e) {
            Cookie::set('__typecho_remember_text', (string) $comment['text']);
            $this->backWithError('spam');
        }

        // ثبت نهایی
        try {
            $commentId = (int) $this->insert($comment);
        } catch (\Throwable $e) {
            $this->backWithError('unknown');
        }

        // فراخوانی هوک پایان ثبت دیدگاه (برای افزونه‌های اعلان، ضداسپم و ...)
        try {
            $this->db->fetchRow($this->select()->where('coid = ?', $commentId)->limit(1), [$this, 'push']);
            Feedback::pluginHandle()->call('finishComment', $this);
        } catch (\Throwable $e) {
            // خطای هوک نباید ثبت رزرو را متوقف کند
        }

        // ارسال ایمیل اعلان به مدیر
        try {
            Plugin::notifyAdmin([
                'coid'    => $commentId,
                'author'  => $name,
                'url'     => $phone,
                'mail'    => $mail,
                'payload' => $payload,
            ]);
        } catch (\Throwable $e) {
            // خطای ایمیل نباید ثبت رزرو را متوقف کند
        }

        // هدایت به صفحهٔ فرم با پیام موفقیت
        $url = Plugin::formUrl() . '?ok=1&name=' . rawurlencode($name);
        $this->response->redirect($url);
    }

    // ====================================================================
    //  افزودن یادداشت داخلی
    // ====================================================================

    private function handleAddNote(): void
    {
        $coid = (int) $this->request->filter('int')->get('coid');
        $text = trim((string) $this->request->get('text'));

        if ($coid < 1) {
            $this->response->redirect(Plugin::listUrl());
        }

        // بررسی وجود رزرو
        $post = Plugin::getBookingPost();
        $cid = (int) ($post['cid'] ?? 0);
        if ($cid < 1) {
            $this->response->redirect(Plugin::listUrl());
        }

        $row = $this->db->fetchRow(
            $this->db->select('coid', 'cid', 'parent', 'type')
                ->from('table.comments')
                ->where('coid = ? AND cid = ? AND parent = 0 AND type = ?', $coid, $cid, 'comment')
                ->limit(1)
        );
        if (!$row) {
            $this->response->redirect(Plugin::listUrl());
        }

        if ($text === '') {
            $this->response->redirect(
                Plugin::detailUrl($coid) . '?err=note_empty'
            );
        }

        if (mb_strlen($text) > 2000) {
            $text = mb_substr($text, 0, 2000);
        }

        $user = User::alloc();
        $note = [
            'cid'      => $cid,
            'created'  => $this->options->time,
            'agent'    => $this->request->getAgent(),
            'ip'       => $this->request->getIp(),
            'ownerId'  => (int) ($post['authorId'] ?? 0),
            'type'     => 'comment',
            'parent'   => $coid, // یادداشتِ فرزندِ رزرو
            'author'   => (string) $user->screenName,
            'mail'     => (string) $user->mail,
            'url'      => (string) $user->url,
            'authorId' => (int) $user->uid,
            'text'     => $text,
            'status'   => 'approved', // یادداشت‌های داخلی همیشه نمایش داده می‌شوند
        ];

        try {
            $this->insert($note);
            $this->response->redirect(
                Plugin::detailUrl($coid) . '?ok=note'
            );
        } catch (\Throwable $e) {
            $this->response->redirect(
                Plugin::detailUrl($coid) . '?err=note_save'
            );
        }
    }

    // ====================================================================
    //  تأیید رزرو
    // ====================================================================

    private function handleApprove(): void
    {
        $coid = (int) $this->request->filter('int')->get('coid');
        if ($coid < 1) {
            $this->response->redirect(Plugin::listUrl());
        }

        $this->updateStatus($coid, 'approved');
        $this->response->redirect(
            Plugin::detailUrl($coid) . '?ok=approve'
        );
    }

    // ====================================================================
    //  رد رزرو
    // ====================================================================

    private function handleReject(): void
    {
        $coid = (int) $this->request->filter('int')->get('coid');
        if ($coid < 1) {
            $this->response->redirect(Plugin::listUrl());
        }

        $this->updateStatus($coid, 'spam');
        $this->response->redirect(
            Plugin::detailUrl($coid) . '?ok=reject'
        );
    }

    // ====================================================================
    //  حذف رزرو
    // ====================================================================

    private function handleDelete(): void
    {
        $coid = (int) $this->request->filter('int')->get('coid');
        if ($coid < 1) {
            $this->response->redirect(Plugin::listUrl());
        }

        try {
            $post = Plugin::getBookingPost();
            $cid = (int) ($post['cid'] ?? 0);

            // حذف یادداشت‌های داخلی این رزو
            $this->db->query(
                $this->db->delete('table.comments')
                    ->where('cid = ? AND parent = ? AND type = ?', $cid, $coid, 'comment')
            );

            // حذف خود رزرو
            $this->db->query(
                $this->db->delete('table.comments')
                    ->where('coid = ? AND cid = ? AND parent = 0', $coid, $cid)
            );

            // به‌روزرسانی شمار دیدگاه‌های نوشتهٔ پشتیبان
            $this->refreshCommentsNum($cid);

            $this->response->redirect(
                Plugin::listUrl() . '?ok=delete'
            );
        } catch (\Throwable $e) {
            $this->response->redirect(
                Plugin::detailUrl($coid) . '?err=delete'
            );
        }
    }

    // ====================================================================
    //  ابزارهای کمکی
    // ====================================================================

    /** به‌روزرسانی وضعیت یک رزرو */
    private function updateStatus(int $coid, string $status): void
    {
        try {
            $post = Plugin::getBookingPost();
            $cid = (int) ($post['cid'] ?? 0);

            $this->db->query(
                $this->db->update('table.comments')
                    ->rows(['status' => $status])
                    ->where('coid = ? AND cid = ? AND parent = 0', $coid, $cid)
            );
        } catch (\Throwable $e) {
            $this->response->redirect(
                Plugin::detailUrl($coid) . '?err=status'
            );
        }
    }

    /** بازگشت به فرم با کد خطا */
    private function backWithError(string $errCode): void
    {
        $url = Plugin::formUrl() . '?err=' . rawurlencode($errCode);
        $this->response->redirect($url);
    }

    /** هدایت امن به URL با حفظ پارامترها */
    private function redirectTo(string $url): void
    {
        $this->response->redirect($url);
    }
}
