<?php
namespace TypechoPlugin\Booking;

use Typecho\Db;
use Typecho\Router;
use Typecho\Widget\Exception as WidgetException;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * صفحهٔ فهرست رزروها — برای اعضای واردشده با دسترسی مدیریت.
 * نشانی: /booking/list
 *
 * اعضا می‌توانند رزروها را بر اساس وضعیت (در انتظار/تأیید/رد) فیلتر کنند،
 * جستجو کنند و روی هر رزرو به صفحهٔ جزئیات بروند.
 *
 * @package Booking
 */
class BookingList extends BookingPage
{
    protected function pageTitle(): string
    {
        $search = $this->searchQuery();
        if ($search !== '') {
            return 'نتایج جستجو برای «' . $search . '»';
        }
        $filter = $this->filterStatus();
        if ($filter !== '') {
            return Plugin::statusLabel($filter) . ' — فهرست رزروها';
        }
        return 'فهرست رزروها';
    }

    protected function pageDescription(): string
    {
        return 'فهرست رزروهای ثبت‌شده در سایت — برای اعضای واردشده.';
    }

    protected function pageUrl(): string
    {
        $page = max(1, (int) ($this->request->get('page') ?: 1));
        $search = $this->searchQuery();
        $filter = $this->filterStatus();
        $url = ($page > 1 || $search !== '' || $filter !== '')
            ? self::pagedUrl($page, $search, $filter)
            : Plugin::listUrl();
        return $url;
    }

    public function render(): void
    {
        // دسترسی‌پذیری: فقط اعضای مجاز
        if (!Plugin::canManage()) {
            // هدایت به صفحه ورود
            $loginUrl = (string) $this->options->loginUrl;
            $this->response->redirect($loginUrl . '?referer=' . rawurlencode(Plugin::listUrl()));
            return;
        }
        $this->renderBookingPage('list.php');
    }

    /** عبارت جستجو از پارامتر q */
    protected function searchQuery(): string
    {
        $q = trim((string) ($this->request->get('q') ?? ''));
        return mb_strlen($q) > 100 ? mb_substr($q, 0, 100) : $q;
    }

    /** فیلتر وضعیت (waiting/approved/spam یا خالی) */
    protected function filterStatus(): string
    {
        $f = (string) $this->request->get('status', '');
        return in_array($f, ['waiting', 'approved', 'spam'], true) ? $f : '';
    }

    protected function prepareContext(): array
    {
        $db = Db::get();
        $post = $this->bookingPost();
        $cid = (int) $post['cid'];

        $pageSize = max(5, min(100, (int) Plugin::opt('pageSize', 20)));
        $page = max(1, (int) ($this->request->get('page') ?: 1));
        $search = $this->searchQuery();
        $status = $this->filterStatus();

        // ساخت شرط کوئری
        $where = ['cid = ? AND parent = 0 AND type = ?'];
        $params = [$cid, 'comment'];
        if ($status !== '') {
            $where[] = 'status = ?';
            $params[] = $status;
        }
        if ($search !== '') {
            // جستجو در author، url (تلفن)، mail و text (که شامل JSON است)
            $like = '%' . Plugin::likeEscape($search) . '%';
            $where[] = '(author LIKE ? OR url LIKE ? OR mail LIKE ? OR text LIKE ?)';
            array_push($params, $like, $like, $like, $like);
        }

        $whereSql = implode(' AND ', $where);

        // شمار کل نتایج
        $countRow = $db->fetchRow(
            $db->select(['COUNT(coid)' => 'n'])->from('table.comments')
                ->where($whereSql, ...$params)
        );
        $total = (int) ($countRow['n'] ?? 0);

        $pages = max(1, (int) ceil($total / $pageSize));
        if ($total > 0 && $page > $pages) {
            throw new WidgetException(_t('صفحهٔ درخواستی وجود ندارد'), 404);
        }

        // واکشی صفحهٔ فعلی
        $rows = $db->fetchAll(
            $db->select()->from('table.comments')
                ->where($whereSql, ...$params)
                ->order('created', Db::SORT_DESC)
                ->page($page, $pageSize)
        );

        // غنی‌سازی ردیف‌ها — باز کردن payload و افزودن شمار یادداشت
        $items = [];
        foreach ($rows as $r) {
            $payload = Plugin::decodePayload((string) $r['text']);
            $items[] = [
                'coid'         => (int) $r['coid'],
                'created'      => (int) $r['created'],
                'author'       => (string) $r['author'],
                'mail'         => (string) $r['mail'],
                'phone'        => (string) $r['url'],
                'ip'           => (string) $r['ip'],
                'status'       => (string) $r['status'],
                'statusLabel'  => Plugin::statusLabel((string) $r['status']),
                'statusClass'  => Plugin::statusClass((string) $r['status']),
                'preferredDate' => (string) ($payload['preferred_date'] ?? ''),
                'preferredTime' => (string) ($payload['preferred_time'] ?? ''),
                'description'  => (string) ($payload['description'] ?? ''),
                'nationalId'   => (string) ($payload['national_id'] ?? ''),
                'age'          => (string) ($payload['age'] ?? ''),
                'gender'       => (string) ($payload['gender'] ?? ''),
                'noteCount'    => Plugin::noteCount((int) $r['coid']),
                'detailUrl'    => Plugin::detailUrl((int) $r['coid']),
                'createdJalali' => Plugin::jalaliDate((int) $r['created']),
                'createdRelative' => Plugin::relativeTime((int) $r['created']),
            ];
        }

        return $this->commonContext() + [
            'items'        => $items,
            'page'         => $page,
            'pages'        => $pages,
            'total'        => $total,
            'search'       => $search,
            'filterStatus' => $status,
            'pendingCount' => Plugin::pendingCount(),
            'approvedCount' => Plugin::approvedCount(),
            'rejectedCount' => Plugin::rejectedCount(),
            'totalCount'   => Plugin::totalCount(),
        ];
    }

    /** نشانی صفحهٔ n از فهرست (با حفظ فیلترها و جستجو) */
    public static function pagedUrl(int $n, string $q = '', string $status = ''): string
    {
        $url = $n <= 1
            ? Plugin::listUrl()
            : Router::url(Plugin::ROUTE_LIST_PAGE, ['page' => $n], \Widget\Options::alloc()->index);

        $params = [];
        if ($q !== '') {
            $params['q'] = rawurlencode($q);
        }
        if ($status !== '') {
            $params['status'] = rawurlencode($status);
        }
        if (!empty($params)) {
            $url .= (str_contains($url, '?') ? '&' : '?') . http_build_query($params);
        }
        return $url;
    }
}
