<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup;

use Typecho\Plugin as Hook;
use Typecho\Plugin\PluginInterface;
use Typecho\Widget\Helper\Form;
use Utils\Helper;
use Utils\NoPersonal;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 *افزونه پشتیبان‌گیری و بازیابی TypeRenew: پشتیبان از دیتابیس و فایل‌ها، بازیابی هوشمند،
 * بکاپ کامل ریشه سایت، بارگذاری فایل پشتیبان، یادداشت نسخه‌ها و مدیریت از پنل اختصاصی.
 * @package SQLiteBackup
 * @author  پوردریایی
 * @link    https://pourdaryaei.ir
 * @version 1.4.0
 * @license GPL-2.0
 */
class Plugin implements PluginInterface
{
    use NoPersonal;

    /**
     * نسخه افزونه.
     */
    public const VERSION = \TypechoPlugin\SQLiteBackup\Core\PluginInfo::VERSION;

    /**
     * نام نمایشی افزونه.
     */
    public const TITLE = \TypechoPlugin\SQLiteBackup\Core\PluginInfo::TITLE;

    /**
     * فعال‌سازی افزونه.
     *
     * @return string پیام نتیجه
     *
     * @throws \RuntimeException در صورت عدم برآورده شدن پیش‌نیازها
     */
    public static function activate(): string
    {
        self::assertRequirements();

        $paths = Core\Paths::class;
        $paths::ensureDirectory($paths::backups());
        $paths::ensureDirectory($paths::sessions());
        $paths::ensureDirectory($paths::logs());

        Settings::ensureStored();

        Helper::removeRoute('sqlite_backup_action');
        Helper::addRoute('sqlite_backup_action', '/action/sqlite-backup', Action::class, 'action');

        Helper::removePanel(1, 'SQLiteBackup/Panel.php');
        Helper::removePanel(3, 'SQLiteBackup/Panel.php');
        Helper::removePanel(4, 'SQLiteBackup/Panel.php');
        Helper::removePanel(5, 'SQLiteBackup/Panel.php');
        Helper::addPanel(
            5,
            'SQLiteBackup/Panel.php',
            self::TITLE,
            'تهیه پشتیبان و بازیابی',
            'administrator',
            false,
            '',
            ['icon' => 'i-archive']
        );

        Helper::lang('SQLiteBackup');

        Core\Logger::success('افزونه تهیه پشتیبان فعال شد', ['version' => self::VERSION]);

        return _t('افزونه تهیه پشتیبان فعال شد؛ پنل مدیریت از منوی «افزونه‌ها» در دسترس است.');
    }

    /**
     * غیرفعال‌سازی افزونه.
     *
     * @return string پیام نتیجه
     */
    public static function deactivate(): string
    {
        Helper::removeRoute('sqlite_backup_action');
        Helper::removePanel(1, 'SQLiteBackup/Panel.php');
        Helper::removePanel(3, 'SQLiteBackup/Panel.php');
        Helper::removePanel(4, 'SQLiteBackup/Panel.php');
        Helper::removePanel(5, 'SQLiteBackup/Panel.php');

        Core\Logger::info('افزونه تهیه پشتیبان غیرفعال شد');

        return _t('افزونه تهیه پشتیبان غیرفعال شد؛ فایل‌های پشتیبان موجود حفظ می‌شوند.');
    }

    /**
     * فرم پیکربندی افزونه.
     *
     * @param Form $form فرم تنظیمات
     *
     * @return void
     */
    public static function config(Form $form)
    {
        $settings = Settings::load();

        $enabled = new Form\Element\Radio(
            'enabled',
            ['1' => _t('فعال'), '0' => _t('غیرفعال')],
            $settings['enabled'],
            _t('وضعیت افزونه'),
            _t('برای ساخت پشتیبان، بازیابی، مدیریت یادداشت نسخه‌ها و مشاهده گزارش‌ها به پنل «تهیه پشتیبان» بروید.')
        );
        $form->addInput($enabled);

        foreach (Settings::defaults() as $key => $default) {
            if ($key === 'enabled') {
                continue;
            }

            $form->addInput(new Form\Element\Hidden($key, null, (string) $settings[$key]));
        }
    }

    /**
     * ادغام تنظیمات فرم پیکربندی با مقادیر ذخیره‌شده.
     *
     * @param array<string,mixed> $settings تنظیمات ارسالی
     * @param bool               $isInit  آیا فراخوانی اولیه است
     *
     * @return void
     */
    public static function configHandle(array $settings, bool $isInit): void
    {
        unset($isInit);

        $current = Settings::load();
        Settings::store(array_merge($current, $settings));
    }

    /**
     * بررسی پیش‌نیازهای اجرای افزونه.
     *
     * @return void
     *
     * @throws \RuntimeException در صورت نبود پیش‌نیاز
     */
    private static function assertRequirements(): void
    {
        if (version_compare(PHP_VERSION, '8.1.0', '<')) {
            throw new \RuntimeException('این افزونه به PHP 8.1 یا بالاتر نیاز دارد؛ نسخه فعال: ' . PHP_VERSION);
        }

        if (!function_exists('openssl_encrypt')) {
            throw new \RuntimeException('افزونه OpenSSL برای رمزنگاری فایل‌های پشتیبان الزامی است');
        }

        if (!Zip\ZipEngine::isSupported()) {
            throw new \RuntimeException('افزونه Zlib برای ساخت فایل‌های ZIP الزامی است');
        }

        $database = Service\DatabaseService::info();

        if (!$database['isSqlite']) {
            throw new \RuntimeException(sprintf(
                'این افزونه برای دیتابیس SQLite طراحی شده است؛ دیتابیس فعال سایت (%s) پشتیبانی نمی‌شود',
                $database['adapter']
            ));
        }
    }
}
