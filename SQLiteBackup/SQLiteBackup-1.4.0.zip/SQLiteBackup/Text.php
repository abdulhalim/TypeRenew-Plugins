<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup;

use TypechoPlugin\SQLiteBackup\Core\Clock;
use TypechoPlugin\SQLiteBackup\Core\Jalali;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class Text
{
    /**
     * سازنده خصوصی.
     */
    private function __construct()
    {
    }

    /**
     * گریز از کاراکترهای خاص HTML.
     *
     * @param string|null $value مقدار
     *
     * @return string
     */
    public static function e(?string $value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    /**
     * تبدیل ارقام لاتین به فارسی.
     *
     * @param string|int|float|null $value مقدار
     *
     * @return string
     */
    public static function num(string|int|float|null $value): string
    {
        return Jalali::digits((string) $value);
    }

    /**
     * قالب‌بندی عدد با جداکننده هزارگان و ارقام فارسی.
     *
     * @param int|float $value عدد
     *
     * @return string
     */
    public static function int(int|float $value): string
    {
        return str_replace(',', '٬', self::num(number_format((float) $value)));
    }

    /**
     * قالب‌بندی حجم بایت به شکل خوانای فارسی.
     *
     * @param int $bytes حجم
     *
     * @return string
     */
    public static function size(int $bytes): string
    {
        if ($bytes < 1024) {
            return self::num($bytes) . ' بایت';
        }

        $units = ['کیلوبایت', 'مگابایت', 'گیگابایت', 'ترابایت'];
        $value = (float) $bytes;
        $index = -1;

        do {
            $value /= 1024;
            $index++;
        } while ($value >= 1024 && $index < count($units) - 1);

        $formatted = ($value >= 100 || $value == (int) $value)
            ? self::num((string) (int) round($value))
            : str_replace('.', '٫', self::num(number_format($value, 1, '.', '')));

        return $formatted . ' ' . $units[$index];
    }

    /**
     * قالب‌بندی تاریخ شمسی (۱۴۰۴/۰۷/۰۵ - ۱۴:۳۰) در منطقه زمانی سایت.
     *
     * @param int $timestamp زمان Unix
     *
     * @return string
     */
    public static function date(int $timestamp): string
    {
        if ($timestamp <= 0) {
            return '-';
        }

        return Clock::jalali($timestamp, 'Y/m/d - H:i');
    }

    /**
     * قالب‌بندی تاریخ شمسی با نام ماه (۵ مهر ۱۴۰۴، ساعت ۱۴:۳۰) در منطقه زمانی سایت.
     *
     * @param int $timestamp زمان Unix
     *
     * @return string
     */
    public static function dateFull(int $timestamp): string
    {
        if ($timestamp <= 0) {
            return '-';
        }

        return Clock::jalali($timestamp, 'd n Y، ساعت H:i');
    }

    /**
     * قالب‌بندی مدت زمان به شکل خوانا.
     *
     * @param int $seconds مدت (ثانیه)
     *
     * @return string
     */
    public static function duration(int $seconds): string
    {
        if ($seconds < 60) {
            return self::num($seconds) . ' ثانیه';
        }

        if ($seconds < 3600) {
            return self::num(intdiv($seconds, 60)) . ' دقیقه و ' . self::num($seconds % 60) . ' ثانیه';
        }

        return self::num(intdiv($seconds, 3600)) . ' ساعت و ' . self::num(intdiv($seconds % 3600, 60)) . ' دقیقه';
    }

    /**
     * برش امن متن با پشتیبانی یونیکد.
     *
     * @param string|null $value متن
     * @param int         $max   بیشترین طول
     *
     * @return string
     */
    public static function cut(?string $value, int $max): string
    {
        $value = trim(str_replace("\0", '', (string) $value));

        if ($max <= 0 || $value === '') {
            return '';
        }

        return mb_substr($value, 0, $max, 'UTF-8');
    }
}
