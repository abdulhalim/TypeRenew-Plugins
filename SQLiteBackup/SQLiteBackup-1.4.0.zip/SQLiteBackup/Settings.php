<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup;

use Utils\Helper;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class Settings
{
    /**
     * نام افزونه.
     */
    public const NAME = 'SQLiteBackup';

    /**
     * مقادیر پیش‌فرض تنظیمات.
     *
     * @return array<string,string>
     */
    public static function defaults(): array
    {
        return [
            'enabled'        => '1',
            'retentionCount' => '10',
        ];
    }

    /**
     * بارگذاری تنظیمات ذخیره‌شده همراه با مقادیر پیش‌فرض.
     *
     * @return array<string,string>
     */
    public static function load(): array
    {
        $stored = [];

        try {
            $config = Helper::options()->plugin(self::NAME);
            $stored = is_object($config) && method_exists($config, 'toArray')
                ? (array) $config->toArray()
                : [];
        } catch (\Throwable) {
            $stored = [];
        }

        if (!is_array($stored)) {
            $stored = [];
        }

        return array_merge(self::defaults(), self::normalize($stored));
    }

    /**
     * ذخیره‌سازی تنظیمات اولیه در صورت نبود.
     *
     * @return void
     */
    public static function ensureStored(): void
    {
        $current = self::load();

        try {
            Helper::configPlugin(self::NAME, $current);
        } catch (\Throwable) {
            // در نصب اول ممکن است ردیف پیکربندی هنوز آماده نباشد
        }
    }

    /**
     * ذخیره‌سازی تنظیمات.
     *
     * @param array<string,mixed> $settings تنظیمات جدید
     *
     * @return void
     *
     * @throws \RuntimeException در صورت خطای ذخیره‌سازی
     */
    public static function store(array $settings): void
    {
        $current = self::load();
        $merged = array_merge($current, self::normalize($settings));
        $merged = array_intersect_key($merged, self::defaults());

        Helper::configPlugin(self::NAME, $merged);
    }

    /**
     * اعتبارسنجی و نرمال‌سازی مقادیر ورودی.
     *
     * @param array<string,mixed> $settings تنظیمات ورودی
     *
     * @return array<string,string>
     */
    public static function normalize(array $settings): array
    {
        $out = [];

        foreach ($settings as $key => $value) {
            if (!array_key_exists($key, self::defaults()) || $key === 'enabled') {
                continue;
            }

            $out[$key] = is_scalar($value) ? trim((string) $value) : '';
        }

        if (array_key_exists('enabled', $settings)) {
            $out['enabled'] = self::bool($settings['enabled']);
        }

        if (isset($out['retentionCount'])) {
            $count = (int) $out['retentionCount'];
            $out['retentionCount'] = (string) max(0, min(200, $count));
        }

        return $out;
    }

    /**
     * نشانی صفحه پنل مدیریت.
     *
     * @return string
     */
    public static function panelUrl(): string
    {
        return Helper::url(self::NAME . '/Panel.php');
    }

    /**
     * نشانی یک فایل استاتیک افزونه.
     *
     * @param string $path مسیر نسبی
     *
     * @return string
     */
    public static function assetUrl(string $path): string
    {
        return \Typecho\Common::url(self::NAME . '/' . ltrim($path, '/'), (string) Helper::options()->pluginUrl);
    }

    /**
     * تبدیل مقدار به رشته بولی استاندارد.
     *
     * @param mixed $value مقدار
     *
     * @return string
     */
    private static function bool(mixed $value): string
    {
        return in_array($value, ['1', 1, true, 'on', 'true'], true) ? '1' : '0';
    }
}
