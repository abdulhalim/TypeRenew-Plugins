<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Zip;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

interface ZipWriter
{
    /**
     * آغاز ساخت آرشیو (ایجاد فایل در صورت نبود).
     *
     * @param string                   $path  مسیر فایل ZIP
     * @param array<string,mixed>|null $state وضعیت ذخیره‌شده برای ادامه ساخت
     *
     * @return void
     *
     * @throws ZipException در صورت خطای I/O
     */
    public function begin(string $path, ?array $state = null): void;

    /**
     * افزودن یک فایل از دیسک به آرشیو.
     *
     * @param string $sourcePath مسیر فایل منبع روی دیسک
     * @param string $entryName  نام مدخل داخل آرشیو (با اسلش)
     *
     * @return int تعداد بایت‌های خام افزوده‌شده
     *
     * @throws ZipException در صورت خطای I/O
     */
    public function addFile(string $sourcePath, string $entryName): int;

    /**
     * افزودن محتوای متنی به آرشیو.
     *
     * @param string $entryName نام مدخل داخل آرشیو
     * @param string $content   محتوا
     *
     * @return void
     *
     * @throws ZipException در صورت خطای I/O
     */
    public function addFromString(string $entryName, string $content): void;

    /**
     * بستن آرشیو و نوشتن پوشه مرکزی.
     *
     * @return void
     *
     * @throws ZipException در صورت خطای I/O
     */
    public function finish(): void;

    /**
     * آزادسازی منابع (در صورت وقوع خطا).
     *
     * @return void
     */
    public function abort(): void;
}
