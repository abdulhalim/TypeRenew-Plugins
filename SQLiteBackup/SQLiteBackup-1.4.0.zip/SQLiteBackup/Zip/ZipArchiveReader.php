<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Zip;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class ZipArchiveReader implements ZipReader
{
    /**
     * نمونه ZipArchive.
     *
     * @var \ZipArchive|null
     */
    private ?\ZipArchive $archive = null;

    /**
     * باز کردن فایل ZIP.
     *
     * @param string $path مسیر فایل
     *
     * @return void
     *
     * @throws ZipException در صورت خرابی فایل
     */
    public function open(string $path): void
    {
        if (!class_exists('ZipArchive')) {
            throw new ZipException('افزونه ZipArchive روی سرور فعال نیست');
        }

        if (!is_file($path)) {
            throw new ZipException('فایل ZIP یافت نشد: ' . $path);
        }

        $archive = new \ZipArchive();
        $status = $archive->open($path, \ZipArchive::RDONLY);

        if ($status !== true) {
            throw new ZipException('باز کردن فایل ZIP ناموفق بود (کد ' . $status . ')');
        }

        $this->archive = $archive;
    }

    /**
     * فهرست مدخل‌ها.
     *
     * @return array<int,array{name:string,size:int,method:int,crc:int}>
     *
     * @throws ZipException در صورت خطا
     */
    public function entries(): array
    {
        $archive = $this->requireArchive();
        $entries = [];

        for ($i = 0; $i < $archive->numFiles; $i++) {
            $stat = $archive->statIndex($i);

            if ($stat === false) {
                continue;
            }

            $entries[] = [
                'name'   => (string) $stat['name'],
                'size'   => (int) $stat['size'],
                'method' => (int) ($stat['comp_method'] ?? 0),
                'crc'    => (int) ($stat['crc'] ?? 0),
            ];
        }

        return $entries;
    }

    /**
     * بررسی وجود مدخل.
     *
     * @param string $name نام مدخل
     *
     * @return bool
     */
    public function has(string $name): bool
    {
        $archive = $this->requireArchive();

        return $archive->locateName($name) !== false;
    }

    /**
     * خواندن محتوای مدخل (مدخل‌های کوچک).
     *
     * @param string $name     نام مدخل
     * @param int    $maxBytes بیشترین حجم مجاز
     *
     * @return string
     *
     * @throws ZipException در صورت خطا
     */
    public function readString(string $name, int $maxBytes = 1048576): string
    {
        $archive = $this->requireArchive();
        $index = $archive->locateName($name);

        if ($index === false) {
            throw new ZipException('مدخل در آرشیو یافت نشد: ' . $name);
        }

        $stat = $archive->statIndex($index);

        if ($stat === false || (int) $stat['size'] > $maxBytes) {
            throw new ZipException('حجم مدخل از حد مجاز بیشتر است: ' . $name);
        }

        $content = $archive->getFromIndex($index);

        if ($content === false) {
            throw new ZipException('خواندن مدخل ناموفق بود: ' . $name);
        }

        return $content;
    }

    /**
     * استخراج جریانی یک مدخل با محاسبه SHA-256.
     *
     * @param string $name     نام مدخل
     * @param string $destPath مسیر مقصد
     *
     * @return array{size:int,sha256:string}
     *
     * @throws ZipException در صورت خطا
     */
    public function extractTo(string $name, string $destPath): array
    {
        $archive = $this->requireArchive();
        $index = $archive->locateName($name);

        if ($index === false) {
            throw new ZipException('مدخل در آرشیو یافت نشد: ' . $name);
        }

        $stream = $archive->getStream($name);

        if ($stream === false) {
            throw new ZipException('باز کردن جریان مدخل ناموفق بود: ' . $name);
        }

        $target = fopen($destPath, 'wb');

        if ($target === false) {
            fclose($stream);
            throw new ZipException('ساخت فایل مقصد ناموفق بود: ' . $destPath);
        }

        $hash = hash_init('sha256');
        $size = 0;

        try {
            while (!feof($stream)) {
                $chunk = fread($stream, 1048576);

                if ($chunk === false) {
                    throw new ZipException('خواندن جریان مدخل ناموفق بود: ' . $name);
                }

                if ($chunk === '') {
                    continue;
                }

                hash_update($hash, $chunk);
                $size += strlen($chunk);

                if (fwrite($target, $chunk) === false) {
                    throw new ZipException('نوشتن فایل مقصد ناموفق بود: ' . $destPath);
                }
            }
        } finally {
            fclose($stream);
            fclose($target);
        }

        return [
            'size'   => $size,
            'sha256' => hash_final($hash),
        ];
    }

    /**
     * بستن آرشیو.
     *
     * @return void
     */
    public function close(): void
    {
        if ($this->archive !== null) {
            $this->archive->close();
            $this->archive = null;
        }
    }

    /**
     * دسترسی به آرشیو باز.
     *
     * @return \ZipArchive
     *
     * @throws ZipException در صورت باز نبودن آرشیو
     */
    private function requireArchive(): \ZipArchive
    {
        if ($this->archive === null) {
            throw new ZipException('آرشیو باز نشده است');
        }

        return $this->archive;
    }
}
