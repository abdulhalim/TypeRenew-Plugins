<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Zip;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class PurePhpWriter implements ZipWriter
{
    /**
     * امضای سرصفحه محلی فایل.
     */
    private const LOCAL_HEADER_SIG = "PK\x03\x04";

    /**
     * امضای مدخل پوشه مرکزی.
     */
    private const CENTRAL_HEADER_SIG = "PK\x01\x02";

    /**
     * امضای پایان پوشه مرکزی.
     */
    private const EOCD_SIG = "PK\x05\x06";

    /**
     * روش ذخیره بدون فشرده‌سازی.
     */
    public const METHOD_STORE = 0;

    /**
     * روش فشرده‌سازی DEFLATE.
     */
    private const METHOD_DEFLATE = 8;

    /**
     * پرچم نام UTF-8.
     */
    private const FLAG_UTF8 = 0x0800;

    /**
     * سطح فشرده‌سازی.
     */
    private const COMPRESSION_LEVEL = 2;

    /**
     * اندازه قطعه خواندن فایل.
     */
    private const READ_CHUNK = 524288;

    /**
     * پسوندهایی که فشرده‌سازی آن‌ها بهینه نیست.
     */
    private const INCOMPRESSIBLE_EXTENSIONS = [
        'jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'bmp', 'ico',
        'mp4', 'm4v', 'mov', 'avi', 'mkv', 'webm', 'mp3', 'm4a', 'ogg', 'wav', 'flac',
        'zip', 'gz', 'bz2', 'xz', 'zst', 'rar', '7z', 'tgz',
        'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'odt',
        'woff', 'woff2', 'ttf', 'otf', 'eot',
        'apk', 'iso', 'dmg', 'exe', 'dll', 'so',
    ];

    /**
     * دسترسی فایل آرشیو.
     *
     * @var resource|null
     */
    private $handle = null;

    /**
     * مسیر فایل آرشیو.
     *
     * @var string
     */
    private string $path = '';

    /**
     * مدخل‌های ثبت‌شده برای پوشه مرکزی.
     *
     * @var array<int,array<string,int|string>>
     */
    private array $records = [];

    /**
     * آفست جاری نوشتن.
     *
     * @var int
     */
    private int $offset = 0;

    /**
     * آغاز آرشیو؛ در صورت وجود وضعیت ذخیره‌شده، ادامه می‌دهد.
     *
     * @param string                    $path  مسیر فایل ZIP
     * @param array<string,mixed>|null  $state وضعیت ذخیره‌شده قبلی
     *
     * @return void
     *
     * @throws ZipException در صورت خطای I/O
     */
    public function begin(string $path, ?array $state = null): void
    {
        $this->path = $path;

        if ($state !== null) {
            $this->records = array_values($state['records'] ?? []);
            $this->offset = (int) ($state['offset'] ?? 0);
        } else {
            $this->records = [];
            $this->offset = 0;
        }

        $exists = is_file($path);
        $size = 0;

        if ($exists) {
            clearstatcache(true, $path);
            $size = (int) filesize($path);
        }

        if ($state !== null && $size !== $this->offset) {
            throw new ZipException('فایل آرشیو با وضعیت ذخیره‌شده هم‌خوانی ندارد');
        }

        $handle = $exists ? fopen($path, 'r+b') : fopen($path, 'xb');

        if ($handle === false) {
            throw new ZipException('ساخت فایل آرشیو ممکن نشد: ' . $path);
        }

        $this->handle = $handle;

        if (fseek($handle, $this->offset) === -1) {
            throw new ZipException('جابه‌جایی در فایل آرشیو ناموفق بود');
        }
    }

    /**
     * افزودن یک فایل از دیسک.
     *
     * @param string $sourcePath مسیر فایل منبع
     * @param string $entryName  نام مدخل
     *
     * @return int حجم خام فایل
     *
     * @throws ZipException در صورت خطای I/O
     */
    public function addFile(string $sourcePath, string $entryName): int
    {
        if (!is_file($sourcePath) || !is_readable($sourcePath)) {
            throw new ZipException('فایل برای افزودن به آرشیو در دسترس نیست: ' . $sourcePath);
        }

        $size = (int) filesize($sourcePath);
        $method = $this->isCompressible($entryName) && $size > 0 ? self::METHOD_DEFLATE : self::METHOD_STORE;

        $source = fopen($sourcePath, 'rb');

        if ($source === false) {
            throw new ZipException('خواندن فایل منبع ناموفق بود: ' . $sourcePath);
        }

        try {
            return $this->addStream($source, $entryName, $method, (int) filemtime($sourcePath));
        } finally {
            fclose($source);
        }
    }

    /**
     * افزودن محتوای متنی.
     *
     * @param string   $entryName نام مدخل
     * @param string   $content   محتوا
     * @param int|null $method    روش ذخیره (null یعنی انتخاب خودکار)
     *
     * @return void
     *
     * @throws ZipException در صورت خطای I/O
     */
    public function addFromString(string $entryName, string $content, ?int $method = null): void
    {
        if ($method === null) {
            $method = $content === '' ? self::METHOD_STORE : self::METHOD_DEFLATE;
        }

        $stream = fopen('php://memory', 'r+b');

        if ($stream === false) {
            throw new ZipException('ساخت جریان حافظه ناموفق بود');
        }

        fwrite($stream, $content);
        rewind($stream);

        try {
            $this->addStream($stream, $entryName, $method, time());
        } finally {
            fclose($stream);
        }
    }

    /**
     * نوشتن پوشه مرکزی و بستن آرشیو.
     *
     * @return void
     *
     * @throws ZipException در صورت خطای I/O
     */
    public function finish(): void
    {
        if ($this->handle === null) {
            throw new ZipException('آرشیو آغاز نشده است');
        }

        $centralStart = $this->offset;
        $centralSize = 0;
        $count = count($this->records);

        foreach ($this->records as $record) {
            $name = (string) $record['name'];
            $binaryName = $name;
            $flags = (bool) $record['utf8'] ? self::FLAG_UTF8 : 0;

            $entry = self::CENTRAL_HEADER_SIG
                . pack(
                    'vvvvvvVVVvvvvvVV',
                    0x0014,
                    0x0014,
                    $flags,
                    (int) $record['method'],
                    (int) $record['mtime'],
                    (int) $record['mdate'],
                    (int) $record['crc'],
                    (int) $record['csize'],
                    (int) $record['usize'],
                    strlen($binaryName),
                    0,
                    0,
                    0,
                    0,
                    ((int) $record['mode']) << 16,
                    (int) $record['offset']
                );

            $this->write($entry . $binaryName);
            $centralSize += 46 + strlen($binaryName);
        }

        $eocd = self::EOCD_SIG . pack(
            'vvvvVVv',
            0,
            0,
            $count & 0xFFFF,
            $count & 0xFFFF,
            $centralSize,
            $centralStart,
            0
        );

        $this->write($eocd);

        if (!fflush($this->handle)) {
            throw new ZipException('ثبت آرشیو روی دیسک ناموفق بود');
        }

        fclose($this->handle);
        $this->handle = null;
    }

    /**
     * آزادسازی منابع بدون نوشتن پوشه مرکزی.
     *
     * @return void
     */
    public function abort(): void
    {
        if (is_resource($this->handle)) {
            fclose($this->handle);
        }

        $this->handle = null;
    }

    /**
     * خروجی وضعیت قابل ذخیره‌سازی.
     *
     * @return array<string,mixed>
     */
    public function exportState(): array
    {
        return [
            'records' => $this->records,
            'offset'  => $this->offset,
        ];
    }

    /**
     * افزودن یک جریان به آرشیو.
     *
     * @param resource $source جریان ورودی
     * @param string   $entryName نام مدخل
     * @param int      $method   روش ذخیره
     * @param int      $mtime    زمان تغییر فایل
     *
     * @return int حجم خام
     *
     * @throws ZipException در صورت خطای I/O
     */
    private function addStream($source, string $entryName, int $method, int $mtime): int
    {
        if ($this->handle === null) {
            throw new ZipException('آرشیو آغاز نشده است');
        }

        $isUtf8 = !preg_match('/^[\x00-\x7F]*$/', $entryName);
        $flags = $isUtf8 ? self::FLAG_UTF8 : 0;
        $headerOffset = $this->offset;
        $nameBytes = $entryName;

        [$dosTime, $dosDate] = self::toDosTime($mtime);

        $localHeader = self::LOCAL_HEADER_SIG . pack(
            'vvvvvVVVvv',
            0x0014,
            $flags,
            $method,
            $dosTime,
            $dosDate,
            0,
            0,
            0,
            strlen($nameBytes),
            0
        );

        $this->write($localHeader . $nameBytes);

        $crcContext = hash_init('crc32b');
        $uncompressed = 0;
        $compressed = 0;

        if ($method === self::METHOD_DEFLATE) {
            $context = deflate_init(ZLIB_ENCODING_RAW, ['level' => self::COMPRESSION_LEVEL]);

            if ($context === false) {
                throw new ZipException('راه‌اندازی فشرده‌سازی ناموفق بود');
            }

            while (!feof($source)) {
                $chunk = fread($source, self::READ_CHUNK);

                if ($chunk === false) {
                    throw new ZipException('خواندن از فایل منبع ناموفق بود');
                }

                if ($chunk === '') {
                    continue;
                }

                hash_update($crcContext, $chunk);
                $uncompressed += strlen($chunk);
                $out = deflate_add($context, $chunk, ZLIB_NO_FLUSH);

                if ($out === false) {
                    throw new ZipException('فشرده‌سازی داده ناموفق بود');
                }

                if ($out !== '') {
                    $this->write($out);
                    $compressed += strlen($out);
                }
            }

            $tail = deflate_add($context, '', ZLIB_FINISH);

            if ($tail === false) {
                throw new ZipException('پایان فشرده‌سازی ناموفق بود');
            }

            if ($tail !== '') {
                $this->write($tail);
                $compressed += strlen($tail);
            }
        } else {
            while (!feof($source)) {
                $chunk = fread($source, self::READ_CHUNK);

                if ($chunk === false) {
                    throw new ZipException('خواندن از فایل منبع ناموفق بود');
                }

                if ($chunk === '') {
                    continue;
                }

                hash_update($crcContext, $chunk);
                $uncompressed += strlen($chunk);
                $compressed += strlen($chunk);
                $this->write($chunk);
            }
        }

        // مقدار CRC نهایی (یک‌بار نهایی‌سازی می‌شود)
        $crcValue = hexdec(hash_final($crcContext));

        // وصله‌کاری مقادیر CRC و اندازه‌ها در سرصفحه محلی
        $patchPosition = $headerOffset + 14;

        if (fseek($this->handle, $patchPosition) === -1) {
            throw new ZipException('وصله‌کاری سرصفحه آرشیو ناموفق بود');
        }

        $patch = pack('VVV', $crcValue, $compressed, $uncompressed);
        $patched = fwrite($this->handle, $patch);

        if ($patched === false || $patched !== strlen($patch)) {
            throw new ZipException('وصله‌کاری سرصفحه آرشیو ناموفق بود');
        }

        if (fseek($this->handle, $this->offset) === -1) {
            throw new ZipException('بازگشت به انتهای آرشیو ناموفق بود');
        }

        $this->records[] = [
            'name'   => $entryName,
            'crc'    => $crcValue,
            'csize'  => $compressed,
            'usize'  => $uncompressed,
            'method' => $method,
            'mtime'  => $dosTime,
            'mdate'  => $dosDate,
            'mode'   => 0100644,
            'offset' => $headerOffset,
            'utf8'   => $isUtf8,
        ];

        return $uncompressed;
    }

    /**
     * نوشتن داده در انتهای آرشیو.
     *
     * @param string $bytes داده
     *
     * @return void
     *
     * @throws ZipException در صورت خطای نوشتن
     */
    private function write(string $bytes): void
    {
        if ($this->handle === null) {
            throw new ZipException('آرشیو آغاز نشده است');
        }

        $length = strlen($bytes);

        if ($length === 0) {
            return;
        }

        $written = fwrite($this->handle, $bytes);

        if ($written === false || $written !== $length) {
            throw new ZipException('نوشتن در فایل آرشیو ناموفق بود');
        }

        $this->offset += $length;
    }

    /**
     * بررسی قابلیت فشرده‌سازی بر اساس پسوند.
     *
     * @param string $entryName نام مدخل
     *
     * @return bool
     */
    private function isCompressible(string $entryName): bool
    {
        $lower = strtolower($entryName);
        $dot = strrpos($lower, '.');

        if ($dot === false) {
            return true;
        }

        $extension = substr($lower, $dot + 1);

        return !in_array($extension, self::INCOMPRESSIBLE_EXTENSIONS, true);
    }

    /**
     * تبدیل زمان Unix به زمان DOS.
     *
     * @param int $timestamp زمان Unix
     *
     * @return array{0:int,1:int} زمان و تاریخ DOS
     */
    private static function toDosTime(int $timestamp): array
    {
        if ($timestamp < 315532800) {
            $timestamp = 315532800;
        }

        $parts = getdate($timestamp);

        $dosTime = (($parts['hours'] & 0x1F) << 11)
            | (($parts['minutes'] & 0x3F) << 5)
            | intdiv($parts['seconds'], 2);

        $dosDate = ((($parts['year'] - 1980) & 0x7F) << 9)
            | (($parts['mon'] & 0x0F) << 5)
            | min(31, max(1, $parts['mday']));

        return [$dosTime, $dosDate];
    }
}
