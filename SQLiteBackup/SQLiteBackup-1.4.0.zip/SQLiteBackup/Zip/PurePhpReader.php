<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Zip;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class PurePhpReader implements ZipReader
{
    /**
     * امضای مدخل پوشه مرکزی.
     */
    private const CENTRAL_HEADER_SIG = 0x02014b50;

    /**
     * امضای پایان پوشه مرکزی.
     */
    private const EOCD_SIG = 0x06054b50;

    /**
     * امضای سرصفحه محلی.
     */
    private const LOCAL_HEADER_SIG = 0x04034b50;

    /**
     * روش ذخیره بدون فشرده‌سازی.
     */
    private const METHOD_STORE = 0;

    /**
     * روش فشرده‌سازی DEFLATE.
     */
    private const METHOD_DEFLATE = 8;

    /**
     * اندازه قطعه خواندن.
     */
    private const READ_CHUNK = 1048576;

    /**
     * دسترسی فایل آرشیو.
     *
     * @var resource|null
     */
    private $handle = null;

    /**
     * مسیر فایل آرشیو.
     *
     * @var string
     */
    private string $path = '';

    /**
     * نقشه مدخل‌ها بر اساس نام.
     *
     * @var array<string,array<string,int|string>>
     */
    private array $entriesByName = [];

    /**
     * باز کردن فایل ZIP و تجزیه پوشه مرکزی.
     *
     * @param string $path مسیر فایل
     *
     * @return void
     *
     * @throws ZipException در صورت خرابی ساختار
     */
    public function open(string $path): void
    {
        if (!is_file($path) || !is_readable($path)) {
            throw new ZipException('فایل ZIP برای خواندن در دسترس نیست: ' . $path);
        }

        $handle = fopen($path, 'rb');

        if ($handle === false) {
            throw new ZipException('باز کردن فایل ZIP ناموفق بود: ' . $path);
        }

        $this->handle = $handle;
        $this->path = $path;

        $eocd = $this->locateEocd();

        if ($eocd === null) {
            throw new ZipException('ساختار ZIP نامعتبر است (پوشه مرکزی یافت نشد)');
        }

        $this->parseCentralDirectory($eocd['offset'], $eocd['count']);
    }

    /**
     * فهرست مدخل‌ها.
     *
     * @return array<int,array{name:string,size:int,method:int,crc:int}>
     */
    public function entries(): array
    {
        $list = [];

        foreach ($this->entriesByName as $entry) {
            $list[] = [
                'name'   => (string) $entry['name'],
                'size'   => (int) $entry['usize'],
                'method' => (int) $entry['method'],
                'crc'    => (int) $entry['crc'],
            ];
        }

        return $list;
    }

    /**
     * بررسی وجود مدخل.
     *
     * @param string $name نام مدخل
     *
     * @return bool
     */
    public function has(string $name): bool
    {
        return isset($this->entriesByName[$name]);
    }

    /**
     * خواندن محتوای مدخل به رشته.
     *
     * @param string $name     نام مدخل
     * @param int    $maxBytes بیشترین حجم مجاز
     *
     * @return string
     *
     * @throws ZipException در صورت خطا
     */
    public function readString(string $name, int $maxBytes = 1048576): string
    {
        $entry = $this->requireEntry($name);

        if ((int) $entry['usize'] > $maxBytes) {
            throw new ZipException('حجم مدخل از حد مجاز بیشتر است: ' . $name);
        }

        $data = $this->readEntry((string) $entry['name']);
        $plain = $this->inflateEntry($entry, $data);

        return $plain;
    }

    /**
     * استخراج جریانی یک مدخل با بررسی CRC و محاسبه SHA-256.
     *
     * @param string $name     نام مدخل
     * @param string $destPath مسیر مقصد
     *
     * @return array{size:int,sha256:string}
     *
     * @throws ZipException در صورت خطا یا خرابی داده
     */
    public function extractTo(string $name, string $destPath): array
    {
        $entry = $this->requireEntry($name);

        $target = fopen($destPath, 'wb');

        if ($target === false) {
            throw new ZipException('ساخت فایل مقصد ناموفق بود: ' . $destPath);
        }

        $hash = hash_init('sha256');
        $crcContext = hash_init('crc32b');
        $size = 0;
        $method = (int) $entry['method'];

        try {
            $this->seekToEntryData($entry);

            $remaining = (int) $entry['csize'];
            $inflate = $method === self::METHOD_DEFLATE ? inflate_init(ZLIB_ENCODING_RAW) : null;

            while ($remaining > 0) {
                $chunk = fread($this->handle, min(self::READ_CHUNK, $remaining));

                if ($chunk === false || $chunk === '') {
                    throw new ZipException('خواندن داده مدخل ناموفق بود: ' . $name);
                }

                $remaining -= strlen($chunk);

                if ($inflate !== null) {
                    $plain = inflate_add($inflate, $chunk);

                    if ($plain === false) {
                        throw new ZipException('بازگشایی فشرده‌سازی مدخل ناموفق بود: ' . $name);
                    }
                } else {
                    $plain = $chunk;
                }

                if ($plain !== '') {
                    hash_update($crcContext, $plain);
                    $size += strlen($plain);
                    hash_update($hash, $plain);

                    if (fwrite($target, $plain) === false) {
                        throw new ZipException('نوشتن فایل مقصد ناموفق بود: ' . $destPath);
                    }
                }
            }

            if ($inflate !== null) {
                $tail = inflate_add($inflate, '', ZLIB_FINISH);

                if ($tail === false) {
                    throw new ZipException('پایان بازگشایی مدخل ناموفق بود: ' . $name);
                }

                if ($tail !== '') {
                    hash_update($crcContext, $tail);
                    $size += strlen($tail);
                    hash_update($hash, $tail);
                    fwrite($target, $tail);
                }
            }
        } finally {
            fclose($target);
        }

        $expectedCrc = sprintf('%08x', (int) $entry['crc']);

        if ($size !== (int) $entry['usize'] || !hash_equals($expectedCrc, hash_final($crcContext))) {
            throw new ZipException('تطبیق صحت داده مدخل ناموفق بود: ' . $name);
        }

        return [
            'size'   => $size,
            'sha256' => hash_final($hash),
        ];
    }

    /**
     * بستن آرشیو.
     *
     * @return void
     */
    public function close(): void
    {
        if (is_resource($this->handle)) {
            fclose($this->handle);
        }

        $this->handle = null;
        $this->entriesByName = [];
    }

    /**
     * یافتن پایان پوشه مرکزی.
     *
     * @return array{offset:int,count:int}|null
     *
     * @throws ZipException در صورت خطای خواندن
     */
    private function locateEocd(): ?array
    {
        $size = (int) filesize($this->path);
        $scan = min(65557, $size);
        $cursor = $size - $scan;

        if (fseek($this->handle, $cursor) === -1) {
            throw new ZipException('جابه‌جایی در فایل ZIP ناموفق بود');
        }

        $buffer = '';

        while ($cursor < $size) {
            $chunk = fread($this->handle, min(8192, $size - $cursor));

            if ($chunk === false) {
                throw new ZipException('خواندن فایل ZIP ناموفق بود');
            }

            $buffer .= $chunk;
            $cursor += strlen($chunk);
        }

        $position = strrpos($buffer, pack('V', self::EOCD_SIG));

        if ($position === false) {
            return null;
        }

        if (strlen($buffer) - $position < 22) {
            return null;
        }

        $record = unpack(
            'Vsig/vdisk/vcdisk/vcount/vcount2/Vsize/Voffset/vcomment',
            substr($buffer, $position, 22)
        );

        if ($record === false || (int) $record['sig'] !== self::EOCD_SIG) {
            return null;
        }

        return [
            'offset' => (int) $record['offset'],
            'count'  => (int) $record['count2'],
        ];
    }

    /**
     * تجزیه پوشه مرکزی.
     *
     * @param int $offset آفست پوشه مرکزی
     * @param int $count  تعداد مدخل‌ها
     *
     * @return void
     *
     * @throws ZipException در صورت خرابی ساختار
     */
    private function parseCentralDirectory(int $offset, int $count): void
    {
        if (fseek($this->handle, $offset) === -1) {
            throw new ZipException('جابه‌جایی به پوشه مرکزی ناموفق بود');
        }

        for ($i = 0; $i < $count; $i++) {
            $header = fread($this->handle, 46);

            if ($header === false || strlen($header) !== 46) {
                throw new ZipException('سرصفحه پوشه مرکزی ناقص است');
            }

            $record = unpack(
                'Vsig/vversion/vneeded/vflags/vmethod/vmtime/vmdate/Vcrc/Vcsize/Vusize/vnamelen/vextralen/vcommentlen/vdisk/vinternal/Vexternal/Voffset',
                $header
            );

            if ($record === false || (int) $record['sig'] !== self::CENTRAL_HEADER_SIG) {
                throw new ZipException('امضای مدخل پوشه مرکزی نامعتبر است');
            }

            $name = (string) fread($this->handle, (int) $record['namelen']);

            if (strlen($name) !== (int) $record['namelen']) {
                throw new ZipException('نام مدخل پوشه مرکزی ناقص است');
            }

            if ((int) $record['extralen'] > 0) {
                fseek($this->handle, (int) $record['extralen'], SEEK_CUR);
            }

            if ((int) $record['commentlen'] > 0) {
                fseek($this->handle, (int) $record['commentlen'], SEEK_CUR);
            }

            $this->entriesByName[$name] = [
                'name'   => $name,
                'method' => (int) $record['method'],
                'crc'    => (int) $record['crc'],
                'csize'  => (int) $record['csize'],
                'usize'  => (int) $record['usize'],
                'offset' => (int) $record['offset'],
            ];
        }
    }

    /**
     * جابه‌جایی به ابتدای داده یک مدخل.
     *
     * @param array<string,int|string> $entry مدخل
     *
     * @return void
     *
     * @throws ZipException در صورت خرابی سرصفحه محلی
     */
    private function seekToEntryData(array $entry): void
    {
        if (fseek($this->handle, (int) $entry['offset']) === -1) {
            throw new ZipException('جابه‌جایی به سرصفحه محلی ناموفق بود');
        }

        $header = fread($this->handle, 30);

        if ($header === false || strlen($header) !== 30) {
            throw new ZipException('سرصفحه محلی ناقص است');
        }

        $record = unpack(
            'Vsig/vversion/vflags/vmethod/vmtime/vmdate/Vcrc/Vcsize/Vusize/vnamelen/vextralen',
            $header
        );

        if ($record === false || (int) $record['sig'] !== self::LOCAL_HEADER_SIG) {
            throw new ZipException('امضای سرصفحه محلی نامعتبر است');
        }

        $skip = (int) $record['namelen'] + (int) $record['extralen'];

        if ($skip > 0 && fseek($this->handle, $skip, SEEK_CUR) === -1) {
            throw new ZipException('عبور از سرصفحه محلی ناموفق بود');
        }
    }

    /**
     * خواندن کامل داده فشرده یک مدخل.
     *
     * @param string $name نام مدخل
     *
     * @return string داده فشرده
     *
     * @throws ZipException در صورت خطا
     */
    private function readEntry(string $name): string
    {
        $entry = $this->requireEntry($name);
        $this->seekToEntryData($entry);

        $data = '';

        while (strlen($data) < (int) $entry['csize']) {
            $chunk = fread($this->handle, (int) $entry['csize'] - strlen($data));

            if ($chunk === false || $chunk === '') {
                throw new ZipException('خواندن داده مدخل ناموفق بود: ' . $name);
            }

            $data .= $chunk;
        }

        return $data;
    }

    /**
     * بازگشایی داده یک مدخل با بررسی CRC.
     *
     * @param array<string,int|string> $entry مدخل
     * @param string                   $data  داده فشرده
     *
     * @return string داده خام
     *
     * @throws ZipException در صورت خرابی داده
     */
    private function inflateEntry(array $entry, string $data): string
    {
        $method = (int) $entry['method'];

        if ($method === self::METHOD_STORE) {
            $plain = $data;
        } elseif ($method === self::METHOD_DEFLATE) {
            $plain = gzinflate($data);

            if ($plain === false) {
                throw new ZipException('بازگشایی فشرده‌سازی مدخل ناموفق بود');
            }
        } else {
            throw new ZipException('روش فشرده‌سازی مدخل پشتیبانی نمی‌شود: ' . $method);
        }

        if (strlen($plain) !== (int) $entry['usize'] || crc32($plain) !== (int) $entry['crc']) {
            throw new ZipException('تطبیق صحت داده مدخل ناموفق بود');
        }

        return $plain;
    }

    /**
     * دسترسی به مدخل با بررسی وجود.
     *
     * @param string $name نام مدخل
     *
     * @return array<string,int|string>
     *
     * @throws ZipException در صورت نبود مدخل
     */
    private function requireEntry(string $name): array
    {
        if (!isset($this->entriesByName[$name])) {
            throw new ZipException('مدخل در آرشیو یافت نشد: ' . $name);
        }

        return $this->entriesByName[$name];
    }
}
