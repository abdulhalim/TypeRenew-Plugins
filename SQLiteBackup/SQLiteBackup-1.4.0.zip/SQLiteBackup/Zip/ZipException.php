<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Zip;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class ZipException extends \RuntimeException
{
}
