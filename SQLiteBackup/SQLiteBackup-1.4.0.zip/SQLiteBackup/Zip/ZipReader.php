<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Zip;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

interface ZipReader
{
    /**
     * باز کردن فایل ZIP.
     *
     * @param string $path مسیر فایل
     *
     * @return void
     *
     * @throws ZipException در صورت خرابی یا نبود فایل
     */
    public function open(string $path): void;

    /**
     * فهرست مدخل‌های آرشیو.
     *
     * @return array<int,array{name:string,size:int,method:int,crc:int}>
     *
     * @throws ZipException در صورت خطا
     */
    public function entries(): array;

    /**
     * بررسی وجود یک مدخل.
     *
     * @param string $name نام مدخل
     *
     * @return bool
     */
    public function has(string $name): bool;

    /**
     * خواندن محتوای یک مدخل به صورت رشته (برای مدخل‌های کوچک).
     *
     * @param string $name نام مدخل
     * @param int    $maxBytes بیشترین حجم مجاز
     *
     * @return string
     *
     * @throws ZipException در صورت خطا یا تجاوز از حجم مجاز
     */
    public function readString(string $name, int $maxBytes = 1048576): string;

    /**
     * استخراج یک مدخل به مسیر مقصد به صورت جریانی با بررسی CRC.
     *
     * @param string $name        نام مدخل
     * @param string $destPath    مسیر فایل مقصد
     *
     * @return array{size:int,sha256:string}
     *
     * @throws ZipException در صورت خطا یا عدم تطابق CRC
     */
    public function extractTo(string $name, string $destPath): array;

    /**
     * بستن آرشیو.
     *
     * @return void
     */
    public function close(): void;
}
