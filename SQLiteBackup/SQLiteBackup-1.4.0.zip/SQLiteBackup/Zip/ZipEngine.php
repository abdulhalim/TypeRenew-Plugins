<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Zip;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class ZipEngine
{
    /**
     * سازنده خصوصی؛ همه متدها ایستا هستند.
     */
    private function __construct()
    {
    }

    /**
     * ساخت موتور نوشتن ZIP (پیاده‌سازی خالص PHP).
     *
     * انتخاب آگاهانه: موتور خالص PHP قابلیت افزودن تدریجی مدخل‌ها در چند
     * درخواست HTTP را دارد و برای ساخت پشتیبان‌های حجیم مناسب‌تر است.
     *
     * @return ZipWriter
     *
     * @throws ZipException در صورت نبود افزونه Zlib
     */
    public static function writer(): ZipWriter
    {
        if (!function_exists('deflate_init')) {
            throw new ZipException('ساخت فایل ZIP به افزونه Zlib نیاز دارد');
        }

        return new PurePhpWriter();
    }

    /**
     * ساخت موتور خواندن ZIP.
     *
     * در صورت وجود افزونه ZipArchive از آن استفاده می‌شود؛ در غیر این صورت
     * موتور خالص PHP به کار می‌رود.
     *
     * @return ZipReader
     */
    public static function reader(): ZipReader
    {
        if (class_exists('ZipArchive')) {
            return new ZipArchiveReader();
        }

        return new PurePhpReader();
    }

    /**
     * بررسی پشتیبانی سرور از ساخت ZIP.
     *
     * @return bool
     */
    public static function isSupported(): bool
    {
        return function_exists('deflate_init') && function_exists('gzinflate');
    }
}
