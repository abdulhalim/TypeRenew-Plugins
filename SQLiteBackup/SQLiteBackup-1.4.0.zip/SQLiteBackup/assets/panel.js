(function () {
    'use strict';

    var panel = document.getElementById('br-panel');

    if (!panel) {
        return;
    }

    /* ============================== Config ============================== */

    var config;

    try {
        config = JSON.parse(panel.getAttribute('data-config') || '{}');
    } catch (e) {
        config = {};
    }

    config.urls = config.urls || {};
    config.initial = config.initial || {};

    var urls = config.urls;

    /* اختلاف منطقه زمانی سایت (ثانیه) برای نمایش تاریخ‌ها به وقت سایت */
    var siteTzOffset = (((config.initial || {}).timezone || {}).offsetSeconds);

    if (typeof siteTzOffset !== 'number') {
        siteTzOffset = null;
    }

    /* ============================== Helpers ============================== */

    function $(id) {
        return document.getElementById(id);
    }

    function el(tag, className, text) {
        var node = document.createElement(tag);

        if (className) {
            node.className = className;
        }

        if (text !== undefined && text !== null) {
            node.textContent = text;
        }

        return node;
    }

    var FA_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

    function faDigits(value) {
        return String(value).replace(/[0-9]/g, function (digit) {
            return FA_DIGITS[+digit];
        });
    }

    /* تبدیل تاریخ میلادی به شمسی (هم‌ارز الگوریتم سمت سرور) */
    function toJalali(year, month, day) {
        var gDaysInMonth = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];

        function div(a, b) {
            return Math.trunc(a / b);
        }

        var jy = (year <= 1600) ? 0 : 979;
        year -= (year <= 1600) ? 621 : 1600;

        var year2 = (month > 2) ? (year + 1) : year;
        var days = (365 * year)
            + div(year2 + 3, 4)
            - div(year2 + 99, 100)
            + div(year2 + 399, 400)
            - 80
            + day
            + gDaysInMonth[month - 1];

        jy += 33 * div(days, 12053);
        days %= 12053;
        jy += 4 * div(days, 1461);
        days %= 1461;

        if (days > 365) {
            jy += div(days - 1, 365);
            days = (days - 1) % 365;
        }

        var jm = (days < 186) ? (1 + div(days, 31)) : (7 + div(days - 186, 30));
        var jd = 1 + ((days < 186) ? (days % 31) : ((days - 186) % 30));

        return [jy, jm, jd];
    }

    function formatBytes(value) {
        value = Number(value) || 0;

        if (value < 1024) {
            return faDigits(value) + ' بایت';
        }

        var units = ['کیلوبایت', 'مگابایت', 'گیگابایت', 'ترابایت'];
        var i = -1;

        do {
            value /= 1024;
            i++;
        } while (value >= 1024 && i < units.length - 1);

        var text = (value >= 100 || value === Math.floor(value))
            ? String(Math.round(value))
            : value.toFixed(1);

        return faDigits(text).replace('.', '٫') + ' ' + units[i];
    }

    function formatNumber(value) {
        return (Number(value) || 0).toLocaleString('fa-IR');
    }

    function formatDate(value) {
        if (!value) {
            return '-';
        }

        var date = new Date(typeof value === 'number' ? value * 1000 : value);

        if (isNaN(date.getTime())) {
            return String(value);
        }

        function pad(n) {
            return (n < 10 ? '0' : '') + n;
        }

        var year;
        var month;
        var day;
        var hours;
        var minutes;

        if (siteTzOffset !== null) {
            // نمایش به وقت سایت (مثلاً تهران) فارغ از منطقه زمانی مرورگر
            var shifted = new Date(date.getTime() + siteTzOffset * 1000);

            year = shifted.getUTCFullYear();
            month = shifted.getUTCMonth() + 1;
            day = shifted.getUTCDate();
            hours = shifted.getUTCHours();
            minutes = shifted.getUTCMinutes();
        } else {
            year = date.getFullYear();
            month = date.getMonth() + 1;
            day = date.getDate();
            hours = date.getHours();
            minutes = date.getMinutes();
        }

        var j = toJalali(year, month, day);

        return faDigits(j[0] + '/' + pad(j[1]) + '/' + pad(j[2]) + ' - ' + pad(hours) + ':' + pad(minutes));
    }

    function formatDuration(seconds) {
        seconds = Math.max(1, Number(seconds) || 1);

        if (seconds < 60) {
            return formatNumber(seconds) + ' ثانیه';
        }

        var minutes = Math.floor(seconds / 60);

        return formatNumber(minutes) + ' دقیقه و ' + formatNumber(seconds % 60) + ' ثانیه';
    }

    /* ============================== Toasts ============================== */

    var toastBox = $('br-toasts');

    function toast(message, type, sticky) {
        if (!toastBox) {
            window.console && console.log('[SQLiteBackup]', message);
            return;
        }

        var item = el('div', 'br-toast' + (type ? ' br-toast-' + type : ''), message);
        toastBox.appendChild(item);

        var timer = null;

        function dismiss() {
            if (timer) {
                window.clearTimeout(timer);
            }

            item.classList.add('br-toast-out');
            window.setTimeout(function () {
                if (item.parentNode) {
                    item.parentNode.removeChild(item);
                }
            }, 220);
        }

        if (!sticky) {
            timer = window.setTimeout(dismiss, type === 'error' ? 9000 : 5200);
        }

        return dismiss;
    }

    /* ============================== Modal ============================== */

    var modalRoot = $('br-modal');
    var modalTitle = $('br-modal-title');
    var modalBody = $('br-modal-body');
    var modalFoot = $('br-modal-foot');

    function openModal(title, bodyNode, buttons) {
        if (!modalRoot) {
            return;
        }

        modalTitle.textContent = title;

        while (modalBody.firstChild) {
            modalBody.removeChild(modalBody.firstChild);
        }

        if (typeof bodyNode === 'string') {
            modalBody.textContent = bodyNode;
        } else if (bodyNode) {
            modalBody.appendChild(bodyNode);
        }

        while (modalFoot.firstChild) {
            modalFoot.removeChild(modalFoot.firstChild);
        }

        (buttons || []).forEach(function (button) {
            var node = el('button', 'br-btn ' + (button.className || 'br-btn-ghost'), button.label);
            node.type = 'button';

            node.addEventListener('click', function () {
                if (!button.keepOpen) {
                    closeModal();
                }

                if (typeof button.onClick === 'function') {
                    button.onClick();
                }
            });

            modalFoot.appendChild(node);
        });

        modalRoot.hidden = false;
    }

    function closeModal() {
        if (modalRoot) {
            modalRoot.hidden = true;
        }
    }

    if ($('br-modal-close')) {
        $('br-modal-close').addEventListener('click', closeModal);
    }

    if (modalRoot) {
        modalRoot.addEventListener('click', function (event) {
            if (event.target === modalRoot) {
                closeModal();
            }
        });
    }

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && modalRoot && !modalRoot.hidden) {
            closeModal();
        }
    });

    /* ============================== Fetch layer ============================== */

    function callApi(endpoint, params, method) {
        var url = urls[endpoint];

        if (!url) {
            return Promise.reject(new Error('نشانی عملیات یافت نشد: ' + endpoint));
        }

        var options = {
            method: method || (params ? 'POST' : 'GET'),
            credentials: 'same-origin',
            headers: {}
        };

        if (params) {
            var form = new FormData();

            Object.keys(params).forEach(function (key) {
                if (params[key] !== undefined && params[key] !== null) {
                    form.append(key, params[key]);
                }
            });

            options.body = form;
        }

        return fetch(url, options).then(function (response) {
            return response.text().then(function (text) {
                var data;

                try {
                    data = JSON.parse(text);
                } catch (e) {
                    throw new Error('پاسخ سرور معتبر نیست (HTTP ' + response.status + ')');
                }

                if (!response.ok) {
                    throw new Error(data.error || ('خطای سرور (HTTP ' + response.status + ')'));
                }

                // خطاهای سطح کاره (مثل restore.check) بدون استثنا برگردانده می‌شوند
                if (data.ok === false && data.error) {
                    throw new Error(data.error);
                }

                return data;
            });
        });
    }

    /* ============================== Progress UI ============================== */

    function progressUI(fillId, percentId, metaId, wrapId, labelId) {
        var fill = $(fillId);
        var percent = $(percentId);
        var meta = $(metaId);
        var wrap = $(wrapId);
        var label = labelId ? $(labelId) : null;

        return {
            show: function (text) {
                if (wrap) {
                    wrap.hidden = false;
                }

                if (label && text) {
                    label.textContent = text;
                }
            },
            update: function (percentValue, metaText) {
                percentValue = Number(percentValue) || 0;

                if (fill) {
                    fill.style.width = Math.max(0, Math.min(100, percentValue)) + '%';
                    fill.removeAttribute('data-state');
                }

                if (percent) {
                    percent.textContent = faDigits(Math.floor(percentValue)) + '٪';
                }

                if (meta && metaText !== undefined && metaText !== null) {
                    meta.textContent = metaText;
                }
            },
            state: function (state) {
                if (fill) {
                    if (state) {
                        fill.setAttribute('data-state', state);
                    } else {
                        fill.removeAttribute('data-state');
                    }
                }
            },
            label: function (text) {
                if (label) {
                    label.textContent = text;
                }
            },
            hide: function () {
                if (wrap) {
                    wrap.hidden = true;
                }
            }
        };
    }

    /* ============================== Tabs ============================== */

    var tabButtons = panel.querySelectorAll('[data-br-tab]');
    var panes = panel.querySelectorAll('[data-br-pane]');

    function activateTab(key) {
        tabButtons.forEach(function (button) {
            var isActive = button.getAttribute('data-br-tab') === key;

            button.classList.toggle('is-active', isActive);
            button.setAttribute('aria-selected', isActive ? 'true' : 'false');
        });

        panes.forEach(function (pane) {
            pane.classList.toggle('is-active', pane.getAttribute('data-br-pane') === key);
        });
    }

    function currentActiveTab() {
        var active = panel.querySelector('.br-tab.is-active');

        return active ? (active.getAttribute('data-br-tab') || 'overview') : 'overview';
    }

    /* بارگذاری مجدد صفحه با حفظ تب فعال (و پیام اختیاری) */
    function gotoTab(key, flash) {
        var url = new URL(window.location.href);

        url.searchParams.set('tab', key);

        if (flash) {
            url.searchParams.set('br-flash', flash);
        } else {
            url.searchParams.delete('br-flash');
        }

        window.location.assign(url.href);
    }

    tabButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            activateTab(button.getAttribute('data-br-tab'));
        });
    });

    /* ============================== Sub-tabs (داخل کارت‌ها) ============================== */

    panel.querySelectorAll('.br-subtabs').forEach(function (group) {
        var buttons = group.querySelectorAll('.br-subtab');
        var scope = group.closest('.br-card-body') || panel;

        function select(clicked) {
            var key = clicked.getAttribute('data-br-subtab');

            buttons.forEach(function (other) {
                var active = other === clicked;

                other.classList.toggle('is-active', active);
                other.setAttribute('aria-selected', active ? 'true' : 'false');
            });

            scope.querySelectorAll('[data-br-subpanel]').forEach(function (subpanel) {
                subpanel.hidden = subpanel.getAttribute('data-br-subpanel') !== key;
            });
        }

        buttons.forEach(function (button) {
            button.addEventListener('click', function () {
                select(button);
            });
        });
    });


    /* نمایش پیام یک‌باره پس از بارگذاری مجدد صفحه */
    (function handleFlash() {
        var params = new URLSearchParams(window.location.search);
        var flash = params.get('br-flash');

        if (!flash) {
            return;
        }

        params.delete('br-flash');

        var query = params.toString();
        window.history.replaceState({}, '', window.location.pathname + (query ? '?' + query : ''));

        if (flash === 'created') {
            toast('فایل پشتیبان جدید با موفقیت ساخته شد و به فهرست افزوده شد.', 'success');
        } else if (flash === 'fullcreated') {
            toast('بکاپ کامل سایت ساخته شد. این فایل پس از دانلود به‌طور خودکار از سرور حذف می‌شود.', 'success', true);
        } else if (flash === 'uploaded') {
            toast('فایل پشتیبان بارگذاری‌شده به فهرست افزوده شد و اکنون دکمه بازگردانی مستقل دارد.', 'success');
        }
    })();

    /* ============================== Backup flow ============================== */

    var backupUi = progressUI('br-backup-fill', 'br-backup-percent', 'br-backup-meta', 'br-backup-progress');
    var activeBackupSid = null;

    /* رابط پیشرفت هدف قابل‌تعیین است تا فاز «پشتیبان اضطراری» هنگام بازیابی
       روی نوار پیشرفتِ همان تب بازیابی نمایش داده شود */
    function runBackupLoop(sid, options) {
        options = options || {};

        var progress = options.progress || backupUi;

        progress.state(null);
        progress.show(options.label || 'در حال ساخت پشتیبان…');

        function step() {
            return callApi('backup.step', { sid: sid }).then(function (response) {
                progress.update(
                    response.percent,
                    'فایل‌ها: ' + formatNumber(response.filesDone) + ' از ' + formatNumber(response.filesTotal)
                    + ' — ' + formatBytes(response.bytesDone) + ' از ' + formatBytes(response.bytesTotal)
                );

                if (response.done) {
                    return callApi('backup.finalize', { sid: sid }).then(function (finalResponse) {
                        return finalResponse;
                    });
                }

                return step();
            });
        }

        return step().then(function (finalResponse) {
            var backup = finalResponse.backup || {};

            progress.state('success');
            progress.update(100, 'کامل شد');

            if (!options.silent) {
                toast('فایل پشتیبان با موفقیت ساخته شد: ' + backup.name + ' (' + formatBytes(backup.size) + ')', 'success');
            }

            return finalResponse;
        });
    }

    function startBackup(type, options, note) {
        options = options || {};

        var params = { type: type || 'backup' };

        if (note) {
            params.note = note;
        }

        return callApi('backup.init', params).then(function (response) {
            activeBackupSid = response.sid;

            return runBackupLoop(response.sid, options).then(function (result) {
                activeBackupSid = null;
                return result;
            }, function (error) {
                activeBackupSid = null;
                throw error;
            });
        });
    }

    var createButton = $('br-backup-create');
    var cancelButton = $('br-backup-cancel');
    var noteField = $('br-backup-note');

    if (createButton) {
        createButton.addEventListener('click', function () {
            createButton.disabled = true;

            var note = noteField ? String(noteField.value || '').trim() : '';

            startBackup('backup', {}, note).then(function () {
                toast('در حال به‌روزرسانی فهرست پشتیبان‌ها…', 'success');

                window.setTimeout(function () {
                    gotoTab('backups', 'created');
                }, 1100);
            }, function (error) {
                backupUi.state('danger');
                toast('خطا در ساخت پشتیبان: ' + error.message, 'error', true);
                createButton.disabled = false;
            });
        });
    }

    if (cancelButton) {
        cancelButton.addEventListener('click', function () {
            if (activeBackupSid) {
                callApi('backup.cancel', { sid: activeBackupSid }).then(function () {
                    toast('فرایند پشتیبان‌گیری لغو شد', 'warning');
                });
            }
        });
    }

    /* ============================== Full backup flow ============================== */

    var fullBackupUi = progressUI('br-fullbackup-fill', 'br-fullbackup-percent', 'br-fullbackup-meta', 'br-fullbackup-progress');
    var fullCreateButton = $('br-fullbackup-create');
    var fullCancelButton = $('br-fullbackup-cancel');
    var activeFullSid = null;

    function runFullBackupLoop(sid) {
        fullBackupUi.state(null);
        fullBackupUi.show('در حال ساخت بکاپ کامل…');

        function step() {
            return callApi('backup.step', { sid: sid }).then(function (response) {
                fullBackupUi.update(
                    response.percent,
                    'فایل‌ها: ' + formatNumber(response.filesDone) + ' از ' + formatNumber(response.filesTotal)
                    + ' — ' + formatBytes(response.bytesDone) + ' از ' + formatBytes(response.bytesTotal)
                );

                if (response.done) {
                    return callApi('backup.finalize', { sid: sid });
                }

                return step();
            });
        }

        return step().then(function (finalResponse) {
            var backup = finalResponse.backup || {};

            fullBackupUi.state('success');
            fullBackupUi.update(100, 'کامل شد');

            toast('بکاپ کامل سایت ساخته شد: ' + backup.name + ' (' + formatBytes(backup.size) + ')', 'success');

            return finalResponse;
        });
    }

    if (fullCreateButton) {
        fullCreateButton.addEventListener('click', function () {
            fullCreateButton.disabled = true;

            confirmModal(
                'ساخت بکاپ کامل',
                'یک ZIP از کل ریشه سایت (به‌جز پوشه بکاپ‌های افزونه) ساخته می‌شود؛ این عملیات ممکن است بسته به حجم سایت کمی طول بکشد. ادامه می‌دهید؟',
                function () {
                    callApi('backup.init', { type: 'full' }).then(function (response) {
                        activeFullSid = response.sid;

                        return runFullBackupLoop(response.sid).then(function (result) {
                            activeFullSid = null;

                            toast('در حال انتقال به فهرست پشتیبان‌ها…', 'success');
                            window.setTimeout(function () {
                                gotoTab('backups', 'fullcreated');
                            }, 1100);
                        }, function (error) {
                            activeFullSid = null;
                            throw error;
                        });
                    }).catch(function (error) {
                        fullBackupUi.state('danger');
                        toast('خطا در ساخت بکاپ کامل: ' + error.message, 'error', true);
                        fullCreateButton.disabled = false;
                    });
                },
                function () {
                    fullCreateButton.disabled = false;
                }
            );
        });
    }

    if (fullCancelButton) {
        fullCancelButton.addEventListener('click', function () {
            if (activeFullSid) {
                callApi('backup.cancel', { sid: activeFullSid }).then(function () {
                    toast('فرایند بکاپ کامل لغو شد', 'warning');
                    fullCreateButton.disabled = false;
                });
            }
        });
    }

    /* ============================== Upload flow ============================== */

    var uploadFileInput = $('br-upload-file');
    var uploadStartButton = $('br-upload-start');
    var uploadUi = {
        wrap: $('br-upload-progress'),
        fill: $('br-upload-fill'),
        percent: $('br-upload-percent'),
        meta: $('br-upload-meta'),
        label: $('br-upload-label'),

        show: function (text) {
            if (this.wrap) {
                this.wrap.hidden = false;
            }

            if (text && this.label) {
                this.label.textContent = text;
            }
        },

        update: function (percent, meta) {
            if (this.fill) {
                this.fill.style.width = Math.max(0, Math.min(100, percent)) + '%';
            }

            if (this.percent) {
                this.percent.textContent = faDigits(Math.floor(percent)) + '٪';
            }

            if (meta !== undefined && this.meta) {
                this.meta.textContent = meta || '';
            }
        },

        hide: function () {
            if (this.wrap) {
                this.wrap.hidden = true;
            }
        }
    };

    if (uploadFileInput) {
        uploadFileInput.addEventListener('change', function () {
            var file = uploadFileInput.files && uploadFileInput.files[0];

            if (uploadStartButton) {
                uploadStartButton.disabled = !file;
            }
        });
    }

    function uploadBackupFile(file) {
        var url = urls['backup.upload'];

        if (!url) {
            return Promise.reject(new Error('نشانی عملیات بارگذاری یافت نشد'));
        }

        var maxBytes = ((config.initial || {}).upload || {}).maxBytes;

        if (typeof maxBytes === 'number' && file.size > maxBytes) {
            return Promise.reject(new Error(
                'حجم فایل (' + formatBytes(file.size) + ') از سقف PHP (' + formatBytes(maxBytes) + ') بیشتر است'
            ));
        }

        return new Promise(function (resolve, reject) {
            var form = new FormData();
            form.append('backupFile', file, file.name);

            var xhr = new XMLHttpRequest();
            xhr.open('POST', url, true);
            xhr.withCredentials = true;
            xhr.responseType = 'text';

            xhr.upload.onprogress = function (event) {
                if (event.lengthComputable) {
                    uploadUi.update((event.loaded / event.total) * 100, formatBytes(event.loaded) + ' از ' + formatBytes(event.total));
                }
            };

            xhr.onload = function () {
                var data;

                try {
                    data = JSON.parse(xhr.responseText);
                } catch (e) {
                    reject(new Error('پاسخ سرور معتبر نیست (HTTP ' + xhr.status + ')'));
                    return;
                }

                if (xhr.status >= 200 && xhr.status < 300 && data && data.ok) {
                    resolve(data);
                } else {
                    reject(new Error((data && data.error) || ('خطای سرور (HTTP ' + xhr.status + ')')));
                }
            };

            xhr.onerror = function () {
                reject(new Error('ارتباط با سرور برقرار نشد'));
            };

            xhr.send(form);
        });
    }

    if (uploadStartButton) {
        uploadStartButton.addEventListener('click', function () {
            var file = uploadFileInput && uploadFileInput.files && uploadFileInput.files[0];

            if (!file) {
                toast('ابتدا یک فایل پشتیبان ZIP انتخاب کنید', 'warning');
                return;
            }

            uploadStartButton.disabled = true;
            uploadUi.show('در حال بارگذاری…');
            uploadUi.update(0, formatBytes(file.size));

            uploadBackupFile(file).then(function (response) {
                uploadUi.update(100, 'انجام شد');

                var uploaded = response.uploaded || {};

                toast('فایل پشتیبان «' + uploaded.name + '» با موفقیت بارگذاری و به فهرست «پشتیبان‌ها» اضافه شد.', 'success');

                window.setTimeout(function () {
                    gotoTab('backups', 'uploaded');
                }, 900);
            }).catch(function (error) {
                uploadUi.hide();
                toast('بارگذاری ناموفق: ' + error.message, 'error', true);
                uploadStartButton.disabled = false;
            });
        });
    }

    /* ============================== Restore flow ============================== */

    var restoreUi = progressUI('br-restore-fill', 'br-restore-percent', 'br-restore-meta', 'br-restore-progress', 'br-restore-label');

    function manifestDetailsNode(details) {
        var wrap = el('div');
        var grid = el('dl', 'br-detail-grid');

        var fields = [
            ['تاریخ ساخت', formatDate(details.createdAt)],
            ['نوع پشتیبان', details.type === 'emergency' ? 'اضطراری' : 'عادی'],
            ['نسخه ساخت', formatNumber(details.formatVersion)],
            ['نسخه افزونه', details.pluginVersion],
            ['نسخه TypeRenew', details.platformVersion],
            ['نوع دیتابیس', details.databaseType],
            ['حجم دیتابیس', formatBytes(details.databaseSize)],
            ['فایل‌های بارگذاری‌ها', formatNumber(details.uploadsFiles)],
            ['حجم بارگذاری‌ها', formatBytes(details.uploadsBytes)],
            ['مجموع فایل‌ها', formatNumber(details.totalFiles)],
            ['حجم کل داده', formatBytes(details.totalBytes)],
            ['حجم فایل پشتیبان', formatBytes(details.backupSize)]
        ];

        fields.forEach(function (field) {
            var item = el('div', 'br-detail-item');
            item.appendChild(el('dt', null, field[0]));
            item.appendChild(el('dd', null, field[1]));
            grid.appendChild(item);
        });

        wrap.appendChild(grid);

        if (details.checksum) {
            wrap.appendChild(el('div', 'br-checksum', 'Checksum (SHA-256):\n' + details.checksum));
        }

        return wrap;
    }

    function runRestoreLoop(sid) {
        restoreUi.state(null);
        restoreUi.show('در حال بازیابی فایل‌ها…');
        restoreUi.label('در حال بازیابی فایل‌ها…');

        function step() {
            return callApi('restore.step', { sid: sid }).then(function (response) {
                restoreUi.update(
                    response.percent,
                    'فایل‌ها: ' + formatNumber(response.filesDone) + ' از ' + formatNumber(response.filesTotal)
                );

                if (response.done) {
                    restoreUi.label('در حال جایگزینی دیتابیس…');
                    restoreUi.update(99, 'جایگزینی دیتابیس SQLite…');

                    return callApi('restore.db', { sid: sid }).then(function () {
                        restoreUi.label('در حال پاک‌سازی و نهایی‌سازی…');

                        return callApi('restore.finish', { sid: sid });
                    });
                }

                return step();
            });
        }

        return step();
    }

    function restoreFrom(name, skipEmergency) {
        restoreUi.state(null);
        restoreUi.show('بررسی فایل پشتیبان…');
        restoreUi.label('بررسی فایل پشتیبان…');

        callApi('restore.check', { file: name }).then(function (response) {
            if (!response.ok) {
                restoreUi.hide();
                var list = el('ul', 'br-error-list');
                (response.errors || ['خطای ناشناخته']).forEach(function (message) {
                    list.appendChild(el('li', null, message));
                });
                openModal('فایل پشتیبان معتبر نیست', list, [{ label: 'بستن' }]);
                return;
            }

            var body = manifestDetailsNode(response.details || {});
            var warn = el('div', 'br-modal-warn',
                'همه محتویات فعلی دیتابیس و پوشه بارگذاری‌ها با نسخه این پشتیبان جایگزین می‌شود؛ تنظیمات افزونه‌ها و پوسته‌ها، کاربران و تنظیمات عمومی نیز کامل بازمی‌گردند. پیش از ادامه، یک پشتیبان اضطراری از وضعیت فعلی ساخته می‌شود.');
            var container = el('div');
            container.appendChild(warn);
            container.appendChild(body);

            openModal('تأیید بازیابی', container, [
                { label: 'انصراف' },
                {
                    label: 'بازیابی',
                    className: 'br-btn-danger',
                    onClick: function () {
                        performRestore(name, !!skipEmergency);
                    }
                }
            ]);
        }).catch(function (error) {
            restoreUi.hide();
            toast('خطا در بررسی پشتیبان: ' + error.message, 'error');
        });
    }

    function performRestore(name, skipEmergency) {
        var emergencyPromise;

        if (skipEmergency) {
            emergencyPromise = Promise.resolve();
        } else {
            restoreUi.label('ساخت پشتیبان اضطراری…');
            restoreUi.show('ساخت پشتیبان اضطراری…');
            emergencyPromise = startBackup('emergency', {
                label: 'ساخت پشتیبان اضطراری…',
                progress: restoreUi,
                silent: true
            }).then(function (response) {
                toast('پشتیبان اضطراری ساخته شد: ' + (response.backup || {}).name, 'success');
            }, function (error) {
                throw new Error('ساخت پشتیبان اضطراری ناموفق بود؛ بازیابی ادامه پیدا نکرد: ' + error.message);
            });
        }

        emergencyPromise.then(function () {
            return callApi('restore.init', { file: name });
        }).then(function (response) {
            return runRestoreLoop(response.sid);
        }).then(function (response) {
            restoreUi.state('success');
            restoreUi.label('بازیابی کامل شد');
            restoreUi.update(100, 'کامل شد');

            var restored = response.restored || {};
            var cache = response.cache || {};
            var reconcile = response.reconcile || {};
            var body = el('div');
            var grid = el('dl', 'br-detail-grid');

            var fields = [
                ['فایل بازیابی‌شده', restored.file],
                ['فایل‌های بازگردانده‌شده', formatNumber(restored.files)],
                ['حجم بازگردانده‌شده', formatBytes(restored.bytes)],
                ['مدت عملیات', formatDuration(restored.duration)],
                ['پاک‌سازی کش', cache.cleared ? 'انجام شد (' + formatNumber(cache.entries) + ' مورد)' : 'غیرفعال بود']
            ];

            if (reconcile.prefixAdapted) {
                fields.push(['تطبیق پیشوند جدول‌ها', 'انجام شد']);
            }

            if (reconcile.keptUser) {
                fields.push(['نشست شما', 'حفظ شد (کاربر ' + reconcile.keptUser + ')']);
            }

            if (reconcile.reissuedLogin) {
                fields.push(['ورود خودکار', 'به مدیر «' + reconcile.reissuedLogin + '» از نسخه پشتیبان']);
            }

            fields.forEach(function (field) {
                var item = el('div', 'br-detail-item');
                item.appendChild(el('dt', null, field[0]));
                item.appendChild(el('dd', null, field[1]));
                grid.appendChild(item);
            });

            body.appendChild(grid);

            if (reconcile.reissuedLogin) {
                body.appendChild(el('p', 'br-modal-warn',
                    'چون کاربر فعلی در نسخه پشتیبان وجود نداشت، نشست شما به مدیر «' + reconcile.reissuedLogin + '» منتقل شد. برای ورود‌های بعدی از رمز عبور همان کاربر استفاده کنید.'));
            } else {
                body.appendChild(el('p', 'br-help',
                    'همه تنظیمات (افزونه‌ها، پوسته فعال، کاربران و تنظیمات عمومی) همراه محتوا بازگردانی شد.'));
            }

            openModal('بازیابی با موفقیت کامل شد', body, [
                { label: 'بستن', className: 'br-btn-primary' }
            ]);

            toast('بازیابی با موفقیت انجام شد', 'success');
            window.setTimeout(function () {
                // بارگذاری تازه صفحه برای اعمال داده‌های بازیابی‌شده
                window.location.reload();
            }, 2200);
        }).catch(function (error) {
            restoreUi.state('danger');
            restoreUi.label('بازیابی ناموفق بود');
            toast('خطا در بازیابی: ' + error.message, 'error', true);
        });
    }

    /* ============================== دراپ‌داون بازیابی (تب پیشخوان) ============================== */

    var restoreSelect = $('br-restore-select');
    var restoreStartButton = $('br-restore-start');

    if (restoreSelect) {
        restoreSelect.addEventListener('change', function () {
            if (restoreStartButton) {
                restoreStartButton.disabled = !restoreSelect.value;
            }
        });
    }

    if (restoreStartButton) {
        restoreStartButton.addEventListener('click', function () {
            var file = restoreSelect ? String(restoreSelect.value || '') : '';

            if (!file) {
                toast('ابتدا یک فایل پشتیبان انتخاب کنید', 'warning');
                return;
            }

            restoreFrom(file, false);
        });
    }

    /* ============================== Backups list ============================== */

    var backupsList = $('br-backups-list');
    var refreshBackupsButton = $('br-refresh-backups');

    function refreshBackupsList() {
        if (!urls.status) {
            return;
        }

        callApi('status').then(function () {
            gotoTab(currentActiveTab());
        }).catch(function (error) {
            toast('به‌روزرسانی فهرست ناموفق: ' + error.message, 'error');
        });
    }

    if (refreshBackupsButton) {
        refreshBackupsButton.addEventListener('click', refreshBackupsList);
    }

    /* ============================== Bulk delete (حذف دسته‌جمعی) ============================== */

    var bulkBar = $('br-bulk-bar');
    var bulkCountLabel = $('br-bulk-count');
    var bulkDeleteButton = $('br-bulk-delete');
    var bulkClearButton = $('br-bulk-clear');
    var checkAllBox = $('br-check-all');

    function rowCheckboxes() {
        return backupsList
            ? Array.prototype.slice.call(backupsList.querySelectorAll('input.br-row-check'))
            : [];
    }

    function selectedBackupFiles() {
        return rowCheckboxes()
            .filter(function (box) { return box.checked; })
            .map(function (box) { return box.value; });
    }

    function updateBulkBar() {
        var boxes = rowCheckboxes();
        var count = selectedBackupFiles().length;

        if (bulkBar) {
            bulkBar.hidden = count === 0;
        }

        if (bulkCountLabel) {
            bulkCountLabel.textContent = faDigits(count) + ' مورد انتخاب شده';
        }

        if (checkAllBox) {
            checkAllBox.checked = count > 0 && count === boxes.length;
        }
    }

    function clearBulkSelection() {
        rowCheckboxes().forEach(function (box) {
            box.checked = false;
        });

        if (checkAllBox) {
            checkAllBox.checked = false;
        }

        updateBulkBar();
    }

    if (checkAllBox) {
        checkAllBox.addEventListener('change', function () {
            rowCheckboxes().forEach(function (box) {
                box.checked = checkAllBox.checked;
            });

            updateBulkBar();
        });
    }

    if (backupsList) {
        backupsList.addEventListener('change', function (event) {
            if (event.target && event.target.classList && event.target.classList.contains('br-row-check')) {
                updateBulkBar();
            }
        });
    }

    if (bulkClearButton) {
        bulkClearButton.addEventListener('click', clearBulkSelection);
    }

    if (bulkDeleteButton) {
        bulkDeleteButton.addEventListener('click', function () {
            var files = selectedBackupFiles();

            if (files.length === 0) {
                toast('ابتدا حداقل یک فایل پشتیبان را انتخاب کنید', 'warning');
                return;
            }

            confirmModal(
                'حذف دسته‌جمعی',
                'آیا از حذف دائمی ' + faDigits(files.length) + ' فایل پشتیبان مطمئن هستید؟ این عملیات قابل بازگشت نیست.',
                function () {
                    bulkDeleteButton.disabled = true;

                    callApi('backup.deleteBatch', { files: JSON.stringify(files) }).then(function (response) {
                        var failed = (response.failedCount || 0);
                        var message = faDigits(response.deletedCount || 0) + ' فایل پشتیبان حذف شد';

                        if (failed > 0) {
                            message += ' — ' + faDigits(failed) + ' فایل به دلیل خطا حذف نشد (جزئیات در گزارش‌ها)';
                        }

                        toast(message, failed > 0 ? 'warning' : 'success');

                        window.setTimeout(function () {
                            gotoTab(currentActiveTab());
                        }, 800);
                    }).catch(function (error) {
                        bulkDeleteButton.disabled = false;
                        toast('حذف دسته‌جمعی ناموفق: ' + error.message, 'error');
                    });
                }
            );
        });
    }


    /* تابع دانلود بکاپ کامل حذف شد — بکاپ کامل مثل بکاپ عادی مستقیم از
       طریق window.location.href دانلود می‌شود. این تغییر به‌دلیل مشکل
       دانلود ناقص/۰ بایتی فایل‌های بزرگ همراه با باز شدن مودال انجام شد. */

    if (backupsList) {
        backupsList.addEventListener('click', function (event) {
            var button = event.target.closest('button');

            if (!button) {
                return;
            }

            var row = button.closest('tr[data-file]');

            if (!row || !row.getAttribute('data-file')) {
                return;
            }

            var file = row.getAttribute('data-file');
            var rowType = row.getAttribute('data-type') || 'backup';

            if (button.classList.contains('br-act-download')) {
                // بکاپ کامل هم مثل بکاپ عادی مستقیم دانلود می‌شود (مودال حذف شد
                // چون باعث ناقص شدن دانلود فایل‌های بزرگ می‌شد). برای بکاپ کامل
                // پارامتر once=1 ارسال می‌شود تا فایل در صف حذف ۲۴ ساعته قرار گیرد.
                var downloadUrl = urls['backup.download'] + '&file=' + encodeURIComponent(file);

                if (rowType === 'full') {
                    downloadUrl += '&once=1';
                }

                window.location.href = downloadUrl;
                return;
            }

            if (button.classList.contains('br-act-restore')) {
                restoreFrom(file, false);
                return;
            }

            if (button.classList.contains('br-act-note')) {
                openNoteEditor(file);
                return;
            }

            if (button.classList.contains('br-act-delete')) {
                confirmModal('حذف فایل پشتیبان', 'آیا از حذف دائمی فایل «' + file + '» مطمئن هستید؟ این عملیات قابل بازگشت نیست.', function () {
                    callApi('backup.delete', { file: file }).then(function () {
                        toast('فایل پشتیبان حذف شد', 'success');
                        window.setTimeout(refreshBackupsList, 500);
                    }).catch(function (error) {
                        toast('حذف ناموفق: ' + error.message, 'error');
                    });
                });
                return;
            }
        });
    }

    function confirmModal(title, message, onConfirm, onCancel) {
        /* کلاس jalali-converted-date جلوی تبدیل تاریخِ داخل نام فایل‌ها به شمسی
           را توسط افزونه JalaliDate می‌گیرد (نام فایل همیشه میلادی می‌ماند) */
        openModal(title, el('p', 'jalali-converted-date', message), [
            { label: 'انصراف', onClick: onCancel || null },
            { label: 'تأیید', className: 'br-btn-danger', onClick: onConfirm }
        ]);
    }

    /* ============================== Backup notes ============================== */

    function findBackupRow(file) {
        return backupsList ? backupsList.querySelector('tr[data-file="' + file + '"]') : null;
    }

    /* هم‌گام‌سازی ظاهر دکمه یادداشت ردیف با محتوای data-note */
    function syncNoteButton(row) {
        if (!row) {
            return;
        }

        var button = row.querySelector('.br-act-note');

        if (!button) {
            return;
        }

        var note = row.getAttribute('data-note') || '';

        button.classList.toggle('br-has-note', note !== '');
        button.title = note !== '' ? 'یادداشت: ' + note : 'یادداشت نسخه (اختیاری)';
        button.setAttribute('aria-label', button.title);

        var noteLine = row.querySelector('.br-note-line');

        if (noteLine) {
            if (note) {
                noteLine.textContent = 'یادداشت: ' + note;
                noteLine.hidden = false;
            } else {
                noteLine.textContent = '';
                noteLine.hidden = true;
            }
        }
    }

    function updateRowNote(file, note) {
        var row = findBackupRow(file);

        if (!row) {
            return;
        }

        if (note) {
            row.setAttribute('data-note', note);
        } else {
            row.removeAttribute('data-note');
        }

        syncNoteButton(row);
    }

    function openNoteEditor(file) {
        var row = findBackupRow(file);
        var currentNote = row ? String(row.getAttribute('data-note') || '') : '';

        var wrap = el('div', 'br-field');
        var label = el('label', 'br-label', 'یادداشت نسخه «' + file + '»');
        label.setAttribute('for', 'br-note-editor-area');

        var area = el('textarea', 'br-textarea');
        area.id = 'br-note-editor-area';
        area.rows = 4;
        area.maxLength = 500;
        area.value = currentNote;

        var hint = el('span', 'br-field-hint', 'حداکثر ۵۰۰ کاراکتر؛ با خالی گذاشتن یا حذف یادداشت، این متن از زیر نسخه پشتیبان برداشته می‌شود.');

        wrap.appendChild(label);
        wrap.appendChild(area);
        wrap.appendChild(hint);

        openModal('یادداشت نسخه پشتیبان', wrap, [
            { label: 'انصراف' },
            {
                label: 'حذف یادداشت',
                className: 'br-btn-danger-ghost',
                onClick: function () {
                    saveBackupNote(file, '');
                }
            },
            {
                label: 'ذخیره',
                className: 'br-btn-primary',
                keepOpen: true,
                onClick: function () {
                    saveBackupNote(file, String(area.value || '').trim());
                }
            }
        ]);

        window.setTimeout(function () {
            area.focus();
        }, 60);
    }

    function saveBackupNote(file, note) {
        callApi('note.save', { file: file, note: note }).then(function (response) {
            closeModal();
            updateRowNote(file, response.note || '');

            if (response.note) {
                toast('یادداشت نسخه پشتیبان ذخیره شد', 'success');
            } else {
                toast('یادداشت نسخه پشتیبان حذف شد', 'success');
            }
        }).catch(function (error) {
            toast('ذخیره یادداشت ناموفق: ' + error.message, 'error');
        });
    }


    /* ============================== Clipboard (کپی گزارش‌ها) ============================== */

    function fallbackCopyText(text) {
        try {
            var area = document.createElement('textarea');

            area.value = text;
            area.setAttribute('readonly', '');
            area.style.position = 'fixed';
            area.style.top = '-1000px';
            area.style.opacity = '0';
            document.body.appendChild(area);
            area.select();

            var done = document.execCommand('copy');

            document.body.removeChild(area);

            return done;
        } catch (e) {
            return false;
        }
    }

    function copyTextToClipboard(text) {
        return new Promise(function (resolve, reject) {
            if (navigator.clipboard && navigator.clipboard.writeText && window.isSecureContext) {
                navigator.clipboard.writeText(text).then(resolve, function () {
                    if (fallbackCopyText(text)) {
                        resolve();
                    } else {
                        reject(new Error('کپی انجام نشد'));
                    }
                });

                return;
            }

            if (fallbackCopyText(text)) {
                resolve();
            } else {
                reject(new Error('کپی انجام نشد'));
            }
        });
    }

    function copyLogText(text) {
        copyTextToClipboard(text).then(function () {
            toast('در کلیپ‌بورد کپی شد', 'success');
        }, function () {
            toast('کپی در کلیپ‌بورد ممکن نشد؛ متن را به‌صورت دستی انتخاب و کپی کنید', 'error');
        });
    }

    /* ============================== Logs tab ============================== */

    var logView = $('br-log-view');

    var LOG_LEVELS = {
        'موفق': 'success',
        'خطا': 'error',
        'هشدار': 'warning',
        'اطلاعات': 'info'
    };

    /* آیکون کپی هر خط گزارش */
    var COPY_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>';

    function logCopyButton() {
        var button = el('button', 'br-log-copy');
        button.type = 'button';
        button.title = 'کپی این خط';
        button.setAttribute('aria-label', 'کپی این خط');
        button.innerHTML = COPY_ICON;

        return button;
    }

    /* رندر ساختاریافته خط گزارش: [تاریخ] [سطح] [کاربر: …] پیام + دکمه کپی */
    function logLineNode(line) {
        var row = el('div', 'br-log-line');
        var match = /^\[([^\]]+)\]\s*\[([^\]]+)\]\s*([\s\S]*)$/.exec(line);

        row.setAttribute('data-copy', line);

        if (match) {
            /* کلاس jalali-converted-date نام فایل‌های داخل پیام را از تبدیل تاریخ
               شمسی توسط افزونه JalaliDate مصون نگه می‌دارد (نام فایل میلادی می‌ماند) */
            row.appendChild(el('span', 'br-log-date', match[1]));
            row.appendChild(el('span', 'br-log-level', match[2]));
            row.appendChild(el('span', 'br-log-msg jalali-converted-date', match[3]));

            if (LOG_LEVELS[match[2]]) {
                row.classList.add('br-log-' + LOG_LEVELS[match[2]]);
            }
        } else {
            row.appendChild(el('span', 'br-log-msg jalali-converted-date', line));
        }

        row.appendChild(logCopyButton());

        return row;
    }

    function renderLogs(lines) {
        if (!logView) {
            return;
        }

        while (logView.firstChild) {
            logView.removeChild(logView.firstChild);
        }

        if (!lines || lines.length === 0) {
            logView.appendChild(el('div', 'br-log-empty', 'گزارشی ثبت نشده است.'));
            return;
        }

        lines.forEach(function (line) {
            logView.appendChild(logLineNode(line));
        });

        logView.scrollTop = logView.scrollHeight;
    }


    if (logView) {
        logView.addEventListener('click', function (event) {
            var button = event.target.closest('button.br-log-copy');

            if (!button) {
                return;
            }

            var line = button.closest('.br-log-line');

            if (line) {
                copyLogText(line.getAttribute('data-copy') || '');
            }
        });
    }

    var logCopyAllButton = $('br-log-copy-all');

    if (logCopyAllButton) {
        logCopyAllButton.addEventListener('click', function () {
            if (!logView) {
                return;
            }

            var lines = Array.prototype.slice.call(logView.querySelectorAll('.br-log-line[data-copy]'))
                .map(function (line) { return line.getAttribute('data-copy') || ''; })
                .filter(function (text) { return text !== ''; });

            if (lines.length === 0) {
                toast('گزارشی برای کپی وجود ندارد', 'warning');
                return;
            }

            copyLogText(lines.join('\n'));
        });
    }

    var logRefreshButton = $('br-log-refresh');

    if (logRefreshButton) {
        logRefreshButton.addEventListener('click', function () {
            callApi('log.tail', null, 'GET').then(function (response) {
                renderLogs(response.lines);
            }).catch(function (error) {
                toast('دریافت گزارش ناموفق: ' + error.message, 'error');
            });
        });
    }

    var logClearButton = $('br-log-clear');

    if (logClearButton) {
        logClearButton.addEventListener('click', function () {
            confirmModal('پاک کردن گزارش‌ها', 'آیا از پاک کردن همه گزارش‌های ثبت‌شده مطمئن هستید؟', function () {
                callApi('log.clear', {}, 'POST').then(function () {
                    renderLogs([]);
                    toast('گزارش‌ها پاک شدند', 'success');
                }).catch(function (error) {
                    toast('پاک‌سازی ناموفق: ' + error.message, 'error');
                });
            });
        });
    }

    /* ============================== Init ============================== */

    // هشدار فضا در صورت کمبود شدید
    (function warnOnLowDisk() {
        var initial = config.initial || {};

        if (initial.diskTotal > 0 && initial.diskFree >= 0) {
            var uploadsBytes = (initial.uploads || {}).bytes || 0;
            var databaseSize = (initial.database || {}).size || 0;
            var needed = uploadsBytes + databaseSize + 52428800; // داده‌ها + ۵۰MB حاشیه

            if (initial.diskFree < needed) {
                toast('هشدار: فضای خالی دیسک (' + formatBytes(initial.diskFree) +
                    ') برای ساخت یک پشتیبان کامل کافی به نظر نمی‌رسد.', 'warning', true);
            }
        }
    })();

})();
