<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Manager;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class FileManager
{
    /**
     * فهرست بازگشتی فایل‌های یک پوشه.
     *
     * @param string $directory پوشه مبدأ
     *
     * @return array<int,array{path:string,relative:string,size:int}>
     *
     * @throws \RuntimeException در صورت عدم دسترسی به پوشه
     */
    public static function listFiles(string $directory): array
    {
        if (!is_dir($directory)) {
            throw new \RuntimeException('پوشه مورد نظر وجود ندارد: ' . $directory);
        }

        $files = [];
        $stack = [$directory];

        while ($stack !== []) {
            $current = array_pop($stack);
            $items = @scandir($current);

            if ($items === false) {
                continue;
            }

            foreach ($items as $item) {
                if ($item === '.' || $item === '..') {
                    continue;
                }

                $path = $current . '/' . $item;

                if (is_link($path)) {
                    continue;
                }

                if (is_dir($path)) {
                    $stack[] = $path;
                    continue;
                }

                if (!is_file($path) || !is_readable($path)) {
                    continue;
                }

                clearstatcache(true, $path);

                $files[] = [
                    'path'     => $path,
                    'relative' => self::relativeName($directory, $path),
                    'size'     => (int) filesize($path),
                ];
            }
        }

        return $files;
    }

    /**
     * محاسبه حجم کل و تعداد فایل‌های یک پوشه.
     *
     * @param string $directory پوشه
     *
     * @return array{files:int,bytes:int}
     */
    public static function usage(string $directory): array
    {
        if (!is_dir($directory)) {
            return ['files' => 0, 'bytes' => 0];
        }

        $files = 0;
        $bytes = 0;
        $stack = [$directory];

        while ($stack !== []) {
            $current = array_pop($stack);
            $items = @scandir($current);

            if ($items === false) {
                continue;
            }

            foreach ($items as $item) {
                if ($item === '.' || $item === '..') {
                    continue;
                }

                $path = $current . '/' . $item;

                if (is_link($path)) {
                    continue;
                }

                if (is_dir($path)) {
                    $stack[] = $path;
                } elseif (is_file($path)) {
                    clearstatcache(true, $path);
                    $files++;
                    $bytes += (int) filesize($path);
                }
            }
        }

        return ['files' => $files, 'bytes' => $bytes];
    }

    /**
     * ساخت بازگشتی پوشه با محافظت وب.
     *
     * @param string $directory مسیر پوشه
     *
     * @return void
     *
     * @throws \RuntimeException در صورت خطا
     */
    public static function ensureDirectory(string $directory): void
    {
        if (is_dir($directory)) {
            return;
        }

        if (!@mkdir($directory, 0755, true) && !is_dir($directory)) {
            throw new \RuntimeException('ساخت پوشه ممکن نشد: ' . $directory);
        }
    }

    /**
     * حذف بازگشتی محتویات یک پوشه (بدون حذف خود پوشه).
     *
     * @param string $directory مسیر پوشه
     *
     * @return void
     */
    public static function clearDirectory(string $directory): void
    {
        if (!is_dir($directory)) {
            return;
        }

        $items = @scandir($directory);

        if ($items === false) {
            return;
        }

        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }

            $path = $directory . '/' . $item;

            if (is_dir($path) && !is_link($path)) {
                self::removeDirectory($path);
            } else {
                @unlink($path);
            }
        }
    }

    /**
     * حذف کامل یک پوشه به صورت بازگشتی.
     *
     * @param string $directory مسیر پوشه
     *
     * @return void
     */
    public static function removeDirectory(string $directory): void
    {
        if (!is_dir($directory) || is_link($directory)) {
            return;
        }

        self::clearDirectory($directory);
        @rmdir($directory);
    }

    /**
     * انتقال امن یک پوشه به مسیر جدید (با کپی و حذف در صورت نیاز).
     *
     * @param string $source مسیر مبدأ
     * @param string $target مسیر مقصد
     *
     * @return void
     *
     * @throws \RuntimeException در صورت خطا
     */
    public static function moveDirectory(string $source, string $target): void
    {
        if (!is_dir($source)) {
            throw new \RuntimeException('پوشه مبدأ برای انتقال وجود ندارد: ' . $source);
        }

        if (is_dir($target)) {
            throw new \RuntimeException('پوشه مقصد از قبل وجود دارد: ' . $target);
        }

        if (@rename($source, $target)) {
            return;
        }

        // انتقال بین دیسک‌ها: کپی و حذف
        self::copyDirectory($source, $target);
        self::removeDirectory($source);
    }

    /**
     * کپی بازگشتی یک پوشه.
     *
     * @param string $source مسیر مبدأ
     * @param string $target مسیر مقصد
     *
     * @return void
     *
     * @throws \RuntimeException در صورت خطا
     */
    public static function copyDirectory(string $source, string $target): void
    {
        self::ensureDirectory($target);

        $items = @scandir($source);

        if ($items === false) {
            throw new \RuntimeException('خواندن پوشه مبدأ ناموفق بود: ' . $source);
        }

        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }

            $from = $source . '/' . $item;
            $to = $target . '/' . $item;

            if (is_link($from)) {
                continue;
            }

            if (is_dir($from)) {
                self::copyDirectory($from, $to);
            } elseif (is_file($from)) {
                if (!@copy($from, $to)) {
                    throw new \RuntimeException('کپی فایل ناموفق بود: ' . $from);
                }
            }
        }
    }

    /**
     * نام نسبی امن یک فایل نسبت به پوشه مبدأ.
     *
     * @param string $root پوشه مبدأ
     * @param string $path مسیر فایل
     *
     * @return string
     */
    private static function relativeName(string $root, string $path): string
    {
        $normalizedRoot = rtrim(str_replace('\\', '/', $root), '/');
        $normalizedPath = str_replace('\\', '/', $path);

        if (str_starts_with($normalizedPath, $normalizedRoot . '/')) {
            return substr($normalizedPath, strlen($normalizedRoot) + 1);
        }

        return basename($normalizedPath);
    }
}
