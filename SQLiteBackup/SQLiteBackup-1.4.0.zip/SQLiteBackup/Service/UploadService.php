<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Service;

use TypechoPlugin\SQLiteBackup\Core\Disk;
use TypechoPlugin\SQLiteBackup\Core\Logger;
use TypechoPlugin\SQLiteBackup\Core\Paths;
use TypechoPlugin\SQLiteBackup\Core\Security;
use TypechoPlugin\SQLiteBackup\Repository\BackupRepository;
use TypechoPlugin\SQLiteBackup\Text;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * بارگذاری فایل پشتیبان از پنل مدیریت.
 *
 * فایل آپلودی پیش از پذیرش، به‌طور کامل اعتبارسنجی می‌شود (ساختار ZIP،
 * وجود و اعتبار manifest و وجود دیتابیس) و سپس با نام استاندارد در
 * پوشه پشتیبان‌ها ذخیره و به فهرست اضافه می‌شود.
 */
final class UploadService
{
    /**
     * نام فیلد فرم آپلود.
     */
    public const FIELD_NAME = 'backupFile';

    /**
     * بیشترین طول نام فایل قابل پذیرش.
     */
    private const MAX_NAME_LENGTH = 180;

    /**
     * حجم بیشینه مجاز PHP برای آپلود (بایت) یا null در حالت نامحدود.
     *
     * @return int|null
     */
    public static function maxUploadBytes(): ?int
    {
        $limits = [];

        foreach (['upload_max_filesize', 'post_max_size'] as $key) {
            $raw = trim((string) ini_get($key));

            if ($raw === '' || $raw === '0' || $raw === '-1') {
                continue;
            }

            $bytes = self::parseIniBytes($raw);

            if ($bytes !== null && $bytes > 0) {
                $limits[] = $bytes;
            }
        }

        return $limits === [] ? null : min($limits);
    }

    /**
     * پذیرش و ذخیره فایل پشتیبان آپلود‌شده.
     *
     * @param array<string,mixed> $file داده فایل از $_FILES
     *
     * @return array<string,mixed> خلاصه فایل ذخیره‌شده
     *
     * @throws \RuntimeException در صورت خطای آپلود یا نامعتبر بودن فایل
     */
    public static function receive(array $file): array
    {
        $errorCode = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);

        if ($errorCode !== UPLOAD_ERR_OK) {
            throw new \RuntimeException(self::errorLabel($errorCode), 400);
        }

        $tmpName = (string) ($file['tmp_name'] ?? '');

        if ($tmpName === '' || !is_uploaded_file($tmpName)) {
            throw new \RuntimeException('فایل آپلودی در دسترس نیست', 400);
        }

        $size = (int) ($file['size'] ?? 0);
        $maxBytes = self::maxUploadBytes();

        if ($maxBytes !== null && $size > $maxBytes) {
            throw new \RuntimeException(
                'حجم فایل از سقف مجاز PHP بیشتر است (سقف فعلی: ' . Text::size($maxBytes) . ')',
                400
            );
        }

        if ($size <= 0) {
            throw new \RuntimeException('فایل آپلودی خالی است', 400);
        }

        // بررسی کفایت فضای دیسک پیش از ذخیرهٔ فایل (با پیام مشخص)
        Disk::assertEnough($size, 'بارگذاری فایل پشتیبان');

        $originalName = (string) ($file['name'] ?? '');
        $originalName = basename(str_replace('\\', '/', $originalName));

        if ($originalName === '' || strlen($originalName) > self::MAX_NAME_LENGTH) {
            throw new \RuntimeException('نام فایل آپلودی نامعتبر است', 400);
        }

        if (!preg_match('/\.zip$/i', $originalName)) {
            throw new \RuntimeException('فقط فایل‌های ZIP قابل بارگذاری هستند', 400);
        }

        // اعتبارسنجی کامل ساختار بسته پیش از هر ذخیره‌سازی
        $inspection = \TypechoPlugin\SQLiteBackup\Service\RestoreService::inspectUploadedArchive($tmpName);

        if (!$inspection['ok']) {
            throw new \RuntimeException(
                'این فایل یک بسته پشتیبان معتبر تهیه پشتیبان نیست: ' . implode('؛ ', $inspection['errors']),
                400
            );
        }

        $manifest = $inspection['manifest'];
        $type = (string) ($manifest['type'] ?? 'backup');

        if ($type === 'full') {
            throw new \RuntimeException(
                'بسته‌های «بکاپ کامل سایت» فقط برای بازگردانی اضطراری از طریق FTP هستند و در فهرست پشتیبان‌ها بازیابی نمی‌شوند',
                400
            );
        }

        // نام استاندارد: نام اصلی اگر الگوی امن داشته باشد، وگرنه نام جدید
        try {
            $name = Security::validateBackupName($originalName);
        } catch (\RuntimeException) {
            $name = BackupRepository::makeName($type === 'emergency' ? 'emergency' : 'backup');
        }

        $destination = Paths::backups() . '/' . $name;

        if (is_file($destination)) {
            $name = BackupRepository::makeName($type === 'emergency' ? 'emergency' : 'backup');
            $destination = Paths::backups() . '/' . $name;
        }

        Paths::ensureDirectory(Paths::backups());

        if (!@move_uploaded_file($tmpName, $destination)) {
            // در محیط‌هایی که move_uploaded_file محدود است (برخی CLI/تست‌ها)
            if (!@rename($tmpName, $destination) && !@copy($tmpName, $destination)) {
                $diskMessage = Disk::insufficientMessage('ذخیره فایل آپلودی ناموفق بود', 'بارگذاری فایل پشتیبان');

                throw new \RuntimeException($diskMessage ?? 'ذخیره فایل آپلودی در پوشه پشتیبان‌ها ناموفق بود', 500);
            }
        }

        @chmod($destination, 0644);

        clearstatcache(true, $destination);

        Logger::success('فایل پشتیبان از پنل بارگذاری شد', [
            'file' => $name,
            'size' => (int) filesize($destination),
            'type' => $type,
        ]);

        return [
            'name'    => $name,
            'type'    => $type === 'emergency' ? 'emergency' : 'backup',
            'size'    => (int) filesize($destination),
            'created' => (int) ($manifest['createdAtUnix'] ?? 0),
        ];
    }

    /**
     * تبدیل مقدار ini (مثل 8M یا 256K) به بایت.
     *
     * @param string $raw مقدار خام
     *
     * @return int|null
     */
    private static function parseIniBytes(string $raw): ?int
    {
        if (is_numeric($raw)) {
            return (int) $raw;
        }

        $value = (float) $raw;
        $unit = strtolower(substr(trim($raw), -1));

        return match ($unit) {
            'g'     => (int) ($value * 1073741824),
            'm'     => (int) ($value * 1048576),
            'k'     => (int) ($value * 1024),
            'b', '' => (int) $value,
            default => null,
        };
    }

    /**
     * پیام فارسی خطاهای آپلود PHP.
     *
     * @param int $code کد خطا
     *
     * @return string
     */
    private static function errorLabel(int $code): string
    {
        return match ($code) {
            UPLOAD_ERR_INI_SIZE => 'حجم فایل از سقف upload_max_filesize در تنظیمات PHP بیشتر است',
            UPLOAD_ERR_FORM_SIZE => 'حجم فایل از سقف تعیین‌شده در فرم بیشتر است',
            UPLOAD_ERR_PARTIAL => 'فایل به‌طور کامل دریافت نشد؛ دوباره تلاش کنید',
            UPLOAD_ERR_NO_FILE => 'فایلی برای بارگذاری انتخاب نشده است',
            UPLOAD_ERR_NO_TMP_DIR => 'پوشه موقت PHP روی سرور در دسترس نیست',
            UPLOAD_ERR_CANT_WRITE => 'نوشتن فایل روی سرور ناموفق بود',
            UPLOAD_ERR_EXTENSION => 'یک افزونه PHP بارگذاری فایل را متوقف کرد',
            default => 'خطای نامشخص در بارگذاری فایل',
        };
    }
}
