<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Service;

use TypechoPlugin\SQLiteBackup\Core\Disk;
use TypechoPlugin\SQLiteBackup\Core\Logger;
use TypechoPlugin\SQLiteBackup\Core\Paths;
use TypechoPlugin\SQLiteBackup\Repository\BackupRepository;
use TypechoPlugin\SQLiteBackup\Repository\SessionStore;
use TypechoPlugin\SQLiteBackup\Zip\PurePhpWriter;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * ساخت بکاپ کامل سایت از ریشه اصلی.
 *
 * ساختار آرشیو دقیقاً مطابق ساختار واقعی فایل‌ها و پوشه‌های سایت است
 * (index.php، admin/، var/، usr/... و خود config.inc.php) و دیتابیس
 * SQLite با همان نام فایل و همان مسیر داخل بسته قرار می‌گیرد؛ بنابراین
 * بازگردانی اضطراری از طریق FTP/فایل‌منیجر تنها با استخراج بسته در ریشه
 * سایت انجام می‌شود.
 *
 * برای بازگردانی پرمیشن‌های اصلی، فایل __permissions.json به همراه
 * اسکریپت restore-permissions.sh داخل بسته قرار داده می‌شود.
 *
 * پوشه usr/backups (بکاپ‌های افزونه) از بسته مستثنی است تا آرشیو
 * تو‌در‌تو و حجیم نشود.
 */
final class FullBackupService
{
    /**
     * بودجه زمانی هر گام (ثانیه).
     */
    private const STEP_BUDGET = 6;

    /**
     * بیشترین تعداد فایل در هر گام.
     */
    private const STEP_FILES = 400;

    /**
     * نام فایل manifest پرمیشن‌ها داخل بسته.
     */
    public const PERMISSIONS_ENTRY = '__permissions.json';

    /**
     * نام اسکریپت بازگردانی پرمیشن‌ها داخل بسته.
     */
    public const RESTORE_SCRIPT_ENTRY = 'restore-permissions.sh';

    /**
     * نام فایل راهنمای بازگردانی اضطراری.
     */
    public const README_ENTRY = 'README-EMERGENCY-RESTORE.txt';

    /**
     * آغاز ساخت بکاپ کامل.
     *
     * @param int    $uid  شناسه کاربر مدیر
     * @param string $note یادداشت اختیاری
     *
     * @return array{sid:string,totalFiles:int,totalBytes:int}
     *
     * @throws \RuntimeException در صورت خطا
     */
    public static function init(int $uid, string $note = ''): array
    {
        Paths::ensureDirectory(Paths::backups());
        Paths::ensureDirectory(Paths::sessions());

        if (!\TypechoPlugin\SQLiteBackup\Zip\ZipEngine::isSupported()) {
            throw new \RuntimeException('ساخت فایل ZIP به افزونه Zlib نیاز دارد');
        }

        $databaseInfo = DatabaseService::info();

        if (!$databaseInfo['isSqlite']) {
            throw new \RuntimeException(
                'بکاپ کامل برای دیتابیس SQLite طراحی شده است؛ دیتابیس فعلی (' . $databaseInfo['adapter'] . ') پشتیبانی نمی‌شود'
            );
        }

        $dbRelative = DatabaseService::relativeFile();

        if ($dbRelative === null || $dbRelative === '') {
            throw new \RuntimeException('مسیر فایل دیتابیس نسبت به ریشه سایت قابل تشخیص نیست');
        }

        // اسنپ‌شات دیتابیس در ابتدای عملیات (نقطه زمانی ثابت)
        $snapshotPath = Paths::sessions() . '/db-' . uniqid('', true) . '.sqlite';

        try {
            $snapshot = DatabaseService::backupTo($snapshotPath);
        } catch (\Throwable $e) {
            if (is_file($snapshotPath)) {
                @unlink($snapshotPath);
            }

            $diskMessage = Disk::insufficientMessage($e->getMessage(), 'بکاپ کامل سایت');

            throw new \RuntimeException($diskMessage ?? ('ساخت اسنپ‌شات دیتابیس ناموفق بود: ' . $e->getMessage()), 0, $e);
        }

        [$files, $permissions] = self::collectSiteFiles($dbRelative);

        $totalFiles = count($files) + 1; // + اسنپ‌شات دیتابیس
        $totalBytes = (int) $snapshot['size'];

        foreach ($files as $file) {
            $totalBytes += $file['size'];
        }

        // بکاپ کامل به اندازهٔ تقریبی کل سایت فضا لازم دارد؛ پیش از آغاز
        // بررسی می‌شود تا با پیام مشخص متوقف شود، نه در میانهٔ کار
        try {
            Disk::assertEnough($totalBytes, 'بکاپ کامل سایت');
        } catch (\RuntimeException $e) {
            if (is_file($snapshotPath)) {
                @unlink($snapshotPath);
            }

            Logger::error('بکاپ کامل سایت به دلیل کمبود فضای دیسک متوقف شد', [
                'needed' => $totalBytes,
            ]);

            throw $e;
        }

        $name = BackupRepository::makeName('full');

        $session = SessionStore::create('backup', [
            'uid'        => $uid,
            'type'       => 'full',
            'phase'      => 'files',
            'name'       => $name,
            'note'       => \TypechoPlugin\SQLiteBackup\Text::cut($note, \TypechoPlugin\SQLiteBackup\Repository\NoteRepository::MAX_LENGTH),
            'zipPath'    => Paths::sessions() . '/work-' . $name . '.part',
            'zipState'   => null,
            'queue'      => $files,
            'totalFiles' => $totalFiles,
            'totalBytes' => $totalBytes,
            'doneFiles'  => 0,
            'doneBytes'  => 0,
            'database'   => [
                'adapter' => $databaseInfo['adapter'],
                'engine'  => $databaseInfo['engine'],
                'size'    => $snapshot['size'],
                'sha256'  => $snapshot['sha256'],
                'method'  => $snapshot['method'],
                'source'  => $snapshotPath,
                'entry'   => $dbRelative,
                'path'    => $dbRelative,
                'prefix'  => DatabaseService::currentPrefix(),
            ],
            'permissions' => $permissions,
        ]);

        Logger::info('فرایند بکاپ کامل سایت آغاز شد', [
            'type'  => 'full',
            'files' => count($files),
            'bytes' => $totalBytes,
        ]);

        return [
            'sid'        => $session['sid'],
            'totalFiles' => $totalFiles,
            'totalBytes' => $totalBytes,
        ];
    }

    /**
     * اجرای یک گام از افزودن فایل‌ها به آرشیو.
     *
     * @param string $sid شناسه نشست
     *
     * @return array{done:bool,filesDone:int,filesTotal:int,bytesDone:int,bytesTotal:int,percent:int}
     *
     * @throws \RuntimeException در صورت خطا
     */
    public static function step(string $sid): array
    {
        $session = self::requireSession($sid);

        if ($session['phase'] !== 'files') {
            throw new \RuntimeException('فاز نشست برای اجرای گام فایل‌ها معتبر نیست');
        }

        // گارد فضای دیسک در میانهٔ عملیات (فضای اشتراکی ممکن است پر شود)
        $remainingBytes = max(0, (int) $session['totalBytes'] - (int) $session['doneBytes']);

        try {
            Disk::assertEnough($remainingBytes, 'ادامه بکاپ کامل');
        } catch (\RuntimeException $e) {
            self::abortOnDisk($sid, $session, 'بکاپ کامل سایت');
            throw $e;
        }

        $writer = new PurePhpWriter();
        $writer->begin((string) $session['zipPath'], $session['zipState']);

        $started = microtime(true);
        $queue = $session['queue'];
        $processed = 0;

        try {
            while ($queue !== [] && $processed < self::STEP_FILES) {
                if (microtime(true) - $started > self::STEP_BUDGET) {
                    break;
                }

                $file = array_shift($queue);
                $relative = (string) $file['relative'];

                try {
                    $writer->addFile((string) $file['path'], $relative);
                } catch (\Throwable $e) {
                    Logger::warning('افزودن فایل به بکاپ کامل ناموفق بود و نادیده گرفته شد', [
                        'file'  => $relative,
                        'error' => $e->getMessage(),
                    ]);
                    $session['totalFiles'] = max(1, (int) $session['totalFiles'] - 1);
                    continue;
                }

                $processed++;
                $session['doneFiles'] = (int) $session['doneFiles'] + 1;
                $session['doneBytes'] = (int) $session['doneBytes'] + (int) $file['size'];
            }

            $session['queue'] = $queue;
            $session['zipState'] = $writer->exportState();
            $writer->abort();

            SessionStore::save($sid, $session);
        } catch (\Throwable $e) {
            $writer->abort();

            $diskMessage = Disk::insufficientMessage($e->getMessage(), 'ادامه بکاپ کامل');

            if ($diskMessage !== null) {
                self::abortOnDisk($sid, $session, 'بکاپ کامل سایت');
                throw new \RuntimeException($diskMessage);
            }

            throw new \RuntimeException('خطا در افزودن فایل‌ها به بکاپ کامل: ' . $e->getMessage(), 0, $e);
        }

        $done = $queue === [];
        $totalFiles = max(1, (int) $session['totalFiles']);
        $totalBytes = max(1, (int) $session['totalBytes']);

        return [
            'done'       => $done,
            'filesDone'  => (int) $session['doneFiles'],
            'filesTotal' => $totalFiles,
            'bytesDone'  => (int) $session['doneBytes'],
            'bytesTotal' => $totalBytes,
            'percent'    => (int) floor(min(100, ($session['doneBytes'] / $totalBytes) * 100)),
        ];
    }

    /**
     * نهایی‌سازی بکاپ کامل.
     *
     * @param string $sid شناسه نشست
     *
     * @return array<string,mixed> خلاصه بکاپ ساخته‌شده
     *
     * @throws \RuntimeException در صورت خطا
     */
    public static function finalize(string $sid): array
    {
        $session = self::requireSession($sid);

        if ($session['phase'] !== 'files' || $session['queue'] !== []) {
            throw new \RuntimeException('همه فایل‌ها هنوز به آرشیو افزوده نشده‌اند');
        }

        $zipPath = (string) $session['zipPath'];
        $database = $session['database'];
        $dbEntry = (string) $database['entry'];

        // پیش از افزودن اسنپ‌شات دیتابیس و فایل‌های جانبی، فضای کافی بررسی می‌شود
        try {
            Disk::assertEnough((int) $database['size'] + 1048576, 'نهایی‌سازی بکاپ کامل');
        } catch (\RuntimeException $e) {
            self::abortOnDisk($sid, $session, 'نهایی‌سازی بکاپ کامل');
            throw $e;
        }

        $writer = new PurePhpWriter();
        $writer->begin($zipPath, $session['zipState']);

        try {
            // اسنپ‌شات دیتابیس دقیقاً در همان مسیر واقعی‌اش داخل بسته
            $writer->addFile((string) $database['source'], $dbEntry);

            $permissions = is_array($session['permissions'] ?? null) ? $session['permissions'] : [];
            $writer->addFromString(
                self::PERMISSIONS_ENTRY,
                self::encodePermissions($permissions),
                PurePhpWriter::METHOD_STORE
            );
            $writer->addFromString(
                self::RESTORE_SCRIPT_ENTRY,
                self::restoreScript($permissions),
                PurePhpWriter::METHOD_STORE
            );
            $writer->addFromString(self::README_ENTRY, self::readmeContent(), PurePhpWriter::METHOD_STORE);

            $manifest = ManifestService::build('full', $database, [
                'files' => (int) $session['totalFiles'] - 1,
                'bytes' => (int) $session['totalBytes'] - (int) $database['size'],
            ], [
                $dbEntry => [
                    'size'   => (int) $database['size'],
                    'sha256' => (string) $database['sha256'],
                ],
            ], [
                'permissionsEntry' => self::PERMISSIONS_ENTRY,
                'restoreScript'    => self::RESTORE_SCRIPT_ENTRY,
                'readmeEntry'      => self::README_ENTRY,
                'siteRoot'         => Paths::root(),
            ]);

            $writer->addFromString(
                ManifestService::ENTRY_NAME,
                ManifestService::serialize($manifest),
                PurePhpWriter::METHOD_STORE
            );
            $writer->finish();
        } catch (\Throwable $e) {
            $writer->abort();

            $diskMessage = Disk::insufficientMessage($e->getMessage(), 'نهایی‌سازی بکاپ کامل');

            if ($diskMessage !== null) {
                self::abortOnDisk($sid, $session, 'نهایی‌سازی بکاپ کامل');
                throw new \RuntimeException($diskMessage);
            }

            throw new \RuntimeException('نهایی‌سازی بکاپ کامل ناموفق بود: ' . $e->getMessage(), 0, $e);
        }

        clearstatcache(true, $zipPath);
        $size = (int) filesize($zipPath);

        $finalPath = Paths::backups() . '/' . (string) $session['name'];

        if (!@rename($zipPath, $finalPath)) {
            throw new \RuntimeException('انتقال فایل بکاپ کامل به پوشه نهایی ناموفق بود');
        }

        if (is_file((string) $database['source'])) {
            @unlink((string) $database['source']);
        }

        SessionStore::delete($sid);

        Logger::success('بکاپ کامل سایت با موفقیت ساخته شد', [
            'file'  => (string) $session['name'],
            'type'  => 'full',
            'size'  => $size,
            'files' => (int) $session['totalFiles'],
        ]);

        return [
            'name'     => (string) $session['name'],
            'type'     => 'full',
            'size'     => $size,
            'files'    => (int) $session['totalFiles'],
            'bytes'    => (int) $session['totalBytes'],
            'duration' => max(1, \TypechoPlugin\SQLiteBackup\Core\Clock::now() - (int) $session['createdAt']),
            'note'     => (string) ($session['note'] ?? ''),
            'manifest' => null,
        ];
    }

    /**
     * توقف عملیات به دلیل کمبود فضا و پاک‌سازی فایل‌های موقت.
     *
     * فایل ZIP ناقص بکاپ کامل می‌تواند بسیار بزرگ باشد؛ حذف فوری آن
     * جلوی پر ماندن دیسک را می‌گیرد.
     *
     * @param string              $sid         شناسه نشست
     * @param array<string,mixed> $session     داده نشست
     * @param string              $actionLabel برچسب عملیات برای گزارش
     *
     * @return void
     */
    private static function abortOnDisk(string $sid, array $session, string $actionLabel): void
    {
        if (!empty($session['zipPath']) && is_file((string) $session['zipPath'])) {
            @unlink((string) $session['zipPath']);
        }

        if (!empty($session['database']['source']) && is_file((string) $session['database']['source'])) {
            @unlink((string) $session['database']['source']);
        }

        SessionStore::delete($sid);

        Logger::error($actionLabel . ' به دلیل کمبود فضای دیسک متوقف و فایل‌های موقت پاک‌سازی شدند', [
            'file' => (string) ($session['name'] ?? ''),
        ]);
    }

    /**
     * لغو ساخت بکاپ کامل و پاک‌سازی فایل‌های موقت.
     *
     * @param string $sid شناسه نشست
     *
     * @return void
     */
    public static function cancel(string $sid): void
    {
        $session = SessionStore::load($sid);

        if ($session !== null && ($session['kind'] ?? '') === 'backup' && ($session['type'] ?? '') === 'full') {
            if (!empty($session['zipPath']) && is_file((string) $session['zipPath'])) {
                @unlink((string) $session['zipPath']);
            }

            if (!empty($session['database']['source']) && is_file((string) $session['database']['source'])) {
                @unlink((string) $session['database']['source']);
            }

            Logger::info('فرایند بکاپ کامل لغو شد');
        }

        SessionStore::delete($sid);
    }

    /**
     * فهرست فایل‌های سایت به‌همراه نقشه پرمیشن‌ها.
     *
     * پوشه بکاپ‌های افزونه، فایل دیتابیس زنده و فایل‌های جانبی موقت آن
     * (WAL/SHM/Journal) از فهرست مستثنی می‌شوند.
     *
     * @param string $dbRelative مسیر نسبی فایل دیتابیس
     *
     * @return array{0:array<int,array{relative:string,path:string,size:int}>,1:array<string,string>}
     */
    private static function collectSiteFiles(string $dbRelative): array
    {
        $root = Paths::root();
        $backupsDir = Paths::backups();
        $dbFile = DatabaseService::locateFile();
        $excluded = [];

        if ($dbFile !== null) {
            $normalizedDb = str_replace('\\', '/', $dbFile);
            $excluded[$normalizedDb] = true;

            foreach (['-wal', '-shm', '-journal'] as $suffix) {
                $excluded[$normalizedDb . $suffix] = true;
            }
        }

        $files = [];
        $permissions = ['.' => '0755'];
        $stack = [$root];

        while ($stack !== []) {
            $current = array_pop($stack);
            $items = @scandir($current);

            if ($items === false) {
                Logger::warning('خواندن پوشه در بکاپ کامل ناموفق بود', ['file' => basename($current)]);
                continue;
            }

            foreach ($items as $item) {
                if ($item === '.' || $item === '..') {
                    continue;
                }

                $path = $current . '/' . $item;
                $normalized = str_replace('\\', '/', $path);

                if ($normalized === $backupsDir) {
                    continue; // پوشه بکاپ‌های افزونه
                }

                if (is_link($path)) {
                    continue; // پیوندهای نمادین داخل بسته نمی‌آیند
                }

                $relative = ltrim(substr($normalized, strlen($root) + 1), '/');

                if (is_dir($path)) {
                    $permissions[$relative] = self::permsOf($path);
                    $stack[] = $path;
                    continue;
                }

                if (!is_file($path) || !is_readable($path)) {
                    continue;
                }

                if (isset($excluded[$normalized])) {
                    continue; // دیتابیس زنده به‌جای آن اسنپ‌شات ذخیره می‌شود
                }

                clearstatcache(true, $path);
                $permissions[$relative] = self::permsOf($path);
                $files[] = [
                    'relative' => $relative,
                    'path'     => $path,
                    'size'     => (int) filesize($path),
                ];
            }
        }

        return [$files, $permissions];
    }

    /**
     * پرمیشن یک مسیر به شکل مبنای ۸ (مثل 0644).
     *
     * @param string $path مسیر
     *
     * @return string
     */
    private static function permsOf(string $path): string
    {
        clearstatcache(true, $path);
        $perms = @fileperms($path);

        if ($perms === false) {
            return '0644';
        }

        return sprintf('%04o', $perms & 07777);
    }

    /**
     * ساخت محتوای JSON نقشه پرمیشن‌ها.
     *
     * @param array<string,string> $permissions نقشه مسیر => پرمیشن
     *
     * @return string
     */
    private static function encodePermissions(array $permissions): string
    {
        ksort($permissions);

        $payload = [
            'note'       => 'پرمیشن‌های اصلی فایل‌ها و پوشه‌ها هنگام ساخت بکاپ کامل',
            'generated'  => \TypechoPlugin\SQLiteBackup\Core\Clock::iso(),
            'count'      => count($permissions),
            'permissions' => $permissions,
        ];

        return (string) json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }

    /**
     * ساخت اسکریپت شل بازگردانی پرمیشن‌ها.
     *
     * @param array<string,string> $permissions نقشه مسیر => پرمیشن
     *
     * @return string
     */
    private static function restoreScript(array $permissions): string
    {
        $lines = [
            '#!/bin/sh',
            '# بازگردانی پرمیشن‌های اصلی سایت پس از استخراج بکاپ کامل',
            '# ساخته‌شده توسط افزونه تهیه پشتیبان — ' . \TypechoPlugin\SQLiteBackup\Core\Clock::iso(),
            '#',
            '# روش استفاده (در ریشه سایت، از طریق SSH):',
            '#   sh restore-permissions.sh',
            '#',
            'set -e',
            '',
        ];

        ksort($permissions);

        foreach ($permissions as $relative => $perm) {
            $safe = str_replace(['\\', '"', '$', '`'], ['\\\\', '\\"', '\\$', '\\`'], $relative);
            $lines[] = sprintf('chmod %s "%s"', $perm, $safe);
        }

        $lines[] = '';
        $lines[] = 'echo "پرمیشن‌های سایت با موفقیت بازگردانی شد."';

        return implode("\n", $lines) . "\n";
    }

    /**
     * محتوای راهنمای بازگردانی اضطراری.
     *
     * @return string
     */
    private static function readmeContent(): string
    {
        return <<<TXT
راهنمای بازگردانی اضطراری بکاپ کامل سایت
=================================================

این بسته توسط افزونه «تهیه پشتیبان» (نسخهٔ قدیمی BackupRestore) ساخته شده است و
شامل یک تصویر کامل از ریشه سایت است: همه فایل‌ها و پوشه‌ها با همان ساختار،
همراه با فایل دیتابیس SQLite با همان نام و همان مسیر قبلی.

بازگردانی اضطراری (فقط در شرایط بحرانی، از طریق FTP یا فایل‌منیجر هاست):

۱) محتوای کامل این بسته ZIP را در ریشه سایت استخراج کنید (همان جایی که
   index.php قرار دارد) و اجازه بازنویسی فایل‌ها را بدهید.

۲) پوشه usr/backups که در زمان ساخت بسته وجود نداشته، در صورت نیاز دوباره
   ساخته می‌شود؛ نیازی به اقدام نیست.

۳) اگر فایل‌منیجر شما پرمیشن‌های اصلی فایل‌ها را هنگام استخراج حفظ نکرده،
   برای بازگردانی دقیق پرمیشن‌ها از فایل restore-permissions.sh استفاده
   کنید (لیست کامل پرمیشن‌ها در __permissions.json موجود است).

۴) پس از استخراج، سایت بلافاصله با همان دیتابیس، همان کانفیگ، همان پوسته،
   همان افزونه‌ها و همان تنظیمات قبل بالا می‌آید؛ نیازی به نصب مجدد نیست.

نکته‌های مهم:
- این بسته برای بازگردانی از طریق پنل مدیریت طراحی نشده است.
- پس از دانلود، فایل ۲۴ ساعت دیگر به‌صورت خودکار از سرور حذف می‌شود؛
  آن را در جای امن نگه دارید.
- فایل config.inc.php همان نسخه‌ی زمان تهیه بکاپ است؛ اگر اطلاعات دیتابیس
  هاست جدید متفاوت است، پیش از استخراج آن را ویرایش کنید.

TXT . "\n" . 'تاریخ ساخت بسته: ' . \TypechoPlugin\SQLiteBackup\Core\Clock::jalali(
            \TypechoPlugin\SQLiteBackup\Core\Clock::now(),
            'Y/m/d - H:i'
        ) . ' (' . \TypechoPlugin\SQLiteBackup\Core\Clock::timezoneId() . ")\n";
    }

    /**
     * بارگذاری نشست بکاپ کامل با اعتبارسنجی.
     *
     * @param string $sid شناسه نشست
     *
     * @return array<string,mixed>
     *
     * @throws \RuntimeException در صورت نامعتبر بودن نشست
     */
    private static function requireSession(string $sid): array
    {
        $session = SessionStore::load($sid);

        if ($session === null || ($session['kind'] ?? '') !== 'backup' || ($session['type'] ?? '') !== 'full') {
            throw new \RuntimeException('نشست بکاپ کامل یافت نشد یا منقضی شده است', 404);
        }

        \TypechoPlugin\SQLiteBackup\Core\Security::assertSessionOwner($session);

        return $session;
    }
}
