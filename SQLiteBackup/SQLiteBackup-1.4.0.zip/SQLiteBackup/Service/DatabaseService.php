<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Service;

use Typecho\Db;
use TypechoPlugin\SQLiteBackup\Core\Logger;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class DatabaseService
{
    /**
     * نام فایل دیتابیس داخل آرشیو پشتیبان.
     */
    public const BACKUP_ENTRY = 'database.sqlite';

    /**
     * اطلاعات دیتابیس جاری سایت.
     *
     * @return array{adapter:string,isSqlite:bool,file:?string,size:int,engine:string}
     */
    public static function info(): array
    {
        try {
            $db = Db::get();
            $adapter = (string) $db->getAdapterName();
        } catch (\Throwable) {
            return [
                'adapter' => 'unknown',
                'isSqlite' => false,
                'file'    => null,
                'size'    => 0,
                'engine'  => '',
            ];
        }

        $isSqlite = stripos($adapter, 'sqlite') !== false;
        $file = null;
        $engine = '';

        if ($isSqlite) {
            $file = self::locateFile();
            $engine = self::engineVersion();
        }

        return [
            'adapter' => $adapter,
            'isSqlite' => $isSqlite,
            'file'    => $file,
            'size'    => ($file !== null && is_file($file)) ? (int) filesize($file) : 0,
            'engine'  => $engine,
        ];
    }

    /**
     * مسیر نسبی فایل دیتابیس نسبت به ریشه سایت.
     *
     * @return string|null
     */
    public static function relativeFile(): ?string
    {
        $file = self::locateFile();

        if ($file === null) {
            return null;
        }

        $root = \TypechoPlugin\SQLiteBackup\Core\Paths::root();
        $normalized = str_replace('\\', '/', $file);

        if (str_starts_with($normalized, $root . '/')) {
            return ltrim(substr($normalized, strlen($root) + 1), '/');
        }

        return null;
    }

    /**
     * مکان‌یابی مسیر فایل دیتابیس SQLite.
     *
     * @return string|null مسیر فایل یا null در صورت ناموفق بودن
     */
    public static function locateFile(): ?string
    {
        try {
            $db = Db::get();
            $config = $db->getConfig(Db::READ);

            if (isset($config->file) && is_string($config->file) && $config->file !== '') {
                $candidate = str_replace('\\', '/', $config->file);

                if (is_file($candidate)) {
                    return $candidate;
                }

                $absolute = rtrim(str_replace('\\', '/', __TYPECHO_ROOT_DIR__), '/') . '/' . ltrim($candidate, '/');

                if (is_file($absolute)) {
                    return $absolute;
                }
            }
        } catch (\Throwable) {
            // تلاش از طریق PRAGMA
        }

        return self::locateFileViaPragma();
    }

    /**
     * مکان‌یابی فایل دیتابیس از طریق PRAGMA database_list.
     *
     * @return string|null
     */
    private static function locateFileViaPragma(): ?string
    {
        try {
            $handle = Db::get()->selectDb(Db::READ);
        } catch (\Throwable) {
            return null;
        }

        try {
            if ($handle instanceof \PDO) {
                $statement = $handle->query('PRAGMA database_list');

                if ($statement === false) {
                    return null;
                }

                foreach ($statement->fetchAll(\PDO::FETCH_ASSOC) as $row) {
                    $file = $row['file'] ?? '';

                    if (is_string($file) && $file !== '' && str_ends_with($file, '.db')) {
                        return $file;
                    }
                }

                return null;
            }

            if ($handle instanceof \SQLite3) {
                $result = $handle->query('PRAGMA database_list');

                if ($result === false) {
                    return null;
                }

                while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
                    $file = $row['file'] ?? '';

                    if (is_string($file) && $file !== '' && str_ends_with($file, '.db')) {
                        return $file;
                    }
                }
            }
        } catch (\Throwable) {
            return null;
        }

        return null;
    }

    /**
     * نسخه موتور SQLite فعال.
     *
     * @return string
     */
    private static function engineVersion(): string
    {
        if (class_exists('SQLite3')) {
            return (string) \SQLite3::version()['versionString'];
        }

        if (class_exists('PDO') && in_array('sqlite', \PDO::getAvailableDrivers(), true)) {
            try {
                $temp = tempnam(sys_get_temp_dir(), 'sqlitever');

                if ($temp === false) {
                    return '';
                }

                $pdo = new \PDO('sqlite:' . $temp);
                $version = (string) $pdo->query('select sqlite_version()')->fetchColumn();
                unset($pdo);
                @unlink($temp);

                return $version;
            } catch (\Throwable) {
                return '';
            }
        }

        return '';
    }

    /**
     * ساخت نسخه پشتیبان سازگار از دیتابیس جاری.
     *
     * @param string $destPath مسیر فایل مقصد
     *
     * @return array{size:int,sha256:string,method:string}
     *
     * @throws \RuntimeException در صورت عدم پشتیبانی یا خطا
     */
    public static function backupTo(string $destPath): array
    {
        $source = self::locateFile();

        if ($source === null || !is_file($source)) {
            throw new \RuntimeException('فایل دیتابیس SQLite یافت نشد؛ سایت از SQLite استفاده نمی‌کند');
        }

        if (is_file($destPath)) {
            @unlink($destPath);
        }

        $method = 'copy';

        if (class_exists('SQLite3')) {
            $method = 'sqlite3-backup';

            try {
                $src = new \SQLite3($source, SQLITE3_OPEN_READONLY);
                $dst = new \SQLite3($destPath);
                $result = $src->backup($dst);
                $src->close();
                $dst->close();

                if ($result === false) {
                    throw new \RuntimeException('خطا در API پشتیبان SQLite3');
                }

                return self::snapshotResult($destPath, $method);
            } catch (\Throwable $e) {
                Logger::warning('روش SQLite3::backup ناموفق بود؛ روش جایگزین امتحان می‌شود', [
                    'error' => $e->getMessage(),
                ]);
            }
        }

        // روش دوم: VACUUM INTO از طریق اتصال جاری
        try {
            $handle = Db::get()->selectDb(Db::READ);

            if ($handle instanceof \PDO) {
                $handle->exec('VACUUM INTO ' . $handle->quote($destPath));

                if (is_file($destPath) && filesize($destPath) > 0) {
                    return self::snapshotResult($destPath, 'vacuum-into');
                }
            }
        } catch (\Throwable $e) {
            Logger::warning('روش VACUUM INTO ناموفق بود؛ کپی قفل‌شده امتحان می‌شود', [
                'error' => $e->getMessage(),
            ]);
        }

        // روش سوم: کپی خام با قفل انحصاری و ادغام WAL
        self::copyWithLock($source, $destPath);

        return self::snapshotResult($destPath, 'locked-copy');
    }

    /**
     * جایگزینی امن دیتابیس جاری با فایل بازیابی‌شده.
     *
     * @param string $sourcePath مسیر فایل دیتابیس سالم بازیابی‌شده
     *
     * @return void
     *
     * @throws \RuntimeException در صورت خطا یا خرابی فایل منبع
     */
    public static function restoreFrom(string $sourcePath): void
    {
        if (!is_file($sourcePath) || !is_readable($sourcePath)) {
            throw new \RuntimeException('فایل دیتابیس بازیابی‌شده در دسترس نیست');
        }

        self::assertIntegrity($sourcePath);

        $target = self::locateFile();

        if ($target === null || !is_file($target)) {
            throw new \RuntimeException('فایل دیتابیس جاری سایت برای جایگزینی یافت نشد');
        }

        if (class_exists('SQLite3')) {
            try {
                $src = new \SQLite3($sourcePath, SQLITE3_OPEN_READONLY);
                $dst = new \SQLite3($target);
                $result = $src->backup($dst);
                $src->close();
                $dst->close();

                if ($result === false) {
                    throw new \RuntimeException('خطا در API پشتیبان SQLite3');
                }

                self::assertIntegrity($target);
                Logger::success('دیتابیس SQLite با موفقیت جایگزین شد (روش API پشتیبان)');

                return;
            } catch (\Throwable $e) {
                Logger::warning('جایگزینی با API پشتیبان ناموفق بود؛ روش کپی مستقیم اجرا می‌شود', [
                    'error' => $e->getMessage(),
                ]);
            }
        }

        // روش جایگزین: قفل انحصاری و کپی مستقیم
        $lock = fopen($target, 'c+b');

        if ($lock === false) {
            throw new \RuntimeException('باز کردن فایل دیتابیس جاری برای جایگزینی ناموفق بود');
        }

        $locked = flock($lock, LOCK_EX);

        try {
            if (!$locked) {
                throw new \RuntimeException('قفل‌گذاری روی دیتابیس جاری ممکن نشد');
            }

            copy($sourcePath, $target);

            // حذف فایل‌های جانبی WAL/SHM مربوط به فایل قبلی
            foreach (['-wal', '-shm', '-journal'] as $suffix) {
                $sidecar = $target . $suffix;

                if (is_file($sidecar)) {
                    @unlink($sidecar);
                }
            }

            fflush($lock);
            flock($lock, LOCK_UN);
        } finally {
            fclose($lock);
        }

        self::assertIntegrity($target);
        Logger::success('دیتابیس SQLite با موفقیت جایگزین شد (روش کپی قفل‌شده)');
    }

    /**
     * آشتی‌دادن دیتابیس بازیابی‌شده با نصب جاری (بازگردانی هوشمند).
     *
     * پس از جایگزینی فایل دیتابیس، سه ناسازگاری بالقوه بین نسخه پشتیبان و
     * نصب جاری به وجود می‌آید که این متد همه را برطرف می‌کند:
     *
     *  ۱) پیشوند جدول‌ها: اگر نصب جاری پیشوندی متفاوت با نسخه پشتیبان
     *     داشته باشد، جدول‌ها به پیشوند جاری تغییر نام می‌دهند تا
     *     config.inc.php نصب جدید بدون تغییر با آن‌ها کار کند.
     *
     *  ۲) کلید secret: کلید امنیتی نصب جاری حفظ می‌شود تا توکن‌های CSRF
     *     صفحه باز و کوکی نشست کاربر اعتبار خود را از دست ندهند.
     *
     *  ۳) نشست مدیر: authCode کاربر جاری در دیتابیس بازیابی‌شده بازنویسی
     *     می‌شود؛ اگر شناسه کاربر جاری در نسخه پشتیبان وجود نداشته باشد،
     *     کوکی‌های جدید برای نخستین مدیر نسخه پشتیبان صادر می‌شود.
     *
     * @param array{uid:int,authCode:string,secret:string,userName:string} $current اطلاعات نشست جاری پیش از بازیابی
     * @param string|null $backupPrefix پیشوند جدول‌های نسخه پشتیبان (از manifest یا کشف خودکار)
     *
     * @return array{prefixAdapted:bool,reissuedLogin:?string,reissuedUid:int,keptUser:?string}
     *
     * @throws \RuntimeException در صورت خطای دیتابیس
     */
    public static function reconcileAfterRestore(array $current, ?string $backupPrefix = null): array
    {
        $db = Db::get();
        $currentPrefix = self::currentPrefix();
        $backupPrefix = $backupPrefix !== null && $backupPrefix !== '' ? $backupPrefix : self::detectPrefix();

        $prefixAdapted = false;

        if ($backupPrefix !== null && $backupPrefix !== $currentPrefix) {
            self::renameTables($backupPrefix, $currentPrefix);
            $prefixAdapted = true;
            Logger::info('پیشوند جدول‌های نسخه پشتیبان با نصب جاری تطبیق یافت', [
                'prefix' => $backupPrefix . ' ← ' . $currentPrefix,
            ]);
        }

        // حفظ کلید امنیتی نصب جاری برای اعتبار نشست و توکن‌های فعلی
        if ($current['secret'] !== '') {
            $db->query(
                $db->update('table.options')
                    ->rows(['value' => $current['secret']])
                    ->where('name = ?', 'secret')
            );
        }

        $reissuedLogin = null;
        $reissuedUid = 0;
        $keptUser = null;

        $uid = (int) $current['uid'];

        if ($uid > 0) {
            $row = $db->fetchRow(
                $db->select()->from('table.users')
                    ->where('uid = ?', $uid)
                    ->limit(1)
            );

            if ($row !== null && (int) $row['uid'] === $uid) {
                // نشست جاری به کاربری با همین شناسه در نسخه پشتیبان نگاشت می‌شود
                $db->query(
                    $db->update('table.users')
                        ->rows(['authCode' => $current['authCode']])
                        ->where('uid = ?', $uid)
                );
                $keptUser = (string) $row['name'];

                Logger::info('نشست مدیر جاری روی کاربر نسخه پشتیبان نگاشت شد', [
                    'user' => $keptUser,
                ]);
            }
        }

        if ($keptUser === null) {
            // شناسه کاربر جاری در نسخه پشتیبان وجود ندارد؛
            // ورود خودکار به نخستین مدیر نسخه پشتیبان
            $admin = $db->fetchRow(
                $db->select()->from('table.users')
                    ->where('`group` = ?', 'administrator')
                    ->order('table.users.uid', Db::SORT_ASC)
                    ->limit(1)
            );

            if ($admin !== null) {
                $authCode = bin2hex(random_bytes(16));

                $db->query(
                    $db->update('table.users')
                        ->rows(['authCode' => $authCode])
                        ->where('uid = ?', (int) $admin['uid'])
                );

                $expire = 0;
                \Typecho\Cookie::set('__typecho_uid', (string) $admin['uid'], $expire);
                \Typecho\Cookie::set('__typecho_authCode', \Typecho\Common::hash($authCode), $expire);

                $reissuedLogin = (string) $admin['name'];
                $reissuedUid = (int) $admin['uid'];

                Logger::info('ورود خودکار به مدیر نسخه پشتیبان انجام شد', [
                    'user' => $reissuedLogin,
                ]);
            } else {
                Logger::warning('هیچ مدیری در دیتابیس بازیابی‌شده یافت نشد؛ نشست جاری باطل شد');
            }
        }

        return [
            'prefixAdapted' => $prefixAdapted,
            'reissuedLogin' => $reissuedLogin,
            'reissuedUid'   => $reissuedUid,
            'keptUser'      => $keptUser,
        ];
    }

    /**
     * اطلاعات نشست و کلید امنیتی جاری برای بازگردانی هوشمند.
     *
     * @return array{uid:int,authCode:string,secret:string,userName:string}
     */
    public static function currentSessionInfo(): array
    {
        $info = [
            'uid'       => 0,
            'authCode'  => '',
            'secret'    => '',
            'userName'  => '',
        ];

        try {
            $db = Db::get();

            $secret = $db->fetchRow(
                $db->select()->from('table.options')
                    ->where('name = ?', 'secret')
                    ->limit(1)
            );

            if ($secret !== null) {
                $info['secret'] = (string) $secret['value'];
            }

            $user = \Widget\User::alloc();

            if ($user->hasLogin()) {
                $info['uid'] = (int) $user->uid;
                $info['userName'] = (string) $user->name;

                $row = $db->fetchRow(
                    $db->select()->from('table.users')
                        ->where('uid = ?', $info['uid'])
                        ->limit(1)
                );

                if ($row !== null) {
                    $info['authCode'] = (string) $row['authCode'];
                }
            }
        } catch (\Throwable $e) {
            Logger::warning('خواندن اطلاعات نشست جاری ناموفق بود', ['error' => $e->getMessage()]);
        }

        return $info;
    }

    /**
     * پیشوند جدول‌های اتصال جاری.
     *
     * @return string
     */
    public static function currentPrefix(): string
    {
        try {
            return (string) Db::get()->getPrefix();
        } catch (\Throwable) {
            return '';
        }
    }

    /**
     * کشف پیشوند جدول‌های یک دیتابیس بازیابی‌شده.
     *
     * @return string|null
     */
    public static function detectPrefix(): ?string
    {
        $tables = self::listTables();

        foreach ($tables as $table) {
            if (preg_match('/^(.+)_users$/', $table, $match) === 1) {
                return $match[1] . '_';
            }
        }

        return null;
    }

    /**
     * فهرست جدول‌های دیتابیس جاری.
     *
     * @return array<int,string>
     */
    public static function listTables(): array
    {
        $tables = [];

        try {
            $handle = Db::get()->selectDb(Db::READ);

            if ($handle instanceof \PDO) {
                $statement = $handle->query("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name");

                if ($statement !== false) {
                    foreach ($statement->fetchAll(\PDO::FETCH_COLUMN) as $table) {
                        if (is_string($table) && !str_starts_with($table, 'sqlite_')) {
                            $tables[] = $table;
                        }
                    }
                }
            } elseif ($handle instanceof \SQLite3) {
                $result = $handle->query("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name");

                if ($result !== false) {
                    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
                        $table = (string) ($row['name'] ?? '');

                        if ($table !== '' && !str_starts_with($table, 'sqlite_')) {
                            $tables[] = $table;
                        }
                    }
                }
            }
        } catch (\Throwable $e) {
            Logger::warning('فهرست‌کردن جدول‌های دیتابیس ناموفق بود', ['error' => $e->getMessage()]);
        }

        return $tables;
    }

    /**
     * تغییر نام جدول‌ها از پیشوند نسخه پشتیبان به پیشوند جاری.
     *
     * @param string $from پیشوند مبدأ
     * @param string $to   پیشوند مقصد
     *
     * @return void
     *
     * @throws \RuntimeException در صورت خطا
     */
    private static function renameTables(string $from, string $to): void
    {
        $handle = Db::get()->selectDb(Db::WRITE);

        foreach (self::listTables() as $table) {
            if (!str_starts_with($table, $from)) {
                continue;
            }

            $newName = $to . substr($table, strlen($from));
            $quotedFrom = '"' . str_replace('"', '""', $table) . '"';
            $quotedTo = '"' . str_replace('"', '""', $newName) . '"';
            $sql = 'ALTER TABLE ' . $quotedFrom . ' RENAME TO ' . $quotedTo;

            if ($handle instanceof \PDO) {
                if ($handle->exec($sql) === false) {
                    throw new \RuntimeException('تغییر نام جدول ناموفق بود: ' . $table);
                }
            } elseif ($handle instanceof \SQLite3) {
                if (!$handle->exec($sql)) {
                    throw new \RuntimeException('تغییر نام جدول ناموفق بود: ' . $table);
                }
            } else {
                throw new \RuntimeException('اتصال دیتابیس برای تغییر نام جدول‌ها در دسترس نیست');
            }
        }
    }

    /**
     * بررسی سلامت ساختاری یک فایل دیتابیس SQLite.
     *
     * @param string $path مسیر فایل
     *
     * @return void
     *
     * @throws \RuntimeException در صورت خرابی فایل
     */
    public static function assertIntegrity(string $path): void
    {
        if (class_exists('SQLite3')) {
            $db = new \SQLite3($path, SQLITE3_OPEN_READONLY);
            $result = $db->querySingle('PRAGMA integrity_check');
            $error = $db->lastErrorMsg();
            $db->close();

            if ($result !== 'ok') {
                throw new \RuntimeException(
                    'بررسی سلامت دیتابیس ناموفق بود: ' . ($result ?: $error)
                );
            }

            return;
        }

        try {
            $pdo = new \PDO('sqlite:' . $path);
            $result = $pdo->query('PRAGMA integrity_check')->fetchColumn();
            unset($pdo);

            if ($result !== 'ok') {
                throw new \RuntimeException('بررسی سلامت دیتابیس ناموفق بود: ' . (string) $result);
            }
        } catch (\PDOException $e) {
            throw new \RuntimeException('بررسی سلامت دیتابیس ناموفق بود: ' . $e->getMessage());
        }
    }

    /**
     * کپی خام فایل دیتابیس با قفل و ادغام WAL.
     *
     * @param string $source مسیر مبدأ
     * @param string $dest   مسیر مقصد
     *
     * @return void
     *
     * @throws \RuntimeException در صورت خطا
     */
    private static function copyWithLock(string $source, string $dest): void
    {
        $lock = fopen($source, 'rb');

        if ($lock === false) {
            throw new \RuntimeException('خواندن فایل دیتابیس ناموفق بود');
        }

        flock($lock, LOCK_SH);

        try {
            // ادغام WAL (در صورت وجود) با اجرای یک checkpoint روی اتصال موقت
            if (is_file($source . '-wal') && class_exists('SQLite3')) {
                try {
                    $db = new \SQLite3($source, SQLITE3_OPEN_READONLY);
                    $db->exec('PRAGMA wal_checkpoint(TRUNCATE)');
                    $db->close();
                } catch (\Throwable) {
                    // بی‌خیال؛ کپی مستقیم انجام می‌شود
                }
            }

            if (!@copy($source, $dest)) {
                throw new \RuntimeException('کپی فایل دیتابیس ناموفق بود');
            }
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }

        if (!is_file($dest) || (int) filesize($dest) === 0) {
            throw new \RuntimeException('فایل پشتیبان دیتابیس ساخته نشد');
        }
    }

    /**
     * ساخت نتیجه snapshot همراه با checksum.
     *
     * @param string $path   مسیر فایل
     * @param string $method روش استفاده‌شده
     *
     * @return array{size:int,sha256:string,method:string}
     */
    private static function snapshotResult(string $path, string $method): array
    {
        clearstatcache(true, $path);

        return [
            'size'   => (int) filesize($path),
            'sha256' => hash_file('sha256', $path) ?: '',
            'method' => $method,
        ];
    }
}
