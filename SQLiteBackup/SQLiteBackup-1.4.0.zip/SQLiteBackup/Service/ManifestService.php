<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Service;

use Typecho\Common;
use TypechoPlugin\SQLiteBackup\Core\Clock;
use TypechoPlugin\SQLiteBackup\Core\Paths;
use TypechoPlugin\SQLiteBackup\Manager\FileManager;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class ManifestService
{
    /**
     * نسخه ساخت فایل پشتیبان.
     */
    public const FORMAT_VERSION = 1;

    /**
     * نام مدخل manifest داخل آرشیو.
     */
    public const ENTRY_NAME = 'manifest.json';

    /**
     * ساخت ساختار manifest.
     *
     * @param string              $type        نوع پشتیبان (backup، emergency یا full)
     * @param array<string,mixed> $database    اطلاعات دیتابیس
     * @param array<string,mixed> $uploads     اطلاعات بارگذاری‌ها
     * @param array<string,mixed> $checksums   نقشه checksum مدخل‌ها
     * @param array<string,mixed> $extra       داده‌های اضافی
     *
     * @return array<string,mixed>
     */
    public static function build(
        string $type,
        array $database,
        array $uploads,
        array $checksums,
        array $extra = []
    ): array {
        $totalFiles = (int) $uploads['files'] + 1;
        $totalBytes = (int) $uploads['bytes'] + (int) $database['size'];

        $normalizedType = match ($type) {
            'emergency' => 'emergency',
            'full'      => 'full',
            default     => 'backup',
        };

        $manifest = [
            'formatVersion'  => self::FORMAT_VERSION,
            'generator'      => 'SQLiteBackup',
            'pluginVersion'  => \TypechoPlugin\SQLiteBackup\Core\PluginInfo::VERSION,
            'type'           => $normalizedType,
            'createdAt'      => Clock::iso(),
            'createdAtUnix'  => Clock::now(),
            'timezone'       => Clock::timezoneId(),
            'platform'       => Common::SOFTWARE,
            'platformVersion' => Common::VERSION,
            'phpVersion'     => PHP_VERSION,
            'database'       => [
                'type'   => $database['adapter'] ?? 'SQLite',
                'engine' => $database['engine'] ?? '',
                'file'   => $database['entry'] ?? DatabaseService::BACKUP_ENTRY,
                'path'   => (string) ($database['path'] ?? ''),
                'prefix' => (string) ($database['prefix'] ?? ''),
                'size'   => (int) ($database['size'] ?? 0),
                'sha256' => (string) ($database['sha256'] ?? ''),
                'method' => (string) ($database['method'] ?? ''),
            ],
            'uploads'        => [
                'path'  => 'uploads/',
                'files' => (int) ($uploads['files'] ?? 0),
                'bytes' => (int) ($uploads['bytes'] ?? 0),
            ],
            'totalFiles'     => $totalFiles,
            'totalBytes'     => $totalBytes,
            'entries'        => $checksums,
        ];

        if ($extra !== []) {
            $manifest = array_merge($manifest, $extra);
        }

        // حجم نهایی فایل پشتیبان پس از ساخت آرشیو افزوده می‌شود
        if (isset($extra['backupSize'])) {
            $manifest['backupSize'] = (int) $extra['backupSize'];
        }

        $manifest['checksum'] = self::computeChecksum($manifest);

        return $manifest;
    }

    /**
     * محاسبه checksum خودارجاع manifest.
     *
     * فیلد checksum خودش در محاسبه لحاظ نمی‌شود.
     *
     * @param array<string,mixed> $manifest ساختار manifest
     *
     * @return string
     */
    public static function computeChecksum(array $manifest): string
    {
        $data = $manifest;
        unset($data['checksum']);

        return hash('sha256', self::canonicalJson($data));
    }

    /**
     * اعتبارسنجی کامل یک manifest بازیابی‌شده.
     *
     * @param array<string,mixed> $manifest ساختار manifest
     *
     * @return array{ok:bool,errors:array<int,string>}
     */
    public static function validate(array $manifest): array
    {
        $errors = [];

        if ((int) ($manifest['formatVersion'] ?? 0) !== self::FORMAT_VERSION) {
            $errors[] = 'نسخه ساخت فایل پشتیبان پشتیبانی نمی‌شود';
        }

        // پذیرش generator از نسخه‌های جدید (SQLiteBackup) و قدیمی (BackupRestore)
        // برای حفظ سازگاری بکاپ‌های ساخته‌شده با نسخه‌های پیشین.
        $generator = (string) ($manifest['generator'] ?? '');

        if ($generator !== 'SQLiteBackup' && $generator !== 'BackupRestore') {
            $errors[] = 'این فایل پشتیبان توسط افزونه تهیه پشتیبان (یا نسخهٔ پیشین BackupRestore) ساخته نشده است';
        }

        if (!isset($manifest['createdAt']) || !is_string($manifest['createdAt'])) {
            $errors[] = 'تاریخ ساخت در فایل پشتیبان ثبت نشده است';
        }

        if (!isset($manifest['checksum']) || !is_string($manifest['checksum'])) {
            $errors[] = 'فیلد checksum در فایل پشتیبان وجود ندارد';
        }

        if (!isset($manifest['database']) || !is_array($manifest['database'])) {
            $errors[] = 'اطلاعات دیتابیس در فایل پشتیبان وجود ندارد';
        }

        if (!isset($manifest['uploads']) || !is_array($manifest['uploads'])) {
            $errors[] = 'اطلاعات بارگذاری‌ها در فایل پشتیبان وجود ندارد';
        }

        if ($errors !== []) {
            return ['ok' => false, 'errors' => $errors];
        }

        $expected = self::computeChecksum($manifest);

        if (!hash_equals($expected, (string) $manifest['checksum'])) {
            $errors[] = 'checksum فایل پشتیبان با محتوای آن مطابقت ندارد؛ فایل دستکاری یا خراب شده است';
            return ['ok' => false, 'errors' => $errors];
        }

        return ['ok' => true, 'errors' => []];
    }

    /**
     * تبدیل manifest به رشته JSON ذخیره‌شده در آرشیو.
     *
     * @param array<string,mixed> $manifest ساختار manifest
     *
     * @return string
     */
    public static function serialize(array $manifest): string
    {
        return self::canonicalJson($manifest);
    }

    /**
     * تجزیه manifest از رشته JSON.
     *
     * @param string $json رشته JSON
     *
     * @return array<string,mixed>|null
     */
    public static function parse(string $json): ?array
    {
        $decoded = json_decode($json, true);

        if (!is_array($decoded)) {
            return null;
        }

        return $decoded;
    }

    /**
     * محاسبه حجم نهایی پشتیبان (به‌روزرسانی manifest قبل از نهایی‌سازی).
     *
     * @param array<string,mixed> $manifest  ساختار manifest
     * @param int                 $blockSize حجم فایل ZIP نهایی
     *
     * @return array<string,mixed>
     */
    public static function withBackupSize(array $manifest, int $blockSize): array
    {
        $manifest['backupSize'] = $blockSize;
        $manifest['checksum'] = self::computeChecksum($manifest);

        return $manifest;
    }

    /**
     * تولید JSON استاندارد با کلیدهای مرتب.
     *
     * @param array<string,mixed> $data داده
     *
     * @return string
     */
    private static function canonicalJson(array $data): string
    {
        self::ksortRecursive($data);

        return (string) json_encode(
            $data,
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRESERVE_ZERO_FRACTION
        );
    }

    /**
     * مرتب‌سازی بازگشتی کلیدهای آرایه.
     *
     * @param array<array-key,mixed> $data آرایه
     *
     * @return void
     */
    private static function ksortRecursive(array &$data): void
    {
        ksort($data);

        foreach ($data as &$value) {
            if (is_array($value)) {
                self::ksortRecursive($value);
            }
        }
    }
}
