<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Service;

use Typecho\Cache;
use TypechoPlugin\SQLiteBackup\Core\Logger;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class CacheService
{
    /**
     * پاک‌سازی کامل کش سیستم (Redis/APCu).
     *
     * @return array{cleared:bool,driver:string,entries:int}
     */
    public static function flush(): array
    {
        try {
            $cache = Cache::getInstance();

            if (!$cache->enabled()) {
                return ['cleared' => false, 'driver' => 'disabled', 'entries' => 0];
            }

            $count = $cache->flush();
            Logger::info('کش سیستم پس از بازیابی پاک‌سازی شد', ['entries' => $count]);

            return ['cleared' => true, 'driver' => 'active', 'entries' => $count];
        } catch (\Throwable $e) {
            Logger::warning('پاک‌سازی کش سیستم ناموفق بود', ['error' => $e->getMessage()]);

            return ['cleared' => false, 'driver' => 'error', 'entries' => 0];
        }
    }
}
