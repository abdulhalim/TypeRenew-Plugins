<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Service;

use TypechoPlugin\SQLiteBackup\Core\Disk;
use TypechoPlugin\SQLiteBackup\Core\Logger;
use TypechoPlugin\SQLiteBackup\Core\Paths;
use TypechoPlugin\SQLiteBackup\Repository\BackupRepository;
use TypechoPlugin\SQLiteBackup\Repository\NoteRepository;
use TypechoPlugin\SQLiteBackup\Repository\SessionStore;
use TypechoPlugin\SQLiteBackup\Text;
use TypechoPlugin\SQLiteBackup\Zip\PurePhpWriter;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class BackupService
{
    /**
     * بودجه زمانی هر گام (ثانیه).
     */
    private const STEP_BUDGET = 6;

    /**
     * بیشترین تعداد فایل در هر گام.
     */
    private const STEP_FILES = 500;

    /**
     * آغاز فرایند ساخت پشتیبان.
     *
     * @param string $type نوع پشتیبان (backup یا emergency)
     * @param int    $uid  شناسه کاربر مدیر
     * @param string $note یادداشت اختیاری این نسخه
     *
     * @return array{sid:string,totalFiles:int,totalBytes:int,database:array<string,mixed>}
     *
     * @throws \RuntimeException در صورت خطا
     */
    public static function init(string $type, int $uid, string $note = ''): array
    {
        Paths::ensureDirectory(Paths::backups());
        Paths::ensureDirectory(Paths::sessions());

        if (!\TypechoPlugin\SQLiteBackup\Zip\ZipEngine::isSupported()) {
            throw new \RuntimeException('ساخت فایل ZIP به افزونه Zlib نیاز دارد');
        }

        $databaseInfo = DatabaseService::info();

        if (!$databaseInfo['isSqlite']) {
            throw new \RuntimeException(
                'این افزونه برای دیتابیس SQLite طراحی شده است؛ دیتابیس فعلی (' . $databaseInfo['adapter'] . ') پشتیبانی نمی‌شود'
            );
        }

        $uploadsDir = Paths::uploads();

        if (!is_dir($uploadsDir)) {
            throw new \RuntimeException('پوشه بارگذاری‌ها یافت نشد: usr/uploads');
        }

        // اسنپ‌شات دیتابیس در ابتدای عملیات (نقطه زمانی ثابت)
        $snapshotPath = Paths::sessions() . '/db-' . uniqid('', true) . '.sqlite';

        try {
            $snapshot = DatabaseService::backupTo($snapshotPath);
        } catch (\Throwable $e) {
            if (is_file($snapshotPath)) {
                @unlink($snapshotPath);
            }

            $diskMessage = Disk::insufficientMessage($e->getMessage(), 'ساخت پشتیبان');

            throw new \RuntimeException($diskMessage ?? ('ساخت اسنپ‌شات دیتابیس ناموفق بود: ' . $e->getMessage()), 0, $e);
        }

        // فهرست فایل‌های بارگذاری‌ها
        $files = \TypechoPlugin\SQLiteBackup\Manager\FileManager::listFiles($uploadsDir);

        $totalBytes = (int) $snapshot['size'];
        $totalFiles = 1;

        foreach ($files as $file) {
            $totalBytes += $file['size'];
            $totalFiles++;
        }

        // بررسی کفایت فضای دیسک پیش از آغاز (با پیام مشخص در صورت کمبود)
        try {
            Disk::assertEnough($totalBytes, 'ساخت پشتیبان');
        } catch (\RuntimeException $e) {
            if (is_file($snapshotPath)) {
                @unlink($snapshotPath);
            }

            Logger::error('ساخت پشتیبان به دلیل کمبود فضای دیسک متوقف شد', [
                'needed' => $totalBytes,
            ]);

            throw $e;
        }

        $name = BackupRepository::makeName($type);

        $session = SessionStore::create('backup', [
            'uid'        => $uid,
            'type'       => $type === 'emergency' ? 'emergency' : 'backup',
            'phase'      => 'files',
            'name'       => $name,
            'note'       => Text::cut($note, NoteRepository::MAX_LENGTH),
            'zipPath'    => Paths::sessions() . '/work-' . $name . '.part',
            'zipState'   => null,
            'queue'      => array_map(static fn ($f) => [
                'relative' => 'uploads/' . $f['relative'],
                'path'     => $f['path'],
                'size'     => $f['size'],
            ], $files),
            'totalFiles' => $totalFiles,
            'totalBytes' => $totalBytes,
            'doneFiles'  => 0,
            'doneBytes'  => 0,
            'database'   => [
                'adapter' => $databaseInfo['adapter'],
                'engine'  => $databaseInfo['engine'],
                'size'    => $snapshot['size'],
                'sha256'  => $snapshot['sha256'],
                'method'  => $snapshot['method'],
                'source'  => $snapshotPath,
                'entry'   => DatabaseService::BACKUP_ENTRY,
                'path'    => (string) (DatabaseService::relativeFile() ?? ''),
                'prefix'  => DatabaseService::currentPrefix(),
            ],
            'uploads'    => [
                'files' => count($files),
                'bytes' => $totalBytes - (int) $snapshot['size'],
            ],
        ]);

        Logger::info('فرایند پشتیبان‌گیری آغاز شد', [
            'type'  => $type,
            'files' => count($files),
            'bytes' => $totalBytes,
        ]);

        return [
            'sid'        => $session['sid'],
            'totalFiles' => $totalFiles,
            'totalBytes' => $totalBytes,
            'database'   => $databaseInfo,
        ];
    }

    /**
     * اجرای یک گام از افزودن فایل‌ها به آرشیو.
     *
     * @param string $sid شناسه نشست
     *
     * @return array{done:bool,filesDone:int,filesTotal:int,bytesDone:int,bytesTotal:int,percent:int}
     *
     * @throws \RuntimeException در صورت خطا
     */
    public static function step(string $sid): array
    {
        $session = self::requireSession($sid);

        if ($session['phase'] !== 'files') {
            throw new \RuntimeException('فاز نشست برای اجرای گام فایل‌ها معتبر نیست');
        }

        // گارد فضای دیسک: ادامهٔ نوشتن تنها وقتی ممکن است که فضای کافی باشد
        $remainingBytes = max(0, (int) $session['totalBytes'] - (int) $session['doneBytes']);

        try {
            Disk::assertEnough($remainingBytes, 'ادامه ساخت پشتیبان');
        } catch (\RuntimeException $e) {
            self::abortOnDisk($sid, $session, 'ساخت پشتیبان');
            throw $e;
        }

        $writer = new PurePhpWriter();
        $writer->begin((string) $session['zipPath'], $session['zipState']);

        $started = microtime(true);
        $queue = $session['queue'];
        $processed = 0;

        try {
            while ($queue !== [] && $processed < self::STEP_FILES) {
                if (microtime(true) - $started > self::STEP_BUDGET) {
                    break;
                }

                $file = array_shift($queue);
                $relative = (string) $file['relative'];

                try {
                    $writer->addFile((string) $file['path'], $relative);
                } catch (\Throwable $e) {
                    // فایل خراب یا حذف‌شده حین عملیات: ثبت و ادامه
                    Logger::warning('افزودن فایل به آرشیو ناموفق بود و نادیده گرفته شد', [
                        'file'  => $relative,
                        'error' => $e->getMessage(),
                    ]);
                    $session['totalFiles'] = max(1, (int) $session['totalFiles'] - 1);
                    continue;
                }

                $processed++;
                $session['doneFiles'] = (int) $session['doneFiles'] + 1;
                $session['doneBytes'] = (int) $session['doneBytes'] + (int) $file['size'];
            }

            $session['queue'] = $queue;
            $session['zipState'] = $writer->exportState();
            $writer->abort(); // بستن موقت؛ در گام بعدی ادامه می‌یابد

            SessionStore::save($sid, $session);
        } catch (\Throwable $e) {
            $writer->abort();

            $diskMessage = Disk::insufficientMessage($e->getMessage(), 'ادامه ساخت پشتیبان');

            if ($diskMessage !== null) {
                self::abortOnDisk($sid, $session, 'ساخت پشتیبان');
                throw new \RuntimeException($diskMessage);
            }

            throw new \RuntimeException('خطا در افزودن فایل‌ها به آرشیو: ' . $e->getMessage(), 0, $e);
        }

        $done = $queue === [];
        $totalFiles = max(1, (int) $session['totalFiles']);
        $totalBytes = max(1, (int) $session['totalBytes']);

        return [
            'done'       => $done,
            'filesDone'  => (int) $session['doneFiles'],
            'filesTotal' => $totalFiles,
            'bytesDone'  => (int) $session['doneBytes'],
            'bytesTotal' => $totalBytes,
            'percent'    => (int) floor(min(100, ($session['doneBytes'] / $totalBytes) * 100)),
        ];
    }

    /**
     * نهایی‌سازی پشتیبان: افزودن دیتابیس و manifest و بستن آرشیو.
     *
     * @param string $sid شناسه نشست
     *
     * @return array<string,mixed> خلاصه پشتیبان ساخته‌شده
     *
     * @throws \RuntimeException در صورت خطا
     */
    public static function finalize(string $sid): array
    {
        $session = self::requireSession($sid);

        if ($session['phase'] !== 'files' || $session['queue'] !== []) {
            throw new \RuntimeException('همه فایل‌ها هنوز به آرشیو افزوده نشده‌اند');
        }

        $zipPath = (string) $session['zipPath'];
        $database = $session['database'];

        // پیش از افزودن اسنپ‌شات دیتابیس و بستن آرشیو، فضای کافی بررسی می‌شود
        try {
            Disk::assertEnough((int) $database['size'] + 1048576, 'نهایی‌سازی پشتیبان');
        } catch (\RuntimeException $e) {
            self::abortOnDisk($sid, $session, 'نهایی‌سازی پشتیبان');
            throw $e;
        }

        $writer = new PurePhpWriter();
        $writer->begin($zipPath, $session['zipState']);

        $manifest = null;

        try {
            // افزودن اسنپ‌شات دیتابیس
            $writer->addFile((string) $database['source'], DatabaseService::BACKUP_ENTRY);

            $entries = [
                DatabaseService::BACKUP_ENTRY => [
                    'size'   => (int) $database['size'],
                    'sha256' => (string) $database['sha256'],
                ],
            ];

            // پیش‌بینی دقیق حجم نهایی برای ثبت در manifest
            $state = $writer->exportState();
            $manifest = self::buildManifestWithExactSize(
                $state,
                (string) $session['type'],
                $database,
                $session['uploads'],
                $entries
            );

            $writer->addFromString(
                ManifestService::ENTRY_NAME,
                ManifestService::serialize($manifest),
                PurePhpWriter::METHOD_STORE
            );
            $writer->finish();
        } catch (\Throwable $e) {
            $writer->abort();

            $diskMessage = Disk::insufficientMessage($e->getMessage(), 'نهایی‌سازی پشتیبان');

            if ($diskMessage !== null) {
                self::abortOnDisk($sid, $session, 'نهایی‌سازی پشتیبان');
                throw new \RuntimeException($diskMessage);
            }

            throw new \RuntimeException('نهایی‌سازی آرشیو ناموفق بود: ' . $e->getMessage(), 0, $e);
        }

        clearstatcache(true, $zipPath);
        $size = (int) filesize($zipPath);

        if ($manifest !== null && (int) ($manifest['backupSize'] ?? 0) !== $size) {
            Logger::warning('حجم پیش‌بینی‌شده پشتیبان با مقدار واقعی تفاوت جزئی دارد', [
                'predicted' => (int) $manifest['backupSize'],
                'actual'    => $size,
            ]);
        }

        $finalPath = Paths::backups() . '/' . (string) $session['name'];

        if (!@rename($zipPath, $finalPath)) {
            throw new \RuntimeException('انتقال فایل پشتیبان به پوشه نهایی ناموفق بود');
        }

        // پاک‌سازی اسنپ‌شات موقت دیتابیس
        if (is_file((string) $database['source'])) {
            @unlink((string) $database['source']);
        }

        // ذخیره یادداشت اختیاری نسخه؛ خطای آن نباید موفقیت پشتیبان‌گیری را تحت تأثیر قرار دهد
        $note = trim((string) ($session['note'] ?? ''));

        if ($note !== '') {
            try {
                NoteRepository::set((string) $session['name'], $note, (int) ($session['uid'] ?? 0));
            } catch (\Throwable $e) {
                Logger::warning('ذخیره یادداشت نسخه پشتیبان ناموفق بود', ['error' => $e->getMessage()]);
            }
        }

        // اعمال سیاست نگهداشت (فقط برای پشتیبان‌های عادی؛ در جریان بازیابی
        // نباید فایلی که در آستانه بازیابی است حذف شود)
        $retained = 0;

        if ((string) $session['type'] === 'backup') {
            $settings = \TypechoPlugin\SQLiteBackup\Settings::load();
            $retained = BackupRepository::applyRetention((int) $settings['retentionCount']);
        }

        SessionStore::delete($sid);

        Logger::success('فایل پشتیبان با موفقیت ساخته شد', [
            'file'     => (string) $session['name'],
            'type'     => (string) $session['type'],
            'size'     => $size,
            'files'    => (int) $session['totalFiles'],
            'retained' => $retained,
        ]);

        return [
            'name'     => (string) $session['name'],
            'type'     => (string) $session['type'],
            'size'     => $size,
            'files'    => (int) $session['totalFiles'],
            'bytes'    => (int) $session['totalBytes'],
            'duration' => max(1, \TypechoPlugin\SQLiteBackup\Core\Clock::now() - (int) $session['createdAt']),
            'note'     => $note,
            'manifest' => $manifest,
        ];
    }

    /**
     * ساخت manifest با حجم نهایی دقیق آرشیو.
     *
     * اندازه نهایی بر اساس ساختار بایت‌های ZIP پیش‌بینی می‌شود و محاسبه
     * تا رسیدن به نقطه ثابت تکرار می‌گردد.
     *
     * @param array<string,mixed>      $writerState وضعیت موتور نوشتن
     * @param string                   $type         نوع پشتیبان
     * @param array<string,mixed>      $database     اطلاعات دیتابیس
     * @param array<string,mixed>      $uploads      اطلاعات بارگذاری‌ها
     * @param array<string,array>      $entries      نقشه checksum مدخل‌ها
     *
     * @return array<string,mixed>
     */
    private static function buildManifestWithExactSize(
        array $writerState,
        string $type,
        array $database,
        array $uploads,
        array $entries
    ): array {
        $offset = (int) ($writerState['offset'] ?? 0);
        $records = is_array($writerState['records'] ?? null) ? $writerState['records'] : [];

        $nameLengthSum = 0;

        foreach ($records as $record) {
            $nameLengthSum += strlen((string) ($record['name'] ?? ''));
        }

        // سرصفحه محلی manifest (۳۰ بایت + نام) + پوشه مرکزی + EOCD
        // manifest با روش STORE نوشته می‌شود تا پیش‌بینی حجم نهایی قطعی باشد
        $manifestNameLength = strlen(ManifestService::ENTRY_NAME);
        $centralSize = 46 * (count($records) + 1) + $nameLengthSum + $manifestNameLength + 22;

        $guess = 0;
        $manifest = null;

        for ($attempt = 0; $attempt < 8; $attempt++) {
            $manifest = ManifestService::build($type, $database, $uploads, $entries, [
                'backupSize' => $guess,
            ]);

            $json = ManifestService::serialize($manifest);
            $predicted = $offset + 30 + $manifestNameLength + strlen($json) + $centralSize;

            if ($predicted === $guess) {
                break;
            }

            $guess = $predicted;
        }

        return $manifest;
    }

    /**
     * پیشرفت فعلی نشست پشتیبان.
     *
     * @param string $sid شناسه نشست
     *
     * @return array<string,int>
     */
    public static function progress(string $sid): array
    {
        $session = self::requireSession($sid);
        $totalBytes = max(1, (int) $session['totalBytes']);

        return [
            'filesDone'  => (int) $session['doneFiles'],
            'filesTotal' => (int) $session['totalFiles'],
            'bytesDone'  => (int) $session['doneBytes'],
            'bytesTotal' => $totalBytes,
            'percent'    => (int) floor(min(100, ((int) $session['doneBytes'] / $totalBytes) * 100)),
        ];
    }

    /**
     * توقف عملیات به دلیل کمبود فضا و پاک‌سازی فایل‌های موقت.
     *
     * فایل ناقص و اسنپ‌شات موقت حذف و نشست برداشته می‌شود تا فضای
     * اشغال‌شده آزاد شود و در گام بعدی خطای گیج‌کننده‌ای ثبت نگردد.
     *
     * @param string              $sid         شناسه نشست
     * @param array<string,mixed> $session     داده نشست
     * @param string              $actionLabel برچسب عملیات برای گزارش
     *
     * @return void
     */
    private static function abortOnDisk(string $sid, array $session, string $actionLabel): void
    {
        if (!empty($session['zipPath']) && is_file((string) $session['zipPath'])) {
            @unlink((string) $session['zipPath']);
        }

        if (!empty($session['database']['source']) && is_file((string) $session['database']['source'])) {
            @unlink((string) $session['database']['source']);
        }

        SessionStore::delete($sid);

        Logger::error($actionLabel . ' به دلیل کمبود فضای دیسک متوقف و فایل‌های موقت پاک‌سازی شدند', [
            'file' => (string) ($session['name'] ?? ''),
        ]);
    }

    /**
     * لغو نشست پشتیبان و پاک‌سازی فایل‌های موقت.
     *
     * @param string $sid شناسه نشست
     *
     * @return void
     */
    public static function cancel(string $sid): void
    {
        $session = SessionStore::load($sid);

        if ($session !== null && ($session['kind'] ?? '') === 'backup') {
            if (!empty($session['zipPath']) && is_file((string) $session['zipPath'])) {
                @unlink((string) $session['zipPath']);
            }

            if (!empty($session['database']['source']) && is_file((string) $session['database']['source'])) {
                @unlink((string) $session['database']['source']);
            }

            Logger::info('فرایند پشتیبان‌گیری لغو شد', ['type' => $session['type'] ?? 'backup']);
        }

        SessionStore::delete($sid);
    }

    /**
     * بارگذاری نشست پشتیبان با اعتبارسنجی.
     *
     * @param string $sid شناسه نشست
     *
     * @return array<string,mixed>
     *
     * @throws \RuntimeException در صورت نامعتبر بودن نشست
     */
    private static function requireSession(string $sid): array
    {
        $session = SessionStore::load($sid);

        if ($session === null || ($session['kind'] ?? '') !== 'backup') {
            throw new \RuntimeException('نشست پشتیبان‌گیری یافت نشد یا منقضی شده است', 404);
        }

        \TypechoPlugin\SQLiteBackup\Core\Security::assertSessionOwner($session);

        return $session;
    }
}
