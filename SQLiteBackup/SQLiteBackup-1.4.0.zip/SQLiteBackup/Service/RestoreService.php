<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Service;

use TypechoPlugin\SQLiteBackup\Core\Logger;
use TypechoPlugin\SQLiteBackup\Core\Clock;
use TypechoPlugin\SQLiteBackup\Core\Paths;
use TypechoPlugin\SQLiteBackup\Core\Security;
use TypechoPlugin\SQLiteBackup\Manager\FileManager;
use TypechoPlugin\SQLiteBackup\Repository\BackupRepository;
use TypechoPlugin\SQLiteBackup\Repository\SessionStore;
use TypechoPlugin\SQLiteBackup\Zip\ZipEngine;
use TypechoPlugin\SQLiteBackup\Zip\ZipReader;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class RestoreService
{
    /**
     * بودجه زمانی هر گام استخراج (ثانیه).
     */
    private const STEP_BUDGET = 6;

    /**
     * بیشترین تعداد مدخل در هر گام.
     */
    private const STEP_ENTRIES = 600;

    /**
     * بررسی کامل صحت یک فایل پشتیبان بدون اجرای بازیابی.
     *
     * @param string $name نام فایل پشتیبان
     *
     * @return array<string,mixed> نتیجه بررسی شامل manifest و خطاها
     *
     * @throws \RuntimeException در صورت عدم دسترسی به فایل
     */
    public static function check(string $name): array
    {
        $path = Security::backupPath($name);

        return self::inspectArchive($path);
    }

    /**
     * بررسی صحت یک فایل پشتیبان آپلود‌شده (مسیر موقت).
     *
     * @param string $tmpPath مسیر فایل موقت روی دیسک
     *
     * @return array<string,mixed> نتیجه بررسی شامل manifest و خطاها
     */
    public static function inspectUploadedArchive(string $tmpPath): array
    {
        if (!is_file($tmpPath) || !is_readable($tmpPath)) {
            return [
                'ok'            => false,
                'errors'        => ['فایل آپلودی روی سرور در دسترس نیست'],
                'manifest'      => null,
                'uploadEntries' => [],
            ];
        }

        return self::inspectArchive($tmpPath);
    }

    /**
     * آغاز فرایند بازیابی.
     *
     * پیش از هر تغییری، پوشه بارگذاری‌ها به محل موقت منتقل می‌شود.
     *
     * @param string $name نام فایل پشتیبان
     * @param int    $uid  شناسه کاربر مدیر
     *
     * @return array<string,mixed> اطلاعات نشست بازیابی
     *
     * @throws \RuntimeException در صورت عدم اعتبار پشتیبان
     */
    public static function init(string $name, int $uid): array
    {
        Paths::ensureDirectory(Paths::backups());
        Paths::ensureDirectory(Paths::sessions());

        if (BackupRepository::typeOf($name) === 'full') {
            throw new \RuntimeException(
                'بکاپ کامل سایت برای بازیابی از پنل طراحی نشده است؛ آن را دانلود کنید و در شرایط اضطراری از طریق FTP/فایل‌منیجر در ریشه سایت جایگزین کنید'
            );
        }

        $path = Security::backupPath($name);
        $inspection = self::inspectArchive($path);

        if (!$inspection['ok']) {
            throw new \RuntimeException('فایل پشتیبان معتبر نیست: ' . implode('؛ ', $inspection['errors']));
        }

        $manifest = $inspection['manifest'];

        // انتقال پوشه بارگذاری‌ها به محل موقت برای امکان بازگشت
        $session = SessionStore::create('restore', [
            'uid'        => $uid,
            'phase'      => 'uploads',
            'name'       => $name,
            'path'       => $path,
            'staging'    => '', // پس از ساخت نشست تکمیل می‌شود
            'queue'      => $inspection['uploadEntries'],
            'totalFiles' => count($inspection['uploadEntries']) + 1,
            'doneFiles'  => 0,
            'totalBytes' => (int) ($manifest['totalBytes'] ?? 0),
            'doneBytes'  => 0,
            'manifest'   => $manifest,
            'restored'   => ['files' => 0, 'bytes' => 0],
        ]);

        $sid = $session['sid'];
        $staging = Paths::sessions() . '/' . $sid . '-staging';
        @mkdir($staging, 0755, true);

        $session['data']['staging'] = $staging;
        SessionStore::save($sid, $session['data']);

        $uploadsDir = Paths::uploads();

        if (is_dir($uploadsDir)) {
            FileManager::moveDirectory($uploadsDir, $staging . '/uploads');
        }

        FileManager::ensureDirectory($uploadsDir);
        Paths::protect($uploadsDir);

        Logger::warning('فرایند بازیابی آغاز شد؛ پوشه بارگذاری‌ها به محل موقت منتقل شد', [
            'file'    => $name,
            'staging' => basename($staging),
        ]);

        return [
            'sid'        => $sid,
            'totalFiles' => $session['data']['totalFiles'],
            'totalBytes' => $session['data']['totalBytes'],
        ];
    }

    /**
     * اجرای یک گام از استخراج فایل‌های بارگذاری‌ها.
     *
     * @param string $sid شناسه نشست
     *
     * @return array<string,mixed> پیشرفت بازیابی
     *
     * @throws \RuntimeException در صورت خطا
     */
    public static function step(string $sid): array
    {
        $session = self::requireSession($sid);

        if ($session['phase'] !== 'uploads') {
            throw new \RuntimeException('فاز نشست برای استخراج فایل‌ها معتبر نیست');
        }

        $reader = ZipEngine::reader();

        try {
            $reader->open((string) $session['path']);
        } catch (\Throwable $e) {
            self::rollback($session);
            throw new \RuntimeException('باز کردن فایل پشتیبان ناموفق بود: ' . $e->getMessage(), 0, $e);
        }

        $started = microtime(true);
        $queue = $session['queue'];
        $processed = 0;

        try {
            while ($queue !== [] && $processed < self::STEP_ENTRIES) {
                if (microtime(true) - $started > self::STEP_BUDGET) {
                    break;
                }

                $entry = array_shift($queue);

                try {
                    $target = Security::entryTargetPath($entry['name']);
                    FileManager::ensureDirectory(dirname($target));
                    $info = $reader->extractTo($entry['name'], $target);
                    @chmod($target, 0644);
                } catch (\Throwable $e) {
                    $reader->close();
                    self::rollback($session);
                    throw new \RuntimeException(
                        'استخراج مدخل ناموفق بود و عملیات بازگردانده شد: ' . $entry['name'] . ' (' . $e->getMessage() . ')',
                        0,
                        $e
                    );
                }

                $processed++;
                $session['doneFiles'] = (int) $session['doneFiles'] + 1;
                $session['doneBytes'] = (int) $session['doneBytes'] + (int) $entry['size'];
                $session['restored']['files'] = (int) $session['restored']['files'] + 1;
                $session['restored']['bytes'] = (int) $session['restored']['bytes'] + (int) $info['size'];
            }
        } finally {
            $reader->close();
        }

        $session['queue'] = $queue;
        SessionStore::save($sid, $session);

        $totalBytes = max(1, (int) $session['totalBytes']);

        return [
            'done'       => $queue === [],
            'filesDone'  => (int) $session['doneFiles'],
            'filesTotal' => (int) $session['totalFiles'],
            'bytesDone'  => (int) $session['doneBytes'],
            'bytesTotal' => $totalBytes,
            'percent'    => (int) floor(min(99, ((int) $session['doneBytes'] / $totalBytes) * 100)),
        ];
    }

    /**
     * جایگزینی دیتابیس با نسخه بازیابی‌شده (بازگردانی هوشمند).
     *
     * پس از جایگزینی، دیتابیس با نصب جاری آشتی داده می‌شود: پیشوند
     * جدول‌ها تطبیق می‌یابد، کلید امنیتی جاری حفظ می‌شود و نشست مدیر
     * بازسازی می‌گردد تا گام «نهایی‌سازی بازیابی» بدون خطای 403 قابل
     * اجرا باشد — حتی روی یک نصب کاملاً تازه.
     *
     * @param string $sid شناسه نشست
     *
     * @return array<string,mixed> نتیجه عملیات
     *
     * @throws \RuntimeException در صورت خطا
     */
    public static function applyDatabase(string $sid): array
    {
        $session = self::requireSession($sid);

        if ($session['phase'] !== 'uploads' || $session['queue'] !== []) {
            throw new \RuntimeException('ابتدا همه فایل‌های بارگذاری‌ها باید استخراج شوند');
        }

        // اطلاعات نشست جاری پیش از هر تغییری ثبت می‌شود
        $currentSession = DatabaseService::currentSessionInfo();
        $backupPrefix = (string) ($session['manifest']['database']['prefix'] ?? '');

        $reader = ZipEngine::reader();

        try {
            $reader->open((string) $session['path']);
        } catch (\Throwable $e) {
            self::rollback($session);
            throw new \RuntimeException('باز کردن فایل پشتیبان ناموفق بود: ' . $e->getMessage(), 0, $e);
        }

        $tempDb = Paths::sessions() . '/' . $sid . '-database.sqlite';
        $result = [];

        try {
            $info = $reader->extractTo(DatabaseService::BACKUP_ENTRY, $tempDb);
        } catch (\Throwable $e) {
            $reader->close();
            self::rollback($session);
            throw new \RuntimeException('استخراج دیتابیس از آرشیو ناموفق بود: ' . $e->getMessage(), 0, $e);
        } finally {
            $reader->close();
        }

        try {
            $expected = (string) ($session['manifest']['database']['sha256'] ?? '');

            if ($expected !== '' && !hash_equals($expected, $info['sha256'])) {
                throw new \RuntimeException('checksum دیتابیس بازیابی‌شده با manifest مطابقت ندارد');
            }

            DatabaseService::restoreFrom($tempDb);

            $reconcile = DatabaseService::reconcileAfterRestore(
                $currentSession,
                $backupPrefix !== '' ? $backupPrefix : null
            );

            // اگر ورود خودکار به مدیر نسخه پشتیبان انجام شده باشد، مالکیت
            // نشست بازیابی به همان کاربر منتقل می‌شود تا بررسی مالکیت در
            // گام بعدی موفق باشد
            if ($reconcile['reissuedLogin'] !== null && (int) $reconcile['reissuedUid'] > 0) {
                $session['uid'] = (int) $reconcile['reissuedUid'];
            }

            // کش سیستم بلافاصله پاک‌سازی می‌شود تا درخواست بعدی داده‌های
            // بازیابی‌شده را بخواند نه وضعیت پیش از بازیابی
            CacheService::flush();

            $session['doneFiles'] = (int) $session['doneFiles'] + 1;
            $session['phase'] = 'database';
            $session['reconcile'] = $reconcile;
            SessionStore::save($sid, $session);

            $result = [
                'ok'            => true,
                'sha256'        => $info['sha256'],
                'size'          => $info['size'],
                'prefixAdapted' => (bool) $reconcile['prefixAdapted'],
                'keptUser'      => $reconcile['keptUser'],
                'reissuedLogin' => $reconcile['reissuedLogin'],
            ];
        } catch (\Throwable $e) {
            self::rollback($session);
            throw new \RuntimeException('جایگزینی دیتابیس ناموفق بود و عملیات بازگردانده شد: ' . $e->getMessage(), 0, $e);
        } finally {
            if (is_file($tempDb)) {
                @unlink($tempDb);
            }
        }

        return $result;
    }

    /**
     * نهایی‌سازی بازیابی: پاک‌سازی کش و حذف محل موقت.
     *
     * @param string $sid شناسه نشست
     *
     * @return array<string,mixed> خلاصه نتیجه
     *
     * @throws \RuntimeException در صورت خطا
     */
    public static function finish(string $sid): array
    {
        $session = self::requireSession($sid);

        if ($session['phase'] !== 'database') {
            throw new \RuntimeException('جایگزینی دیتابیس هنوز انجام نشده است');
        }

        $cache = CacheService::flush();

        $staging = (string) $session['staging'];

        if (is_dir($staging)) {
            FileManager::removeDirectory($staging);
        }

        $reconcile = is_array($session['reconcile'] ?? null) ? $session['reconcile'] : [];

        $summary = [
            'file'     => (string) $session['name'],
            'files'    => (int) $session['restored']['files'],
            'bytes'    => (int) $session['restored']['bytes'],
            'duration' => max(1, Clock::now() - (int) $session['createdAt']),
            'cache'    => $cache,
            'reconcile' => [
                'prefixAdapted' => (bool) ($reconcile['prefixAdapted'] ?? false),
                'keptUser'      => $reconcile['keptUser'] ?? null,
                'reissuedLogin' => $reconcile['reissuedLogin'] ?? null,
            ],
        ];

        SessionStore::delete($sid);

        Logger::success('بازیابی پشتیبان با موفقیت کامل شد', $summary);

        return $summary;
    }

    /**
     * لغو بازیابی و بازگرداندن وضعیت قبلی.
     *
     * @param string $sid شناسه نشست
     *
     * @return void
     */
    public static function cancel(string $sid): void
    {
        $session = SessionStore::load($sid);

        if ($session === null || ($session['kind'] ?? '') !== 'restore') {
            return;
        }

        Security::assertSessionOwner($session);
        self::rollback($session);
        SessionStore::delete($sid);
    }

    /**
     * بازگرداندن پوشه بارگذاری‌ها از محل موقت.
     *
     * @param array<string,mixed> $session نشست بازیابی
     *
     * @return void
     */
    private static function rollback(array $session): void
    {
        $staging = (string) ($session['staging'] ?? '');
        $stagedUploads = $staging !== '' ? $staging . '/uploads' : '';
        $uploadsDir = Paths::uploads();

        if ($stagedUploads !== '' && is_dir($stagedUploads)) {
            if (is_dir($uploadsDir)) {
                FileManager::removeDirectory($uploadsDir);
            }

            @rename($stagedUploads, $uploadsDir);

            if (is_dir($staging)) {
                FileManager::removeDirectory($staging);
            }

            Logger::warning('بازیابی بازگردانده شد؛ پوشه بارگذاری‌ها به وضعیت قبلی برگشت', [
                'file' => (string) ($session['name'] ?? ''),
            ]);
        }

        $tempDb = Paths::sessions() . '/' . ($session['staging'] !== '' ? basename($staging, '-staging') : '') . '-database.sqlite';

        if (is_file($tempDb)) {
            @unlink($tempDb);
        }
    }

    /**
     * بازرسی کامل آرشیو پشتیبان.
     *
     * @param string $path مسیر فایل
     *
     * @return array<string,mixed>
     */
    private static function inspectArchive(string $path): array
    {
        $errors = [];
        $reader = ZipEngine::reader();

        try {
            $reader->open($path);
            $entries = $reader->entries();
        } catch (\Throwable $e) {
            return [
                'ok'            => false,
                'errors'        => ['باز کردن فایل ZIP ناموفق بود: ' . $e->getMessage()],
                'manifest'      => null,
                'uploadEntries' => [],
            ];
        }

        $names = [];
        $uploadEntries = [];
        $hasManifest = false;
        $hasDatabase = false;

        foreach ($entries as $entry) {
            $name = (string) $entry['name'];
            $names[] = $name;

            if ($name === ManifestService::ENTRY_NAME) {
                $hasManifest = true;
                continue;
            }

            if ($name === DatabaseService::BACKUP_ENTRY) {
                $hasDatabase = true;
                continue;
            }

            if (str_starts_with($name, 'uploads/')) {
                try {
                    Security::validateEntryName($name);
                    $uploadEntries[] = ['name' => $name, 'size' => (int) $entry['size']];
                } catch (\RuntimeException $e) {
                    $errors[] = $e->getMessage();
                }
                continue;
            }

            $errors[] = 'مدخل غیرمجاز در آرشیو: ' . $name;
        }

        if (!$hasManifest) {
            $errors[] = 'فایل manifest.json در آرشیو یافت نشد';
        }

        if (!$hasDatabase) {
            $errors[] = 'فایل دیتابیس در آرشیو یافت نشد';
        }

        $manifest = null;

        if ($hasManifest) {
            try {
                $json = $reader->readString(ManifestService::ENTRY_NAME, 8388608);
                $manifest = ManifestService::parse($json);
            } catch (\Throwable $e) {
                $errors[] = 'خواندن manifest ناموفق بود: ' . $e->getMessage();
            } finally {
                $reader->close();
            }

            if ($manifest === null) {
                $errors[] = 'ساختار manifest نامعتبر است';
            } else {
                $validation = ManifestService::validate($manifest);

                if (!$validation['ok']) {
                    $errors = array_merge($errors, $validation['errors']);
                }
            }
        } else {
            $reader->close();
        }

        return [
            'ok'            => $errors === [],
            'errors'        => $errors,
            'manifest'      => $manifest,
            'uploadEntries' => $uploadEntries,
        ];
    }

    /**
     * بارگذاری نشست بازیابی با اعتبارسنجی.
     *
     * @param string $sid شناسه نشست
     *
     * @return array<string,mixed>
     *
     * @throws \RuntimeException در صورت نامعتبر بودن نشست
     */
    private static function requireSession(string $sid): array
    {
        $session = SessionStore::load($sid);

        if ($session === null || ($session['kind'] ?? '') !== 'restore') {
            throw new \RuntimeException('نشست بازیابی یافت نشد یا منقضی شده است', 404);
        }

        Security::assertSessionOwner($session);

        return $session;
    }
}
