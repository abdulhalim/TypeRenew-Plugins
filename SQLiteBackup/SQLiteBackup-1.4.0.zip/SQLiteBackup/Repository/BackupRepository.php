<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Repository;

use TypechoPlugin\SQLiteBackup\Core\Clock;
use TypechoPlugin\SQLiteBackup\Core\Logger;
use TypechoPlugin\SQLiteBackup\Core\Paths;
use TypechoPlugin\SQLiteBackup\Core\Security;
use TypechoPlugin\SQLiteBackup\Service\ManifestService;
use TypechoPlugin\SQLiteBackup\Zip\ZipEngine;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class BackupRepository
{
    /**
     * پیشوند نام فایل پشتیبان‌های عادی (قالب پیشین ۱.۲.۰ — برای سازگاری).
     */
    public const PREFIX = 'backup-';

    /**
     * پیشوند نام فایل پشتیبان‌های اضطراری (قالب پیشین — برای سازگاری).
     */
    public const EMERGENCY_PREFIX = 'emergency-';

    /**
     * پیشوند نام فایل بکاپ کامل سایت (قالب پیشین — برای سازگاری).
     */
    public const FULL_PREFIX = 'fullbackup-';

    /**
     * برچسب نوع داخل نام فایل برای بکاپ کامل.
     */
    public const FULL_TAG = '_full';

    /**
     * برچسب نوع داخل نام فایل برای پشتیبان اضطراری.
     */
    public const EMERGENCY_TAG = '_emergency';

    /**
     * ساخت نام استاندارد فایل پشتیبان.
     *
     * الگوی نام: Host_Date_random — دامنه/میزبان سایت، تاریخ میلادی در منطقه
     * زمانی سایت و یک بخش تصادفی؛ مثال‌ها:
     *   - عادی:     localhost_2026-09-27_1630-a1b2c3.zip
     *   - اضطراری: localhost_emergency_2026-09-27_1630-a1b2c3.zip
     *   - کامل:    localhost_full_2026-09-27_1630-a1b2c3.zip
     *
     * @param string $type نوع پشتیبان (backup، emergency یا full)
     *
     * @return string
     */
    public static function makeName(string $type = 'backup'): string
    {
        $tag = match ($type) {
            'emergency' => self::EMERGENCY_TAG,
            'full'      => self::FULL_TAG,
            default     => '',
        };

        $random = bin2hex(random_bytes(3));

        return self::siteSlug() . $tag . '_' . Clock::gregorianStamp() . '-' . $random . '.zip';
    }

    /**
     * نام کوتاه و امن سایت برای استفاده در نام فایل‌ها.
     *
     * از hostname نشانی سایت (siteUrl) خوانده می‌شود؛ مثال‌ها:
     * http://localhost:8090 → localhost و https://www.typerenew.com → typerenew.
     * فقط حروف، ارقام، نقطه و خط تیره نگه داشته می‌شود (خط زیر حذف
     * می‌شود تا با برچسب‌های نوع _full_/_emergency_ تداخل پیش نیاید) و در
     * نبود مقدار معتبر به «site» سقوط می‌کند.
     *
     * @return string
     */
    public static function siteSlug(): string
    {
        $siteUrl = '';

        try {
            $options = \Widget\Options::alloc();
            $siteUrl = trim((string) ($options->siteUrl ?? ''));
        } catch (\Throwable) {
            $siteUrl = '';
        }

        $host = '';

        if ($siteUrl !== '') {
            $parsed = parse_url($siteUrl);
            $host = is_array($parsed) && isset($parsed['host']) ? (string) $parsed['host'] : '';
        }

        if ($host !== '') {
            $host = mb_strtolower($host, 'UTF-8');

            // حذف پیشوند رایج www. برای نام تمیزتر
            if (str_starts_with($host, 'www.')) {
                $host = substr($host, 4);
            }

            // فاصله‌ها و علائم به خط تیره تبدیل و کاراکترهای غیرمجاز حذف می‌شوند
            $slug = preg_replace('/[^\p{L}\p{Nd}.-]+/u', '-', $host) ?? '';
            $slug = trim((string) preg_replace('/-{2,}/', '-', $slug), '-.');
        } else {
            $slug = '';
        }

        if ($slug === '') {
            $slug = 'site';
        }

        if (mb_strlen($slug, 'UTF-8') > 40) {
            $slug = mb_substr($slug, 0, 40, 'UTF-8');
        }

        return $slug;
    }

    /**
     * تشخیص نوع پشتیبان از نام فایل.
     *
     * هم الگوی جدید (Host_full_Date-random.zip) و هم الگوی پیشین
     * (fullbackup-…) شناخته می‌شود تا فایل‌های نسخه‌های قدیمی همچنان
     * درست دسته‌بندی شوند.
     *
     * @param string $name نام فایل
     *
     * @return string backup | emergency | full
     */
    public static function typeOf(string $name): string
    {
        // الگوی جدید: Host_full_2026-09-27_1630-xxxx.zip
        if (str_starts_with($name, self::FULL_PREFIX)
            || preg_match('/_full_\d{4}-\d{2}-\d{2}_\d{4}-[0-9a-f]+\./i', $name) === 1
        ) {
            return 'full';
        }

        if (str_starts_with($name, self::EMERGENCY_PREFIX)
            || preg_match('/_emergency_\d{4}-\d{2}-\d{2}_\d{4}-[0-9a-f]+\./i', $name) === 1
        ) {
            return 'emergency';
        }

        return 'backup';
    }

    /**
     * فهرست پشتیبان‌های موجود به همراه وضعیت، اطلاعات manifest و یادداشت.
     *
     * @return array<int,array<string,mixed>>
     */
    public static function all(): array
    {
        $files = glob(Paths::backups() . '/*.zip') ?: [];
        $backups = [];

        // یادداشت‌های نسخه‌های حذف‌شده نیز در همین فرصت پاک‌سازی می‌شوند
        $notes = NoteRepository::all();

        foreach ($files as $file) {
            $name = basename($file);
            clearstatcache(true, $file);

            $entry = [
                'name'     => $name,
                'size'     => (int) filesize($file),
                'mtime'    => (int) filemtime($file),
                'type'     => self::typeOf($name),
                'valid'    => null,
                'manifest' => null,
                'note'     => $notes[$name] ?? null,
            ];

            $manifest = self::readManifest($name);

            if ($manifest !== null) {
                $entry['valid'] = ManifestService::validate($manifest)['ok'];
                $entry['manifest'] = $manifest;
            } else {
                $entry['valid'] = false;
            }

            $backups[] = $entry;
        }

        usort($backups, static fn ($a, $b) => (int) $b['mtime'] <=> (int) $a['mtime']);

        if ($backups !== []) {
            NoteRepository::prune(array_map(static fn (array $entry): string => (string) $entry['name'], $backups));
        }

        return $backups;
    }

    /**
     * خواندن manifest یک فایل پشتیبان.
     *
     * @param string $name نام فایل
     *
     * @return array<string,mixed>|null
     */
    public static function readManifest(string $name): ?array
    {
        try {
            $path = Security::backupPath($name);
        } catch (\RuntimeException) {
            return null;
        }

        $reader = ZipEngine::reader();

        try {
            $reader->open($path);

            if (!$reader->has(ManifestService::ENTRY_NAME)) {
                return null;
            }

            $json = $reader->readString(ManifestService::ENTRY_NAME, 8388608);
            $manifest = ManifestService::parse($json);
        } catch (\Throwable) {
            return null;
        } finally {
            $reader->close();
        }

        return $manifest;
    }

    /**
     * حذف یک فایل پشتیبان.
     *
     * @param string $name نام فایل
     *
     * @return void
     *
     * @throws \RuntimeException در صورت خطا
     */
    public static function delete(string $name): void
    {
        $path = Security::backupPath($name);

        if (!@unlink($path)) {
            throw new \RuntimeException('حذف فایل پشتیبان ناموفق بود: ' . $name);
        }

        NoteRepository::remove($name);

        Logger::info('فایل پشتیبان حذف شد', ['file' => $name]);
    }

    /**
     * اعمال سیاست نگهداشت (حذف پشتیبان‌های قدیمی).
     *
     * همهٔ فایل‌های ZIP پوشه پشتیبان‌ها بررسی و بر اساس نوعشان (عادی یا
     * اضطراری) دسته‌بندی می‌شوند؛ از هر دسته تعداد مشخصی نسخهٔ جدیدتر
     * نگه داشته می‌شود. بکاپ‌های کامل مشمول این سیاست نیستند.
     *
     * @param int $keep تعداد پشتیبان‌های نگهداری‌شده (صفر یعنی غیرفعال)
     *
     * @return int تعداد فایل‌های حذف‌شده
     */
    public static function applyRetention(int $keep): int
    {
        if ($keep <= 0) {
            return 0;
        }

        $limits = ['backup' => $keep, 'emergency' => 3];
        $byType = ['backup' => [], 'emergency' => []];

        $files = glob(Paths::backups() . '/*.zip') ?: [];

        foreach ($files as $file) {
            $type = self::typeOf(basename($file));

            if (!isset($limits[$type])) {
                continue; // بکاپ کامل مشمول سیاست نگهداشت نیست
            }

            clearstatcache(true, $file);
            $byType[$type][] = ['path' => $file, 'mtime' => (int) filemtime($file)];
        }

        $deleted = 0;

        foreach ($byType as $type => $entries) {
            usort($entries, static fn ($a, $b) => $b['mtime'] <=> $a['mtime']);

            $stale = array_slice($entries, $limits[$type]);

            foreach ($stale as $entry) {
                if (@unlink($entry['path'])) {
                    $deleted++;
                    NoteRepository::remove(basename($entry['path']));
                    Logger::info('پشتیبان قدیمی بر اساس سیاست نگهداشت حذف شد', [
                        'file' => basename($entry['path']),
                    ]);
                }
            }
        }

        return $deleted;
    }

    /**
     * آمار کلی پشتیبان‌ها.
     *
     * @return array{count:int,size:int,oldest:?int,newest:?int}
     */
    public static function stats(): array
    {
        $files = glob(Paths::backups() . '/*.zip') ?: [];

        if ($files === []) {
            return ['count' => 0, 'size' => 0, 'oldest' => null, 'newest' => null];
        }

        $size = 0;
        $oldest = null;
        $newest = null;

        foreach ($files as $file) {
            clearstatcache(true, $file);
            $size += (int) filesize($file);
            $mtime = (int) filemtime($file);
            $oldest = $oldest === null ? $mtime : min($oldest, $mtime);
            $newest = $newest === null ? $mtime : max($newest, $mtime);
        }

        return [
            'count'  => count($files),
            'size'   => $size,
            'oldest' => $oldest,
            'newest' => $newest,
        ];
    }

    /**
     * مسیر امن یک فایل پشتیبان.
     *
     * @param string $name نام فایل
     *
     * @return string
     *
     * @throws \RuntimeException در صورت نامعتبر بودن
     */
    public static function path(string $name): string
    {
        return Security::backupPath($name);
    }
}
