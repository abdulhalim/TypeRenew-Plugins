<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Repository;

use TypechoPlugin\SQLiteBackup\Core\Logger;
use TypechoPlugin\SQLiteBackup\Core\Paths;
use TypechoPlugin\SQLiteBackup\Core\Security;
use TypechoPlugin\SQLiteBackup\Text;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class NoteRepository
{
    /**
     * بیشترین طول مجاز یادداشت (کاراکتر).
     */
    public const MAX_LENGTH = 500;

    /**
     * سازنده خصوصی.
     */
    private function __construct()
    {
    }

    /**
     * مسیر فایل ذخیره‌سازی یادداشت‌ها.
     *
     * @return string
     */
    public static function file(): string
    {
        return Paths::backups() . '/notes.json';
    }

    /**
     * همه یادداشت‌های ذخیره‌شده.
     *
     * @return array<string,array{note:string,updatedAt:int,updatedBy:int}>
     */
    public static function all(): array
    {
        $file = self::file();

        if (!is_file($file)) {
            return [];
        }

        $raw = @file_get_contents($file);

        if (!is_string($raw) || trim($raw) === '') {
            return [];
        }

        $data = json_decode($raw, true);

        if (!is_array($data)) {
            return [];
        }

        $out = [];

        foreach ($data as $name => $entry) {
            if (!is_string($name) || !is_array($entry)) {
                continue;
            }

            $note = Text::cut((string) ($entry['note'] ?? ''), self::MAX_LENGTH);

            if ($note === '') {
                continue;
            }

            $out[$name] = [
                'note'      => $note,
                'updatedAt' => (int) ($entry['updatedAt'] ?? 0),
                'updatedBy' => (int) ($entry['updatedBy'] ?? 0),
            ];
        }

        return $out;
    }

    /**
     * یادداشت یک نسخه پشتیبان.
     *
     * @param string $name نام فایل پشتیبان
     *
     * @return array{note:string,updatedAt:int,updatedBy:int}|null
     */
    public static function get(string $name): ?array
    {
        $all = self::all();

        return $all[$name] ?? null;
    }

    /**
     * ذخیره یا حذف یادداشت یک نسخه پشتیبان.
     *
     * یادداشت خالی به معنای حذف ورودی است.
     *
     * @param string $name نام فایل پشتیبان
     * @param string $note متن یادداشت
     * @param int    $uid  شناسه کاربر مدیر
     *
     * @return array{note:string,updatedAt:int,updatedBy:int}
     *
     * @throws \RuntimeException در صورت نامعتبر بودن نام یا خطای ذخیره‌سازی
     */
    public static function set(string $name, string $note, int $uid): array
    {
        // اعتبارسنجی فقط واژگانی است؛ هنگام ساخت پشتیبان فایل هنوز وجود ندارد
        $name = Security::validateBackupName($name);
        $note = Text::cut($note, self::MAX_LENGTH);

        $all = self::all();

        if ($note === '') {
            unset($all[$name]);
            self::persist($all);
            Logger::info('یادداشت نسخه پشتیبان حذف شد', ['file' => $name]);

            return ['note' => '', 'updatedAt' => time(), 'updatedBy' => $uid];
        }

        $entry = [
            'note'      => $note,
            'updatedAt' => time(),
            'updatedBy' => $uid,
        ];

        $all[$name] = $entry;
        self::persist($all);
        Logger::info('یادداشت نسخه پشتیبان ذخیره شد', ['file' => $name]);

        return $entry;
    }

    /**
     * حذف یادداشت یک نسخه پشتیبان.
     *
     * @param string $name نام فایل پشتیبان
     *
     * @return void
     */
    public static function remove(string $name): void
    {
        $all = self::all();

        if (!isset($all[$name])) {
            return;
        }

        unset($all[$name]);
        self::persist($all);
    }

    /**
     * حذف یادداشت‌های نسخه‌هایی که دیگر وجود ندارند.
     *
     * @param array<int,string> $existingNames نام فایل‌های موجود
     *
     * @return int تعداد ورودی‌های حذف‌شده
     */
    public static function prune(array $existingNames): int
    {
        $all = self::all();
        $stale = array_diff(array_keys($all), array_values($existingNames));

        if ($stale === []) {
            return 0;
        }

        foreach ($stale as $name) {
            unset($all[$name]);
        }

        self::persist($all);

        return count($stale);
    }

    /**
     * نوشتن اتومیک فایل یادداشت‌ها.
     *
     * @param array<string,array{note:string,updatedAt:int,updatedBy:int}> $all همه یادداشت‌ها
     *
     * @return void
     *
     * @throws \RuntimeException در صورت خطای نوشتن
     */
    private static function persist(array $all): void
    {
        Paths::ensureDirectory(Paths::backups());

        $file = self::file();
        $json = json_encode($all, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        if ($json === false) {
            throw new \RuntimeException('رمزگذاری یادداشت‌های نسخه‌های پشتیبان ناموفق بود');
        }

        $tmp = $file . '.tmp-' . bin2hex(random_bytes(4));

        if (@file_put_contents($tmp, $json) === false || !@rename($tmp, $file)) {
            @unlink($tmp);
            throw new \RuntimeException('ذخیره فایل یادداشت‌های نسخه‌های پشتیبان ناموفق بود');
        }
    }
}
