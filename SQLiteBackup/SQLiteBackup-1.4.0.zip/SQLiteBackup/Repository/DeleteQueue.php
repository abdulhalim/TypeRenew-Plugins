<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Repository;

use TypechoPlugin\SQLiteBackup\Core\Logger;
use TypechoPlugin\SQLiteBackup\Core\Paths;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * صف زمان‌بندی‌شدهٔ حذف فایل‌های پشتیبانی که دانلود شده‌اند.
 *
 * مشکل نسخهٔ پیشین این بود که فایل بکاپ کامل بلافاصله پس از پایان دانلود
 * با register_shutdown_function حذف می‌شد. روی هاست‌های اشتراکی به‌دلیل
 * output buffering، محدودیت max_execution_time یا قطع زودرس کانکشن، گاهی
 * تابع shutdown پیش از اتمام کامل ارسال فایل اجرا می‌شد و فایل پیش از
 * رسیدن کامل به مرورگر حذف می‌گردید.
 *
 * در نسخهٔ جدید، فایل دانلودی به‌جای حذف آنی، در این صف زمان‌بندی می‌شود
 * تا حداقل ۲۴ ساعت روی سرور باقی بماند. در صورت بروز خطا در دانلود،
 * کاربر فرصت دریافت مجدد را دارد. پاک‌سازی خودکار هنگام هر فراخوانی اکشن
 * یا بارگذاری پنل انجام می‌شود.
 *
 * @package SQLiteBackup
 * @author  TypeRenew SQLiteBackup
 * @license GPL-2.0
 */
final class DeleteQueue
{
    /**
     * مدت ماندگاری فایل روی سرور پس از دانلود (ثانیه).
     *
     * ۲۴ ساعت = ۸۶۴۰۰ ثانیه. این مقدار حداقل مهلت قابل قبول است تا در صورت
     * بروز خطا در دریافت، امکان دانلود مجدد فراهم باشد.
     */
    public const RETENTION_SECONDS = 86400;

    /**
     * سازنده خصوصی.
     */
    private function __construct()
    {
    }

    /**
     * مسیر پوشهٔ صف حذف.
     *
     * @return string
     */
    public static function dir(): string
    {
        return Paths::backups() . '/.delete-queue';
    }

    /**
     * زمان‌بندی حذف یک فایل پشتیبان برای ۲۴ ساعت آینده.
     *
     * اگر فایلی با همین نام از قبل در صف باشد، زمان‌بندی آن تجدید نمی‌شود
     * تا نخستین مهلت ۲۴ ساعته همواره حفظ گردد.
     *
     * @param string $name نام فایل پشتیبان
     *
     * @return void
     */
    public static function schedule(string $name): void
    {
        $name = trim($name);

        if ($name === '') {
            return;
        }

        Paths::ensureDirectory(self::dir());

        $marker = self::markerPath($name);

        // اگر از قبل زمان‌بندی شده، تجدید نکن
        if (is_file($marker)) {
            return;
        }

        $entry = [
            'name'        => $name,
            'path'        => Paths::backups() . '/' . $name,
            'scheduledAt' => time(),
            'deleteAt'    => time() + self::RETENTION_SECONDS,
        ];

        $json = json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $tmp = $marker . '.tmp-' . bin2hex(random_bytes(4));

        if (@file_put_contents($tmp, $json) === false || !@rename($tmp, $marker)) {
            @unlink($tmp);
            return;
        }

        Logger::info('فایل پشتیبان برای حذف خودکار زمان‌بندی شد', [
            'file'    => $name,
            'deleteAt' => date('Y-m-d H:i:s', $entry['deleteAt']),
        ]);
    }

    /**
     * لغو زمان‌بندی حذف یک فایل (در صورت حذف دستی توسط کاربر).
     *
     * @param string $name نام فایل
     *
     * @return void
     */
    public static function cancel(string $name): void
    {
        $name = trim($name);

        if ($name === '') {
            return;
        }

        $marker = self::markerPath($name);

        if (is_file($marker)) {
            @unlink($marker);
        }
    }

    /**
     * زمان‌بندی حذف یک فایل (اگر در صف باشد).
     *
     * @param string $name نام فایل
     *
     * @return int|null زمان حذف به‌صورت یونیکس‌تایم‌استمپ یا null
     */
    public static function scheduledFor(string $name): ?int
    {
        $marker = self::markerPath($name);

        if (!is_file($marker)) {
            return null;
        }

        $raw = @file_get_contents($marker);

        if ($raw === false) {
            return null;
        }

        $data = json_decode($raw, true);

        if (!is_array($data) || !isset($data['deleteAt'])) {
            return null;
        }

        $deleteAt = (int) $data['deleteAt'];

        return $deleteAt > 0 ? $deleteAt : null;
    }

    /**
     * پاک‌سازی خودکار فایل‌هایی که مهلت ۲۴ ساعته‌شان سپری شده.
     *
     * این متد باید هنگام هر فراخوانی اکشن و هر بارگذاری پنل اجرا شود.
     * در صورت نبود پوشهٔ صف، بدون خطا بازمی‌گردد.
     *
     * @return int تعداد فایل‌های حذف‌شده
     */
    public static function gc(): int
    {
        $dir = self::dir();

        if (!is_dir($dir)) {
            return 0;
        }

        $now = time();
        $deleted = 0;

        $markers = glob($dir . '/*.json') ?: [];

        foreach ($markers as $marker) {
            $raw = @file_get_contents($marker);
            $data = is_string($raw) ? json_decode($raw, true) : null;

            // مارکر نامعتبر را پاک کن
            if (!is_array($data)) {
                @unlink($marker);
                continue;
            }

            $deleteAt = (int) ($data['deleteAt'] ?? 0);

            // هنوز زمانش نرسیده
            if ($deleteAt > $now) {
                continue;
            }

            $path = (string) ($data['path'] ?? '');
            $name = (string) ($data['name'] ?? '');

            // اگر فایل هنوز وجود دارد، حذفش کن
            if ($path !== '' && is_file($path)) {
                if (@unlink($path)) {
                    $deleted++;

                    if ($name !== '') {
                        NoteRepository::remove($name);
                    }

                    Logger::info('فایل پشتیبان پس از سپری شدن مهلت ۲۴ ساعته حذف شد', [
                        'file' => $name,
                    ]);
                } else {
                    // حذف ناموفق بود؛ مارکر را نگه دار تا دفعهٔ بعد تلاش شود
                    continue;
                }
            } else {
                // فایل از قبل حذف شده (احتمالاً دستی)؛ فقط مارکر را پاک کن
                if ($name !== '') {
                    NoteRepository::remove($name);
                }
            }

            @unlink($marker);
        }

        return $deleted;
    }

    /**
     * مسیر فایل مارکر برای یک نام پشتیبان.
     *
     * @param string $name نام فایل پشتیبان
     *
     * @return string
     */
    private static function markerPath(string $name): string
    {
        // هگزاسم نام فایل برای جلوگیری از هرگونه مشکل کاراکترهای یونیکد در نام فایل
        return self::dir() . '/' . bin2hex($name) . '.json';
    }
}
