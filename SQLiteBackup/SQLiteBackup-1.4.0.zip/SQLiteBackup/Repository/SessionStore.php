<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Repository;

use TypechoPlugin\SQLiteBackup\Core\Paths;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class SessionStore
{
    private const MAX_AGE = 900;

    /**
     * ساخت نشست جدید.
     *
     * @param string              $kind نوع عملیات
     * @param array<string,mixed> $data داده اولیه نشست
     *
     * @return array{sid:string,data:array<string,mixed>}
     *
     * @throws \RuntimeException در صورت خطای I/O
     */
    public static function create(string $kind, array $data): array
    {
        $sid = bin2hex(random_bytes(16));

        $payload = array_merge($data, [
            'kind'      => $kind,
            'createdAt' => time(),
            'updatedAt' => time(),
        ]);

        self::write($sid, $payload);

        return ['sid' => $sid, 'data' => $payload];
    }

    /**
     * بارگذاری یک نشست.
     *
     * @param string $sid شناسه نشست
     *
     * @return array<string,mixed>|null
     */
    public static function load(string $sid): ?array
    {
        $file = self::path($sid);

        if (!is_file($file)) {
            return null;
        }

        $content = @file_get_contents($file);

        if ($content === false) {
            return null;
        }

        $data = json_decode($content, true);

        if (!is_array($data)) {
            return null;
        }

        return $data;
    }

    /**
     * ذخیره‌سازی نشست.
     *
     * @param string              $sid  شناسه نشست
     * @param array<string,mixed> $data داده نشست
     *
     * @return void
     *
     * @throws \RuntimeException در صورت خطای I/O
     */
    public static function save(string $sid, array $data): void
    {
        $data['updatedAt'] = time();
        self::write($sid, $data);
    }

    /**
     * حذف یک نشست به همراه فایل‌های موقت آن.
     *
     * @param string $sid شناسه نشست
     *
     * @return void
     */
    public static function delete(string $sid): void
    {
        $file = self::path($sid);

        if (is_file($file)) {
            @unlink($file);
        }

        $temp = self::path($sid) . '.part';

        if (is_file($temp)) {
            @unlink($temp);
        }

        // دیتابیس موقت استخراج‌شده در جریان بازیابی
        $tempDb = Paths::sessions() . '/' . $sid . '-database.sqlite';

        if (is_file($tempDb)) {
            @unlink($tempDb);
        }

        $staging = Paths::sessions() . '/' . $sid . '-staging';

        if (is_dir($staging)) {
            \TypechoPlugin\SQLiteBackup\Manager\FileManager::removeDirectory($staging);
        }
    }

    /**
     * پاک‌سازی نشست‌های منقضی و فایل‌های موقت یتیم.
     *
     * نشست‌های بی‌کارگردان (بسته شدن مرورگر میان گام‌ها، قطع شبکه و مانند
     * آن) به همراه اسنپ‌شات دیتابیس، آرشیو نیمه‌کاره و پوشه Staging خود
     * جمع‌آوری می‌شوند. فایل‌هایی که به نشست زنده‌ای ارجاع داده نشده باشند
     * و سن آن‌ها از آستانه گذشته باشد نیز حذف می‌شوند.
     *
     * @return void
     */
    public static function gc(): void
    {
        $dir = Paths::sessions();
        $limit = time() - self::MAX_AGE;
        $referenced = [];

        // مرحله ۱: جمع‌آوری نشست‌های منقضی و فهرست ارجاعات نشست‌های زنده
        foreach (glob($dir . '/*.json') ?: [] as $file) {
            clearstatcache(true, $file);
            $sid = basename($file, '.json');

            if ((int) filemtime($file) < $limit) {
                self::delete($sid);
                continue;
            }

            $content = @file_get_contents($file);
            $data = $content === false ? null : json_decode($content, true);

            if (is_array($data)) {
                self::collectReferences($data, $referenced);
            }
        }

        // مرحله ۲: حذف فایل‌های موقت یتیم در پوشه نشست‌ها
        // (اسنپ‌شات‌های دیتابیس، آرشیوهای نیمه‌کاره، دیتابیس موقت بازیابی)
        $patterns = ['db-*.sqlite', 'work-*.part', '*-database.sqlite', '*.json.part'];

        foreach ($patterns as $pattern) {
            foreach (glob($dir . '/' . $pattern) ?: [] as $file) {
                clearstatcache(true, $file);
                $base = basename($file);

                // سن کم = ممکن است در همان لحظه توسط یک init هم‌زمان در حال ساخت باشد
                if (isset($referenced[$base]) || (int) filemtime($file) >= $limit) {
                    continue;
                }

                @unlink($file);
            }
        }

        // مرحله ۳: حذف پوشه‌های Staging یتیم
        foreach (glob($dir . '/*-staging', GLOB_ONLYDIR) ?: [] as $staging) {
            $base = basename($staging);
            $sid = substr($base, 0, -strlen('-staging'));

            if (isset($referenced[$base]) || is_file($dir . '/' . $sid . '.json')) {
                continue;
            }

            clearstatcache(true, $staging);

            if ((int) filemtime($staging) < $limit) {
                \TypechoPlugin\SQLiteBackup\Manager\FileManager::removeDirectory($staging);
            }
        }

        // مرحله ۴: حذف فایل‌های نیمه‌کاره انتقال ابری در پوشه پشتیبان‌ها
        foreach (glob(Paths::backups() . '/*.part') ?: [] as $file) {
            clearstatcache(true, $file);
            $base = basename($file);

            if (isset($referenced[$base]) || (int) filemtime($file) >= $limit) {
                continue;
            }

            @unlink($file);
        }
    }

    /**
     * گردآوری نام فایل‌های ارجاع‌شده در داده نشست (به صورت بازگشتی).
     *
     * @param array<mixed>        $data داده نشست
     * @param array<string,true>  $out  مجموعه نام فایل‌های ارجاع‌شده
     *
     * @return void
     */
    private static function collectReferences(array $data, array &$out): void
    {
        foreach ($data as $value) {
            if (is_array($value)) {
                self::collectReferences($value, $out);
            } elseif (is_string($value) && $value !== '') {
                $out[basename($value)] = true;
            }
        }
    }

    /**
     * مسیر فایل یک نشست.
     *
     * @param string $sid شناسه نشست
     *
     * @return string
     */
    private static function path(string $sid): string
    {
        return Paths::sessions() . '/' . $sid . '.json';
    }

    /**
     * نوشتن فایل نشست.
     *
     * @param string              $sid  شناسه نشست
     * @param array<string,mixed> $data داده نشست
     *
     * @return void
     *
     * @throws \RuntimeException در صورت خطای I/O
     */
    private static function write(string $sid, array $data): void
    {
        Paths::ensureDirectory(Paths::sessions());

        $file = self::path($sid);
        $json = (string) json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        if (@file_put_contents($file, $json, LOCK_EX) === false) {
            throw new \RuntimeException('ذخیره‌سازی نشست عملیات ناموفق بود');
        }

        @chmod($file, 0600);
    }
}
