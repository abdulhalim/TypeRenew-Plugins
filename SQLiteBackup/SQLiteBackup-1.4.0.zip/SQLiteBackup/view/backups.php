<?php
declare(strict_types=1);

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

use TypechoPlugin\SQLiteBackup\Text;

/**
 * @var array<string,string>      $settings
 * @var array<string,mixed>       $stats
 * @var array<int,array<string,mixed>> $backups
 * @var string                    $currentTab
 */
?>
<div class="br-pane<?php echo ($currentTab ?? '') === 'backups' ? ' is-active' : ''; ?>" data-br-pane="backups" role="tabpanel">
    <section class="br-card">
        <div class="br-card-body">
            <div class="br-section-head">
                <h3 class="br-section-title"><?php echo Text::e(_t('فایل‌های پشتیبان محلی')); ?></h3>
                <div class="br-section-actions">
                    <span class="br-pill"><?php echo Text::e(sprintf(_t('%s فایل'), Text::int((int) $stats['count']))); ?></span>
                    <span class="br-pill"><?php echo Text::e(sprintf(_t('حجم کل: %s'), Text::size((int) $stats['size']))); ?></span>
                    <button type="button" class="br-btn br-btn-ghost br-btn-sm" id="br-refresh-backups"><?php echo Text::e(_t('به‌روزرسانی فهرست')); ?></button>
                </div>
            </div>

            <?php if ($settings['retentionCount'] !== '0'): ?>
                <p class="br-help">
                    <?php echo Text::e(sprintf(
                        _t('سیاست نگهداشت فعال است: حداکثر %s نسخه عادی و ۳ نسخه اضطراری نگهداری می‌شوند.'),
                        Text::num($settings['retentionCount'])
                    )); ?>
                </p>
            <?php endif; ?>
            <p class="br-help">
                <?php echo Text::e(_t('بکاپ‌های کامل پس از دانلود، ۲۴ ساعت دیگر به‌طور خودکار از سرور حذف می‌شوند تا در صورت بروز مشکل در دریافت، امکان دانلود مجدد فراهم باشد.')); ?>
            </p>

            <div class="br-bulk-bar" id="br-bulk-bar" hidden>
                <span class="br-bulk-count" id="br-bulk-count"></span>
                <span class="br-bulk-actions">
                    <button type="button" class="br-btn br-btn-danger-ghost br-btn-sm" id="br-bulk-delete"><?php echo Text::e(_t('حذف انتخاب‌شده‌ها')); ?></button>
                    <button type="button" class="br-btn br-btn-ghost br-btn-sm" id="br-bulk-clear"><?php echo Text::e(_t('برداشتن انتخاب')); ?></button>
                </span>
            </div>

            <div class="br-table-wrap">
                <table class="br-table" id="br-backups-table">
                    <thead>
                        <tr>
                            <?php if ($backups !== []): ?>
                                <th class="br-col-check"><input type="checkbox" id="br-check-all" aria-label="<?php echo Text::e(_t('انتخاب همه')); ?>" title="<?php echo Text::e(_t('انتخاب همه')); ?>" /></th>
                            <?php endif; ?>
                            <th><?php echo Text::e(_t('نام فایل')); ?></th>
                            <th><?php echo Text::e(_t('نوع')); ?></th>
                            <th><?php echo Text::e(_t('تاریخ ساخت')); ?></th>
                            <th><?php echo Text::e(_t('حجم')); ?></th>
                            <th><?php echo Text::e(_t('وضعیت')); ?></th>
                            <th><?php echo Text::e(_t('عملیات')); ?></th>
                        </tr>
                    </thead>
                    <tbody id="br-backups-list">
                        <?php if ($backups === []): ?>
                            <tr class="br-table-empty-row">
                                <td colspan="7"><?php echo Text::e(_t('هنوز هیچ فایل پشتیبانی ساخته نشده است.')); ?></td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($backups as $backup): ?>
                                <?php
                                $noteEntry = is_array($backup['note'] ?? null) ? $backup['note'] : null;
                                $rowNote = $noteEntry !== null ? trim((string) ($noteEntry['note'] ?? '')) : '';
                                $nameTitle = (string) $backup['name'];

                                if ($rowNote !== '') {
                                    $nameTitle .= "\n" . sprintf(_t('یادداشت: %s'), $rowNote);
                                }

                                if ($backup['valid'] !== true) {
                                    $nameTitle .= "\n" . _t('manifest غایب، ناقص یا نامعتبر است');
                                }

                                $manifest = is_array($backup['manifest'] ?? null) ? $backup['manifest'] : null;
                                $typeLabel = match ($backup['type']) {
                                    'full'      => _t('کامل'),
                                    'emergency' => _t('اضطراری'),
                                    default     => _t('عادی'),
                                };
                                ?>
                                <tr class="<?php echo $backup['valid'] === true ? '' : 'br-row-invalid'; ?>"
                                    data-file="<?php echo Text::e((string) $backup['name']); ?>"
                                    data-type="<?php echo Text::e((string) $backup['type']); ?>"
                                    <?php if ($rowNote !== ''): ?>data-note="<?php echo Text::e($rowNote); ?>"<?php endif; ?>>

                                    <td class="br-col-check">
                                        <input type="checkbox" class="br-row-check" value="<?php echo Text::e((string) $backup['name']); ?>"
                                            aria-label="<?php echo Text::e(_t('انتخاب این فایل')); ?>" />
                                    </td>

                                    <td class="br-cell-name">
                                        <span class="br-file-name jalali-converted-date" title="<?php echo Text::e($nameTitle); ?>"><?php echo Text::e((string) $backup['name']); ?></span>
                                        <?php if ($manifest !== null): ?>
                                            <span class="br-cell-meta"><?php echo Text::e(sprintf(_t('%s فایل'), Text::int((int) ($manifest['totalFiles'] ?? 0)))); ?></span>
                                            <?php if ((string) ($manifest['platform'] ?? '') !== ''): ?>
                                                <span class="br-cell-meta"><?php echo Text::e(sprintf('%s %s', (string) $manifest['platform'], Text::num((string) ($manifest['platformVersion'] ?? '')))); ?></span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <span class="br-cell-meta br-note-line"<?php echo $rowNote === '' ? ' hidden' : ''; ?>><?php echo Text::e($rowNote === '' ? '' : sprintf(_t('یادداشت: %s'), $rowNote)); ?></span>
                                    </td>

                                    <td>
                                        <?php if ($backup['type'] === 'full'): ?>
                                            <span class="br-badge br-badge-full" title="<?php echo Text::e(_t('بکاپ کامل ریشه سایت — فقط برای استفاده اضطراری از طریق FTP')); ?>"><?php echo Text::e($typeLabel); ?></span>
                                        <?php elseif ($backup['type'] === 'emergency'): ?>
                                            <span class="br-badge br-badge-warn" title="<?php echo Text::e(_t('پشتیبان اضطراری ساخته‌شده پیش از بازیابی')); ?>"><?php echo Text::e($typeLabel); ?></span>
                                        <?php else: ?>
                                            <span class="br-badge br-badge-info"><?php echo Text::e($typeLabel); ?></span>
                                        <?php endif; ?>
                                    </td>

                                    <td class="br-cell-date"><?php echo Text::e(Text::date((int) $backup['mtime'])); ?></td>
                                    <td class="br-cell-size"><?php echo Text::e(Text::size((int) $backup['size'])); ?></td>

                                    <td>
                                        <?php if ($backup['valid'] === true): ?>
                                            <span class="br-badge br-badge-ok"><?php echo Text::e(_t('سالم')); ?></span>
                                        <?php else: ?>
                                            <span class="br-badge br-badge-danger" title="<?php echo Text::e(_t('manifest غایب، ناقص یا نامعتبر است')); ?>"><?php echo Text::e(_t('نامعتبر')); ?></span>
                                        <?php endif; ?>
                                    </td>

                                    <td class="br-cell-actions">
                                        <div class="br-actions">
                                            <?php if ($backup['type'] === 'full'): ?>
                                                <button type="button" class="br-btn br-btn-danger-ghost br-btn-sm br-act-download"
                                                    <?php echo $backup['valid'] ? '' : 'disabled'; ?>
                                                    title="<?php echo Text::e(_t('بکاپ کامل فقط برای دانلود است؛ ۲۴ ساعت پس از دانلود به‌طور خودکار از سرور حذف می‌شود')); ?>"><?php echo Text::e(_t('دانلود')); ?></button>
                                                <button type="button" class="br-btn br-btn-ghost br-btn-sm br-act-delete"><?php echo Text::e(_t('حذف')); ?></button>
                                            <?php else: ?>
                                                <button type="button" class="br-btn br-btn-danger-ghost br-btn-sm br-act-restore"
                                                    <?php echo $backup['valid'] ? '' : 'disabled'; ?>><?php echo Text::e(_t('بازگردانی')); ?></button>
                                                <button type="button" class="br-btn br-btn-ghost br-btn-sm br-act-download"
                                                    <?php echo $backup['valid'] ? '' : 'disabled'; ?>><?php echo Text::e(_t('دانلود')); ?></button>
                                                <button type="button" class="br-btn br-btn-ghost br-btn-sm br-act-note<?php echo $rowNote !== '' ? ' br-has-note' : ''; ?>"
                                                    title="<?php echo Text::e($rowNote !== '' ? sprintf(_t('یادداشت: %s'), $rowNote) : _t('یادداشت نسخه (اختیاری)')); ?>"><?php echo Text::e(_t('یادداشت')); ?></button>
                                                <button type="button" class="br-btn br-btn-danger-ghost br-btn-sm br-act-delete"><?php echo Text::e(_t('حذف')); ?></button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>
