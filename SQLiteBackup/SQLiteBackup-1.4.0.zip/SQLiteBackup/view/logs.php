<?php
declare(strict_types=1);

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

use TypechoPlugin\SQLiteBackup\Text;

/** @var array<int,string> $logs */
/** @var string $currentTab */

$brLogLevels = [
    'موفق'    => 'success',
    'خطا'     => 'error',
    'هشدار'   => 'warning',
    'اطلاعات' => 'info',
];
?>
<div class="br-pane<?php echo ($currentTab ?? '') === 'logs' ? ' is-active' : ''; ?>" data-br-pane="logs" role="tabpanel">
    <section class="br-card">
        <div class="br-card-body">
            <div class="br-section-head">
                <h3 class="br-section-title"><?php echo Text::e(_t('گزارش عملیات')); ?></h3>
                <div class="br-section-actions">
                    <button type="button" class="br-btn br-btn-ghost br-btn-sm" id="br-log-copy-all" title="<?php echo Text::e(_t('کپی همه گزارش‌ها در کلیپ‌بورد')); ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                        <?php echo Text::e(_t('کپی همه')); ?>
                    </button>
                    <button type="button" class="br-btn br-btn-ghost br-btn-sm" id="br-log-refresh"><?php echo Text::e(_t('به‌روزرسانی')); ?></button>
                    <button type="button" class="br-btn br-btn-danger-ghost br-btn-sm" id="br-log-clear"><?php echo Text::e(_t('پاک کردن گزارش‌ها')); ?></button>
                </div>
            </div>
            <p class="br-help"><?php echo Text::e(_t('آخرین رویدادهای ساخت، بازیابی، مدیریت نسخه‌ها و رخدادهای امنیتی.')); ?></p>
            <div class="br-log-view" id="br-log-view" dir="rtl">
                <?php if ($logs === []): ?>
                    <div class="br-log-empty"><?php echo Text::e(_t('گزارشی ثبت نشده است.')); ?></div>
                <?php else: ?>
                    <?php foreach ($logs as $line): ?>
                        <?php
                        // قالب خط: [تاریخ] [سطح] [کاربر: x] [IP: x] پیام — زمینه
                        $levelClass = '';
                        $datePart = '';
                        $restPart = $line;

                        if (preg_match('/^\[([^\]]+)\]\s*\[([^\]]+)\]\s*(.*)$/u', $line, $m)) {
                            $datePart = $m[1];
                            $levelName = $m[2];
                            $restPart = $m[3];

                            if (isset($brLogLevels[$levelName])) {
                                $levelClass = ' br-log-' . $brLogLevels[$levelName];
                            }
                        }
                        ?>
                        <div class="br-log-line<?php echo $levelClass; ?>" data-copy="<?php echo Text::e($line); ?>">
                            <?php if ($datePart !== ''): ?>
                                <span class="br-log-date"><?php echo Text::e($datePart); ?></span>
                                <span class="br-log-level"><?php echo Text::e($m[2]); ?></span>
                                <span class="br-log-msg jalali-converted-date"><?php echo Text::e($restPart); ?></span>
                            <?php else: ?>
                                <span class="br-log-msg jalali-converted-date"><?php echo Text::e($line); ?></span>
                            <?php endif; ?>
                            <button type="button" class="br-log-copy" title="<?php echo Text::e(_t('کپی این خط')); ?>" aria-label="<?php echo Text::e(_t('کپی این خط')); ?>">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                            </button>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
</div>
