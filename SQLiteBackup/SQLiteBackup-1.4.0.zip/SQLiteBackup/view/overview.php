<?php
declare(strict_types=1);

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

use TypechoPlugin\SQLiteBackup\Text;

/**
 * @var array<string,string>      $settings
 * @var array<string,mixed>       $database
 * @var array{files:int,bytes:int} $uploads
 * @var array<string,mixed>       $stats
 * @var int                       $diskFree
 * @var int                       $diskTotal
 * @var int                       $diskPercent
 * @var array<int,array<string,mixed>> $backups
 * @var int|null                  $uploadMaxBytes
 * @var string                    $currentTab
 */

/* فقط فایل‌های سالم و غیرکامل برای بازیابی از سرور (دراپ‌داون) */
$restoreOptions = [];

foreach ($backups as $backup) {
    if (($backup['valid'] ?? null) === true && ($backup['type'] ?? '') !== 'full') {
        $restoreOptions[] = $backup;
    }
}
?>
<div class="br-pane<?php echo ($currentTab ?? 'overview') === 'overview' ? ' is-active' : ''; ?>" data-br-pane="overview" role="tabpanel">

    <section class="br-card">
        <div class="br-card-body">
            <h3 class="br-section-title"><?php echo Text::e(_t('وضعیت سایت')); ?></h3>
            <div class="br-kpis">
                <article class="br-kpi">
                    <div class="br-kpi-main">
                        <strong class="br-kpi-value"><?php echo Text::e((string) $database['adapter']); ?></strong>
                        <span class="br-kpi-label"><?php echo Text::e(_t('نوع دیتابیس')); ?></span>
                        <span class="br-kpi-meta"><?php echo Text::e(sprintf(_t('حجم: %s'), Text::size((int) $database['size']))); ?></span>
                        <?php if ((string) ($database['engine'] ?? '') !== ''): ?>
                            <span class="br-kpi-meta"><?php echo Text::e(sprintf(_t('موتور: %s'), Text::num((string) $database['engine']))); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="br-kpi-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="9" ry="3"></ellipse><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path></svg>
                    </div>
                </article>
                <article class="br-kpi">
                    <div class="br-kpi-main">
                        <strong class="br-kpi-value"><?php echo Text::e(Text::size((int) $uploads['bytes'])); ?></strong>
                        <span class="br-kpi-label"><?php echo Text::e(_t('پوشه بارگذاری‌ها')); ?></span>
                        <span class="br-kpi-meta"><?php echo Text::e(sprintf(_t('%s فایل'), Text::int((int) $uploads['files']))); ?></span>
                        <span class="br-kpi-meta"><?php echo Text::e(_t('مسیر: usr/uploads')); ?></span>
                    </div>
                    <div class="br-kpi-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"></path></svg>
                    </div>
                </article>
                <article class="br-kpi">
                    <div class="br-kpi-main">
                        <strong class="br-kpi-value"><?php echo Text::e(Text::int((int) $stats['count'])); ?></strong>
                        <span class="br-kpi-label"><?php echo Text::e(_t('پشتیبان‌های محلی')); ?></span>
                        <span class="br-kpi-meta"><?php echo Text::e(sprintf(_t('حجم کل: %s'), Text::size((int) $stats['size']))); ?></span>
                        <span class="br-kpi-meta"><?php echo Text::e(_t('مسیر: usr/backups')); ?></span>
                    </div>
                    <div class="br-kpi-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="5" rx="1"></rect><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"></path><path d="M10 12h4"></path></svg>
                    </div>
                </article>
                <article class="br-kpi">
                    <div class="br-kpi-main">
                        <strong class="br-kpi-value"><?php echo Text::e(Text::size($diskFree)); ?></strong>
                        <span class="br-kpi-label"><?php echo Text::e(_t('فضای خالی دیسک')); ?></span>
                        <?php if ($diskTotal > 0): ?>
                            <span class="br-kpi-meta"><?php echo Text::e(sprintf(_t('از %s کل'), Text::size($diskTotal))); ?></span>
                            <span class="br-kpi-meta">
                                <span class="br-mini-track"><span class="br-mini-fill" style="width:<?php echo $diskPercent; ?>%"></span></span>
                                <?php echo Text::e(sprintf(_t('%s٪ آزاد'), Text::num($diskPercent))); ?>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="br-kpi-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="12" x2="2" y2="12"></line><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"></path><line x1="6" y1="16" x2="6.01" y2="16"></line><line x1="10" y1="16" x2="10.01" y2="16"></line></svg>
                    </div>
                </article>
            </div>
        </div>
    </section>

    <div class="br-grid-2">
        <section class="br-card">
            <div class="br-card-body">
                <h3 class="br-section-title"><?php echo Text::e(_t('ساخت نسخه پشتیبان')); ?></h3>

                <div class="br-subtabs" role="tablist" aria-label="<?php echo Text::e(_t('نوع پشتیبان')); ?>">
                    <button type="button" role="tab" class="br-subtab is-active" aria-selected="true"
                        data-br-subtab="db"><?php echo Text::e(_t('پایگاه داده')); ?></button>
                    <button type="button" role="tab" class="br-subtab" aria-selected="false"
                        data-br-subtab="full"><?php echo Text::e(_t('کل سایت')); ?></button>
                </div>

                <div class="br-subpanel" data-br-subpanel="db" role="tabpanel">
                    <p class="br-help">
                        <?php echo Text::e(_t('یک فایل ZIP شامل اسنپ‌شات کامل دیتابیس SQLite، همه محتویات پوشه بارگذاری‌ها و فایل manifest ساخته می‌شود.')); ?>
                    </p>
                    <ul class="br-feature-list">
                        <li><?php echo Text::e(_t('پشتیبان‌گیری به صورت قطعه‌ای و بدون محدودیت زمان اجرا انجام می‌شود')); ?></li>
                        <li><?php echo Text::e(_t('checksum کامل و تاریخ ساخت هر نسخه در manifest ثبت می‌شود')); ?></li>
                        <li><?php echo Text::e(_t('می‌توانید برای هر نسخه یادداشت بنویسید و آن را در تب «پشتیبان‌ها» ببینید')); ?></li>
                    </ul>
                    <div class="br-field">
                        <label class="br-label" for="br-backup-note"><?php echo Text::e(_t('یادداشت این نسخه (اختیاری)')); ?></label>
                        <textarea class="br-textarea" id="br-backup-note" rows="2" maxlength="500"
                            placeholder="<?php echo Text::e(_t('مثلاً: پیش از به‌روزرسانی قالب')); ?>"></textarea>
                        <span class="br-field-hint"><?php echo Text::e(_t('این یادداشت زیر نام نسخه پشتیبان در تب «پشتیبان‌ها» نمایش داده می‌شود و بعداً قابل ویرایش است.')); ?></span>
                    </div>
                    <div class="br-actions-bar">
                        <button type="button" class="br-btn br-btn-primary" id="br-backup-create">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                            <?php echo Text::e(_t('شروع پشتیبان‌گیری')); ?>
                        </button>
                    </div>
                    <div class="br-progress-wrap" id="br-backup-progress" hidden>
                        <div class="br-progress-head">
                            <span class="br-progress-label"><?php echo Text::e(_t('در حال ساخت پشتیبان…')); ?></span>
                            <span class="br-progress-percent" id="br-backup-percent">۰٪</span>
                        </div>
                        <div class="br-progress-track"><div class="br-progress-fill" id="br-backup-fill" style="width:0%"></div></div>
                        <div class="br-progress-meta" id="br-backup-meta"></div>
                        <button type="button" class="br-btn br-btn-ghost br-btn-sm br-backup-cancel-btn" id="br-backup-cancel"><?php echo Text::e(_t('لغو')); ?></button>
                    </div>
                </div>

                <div class="br-subpanel" data-br-subpanel="full" role="tabpanel" hidden>
                    <p class="br-help">
                        <?php echo Text::e(_t('یک ZIP از کل ریشه سایت با همان ساختار فایل‌ها، همان پرمیشن‌ها و همان نام دیتابیس؛ مناسب بازگردانی اضطراری از طریق FTP.')); ?>
                    </p>
                    <ul class="br-feature-list">
                        <li><?php echo Text::e(_t('فایل‌های سایت به‌همراه دیتابیس و اسکریپت بازگردانی پرمیشن‌ها در یک بسته واحد')); ?></li>
                        <li><?php echo Text::e(_t('پوشه بکاپ‌های موجود در بسته قرار نمی‌گیرد تا حجم بی‌مورد تولید نشود')); ?></li>
                    </ul>
                    <p class="br-help br-help-warn">
                        <?php echo Text::e(_t('این بسته فقط برای شرایط اضطراری است و پس از پایان دانلود، به‌طور خودکار از سرور حذف می‌شود.')); ?>
                    </p>
                    <div class="br-actions-bar">
                        <button type="button" class="br-btn br-btn-danger" id="br-fullbackup-create">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6 12 12.01 20.73 6"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>
                            <?php echo Text::e(_t('ساخت بکاپ کامل')); ?>
                        </button>
                    </div>
                    <div class="br-progress-wrap" id="br-fullbackup-progress" hidden>
                        <div class="br-progress-head">
                            <span class="br-progress-label"><?php echo Text::e(_t('در حال ساخت بکاپ کامل…')); ?></span>
                            <span class="br-progress-percent" id="br-fullbackup-percent">۰٪</span>
                        </div>
                        <div class="br-progress-track"><div class="br-progress-fill" id="br-fullbackup-fill" style="width:0%"></div></div>
                        <div class="br-progress-meta" id="br-fullbackup-meta"></div>
                        <button type="button" class="br-btn br-btn-ghost br-btn-sm" id="br-fullbackup-cancel"><?php echo Text::e(_t('لغو')); ?></button>
                    </div>
                </div>

                <?php if ($diskFree > 0): ?>
                    <div class="br-card-foot">
                        <span class="br-disk-line">
                            <?php
                            echo Text::e(sprintf(
                                _t('فضای آزاد دیسک: %s%s'),
                                Text::size($diskFree),
                                $diskTotal > 0 ? sprintf(_t(' از %s'), Text::size($diskTotal)) : ''
                            ));
                            ?>
                        </span>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <section class="br-card">
            <div class="br-card-body">
                <h3 class="br-section-title"><?php echo Text::e(_t('بازیابی نسخه پشتیبان')); ?></h3>

                <div class="br-subtabs" role="tablist" aria-label="<?php echo Text::e(_t('منبع بازیابی')); ?>">
                    <button type="button" role="tab" class="br-subtab is-active" aria-selected="true"
                        data-br-subtab="server"><?php echo Text::e(_t('از سرور')); ?></button>
                    <button type="button" role="tab" class="br-subtab" aria-selected="false"
                        data-br-subtab="local"><?php echo Text::e(_t('از فایل لوکال')); ?></button>
                </div>

                <div class="br-subpanel" data-br-subpanel="server" role="tabpanel">
                    <p class="br-help">
                        <?php echo Text::e(_t('محتوای دیتابیس و پوشه بارگذاری‌ها به‌طور کامل به وضعیت لحظه ساخت نسخه انتخابی بازمی‌گردد.')); ?>
                    </p>
                    <ul class="br-feature-list">
                        <li><?php echo Text::e(_t('پیش از بازگردانی، صحت فایل و checksum آن به‌طور خودکار بررسی می‌شود')); ?></li>
                        <li><?php echo Text::e(_t('پیش از هر بازیابی، یک نسخه پشتیبان اضطراری از وضعیت فعلی ساخته می‌شود')); ?></li>
                        <li><?php echo Text::e(_t('پس از پایان عملیات، کش سیستم برای بارگذاری داده‌های جدید پاک‌سازی می‌شود')); ?></li>
                    </ul>
                    <div class="br-field">
                        <label class="br-label" for="br-restore-select"><?php echo Text::e(_t('انتخاب فایل پشتیبان')); ?></label>
                        <select class="br-select" id="br-restore-select">
                            <option value=""><?php echo Text::e($restoreOptions === []
                                ? _t('فایل پشتیبان سالمی برای بازیابی وجود ندارد')
                                : _t('— یک فایل پشتیبان انتخاب کنید —')); ?></option>
                            <?php foreach ($restoreOptions as $backup): ?>
                                <option value="<?php echo Text::e((string) $backup['name']); ?>">
                                    <?php echo Text::e(sprintf(
                                        '%s (%s - %s)',
                                        (string) $backup['name'],
                                        ($backup['type'] ?? '') === 'emergency' ? _t('اضطراری') : _t('عادی'),
                                        Text::size((int) $backup['size'])
                                    )); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <span class="br-field-hint"><?php echo Text::e(_t('فقط فایل‌های سالم که صحت آن‌ها تأیید شده است در این فهرست نمایش داده می‌شوند.')); ?></span>
                    </div>
                    <div class="br-actions-bar">
                        <button type="button" class="br-btn br-btn-danger" id="br-restore-start" disabled>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="1 4 1 10 7 10"></polyline><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"></path></svg>
                            <?php echo Text::e(_t('بررسی و بازیابی')); ?>
                        </button>
                    </div>
                </div>

                <div class="br-subpanel" data-br-subpanel="local" role="tabpanel" hidden>
                    <p class="br-help">
                        <?php echo Text::e(_t('فایل ZIP پشتیبان ساخته‌شده توسط همین افزونه را از سیستم خود بارگذاری کنید؛ پس از بررسی صحت به فهرست «پشتیبان‌ها» اضافه می‌شود و دکمه بازگردانی مستقل خواهد داشت.')); ?>
                    </p>
                    <ul class="br-feature-list">
                        <li><?php echo Text::e(_t('صحت ساختار ZIP و manifest پیش از پذیرش فایل بررسی می‌شود')); ?></li>
                        <li><?php echo Text::e(_t('در صورت هم‌نامی با فایل موجود، نام فایل جدید به‌طور خودکار تغییر می‌کند')); ?></li>
                    </ul>
                    <div class="br-field">
                        <input type="file" class="br-file-input" id="br-upload-file" accept=".zip,application/zip" />
                        <span class="br-field-hint"><?php echo Text::e(sprintf(
                            _t('سقف حجم قابل بارگذاری بر اساس تنظیمات PHP: %s'),
                            $uploadMaxBytes !== null ? Text::size((int) $uploadMaxBytes) : 'نامحدود'
                        )); ?></span>
                    </div>
                    <div class="br-actions-bar">
                        <button type="button" class="br-btn br-btn-primary" id="br-upload-start" disabled>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                            <?php echo Text::e(_t('بارگذاری')); ?>
                        </button>
                    </div>
                    <div class="br-progress-wrap" id="br-upload-progress" hidden>
                        <div class="br-progress-head">
                            <span class="br-progress-label" id="br-upload-label"><?php echo Text::e(_t('در حال بارگذاری…')); ?></span>
                            <span class="br-progress-percent" id="br-upload-percent"></span>
                        </div>
                        <div class="br-progress-track"><div class="br-progress-fill" id="br-upload-fill" style="width:0%"></div></div>
                        <div class="br-progress-meta" id="br-upload-meta"></div>
                    </div>
                </div>

                <div class="br-progress-wrap" id="br-restore-progress" hidden>
                    <div class="br-progress-head">
                        <span class="br-progress-label" id="br-restore-label"><?php echo Text::e(_t('در حال بازیابی…')); ?></span>
                        <span class="br-progress-percent" id="br-restore-percent">۰٪</span>
                    </div>
                    <div class="br-progress-track"><div class="br-progress-fill" id="br-restore-fill" style="width:0%"></div></div>
                    <div class="br-progress-meta" id="br-restore-meta"></div>
                </div>
            </div>
        </section>
    </div>
</div>
