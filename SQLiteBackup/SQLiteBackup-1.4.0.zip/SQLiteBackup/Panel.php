<?php

declare(strict_types=1);

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

use TypechoPlugin\SQLiteBackup\Core\Clock;
use TypechoPlugin\SQLiteBackup\Core\Disk;
use TypechoPlugin\SQLiteBackup\Core\Logger;
use TypechoPlugin\SQLiteBackup\Core\Paths;
use TypechoPlugin\SQLiteBackup\Core\Security;
use TypechoPlugin\SQLiteBackup\Manager\FileManager;
use TypechoPlugin\SQLiteBackup\Core\PluginInfo;
use TypechoPlugin\SQLiteBackup\Repository\BackupRepository;
use TypechoPlugin\SQLiteBackup\Service\DatabaseService;
use TypechoPlugin\SQLiteBackup\Service\UploadService;
use TypechoPlugin\SQLiteBackup\Settings;
use TypechoPlugin\SQLiteBackup\Text;

$user->pass('administrator');

// پاک‌سازی خودکار فایل‌های زمان‌بندی‌شده برای حذف که مهلت ۲۴ ساعته‌شان سپری شده
\TypechoPlugin\SQLiteBackup\Repository\DeleteQueue::gc();

$settings = Settings::load();
$database = DatabaseService::info();
$uploads = FileManager::usage(Paths::uploads());
$stats = BackupRepository::stats();
$backups = BackupRepository::all();
$logs = Logger::tail(150);
$diskFree  = Disk::free();
$diskTotal = Disk::total();
$diskFree  = $diskFree !== null ? (int) $diskFree : 0;
$diskTotal = $diskTotal !== null ? (int) $diskTotal : 0;
$diskPercent = $diskTotal > 0
    ? max(0, min(100, (int) floor($diskFree / max(1, $diskTotal) * 100)))
    : 0;
$uploadMaxBytes = UploadService::maxUploadBytes();

$tabs = [
    'overview' => 'پیشخوان',
    'backups'  => 'پشتیبان‌ها',
    'logs'     => 'گزارش‌ها',
];

$currentTab = trim((string) $request->get('tab', 'overview'));

if (!array_key_exists($currentTab, $tabs)) {
    $currentTab = 'overview';
}

$jsConfig = [
    'urls' => [
        'status'          => Security::actionUrl('status'),
        'backup.init'     => Security::actionUrl('backup.init'),
        'backup.step'     => Security::actionUrl('backup.step'),
        'backup.finalize' => Security::actionUrl('backup.finalize'),
        'backup.cancel'   => Security::actionUrl('backup.cancel'),
        'backup.download' => Security::actionUrl('backup.download'),
        'backup.delete'   => Security::actionUrl('backup.delete'),
        'backup.deleteBatch' => Security::actionUrl('backup.deleteBatch'),
        'backup.upload'   => Security::actionUrl('backup.upload'),
        'note.save'       => Security::actionUrl('note.save'),
        'restore.check'   => Security::actionUrl('restore.check'),
        'restore.init'    => Security::actionUrl('restore.init'),
        'restore.step'    => Security::actionUrl('restore.step'),
        'restore.db'      => Security::actionUrl('restore.db'),
        'restore.finish'  => Security::actionUrl('restore.finish'),
        'restore.cancel'  => Security::actionUrl('restore.cancel'),
        'settings.save'   => Security::actionUrl('settings.save'),
        'log.tail'        => Security::actionUrl('log.tail'),
        'log.clear'       => Security::actionUrl('log.clear'),
    ],
    'initial' => [
        'database' => [
            'adapter'  => $database['adapter'],
            'isSqlite' => $database['isSqlite'],
            'size'     => $database['size'],
            'engine'   => $database['engine'],
        ],
        'uploads'   => $uploads,
        'backups'   => $stats,
        'diskFree'  => $diskFree,
        'diskTotal' => $diskTotal,
        'timezone'  => [
            'id'            => Clock::timezoneId(),
            'label'         => Clock::timezoneLabel(),
            'offsetSeconds' => (int) ((new \DateTimeZone(Clock::timezoneId()))->getOffset(new \DateTimeImmutable('now'))),
        ],
        'upload'    => [
            'maxBytes' => $uploadMaxBytes,
            'maxLabel' => $uploadMaxBytes !== null ? Text::size((int) $uploadMaxBytes) : 'نامحدود',
        ],
    ],
];

// پیغام یک‌بارهٔ حذف بکاپ کامل پس از دانلود
$fullNotice = '';
$noticeFile = Paths::backups() . '/.fullbackup-notice';

if (is_file($noticeFile)) {
    $rawNotice = trim((string) @file_get_contents($noticeFile));
    $fullNotice = Text::cut($rawNotice, 300);
    @unlink($noticeFile);
}
?>
<link rel="stylesheet" href="<?php echo Text::e(Settings::assetUrl('assets/panel.css')); ?>">
<div class="br-panel" dir="rtl" id="br-panel"
     data-config="<?php echo Text::e(json_encode($jsConfig, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)); ?>">

    <header class="br-head">
        <div class="br-head-main">
            <div class="br-head-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 8v13H3V8"/><path d="M1 3h22v5H1z"/><path d="M10 12h4"/>
                </svg>
            </div>
            <div class="br-head-text">
                <h2 class="br-title"><?php echo Text::e(_t('تهیه پشتیبان')); ?></h2>
                <p class="br-subtitle">
                    <?php echo Text::e(_t('پشتیبان‌گیری از دیتابیس SQLite و فایل‌های سایت همراه با بازیابی هوشمند و یادداشت‌گذاری نسخه‌ها.')); ?>
                </p>
            </div>
        </div>
        <div class="br-head-side">
            <span class="br-pill<?php echo $settings['enabled'] === '1' ? ' br-pill-ok' : ' br-pill-warn'; ?>">
                <?php echo $settings['enabled'] === '1' ? Text::e(_t('فعال')) : Text::e(_t('غیرفعال')); ?>
            </span>
            <span class="br-pill"><?php echo Text::e(sprintf(_t('افزونه %s'), PluginInfo::VERSION)); ?></span>
            <span class="br-pill"><?php echo Text::e(sprintf(_t('%s %s'), \Typecho\Common::SOFTWARE, \Typecho\Common::VERSION)); ?></span>
        </div>
    </header>

    <?php if ($fullNotice !== ''): ?>
        <section class="br-card br-card-ok" id="br-fullbackup-notice">
            <div class="br-card-body">
                <strong><?php echo Text::e(_t('بکاپ کامل دانلود شد')); ?></strong>
                <p class="br-help"><?php echo Text::e($fullNotice); ?></p>
            </div>
        </section>
    <?php endif; ?>

    <?php if (!$database['isSqlite']): ?>
        <section class="br-card br-card-danger">
            <div class="br-card-body">
                <strong><?php echo Text::e(_t('دیتابیس سایت SQLite نیست.')); ?></strong>
                <p class="br-help">
                    <?php echo Text::e(sprintf(_t('دیتابیس فعال: %s. این افزونه برای تهیه پشتیبان سطح فایل، مخصوص دیتابیس SQLite طراحی شده است.'), $database['adapter'])); ?>
                </p>
            </div>
        </section>
    <?php endif; ?>

    <nav class="br-tabs" role="tablist" aria-label="<?php echo Text::e(_t('ناوبری پنل پشتیبان‌گیری')); ?>">
        <?php foreach ($tabs as $key => $label): ?>
            <button type="button" role="tab" class="br-tab<?php echo $currentTab === $key ? ' is-active' : ''; ?>"
                    aria-selected="<?php echo $currentTab === $key ? 'true' : 'false'; ?>"
                    data-br-tab="<?php echo Text::e($key); ?>"><?php echo Text::e(_t($label)); ?></button>
        <?php endforeach; ?>
    </nav>

    <div class="br-panes">
        <?php require __DIR__ . '/view/overview.php'; ?>
        <?php require __DIR__ . '/view/backups.php'; ?>
        <?php require __DIR__ . '/view/logs.php'; ?>
    </div>

    <div class="br-modal-backdrop" id="br-modal" hidden>
        <div class="br-modal" role="dialog" aria-modal="true">
            <div class="br-modal-head">
                <h3 id="br-modal-title"><?php echo Text::e(_t('تأیید عملیات')); ?></h3>
                <button type="button" class="br-modal-close" id="br-modal-close" aria-label="<?php echo Text::e(_t('بستن')); ?>">&times;</button>
            </div>
            <div class="br-modal-body" id="br-modal-body"></div>
            <div class="br-modal-foot" id="br-modal-foot"></div>
        </div>
    </div>

    <div class="br-toasts" id="br-toasts" aria-live="polite"></div>
</div>
<script src="<?php echo Text::e(Settings::assetUrl('assets/panel.js')); ?>"></script>
