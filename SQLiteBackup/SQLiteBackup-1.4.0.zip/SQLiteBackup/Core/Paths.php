<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Core;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class Paths
{
    /**
     * سازنده خصوصی.
     */
    private function __construct()
    {
    }

    /**
     * مسیر ریشه سایت.
     *
     * @return string
     */
    public static function root(): string
    {
        return rtrim(str_replace('\\', '/', __TYPECHO_ROOT_DIR__), '/');
    }

    /**
     * مسیر پوشه پشتیبان‌ها.
     *
     * @return string
     */
    public static function backups(): string
    {
        return self::root() . '/usr/backups';
    }

    /**
     * مسیر پوشه بارگذاری‌ها.
     *
     * @return string
     */
    public static function uploads(): string
    {
        return self::root() . '/usr/uploads';
    }

    /**
     * مسیر پوشه نشست‌های عملیات.
     *
     * @return string
     */
    public static function sessions(): string
    {
        return self::backups() . '/.sessions';
    }

    /**
     * مسیر پوشه گزارش‌ها.
     *
     * @return string
     */
    public static function logs(): string
    {
        return self::backups() . '/logs';
    }

    /**
     * مسیر فایل گزارش اصلی.
     *
     * @return string
     */
    public static function logFile(): string
    {
        return self::logs() . '/backup-restore.log';
    }

    /**
     * ساخت پوشه در صورت نبود همراه با محافظت از دسترسی وب.
     *
     * @param string $dir مسیر پوشه
     *
     * @return void
     *
     * @throws \RuntimeException در صورت عدم امکان ساخت
     */
    public static function ensureDirectory(string $dir): void
    {
        if (is_dir($dir)) {
            self::protect($dir);
            return;
        }

        if (!@mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new \RuntimeException('ساخت پوشه ممکن نشد: ' . $dir);
        }

        self::protect($dir);
    }

    /**
     * اعمال محافظت دسترسی وب روی پوشه.
     *
     * @param string $dir مسیر پوشه
     *
     * @return void
     */
    public static function protect(string $dir): void
    {
        if (!is_dir($dir) || !is_writable($dir)) {
            return;
        }

        $guards = [
            '.htaccess' => "Require all denied\n<IfModule !mod_authz_core.c>\n    Order allow,deny\n    Deny from all\n</IfModule>\n",
            'index.html' => '',
        ];

        foreach ($guards as $name => $content) {
            $file = $dir . '/' . $name;

            if (!file_exists($file)) {
                @file_put_contents($file, $content);
            }
        }
    }

    /**
     * بررسی قرار گرفتن یک مسیر داخل یک ریشه.
     *
     * @param string $path مسیر مورد بررسی
     * @param string $root مسیر ریشه
     *
     * @return bool
     */
    public static function isInside(string $path, string $root): bool
    {
        $realPath = realpath($path);

        if ($realPath === false) {
            return false;
        }

        $realRoot = realpath($root);

        if ($realRoot === false) {
            return false;
        }

        $normalizedPath = str_replace('\\', '/', $realPath);
        $normalizedRoot = rtrim(str_replace('\\', '/', $realRoot), '/') . '/';

        return str_starts_with($normalizedPath, $normalizedRoot);
    }
}
