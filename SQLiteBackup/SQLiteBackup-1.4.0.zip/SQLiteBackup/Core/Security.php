<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Core;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class Security
{
    /**
     * الگوی مجاز نام فایل پشتیبان.
     */
    /**
     * الگوی نام فایل پشتیبان.
     *
     * حروف یونیکد (فارسی/لاتین)، ارقام، نقطه، خط تیره و زیرخط مجازند؛
     * نام‌های فارسی مثل «عنوان-سایت_2026-09-27_1630-ab12cd.zip» نیز
     * پذیرفته می‌شوند. امنیت مسیر با realpath و بررسی محدوده در
     * backupPath تضمین می‌شود.
     */
    private const BACKUP_NAME_PATTERN = '/^[\p{L}\p{Nd}][\p{L}\p{Nd}._-]{0,180}\.zip$/u';

    /**
     * سازنده خصوصی.
     */
    private function __construct()
    {
    }

    /**
     * بررسی دسترسی مدیر سیستم؛ در صورت عدم دسترسی درخواست متوقف می‌شود.
     *
     * @return void
     *
     * @throws \RuntimeException در صورت عدم دسترسی
     */
    public static function assertAdmin(): void
    {
        $user = \Widget\User::alloc();

        if (!$user->hasLogin() || !$user->pass('administrator', true)) {
            \TypechoPlugin\SQLiteBackup\Core\Logger::warning('تلاش برای دسترسی بدون سطح مدیر');
            throw new \RuntimeException('این عملیات فقط برای مدیرکل سایت مجاز است', 403);
        }
    }

    /**
     * اعتبارسنجی توکن CSRF درخواست.
     *
     * توکن باید با یکی از سه مسیر مرجع (نشانی درخواست، Referer یا نشانی
     * استاندارد اکشن) مطابقت داشته باشد.
     *
     * @return void
     *
     * @throws \RuntimeException در صورت نامعتبر بودن توکن
     */
    public static function assertCsrf(): void
    {
        $provided = (string) \Typecho\Request::getInstance()->get('_', '');

        if ($provided === '' || strlen($provided) > 128) {
            \TypechoPlugin\SQLiteBackup\Core\Logger::warning('درخواست بدون توکن CSRF');
            throw new \RuntimeException('درخواست فاقد توکن امنیتی معتبر است', 403);
        }

        $security = \Widget\Security::alloc();
        $request = \Typecho\Request::getInstance();

        $candidates = [
            $security->getToken((string) $request->getRequestUrl()),
            $security->getToken((string) $request->getReferer()),
            $security->getToken(self::canonicalActionUrl()),
        ];

        foreach ($candidates as $expected) {
            if (hash_equals($expected, $provided)) {
                return;
            }
        }

        \TypechoPlugin\SQLiteBackup\Core\Logger::warning('توکن CSRF نامعتبر', [
            'do'     => (string) \Typecho\Request::getInstance()->get('do', ''),
            'reason' => \Typecho\Request::getInstance()->getReferer() !== null
                ? 'عدم تطابق نشانی مبدا'
                : 'نبود هدر Referer',
        ]);
        throw new \RuntimeException('توکن امنیتی درخواست نامعتبر یا منقضی شده است', 403);
    }

    /**
     * نشانی استاندارد اکشن افزونه برای ساخت توکن.
     *
     * @return string
     */
    public static function canonicalActionUrl(): string
    {
        $options = \Utils\Helper::options();

        return \Typecho\Common::url('/action/sqlite-backup', (string) $options->index);
    }

    /**
     * ساخت نشانی امن (همراه توکن) برای یک عملیات.
     *
     * توکن به نشانی استانداردِ خودِ اکشن گره می‌خورد (نه نشانی صفحه‌ای که
     * در حال نمایش است) تا با تغییر نشانی مرورگر (مثل حذف پارامترهای
     * موقت br-flash توسط history.replaceState)، حذف Referer توسط مرورگر
     * یا رفت‌وآمد بین صفحات مدیریت، اعتبار خود را از دست ندهد.
     *
     * @param string $do نام عملیات
     *
     * @return string
     */
    public static function actionUrl(string $do = ''): string
    {
        $path = '/action/sqlite-backup';

        if ($do !== '') {
            $path .= '?do=' . rawurlencode($do);
        }

        $security = \Widget\Security::alloc();

        return \Typecho\Common::url(
            $security->getTokenUrl($path, self::canonicalActionUrl()),
            (string) \Utils\Helper::options()->index
        );
    }

    /**
     * اعتبارسنجی نام فایل پشتیبان.
     *
     * @param string $name نام فایل
     *
     * @return string نام امن
     *
     * @throws \RuntimeException در صورت نامعتبر بودن نام
     */
    public static function validateBackupName(string $name): string
    {
        $name = trim($name);

        if ($name === ''
            || str_contains($name, '/')
            || str_contains($name, '\\')
            || str_contains($name, "\0")
            || str_starts_with($name, '.')
            || !preg_match(self::BACKUP_NAME_PATTERN, $name)
        ) {
            \TypechoPlugin\SQLiteBackup\Core\Logger::warning('نام فایل پشتیبان نامعتبر رد شد', ['name' => $name]);
            throw new \RuntimeException('نام فایل پشتیبان نامعتبر است', 400);
        }

        return $name;
    }

    /**
     * مسیر امن یک فایل پشتیبان داخل پوشه پشتیبان‌ها.
     *
     * @param string $name نام فایل
     *
     * @return string مسیر مطلق
     *
     * @throws \RuntimeException در صورت خروج از محدوده مجاز
     */
    public static function backupPath(string $name): string
    {
        $name = self::validateBackupName($name);
        $path = Paths::backups() . '/' . $name;

        $real = realpath($path);

        if ($real === false || !is_file($real) || !Paths::isInside($real, Paths::backups())) {
            throw new \RuntimeException('فایل پشتیبان یافت نشد یا در محدوده مجاز نیست', 404);
        }

        return $real;
    }

    /**
     * اعتبارسنجی نام مدخل داخل آرشیو پشتیبان.
     *
     * فقط مدخل‌های مجاز (manifest.json، database.sqlite و مسیرهای
     * داخل uploads/) پذیرفته می‌شوند.
     *
     * @param string $entryName نام مدخل
     *
     * @return string نام امن
     *
     * @throws \RuntimeException در صورت نامعتبر بودن مدخل
     */
    public static function validateEntryName(string $entryName): string
    {
        $name = str_replace('\\', '/', $entryName);

        if ($name === ''
            || str_contains($name, "\0")
            || preg_match('#(^|/)\.\.(/|$)#', $name) === 1
            || str_starts_with($name, '/')
            || str_starts_with($name, '~')
            || preg_match('#^[A-Za-z]:#', $name) === 1
        ) {
            throw new \RuntimeException('نام مدخل آرشیو نامعتبر است: ' . $entryName, 400);
        }

        $allowed = false;

        if ($name === 'manifest.json' || $name === 'database.sqlite') {
            $allowed = true;
        } elseif (str_starts_with($name, 'uploads/') && strlen($name) > 8) {
            $allowed = true;
        }

        if (!$allowed) {
            throw new \RuntimeException('مدخل آرشیو در فهرست مجاز نیست: ' . $entryName, 400);
        }

        return $name;
    }

    /**
     * تبدیل مسیر مدخل آرشیو به مسیر مطلق امن روی دیسک.
     *
     * مدخل‌های «uploads/...» به «usr/uploads/...» نگاشت می‌شوند.
     *
     * @param string $entryName نام مدخل
     *
     * @return string مسیر مطلق
     *
     * @throws \RuntimeException در صورت خروج از محدوده
     */
    public static function entryTargetPath(string $entryName): string
    {
        $name = self::validateEntryName($entryName);

        if (!str_starts_with($name, 'uploads/')) {
            throw new \RuntimeException(
                'استخراج مستقیم این مدخل روی دیسک مجاز نیست (فقط محتویات uploads قابل استخراج است): ' . $entryName,
                400
            );
        }

        $target = Paths::root() . '/usr/' . $name;

        // اعتبارسنجی واژگانی مسیر (validateEntryName قبلاً از «..» و مسیرهای مطلق جلوگیری کرده است)
        $normalizedTarget = str_replace('\\', '/', $target);
        $allowedRoot = rtrim(str_replace('\\', '/', Paths::root()), '/') . '/usr/uploads/';

        if (!str_starts_with($normalizedTarget, $allowedRoot)) {
            throw new \RuntimeException('مسیر مقصد مدخل خارج از محدوده مجاز است', 400);
        }

        return $target;
    }

    /**
     * بررسی مالکیت یک نشست عملیات توسط کاربر جاری.
     *
     * @param array<string,mixed> $session داده نشست
     *
     * @return void
     *
     * @throws \RuntimeException در صورت عدم مالکیت
     */
    public static function assertSessionOwner(array $session): void
    {
        $user = \Widget\User::alloc();
        $sessionUid = (int) ($session['uid'] ?? 0);
        $currentUid = $user->hasLogin() ? (int) $user->uid : 0;

        if ($sessionUid !== $currentUid || $currentUid === 0) {
            \TypechoPlugin\SQLiteBackup\Core\Logger::warning('دسترسی غیرمجاز به نشست عملیات', [
                'sessionUid' => $sessionUid,
            ]);
            throw new \RuntimeException('نشست عملیات متعلق به کاربر جاری نیست', 403);
        }
    }

    /**
     * اعتبارسنجی شناسه نشست.
     *
     * @param string $sid شناسه
     *
     * @return string
     *
     * @throws \RuntimeException در صورت نامعتبر بودن
     */
    public static function validateSessionId(string $sid): string
    {
        if (!preg_match('/^[a-f0-9]{32}$/', $sid)) {
            throw new \RuntimeException('شناسه نشست نامعتبر است', 400);
        }

        return $sid;
    }
}
