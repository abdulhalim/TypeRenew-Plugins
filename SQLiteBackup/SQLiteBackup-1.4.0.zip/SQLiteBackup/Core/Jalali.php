<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Core;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * تبدیل تاریخ میلادی به شمسی (تقویم جلالی).
 *
 * الگوریتم بر پایه تبدیل‌کننده Roozbeh Pournader و Mohammad Toossi
 * که در کتابخانه‌های استاندارد تاریخ جلالی PHP استفاده می‌شود.
 */
final class Jalali
{
    /**
     * نام ماه‌های شمسی.
     *
     * @var array<int,string>
     */
    private const MONTHS = [
        1  => 'فروردین',
        2  => 'اردیبهشت',
        3  => 'خرداد',
        4  => 'تیر',
        5  => 'مرداد',
        6  => 'شهریور',
        7  => 'مهر',
        8  => 'آبان',
        9  => 'آذر',
        10 => 'دی',
        11 => 'بهمن',
        12 => 'اسفند',
    ];

    /**
     * سازنده خصوصی.
     */
    private function __construct()
    {
    }

    /**
     * تبدیل تاریخ میلادی به شمسی.
     *
     * @param int $year  سال میلادی
     * @param int $month ماه میلادی (۱ تا ۱۲)
     * @param int $day   روز میلادی (۱ تا ۳۱)
     *
     * @return array{0:int,1:int,2:int} [سال، ماه، روز] شمسی
     */
    public static function toJalali(int $year, int $month, int $day): array
    {
        $gDaysInMonth = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];

        $jy = ($year <= 1600) ? 0 : 979;
        $year -= ($year <= 1600) ? 621 : 1600;

        $year2 = ($month > 2) ? ($year + 1) : $year;
        $days = (365 * $year)
            + intdiv($year2 + 3, 4)
            - intdiv($year2 + 99, 100)
            + intdiv($year2 + 399, 400)
            - 80
            + $day
            + $gDaysInMonth[$month - 1];

        $jy += 33 * intdiv($days, 12053);
        $days %= 12053;
        $jy += 4 * intdiv($days, 1461);
        $days %= 1461;

        if ($days > 365) {
            $jy += intdiv($days - 1, 365);
            $days = ($days - 1) % 365;
        }

        $jm = ($days < 186) ? (1 + intdiv($days, 31)) : (7 + intdiv($days - 186, 30));
        $jd = 1 + (($days < 186) ? ($days % 31) : (($days - 186) % 30));

        return [$jy, $jm, $jd];
    }

    /**
     * نام ماه شمسی.
     *
     * @param int $month شماره ماه (۱ تا ۱۲)
     *
     * @return string
     */
    public static function monthName(int $month): string
    {
        return self::MONTHS[max(1, min(12, $month))] ?? '';
    }

    /**
     * قالب‌بندی تاریخ شمسی از زمان Unix.
     *
     * پشتیبانی از نویسه‌ها: Y (سال ۴ رقمی)، m (ماه ۲ رقمی)، d (روز ۲ رقمی)،
     * H (ساعت ۲ رقمی)، i (دقیقه ۲ رقمی)، s (ثانیه ۲ رقمی)، n (نام ماه).
     *
     * توجه: این متد تاریخ را در منطقه زمانی پیش‌فرض PHP تفسیر می‌کند؛
     * برای منطقه زمانی سایت از Core\Clock::jalali استفاده کنید.
     *
     * @param int    $timestamp زمان Unix
     * @param string $pattern   الگوی قالب‌بندی
     * @param bool   $persianDigits نمایش اعداد با ارقام فارسی
     *
     * @return string
     */
    public static function format(int $timestamp, string $pattern = 'Y/m/d H:i', bool $persianDigits = true): string
    {
        if ($timestamp <= 0) {
            return '-';
        }

        return self::formatFromParts(
            (int) date('Y', $timestamp),
            (int) date('n', $timestamp),
            (int) date('j', $timestamp),
            (int) date('G', $timestamp),
            (int) date('i', $timestamp),
            (int) date('s', $timestamp),
            $pattern,
            $persianDigits
        );
    }

    /**
     * قالب‌بندی تاریخ شمسی از اجزای تاریخ میلادی از پیش تفکیک‌شده.
     *
     * اجزا باید در منطقه زمانی مورد نظر (مثلاً تهران) محاسبه شده باشند.
     *
     * @param int    $year  سال میلادی
     * @param int    $month ماه میلادی (۱ تا ۱۲)
     * @param int    $day   روز میلادی (۱ تا ۳۱)
     * @param int    $hour  ساعت (۰ تا ۲۳)
     * @param int    $minute دقیقه (۰ تا ۵۹)
     * @param int    $second ثانیه (۰ تا ۵۹)
     * @param string $pattern الگوی قالب‌بندی
     * @param bool   $persianDigits نمایش اعداد با ارقام فارسی
     *
     * @return string
     */
    public static function formatFromParts(
        int $year,
        int $month,
        int $day,
        int $hour,
        int $minute,
        int $second,
        string $pattern = 'Y/m/d H:i',
        bool $persianDigits = true
    ): string {
        [$jy, $jm, $jd] = self::toJalali($year, $month, $day);

        $map = [
            'Y' => sprintf('%04d', $jy),
            'm' => sprintf('%02d', $jm),
            'd' => sprintf('%02d', $jd),
            'H' => sprintf('%02d', $hour),
            'i' => sprintf('%02d', $minute),
            's' => sprintf('%02d', $second),
            'n' => self::monthName($jm),
        ];

        $result = strtr($pattern, $map);

        return $persianDigits ? self::digits($result) : $result;
    }

    /**
     * تبدیل ارقام لاتین به فارسی.
     *
     * @param string $value متن ورودی
     *
     * @return string
     */
    public static function digits(string $value): string
    {
        return strtr($value, [
            '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
            '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
        ]);
    }
}
