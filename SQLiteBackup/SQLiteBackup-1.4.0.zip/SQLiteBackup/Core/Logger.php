<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Core;

use TypechoPlugin\SQLiteBackup\Core\Clock;
use TypechoPlugin\SQLiteBackup\Text;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class Logger
{
    /**
     * سطح اطلاعات.
     */
    public const INFO = 'info';

    /**
     * سطح موفقیت.
     */
    public const SUCCESS = 'success';

    /**
     * سطح هشدار.
     */
    public const WARNING = 'warning';

    /**
     * سطح خطا.
     */
    public const ERROR = 'error';

    /**
     * بیشترین اندازه فایل گزارش پیش از چرخش (بایت).
     */
    private const MAX_SIZE = 2097152;

    /**
     * تعداد فایل‌های چرخش‌شده نگهداری‌شده.
     */
    private const MAX_ROTATED = 2;

    /**
     * برچسب فارسی سطوح گزارش.
     *
     * @var array<string,string>
     */
    private const LEVEL_LABELS = [
        self::INFO    => 'اطلاعات',
        self::SUCCESS => 'موفق',
        self::WARNING => 'هشدار',
        self::ERROR   => 'خطا',
    ];

    /**
     * معادل فارسی کلیدهای زمینه گزارش.
     *
     * @var array<string,string>
     */
    private const CONTEXT_LABELS = [
        'version'  => 'نسخه',
        'type'     => 'نوع',
        'file'     => 'فایل',
        'name'     => 'نام',
        'size'     => 'حجم',
        'files'    => 'تعداد فایل',
        'bytes'    => 'حجم',
        'duration' => 'مدت',
        'error'    => 'خطا',
        'at'       => 'موقعیت',
        'do'       => 'عملیات',
        'entries'  => 'تعداد موارد',
        'retained' => 'نگهداشت',
        'note'     => 'یادداشت',
        'sid'      => 'شناسه',
        'reason'   => 'دلیل',
        'timezone' => 'منطقه زمانی',
        'prefix'   => 'پیشوند',
        'user'     => 'کاربر',
        'method'   => 'روش',
    ];

    /**
     * ثبت یک رویداد در گزارش.
     *
     * @param string              $level   سطح رویداد
     * @param string              $message پیام
     * @param array<string,mixed> $context زمینه رویداد
     *
     * @return void
     */
    public static function log(string $level, string $message, array $context = []): void
    {
        $allowed = [self::INFO, self::SUCCESS, self::WARNING, self::ERROR];

        if (!in_array($level, $allowed, true)) {
            $level = self::INFO;
        }

        $file = Paths::logFile();

        if (!is_dir(dirname($file))) {
            try {
                Paths::ensureDirectory(dirname($file));
            } catch (\RuntimeException) {
                return;
            }
        }

        self::rotateIfNeeded($file);

        $line = sprintf(
            "[%s] [%s] [کاربر: %s] [IP: %s] %s%s\n",
            Clock::jalali(Clock::now(), 'Y/m/d H:i'),
            self::LEVEL_LABELS[$level],
            self::currentUserName(),
            self::currentIp(),
            $message,
            $context === [] ? '' : ' — ' . self::encodeContext($context)
        );

        @file_put_contents($file, $line, FILE_APPEND | LOCK_EX);
    }

    /**
     * ثبت رویداد در سطح اطلاعات.
     *
     * @param string              $message پیام
     * @param array<string,mixed> $context زمینه
     *
     * @return void
     */
    public static function info(string $message, array $context = []): void
    {
        self::log(self::INFO, $message, $context);
    }

    /**
     * ثبت رویداد موفقیت.
     *
     * @param string              $message پیام
     * @param array<string,mixed> $context زمینه
     *
     * @return void
     */
    public static function success(string $message, array $context = []): void
    {
        self::log(self::SUCCESS, $message, $context);
    }

    /**
     * ثبت رویداد هشدار.
     *
     * @param string              $message پیام
     * @param array<string,mixed> $context زمینه
     *
     * @return void
     */
    public static function warning(string $message, array $context = []): void
    {
        self::log(self::WARNING, $message, $context);
    }

    /**
     * ثبت رویداد خطا.
     *
     * @param string              $message پیام
     * @param array<string,mixed> $context زمینه
     *
     * @return void
     */
    public static function error(string $message, array $context = []): void
    {
        self::log(self::ERROR, $message, $context);
    }

    /**
     * خواندن انتهای گزارش.
     *
     * @param int $lines تعداد خطوط
     *
     * @return array<int,string>
     */
    public static function tail(int $lines = 200): array
    {
        $file = Paths::logFile();

        if (!is_file($file)) {
            return [];
        }

        $content = @file_get_contents($file);

        if ($content === false || $content === '') {
            return [];
        }

        $all = preg_split('/\r\n|\r|\n/', rtrim($content));

        if ($all === false) {
            return [];
        }

        return array_values(array_slice($all, -$lines));
    }

    /**
     * پاک کردن کامل گزارش‌ها.
     *
     * @return void
     */
    public static function clear(): void
    {
        $file = Paths::logFile();

        if (is_file($file)) {
            @unlink($file);
        }

        $rotated = glob(dirname($file) . '/*.log.*') ?: [];

        foreach ($rotated as $old) {
            @unlink($old);
        }
    }

    /**
     * چرخش فایل گزارش در صورت عبور از حد اندازه.
     *
     * @param string $file مسیر فایل
     *
     * @return void
     */
    private static function rotateIfNeeded(string $file): void
    {
        clearstatcache(true, $file);

        if (!is_file($file) || (int) filesize($file) < self::MAX_SIZE) {
            return;
        }

        for ($i = self::MAX_ROTATED; $i >= 1; $i--) {
            $source = $file . '.' . $i;
            $target = $file . '.' . ($i + 1);

            if (is_file($source)) {
                if ($i === self::MAX_ROTATED) {
                    @unlink($source);
                } else {
                    @rename($source, $target);
                }
            }
        }

        @rename($file, $file . '.1');
    }

    /**
     * کدگذاری زمینه رویداد به شکل خوانای فارسی.
     *
     * @param array<string,mixed> $context زمینه
     *
     * @return string
     */
    private static function encodeContext(array $context): string
    {
        $parts = [];

        foreach ($context as $key => $value) {
            if ($value === null || $value === '') {
                continue;
            }

            $label = self::CONTEXT_LABELS[$key] ?? $key;

            if (is_bool($value)) {
                $value = $value ? 'بله' : 'خیر';
            } elseif (is_array($value)) {
                $value = json_encode(
                    $value,
                    JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR
                ) ?: '';
            } elseif (in_array($key, ['size', 'bytes'], true) && is_numeric($value) && (int) $value > 1023) {
                $value = Text::size((int) $value);
            } elseif (in_array($key, ['files', 'entries'], true) && is_numeric($value)) {
                $value = Text::int((int) $value);
            } elseif ($key === 'duration' && is_numeric($value) && (int) $value > 0) {
                $value = Text::duration((int) $value);
            } else {
                $value = (string) $value;
            }

            if ($value === '') {
                continue;
            }

            $parts[] = $label . ': ' . $value;
        }

        return implode('؛ ', $parts);
    }

    /**
     * نام کاربر جاری (در صورت وجود).
     *
     * @return string
     */
    private static function currentUserName(): string
    {
        try {
            $user = \Widget\User::alloc();

            if ($user->hasLogin()) {
                return (string) $user->screenName;
            }
        } catch (\Throwable) {
            // در محیط خط فرمان کاربر وجود ندارد
        }

        return 'system';
    }

    /**
     * نشانی IP کاربر جاری.
     *
     * @return string
     */
    private static function currentIp(): string
    {
        try {
            $request = \Typecho\Request::getInstance();

            return (string) $request->getIp();
        } catch (\Throwable) {
            return 'cli';
        }
    }
}
