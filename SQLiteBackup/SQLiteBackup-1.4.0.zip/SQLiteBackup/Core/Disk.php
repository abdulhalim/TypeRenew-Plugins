<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Core;

use TypechoPlugin\SQLiteBackup\Text;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * بررسی فضای ذخیره‌سازی سرور.
 *
 * روی هاست‌های اشتراکی معمولاً نمی‌دانیم چه مقدار فضا در اختیار داریم؛
 * این کلاس پیش و در میانهٔ عملیات‌های سنگین (ساخت پشتیبان، بکاپ کامل و
 * بارگذاری فایل) فضای آزاد را می‌سنجد و در صورت ناکافی بودن، خطایی با
 * پیام مشخص و ارقام خوانا تولید می‌کند تا کاربر بداند چه اتفاقی افتاده
 * و چه کاری باید بکند.
 */
final class Disk
{
    /**
     * حاشیهٔ اطمینان اضافه روی تخمین نیاز (بایت).
     *
     * فایل ZIP فشرده می‌شود و معمولاً از مجموع داده‌ها کوچک‌تر است؛
     * این حاشیه جبران سرصفحه‌ها، اسنپ‌شات موقت دیتابیس و نوسان
     * فضای اشتراکی سایر فرایندها است.
     */
    private const SAFETY_MARGIN = 8388608; // 8 مگابایت

    /**
     * سازنده خصوصی.
     */
    private function __construct()
    {
    }

    /**
     * فضای آزاد دیسک (بایت) یا null در صورت عدم دسترسی.
     *
     * @param string|null $dir مسیر مورد سنجش (پیش‌فرض: پوشه پشتیبان‌ها)
     *
     * @return int|null
     */
    public static function free(?string $dir = null): ?int
    {
        if (!function_exists('disk_free_space')) {
            return null;
        }

        $dir = $dir ?? Paths::backups();
        $free = @disk_free_space($dir);

        return is_float($free) && $free >= 0 ? (int) $free : null;
    }

    /**
     * کل ظرفیت دیسک (بایت) یا null.
     *
     * @param string|null $dir مسیر مورد سنجش
     *
     * @return int|null
     */
    public static function total(?string $dir = null): ?int
    {
        if (!function_exists('disk_total_space')) {
            return null;
        }

        $dir = $dir ?? Paths::backups();
        $total = @disk_total_space($dir);

        return is_float($total) && $total >= 0 ? (int) $total : null;
    }

    /**
     * بررسی کفایت فضا؛ در صورت ناکافی بودن، خطای مشخص پرتاب می‌شود.
     *
     * @param int         $neededBytes   فضای مورد نیاز تخمینی (بایت)
     * @param string|null $actionLabel   برچسب عملیات برای پیام خطا
     *
     * @return void
     *
     * @throws \RuntimeException با پیام فارسی مشخص
     */
    public static function assertEnough(int $neededBytes, ?string $actionLabel = null): void
    {
        $free = self::free();

        if ($free === null) {
            // سنجش ممکن نیست (مثلاً تابع غیرفعال است)؛ ادامه می‌دهیم و
            // به خطاهای زمان اجرا تکیه می‌کنیم.
            return;
        }

        $needed = $neededBytes + self::SAFETY_MARGIN;

        if ($free >= $needed) {
            return;
        }

        throw new \RuntimeException(self::message($free, $needed, $actionLabel));
    }

    /**
     * آیا پیام خطا به کمبود فضای دیسک اشاره دارد؟
     *
     * برای تشخیص خطاهای زمان اجرا (مثل fwrite ناموفق) به کار می‌رود تا
     * پیام عمومی، با پیام مشخص کمبود فضا جایگزین شود.
     *
     * @param string      $errorMessage پیام خطای خام
     * @param string|null $actionLabel  برچسب عملیات
     *
     * @return string|null پیام مشخص در صورت احتمال پر بودن دیسک
     */
    public static function insufficientMessage(string $errorMessage, ?string $actionLabel = null): ?string
    {
        $free = self::free();

        if ($free !== null && $free < self::SAFETY_MARGIN) {
            return self::message($free, self::SAFETY_MARGIN, $actionLabel);
        }

        if (stripos($errorMessage, 'space') !== false
            || stripos($errorMessage, 'quota') !== false
            || stripos($errorMessage, 'نوشتن') !== false
            || stripos($errorMessage, 'ذخیره') !== false
        ) {
            return self::message($free ?? 0, self::SAFETY_MARGIN, $actionLabel);
        }

        return null;
    }

    /**
     * ساخت پیام مشخص کمبود فضا.
     *
     * @param int|null    $freeBytes    فضای آزاد فعلی
     * @param int         $neededBytes  فضای مورد نیاز
     * @param string|null $actionLabel  برچسب عملیات
     *
     * @return string
     */
    private static function message(?int $freeBytes, int $neededBytes, ?string $actionLabel): string
    {
        $context = $actionLabel !== null && $actionLabel !== ''
            ? 'برای «' . $actionLabel . '» '
            : '';

        $parts = [
            'فضای ذخیره‌سازی سرور کافی نیست. ' . $context . 'فضای آزاد فعلی: '
            . ($freeBytes !== null ? Text::size($freeBytes) : 'نامشخص')
            . ' — فضای مورد نیاز تقریبی: ' . Text::size(max(0, $neededBytes)) . '.',
            'چند فایل پشتیبان قدیمی را از فهرست حذف کنید، فایل‌های بلااستفادهٔ پوشه بارگذاری‌ها را پاک کنید یا با پشتیبانی هاست خود (افزایش فضای اشتراک) تماس بگیرید.',
        ];

        return implode(' ', $parts);
    }
}
