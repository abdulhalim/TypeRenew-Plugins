<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Core;

use Typecho\Date;
use Utils\Zone;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * مدیریت زمان در منطقه زمانی سایت.
 *
 * منطقه زمانی از تنظیمات عمومی TypeRenew خوانده می‌شود (timezoneId/
 * timezone که هسته در هر درخواست از طریق Date::configure تنظیم می‌کند)
 * و اگر تعیین نشده باشد به‌طور پیش‌فرض Asia/Tehran اعمال می‌شود.
 */
final class Clock
{
    /**
     * منطقه زمانی پیش‌فرض هنگام نبود تنظیم سایت.
     */
    public const DEFAULT_TIMEZONE = 'Asia/Tehran';

    /**
     * سازنده خصوصی.
     */
    private function __construct()
    {
    }

    /**
     * زمان فعلی Unix.
     *
     * @return int
     */
    public static function now(): int
    {
        return Date::time();
    }

    /**
     * شناسه منطقه زمانی مؤثر افزونه.
     *
     * @return string
     */
    public static function timezoneId(): string
    {
        $id = Date::$timezoneId;

        if (is_string($id) && $id !== '' && Zone::normalizeId($id) !== null) {
            return $id;
        }

        return self::DEFAULT_TIMEZONE;
    }

    /**
     * برچسب خوانای منطقه زمانی برای نمایش در پنل.
     *
     * @return string
     */
    public static function timezoneLabel(): string
    {
        return self::timezoneId() . ' (UTC' . self::offsetLabel() . ')';
    }

    /**
     * اختلاف ساعت مؤثر نسبت به UTC به شکل +03:30.
     *
     * @return string
     */
    public static function offsetLabel(): string
    {
        $offset = self::offsetAt(self::now());
        $sign = $offset < 0 ? '-' : '+';
        $abs = abs($offset);
        $hours = intdiv($abs, 3600);
        $minutes = intdiv($abs % 3600, 60);

        return sprintf('%s%02d:%02d', $sign, $hours, $minutes);
    }

    /**
     * تاریخ‌ساز در منطقه زمانی سایت.
     *
     * @param int|null $timestamp زمان Unix (پیش‌فرض: اکنون)
     *
     * @return \DateTimeImmutable
     */
    public static function dateTime(?int $timestamp = null): \DateTimeImmutable
    {
        $timestamp = $timestamp ?? self::now();

        try {
            $zone = new \DateTimeZone(self::timezoneId());

            return (new \DateTimeImmutable('@' . $timestamp))->setTimezone($zone);
        } catch (\Throwable) {
            // بازگشت به روش هسته (شناسه + اختلاف ذخیره‌شده)
            return Zone::dateTime($timestamp, Date::$timezoneId, Date::$timezoneOffset);
        }
    }

    /**
     * قالب‌بندی تاریخ شمسی از زمان Unix در منطقه زمانی سایت.
     *
     * @param int    $timestamp     زمان Unix
     * @param string $pattern       الگوی قالب‌بندی (پشتیبانی Jalali::format)
     * @param bool   $persianDigits نمایش اعداد با ارقام فارسی
     *
     * @return string
     */
    public static function jalali(int $timestamp, string $pattern = 'Y/m/d H:i', bool $persianDigits = true): string
    {
        if ($timestamp <= 0) {
            return '-';
        }

        $dt = self::dateTime($timestamp);

        return Jalali::formatFromParts(
            (int) $dt->format('Y'),
            (int) $dt->format('n'),
            (int) $dt->format('j'),
            (int) $dt->format('G'),
            (int) $dt->format('i'),
            (int) $dt->format('s'),
            $pattern,
            $persianDigits
        );
    }

    /**
     * مُهر زمانی شمسی با ارقام لاتین، مناسب نام فایل.
     *
     * نمونه خروجی: 1404-07-05-1530
     *
     * @param int|null $timestamp زمان Unix (پیش‌فرض: اکنون)
     *
     * @return string
     */
    public static function jalaliStamp(?int $timestamp = null): string
    {
        $timestamp = $timestamp ?? self::now();

        return self::jalali($timestamp, 'Y-m-d-His', false);
    }

    /**
     * مُهر زمانی میلادی با ارقام لاتین در منطقه زمانی سایت، مناسب نام فایل.
     *
     * نمونه خروجی: 2026-09-27_1630
     *
     * @param int|null $timestamp زمان Unix (پیش‌فرض: اکنون)
     *
     * @return string
     */
    public static function gregorianStamp(?int $timestamp = null): string
    {
        return self::dateTime($timestamp ?? self::now())->format('Y-m-d_Hi');
    }

    /**
     * زمان ISO 8601 در منطقه زمانی سایت.
     *
     * @param int|null $timestamp زمان Unix (پیش‌فرض: اکنون)
     *
     * @return string
     */
    public static function iso(?int $timestamp = null): string
    {
        return self::dateTime($timestamp)->format('c');
    }

    /**
     * اختلاف منطقه زمانی مؤثر نسبت به UTC در یک لحظه (ثانیه).
     *
     * @param int $timestamp زمان Unix
     *
     * @return int
     */
    private static function offsetAt(int $timestamp): int
    {
        try {
            return (int) (new \DateTimeZone(self::timezoneId()))->getOffset(
                new \DateTimeImmutable('@' . $timestamp)
            );
        } catch (\Throwable) {
            return Date::$timezoneOffset;
        }
    }
}
