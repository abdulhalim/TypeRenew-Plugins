<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup\Core;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class PluginInfo
{
    /**
     * نام افزونه.
     */
    public const NAME = 'SQLiteBackup';

    /**
     * نسخه افزونه.
     */
    public const VERSION = '1.4.0';

    /**
     * نام نمایشی افزونه.
     */
    public const TITLE = 'تهیه پشتیبان';

    /**
     * سازنده خصوصی.
     */
    private function __construct()
    {
    }
}
