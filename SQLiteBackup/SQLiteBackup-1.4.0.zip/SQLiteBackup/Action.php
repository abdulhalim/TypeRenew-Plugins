<?php
declare(strict_types=1);

namespace TypechoPlugin\SQLiteBackup;

use TypechoPlugin\SQLiteBackup\Core\Logger;
use TypechoPlugin\SQLiteBackup\Core\Security;
use TypechoPlugin\SQLiteBackup\Repository\BackupRepository;
use TypechoPlugin\SQLiteBackup\Repository\DeleteQueue;
use TypechoPlugin\SQLiteBackup\Repository\NoteRepository;
use TypechoPlugin\SQLiteBackup\Repository\SessionStore;
use TypechoPlugin\SQLiteBackup\Service\BackupService;
use TypechoPlugin\SQLiteBackup\Service\DatabaseService;
use TypechoPlugin\SQLiteBackup\Service\FullBackupService;
use TypechoPlugin\SQLiteBackup\Service\RestoreService;
use TypechoPlugin\SQLiteBackup\Service\UploadService;
use Widget\User;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * اکشن پردازش درخواست‌های AJAX افزونه.
 *
 * همه نقاط پایانی فقط با سطح دسترسی مدیرکل و توکن CSRF معتبر
 * پاسخ می‌دهند و خروجی به صورت JSON است (به‌جز دانلود فایل).
 *
 * @package SQLiteBackup
 * @author  TypeRenew SQLiteBackup
 * @license GPL-2.0
 */
class Action extends \Typecho\Widget
{
    /**
     * عملیات‌هایی که فقط با POST مجاز هستند.
     *
     * @var array<int,string>
     */
    private const POST_ONLY = [
        'backup.init', 'backup.step', 'backup.finalize', 'backup.cancel',
        'restore.init', 'restore.step', 'restore.db', 'restore.finish', 'restore.cancel',
        'settings.save', 'note.save', 'log.clear',
        'backup.delete', 'backup.deleteBatch', 'backup.upload',
    ];

    /**
     * اجرای اکشن اصلی.
     *
     * @return void
     */
    public function action(): void
    {
        // این متد خروجی ندارد؛ پاسخ‌ها از طریق jsonSuccess/jsonError/throwFile ارسال می‌شوند
        $this->run();
    }

    /**
     * اجرای زنجیره پردازش درخواست.
     *
     * @return void
     */
    private function run(): void
    {
        SessionStore::gc();
        DeleteQueue::gc();

        $do = trim((string) $this->request->get('do', ''));

        if ($do === '') {
            $this->jsonError('عملیات مشخص نشده است', 400);
            return;
        }

        try {
            Security::assertAdmin();
        } catch (\RuntimeException $e) {
            $this->jsonError($e->getMessage(), (int) $e->getCode() ?: 403);
            return;
        }

        if (in_array($do, self::POST_ONLY, true) && !$this->request->isPost()) {
            $this->jsonError('این عملیات باید با درخواست POST ارسال شود', 405);
            return;
        }

        try {
            Security::assertCsrf();
        } catch (\RuntimeException $e) {
            $this->jsonError($e->getMessage(), (int) $e->getCode() ?: 403);
            return;
        }

        // دانلود فایل مسیر انتقال خودش را دارد و در محیط واقعی با exit پایان می‌یابد
        if ($do === 'backup.download') {
            $this->handleDownload();
            return;
        }

        try {
            $payload = $this->dispatch($do);
        } catch (\RuntimeException $e) {
            $this->jsonError($e->getMessage(), (int) ($e->getCode() > 0 ? $e->getCode() : 500));
            return;
        } catch (\Throwable $e) {
            Logger::error('خطای غیرمنتظره در پردازش درخواست', [
                'do'    => $do,
                'error' => $e->getMessage(),
                'at'    => basename($e->getFile()) . ':' . $e->getLine(),
            ]);
            $this->jsonError('خطای غیرمنتظره رخ داد؛ جزئیات در گزارش ثبت شد', 500);
            return;
        }

        $this->jsonSuccess($payload);
    }

    /**
     * هدایت درخواست به عملیات مربوط.
     *
     * @param string $do نام عملیات
     *
     * @return array<string,mixed> داده پاسخ
     *
     * @throws \RuntimeException در صورت نامشخص بودن عملیات
     */
    private function dispatch(string $do): array
    {
        return match ($do) {
            'status' => $this->handleStatus(),
            'backup.init' => $this->handleBackupInit(),
            'backup.step' => $this->handleBackupStep(),
            'backup.finalize' => $this->handleBackupFinalize(),
            'backup.cancel' => $this->handleBackupCancel(),
            'backup.delete' => $this->handleBackupDelete(),
            'backup.deleteBatch' => $this->handleBackupBulkDelete(),
            'backup.upload' => $this->handleBackupUpload(),
            'note.save' => $this->handleNoteSave(),
            'restore.check' => $this->handleRestoreCheck(),
            'restore.init' => $this->handleRestoreInit(),
            'restore.step' => $this->handleRestoreStep(),
            'restore.db' => $this->handleRestoreDatabase(),
            'restore.finish' => $this->handleRestoreFinish(),
            'restore.cancel' => $this->handleRestoreCancel(),
            'settings.save' => $this->handleSettingsSave(),
            'log.tail' => $this->handleLogTail(),
            'log.clear' => $this->handleLogClear(),
            default => throw new \RuntimeException('عملیات ناشناخته: ' . $do, 400),
        };
    }

    /**
     * وضعیت کلی محیط و پشتیبان‌ها.
     *
     * @return array<string,mixed>
     */
    private function handleStatus(): array
    {
        $database = DatabaseService::info();
        $uploads = \TypechoPlugin\SQLiteBackup\Manager\FileManager::usage(
            \TypechoPlugin\SQLiteBackup\Core\Paths::uploads()
        );
        $stats = BackupRepository::stats();
        $backupsDir = \TypechoPlugin\SQLiteBackup\Core\Paths::backups();

        return [
            'database'  => [
                'adapter'  => $database['adapter'],
                'isSqlite' => $database['isSqlite'],
                'size'     => $database['size'],
                'engine'   => $database['engine'],
                'prefix'   => DatabaseService::currentPrefix(),
            ],
            'uploads'   => $uploads,
            'backups'   => $stats,
            'diskFree'  => function_exists('disk_free_space')  ? (int) @disk_free_space($backupsDir)  : 0,
            'diskTotal' => function_exists('disk_total_space') ? (int) @disk_total_space($backupsDir) : 0,
            'platform'  => [
                'name'    => \Typecho\Common::SOFTWARE,
                'version' => \Typecho\Common::VERSION,
            ],
            'plugin'    => ['version' => Plugin::VERSION],
            'php'       => PHP_VERSION,
            'timezone'  => [
                'id'    => \TypechoPlugin\SQLiteBackup\Core\Clock::timezoneId(),
                'label' => \TypechoPlugin\SQLiteBackup\Core\Clock::timezoneLabel(),
            ],
            'upload'    => [
                'maxBytes' => UploadService::maxUploadBytes(),
                'maxLabel' => UploadService::maxUploadBytes() !== null
                    ? \TypechoPlugin\SQLiteBackup\Text::size((int) UploadService::maxUploadBytes())
                    : 'نامحدود',
            ],
        ];
    }

    /**
     * آغاز ساخت پشتیبان.
     *
     * @return array<string,mixed>
     */
    private function handleBackupInit(): array
    {
        $this->assertEnabled();
        $type = (string) $this->request->get('type', 'backup');

        if (!in_array($type, ['backup', 'emergency', 'full'], true)) {
            throw new \RuntimeException('نوع پشتیبان نامعتبر است', 400);
        }

        $uid = (int) User::alloc()->uid;
        $note = (string) $this->request->get('note', '');

        if ($type === 'full') {
            $result = FullBackupService::init($uid, $note);

            return [
                'sid'        => $result['sid'],
                'type'       => 'full',
                'totalFiles' => $result['totalFiles'],
                'totalBytes' => $result['totalBytes'],
            ];
        }

        $result = BackupService::init($type, $uid, $note);

        return [
            'sid'        => $result['sid'],
            'type'       => $type,
            'totalFiles' => $result['totalFiles'],
            'totalBytes' => $result['totalBytes'],
        ];
    }

    /**
     * گام ساخت پشتیبان.
     *
     * @return array<string,mixed>
     */
    private function handleBackupStep(): array
    {
        $sid = Security::validateSessionId((string) $this->request->get('sid', ''));
        $session = SessionStore::load($sid);

        if ($session !== null && ($session['type'] ?? '') === 'full') {
            return FullBackupService::step($sid);
        }

        return BackupService::step($sid);
    }

    /**
     * نهایی‌سازی ساخت پشتیبان.
     *
     * @return array<string,mixed>
     */
    private function handleBackupFinalize(): array
    {
        $sid = Security::validateSessionId((string) $this->request->get('sid', ''));
        $session = SessionStore::load($sid);

        if ($session !== null && ($session['type'] ?? '') === 'full') {
            $summary = FullBackupService::finalize($sid);
        } else {
            $summary = BackupService::finalize($sid);
        }

        return [
            'backup' => [
                'name'     => $summary['name'],
                'type'     => $summary['type'],
                'size'     => $summary['size'],
                'files'    => $summary['files'],
                'bytes'    => $summary['bytes'],
                'duration' => $summary['duration'],
                'note'     => $summary['note'],
            ],
        ];
    }

    /**
     * لغو ساخت پشتیبان.
     *
     * @return array<string,mixed>
     */
    private function handleBackupCancel(): array
    {
        $sid = Security::validateSessionId((string) $this->request->get('sid', ''));
        $session = SessionStore::load($sid);

        if ($session !== null && ($session['type'] ?? '') === 'full') {
            FullBackupService::cancel($sid);
        } else {
            BackupService::cancel($sid);
        }

        return ['cancelled' => true];
    }

    /**
     * دانلود فایل پشتیبان.
     *
     * بکاپ‌های کامل (یا درخواست‌های همراه پارامتر once) پس از دانلود در صف
     * زمان‌بندی حذف قرار می‌گیرند و حداقل ۲۴ ساعت روی سرور باقی می‌مانند تا
     * در صورت بروز خطا در دریافت، امکان دانلود مجدد فراهم باشد. پاک‌سازی
     * خودکار هنگام فراخوانی‌های بعدی اکشن یا بارگذاری پنل انجام می‌شود.
     *
     * این روش جایگزین register_shutdown_function نسخهٔ پیشین شده تا از حذف
     * زودرس فایل روی هاست‌های اشتراکی (که گاهی تابع shutdown پیش از اتمام
     * کامل ارسال فایل اجرا می‌شود) جلوگیری شود.
     *
     * @return void
     */
    private function handleDownload(): void
    {
        $name = (string) $this->request->get('file', '');

        try {
            $path = Security::backupPath($name);
        } catch (\RuntimeException $e) {
            $this->jsonError($e->getMessage(), (int) ($e->getCode() > 0 ? $e->getCode() : 400));
            return;
        }

        $deleteAfter = BackupRepository::typeOf(basename($path)) === 'full'
            || $this->request->get('once') === '1';

        if ($deleteAfter) {
            $finalName = basename($path);

            // به‌جای حذف آنی با register_shutdown_function (که روی هاست‌های اشتراکی
            // گاهی پیش از اتمام دانلود اجرا می‌شود و فایل را زود حذف می‌کند)،
            // فایل در صف زمان‌بندی حذف قرار می‌گیرد تا حداقل ۲۴ ساعت روی سرور
            // باقی بماند. پاک‌سازی خودکار هنگام فراخوانی‌های بعدی اکشن یا پنل
            // انجام می‌شود.
            DeleteQueue::schedule($finalName);

            // پیغام یک‌باره برای نمایش در بارگذاری بعدی پنل
            $notice = 'فایل «' . $finalName . '» با موفقیت دانلود شد. '
                . 'این فایل ۲۴ ساعت دیگر به‌طور خودکار از سرور حذف خواهد شد تا '
                . 'در صورت بروز مشکل در دریافت، امکان دانلود مجدد فراهم باشد. '
                . 'نسخه‌ای که روی سیستم خود ذخیره کرده‌اید را در جای امن نگه دارید.';
            @file_put_contents(
                \TypechoPlugin\SQLiteBackup\Core\Paths::backups() . '/.fullbackup-notice',
                $notice
            );

            Logger::warning('بکاپ کامل برای دانلود ارسال شد؛ ۲۴ ساعت دیگر به‌طور خودکار حذف می‌شود', [
                'file'     => $finalName,
                'deleteAt' => date('Y-m-d H:i:s', time() + DeleteQueue::RETENTION_SECONDS),
            ]);
        } else {
            Logger::info('فایل پشتیبان دانلود شد', ['file' => basename($path)]);
        }

        // استریم مستقیم فایل به‌جای throwFile() فریم‌ورک.
        // throwFile() از readfile() استفاده می‌کند که برای فایل‌های بزرگ
        // (بکاپ کامل) روی هاست‌های اشتراکی با output buffering تداخل دارد
        // و باعث دانلود ۰ بایتی می‌شود. استریم chunked با fopen/fread این
        // مشکل را حل می‌کند.
        $this->streamFile($path, $deleteAfter);
    }

    /**
     * استریم یک فایل به کلاینت در قطعات ۱ مگابایتی.
     *
     * این متد به‌جای Response::throwFile() فریم‌ورک استفاده می‌شود تا از
     * مشکلات readfile() با فایل‌های بزرگ جلوگیری شود. throwFile() کل فایل
     * را از طریق readfile() ارسال می‌کند که با output buffering هاست‌های
     * اشتراکی تداخل دارد و برای فایل‌های بزرگ (بکاپ کامل) باعث دانلود
     * ناقص یا ۰ بایتی می‌شود.
     *
     * این متد:
     *  - تمام output buffer ها را پاک می‌کند
     *  - محدودیت زمان اجرا را برمی‌دارد (set_time_limit(0))
     *  - هدرها را مستقیماً ارسال می‌کند (بدون واسطه فریم‌ورک)
     *  - فایل را در قطعات ۱ مگابایتی با fopen/fread می‌خواند
     *  - پس از هر قطعه flush می‌کند تا داده فوراً به مرورگر برسد
     *  - در صورت قطع اتصال کلاینت، ارسال را متوقف می‌کند
     *
     * @param string $path          مسیر مطلق فایل
     * @param bool   $deleteAfter   آیا فایل برای حذف زمان‌بندی شده است
     *
     * @return void
     */
    private function streamFile(string $path, bool $deleteAfter): void
    {
        if (!is_readable($path)) {
            $this->jsonError('فایل پشتیبان قابل خواندن نیست', 500);
            return;
        }

        $size = filesize($path);

        if ($size === false) {
            $this->jsonError('اندازه فایل پشتیبان قابل تشخیص نیست', 500);
            return;
        }

        // حذف محدودیت زمان اجرا برای دانلود فایل‌های بزرگ
        if (function_exists('set_time_limit')) {
            @set_time_limit(0);
        }

        // نادیده گرفتن قطع اتصال کاربر برای اطمینان از استریم کامل
        if (function_exists('ignore_user_abort')) {
            @ignore_user_abort(true);
        }

        // پاک کردن تمام output buffer ها تا با استریم فایل تداخل نداشته باشند.
        // هر محتوای بافر شده دانلود را خراب می‌کند یا از flush صحیح جلوگیری
        // می‌کند.
        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        $displayName = basename($path);
        $encodedName = rawurlencode($displayName);

        // ارسال مستقیم هدرها بدون واسطه فریم‌ورک.
        // Content-Type بدون charset برای دانلود باینری.
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $displayName . '"; filename*=UTF-8\'\'' . $encodedName);
        header('Content-Length: ' . $size);
        header('Content-Transfer-Encoding: binary');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');

        if ($deleteAfter) {
            header('X-Backup-Delete-After: 24h');
        }

        // خواندن فایل در قطعات ۱ مگابایتی برای جلوگیری از بارگذاری کل فایل
        // در حافظه.
        $handle = @fopen($path, 'rb');

        if ($handle === false) {
            // هدرها ارسال شده‌اند؛ نمی‌توانیم خطای JSON بفرستیم
            exit;
        }

        $chunkSize = 1024 * 1024; // ۱ مگابایت

        while (!feof($handle)) {
            $chunk = fread($handle, $chunkSize);

            if ($chunk === false || $chunk === '') {
                break;
            }

            echo $chunk;

            // flush خروجی به کلاینت پس از هر قطعه
            @flush();

            // توقف در صورت قطع اتصال کلاینت
            if (connection_aborted()) {
                break;
            }
        }

        fclose($handle);
        exit;
    }

    /**
     * بارگذاری فایل پشتیبان از پنل.
     *
     * @return array<string,mixed>
     *
     * @throws \RuntimeException در صورت خطای آپلود یا نامعتبر بودن فایل
     */
    private function handleBackupUpload(): array
    {
        $this->assertEnabled();

        if (!isset($_FILES[UploadService::FIELD_NAME]) || !is_array($_FILES[UploadService::FIELD_NAME])) {
            throw new \RuntimeException('فایلی برای بارگذاری ارسال نشده است', 400);
        }

        $summary = UploadService::receive($_FILES[UploadService::FIELD_NAME]);

        return [
            'uploaded' => $summary,
        ];
    }

    /**
     * ذخیره یادداشت یک نسخه پشتیبان.
     *
     * @return array<string,mixed>
     */
    private function handleNoteSave(): array
    {
        $name = (string) $this->request->get('file', '');
        $path = Security::backupPath($name);
        $note = (string) $this->request->get('note', '');

        $entry = NoteRepository::set(basename($path), $note, (int) User::alloc()->uid);

        return [
            'file'      => basename($path),
            'note'      => $entry['note'],
            'updatedAt' => $entry['updatedAt'],
        ];
    }

    /**
     * حذف فایل پشتیبان.
     *
     * @return array<string,mixed>
     */
    private function handleBackupDelete(): array
    {
        $name = (string) $this->request->get('file', '');
        BackupRepository::delete($name);
        return ['deleted' => $name];
    }

    /**
     * حذف دسته‌جمعی فایل‌های پشتیبان.
     *
     * فهرست نام فایل‌ها به شکل JSON در پارامتر «files» ارسال می‌شود؛
     * هر فایل مستقل حذف می‌شود و نتیجهٔ جزئی (حذف‌شده‌ها و خطاها)
     * برگردانده می‌شود تا یک خطای تکی، حذف بقیه را متوقف نکند.
     *
     * @return array<string,mixed>
     */
    private function handleBackupBulkDelete(): array
    {
        $raw = (string) $this->request->get('files', '');
        $names = json_decode($raw, true);

        if (!is_array($names) || $names === []) {
            throw new \RuntimeException('فهرست فایل‌ها برای حذف ارسال نشده است', 400);
        }

        if (count($names) > 100) {
            throw new \RuntimeException('در هر نوبت حداکثر ۱۰۰ فایل قابل حذف است', 400);
        }

        $deleted = [];
        $failed = [];

        foreach ($names as $name) {
            if (!is_string($name) || $name === '') {
                continue;
            }

            try {
                BackupRepository::delete($name);
                $deleted[] = $name;
            } catch (\Throwable $e) {
                $failed[] = ['file' => $name, 'error' => $e->getMessage()];
            }
        }

        if ($deleted !== []) {
            Logger::info('حذف دسته‌جمعی پشتیبان‌ها انجام شد', [
                'count'  => count($deleted),
                'failed' => count($failed),
            ]);
        }

        return [
            'deletedCount' => count($deleted),
            'failedCount'  => count($failed),
            'failed'       => $failed,
        ];
    }

    /**
     * بررسی صحت فایل پشتیبان پیش از بازیابی.
     *
     * @return array<string,mixed>
     */
    private function handleRestoreCheck(): array
    {
        $name = (string) $this->request->get('file', '');
        $result = RestoreService::check($name);
        $manifest = $result['manifest'];

        return [
            'ok'      => $result['ok'],
            'errors'  => $result['errors'],
            'details' => is_array($manifest) ? [
                'createdAt'     => (string) ($manifest['createdAt'] ?? ''),
                'type'          => (string) ($manifest['type'] ?? 'backup'),
                'pluginVersion' => (string) ($manifest['pluginVersion'] ?? ''),
                'platform'      => (string) ($manifest['platform'] ?? ''),
                'platformVersion' => (string) ($manifest['platformVersion'] ?? ''),
                'databaseType'  => (string) ($manifest['database']['type'] ?? ''),
                'databaseSize'  => (int) ($manifest['database']['size'] ?? 0),
                'uploadsFiles'  => (int) ($manifest['uploads']['files'] ?? 0),
                'uploadsBytes'  => (int) ($manifest['uploads']['bytes'] ?? 0),
                'totalFiles'    => (int) ($manifest['totalFiles'] ?? 0),
                'totalBytes'    => (int) ($manifest['totalBytes'] ?? 0),
                'backupSize'    => (int) ($manifest['backupSize'] ?? 0),
                'checksum'      => (string) ($manifest['checksum'] ?? ''),
                'formatVersion' => (int) ($manifest['formatVersion'] ?? 0),
            ] : null,
        ];
    }

    /**
     * آغاز بازیابی.
     *
     * @return array<string,mixed>
     */
    private function handleRestoreInit(): array
    {
        $this->assertEnabled();
        $name = (string) $this->request->get('file', '');
        $result = RestoreService::init($name, (int) User::alloc()->uid);

        return [
            'sid'        => $result['sid'],
            'totalFiles' => $result['totalFiles'],
            'totalBytes' => $result['totalBytes'],
        ];
    }

    /**
     * گام بازیابی فایل‌ها.
     *
     * @return array<string,mixed>
     */
    private function handleRestoreStep(): array
    {
        $sid = Security::validateSessionId((string) $this->request->get('sid', ''));
        return RestoreService::step($sid);
    }

    /**
     * جایگزینی دیتابیس در بازیابی.
     *
     * @return array<string,mixed>
     */
    private function handleRestoreDatabase(): array
    {
        $sid = Security::validateSessionId((string) $this->request->get('sid', ''));
        $result = RestoreService::applyDatabase($sid);

        return [
            'database'      => true,
            'prefixAdapted' => (bool) ($result['prefixAdapted'] ?? false),
            'keptUser'      => $result['keptUser'] ?? null,
            'reissuedLogin' => $result['reissuedLogin'] ?? null,
        ];
    }

    /**
     * نهایی‌سازی بازیابی.
     *
     * @return array<string,mixed>
     */
    private function handleRestoreFinish(): array
    {
        $sid = Security::validateSessionId((string) $this->request->get('sid', ''));
        $summary = RestoreService::finish($sid);

        return [
            'restored' => [
                'file'     => $summary['file'],
                'files'    => $summary['files'],
                'bytes'    => $summary['bytes'],
                'duration' => $summary['duration'],
            ],
            'cache'     => $summary['cache'],
            'reconcile' => $summary['reconcile'] ?? [],
        ];
    }

    /**
     * لغو بازیابی.
     *
     * @return array<string,mixed>
     */
    private function handleRestoreCancel(): array
    {
        $sid = Security::validateSessionId((string) $this->request->get('sid', ''));
        RestoreService::cancel($sid);
        return ['cancelled' => true];
    }

    /**
     * ذخیره تنظیمات از پنل.
     *
     * @return array<string,mixed>
     */
    private function handleSettingsSave(): array
    {
        $fields = [
            'enabled', 'retentionCount',
        ];

        $input = [];

        foreach ($fields as $field) {
            $raw = $this->request->get($field, null);

            if ($raw === null) {
                continue;
            }

            $input[$field] = is_scalar($raw) ? (string) $raw : '';
        }

        Settings::store($input);
        Logger::info('تنظیمات افزونه از پنل ذخیره شد');

        return ['saved' => true];
    }

    /**
     * خواندن انتهای گزارش.
     *
     * @return array<string,mixed>
     */
    private function handleLogTail(): array
    {
        $lines = (int) $this->request->get('lines', 200);
        $lines = max(10, min(500, $lines));

        return ['lines' => Logger::tail($lines)];
    }

    /**
     * پاک کردن گزارش‌ها.
     *
     * @return array<string,mixed>
     */
    private function handleLogClear(): array
    {
        Logger::clear();
        Logger::info('گزارش‌ها توسط مدیر پاک شدند');
        return ['cleared' => true];
    }

    /**
     * بررسی فعال بودن افزونه.
     *
     * @return void
     *
     * @throws \RuntimeException در صورت غیرفعال بودن
     */
    private function assertEnabled(): void
    {
        $settings = Settings::load();

        if ($settings['enabled'] !== '1') {
            throw new \RuntimeException('افزونه در تنظیمات غیرفعال است', 400);
        }
    }

    /**
     * پاسخ موفق JSON.
     *
     * @param array<string,mixed> $data داده
     *
     * @return void
     */
    private function jsonSuccess(array $data): void
    {
        $this->response->setStatus(200);
        $this->response->throwJson(array_merge(['ok' => true], $data));
    }

    /**
     * پاسخ خطای JSON.
     *
     * @param string $message پیام خطا
     * @param int    $code    کد وضعیت HTTP
     *
     * @return void
     */
    private function jsonError(string $message, int $code = 400): void
    {
        $this->response->setStatus($code >= 200 && $code < 600 ? $code : 500);
        $this->response->throwJson([
            'ok'    => false,
            'error' => $message,
            'code'  => $code,
        ]);
    }
}
