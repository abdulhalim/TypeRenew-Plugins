<?php
/**
 * SimpleReaction - English (en_US) Language Pack
 *
 * This file contains English translations for the SimpleReaction plugin.
 *
 * @package SimpleReaction
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

return array(
    // ============================================================
    // Plugin Info
    // ============================================================
    'SimpleReaction'                                                                 => 'SimpleReaction',
    'Lightweight and secure reaction system for TypeRenew'                           => 'Lightweight and secure reaction system for TypeRenew',
    'Version %s'                                                                     => 'Version %s',

    // ============================================================
    // Settings - Main
    // ============================================================
    'Plugin Status'                                                                  => 'Plugin Status',
    'Enable or disable the entire reaction system.'                                  => 'Enable or disable the entire reaction system.',
    'Enabled'                                                                        => 'Enabled',
    'Disabled'                                                                       => 'Disabled',

    'Active Reactions'                                                               => 'Active Reactions',
    'Select which reactions should be displayed on posts.'                           => 'Select which reactions should be displayed on posts.',

    'Auto Inject'                                                                    => 'Auto Inject',
    'If enabled, reactions will appear at the end of each post.'                     => 'If enabled, reactions will appear at the end of each post.',
    'Yes (auto inject)'                                                              => 'Yes (auto inject)',
    'No, manual only'                                                                => 'No, manual only',

    'Show Count'                                                                     => 'Show Count',
    'Should the reaction count be displayed next to each button?'                    => 'Should the reaction count be displayed next to each button?',
    'Show'                                                                           => 'Show',
    'Hide'                                                                           => 'Hide',

    'Show Label'                                                                     => 'Show Label',
    'Should the text label be displayed next to each button?'                        => 'Should the text label be displayed next to each button?',
    'Emoji only'                                                                     => 'Emoji only',

    'Rate Limit'                                                                     => 'Rate Limit',
    'Maximum number of reactions allowed per visitor in a 60-second window.'         => 'Maximum number of reactions allowed per visitor in a 60-second window.',

    'Display Restriction'                                                            => 'Display Restriction',
    'Should reactions only appear on single post pages?'                             => 'Should reactions only appear on single post pages?',
    'Single post only'                                                               => 'Single post only',
    'Everywhere'                                                                     => 'Everywhere',

    // ============================================================
    // Settings - Security
    // ============================================================
    'Active Security Measures'                                                       => 'Active Security Measures',
    'These features are enabled by default and cannot be disabled.'                  => 'These features are enabled by default and cannot be disabled.',
    'CSRF Protection (Nonce Verification)'                                           => 'CSRF Protection (Nonce Verification)',
    'XSS Protection (Output Escaping)'                                               => 'XSS Protection (Output Escaping)',
    'SQL Injection Protection (Prepared Statements)'                                 => 'SQL Injection Protection (Prepared Statements)',
    'Input Validation (cid, reaction)'                                               => 'Input Validation (cid, reaction)',
    'Permission Checking for Admin Operations'                                       => 'Permission Checking for Admin Operations',
    'Direct Access Protection'                                                       => 'Direct Access Protection',
    'Rate Limiting (IP/visitor_hash)'                                                => 'Rate Limiting (IP/visitor_hash)',

    // ============================================================
    // Settings - Admin Tools
    // ============================================================
    'Admin Tools'                                                                    => 'Admin Tools',
    'Export CSV'                                                                     => 'Export CSV',
    'Download all reaction statistics as a CSV file.'                                => 'Download all reaction statistics as a CSV file.',
    'Reset Statistics'                                                               => 'Reset Statistics',
    'Reset counter statistics without deleting vote records.'                        => 'Reset counter statistics without deleting vote records.',
    'Purge All Reactions'                                                            => 'Purge All Reactions',
    'Delete all vote records and statistics. This action is irreversible!'            => 'Delete all vote records and statistics. This action is irreversible!',

    // ============================================================
    // Settings - Danger Zone
    // ============================================================
    'Uninstall Plugin (Danger Zone)'                                                 => 'Uninstall Plugin (Danger Zone)',
    'To completely remove the plugin along with all database tables, use the "Plugins" section in the Typecho admin panel. The uninstall action will permanently delete all reaction data.' => 'To completely remove the plugin along with all database tables, use the "Plugins" section in the Typecho admin panel. The uninstall action will permanently delete all reaction data.',

    // ============================================================
    // Settings - Buttons
    // ============================================================
    'Save Settings'                                                                  => 'Save Settings',
    'Back to Plugins'                                                                => 'Back to Plugins',

    // ============================================================
    // Settings - Confirm Messages
    // ============================================================
    'Are you sure you want to reset all statistics? This action cannot be undone.'   => 'Are you sure you want to reset all statistics? This action cannot be undone.',
    'WARNING: All stored reactions will be permanently deleted. Are you sure?'       => 'WARNING: All stored reactions will be permanently deleted. Are you sure?',

    // ============================================================
    // Settings - Status Messages
    // ============================================================
    'The reaction system is currently disabled. Enable it to display reactions on your site.' => 'The reaction system is currently disabled. Enable it to display reactions on your site.',

    // ============================================================
    // Frontend - Labels
    // ============================================================
    'React to this post'                                                             => 'React to this post',
    'Total:'                                                                         => 'Total:',
    'Most Popular:'                                                                  => 'Most Popular:',

    // ============================================================
    // Frontend - Reaction Labels (default reactions)
    // ============================================================
    'Loved it'                                                                       => 'Loved it',
    'Useful'                                                                         => 'Useful',
    'Awesome'                                                                        => 'Awesome',
    'Funny'                                                                          => 'Funny',
    'Sad'                                                                            => 'Sad',
    'Disagree'                                                                       => 'Disagree',

    // ============================================================
    // Frontend - AJAX Messages
    // ============================================================
    'Loading...'                                                                     => 'Loading...',
    'An error occurred. Please try again.'                                           => 'An error occurred. Please try again.',
    'Your reaction has been recorded.'                                               => 'Your reaction has been recorded.',
    'Your reaction has been removed.'                                                => 'Your reaction has been removed.',
    'Your reaction has been changed.'                                                => 'Your reaction has been changed.',
    'Too many requests. Please wait a moment.'                                       => 'Too many requests. Please wait a moment.',

    // ============================================================
    // AJAX Error Responses
    // ============================================================
    'Invalid request.'                                                               => 'Invalid request.',
    'Invalid security token.'                                                        => 'Invalid security token.',
    'Invalid post ID.'                                                               => 'Invalid post ID.',
    'Invalid reaction type.'                                                         => 'Invalid reaction type.',
    'This reaction is disabled.'                                                     => 'This reaction is disabled.',
    'Post not found.'                                                                => 'Post not found.',
    'Error recording reaction.'                                                      => 'Error recording reaction.',
    'Statistics loaded.'                                                             => 'Statistics loaded.',
    'Access denied.'                                                                 => 'Access denied.',
    'Invalid token.'                                                                 => 'Invalid token.',
    'Internal server error.'                                                         => 'Internal server error.',
    'Confirmation required. The confirm parameter must be PURGE_ALL_YES.'            => 'Confirmation required. The confirm parameter must be PURGE_ALL_YES.',
    'All reactions have been deleted.'                                               => 'All reactions have been deleted.',
    'Error deleting reactions.'                                                      => 'Error deleting reactions.',
    'Error generating CSV.'                                                          => 'Error generating CSV.',
    'Statistics have been reset successfully.'                                       => 'Statistics have been reset successfully.',
    'Unknown operation.'                                                             => 'Unknown operation.',

    // ============================================================
    // Settings Sections
    // ============================================================
    '1. Main Settings'                                                               => '1. Main Settings',
    '2. Display Options'                                                             => '2. Display Options',
    '3. Security & Rate Limiting'                                                    => '3. Security & Rate Limiting',
    '4. Admin Tools'                                                                 => '4. Admin Tools',
    '5. Uninstall Plugin (Danger Zone)'                                              => '5. Uninstall Plugin (Danger Zone)',
);