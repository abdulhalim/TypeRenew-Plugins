<?php
/**
 * SimpleReaction - Persian (fa_IR) Language Pack
 *
 * This file contains Persian translations for the SimpleReaction plugin.
 *
 * @package SimpleReaction
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

return array(
    // ============================================================
    // Plugin Info
    // ============================================================
    'SimpleReaction'                                                                 => 'ساده واکنش',
    'Lightweight and secure reaction system for TypeRenew'                           => 'سیستم واکنش سبک و امن برای TypeRenew',
    'Version %s'                                                                     => 'نسخه %s',

    // ============================================================
    // Settings - Main
    // ============================================================
    'Plugin Status'                                                                  => 'وضعیت پلاگین',
    'Enable or disable the entire reaction system.'                                  => 'فعال یا غیرفعال کردن کل سیستم واکنش.',
    'Enabled'                                                                        => 'فعال',
    'Disabled'                                                                       => 'غیرفعال',

    'Active Reactions'                                                               => 'واکنش‌های فعال',
    'Select which reactions should be displayed on posts.'                           => 'انتخاب کنید کدام واکنش‌ها در نوشته‌ها نمایش داده شوند.',

    'Auto Inject'                                                                    => 'تزریق خودکار',
    'If enabled, reactions will appear at the end of each post.'                     => 'اگر فعال باشد، واکنش‌ها در انتهای هر نوشته نمایش داده می‌شوند.',
    'Yes (auto inject)'                                                              => 'بله (تزریق خودکار)',
    'No, manual only'                                                                => 'خیر، فقط با کد دستی',

    'Show Count'                                                                     => 'نمایش شمارنده',
    'Should the reaction count be displayed next to each button?'                    => 'آیا تعداد هر واکنش کنار دکمه نمایش داده شود؟',
    'Show'                                                                           => 'نمایش داده شود',
    'Hide'                                                                           => 'مخفی باشد',

    'Show Label'                                                                     => 'نمایش برچسب',
    'Should the text label be displayed next to each button?'                        => 'آیا برچسب متنی کنار دکمه نمایش داده شود؟',
    'Emoji only'                                                                     => 'فقط ایموجی',

    'Rate Limit'                                                                     => 'حد Rate Limiting',
    'Maximum number of reactions allowed per visitor in a 60-second window.'         => 'حداکثر تعداد واکنش مجاز برای هر بازدیدکننده در پنجرهٔ ۶۰ ثانیه.',

    'Display Restriction'                                                            => 'محدودیت نمایش',
    'Should reactions only appear on single post pages?'                             => 'آیا واکنش‌ها فقط در صفحهٔ تکی نوشته نمایش داده شوند؟',
    'Single post only'                                                               => 'فقط در صفحهٔ تکی نوشته',
    'Everywhere'                                                                     => 'همه‌جا',

    // ============================================================
    // Settings - Security
    // ============================================================
    'Active Security Measures'                                                       => 'اقدامات امنیتی فعال',
    'These features are enabled by default and cannot be disabled.'                  => 'این موارد به‌صورت پیش‌فرض فعال هستند و قابل غیرفعال کردن نیستند.',
    'CSRF Protection (Nonce Verification)'                                           => 'CSRF Protection (Nonce Verification)',
    'XSS Protection (Output Escaping)'                                               => 'XSS Protection (Output Escaping)',
    'SQL Injection Protection (Prepared Statements)'                                 => 'SQL Injection Protection (Prepared Statements)',
    'Input Validation (cid, reaction)'                                               => 'Input Validation (cid, reaction)',
    'Permission Checking for Admin Operations'                                       => 'Permission Checking for Admin Operations',
    'Direct Access Protection'                                                       => 'Direct Access Protection',
    'Rate Limiting (IP/visitor_hash)'                                                => 'Rate Limiting (IP/visitor_hash)',

    // ============================================================
    // Settings - Admin Tools
    // ============================================================
    'Admin Tools'                                                                    => 'ابزار مدیریتی',
    'Export CSV'                                                                     => 'خروجی CSV',
    'Download all reaction statistics as a CSV file.'                                => 'دانلود آمار کل واکنش‌ها به‌صورت فایل CSV.',
    'Reset Statistics'                                                               => 'ریست آمار',
    'Reset counter statistics without deleting vote records.'                        => 'ریست کردن آمار شمارنده‌ها بدون حذف رکوردهای رأی.',
    'Purge All Reactions'                                                            => 'حذف کامل واکنش‌ها',
    'Delete all vote records and statistics. This action is irreversible!'            => 'حذف تمام رکوردهای آراء و آمار. این عمل غیرقابل بازگشت است!',

    // ============================================================
    // Settings - Danger Zone
    // ============================================================
    'Uninstall Plugin (Danger Zone)'                                                 => 'حذف پلاگین (Danger Zone)',
    'To completely remove the plugin along with all database tables, use the "Plugins" section in the Typecho admin panel. The uninstall action will permanently delete all reaction data.' => 'برای حذف کامل پلاگین به‌همراه تمام جداول دیتابیس، از بخش «پلاگین‌های نصب‌شده» در پیشخوان Typecho اقدام کنید. عمل uninstall تمام داده‌های واکنش‌ها را برای همیشه حذف می‌کند.',

    // ============================================================
    // Settings - Buttons
    // ============================================================
    'Save Settings'                                                                  => 'ذخیرهٔ تنظیمات',
    'Back to Plugins'                                                                => 'بازگشت به پلاگین‌ها',

    // ============================================================
    // Settings - Confirm Messages
    // ============================================================
    'Are you sure you want to reset all statistics? This action cannot be undone.'   => 'آیا مطمئن هستید آمار ریست شود؟ این عمل قابل بازگشت نیست.',
    'WARNING: All stored reactions will be permanently deleted. Are you sure?'       => 'هشدار جدی! تمام واکنش‌های ذخیره‌شده حذف خواهند شد. آیا مطمئن هستید؟',

    // ============================================================
    // Settings - Status Messages
    // ============================================================
    'The reaction system is currently disabled. Enable it to display reactions on your site.' => 'سیستم واکنش در حال حاضر غیرفعال است. برای نمایش واکنش‌ها در سایت، آن را فعال کنید.',

    // ============================================================
    // Frontend - Labels
    // ============================================================
    'React to this post'                                                             => 'واکنش شما به این نوشته؟',
    'Total:'                                                                         => 'مجموع:',
    'Most Popular:'                                                                  => 'محبوب‌ترین:',

    // ============================================================
    // Frontend - Reaction Labels (default reactions)
    // ============================================================
    'Loved it'                                                                       => 'دوست داشتم',
    'Useful'                                                                         => 'مفید بود',
    'Awesome'                                                                        => 'عالی بود',
    'Funny'                                                                          => 'خنده‌دار بود',
    'Sad'                                                                            => 'ناراحت‌کننده بود',
    'Disagree'                                                                       => 'مخالفم',

    // ============================================================
    // Frontend - AJAX Messages
    // ============================================================
    'Loading...'                                                                     => 'در حال بارگذاری...',
    'An error occurred. Please try again.'                                           => 'خطایی رخ داد. مجدد تلاش کنید.',
    'Your reaction has been recorded.'                                               => 'نظر شما ثبت شد.',
    'Your reaction has been removed.'                                                => 'واکنش شما حذف شد.',
    'Your reaction has been changed.'                                                => 'واکنش شما تغییر کرد.',
    'Too many requests. Please wait a moment.'                                       => 'تعداد درخواست‌ها بیش از حد مجاز است. کمی صبر کنید.',

    // ============================================================
    // AJAX Error Responses
    // ============================================================
    'Invalid request.'                                                               => 'درخواست نامعتبر است.',
    'Invalid security token.'                                                        => 'توکن امنیتی نامعتبر است.',
    'Invalid post ID.'                                                               => 'شناسهٔ نوشته نامعتبر است.',
    'Invalid reaction type.'                                                         => 'نوع واکنش نامعتبر است.',
    'This reaction is disabled.'                                                     => 'این واکنش غیرفعال است.',
    'Post not found.'                                                                => 'نوشته یافت نشد.',
    'Error recording reaction.'                                                      => 'خطا در ثبت واکنش.',
    'Statistics loaded.'                                                             => 'آمار بارگذاری شد.',
    'Access denied.'                                                                 => 'دسترسی غیرمجاز.',
    'Invalid token.'                                                                 => 'توکن نامعتبر.',
    'Internal server error.'                                                         => 'خطای داخلی سرور.',
    'Confirmation required. The confirm parameter must be PURGE_ALL_YES.'            => 'تأیید لازم است. مقدار confirm باید PURGE_ALL_YES باشد.',
    'All reactions have been deleted.'                                               => 'تمام واکنش‌ها حذف شدند.',
    'Error deleting reactions.'                                                      => 'خطا در حذف واکنش‌ها.',
    'Error generating CSV.'                                                          => 'خطا در تولید CSV.',
    'Statistics have been reset successfully.'                                       => 'آمار با موفقیت ریست شد.',
    'Unknown operation.'                                                             => 'عملیات ناشناخته.',

    // ============================================================
    // Settings Sections
    // ============================================================
    '1. Main Settings'                                                               => '۱. تنظیمات اصلی',
    '2. Display Options'                                                             => '۲. نحوهٔ نمایش',
    '3. Security & Rate Limiting'                                                    => '۳. امنیت و Rate Limiting',
    '4. Admin Tools'                                                                 => '۴. ابزار مدیریتی',
    '5. Uninstall Plugin (Danger Zone)'                                              => '۵. حذف پلاگین (Danger Zone)',
);