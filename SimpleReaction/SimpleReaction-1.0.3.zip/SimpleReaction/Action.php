<?php
declare(strict_types=1);

namespace TypechoPlugin\SimpleReaction;

use Typecho\Db;
use Typecho\Widget;
use Widget\ActionInterface;
use Widget\User;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * کنترلر AJAX برای واکنش‌ها.
 *
 * مسیر: /action/simpleReaction
 *
 * اکشن‌ها:
 *   POST do=vote            — ثبت یا حذف یک واکنش
 *   GET  do=stats           — دریافت آمار یک نوشته
 *   POST do=reset           — بازنشانی آمار (فقط مدیر)
 *   GET  do=export          — خروجی CSV (فقط مدیر)
 *   POST do=purge           — حذف کامل آراء و آمار (فقط مدیر)
 */
class Action extends Widget implements ActionInterface
{
    /**
     * نقطه‌ی ورود اکشن.
     */
    public function action(): void
    {
        $this->setSecurityHeaders();

        $do = (string) $this->request->get('do', 'vote');
        $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));

        try {
            switch ($do) {
                case 'vote':
                    if ($method !== 'POST') {
                        $this->jsonExit(false, Plugin::tr('Invalid request.'), null, 405);
                    }
                    $this->handleVote();
                    break;

                case 'stats':
                    if ($method !== 'GET') {
                        $this->jsonExit(false, Plugin::tr('Invalid request.'), null, 405);
                    }
                    $this->handleStats();
                    break;

                case 'reset':
                    if ($method !== 'POST') {
                        $this->jsonExit(false, Plugin::tr('Invalid request.'), null, 405);
                    }
                    $this->handleReset();
                    break;

                case 'export':
                    if ($method !== 'GET') {
                        $this->jsonExit(false, Plugin::tr('Invalid request.'), null, 405);
                    }
                    $this->handleExport();
                    break;

                case 'purge':
                    if ($method !== 'POST') {
                        $this->jsonExit(false, Plugin::tr('Invalid request.'), null, 405);
                    }
                    $this->handlePurge();
                    break;

                default:
                    $this->jsonExit(false, Plugin::tr('Unknown operation.'), null, 400);
            }
        } catch (\Throwable $e) {
            $this->jsonExit(false, Plugin::tr('Internal server error.'), null, 500);
        }
    }

    /* ============================================================
     *                    SECURITY HEADERS
     * ============================================================ */

    /**
     * تنظیم هدرهای امنیتی برای همه‌ی پاسخ‌ها.
     */
    private function setSecurityHeaders(): void
    {
        $resp = $this->response;
        $resp->setHeader('Content-Type', 'application/json; charset=utf-8');
        $resp->setHeader('X-Robots-Tag', 'noindex, nofollow');
        $resp->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $resp->setHeader('Pragma', 'no-cache');
        $resp->setHeader('X-Content-Type-Options', 'nosniff');
        $resp->setHeader('X-Frame-Options', 'DENY');
        $resp->setHeader('Referrer-Policy', 'same-origin');
    }

    /* ============================================================
     *                    VOTE HANDLER
     * ============================================================ */

    private function handleVote(): void
    {
        $nonce = (string) $this->request->get('sr_nonce', '');
        if (!Plugin::verifyNonce($nonce, 'sr_vote')) {
            $this->jsonExit(false, Plugin::tr('Invalid security token.'), null, 403);
        }

        if (!$this->rateLimitCheck()) {
            $this->jsonExit(false, Plugin::tr('Too many requests. Please wait a moment.'), null, 429);
        }

        $cid = (int) $this->request->get('cid', 0);
        $reaction = (string) $this->request->get('reaction', '');

        if ($cid <= 0) {
            $this->jsonExit(false, Plugin::tr('Invalid post ID.'), null, 400);
        }
        if (!Plugin::isValidReaction($reaction)) {
            $this->jsonExit(false, Plugin::tr('Invalid reaction type.'), null, 400);
        }

        $active = Plugin::getActiveReactions();
        if (!in_array($reaction, $active, true)) {
            $this->jsonExit(false, Plugin::tr('This reaction is disabled.'), null, 400);
        }

        if (!$this->cidExists($cid)) {
            $this->jsonExit(false, Plugin::tr('Post not found.'), null, 404);
        }

        $uid = Plugin::currentUserId();
        $visitorHash = $uid ? '' : Plugin::visitorHash();
        $ipHash = Plugin::ipHash();

        $existing = $this->fetchVote($cid, $uid, $visitorHash);

        try {
            $db = Db::get();
            $now = time();
            $votesTable = 'table.' . Plugin::VOTES_TABLE;

            if ($existing) {
                if ($existing['reaction'] === $reaction) {
                    // حذف رأی
                    $db->query(
                        $db->delete($votesTable)
                            ->where('id = ?', (int) $existing['id']),
                        Db::WRITE
                    );
                    $this->decrementStat($cid, $reaction);
                    $stats = Renderer::getStatsForCid($cid);
                    $this->jsonExit(true, Plugin::tr('Your reaction has been removed.'), $stats, 200);
                    return;
                } else {
                    // تغییر رأی
                    $db->query(
                        $db->delete($votesTable)
                            ->where('id = ?', (int) $existing['id']),
                        Db::WRITE
                    );
                    $this->decrementStat($cid, $existing['reaction']);
                    $this->insertVote($cid, $reaction, $uid, $visitorHash, $ipHash, $now);
                    $this->incrementStat($cid, $reaction, $now);
                    $stats = Renderer::getStatsForCid($cid);
                    $this->jsonExit(true, Plugin::tr('Your reaction has been changed.'), $stats, 200);
                    return;
                }
            } else {
                // ثبت رأی جدید
                $this->insertVote($cid, $reaction, $uid, $visitorHash, $ipHash, $now);
                $this->incrementStat($cid, $reaction, $now);
                $stats = Renderer::getStatsForCid($cid);
                $this->jsonExit(true, Plugin::tr('Your reaction has been recorded.'), $stats, 200);
                return;
            }
        } catch (\Throwable $e) {
            $isDebug = defined('__TYPECHO_DEBUG__') && __TYPECHO_DEBUG__;
            $msg = $isDebug
                ? sprintf(Plugin::tr('Error recording reaction: %s'), $e->getMessage())
                : Plugin::tr('Error recording reaction.');
            $this->jsonExit(false, $msg, null, 500);
        }
    }

    /* ============================================================
     *                    DATABASE HELPERS
     * ============================================================ */

    /**
     * @param int    $cid
     * @param int    $uid
     * @param string $visitorHash
     * @return array<string,mixed>|null
     */
    private function fetchVote(int $cid, int $uid, string $visitorHash): ?array
    {
        $db = Db::get();
        $select = $db->select('id', 'reaction')
            ->from('table.' . Plugin::VOTES_TABLE)
            ->where('cid = ?', $cid);

        if ($uid > 0) {
            $select->where('user_id = ?', $uid);
        } else {
            $select->where('visitor_hash = ?', $visitorHash)
                ->where('user_id = 0');
        }
        $select->limit(1);

        $row = $db->fetchRow($select);
        return $row ?: null;
    }

    private function insertVote(
        int $cid,
        string $reaction,
        int $uid,
        string $visitorHash,
        string $ipHash,
        int $now
    ): void {
        $db = Db::get();
        $db->query(
            $db->insert('table.' . Plugin::VOTES_TABLE)
                ->rows([
                    'cid'          => $cid,
                    'reaction'     => $reaction,
                    'user_id'      => $uid,
                    'visitor_hash' => $visitorHash,
                    'ip_hash'      => $ipHash,
                    'created'      => $now,
                ]),
            Db::WRITE
        );
    }

    private function incrementStat(int $cid, string $reaction, int $now): void
    {
        $db = Db::get();

        $exists = $db->fetchRow(
            $db->select('id', 'count')->from('table.' . Plugin::STATS_TABLE)
                ->where('cid = ?', $cid)->where('reaction = ?', $reaction)
        );

        if ($exists) {
            $db->query(
                $db->update('table.' . Plugin::STATS_TABLE)
                    ->rows(['count' => (int) $exists['count'] + 1, 'updated' => $now])
                    ->where('id = ?', (int) $exists['id']),
                Db::WRITE
            );
        } else {
            $db->query(
                $db->insert('table.' . Plugin::STATS_TABLE)
                    ->rows([
                        'cid'      => $cid,
                        'reaction' => $reaction,
                        'count'    => 1,
                        'created'  => $now,
                        'updated'  => $now,
                    ]),
                Db::WRITE
            );
        }
    }

    private function decrementStat(int $cid, string $reaction): void
    {
        $db = Db::get();
        $now = time();
        $row = $db->fetchRow(
            $db->select('id', 'count')->from('table.' . Plugin::STATS_TABLE)
                ->where('cid = ?', $cid)->where('reaction = ?', $reaction)
        );
        if (!$row) {
            return;
        }
        $newCount = max(0, (int) $row['count'] - 1);
        $db->query(
            $db->update('table.' . Plugin::STATS_TABLE)
                ->rows(['count' => $newCount, 'updated' => $now])
                ->where('id = ?', (int) $row['id']),
            Db::WRITE
        );
    }

    private function cidExists(int $cid): bool
    {
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('cid')->from('table.contents')
                    ->where('cid = ?', $cid)
                    ->where('type IN (?, ?)', 'post', 'page')
                    ->where('status = ?', 'publish')
                    ->limit(1)
            );
            return !empty($row);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /* ============================================================
     *                    STATS HANDLER
     * ============================================================ */

    private function handleStats(): void
    {
        $cid = (int) $this->request->get('cid', 0);
        if ($cid <= 0) {
            $this->jsonExit(false, Plugin::tr('Invalid post ID.'), null, 400);
        }

        $stats = Renderer::getStatsForCid($cid);
        $userReaction = Renderer::getUserReaction($cid);

        $total = 0;
        $topKey = null;
        $topVal = 0;
        foreach ($stats as $key => $val) {
            $total += $val;
            if ($val > $topVal) {
                $topVal = $val;
                $topKey = $key;
            }
        }

        $this->jsonExit(true, Plugin::tr('Statistics loaded.'), [
            'cid'           => $cid,
            'stats'         => $stats,
            'user_reaction' => $userReaction,
            'total'         => $total,
            'top_reaction'  => $topKey,
        ], 200);
    }

    /* ============================================================
     *                    ADMIN HANDLERS
     * ============================================================ */

    private function handleReset(): void
    {
        if (!$this->requireAdmin('sr_admin')) {
            return;
        }
        Migration::resetStats();
        $this->jsonExit(true, Plugin::tr('Statistics have been reset successfully.'), null, 200);
    }

    private function handlePurge(): void
    {
        if (!$this->requireAdmin('sr_admin')) {
            return;
        }
        $confirm = (string) $this->request->get('confirm', '');
        if ($confirm !== 'PURGE_ALL_YES') {
            $this->jsonExit(false, Plugin::tr('Confirmation required. The confirm parameter must be PURGE_ALL_YES.'), null, 400);
            return;
        }
        try {
            Migration::resetStats();
            $this->jsonExit(true, Plugin::tr('All reactions have been deleted.'), null, 200);
        } catch (\Throwable $e) {
            $this->jsonExit(false, Plugin::tr('Error deleting reactions.'), null, 500);
        }
    }

    private function handleExport(): void
    {
        if (!$this->requireAdmin('sr_admin', false)) {
            return;
        }
        try {
            $db = Db::get();
            $prefix = $db->getPrefix();
            $adapter = strtolower($db->getAdapterName());
            $q = str_contains($adapter, 'pgsql') ? '"' : '`';
            $statsTable = $prefix . Plugin::STATS_TABLE;

            $rows = $db->fetchAll(
                "SELECT {$q}cid{$q},{$q}reaction{$q},{$q}count{$q},{$q}created{$q},{$q}updated{$q} "
                . "FROM {$q}{$statsTable}{$q} ORDER BY {$q}cid{$q} ASC, {$q}count{$q} DESC;"
            );

            $resp = $this->response;
            $resp->setHeader('Content-Type', 'text/csv; charset=utf-8');
            $resp->setHeader('Content-Disposition', 'attachment; filename="simple-reaction-stats.csv"');
            $resp->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
            $resp->setHeader('Pragma', 'no-cache');

            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF");
            fputcsv($out, ['cid', 'reaction', 'count', 'created', 'updated']);
            foreach ($rows as $row) {
                fputcsv($out, [
                    $row['cid'],
                    $row['reaction'],
                    $row['count'],
                    date('Y-m-d H:i:s', (int) $row['created']),
                    date('Y-m-d H:i:s', (int) $row['updated']),
                ]);
            }
            fclose($out);
        } catch (\Throwable $e) {
            $this->jsonExit(false, Plugin::tr('Error generating CSV.'), null, 500);
        }
    }

    /* ============================================================
     *                      HELPERS
     * ============================================================ */

    /**
     * بررسی دسترسی مدیر با nonce.
     *
     * @param string $action
     * @param bool   $jsonOnFail
     * @return bool
     */
    private function requireAdmin(string $action, bool $jsonOnFail = true): bool
    {
        $user = User::alloc();
        if (!$user->hasLogin() || !$user->pass('administrator', true)) {
            if ($jsonOnFail) {
                $this->jsonExit(false, Plugin::tr('Access denied.'), null, 403);
            } else {
                $this->response->setStatus(403);
                echo Plugin::tr('Access denied.');
            }
            return false;
        }
        $nonce = (string) $this->request->get('sr_nonce', '');
        if (!Plugin::verifyNonce($nonce, $action)) {
            if ($jsonOnFail) {
                $this->jsonExit(false, Plugin::tr('Invalid security token.'), null, 403);
            } else {
                $this->response->setStatus(403);
                echo Plugin::tr('Invalid token.');
            }
            return false;
        }
        return true;
    }

    /**
     * Rate limit بدون استفاده از session (که با مدیریت session خود TypeRenew تداخل دارد).
     * از یک فایل قفل‌گذاری‌شده (flock) در مسیر آپلودها استفاده می‌کند.
     *
     * @return bool
     */
    private function rateLimitCheck(): bool
    {
        $uid = Plugin::currentUserId();
        $visitorHash = $uid ? 'u' . sha1((string) $uid) : 'v' . Plugin::visitorHash();
        $config = Plugin::getConfig();
        $limit = $config ? (int) $config->rate_limit : Plugin::RATE_LIMIT_COUNT;
        if ($limit <= 0) {
            $limit = Plugin::RATE_LIMIT_COUNT;
        }

        // مسیر ذخیره‌ی state — داخل دایرکتوری آپلودها
        $cacheDir = self::cacheDir();
        if (!is_dir($cacheDir)) {
            @mkdir($cacheDir, 0755, true);
        }
        if (!is_dir($cacheDir) || !is_writable($cacheDir)) {
            // اگر دایرکتوری قابل نوشتن نبود، rate limit را غیرفعال می‌کنیم
            return true;
        }

        $file = $cacheDir . '/rl_' . substr($visitorHash, 0, 32) . '.json';
        $now = time();
        $window = Plugin::RATE_LIMIT_WINDOW;

        $data = ['count' => 0, 'start' => $now];
        if (is_file($file)) {
            $content = @file_get_contents($file);
            if ($content !== false) {
                $decoded = json_decode($content, true);
                if (is_array($decoded) && isset($decoded['count'], $decoded['start'])) {
                    $data = $decoded;
                }
            }
        }
        if ($now - (int) $data['start'] > $window) {
            $data = ['count' => 0, 'start' => $now];
        }
        $data['count'] = (int) $data['count'] + 1;

        // نوشتن و قفل‌گذاری برای جلوگیری از رقابت
        $fp = @fopen($file, 'c+');
        if (!$fp) {
            return true;
        }
        if (flock($fp, LOCK_EX)) {
            ftruncate($fp, 0);
            rewind($fp);
            fwrite($fp, json_encode($data, JSON_UNESCAPED_UNICODE));
            fflush($fp);
            flock($fp, LOCK_UN);
        }
        fclose($fp);

        return $data['count'] <= $limit;
    }

    /**
     * مسیر دایرکتوری کش rate limit.
     * در دایرکتوری آپلودها قرار می‌گیرد تا قابل نوشتن باشد.
     *
     * @return string
     */
    private static function cacheDir(): string
    {
        $root = rtrim(str_replace(['/', '\\'], DIRECTORY_SEPARATOR, (string) __TYPECHO_ROOT_DIR__), DIRECTORY_SEPARATOR);

        $uploadDir = defined('__TYPECHO_UPLOAD_DIR__')
            ? (string) __TYPECHO_UPLOAD_DIR__
            : '/usr/uploads';
        $uploadDir = trim(str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $uploadDir), DIRECTORY_SEPARATOR);

        return $root . DIRECTORY_SEPARATOR . $uploadDir . DIRECTORY_SEPARATOR . '.sr_cache';
    }

    /**
     * خروجی JSON و پایان.
     *
     * @param bool       $success
     * @param string     $message
     * @param array|null $stats
     * @param int        $code
     */
    private function jsonExit(bool $success, string $message, ?array $stats = null, int $code = 200): void
    {
        $this->response->setStatus($code);
        $payload = [
            'success' => $success,
            'message' => $message,
            'code'    => $code,
            'stats'   => $stats,
            'ts'      => time(),
        ];
        echo json_encode(
            $payload,
            JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
        );
        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        }
        exit;
    }
}
