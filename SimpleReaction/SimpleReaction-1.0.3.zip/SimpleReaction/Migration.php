<?php
declare(strict_types=1);

namespace TypechoPlugin\SimpleReaction;

use Typecho\Db;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * مدیریت شِما (schema) افزونه SimpleReaction.
 *
 * دو جدول ایجاد می‌کند:
 *   1) simple_reaction_stats   — آمار تجمیعی (cid, reaction, count)
 *   2) simple_reaction_votes   — آراء منفرد (cid, reaction, user_id/visitor_hash)
 *
 * سازگار با MySQL/Mysqli، PostgreSQL و SQLite.
 */
class Migration
{
    /**
     * اطمینان از وجود هر دو جدول.
     *
     * @throws \Throwable
     */
    public static function ensure(): void
    {
        $db = Db::get();
        $prefix = $db->getPrefix();
        $adapter = strtolower($db->getAdapterName());
        $statsTable = $prefix . Plugin::STATS_TABLE;
        $votesTable = $prefix . Plugin::VOTES_TABLE;

        // برای Pgsql از "TABLE" استفاده می‌کنیم تا حساسیت به حروف بزرگ/کوچک رعایت شود.
        $isPgsql = str_contains($adapter, 'pgsql');
        $isSqlite = str_contains($adapter, 'sqlite');

        if ($isSqlite) {
            self::createSqlite($db, $statsTable, $votesTable);
        } elseif ($isPgsql) {
            self::createPgsql($db, $statsTable, $votesTable);
        } else {
            self::createMysql($db, $statsTable, $votesTable);
        }
    }

    /**
     * ساخت جداول در SQLite.
     */
    private static function createSqlite(Db $db, string $statsTable, string $votesTable): void
    {
        $db->query("CREATE TABLE IF NOT EXISTS `{$statsTable}` (
            `id`       INTEGER PRIMARY KEY AUTOINCREMENT,
            `cid`      INTEGER NOT NULL DEFAULT 0,
            `reaction` TEXT    NOT NULL DEFAULT '',
            `count`    INTEGER NOT NULL DEFAULT 0,
            `created`  INTEGER NOT NULL DEFAULT 0,
            `updated`  INTEGER NOT NULL DEFAULT 0
        );", Db::WRITE);
        $db->query("CREATE TABLE IF NOT EXISTS `{$votesTable}` (
            `id`           INTEGER PRIMARY KEY AUTOINCREMENT,
            `cid`          INTEGER NOT NULL DEFAULT 0,
            `reaction`     TEXT    NOT NULL DEFAULT '',
            `user_id`      INTEGER NOT NULL DEFAULT 0,
            `visitor_hash` TEXT    NOT NULL DEFAULT '',
            `ip_hash`      TEXT    NOT NULL DEFAULT '',
            `created`      INTEGER NOT NULL DEFAULT 0
        );", Db::WRITE);
        // شاخص‌ها
        $db->query("CREATE INDEX IF NOT EXISTS `idx_srs_cid_reaction` ON `{$statsTable}` (`cid`, `reaction`);", Db::WRITE);
        $db->query("CREATE INDEX IF NOT EXISTS `idx_srs_cid` ON `{$statsTable}` (`cid`);", Db::WRITE);
        $db->query("CREATE INDEX IF NOT EXISTS `idx_srv_cid_user` ON `{$votesTable}` (`cid`, `user_id`);", Db::WRITE);
        $db->query("CREATE INDEX IF NOT EXISTS `idx_srv_cid_visitor` ON `{$votesTable}` (`cid`, `visitor_hash`);", Db::WRITE);
        $db->query("CREATE INDEX IF NOT EXISTS `idx_srv_created` ON `{$votesTable}` (`created`);", Db::WRITE);
    }

    /**
     * ساخت جداول در PostgreSQL.
     */
    private static function createPgsql(Db $db, string $statsTable, string $votesTable): void
    {
        $db->query("CREATE TABLE IF NOT EXISTS \"{$statsTable}\" (
            \"id\"       SERIAL PRIMARY KEY,
            \"cid\"      INTEGER NOT NULL DEFAULT 0,
            \"reaction\" VARCHAR(32) NOT NULL DEFAULT '',
            \"count\"    INTEGER NOT NULL DEFAULT 0,
            \"created\"  INTEGER NOT NULL DEFAULT 0,
            \"updated\"  INTEGER NOT NULL DEFAULT 0,
            UNIQUE (\"cid\", \"reaction\")
        );", Db::WRITE);
        $db->query("CREATE TABLE IF NOT EXISTS \"{$votesTable}\" (
            \"id\"           SERIAL PRIMARY KEY,
            \"cid\"          INTEGER NOT NULL DEFAULT 0,
            \"reaction\"     VARCHAR(32) NOT NULL DEFAULT '',
            \"user_id\"      INTEGER NOT NULL DEFAULT 0,
            \"visitor_hash\" VARCHAR(128) NOT NULL DEFAULT '',
            \"ip_hash\"      VARCHAR(128) NOT NULL DEFAULT '',
            \"created\"      INTEGER NOT NULL DEFAULT 0
        );", Db::WRITE);
        $db->query("CREATE INDEX IF NOT EXISTS \"idx_srs_cid\" ON \"{$statsTable}\" (\"cid\");", Db::WRITE);
        $db->query("CREATE INDEX IF NOT EXISTS \"idx_srs_cid_reaction\" ON \"{$statsTable}\" (\"cid\", \"reaction\");", Db::WRITE);
        $db->query("CREATE INDEX IF NOT EXISTS \"idx_srv_cid_user\" ON \"{$votesTable}\" (\"cid\", \"user_id\");", Db::WRITE);
        $db->query("CREATE INDEX IF NOT EXISTS \"idx_srv_cid_visitor\" ON \"{$votesTable}\" (\"cid\", \"visitor_hash\");", Db::WRITE);
        $db->query("CREATE INDEX IF NOT EXISTS \"idx_srv_created\" ON \"{$votesTable}\" (\"created\");", Db::WRITE);
    }

    /**
     * ساخت جداول در MySQL/MariaDB.
     */
    private static function createMysql(Db $db, string $statsTable, string $votesTable): void
    {
        $db->query("CREATE TABLE IF NOT EXISTS `{$statsTable}` (
            `id`       INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `cid`      INT UNSIGNED NOT NULL DEFAULT 0,
            `reaction` VARCHAR(32)  NOT NULL DEFAULT '',
            `count`    INT UNSIGNED NOT NULL DEFAULT 0,
            `created`  INT UNSIGNED NOT NULL DEFAULT 0,
            `updated`  INT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uk_cid_reaction` (`cid`, `reaction`),
            KEY `idx_cid` (`cid`),
            KEY `idx_reaction` (`reaction`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;", Db::WRITE);
        $db->query("CREATE TABLE IF NOT EXISTS `{$votesTable}` (
            `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `cid`          INT UNSIGNED NOT NULL DEFAULT 0,
            `reaction`     VARCHAR(32)  NOT NULL DEFAULT '',
            `user_id`      INT UNSIGNED NOT NULL DEFAULT 0,
            `visitor_hash` CHAR(64)     NOT NULL DEFAULT '',
            `ip_hash`      CHAR(64)     NOT NULL DEFAULT '',
            `created`      INT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uk_cid_user_visitor` (`cid`, `user_id`, `visitor_hash`),
            KEY `idx_cid` (`cid`),
            KEY `idx_user` (`user_id`),
            KEY `idx_visitor` (`visitor_hash`),
            KEY `idx_created` (`created`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;", Db::WRITE);
    }

    /**
     * حذف کامل جداول افزونه.
     */
    public static function drop(): void
    {
        $db = Db::get();
        $prefix = $db->getPrefix();
        $adapter = strtolower($db->getAdapterName());
        $statsTable = $prefix . Plugin::STATS_TABLE;
        $votesTable = $prefix . Plugin::VOTES_TABLE;
        $q = str_contains($adapter, 'pgsql') ? '"' : '`';
        $db->query("DROP TABLE IF EXISTS {$q}{$statsTable}{$q};", Db::WRITE);
        $db->query("DROP TABLE IF EXISTS {$q}{$votesTable}{$q};", Db::WRITE);
    }

    /**
     * پاکسازی همه‌ی آمار (بدون حذف جدول).
     *
     * @return int
     */
    public static function resetStats(): int
    {
        $db = Db::get();
        $prefix = $db->getPrefix();
        $adapter = strtolower($db->getAdapterName());
        $q = str_contains($adapter, 'pgsql') ? '"' : '`';
        $statsTable = $prefix . Plugin::STATS_TABLE;
        $votesTable = $prefix . Plugin::VOTES_TABLE;
        $db->query("DELETE FROM {$q}{$statsTable}{$q};", Db::WRITE);
        $db->query("DELETE FROM {$q}{$votesTable}{$q};", Db::WRITE);
        return 1;
    }
}
