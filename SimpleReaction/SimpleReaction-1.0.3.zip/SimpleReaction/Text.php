<?php
declare(strict_types=1);

namespace TypechoPlugin\SimpleReaction;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * توابع کمکی متن برای escape و قالب‌بندی.
 */
class Text
{
    /**
     * خروجی امن HTML.
     *
     * @param string|null $value
     * @return string
     */
    public static function e(?string $value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    /**
     * خروجی امن برای ویژگی HTML.
     *
     * @param string|null $value
     * @return string
     */
    public static function attr(?string $value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    /**
     * قالب‌بندی عدد با جداکننده‌ی هزارگان.
     *
     * @param int|string|null $value
     * @return string
     */
    public static function num($value): string
    {
        return number_format((int) $value, 0, '.', ',');
    }
}
