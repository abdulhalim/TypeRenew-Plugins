# SimpleReaction

> سیستم واکنش سبک، امن و سازگار با **TypeRenew** — بدون jQuery، با JavaScript مدرن (Vanilla JS + Fetch API)

پلاگین **SimpleReaction** به کاربران سایت شما اجازه می‌دهد با کلیک روی ایموجی‌ها، به نوشته‌های شما واکنش نشان دهند. این پلاگین برای TypeRenew (و Typecho 1.3+) بهینه‌سازی شده و با پوسته‌های پیش‌فرض TypeRenew (default و Parnian) سازگار است.

- **نویسنده:** پوردریایی
- **وب:** <https://pourdaryaei.ir>
- **نسخه:** 1.0.3
- **مجوز:** GPL-2.0-or-later

---

## فهرست

1. [ویژگی‌ها](#ویژگی‌ها)
2. [نصب](#نصب)
3. [فعال‌سازی](#فعالسازی)
4. [تنظیمات افزونه](#تنظیمات-افزونه)
5. [استفاده در قالب](#استفاده-در-قالب)
6. [سازگاری با حالت روز/شب](#سازگاری-با-حالت-روزشب)
7. [سازگاری با دیتابیس‌ها](#سازگاری-با-دیتابیسها)
8. [امنیت](#امنیت)
9. [API اکشن‌ها](#api-اکشنها)
10. [سفارشی‌سازی رنگ](#سفارشی-سازی-رنگ)
11. [عیب‌یابی](#عیبیابی)
12. [ساختار فایل‌ها](#ساختار-فایلها)

---

## ویژگی‌ها

- ✅ **بدون jQuery** — JavaScript مدرن (Vanilla JS + Fetch API)
- ✅ **سازگار با TypeRenew** — Namespaces جدید Typecho، `Utils\Helper`، `Utils\NoPersonal`
- ✅ **حالت روز/شب خودکار** — با هر دو پوسته‌ی پیش‌فرض TypeRenew (default و Parnian) سازگار است
- ✅ **امنیت بالا** — Nonce CSRF، Rate limit، هش IP/Visitor، بدون session_start
- ✅ **چند-دیتابیسی** — MySQL/MariaDB، PostgreSQL و SQLite
- ✅ **بدون تداخل با session** — Rate limit به‌جای session از فایل‌های قفل‌گذاری‌شده استفاده می‌کند
- ✅ **AJAX سبک** — رأی‌دهی، حذف، تغییر و نمایش آمار به‌صورت آسنکرون
- ✅ **خروجی CSV** — خروجی گرفتن از آمار واکنش‌ها برای تحلیل (فقط مدیر)
- ✅ **چند-زبانه** — فارسی (fa_IR) و انگلیسی (en_US)
- ✅ **Accessibility** — پشتیبانی از کیبورد، aria-pressed، aria-label، prefers-reduced-motion

---

## نصب

1. فایل ZIP را دانلود کنید.
2. محتویات آن را در مسیر زیر اکسترکت کنید:
   ```
   usr/plugins/SimpleReaction/
   ```
   پس از اکسترکت، ساختار باید این‌گونه باشد:
   ```
   usr/plugins/SimpleReaction/
   ├── Plugin.php
   ├── Action.php
   ├── Renderer.php
   ├── Assets.php
   ├── Migration.php
   ├── Text.php
   ├── README.md
   ├── languages/
   │   ├── en_US.php
   │   └── fa_IR.php
   └── assets/
       ├── style.css
       └── app.js
   ```
3. مطمئن شوید که پوشه‌ی `SimpleReaction` و تمام فایل‌های داخلش قابل خواندن توسط PHP باشند (معمولاً `0644` برای فایل‌ها و `0755` برای پوشه‌ها کافی است).

---

## فعال‌سازی

1. وارد پنل مدیریت TypeRenew شوید.
2. به مسیر **افزونه‌ها** بروید.
3. در لیست افزونه‌ها، روی نام **SimpleReaction** کلیک کنید و سپس روی **فعال‌سازی** بزنید.
4. پس از فعال‌سازی، سه اتفاق می‌افتد:
   - دو جدول به دیتابیس اضافه می‌شود:
     - `typecho_simple_reaction_stats` (آمار تجمیعی)
     - `typecho_simple_reaction_votes` (آراء منفرد)
   - مسیر اکشن `/action/simpleReaction` ثبت می‌شود.
   - هوک‌های تزریق به هدر/فوتر و محتوای نوشته فعال می‌شوند.
5. پیام تأیید زیر نمایش داده می‌شود:
   > افزونه SimpleReaction فعال شد. حالا کاربران می‌توانند به نوشته‌ها واکنش نشان دهند.

---

## تنظیمات افزونه

برای پیکربندی افزونه:

1. به مسیر **افزونه‌ها** بروید.
2. روی نام SimpleReaction کلیک کنید (یا روی لینک «تنظیمات» در کنار آن).
3. در فرم تنظیمات، موارد زیر قابل تنظیم هستند:

| فیلد | توضیح | پیش‌فرض |
|---|---|---|
| `enabled` | فعال یا غیرفعال کردن کل سیستم واکنش | `فعال` |
| `active_reactions` | کدام واکنش‌ها در نوشته‌ها نمایش داده شوند | همه (۶ واکنش) |
| `auto_inject` | تزریق خودکار به انتهای محتوای نوشته | `بله` |
| `show_count` | نمایش تعداد واکنش کنار هر دکمه | `نمایش` |
| `show_label` | نمایش برچسب متنی کنار دکمه | `فقط ایموجی` |
| `rate_limit` | حداکثر تعداد درخواست در پنجره‌ی ۶۰ ثانیه‌ای | `30` |
| `single_only` | نمایش فقط در صفحه‌ی تکی یا همه‌جا | `فقط صفحه‌ی تکی` |

4. روی **ذخیره تنظیمات** بزنید.

---

## استفاده در قالب

### روش ۱: تزریق خودکار (پیشنهادی)

اگر «تزریق خودکار» در تنظیمات فعال باشد، واکنش‌ها به‌صورت خودکار در انتهای محتوای هر نوشته نمایش داده می‌شوند. نیازی به تغییری در قالب نیست.

### روش ۲: نمایش دستی

اگر می‌خواهید کنترل دقیق‌تری روی محل نمایش داشته باشید، «تزریق خودکار» را غیرفعال کنید و در قالب (معمولاً `post.php`) این کد را در محل دلخواه قرار دهید:

```php
<?php \TypechoPlugin\SimpleReaction\Renderer::render($this); ?>
```

مثال در `post.php`:
```php
<article class="post-content">
    <?php $this->content(); ?>
</article>

<?php \TypechoPlugin\SimpleReaction\Renderer::render($this); ?>
```

---

## سازگاری با حالت روز/شب

این افزونه به‌صورت **خودکار** با پوسته‌های TypeRenew در حالت روز/شب سازگار است. هیچ پیکربندی اضافی لازم نیست.

### راهبرد CSS

- رنگ‌ها به‌صورت **مستقیم** روی `.sr-container` و اعضای داخلی‌اش با `!important` تنظیم شده‌اند تا هیچ پوسته‌ای نتواند آن‌ها را override کند.
- حالت تیره «فقط» زمانی فعال می‌شود که پوسته‌ی سایت صریحاً آن را اعلام کند. سلکتورهای پشتیبانی‌شده:

1. **`[data-theme='dark'] .sr-container`** — هر دو پوسته‌ی پیش‌فرض TypeRenew (`default` و `Parnian`) در حالت تیره، ویژگی `data-theme` را روی `<html>` تنظیم می‌کنند.
2. **`html[data-theme="dark"] .sr-container`** — همان سلکتور با کوتیشن دوتایی (variant).
3. **`html.tr-theme-dark .sr-container`** — حالت تیره‌ی پیشخوان TypeRenew.
4. **`body.sr-dark .sr-container`** — سفارشی‌سازی دستی برای قالب‌های دلخواه.

> **مهم:** به‌طور عمدی از `@media (prefers-color-scheme: dark)` استفاده **نمی‌شود**. اگر پوسته حالت تیره را اعلام نکند، ویجت همیشه در حالت روشن نمایش داده می‌شود — حتی اگر سیستم‌عامل کاربر تیره باشد. این رفتار از الزامات طراحی است تا حالت تیره هرگز به‌اجبار فعال نشود.

### پالت رنگی

| | پس‌زمینه | متن | حاشیه |
|---|---|---|---|
| **حالت روشن** | `#ffffff` | `#1f2937` | `#e5e7eb` |
| **حالت تیره** | `#1e293b` (آبی-خاکستری تیره، نه سیاه خالص) | `#e2e8f0` | `#334155` |

### سفارشی‌سازی دستی

اگر می‌خواهید حالت را به‌صورت دستی برای کل صفحه تنظیم کنید (بدون توجه به تنظیمات پوسته)، کافی است کلاس زیر را به `<body>` اضافه کنید:

```html
<body class="sr-dark">  <!-- اجبار به حالت تیره -->
```

اگر هیچ کلاسی تنظیم نشود، ویجت از حالت روشن استفاده می‌کند مگر آنکه پوسته `data-theme='dark'` را روی `<html>` تنظیم کند.

### تست حالت تیره

برای تست سریع، می‌توانید در کنسول مرورگر اجرا کنید:

```javascript
document.documentElement.setAttribute('data-theme', 'dark');
```

این کار بلافاصله (بدون رفرش) پلاگین را به حالت تیره می‌برد.

---

## سازگاری با دیتابیس‌ها

این افزونه با سه دیتابیس اصلی TypeRenew سازگار است:

- ✅ **MySQL / Mysqli** (پیش‌فرض TypeRenew) — از `ENGINE=InnoDB` و `utf8mb4_unicode_ci` استفاده می‌کند
- ✅ **PostgreSQL** — از کوتیشن دوتایی (`"`) برای شناسه‌ها استفاده می‌کند
- ✅ **SQLite** — از `AUTOINCREMENT` و `CREATE INDEX IF NOT EXISTS` استفاده می‌کند

تمام کوئری‌های `CREATE TABLE` به‌صورت شرطی برای هر دیتابیس ساخته شده‌اند. شاخص‌ها (indexes) به‌گونه‌ای طراحی شده‌اند که هم `cid` و هم `reaction` سریع باشند.

---

## امنیت

این افزونه چندین لایه‌ی امنیتی دارد:

### ۱. CSRF Protection (Nonce)
هر درخواست AJAX باید یک nonce معتبر ارسال کند. nonce با `hash_hmac('sha256', …)` ساخته می‌شود و با `hash_equals` مقایسه می‌شود (برای جلوگیری از timing attack).

- اکشن رأی‌دهی: `sr_vote`
- اکشن‌های مدیریتی (reset, purge, export): `sr_admin`

### ۲. Rate Limiting
هر بازدیدکننده می‌تواند حداکثر ۳۰ واکنش در پنجره‌ی ۶۰ ثانیه‌ای ثبت کند (قابل تنظیم).

**نکته‌ی مهم:** برخلاف نسخه‌ی قدیمی، این نسخه از `session_start()` استفاده **نمی‌کند** چون TypeRenew session را خودش مدیریت می‌کند و `session_start()` می‌تواند باعث تداخل شود. به‌جای آن از فایل‌های قفل‌گذاری‌شده در دایرکتوری آپلودها استفاده می‌شود.

### ۳. هش IP و Visitor Hash
IP و ترکیب IP+UserAgent به‌صورت هش‌شده با نمک افزونه ذخیره می‌شوند. هیچ IP خام یا User-Agent خام در دیتابیس ذخیره نمی‌شود.

### ۴. Input Validation
- `cid` باید عدد صحیح مثبت باشد.
- `reaction` باید الگوی `^[a-z0-9_]+$` را رعایت کند و در لیست واکنش‌های فعال باشد.

### ۵. Permission Checking
اکشن‌های `reset`، `purge` و `export` فقط برای مدیر (`administrator`) در دسترس هستند. هر کدام nonce جداگانه‌ای با اکشن `sr_admin` نیاز دارند.

### ۶. Security Headers
تمام پاسخ‌های AJAX هدرهای امنیتی زیر را دارند:
- `X-Content-Type-Options: nosniff`
- `X-Frame-Options: DENY`
- `X-Robots-Tag: noindex, nofollow`
- `Cache-Control: no-store, no-cache, must-revalidate`
- `Referrer-Policy: same-origin`

### ۷. Output Escaping
تمام خروجی‌های HTML با `htmlspecialchars(…, ENT_QUOTES | ENT_HTML5, 'UTF-8')` escape می‌شوند تا از XSS جلوگیری شود.

### ۸. SQL Injection
تمام کوئری‌های دیتابیس از PreparedStatement (مثل `where('cid = ?', $cid)`) استفاده می‌کنند — هیچ رشته‌ای به‌صورت دستی در SQL قرار نمی‌گیرد.

---

## API اکشن‌ها

مسیر پایه: `/action/simpleReaction`

### ۱. ثبت رأی (`POST ?do=vote`)

**پارامترها:**
- `cid` (int) — شناسه‌ی نوشته
- `reaction` (string) — کلید واکنش (مثلاً `heart`)
- `sr_nonce` (string) — nonce با اکشن `sr_vote`

**پاسخ:**
```json
{
    "success": true,
    "message": "Your reaction has been recorded.",
    "code": 200,
    "stats": { "heart": 5, "thumbsup": 3 },
    "ts": 1234567890
}
```

اگر کاربر قبلاً واکنش داده باشد، رأی قبلی حذف می‌شود (toggle). اگر واکنش دیگری داده باشد، تغییر می‌کند.

### ۲. دریافت آمار (`GET ?do=stats&cid=123`)

**پاسخ:**
```json
{
    "success": true,
    "stats": {
        "cid": 123,
        "stats": { "heart": 5, "thumbsup": 3 },
        "user_reaction": "heart",
        "total": 8,
        "top_reaction": "heart"
    }
}
```

### ۳. بازنشانی آمار (`POST ?do=reset`) — فقط مدیر

**پارامترها:**
- `sr_nonce` (string) — nonce با اکشن `sr_admin`

آمار شمارنده‌ها را به صفر می‌برد ولی رکوردهای رأی را نگه می‌دارد.

### ۴. حذف کامل (`POST ?do=purge`) — فقط مدیر

**پارامترها:**
- `sr_nonce` (string) — nonce با اکشن `sr_admin`
- `confirm` (string) — باید دقیقاً `PURGE_ALL_YES` باشد

تمام رکوردهای رأی و آمار را حذف می‌کند.

### ۵. خروجی CSV (`GET ?do=export`) — فقط مدیر

یک فایل CSV با ستون‌های `cid, reaction, count, created, updated` دانلود می‌کند.

---

## سفارشی‌سازی رنگ

از نسخه‌ی 1.0.3 رنگ‌ها به‌صورت مستقیم با `!important` روی `.sr-container` و اعضای داخلی‌اش تنظیم می‌شوند (نه با متغیرهای CSS روی `:root`) تا هیچ پوسته‌ای نتواند آن‌ها را override کند. بنابراین برای سفارشی‌سازی، باید استایل‌های خود را **بعد از** استایل افزونه لود کنید و با انتخاب‌گرهای دقیق‌تر یا `!important` بنویسید:

```html
<style>
/* مثال: تغییر رنگ تأکید در حالت روشن */
.sr-container .sr-btn--active {
    background-color: #ea580c !important;
    border-color: #ea580c !important;
}
.sr-container .sr-btn:hover {
    border-color: #ea580c !important;
    background-color: rgba(234, 88, 12, .12) !important;
}
</style>
```

برای حالت تیره‌ی سفارشی:
```html
<style>
html[data-theme='dark'] .sr-container {
    background-color: #0f172a !important;
    color: #e6edf3 !important;
    border-color: #1e293b !important;
}
</style>
```

---

## عیب‌یابی

### پلاگین فعال است ولی واکنش‌ها نمایش داده نمی‌شوند
- بررسی کنید که `enabled` روی `1` تنظیم شده باشد.
- اگر `single_only` روی `1` است، مطمئن شوید در صفحه‌ی تکی نوشته هستید (نه صفحه‌ی اصلی).
- اگر `auto_inject` روی `0` است، باید به‌صورت دستی `Renderer::render($this)` را در قالب قرار دهید.
- اگر هیچ‌کدام کار نکرد، کنسول مرورگر را باز کنید — پیام خطا در `console.error` دیده می‌شود.

### خطای «Invalid security token»
این یعنی nonce ارسالی نامعتبر است. دلایل احتمالی:
- کاربر مدت زیادی در صفحه بوده و nonce منقضی شده — رفرش صفحه.
- نمک افزونه تغییر کرده — یک‌بار افزونه را غیرفعال و فعال کنید.

### خطای «Too many requests» (۴۲۹)
- Rate limit فعال است. ۶۰ ثانیه صبر کنید یا `rate_limit` را در تنظیمات افزایش دهید.
- اگر فایل `.sr_cache` در دایرکتوری آپلودها قابل نوشتن نیست، rate limit خود را غیرفعال می‌کند. مطمئن شوید دایرکتوری آپلودها (`usr/uploads/`) قابل نوشتن است.

### حالت تیره درست نمایش داده نمی‌شود
- مطمئن شوید پوسته‌ی شما از `data-theme='dark'` روی `<html>` استفاده می‌کند (مثل پوسته‌های پیش‌فرض TypeRenew). اگر پوسته‌ی شما روش دیگری دارد، می‌توانید کلاس `sr-dark` را به `<body>` اضافه کنید.
- توجه: حالت تیره‌ی سیستم‌عامل (`prefers-color-scheme`) به‌طور عمدی پشتیبانی نمی‌شود تا با پوسته‌های فاقد حالت تیره تداخل نکند.

### جداول دیتابیس ساخته نشدند
اگر هنگام فعال‌سازی خطایی دیدید:
1. افزونه را غیرفعال کنید.
2. مجدداً فعال کنید.
3. اگر باز هم خطا داشت، دستی این SQL را اجرا کنید (در phpMyAdmin) — برای MySQL:
   ```sql
   CREATE TABLE IF NOT EXISTS `typecho_simple_reaction_stats` (
       `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
       `cid` INT UNSIGNED NOT NULL DEFAULT 0,
       `reaction` VARCHAR(32) NOT NULL DEFAULT '',
       `count` INT UNSIGNED NOT NULL DEFAULT 0,
       `created` INT UNSIGNED NOT NULL DEFAULT 0,
       `updated` INT UNSIGNED NOT NULL DEFAULT 0,
       PRIMARY KEY (`id`),
       UNIQUE KEY `uk_cid_reaction` (`cid`, `reaction`)
   ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
   ```

### خطای «session_start» در error_log
این خطا در نسخه‌ی TypeRenew رخ نمی‌دهد، چون این نسخه از session استفاده نمی‌کند. اگر این خطا را می‌بینید، احتمالاً نسخه‌ی قدیمی پلاگین را نصب کرده‌اید — حتماً فایل‌های جدید را جایگزین کنید.

---

## ساختار فایل‌ها

```
SimpleReaction/
├── Plugin.php        ← نقطه‌ی ورود، فعال/غیرفعال‌سازی، فرم پیکربندی، توابع امنیتی
├── Action.php        ← کنترلر AJAX (vote/stats/reset/purge/export)
├── Renderer.php      ← رندر HTML ویجت واکنش‌ها + تزریق خودکار به محتوا
├── Assets.php        ← تزریق CSS/JS به هدر + داده‌ی پیکربندی به فوتر
├── Migration.php     ← ساخت و حذف جداول (MySQL/Pgsql/SQLite)
├── Text.php          ← توابع کمکی escape و قالب‌بندی عدد
├── README.md         ← همین فایل
├── languages/
│   ├── en_US.php     ← ترجمه‌ی انگلیسی
│   └── fa_IR.php     ← ترجمه‌ی فارسی
└── assets/
    ├── style.css     ← استایل فرانت‌اند (با حالت روز/شب خودکار)
    └── app.js        ← منطق فرانت‌اند (Vanilla JS, Fetch API)
```

### Hook های استفاده‌شده

| Hook | نوع | کاربرد |
|---|---|---|
| `Widget\Archive::header` | call | تزریق CSS و JS به هدر |
| `Widget\Archive::footer` | call | تزریق داده‌ی پیکربندی به فوتر |
| `Widget\Base\Contents::contentEx` | filter | تزریق خودکار ویجت واکنش به انتهای محتوا |

### متد تعریف‌شده برای استفاده در قالب

```php
\TypechoPlugin\SimpleReaction\Renderer::render($this);
```

این متد HTML ویجت واکنش‌ها را برای مطلب جاری چاپ می‌کند.

---

## حمایت

اگر این افزونه برای شما مفید بود، می‌توانید از طریق وب‌سایت <https://pourdaryaei.ir> با من در تماس باشید. بازخورد و پیشنهاداتتان را با کمال میل دریافت می‌کنم.
