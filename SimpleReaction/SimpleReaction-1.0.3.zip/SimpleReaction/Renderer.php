<?php
declare(strict_types=1);

namespace TypechoPlugin\SimpleReaction;

use Typecho\Db;
use Widget\Base\Contents;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * رندر ویجت واکنش‌ها و تزریق خودکار به محتوا.
 */
class Renderer
{
    /** جلوگیری از بازگشت بی‌نهایت در autoRender */
    private static bool $inAutoRender = false;

    /**
     * تزریق خودکار به انتهای محتوای نوشته.
     *
     * @param string|null $content
     * @param Contents|null $widget
     * @return string|null
     */
    public static function autoRender($content, $widget = null)
    {
        if (self::$inAutoRender) {
            return $content;
        }

        try {
            $config = Plugin::getConfig();
            if (!$config || empty($config->enabled)) {
                return $content;
            }
            if (empty($config->auto_inject)) {
                return $content;
            }
            if (!Assets::shouldDisplay($widget)) {
                return $content;
            }

            self::$inAutoRender = true;
            $html = self::renderHtml($widget);
            self::$inAutoRender = false;

            return $content . "\n" . $html;
        } catch (\Throwable $e) {
            self::$inAutoRender = false;
            return $content;
        }
    }

    /**
     * رندر ویجت واکنش برای فراخوانی دستی در قالب.
     *
     * استفاده در قالب:
     *     <?php \TypechoPlugin\SimpleReaction\Renderer::render($this); ?>
     *
     * @param mixed $widget
     * @return void
     */
    public static function render($widget): void
    {
        try {
            $config = Plugin::getConfig();
            if (!$config || empty($config->enabled)) {
                return;
            }
            if (!Assets::shouldDisplay($widget)) {
                return;
            }
            echo self::renderHtml($widget);
        } catch (\Throwable $e) {
            // بی‌صدا
        }
    }

    /**
     * ساخت HTML کامل ویجت واکنش‌ها.
     *
     * @param mixed $widget
     * @return string
     */
    public static function renderHtml($widget): string
    {
        $cid = 0;
        if (is_object($widget) && isset($widget->cid)) {
            $cid = (int) $widget->cid;
        }
        if ($cid <= 0) {
            return '';
        }

        $config    = Plugin::getConfig();
        $active    = Plugin::getActiveReactions();
        $showCount = !empty($config->show_count);
        $showLabel = !empty($config->show_label);

        $stats = self::getStatsForCid($cid);
        $userReaction = self::getUserReaction($cid);

        $buttons = [];
        foreach ($active as $key) {
            $meta   = Plugin::$defaultReactions[$key] ?? ['emoji' => '?', 'label' => $key];
            $count  = $stats[$key] ?? 0;
            $cls    = 'sr-btn';
            $cls   .= ($userReaction === $key) ? ' sr-btn--active' : '';

            $emoji  = Text::e($meta['emoji']);
            $label  = Text::e(Plugin::tr($meta['label']));
            $keyE   = Text::attr($key);

            $badges = '';
            if ($showCount) {
                $badges = '<span class="sr-count" data-count="' . (int) $count . '">' . Text::num($count) . '</span>';
            }
            $labels = '';
            if ($showLabel) {
                $labels = '<span class="sr-label">' . $label . '</span>';
            }

            $buttons[] = '<button type="button" class="' . Text::e($cls) . '" data-reaction="' . $keyE . '"'
                . ' aria-pressed="' . ($userReaction === $key ? 'true' : 'false') . '"'
                . ' aria-label="' . $label . '"'
                . ' title="' . $label . '">'
                . '<span class="sr-emoji" aria-hidden="true">' . $emoji . '</span>'
                . $labels
                . $badges
                . '</button>';
        }

        $wrap = '<div class="sr-container"'
            . ' data-cid="' . (int) $cid . '"'
            . ' data-nonce="' . Text::attr(Plugin::createNonce('sr_vote')) . '"'
            . ' role="group" aria-label="' . Text::attr(Plugin::tr('React to this post')) . '">'
            . '<div class="sr-header"><span class="sr-title">' . Text::e(Plugin::tr('React to this post')) . '</span></div>'
            . '<div class="sr-buttons">' . implode('', $buttons) . '</div>'
            . '<div class="sr-status" role="status" aria-live="polite"></div>'
            . '<div class="sr-summary" aria-live="polite">'
            . '<span class="sr-total"><strong>' . Plugin::tr('Total:') . '</strong> <span class="sr-total-value">0</span></span>'
            . '<span class="sr-top"><strong>' . Plugin::tr('Most Popular:') . '</strong> <span class="sr-top-value">—</span></span>'
            . '</div>'
            . '</div>';

        return $wrap;
    }

    /**
     * دریافت آمار واکنش‌ها برای یک نوشته.
     *
     * @param int $cid
     * @return array<string,int>
     */
    public static function getStatsForCid(int $cid): array
    {
        if ($cid <= 0) {
            return [];
        }
        try {
            $db = Db::get();
            $rows = $db->fetchAll(
                $db->select('reaction', 'count')->from('table.' . Plugin::STATS_TABLE)
                    ->where('cid = ?', $cid)
            );
            $out = [];
            foreach ($rows as $row) {
                $out[(string) $row['reaction']] = (int) $row['count'];
            }
            return $out;
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * دریافت واکنش فعلی کاربر برای یک نوشته.
     *
     * @param int $cid
     * @return string|null
     */
    public static function getUserReaction(int $cid): ?string
    {
        if ($cid <= 0) {
            return null;
        }
        try {
            $db = Db::get();
            $uid = Plugin::currentUserId();
            $vhash = $uid ? '' : Plugin::visitorHash();

            $select = $db->select('reaction')->from('table.' . Plugin::VOTES_TABLE)
                ->where('cid = ?', $cid);

            if ($uid > 0) {
                $select->where('user_id = ?', $uid);
            } else {
                $select->where('visitor_hash = ?', $vhash)
                    ->where('user_id = 0');
            }
            $select->limit(1);

            $row = $db->fetchRow($select);
            return $row ? (string) $row['reaction'] : null;
        } catch (\Throwable $e) {
            return null;
        }
    }
}
