<?php
declare(strict_types=1);

namespace TypechoPlugin\SimpleReaction;

use Typecho\Plugin as Hook;
use Typecho\Plugin\PluginInterface;
use Typecho\Widget\Helper\Form;
use Utils\Helper;
use Utils\NoPersonal;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * سیستم واکنش سبک برای مطالب TypeRenew با پشتیبانی آجاکسی.
 *
 * @package SimpleReaction
 * @author  پوردریایی
 * @link    https://pourdaryaei.ir
 * @version 1.0.3
 * @license GPL-2.0-or-later
 */
class Plugin implements PluginInterface
{
    use NoPersonal;

    /** نسخه‌ی فعلی افزونه */
    public const VERSION = '1.0.3';

    /** شناسه‌ی افزونه */
    public const NAME = 'SimpleReaction';

    /** نام مسیر اکشن (camelCase برای سازگاری با TypeRenew) */
    public const ROUTE_NAME = 'simpleReaction';

    /** نام جدول آمار واکنش‌ها */
    public const STATS_TABLE = 'simple_reaction_stats';

    /** نام جدول آراء */
    public const VOTES_TABLE = 'simple_reaction_votes';

    /** تعداد پیش‌فرض درخواست در پنجره‌ی زمانی Rate limit */
    public const RATE_LIMIT_COUNT = 30;

    /** طول پنجره‌ی زمانی Rate limit به ثانیه */
    public const RATE_LIMIT_WINDOW = 60;

    /** طول نمک هش (به بایت) */
    public const SALT_BYTES = 24;

    /**
     * واکنش‌های پیش‌فرض
     *
     * @var array<string,array{emoji:string,label:string}>
     */
    public static array $defaultReactions = [
        'heart'    => ['emoji' => '❤️', 'label' => 'Loved it'],
        'thumbsup' => ['emoji' => '👍', 'label' => 'Useful'],
        'fire'     => ['emoji' => '🔥', 'label' => 'Awesome'],
        'laugh'    => ['emoji' => '😂', 'label' => 'Funny'],
        'sad'      => ['emoji' => '😢', 'label' => 'Sad'],
        'angry'    => ['emoji' => '😡', 'label' => 'Disagree'],
    ];

    /* ============================================================
     *                    PLUGIN LIFECYCLE
     * ============================================================ */

    /**
     * فعال‌سازی افزونه.
     *
     * @return string
     * @throws \Throwable
     */
    public static function activate(): string
    {
        // ۱. اطمینان از وجود جداول
        Migration::ensure();

        // ۲. ثبت مسیر اکشن
        Helper::removeAction(self::ROUTE_NAME);
        Helper::addAction(self::ROUTE_NAME, Action::class);

        // ۳. تزریق CSS/JS به هدر سایت و داده‌ی پیکربندی به فوتر
        Hook::factory('Widget\Archive')->header = [Assets::class, 'injectHeader'];
        Hook::factory('Widget\Archive')->footer = [Assets::class, 'injectFooter'];

        // ۴. تزریق خودکار واکنش‌ها به انتهای محتوای نوشته‌ها
        Hook::factory('Widget\Base\Contents')->contentEx = [Renderer::class, 'autoRender'];

        return _t('افزونه SimpleReaction فعال شد. حالا کاربران می‌توانند به نوشته‌ها واکنش نشان دهند.');
    }

    /**
     * غیرفعال‌سازی افزونه.
     *
     * @return string
     */
    public static function deactivate(): string
    {
        Helper::removeAction(self::ROUTE_NAME);
        return _t('افزونه SimpleReaction غیرفعال شد. جداول دیتابیس و آمار حفظ شدند.');
    }

    /**
     * فرم پیکربندی افزونه.
     *
     * @param Form $form
     */
    public static function config(Form $form): void
    {
        $enabled = new Form\Element\Radio(
            'enabled',
            ['1' => _t('فعال'), '0' => _t('غیرفعال')],
            '1',
            _t('وضعیت افزونه'),
            _t('در حالت غیرفعال، هیچ واکنشی ثبت یا نمایش داده نمی‌شود.')
        );
        $form->addInput($enabled);

        $options = [];
        foreach (self::$defaultReactions as $key => $meta) {
            $options[$key] = $meta['emoji'] . ' ' . Text::e(self::tr($meta['label']));
        }
        $activeReactions = new Form\Element\Checkbox(
            'active_reactions',
            $options,
            array_keys($options),
            _t('واکنش‌های فعال'),
            _t('انتخاب کنید کدام واکنش‌ها در نوشته‌ها نمایش داده شوند.')
        );
        $form->addInput($activeReactions);

        $autoInject = new Form\Element\Radio(
            'auto_inject',
            ['1' => _t('بله (تزریق خودکار)'), '0' => _t('خیر، فقط دستی')],
            '1',
            _t('تزریق خودکار'),
            _t('اگر فعال باشد، واکنش‌ها در انتهای هر نوشته نمایش داده می‌شوند.')
        );
        $form->addInput($autoInject);

        $showCount = new Form\Element\Radio(
            'show_count',
            ['1' => _t('نمایش'), '0' => _t('مخفی')],
            '1',
            _t('نمایش شمارنده'),
            _t('آیا تعداد هر واکنش کنار دکمه نمایش داده شود؟')
        );
        $form->addInput($showCount);

        $showLabel = new Form\Element\Radio(
            'show_label',
            ['1' => _t('نمایش'), '0' => _t('فقط ایموجی')],
            '0',
            _t('نمایش برچسب متنی'),
            _t('آیا برچسب متنی کنار دکمه نمایش داده شود؟')
        );
        $form->addInput($showLabel);

        $rateLimit = new Form\Element\Text(
            'rate_limit',
            null,
            (string) self::RATE_LIMIT_COUNT,
            _t('حد نرخ درخواست'),
            _t('حداکثر تعداد واکنش‌های مجاز برای هر بازدیدکننده در پنجره‌ی ۶۰ ثانیه‌ای.')
        );
        $rateLimit->addRule('required', _t('این فیلد الزامی است.'));
        $rateLimit->addRule('isInteger', _t('باید عدد صحیح باشد.'));
        $form->addInput($rateLimit);

        $singleOnly = new Form\Element\Radio(
            'single_only',
            ['1' => _t('فقط صفحه‌ی تکی'), '0' => _t('همه‌جا')],
            '1',
            _t('محدودیت نمایش'),
            _t('آیا واکنش‌ها فقط در صفحه‌ی تکی نوشته نمایش داده شوند؟')
        );
        $form->addInput($singleOnly);
    }

    /* ============================================================
     *                   TRANSLATION
     * ============================================================ */

    /** @var array<string,string>|null */
    private static ?array $translations = null;

    /** @var string|null کش زبان تشخیص‌داده‌شده */
    private static ?string $langCache = null;

    /**
     * تشخیص زبان جاری سایت.
     *
     * اولویت‌ها:
     *   ۱. ثابت `__TYPECHO_LANG__` (تعریف‌شده در config.inc.php)
     *   ۲. `{$options->lang}` (تنظیم TypeRenew)
     *   ۳. `{$options->language}`
     *   ۴. تشخیص از روی بسته‌ی زبان نصب‌شده (`usr/langs/fa_IR.mo` یا `en_US.mo`)
     *   ۵. پیش‌فرض: `fa_IR` (TypeRenew عمدتاً فارسی‌زبان است)
     *
     * @return string
     */
    public static function getLanguage(): string
    {
        if (self::$langCache !== null) {
            return self::$langCache;
        }

        $candidates = [];

        // ۱. ثابت تعریف‌شده توسط کاربر — بالاترین اولویت
        if (defined('__TYPECHO_LANG__') && (string) __TYPECHO_LANG__ !== '') {
            $candidates[] = (string) __TYPECHO_LANG__;
        }

        // ۲ و ۳. تنظیمات TypeRenew
        try {
            $opts = Helper::options();
            if (!empty($opts->lang)) {
                $candidates[] = (string) $opts->lang;
            }
            if (!empty($opts->language)) {
                $candidates[] = (string) $opts->language;
            }
        } catch (\Throwable $e) {
            // ignore
        }

        // نرمال‌سازی نامزدها (fa → fa_IR و غیره)
        foreach ($candidates as $candidate) {
            $normalized = self::normalizeLang($candidate);
            if ($normalized !== null) {
                self::$langCache = $normalized;
                return $normalized;
            }
        }

        // ۴. تشخیص از روی بسته‌ی زبان نصب‌شده در TypeRenew
        $detected = self::detectInstalledLang();
        if ($detected !== null) {
            self::$langCache = $detected;
            return $detected;
        }

        // ۵. پیش‌فرض — فارسی
        self::$langCache = 'fa_IR';
        return 'fa_IR';
    }

    /**
     * نرمال‌سازی کد زبان به یکی از زبان‌های پشتیبانی‌شده‌ی افزونه.
     * اگر بسته‌ی زبان متناظر در افزونه موجود نباشد، null برمی‌گردد.
     *
     * @param string $lang
     * @return string|null
     */
    private static function normalizeLang(string $lang): ?string
    {
        $lang = strtolower(trim(str_replace('-', '_', $lang)));
        if ($lang === '') {
            return null;
        }

        // کدهای کوتاه رایج → کد کامل
        $map = [
            'fa'    => 'fa_ir',
            'en'    => 'en_us',
            'zh'    => 'zh_cn',
        ];
        if (isset($map[$lang])) {
            $lang = $map[$lang];
        }

        // فقط اگر بسته‌ی زبان متناظر در افزونه موجود باشد استفاده می‌شود
        if (is_file(__DIR__ . '/languages/' . $lang . '.php')) {
            return $lang;
        }

        // مثلاً fa_AF → fa_IR (بسته‌ی پایه‌ی fa)
        $base = explode('_', $lang)[0];
        if (isset($map[$base]) && is_file(__DIR__ . '/languages/' . $map[$base] . '.php')) {
            return $map[$base];
        }

        return null;
    }

    /**
     * تشخیص زبان از روی بسته‌های زبان نصب‌شده‌ی TypeRenew.
     *
     * @return string|null
     */
    private static function detectInstalledLang(): ?string
    {
        $root = defined('__TYPECHO_ROOT_DIR__')
            ? rtrim((string) __TYPECHO_ROOT_DIR__, '/')
            : '';
        if ($root === '') {
            return null;
        }

        if (is_file($root . '/usr/langs/fa_IR.mo')) {
            return 'fa_IR';
        }
        if (is_file($root . '/usr/langs/en_US.mo')) {
            return 'en_US';
        }

        return null;
    }

    /**
     * ترجمه‌ی یک رشته.
     *
     * @param string $text
     * @param mixed  ...$args
     * @return string
     */
    public static function tr(string $text, ...$args): string
    {
        $translations = self::loadTranslations();
        $translated = $translations[$text] ?? $text;
        if (!empty($args)) {
            return sprintf($translated, ...$args);
        }
        return $translated;
    }

    /**
     * بازگرداندن واکنش‌ها با برچسب‌های ترجمه‌شده.
     * این آرایه برای ارسال به JavaScript (allReactions) استفاده می‌شود.
     *
     * @return array<string,array{emoji:string,label:string}>
     */
    public static function translatedReactions(): array
    {
        $out = [];
        foreach (self::$defaultReactions as $key => $meta) {
            $out[$key] = [
                'emoji' => $meta['emoji'],
                'label' => self::tr($meta['label']),
            ];
        }
        return $out;
    }

    /**
     * بارگذاری فایل ترجمه‌ی زبان جاری.
     *
     * @return array<string,string>
     */
    private static function loadTranslations(): array
    {
        if (self::$translations !== null) {
            return self::$translations;
        }

        $lang = self::getLanguage();

        $file = __DIR__ . '/languages/' . $lang . '.php';
        $loaded = [];
        if (is_file($file)) {
            try {
                $arr = include $file;
                if (is_array($arr)) {
                    $loaded = $arr;
                }
            } catch (\Throwable $e) {
                $loaded = [];
            }
        }
        self::$translations = $loaded;
        return $loaded;
    }

    /* ============================================================
     *                   SECURITY HELPERS
     * ============================================================ */

    /** @var string|null نمک هش کش‌شده */
    private static ?string $saltCache = null;

    /**
     * دریافت نمک امنیتی افزونه.
     *
     * اولویت‌ها:
     *   ۱. کش ران‌تایست (سریع‌ترین)
     *   ۲. `$options->secret` از پیکربندی TypeRenew (پیش‌فرض TypeRenew)
     *   ۳. نمک ذخیره‌شده در پیکربندی افزونه (`sr_salt`)
     *   ۴. ساخت نمک تصادفی جدید و ذخیره‌ی آن
     *
     * @return string
     */
    public static function salt(): string
    {
        if (self::$saltCache !== null) {
            return self::$saltCache;
        }

        // ۱. constant تعریف‌شده توسط کاربر
        if (defined('__TYPECHO_SECURITY_KEY__') && __TYPECHO_SECURITY_KEY__ !== '') {
            self::$saltCache = (string) __TYPECHO_SECURITY_KEY__;
            return self::$saltCache;
        }

        // ۲. secret از پیکربندی TypeRenew
        try {
            $secret = Helper::options()->secret ?? '';
            if (is_string($secret) && $secret !== '') {
                self::$saltCache = $secret;
                return $secret;
            }
        } catch (\Throwable $e) {
            // ignore
        }

        // ۳. نمک ذخیره‌شده در پیکربندی افزونه
        try {
            $config = Helper::options()->plugin(self::NAME);
            $stored = $config->sr_salt ?? null;
            if (is_string($stored) && $stored !== '') {
                self::$saltCache = $stored;
                return $stored;
            }
        } catch (\Throwable $e) {
            // ignore
        }

        // ۴. ساخت نمک جدید
        $new = bin2hex(random_bytes(self::SALT_BYTES));
        try {
            \Widget\Plugins\Edit::configPlugin(self::NAME, ['sr_salt' => $new]);
        } catch (\Throwable $e) {
            // اگر ذخیره نشد، فقط برای این ریکوئست استفاده می‌شود
        }
        self::$saltCache = $new;
        return $new;
    }

    /**
     * ساخت یک nonce برای اکشن مشخص.
     *
     * @param string $action
     * @return string
     */
    public static function createNonce(string $action): string
    {
        $salt = self::salt();
        $uid = self::currentUserId();
        $token = $salt . '|' . $action . '|' . $uid;
        return hash_hmac('sha256', $token, $salt);
    }

    /**
     * اعتبارسنجی nonce.
     *
     * @param string $nonce
     * @param string $action
     * @return bool
     */
    public static function verifyNonce(string $nonce, string $action): bool
    {
        if ($nonce === '' || !ctype_xdigit($nonce) || strlen($nonce) !== 64) {
            return false;
        }
        return hash_equals(self::createNonce($action), $nonce);
    }

    /**
     * شناسه‌ی کاربر جاری (۰ برای مهمان).
     *
     * @return int
     */
    public static function currentUserId(): int
    {
        try {
            $user = \Widget\User::alloc();
            return $user->hasLogin() ? (int) $user->uid : 0;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /**
     * هش بازدیدکننده: sha1(IP + UserAgent + Salt).
     * در نسخه‌ی TypeRenew از نمک افزونه برای پایداری استفاده می‌شود.
     *
     * @return string
     */
    public static function visitorHash(): string
    {
        $ip = self::clientIp();
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $salt = self::salt();
        return hash_hmac('sha1', $ip . '|' . $ua, $salt);
    }

    /**
     * هش IP برای حفظ حریم خصوصی.
     *
     * @return string
     */
    public static function ipHash(): string
    {
        $ip = self::clientIp();
        $salt = self::salt();
        return hash_hmac('sha256', $ip, $salt);
    }

    /**
     * دریافت IP کاربر با پشتیبانی از پراکسی‌های رایج.
     * فقط در صورتی که درخواست از یک پراکسی معتبر (Trusted Proxy) باشد، هدر X-Forwarded-For استفاده می‌شود.
     *
     * @return string
     */
    public static function clientIp(): string
    {
        // REMOTE_ADDR همیشه اولویت دارد چون توسط سرور تنظیم می‌شود.
        $remote = $_SERVER['REMOTE_ADDR'] ?? '';
        if (filter_var($remote, FILTER_VALIDATE_IP) && $remote !== '127.0.0.1' && $remote !== '::1') {
            return $remote;
        }

        // اگر در محیط محلی هستیم، پراکسی‌ها را بررسی می‌کنیم.
        $candidates = [
            'HTTP_CF_CONNECTING_IP',
            'HTTP_X_REAL_IP',
            'HTTP_X_FORWARDED_FOR',
        ];
        foreach ($candidates as $key) {
            if (!empty($_SERVER[$key])) {
                // در X-Forwarded-For ممکن است چند IP باشد؛ اولی معتبرترین است.
                $value = trim(explode(',', (string) $_SERVER[$key])[0]);
                if (filter_var($value, FILTER_VALIDATE_IP)) {
                    return $value;
                }
            }
        }
        return $remote ?: '0.0.0.0';
    }

    /**
     * اعتبارسنجی کلید واکنش.
     *
     * @param string $key
     * @return bool
     */
    public static function isValidReaction(string $key): bool
    {
        if ($key === '' || strlen($key) > 32) {
            return false;
        }
        if (!preg_match('/^[a-z0-9_]+$/', $key)) {
            return false;
        }
        return array_key_exists($key, self::$defaultReactions);
    }

    /**
     * دریافت پیکربندی افزونه.
     *
     * @return \Typecho\Config|null
     */
    public static function getConfig(): ?\Typecho\Config
    {
        try {
            return Helper::options()->plugin(self::NAME);
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * دریافت واکنش‌های فعال از پیکربندی.
     *
     * @return array<int,string>
     */
    public static function getActiveReactions(): array
    {
        $config = self::getConfig();
        if (!$config) {
            return array_keys(self::$defaultReactions);
        }
        $active = $config->active_reactions;
        if (empty($active)) {
            return array_keys(self::$defaultReactions);
        }
        $active = is_array($active) ? $active : [$active];
        $valid = [];
        foreach ($active as $key) {
            $key = (string) $key;
            if (self::isValidReaction($key)) {
                $valid[] = $key;
            }
        }
        return $valid;
    }
}
