/**
 * SimpleReaction — Front-end Application (TypeRenew)
 *
 * @package SimpleReaction
 */
(function () {
    'use strict';

    if (window.SimpleReactionBooted) return;
    window.SimpleReactionBooted = true;

    var CFG = window.SimpleReactionConfig || null;
    if (!CFG) return;

    // ----- Debug info -----
    if (CFG.version) {
        console.log('[SimpleReaction] v' + CFG.version + ' | lang=' + (CFG.lang || '?'));
    }

    // ----- State Management -----
    var state = {
        cid: 0,
        nonce: '',
        loading: false,
        userReaction: null,
        stats: {},
        total: 0,
        top: null
    };

    // ----- Helpers -----
    function $(sel, root) {
        return (root || document).querySelector(sel);
    }
    function $all(sel, root) {
        return Array.prototype.slice.call((root || document).querySelectorAll(sel));
    }

    function statusMessage(node, text, type) {
        if (!node) return;
        node.textContent = text || '';
        node.setAttribute('data-state', type || '');
        clearTimeout(node._srT);
        node._srT = setTimeout(function () {
            node.textContent = '';
            node.removeAttribute('data-state');
        }, 3000);
    }

    // ----- API client -----
    function apiCall(action, method, formData) {
        if (!CFG || !CFG.endpoint) {
            return Promise.reject(new Error('no config'));
        }
        var url = CFG.endpoint + '?do=' + encodeURIComponent(action);
        var opts = {
            method: method,
            credentials: 'same-origin',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        };
        if (method === 'POST' && formData) {
            opts.body = formData;
        }
        return fetch(url, opts).then(function (r) {
            return r.text().then(function (text) {
                var ct = r.headers.get('content-type') || '';
                if (ct.indexOf('application/json') === -1) {
                    throw new Error('Non-JSON response (status ' + r.status + ')');
                }
                var j;
                try {
                    j = JSON.parse(text);
                } catch (e) {
                    throw new Error('Invalid JSON from server');
                }
                j._status = r.status;
                return j;
            });
        });
    }

    // ----- Core: Vote -----
    function vote(container, button) {
        if (state.loading) return;
        if (!state.cid) return;

        var reaction = button.getAttribute('data-reaction');
        if (!reaction) return;

        // اعتبارسنجی client-side برای اضافه‌کردن لایه‌ی امنیتی
        if (!CFG.activeReactions || CFG.activeReactions.indexOf(reaction) === -1) {
            var status = $('.sr-status', container);
            statusMessage(status, (CFG.i18n && CFG.i18n.error) || 'error', 'error');
            return;
        }

        state.loading = true;
        container.setAttribute('data-loading', '1');
        button.setAttribute('aria-busy', 'true');
        button.classList.add('sr-btn--loading');

        var fd = new FormData();
        fd.append('do', 'vote');
        fd.append('cid', String(state.cid));
        fd.append('reaction', reaction);
        fd.append('sr_nonce', state.nonce);

        apiCall('vote', 'POST', fd)
            .then(function (j) {
                if (j && j.success) {
                    var statsData = j.stats || {};
                    if (statsData && typeof statsData === 'object' && statsData.stats && typeof statsData.stats === 'object') {
                        statsData = statsData.stats;
                    }
                    state.stats = statsData;

                    if (j.stats && j.stats.user_reaction) {
                        state.userReaction = j.stats.user_reaction;
                    } else if (j.userReaction) {
                        state.userReaction = j.userReaction;
                    } else {
                        if (j.message && j.message.indexOf('removed') >= 0) {
                            state.userReaction = null;
                        } else {
                            state.userReaction = reaction;
                        }
                    }

                    refreshUI(container, statsData);
                    var status2 = $('.sr-status', container);
                    statusMessage(status2, j.message || ((CFG.i18n && CFG.i18n.success) || ''), 'success');
                    animatePop(button);
                } else {
                    var status3 = $('.sr-status', container);
                    var code = j && j.code ? j.code : 0;
                    if (code === 429) {
                        statusMessage(status3, (CFG.i18n && CFG.i18n.rateLimited) || (j && j.message), 'warn');
                    } else {
                        statusMessage(status3, (j && j.message) || (CFG.i18n && CFG.i18n.error) || 'error', 'error');
                    }
                    if (code === 403) {
                        setTimeout(function () { window.location.reload(); }, 1200);
                    }
                }
            })
            .catch(function () {
                var status4 = $('.sr-status', container);
                statusMessage(status4, (CFG.i18n && CFG.i18n.error) || 'error', 'error');
            })
            .then(function () {
                state.loading = false;
                container.removeAttribute('data-loading');
                button.removeAttribute('aria-busy');
                button.classList.remove('sr-btn--loading');
            });
    }

    // ----- Core: Stats -----
    function loadStats(container) {
        if (!state.cid) return;
        var url = CFG.endpoint + '?do=stats&cid=' + encodeURIComponent(state.cid);
        fetch(url, { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (j) {
                if (j.success && j.stats) {
                    state.stats = j.stats.stats || {};
                    state.userReaction = j.stats.user_reaction || null;
                    state.total = j.stats.total || 0;
                    state.top = j.stats.top_reaction || null;
                    refreshUI(container, state.stats);
                }
            })
            .catch(function () {
                // Stats unavailable; UI displays without them
            });
    }

    // ----- UI Refresh -----
    function refreshUI(container, stats) {
        var total = 0;
        var topKey = null, topVal = 0;
        var buttons = $all('.sr-btn', container);
        buttons.forEach(function (btn) {
            var key = btn.getAttribute('data-reaction');
            var c = (stats && stats[key]) || 0;
            total += c;
            if (c > topVal) { topVal = c; topKey = key; }

            var countNode = $('.sr-count', btn);
            if (countNode) {
                countNode.textContent = String(c);
                countNode.setAttribute('data-count', String(c));
            }
            var isActive = (key === state.userReaction);
            btn.classList.toggle('sr-btn--active', isActive);
            btn.setAttribute('aria-pressed', isActive ? 'true' : 'false');
        });

        var totalNode = $('.sr-total-value', container);
        if (totalNode) totalNode.textContent = String(total);

        var topNode = $('.sr-top-value', container);
        if (topNode) {
            if (topKey && CFG.allReactions && CFG.allReactions[topKey] && CFG.allReactions[topKey].label) {
                var meta = CFG.allReactions[topKey];
                topNode.textContent = meta.emoji + ' ' + meta.label;
            } else {
                topNode.textContent = '—';
            }
        }
    }

    // ----- Animation -----
    function animatePop(button) {
        button.classList.remove('sr-btn--pop');
        void button.offsetWidth;
        button.classList.add('sr-btn--pop');
        setTimeout(function () {
            button.classList.remove('sr-btn--pop');
        }, 450);
    }

    // ----- Keyboard accessibility -----
    function onKeydown(e) {
        if (e.key === 'Enter' || e.key === ' ') {
            var t = e.target;
            if (t && t.classList && t.classList.contains('sr-btn')) {
                e.preventDefault();
                t.click();
            }
        }
    }

    // ----- Boot -----
    function boot() {
        var containers = $all('.sr-container');
        if (!containers.length) return;

        containers.forEach(function (container) {
            state.cid = parseInt(container.getAttribute('data-cid'), 10) || 0;
            state.nonce = container.getAttribute('data-nonce') || (CFG && CFG.nonce) || '';

            var activeBtn = $('.sr-btn--active', container);
            state.userReaction = activeBtn ? activeBtn.getAttribute('data-reaction') : null;

            $all('.sr-btn', container).forEach(function (btn) {
                btn.addEventListener('click', function (e) {
                    e.preventDefault();
                    vote(container, btn);
                });
            });

            container.addEventListener('keydown', onKeydown);

            // Lazy-load stats
            if ('IntersectionObserver' in window) {
                var io = new IntersectionObserver(function (entries) {
                    entries.forEach(function (entry) {
                        if (entry.isIntersecting) {
                            loadStats(container);
                            io.unobserve(entry.target);
                        }
                    });
                }, { rootMargin: '200px' });
                io.observe(container);
            } else {
                if (document.readyState === 'complete') {
                    setTimeout(function () { loadStats(container); }, 50);
                } else {
                    window.addEventListener('load', function () {
                        setTimeout(function () { loadStats(container); }, 50);
                    });
                }
            }
        });
    }

    // ----- DOM Ready -----
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
