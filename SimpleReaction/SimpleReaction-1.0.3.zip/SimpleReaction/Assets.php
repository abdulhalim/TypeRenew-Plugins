<?php
declare(strict_types=1);

namespace TypechoPlugin\SimpleReaction;

use Typecho\Common;
use Utils\Helper;
use Widget\Archive;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * تزریق دارایی‌های فرانت‌اند (CSS/JS) و داده‌ی پیکربندی به صفحه.
 */
class Assets
{
    /**
     * تزریق CSS و JS به هدر سایت.
     * در Typecho، هوک header یک call() است نه filter، بنابراین باید مستقیماً echo کنیم.
     *
     * @param string|null      $header_html
     * @param Archive|null     $archive
     * @return void
     */
    public static function injectHeader($header_html = null, $archive = null): void
    {
        try {
            $config = Plugin::getConfig();
            if (!$config || empty($config->enabled)) {
                return;
            }
            if (!self::shouldDisplay($archive)) {
                return;
            }

            $styleUrl = self::assetUrl('assets/style.css');
            $scriptUrl = self::assetUrl('assets/app.js');
            $v = Plugin::VERSION;
            echo '<link rel="stylesheet" href="' . Text::attr($styleUrl) . '?v=' . $v . '" media="all">' . "\n";
            echo '<script defer src="' . Text::attr($scriptUrl) . '?v=' . $v . '"></script>' . "\n";
        } catch (\Throwable $e) {
            // بی‌صدا رد شو
        }
    }

    /**
     * تزریق داده‌ی پیکربندی به فوتر سایت.
     *
     * @param Archive|null $archive
     * @return void
     */
    public static function injectFooter($archive = null): void
    {
        try {
            $config = Plugin::getConfig();
            if (!$config || empty($config->enabled)) {
                return;
            }
            if (!self::shouldDisplay($archive)) {
                return;
            }

            $nonce = Plugin::createNonce('sr_vote');

            $active = Plugin::getActiveReactions();

            $boot = [
                'version'         => Plugin::VERSION,
                'lang'            => Plugin::getLanguage(),
                'endpoint'        => self::endpointUrl(),
                'nonce'           => $nonce,
                'showCount'       => (bool) $config->show_count,
                'showLabel'       => (bool) $config->show_label,
                'activeReactions' => $active,
                'allReactions'    => Plugin::translatedReactions(),
                'csrfKey'         => 'sr_nonce',
                'i18n'            => [
                    'loading'     => Plugin::tr('Loading...'),
                    'error'       => Plugin::tr('An error occurred. Please try again.'),
                    'success'     => Plugin::tr('Your reaction has been recorded.'),
                    'removed'     => Plugin::tr('Your reaction has been removed.'),
                    'switched'    => Plugin::tr('Your reaction has been changed.'),
                    'rateLimited' => Plugin::tr('Too many requests. Please wait a moment.'),
                ],
            ];

            $json = Common::jsonEncode(
                $boot,
                JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT,
                '{}'
            );
            echo '<script>window.SimpleReactionConfig=' . $json . ';</script>' . "\n";
        } catch (\Throwable $e) {
            // بی‌صدا
        }
    }

    /**
     * تعیین اینکه آیا واکنش‌ها باید در صفحه‌ی فعلی نمایش داده شوند.
     *
     * @param mixed $widget
     * @return bool
     */
    public static function shouldDisplay($widget): bool
    {
        $config = Plugin::getConfig();
        if (!$config || empty($config->enabled)) {
            return false;
        }
        if (empty($config->single_only)) {
            return true;
        }

        // فقط در صفحه‌ی تکی
        if (is_object($widget) && method_exists($widget, 'is')) {
            try {
                if ($widget->is('single') || $widget->is('post') || $widget->is('page')) {
                    return true;
                }
            } catch (\Throwable $e) {}
        }

        // fallback: بررسی مستقیم Widget\Archive
        try {
            $archive = Archive::alloc(null, null, false);
            if (method_exists($archive, 'is') && $archive->is('single')) {
                return true;
            }
        } catch (\Throwable $e) {}

        return false;
    }

    /**
     * آدرس نقطه‌ی پایانی اکشن AJAX.
     *
     * @return string
     */
    public static function endpointUrl(): string
    {
        try {
            $opts = Helper::options();
            $index = (string) $opts->index;
            return Common::url('/action/' . Plugin::ROUTE_NAME, $index);
        } catch (\Throwable $e) {
            return '/action/' . Plugin::ROUTE_NAME;
        }
    }

    /**
     * آدرس یک دارایی افزونه.
     *
     * @param string $path
     * @return string
     */
    public static function assetUrl(string $path): string
    {
        $path = ltrim($path, '/');
        try {
            $base = (string) (Helper::options()->pluginUrl ?? '');
            if ($base === '') {
                $siteUrl = rtrim((string) Helper::options()->siteUrl, '/') . '/';
                $base = Common::url('usr/plugins/', $siteUrl);
            }
            return Common::url(Plugin::NAME . '/' . $path, $base);
        } catch (\Throwable $e) {
            return 'usr/plugins/' . Plugin::NAME . '/' . $path;
        }
    }
}
