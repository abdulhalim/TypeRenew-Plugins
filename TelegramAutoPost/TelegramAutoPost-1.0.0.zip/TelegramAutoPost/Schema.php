<?php
declare(strict_types=1);

namespace TypechoPlugin\TelegramAutoPost;

use Typecho\Db;
use Utils\Schema as CoreSchema;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * تعریف و نگهداری جدول گزارش‌های ارسال.
 *
 * از Utils\Schema هسته TypeRenew برای سازگاری با MySQL، PostgreSQL و SQLite استفاده می‌کند.
 */
class Schema
{
    public static function ensure(): void
    {
        $db = Db::get();
        $dialect = CoreSchema::dialect($db);
        $table = $db->getPrefix() . Plugin::LOG_TABLE;

        // 1) Create the table if it doesn't exist (dialect-aware).
        $db->query(self::tableSql($db, $dialect, $table), Db::WRITE);

        // 2) Ensure every expected column exists (handles upgrades from older versions).
        foreach (self::columns($dialect) as $column => $definition) {
            if (!CoreSchema::columnExists($db, $table, $column)) {
                try {
                    $db->query(
                        'ALTER TABLE ' . CoreSchema::quote($table, $dialect)
                        . ' ADD COLUMN ' . $definition,
                        Db::WRITE
                    );
                } catch (\Throwable $e) {
                    // Column may already exist (race) — ignore.
                }
            }
        }

        // 3) Ensure indexes exist.
        $name = static fn(string $mysql, string $other): string =>
            $dialect === 'mysql' ? $mysql : $table . '_' . $other;

        CoreSchema::ensureIndex($db, $table, $name('idx_cid', 'cid'), ['cid']);
        CoreSchema::ensureIndex($db, $table, $name('idx_status', 'status'), ['status']);
        CoreSchema::ensureIndex($db, $table, $name('idx_created', 'created'), ['created_at']);
        CoreSchema::ensureIndex($db, $table, $name('idx_payload', 'payload'), ['payload_hash']);
    }

    private static function tableSql(Db $db, string $dialect, string $table): string
    {
        $name = CoreSchema::quote($table, $dialect);

        switch ($dialect) {
            case 'sqlite':
                return 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                    . '"id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,'
                    . '"cid" INTEGER NOT NULL DEFAULT 0,'
                    . '"chat_id" TEXT NOT NULL DEFAULT \'\','
                    . '"reason" TEXT NOT NULL DEFAULT \'\','
                    . '"status" TEXT NOT NULL DEFAULT \'\','
                    . '"message_id" INTEGER NOT NULL DEFAULT 0,'
                    . '"error" TEXT NOT NULL DEFAULT \'\','
                    . '"payload_hash" TEXT NOT NULL DEFAULT \'\','
                    . '"created_at" INTEGER NOT NULL DEFAULT 0'
                    . ')';

            case 'pgsql':
                return 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                    . '"id" BIGSERIAL PRIMARY KEY,'
                    . '"cid" INTEGER NOT NULL DEFAULT 0,'
                    . '"chat_id" VARCHAR(128) NOT NULL DEFAULT \'\','
                    . '"reason" VARCHAR(32) NOT NULL DEFAULT \'\','
                    . '"status" VARCHAR(16) NOT NULL DEFAULT \'\','
                    . '"message_id" BIGINT NOT NULL DEFAULT 0,'
                    . '"error" VARCHAR(255) NOT NULL DEFAULT \'\','
                    . '"payload_hash" CHAR(32) NOT NULL DEFAULT \'\','
                    . '"created_at" INTEGER NOT NULL DEFAULT 0'
                    . ')';

            default: // mysql
                $collation = '';
                try {
                    $collation = CoreSchema::detectMysqlCollation($db);
                } catch (\Throwable $e) {
                    $collation = 'utf8mb4_unicode_ci';
                }
                return 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                    . '`id` bigint unsigned NOT NULL auto_increment,'
                    . '`cid` int unsigned NOT NULL default 0,'
                    . '`chat_id` varchar(128) NOT NULL default \'\','
                    . '`reason` varchar(32) NOT NULL default \'\','
                    . '`status` varchar(16) NOT NULL default \'\','
                    . '`message_id` bigint NOT NULL default 0,'
                    . '`error` varchar(255) NOT NULL default \'\','
                    . '`payload_hash` char(32) NOT NULL default \'\','
                    . '`created_at` int unsigned NOT NULL default 0,'
                    . 'PRIMARY KEY (`id`)'
                    . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=' . $collation;
        }
    }

    /**
     * Column definitions for ALTER TABLE ADD COLUMN (used during upgrades).
     */
    private static function columns(string $dialect): array
    {
        if ($dialect === 'mysql') {
            return [
                'cid'          => '`cid` int unsigned NOT NULL default 0',
                'chat_id'      => '`chat_id` varchar(128) NOT NULL default \'\'',
                'reason'       => '`reason` varchar(32) NOT NULL default \'\'',
                'status'       => '`status` varchar(16) NOT NULL default \'\'',
                'message_id'   => '`message_id` bigint NOT NULL default 0',
                'error'        => '`error` varchar(255) NOT NULL default \'\'',
                'payload_hash' => '`payload_hash` char(32) NOT NULL default \'\'',
                'created_at'   => '`created_at` int unsigned NOT NULL default 0',
            ];
        }

        // SQLite and PgSQL — both use double quotes for identifiers.
        return [
            'cid'          => '"cid" INTEGER NOT NULL DEFAULT 0',
            'chat_id'      => '"chat_id" VARCHAR(128) NOT NULL DEFAULT \'\'',
            'reason'       => '"reason" VARCHAR(32) NOT NULL DEFAULT \'\'',
            'status'       => '"status" VARCHAR(16) NOT NULL DEFAULT \'\'',
            'message_id'   => '"message_id" BIGINT NOT NULL DEFAULT 0',
            'error'        => '"error" VARCHAR(255) NOT NULL DEFAULT \'\'',
            'payload_hash' => '"payload_hash" CHAR(32) NOT NULL DEFAULT \'\'',
            'created_at'   => '"created_at" INTEGER NOT NULL DEFAULT 0',
        ];
    }
}
