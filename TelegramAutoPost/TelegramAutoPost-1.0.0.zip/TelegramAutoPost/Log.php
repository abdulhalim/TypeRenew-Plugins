<?php
declare(strict_types=1);

namespace TypechoPlugin\TelegramAutoPost;

use Typecho\Db;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * ثبت و نگهداری گزارش ارسال‌ها.
 */
class Log
{
    public static function record(
        int $cid,
        string $chatId,
        string $reason,
        string $status,
        int $messageId = 0,
        string $error = ''
    ): void {
        try {
            $db = Db::get();
            $db->query(
                $db->insert('table.' . Plugin::LOG_TABLE)->rows([
                    'cid'          => $cid,
                    'chat_id'      => $chatId,
                    'reason'       => $reason,
                    'status'       => $status,
                    'message_id'   => $messageId,
                    'error'        => mb_substr($error, 0, 250),
                    'payload_hash' => '',
                    'created_at'   => time(),
                ])
            );
        } catch (\Throwable $e) {
            error_log('TelegramAutoPost.Log::record failed: ' . $e->getMessage());
        }
    }

    public static function recent(int $limit = 50): array
    {
        try {
            $db = Db::get();
            return $db->fetchAll(
                $db->select()
                    ->from('table.' . Plugin::LOG_TABLE)
                    ->order('id', Db::SORT_DESC)
                    ->limit(max(1, min(200, $limit)))
            );
        } catch (\Throwable $e) {
            return [];
        }
    }

    public static function summary(): array
    {
        try {
            $db = Db::get();
            $total = (int) ($db->fetchRow(
                $db->select(['COUNT(*)' => 'num'])
                    ->from('table.' . Plugin::LOG_TABLE)
                    ->where("status <> 'dedup'")
            )['num'] ?? 0);
            $success = (int) ($db->fetchRow(
                $db->select(['COUNT(*)' => 'num'])
                    ->from('table.' . Plugin::LOG_TABLE)
                    ->where('status = ?', 'success')
            )['num'] ?? 0);
            $error = (int) ($db->fetchRow(
                $db->select(['COUNT(*)' => 'num'])
                    ->from('table.' . Plugin::LOG_TABLE)
                    ->where('status = ?', 'error')
            )['num'] ?? 0);
            return [
                'total'   => $total,
                'success' => $success,
                'error'   => $error,
                'rate'    => $total > 0 ? round($success * 100 / $total, 1) : 0.0,
            ];
        } catch (\Throwable $e) {
            return ['total' => 0, 'success' => 0, 'error' => 0, 'rate' => 0.0];
        }
    }

    public static function cleanup(int $keepDays): int
    {
        if ($keepDays <= 0) {
            return 0;
        }
        try {
            $db = Db::get();
            $threshold = time() - $keepDays * 86400;
            $deleted = 0;
            while (true) {
                $rows = $db->fetchAll(
                    $db->select('id')
                        ->from('table.' . Plugin::LOG_TABLE)
                        ->where('created_at < ?', $threshold)
                        ->order('id', Db::SORT_ASC)
                        ->limit(500)
                );
                if (empty($rows)) {
                    break;
                }
                $ids = array_map(static fn($r) => (int) $r['id'], $rows);
                $db->query(
                    $db->delete('table.' . Plugin::LOG_TABLE)
                        ->where('id IN (' . implode(',', $ids) . ')')
                );
                $deleted += count($ids);
                if (count($ids) < 500) {
                    break;
                }
            }
            return $deleted;
        } catch (\Throwable $e) {
            return 0;
        }
    }
}
