<?php
declare(strict_types=1);

namespace TypechoPlugin\TelegramAutoPost;

use Typecho\Http\Client;
use Utils\Helper;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * کلاینت سبک برای Bot API تلگرام.
 */
class Sender
{
    private const API_BASE = 'https://api.telegram.org/bot';

    /**
     * ارسال پیام (و در صورت وجود تصویر، ابتدا عکس را می‌فرستد).
     *
     * @return array{ok: bool, message_id?: int, description?: string}
     */
    public static function send(array $settings, string $chatId, array $payload): array
    {
        $token = trim((string) ($settings['botToken'] ?? ''));
        if ($token === '') {
            return ['ok' => false, 'description' => 'bot token is empty'];
        }

        $timeout = max(3, min(60, (int) ($settings['timeout'] ?? 15)));
        $parseMode = (string) ($settings['parseMode'] ?? 'HTML');
        $disablePreview = (string) ($settings['disablePreview'] ?? '1') === '1';
        $text = (string) ($payload['text'] ?? '');
        $image = trim((string) ($payload['image'] ?? ''));

        // 1) Photo with caption — fallback to text if image is unreachable.
        if ($image !== '') {
            $result = self::apiRequest($token, 'sendPhoto', [
                'chat_id'             => $chatId,
                'photo'               => $image,
                'caption'             => $text,
                'parse_mode'          => $parseMode === 'None' ? null : $parseMode,
                'disable_notification' => false,
            ], $timeout);

            if ($result['ok']) {
                return $result;
            }
            // If the photo fails (e.g. URL not downloadable by Telegram),
            // fall through to sendMessage rather than failing the whole send.
        }

        return self::apiRequest($token, 'sendMessage', [
            'chat_id'             => $chatId,
            'text'                => $text,
            'parse_mode'          => $parseMode === 'None' ? null : $parseMode,
            'disable_web_page_preview' => $disablePreview,
            'disable_notification' => false,
        ], $timeout);
    }

    /**
     * @return array{ok: bool, message_id?: int, description?: string}
     */
    private static function apiRequest(string $token, string $method, array $params, int $timeout): array
    {
        $url = self::API_BASE . $token . '/' . $method;

        try {
            $client = Client::get();
            if (!$client) {
                return ['ok' => false, 'description' => 'http client unavailable'];
            }
            $client->setTimeout($timeout);
            $client->setMethod('POST');
            $client->setHeader('User-Agent', (string) (Helper::options()->generator ?? 'TypeRenew') . ' / TelegramAutoPost');
            $client->setHeader('Content-Type', 'application/json; charset=utf-8');
            // Strip nulls — Telegram returns 400 for null fields.
            $clean = array_filter($params, static fn($v) => $v !== null);
            $client->setJson($clean);
            $client->send($url);

            $status = $client->getResponseStatus();
            $body = (string) $client->getResponseBody();
            $json = json_decode($body, true);
            if (!is_array($json)) {
                return [
                    'ok' => false,
                    'description' => sprintf('invalid response (HTTP %d)', $status),
                ];
            }
            if (($json['ok'] ?? false) !== true) {
                return [
                    'ok' => false,
                    'description' => (string) ($json['description'] ?? 'telegram error'),
                ];
            }
            $messageId = 0;
            if (isset($json['result']['message_id'])) {
                $messageId = (int) $json['result']['message_id'];
            }
            return ['ok' => true, 'message_id' => $messageId];
        } catch (\Throwable $e) {
            return ['ok' => false, 'description' => $e->getMessage()];
        }
    }

    /**
     * Test the bot configuration by calling getMe.
     *
     * @return array{ok: bool, info?: array, description?: string}
     */
    public static function testBot(string $token): array
    {
        $token = trim($token);
        if ($token === '') {
            return ['ok' => false, 'description' => 'bot token is empty'];
        }
        try {
            $client = Client::get();
            if (!$client) {
                return ['ok' => false, 'description' => 'http client unavailable'];
            }
            $client->setTimeout(10);
            $client->setMethod('GET');
            $client->setHeader('User-Agent', 'TypeRenew / TelegramAutoPost');
            $client->send(self::API_BASE . $token . '/getMe');
            $body = (string) $client->getResponseBody();
            $json = json_decode($body, true);
            if (!is_array($json) || ($json['ok'] ?? false) !== true) {
                return [
                    'ok' => false,
                    'description' => (string) ($json['description'] ?? 'invalid bot token'),
                ];
            }
            $r = $json['result'] ?? [];
            return [
                'ok' => true,
                'info' => [
                    'id'         => (int) ($r['id'] ?? 0),
                    'username'   => (string) ($r['username'] ?? ''),
                    'first_name' => (string) ($r['first_name'] ?? ''),
                    'can_join_groups'      => (bool) ($r['can_join_groups'] ?? false),
                    'can_read_all_group_messages' => (bool) ($r['can_read_all_group_messages'] ?? false),
                    'supports_inline_queries'     => (bool) ($r['supports_inline_queries'] ?? false),
                ],
            ];
        } catch (\Throwable $e) {
            return ['ok' => false, 'description' => $e->getMessage()];
        }
    }

    /**
     * Test chat reachability for the given bot token by calling getChat.
     *
     * @return array{ok: bool, info?: array, description?: string}
     */
    public static function testChat(string $token, string $chatId): array
    {
        $chatId = trim($chatId);
        if ($chatId === '') {
            return ['ok' => false, 'description' => 'chat id is empty'];
        }
        try {
            $client = Client::get();
            if (!$client) {
                return ['ok' => false, 'description' => 'http client unavailable'];
            }
            $client->setTimeout(10);
            $client->setMethod('GET');
            $client->setQuery(['chat_id' => $chatId]);
            $client->setHeader('User-Agent', 'TypeRenew / TelegramAutoPost');
            $client->send(self::API_BASE . $token . '/getChat');
            $body = (string) $client->getResponseBody();
            $json = json_decode($body, true);
            if (!is_array($json) || ($json['ok'] ?? false) !== true) {
                return [
                    'ok' => false,
                    'description' => (string) ($json['description'] ?? 'cannot reach chat'),
                ];
            }
            $r = $json['result'] ?? [];
            return [
                'ok' => true,
                'info' => [
                    'id'    => (int) ($r['id'] ?? 0),
                    'type'  => (string) ($r['type'] ?? ''),
                    'title' => (string) ($r['title'] ?? $r['first_name'] ?? ''),
                    'username' => (string) ($r['username'] ?? ''),
                ],
            ];
        } catch (\Throwable $e) {
            return ['ok' => false, 'description' => $e->getMessage()];
        }
    }
}
