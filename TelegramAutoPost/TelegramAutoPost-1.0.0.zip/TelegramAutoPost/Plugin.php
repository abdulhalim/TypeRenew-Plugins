<?php
declare(strict_types=1);

namespace TypechoPlugin\TelegramAutoPost;

use Typecho\Db;
use Typecho\Plugin as Hook;
use Typecho\Plugin\PluginInterface;
use Typecho\Router;
use Typecho\Widget\Helper\Form;
use Utils\Helper;
use Utils\NoPersonal;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * افزونه ارسال خودکار پست‌ها به تلگرام
 *
 * @package TelegramAutoPost
 * @author پوردریایی
 * @link https://pourdaryaei.ir/
 * @version 1.0.0
 * @since 1.6.0
 */
class Plugin implements PluginInterface
{
    use NoPersonal;

    public const NAME = 'TelegramAutoPost';
    public const VERSION = '1.0.0';
    public const LOG_TABLE = 'tgautopost_logs';

    /** @var array<string,string> */
    public const DEFAULTS = [
        'enabled'          => '0',
        'botToken'         => '',
        'chatIds'          => '',
        'parseMode'        => 'HTML',
        'disablePreview'   => '1',
        'sendImage'        => '1',
        'postTypes'        => 'post',
        'categoryFilter'   => '',
        'skipField'        => 'tg_skip',
        'messageTemplate'  => "<b>{title}</b>\n\n{excerpt}\n\n{tags}\n\n<a href=\"{url}\">ادامه مطلب در سایت</a>",
        'sendOnPublish'    => '1',
        'sendOnUpdate'     => '0',
        'includeAuthor'    => '1',
        'includeCategories'=> '1',
        'includeDate'      => '0',
        'timeout'          => '15',
    ];

    public static ?array $runtimeSettings = null;

    public static function activate(): string
    {
        Schema::ensure();

        foreach (['Widget\Contents\Post\Edit', 'Widget\Contents\Page\Edit'] as $editor) {
            Hook::factory($editor)->finishPublish = [self::class, 'onPublish'];
            Hook::factory($editor)->finishSave    = [self::class, 'onSave'];
            Hook::factory($editor)->finishMark    = [self::class, 'onMark'];
        }

        self::ensureConfigStored();

        return _t('افزونه TelegramAutoPost فعال شد. توکن بات و شناسه چت را در تنظیمات افزونه وارد کنید.');
    }

    public static function deactivate(): string
    {
        return _t('افزونه TelegramAutoPost غیرفعال شد.');
    }

    public static function config(Form $form): void
    {
        $settings = self::settings();

        // ---- وضعیت افزونه ----
        $enabled = new Form\Element\Radio(
            'enabled',
            ['1' => _t('فعال'), '0' => _t('غیرفعال')],
            (string) ($settings['enabled'] ?? '0'),
            _t('وضعیت افزونه'),
            _t('پس از پیکربندی توکن و شناسه چت، افزونه را فعال کنید.')
        );
        $form->addInput($enabled);

        // ---- توکن بات ----
        $botToken = new Form\Element\Text(
            'botToken',
            null,
            (string) ($settings['botToken'] ?? ''),
            _t('توکن بات تلگرام'),
            _t('از @BotFather دریافت کنید. مثال: <code>123456789:ABCdefGhiJklMnoPqrStuVwxYz</code>')
        );
        $botToken->input->setAttribute('class', 'w-90 mono');
        $form->addInput($botToken);

        // ---- شناسه چت ----
        $chatIds = new Form\Element\Text(
            'chatIds',
            null,
            (string) ($settings['chatIds'] ?? ''),
            _t('شناسه چت (چت‌ها)'),
            _t('چند شناسه را با کاما جدا کنید. مثال: <code>-1001234567890,@channelusername</code>. بات باید ادمین کانال باشد.')
        );
        $chatIds->input->setAttribute('class', 'w-90 mono');
        $form->addInput($chatIds);

        // ---- نوع محتوا ----
        $postTypes = new Form\Element\Checkbox(
            'postTypes',
            [
                'post' => _t('نوشته‌ها'),
                'page' => _t('برگه‌ها'),
            ],
            array_values(array_filter(explode(',', (string) ($settings['postTypes'] ?? 'post')))),
            _t('ارسال برای'),
            _t('تعیین کنید برای کدام نوع محتوا پیام ارسال شود.')
        );
        $postTypes->multiMode();
        $form->addInput($postTypes);

        // ---- رویدادها ----
        $events = new Form\Element\Checkbox(
            'events',
            [
                'sendOnPublish' => _t('انتشار'),
                'sendOnUpdate'  => _t('به‌روزرسانی'),
            ],
            array_values(array_filter([
                ($settings['sendOnPublish'] ?? '1') === '1' ? 'sendOnPublish' : '',
                ($settings['sendOnUpdate'] ?? '0') === '1' ? 'sendOnUpdate' : '',
            ])),
            _t('رویدادهای ارسال'),
            _t('پیش‌فرض: فقط هنگام انتشار. اگر «به‌روزرسانی» هم انتخاب شود، هنگام ویرایش مطالب منتشر شده هم پیام ارسال می‌شود.')
        );
        $events->multiMode();
        $form->addInput($events);

        // ---- حالت قالب‌بندی ----
        $parseMode = new Form\Element\Select(
            'parseMode',
            [
                'HTML'       => _t('HTML'),
                'MarkdownV2' => _t('MarkdownV2'),
                'None'       => _t('متن ساده'),
            ],
            (string) ($settings['parseMode'] ?? 'HTML'),
            _t('حالت قالب‌بندی پیام')
        );
        $form->addInput($parseMode);

        // ---- قالب پیام ----
        $template = new Form\Element\Textarea(
            'messageTemplate',
            null,
            (string) ($settings['messageTemplate'] ?? self::DEFAULTS['messageTemplate']),
            _t('قالب پیام'),
            _t('متغیرها: <code>{title} {url} {excerpt} {tags} {categories} {author} {date} {site}</code> — در حالت HTML از تگ‌های <code>&lt;b&gt; &lt;i&gt; &lt;a&gt; &lt;code&gt;</code> استفاده کنید.')
        );
        $template->input->setAttribute('rows', '8');
        $template->input->setAttribute('class', 'w-90 mono');
        $form->addInput($template);

        // ---- گزینه‌های ارسال ----
        $options = new Form\Element\Checkbox(
            'options',
            [
                'sendImage'         => _t('ارسال تصویر شاخص (sendPhoto)'),
                'disablePreview'    => _t('غیرفعال‌کردن پیش‌نمایش لینک'),
                'includeAuthor'     => _t('افزودن نام نویسنده به متغیر {author}'),
                'includeCategories' => _t('افزودن دسته‌ها به متغیر {categories}'),
                'includeDate'       => _t('افزودن تاریخ به متغیر {date}'),
            ],
            array_values(array_filter([
                ($settings['sendImage'] ?? '1')         === '1' ? 'sendImage' : '',
                ($settings['disablePreview'] ?? '1')    === '1' ? 'disablePreview' : '',
                ($settings['includeAuthor'] ?? '1')     === '1' ? 'includeAuthor' : '',
                ($settings['includeCategories'] ?? '1') === '1' ? 'includeCategories' : '',
                ($settings['includeDate'] ?? '0')       === '1' ? 'includeDate' : '',
            ])),
            _t('گزینه‌های ارسال')
        );
        $options->multiMode();
        $form->addInput($options);

        // ---- فیلتر دسته ----
        $categoryFilter = new Form\Element\Text(
            'categoryFilter',
            null,
            (string) ($settings['categoryFilter'] ?? ''),
            _t('فیلتر دسته‌ها (اختیاری)'),
            _t('اسلاگ دسته‌ها را با کاما وارد کنید. خالی = همه مطالب. مثال: <code>news,tutorial</code>')
        );
        $categoryFilter->input->setAttribute('class', 'w-90');
        $form->addInput($categoryFilter);

        // ---- فیلد رد کردن ----
        $skipField = new Form\Element\Text(
            'skipField',
            null,
            (string) ($settings['skipField'] ?? 'tg_skip'),
            _t('فیلد رد کردن (اختیاری)'),
            _t('نام فیلد سفارشی برای رد کردن یک مطلب. اگر این فیلد در مطلب مقدار 1 داشته باشد، پیام ارسال نمی‌شود.')
        );
        $skipField->input->setAttribute('class', 'w-90 mono');
        $form->addInput($skipField);

        // ---- مهلت ارسال ----
        $timeout = new Form\Element\Text(
            'timeout',
            null,
            (string) ($settings['timeout'] ?? '15'),
            _t('مهلت ارسال (ثانیه)'),
            _t('بین ۳ تا ۶۰ ثانیه.')
        );
        $timeout->input->setAttribute('class', 'w-20');
        $form->addInput($timeout);
    }

    public static function configHandle(array $settings, bool $_isInit): void
    {
        $current = self::settings();
        $merged = array_merge(self::DEFAULTS, $current);

        // Normalize checkbox arrays
        if (isset($settings['postTypes'])) {
            $v = $settings['postTypes'];
            $merged['postTypes'] = is_array($v) ? implode(',', $v) : (string) $v;
        }
        if (isset($settings['events'])) {
            $events = is_array($settings['events']) ? $settings['events'] : [];
            $merged['sendOnPublish'] = in_array('sendOnPublish', $events, true) ? '1' : '0';
            $merged['sendOnUpdate']  = in_array('sendOnUpdate',  $events, true) ? '1' : '0';
        }
        if (isset($settings['options'])) {
            $opts = is_array($settings['options']) ? $settings['options'] : [];
            foreach (['sendImage','disablePreview','includeAuthor','includeCategories','includeDate'] as $k) {
                $merged[$k] = in_array($k, $opts, true) ? '1' : '0';
            }
        }

        // Plain text fields
        foreach (['enabled','botToken','chatIds','parseMode','messageTemplate',
                  'categoryFilter','skipField','timeout'] as $k) {
            if (array_key_exists($k, $settings)) {
                $merged[$k] = is_string($settings[$k]) ? trim($settings[$k]) : (string) $settings[$k];
            }
        }

        // Specific normalizations
        if (isset($merged['botToken'])) {
            $merged['botToken'] = trim((string) $merged['botToken']);
        }
        if (isset($merged['chatIds'])) {
            $merged['chatIds'] = trim((string) $merged['chatIds']);
        }
        $t = (int) ($merged['timeout'] ?? 15);
        $merged['timeout'] = (string) max(3, min(60, $t));

        self::storeSettings($merged);
    }

    /* ---------------------------- hooks ---------------------------- */

    /**
     * Hook: Widget\Contents\{Post,Page}\Edit::finishPublish
     *
     * @param array $contents The write payload.
     * @param mixed $editor   The Edit widget instance.
     */
    public static function onPublish(array $contents, $editor): void
    {
        $settings = self::settings();
        if ((string) ($settings['enabled'] ?? '0') !== '1') {
            return;
        }
        if ((string) ($settings['sendOnPublish'] ?? '1') !== '1') {
            return;
        }
        $cid = (int) ($editor->cid ?? 0);
        if ($cid <= 0) {
            return;
        }
        self::send($cid, 'publish', $settings);
    }

    /**
     * Hook: Widget\Contents\{Post,Page}\Edit::finishSave
     *
     * @param array $contents The write payload.
     * @param mixed $editor   The Edit widget instance.
     */
    public static function onSave(array $contents, $editor): void
    {
        $settings = self::settings();
        if ((string) ($settings['enabled'] ?? '0') !== '1') {
            return;
        }
        $cid = (int) ($editor->cid ?? 0);
        if ($cid <= 0) {
            return;
        }
        $row = self::fetchContentRow($cid);
        if (!$row) {
            return;
        }
        if ($row['status'] === 'publish' && (string) ($settings['sendOnUpdate'] ?? '0') === '1') {
            self::send($cid, 'update', $settings);
        }
    }

    /**
     * Hook: Widget\Contents\{Post,Page}\Edit::finishMark
     *
     * @param string $status New status: publish|draft|private|hidden|waiting
     * @param array  $post   Post row snapshot.
     * @param mixed  $editor The Edit widget instance.
     */
    public static function onMark(string $status, $post, $editor): void
    {
        $settings = self::settings();
        if ((string) ($settings['enabled'] ?? '0') !== '1') {
            return;
        }
        if ((string) ($settings['sendOnPublish'] ?? '1') !== '1') {
            return;
        }
        if ($status !== 'publish') {
            return;
        }
        $cid = (int) ($post['cid'] ?? ($editor->cid ?? 0));
        if ($cid <= 0) {
            return;
        }
        self::send($cid, 'mark:publish', $settings);
    }

    /* --------------------------- sending --------------------------- */

    public static function send(int $cid, string $reason, ?array $settings = null): void
    {
        $settings = $settings ?? self::settings();
        $row = self::fetchContentRow($cid);
        if (!$row) {
            return;
        }

        // Type filter
        $type = (string) $row['type'];
        $allowed = array_filter(explode(',', (string) ($settings['postTypes'] ?? 'post')));
        if (!in_array($type, $allowed, true)) {
            return;
        }

        // Category filter
        $filter = trim((string) ($settings['categoryFilter'] ?? ''));
        if ($filter !== '') {
            $wanted = array_filter(array_map('trim', explode(',', $filter)));
            if (!empty($wanted)) {
                $slugs = self::contentCategorySlugs($cid);
                if (empty(array_intersect($wanted, $slugs))) {
                    return;
                }
            }
        }

        // Per-post skip field
        $skipField = trim((string) ($settings['skipField'] ?? 'tg_skip'));
        if ($skipField !== '' && self::readField($cid, $skipField) === '1') {
            return;
        }

        // Avoid duplicate sends in a 60s window.
        $key = sprintf('%d:%s:%d', $cid, $reason, (int) ($row['modified'] ?? 0));
        if (self::recentlySent($key, 60)) {
            return;
        }

        $payload = self::buildPayload($row, $settings);
        if ($payload === null) {
            return;
        }

        $chatIds = array_filter(array_map('trim', explode(',', (string) ($settings['chatIds'] ?? ''))));
        if (empty($chatIds)) {
            return;
        }

        $sent = false;
        foreach ($chatIds as $chatId) {
            $chatId = trim($chatId);
            if ($chatId === '') {
                continue;
            }
            try {
                $result = Sender::send($settings, $chatId, $payload);
                Log::record(
                    $cid,
                    $chatId,
                    $reason,
                    $result['ok'] ? 'success' : 'error',
                    $result['ok'] ? ($result['message_id'] ?? 0) : 0,
                    $result['ok'] ? '' : ($result['description'] ?? 'unknown error')
                );
                $sent = $sent || $result['ok'];
            } catch (\Throwable $e) {
                Log::record($cid, $chatId, $reason, 'error', 0, $e->getMessage());
            }
        }

        if ($sent) {
            self::markSent($key);
        }
    }

    /**
     * Build the Telegram payload from a content row.
     *
     * @return array{image: string, text: string}|null
     */
    public static function buildPayload(array $row, array $settings): ?array
    {
        $options = Helper::options();
        $title = (string) ($row['title'] ?? '');
        $slug = (string) ($row['slug'] ?? '');
        $created = (int) ($row['created'] ?? time());
        $cid = (int) ($row['cid'] ?? 0);

        $url = self::buildPermalink($row);
        if ($url === '' || $url === '#') {
            $url = (string) $options->siteUrl . 'index.php?cid=' . $cid;
        }

        $excerpt = self::buildExcerpt($row);
        $tags = self::contentTagNames($cid);
        $categories = self::contentCategoryNames($cid);
        $author = self::authorName((int) ($row['authorId'] ?? 0));

        $image = '';
        if ((string) ($settings['sendImage'] ?? '1') === '1') {
            $image = self::firstImageFromContent((string) ($row['text'] ?? ''), (int) ($row['cid'] ?? 0));
        }

        $template = (string) ($settings['messageTemplate'] ?? self::DEFAULTS['messageTemplate']);
        $siteName = (string) ($options->title ?? '');
        $dateText = (string) date('Y/m/d H:i', $created);

        $tagLine = '';
        if (!empty($tags) && strpos($template, '{tags}') !== false) {
            $tagLine = '#' . implode(' #', $tags);
        }

        $catLine = '';
        if (!empty($categories)
            && (string) ($settings['includeCategories'] ?? '1') === '1'
            && strpos($template, '{categories}') !== false) {
            $catLine = implode(' • ', $categories);
        }

        $authorLine = '';
        if ((string) ($settings['includeAuthor'] ?? '1') === '1'
            && $author !== ''
            && strpos($template, '{author}') !== false) {
            $authorLine = $author;
        }

        $dateLine = '';
        if ((string) ($settings['includeDate'] ?? '0') === '1'
            && strpos($template, '{date}') !== false) {
            $dateLine = $dateText;
        }

        $replacements = [
            '{title}'      => $title,
            '{url}'        => $url,
            '{excerpt}'    => $excerpt,
            '{tags}'       => $tagLine,
            '{categories}' => $catLine,
            '{author}'     => $authorLine,
            '{date}'       => $dateLine,
            '{site}'       => $siteName,
        ];

        $text = strtr($template, $replacements);
        $text = self::normalizeForParseMode($text, (string) ($settings['parseMode'] ?? 'HTML'));

        return ['image' => $image, 'text' => $text];
    }

    public static function buildExcerpt(array $row): string
    {
        $text = (string) ($row['text'] ?? '');
        $text = preg_replace('#<!--markdown-->#', '', $text);
        $text = preg_replace('/```[\s\S]*?```/', ' ', $text);
        $text = preg_replace('/`([^`]+)`/', '$1', $text);
        $text = preg_replace('/!\[[^\]]*\]\([^)]+\)/', ' ', $text);
        $text = preg_replace('/\[([^\]]+)\]\([^)]+\)/', '$1', $text);
        $text = preg_replace('/^#{1,6}\s+/m', '', $text);
        $text = preg_replace('/[*_~>]/', '', $text);
        $text = strip_tags($text);
        $text = preg_replace('/\s+/', ' ', $text);
        $text = trim($text);

        if (mb_strlen($text) <= 280) {
            return $text;
        }
        return mb_substr($text, 0, 280) . '…';
    }

    public static function normalizeForParseMode(string $text, string $mode): string
    {
        if ($mode === 'MarkdownV2') {
            $escape = ['_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!'];
            $escaped = '';
            for ($i = 0, $n = mb_strlen($text); $i < $n; $i++) {
                $ch = $text[$i];
                if (in_array($ch, $escape, true)) {
                    $escaped .= '\\' . $ch;
                } else {
                    $escaped .= $ch;
                }
            }
            return $escaped;
        }
        return $text;
    }

    public static function buildPermalink(array $row): string
    {
        try {
            $options = Helper::options();
            $cid = (int) ($row['cid'] ?? 0);
            $slug = (string) ($row['slug'] ?? '');
            $created = (int) ($row['created'] ?? time());
            $type = (string) ($row['type'] ?? 'post');
            $category = self::firstCategory((int) $cid);

            $params = [
                'cid'      => (string) $cid,
                'slug'     => urlencode($slug),
                'category' => urlencode((string) ($category['slug'] ?? '')),
                'year'     => date('Y', $created),
                'month'    => date('m', $created),
                'day'      => date('d', $created),
            ];

            $routeName = $type === 'page' ? 'page' : 'post';
            return Router::url($routeName, $params, $options->index);
        } catch (\Throwable $e) {
            return '';
        }
    }

    /* --------------------------- helpers --------------------------- */

    public static function fetchContentRow(int $cid): ?array
    {
        if ($cid <= 0) {
            return null;
        }
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select(
                    'cid', 'title', 'slug', 'text', 'created', 'modified',
                    'type', 'status', 'authorId', 'commentsNum'
                )
                ->from('table.contents')
                ->where('cid = ?', $cid)
                ->limit(1)
            );
            return $row ?: null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    public static function firstCategory(int $cid): ?array
    {
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('mid', 'name', 'slug')
                    ->from('table.metas')
                    ->join('table.relationships', 'table.relationships.mid = table.metas.mid')
                    ->where('table.relationships.cid = ?', $cid)
                    ->where('table.metas.type = ?', 'category')
                    ->order('table.metas.order', Db::SORT_ASC)
                    ->limit(1)
            );
            return $row ?: null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    public static function contentCategorySlugs(int $cid): array
    {
        return array_map(static fn($r) => (string) $r['slug'], self::contentMetas($cid, 'category'));
    }

    public static function contentCategoryNames(int $cid): array
    {
        return array_map(static fn($r) => (string) $r['name'], self::contentMetas($cid, 'category'));
    }

    public static function contentTagNames(int $cid): array
    {
        return array_map(static fn($r) => (string) $r['name'], self::contentMetas($cid, 'tag'));
    }

    public static function contentMetas(int $cid, string $type): array
    {
        if ($cid <= 0) {
            return [];
        }
        try {
            $db = Db::get();
            return $db->fetchAll(
                $db->select('mid', 'name', 'slug')
                    ->from('table.metas')
                    ->join('table.relationships', 'table.relationships.mid = table.metas.mid')
                    ->where('table.relationships.cid = ?', $cid)
                    ->where('table.metas.type = ?', $type)
                    ->order('table.metas.order', Db::SORT_ASC)
            );
        } catch (\Throwable $e) {
            return [];
        }
    }

    public static function authorName(int $authorId): string
    {
        if ($authorId <= 0) {
            return '';
        }
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('name', 'screenName')
                    ->from('table.users')
                    ->where('uid = ?', $authorId)
                    ->limit(1)
            );
            if (!$row) {
                return '';
            }
            return (string) ($row['screenName'] !== '' ? $row['screenName'] : $row['name']);
        } catch (\Throwable $e) {
            return '';
        }
    }

    public static function firstImageFromContent(string $text, int $cid): string
    {
        if (preg_match('/!\[[^\]]*\]\(([^)\s]+)["\']?\s*[^\)]*\)/', $text, $m)) {
            return self::absoluteUrl($m[1]);
        }
        if (preg_match('#<img[^>]+src=["\']([^"\']+)["\']#i', $text, $m)) {
            return self::absoluteUrl($m[1]);
        }
        try {
            if ($cid > 0) {
                $db = Db::get();
                $row = $db->fetchRow(
                    $db->select('text')
                        ->from('table.contents')
                        ->where('type = ?', 'attachment')
                        ->where('parent = ?', $cid)
                        ->order('cid', Db::SORT_ASC)
                        ->limit(1)
                );
                if ($row && preg_match('#https?://[^\s\'"<>]+\.(?:jpg|jpeg|png|webp|gif)#i', (string) $row['text'], $m)) {
                    return $m[1];
                }
            }
        } catch (\Throwable $e) {
        }
        return '';
    }

    public static function absoluteUrl(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }
        if (preg_match('#^https?://#i', $url)) {
            return $url;
        }
        if (str_starts_with($url, '//')) {
            return 'https:' . $url;
        }
        $base = rtrim((string) Helper::options()->siteUrl, '/');
        if (str_starts_with($url, '/')) {
            return $base . $url;
        }
        return $base . '/' . $url;
    }

    public static function readField(int $cid, string $name): string
    {
        if ($cid <= 0 || $name === '') {
            return '';
        }
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('str_value', 'int_value')
                    ->from('table.fields')
                    ->where('cid = ? AND name = ?', $cid, $name)
                    ->limit(1)
            );
            if (!$row) {
                return '';
            }
            return (string) ($row['str_value'] !== '' ? $row['str_value'] : $row['int_value']);
        } catch (\Throwable $e) {
            return '';
        }
    }

    public static function recentlySent(string $key, int $windowSeconds): bool
    {
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select(['COUNT(*)' => 'num'])
                    ->from('table.' . self::LOG_TABLE)
                    ->where('payload_hash = ?', md5($key))
                    ->where('created_at > ?', time() - $windowSeconds)
            );
            return ((int) ($row['num'] ?? 0)) > 0;
        } catch (\Throwable $e) {
            return false;
        }
    }

    public static function markSent(string $key): void
    {
        try {
            $db = Db::get();
            $db->query(
                $db->insert('table.' . self::LOG_TABLE)
                    ->rows([
                        'cid'          => 0,
                        'chat_id'      => '',
                        'reason'       => 'dedup',
                        'status'       => 'dedup',
                        'message_id'   => 0,
                        'error'        => '',
                        'payload_hash' => md5($key),
                        'created_at'   => time(),
                    ])
            );
        } catch (\Throwable $e) {
            // best-effort
        }
    }

    /* ----------------------------- settings ----------------------------- */

    public static function settings(): array
    {
        if (is_array(self::$runtimeSettings)) {
            return self::$runtimeSettings;
        }
        try {
            $raw = (array) Helper::options()->plugin(self::NAME)->toArray();
        } catch (\Throwable $e) {
            $raw = [];
        }
        $merged = array_merge(self::DEFAULTS, $raw);
        self::$runtimeSettings = $merged;
        return $merged;
    }

    public static function ensureConfigStored(): void
    {
        try {
            $raw = (array) Helper::options()->plugin(self::NAME)->toArray();
            if (empty($raw)) {
                self::storeSettings(self::DEFAULTS);
            }
        } catch (\Throwable $e) {
        }
    }

    public static function storeSettings(array $settings): void
    {
        try {
            Helper::configPlugin(self::NAME, $settings);
        } catch (\Throwable $e) {
        }
        self::$runtimeSettings = $settings;
    }
}
