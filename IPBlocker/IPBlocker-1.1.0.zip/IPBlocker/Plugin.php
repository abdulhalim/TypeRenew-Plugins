<?php
namespace TypechoPlugin\IPBlocker;

use Typecho\Plugin as TypechoPlugin;
use Typecho\Plugin\PluginInterface;
use Typecho\Request;
use Typecho\Response;
use Typecho\Widget\Helper\Form;
use Typecho\Widget\Helper\Form\Element\Number;
use Typecho\Widget\Helper\Form\Element\Radio;
use Typecho\Widget\Helper\Form\Element\Submit;
use Typecho\Widget\Helper\Form\Element\Text;
use Typecho\Widget\Helper\Form\Element\Textarea;
use TypechoPlugin\IPBlocker\lib\Cache;
use TypechoPlugin\IPBlocker\lib\Ip;
use TypechoPlugin\IPBlocker\lib\Logger;
use TypechoPlugin\IPBlocker\lib\Settings;
use TypechoPlugin\IPBlocker\lib\Store;
use Utils\Helper;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * افزونه ای برای مسدود کردن آی پی های مزاحم
 *
 * @package IP Blocker
 * @author  پوردریایی
 * @link    https://pourdaryaei.ir
 * @since   1.6.0
 * @version 1.1.0
 */
class Plugin implements PluginInterface
{
    /** نسخه‌ی پلاگین */
    public const VERSION = '1.1.0';

    /** پنل یکپارچه (تنها مدخل منو) */
    public const PANEL_MANAGE = 'IPBlocker/panels/manage.php';

    /** نماهای داخلی پنل یکپارچه */
    public const VIEWS = ['manage', 'logs', 'tools'];

    /** پنل‌های قدیمی ۱.۰.۰ — فقط برای پاک‌سازی هنگام ارتقا و نشانی‌های قدیمی */
    public const PANEL_LOGS = 'IPBlocker/panels/logs.php';
    public const PANEL_TOOLS = 'IPBlocker/panels/tools.php';

    /** شناسه‌ی اکشن */
    public const ACTION_NAME = 'ip-blocker';

    // ------------------------------------------------------------------
    // چرخه‌ی حیات پلاگین
    // ------------------------------------------------------------------

    /**
     * فعال‌سازی پلاگین
     */
    public static function activate()
    {
        // ۱) ساخت جداول دیتابیس (MySQL / PostgreSQL / SQLite)
        Store::ensureSchema();
        Logger::ensureSchema();

        // ۲) هوک مسدودسازی فرانت‌اند — زودترین نقطه‌ی ممکن پیش از Router
        TypechoPlugin::factory('index.php')->begin = [__CLASS__, 'guard'];

        // ۳) هوک پنل مدیریت: ثبت IP مدیر + اعمال بلاک روی پنل
        TypechoPlugin::factory('admin/common.php')->begin = [__CLASS__, 'adminGuard'];

        // ۴) تزریق CSS/JS اختصاصی فقط روی پنل‌های خود افزونه
        TypechoPlugin::factory('admin/header.php')->header = [__CLASS__, 'injectAssets'];

        // ۵) پنل یکپارچه‌ی مدیریت — تنها مدخل منو؛ لاگ‌ها و ابزارها تب‌های داخلی همان پنل‌اند
        Helper::addPanel(5, self::PANEL_MANAGE, 'IP Blocker', 'مدیریت، لاگ و ابزارهای مسدودسازی IP', 'administrator');

        // ۶) اکشن پردازش عملیات (با محافظت CSRF داخلی)
        Helper::addAction(self::ACTION_NAME, '\TypechoPlugin\IPBlocker\Action');

        // ۷) ثبت IP مدیرِ فعال‌کننده به‌عنوان آدرس محافظت‌شده (ضد قفل‌شدن از ابتدا)
        try {
            $adminIp = Ip::normalize(Request::getInstance()->getIp());
            if ($adminIp !== null) {
                Store::touchProtectedIp($adminIp);
            }
        } catch (\Throwable $e) {
            // محافظت اختیاری است
        }

        // ۸) ساخت اولیه‌ی کش
        Cache::build();

        return 'افزونه‌ی IP Blocker فعال شد. از منوی «افزونه‌ها» به «IP Blocker» وارد شوید.';
    }

    /**
     * غیرفعال‌سازی پلاگین
     *
     * داده‌ها حذف نمی‌شوند تا با فعال‌سازی مجدد، همه‌چیز سر جای خود باشد.
     */
    public static function deactivate()
    {
        // پنل یکپارچه + پاک‌سازی مدخل‌های قدیمی ۱.۰.۰ (برای حالت ارتقا بدون غیرفعال‌سازی)
        Helper::removePanel(5, self::PANEL_MANAGE);
        Helper::removePanel(5, self::PANEL_LOGS);
        Helper::removePanel(5, self::PANEL_TOOLS);
        Helper::removeAction(self::ACTION_NAME);

        Cache::invalidate();

        return 'افزونه‌ی IP Blocker غیرفعال شد. قوانین و لاگ‌ها برای فعال‌سازی مجدد حفظ شده‌اند.';
    }

    // ------------------------------------------------------------------
    // فرم تنظیمات
    // ------------------------------------------------------------------

    /**
     * پنل تنظیمات افزونه
     */
    public static function config(Form $form)
    {
        $enabled = new Radio(
            'enabled',
            ['1' => 'فعال', '0' => 'غیرفعال'],
            '1',
            'وضعیت مسدودسازی',
            'کلید اصلی افزونه؛ در حالت غیرفعال هیچ درخواستی مسدود نمی‌شود.'
        );
        $form->addInput($enabled);

        $blockMessage = new Textarea(
            'blockMessage',
            null,
            Settings::DEFAULTS['blockMessage'],
            'پیام نمایش‌داده‌شده به بازدیدکننده‌ی مسدود',
            'این متن همراه کد HTTP 403 نمایش داده می‌شود.'
        );
        $blockMessage->setAttribute('rows', 3);
        $form->addInput($blockMessage);

        $blockAdmin = new Radio(
            'blockAdmin',
            ['1' => 'بله، پنل مدیریت هم فیلتر شود', '0' => 'خیر، فقط سایت عمومی'],
            '1',
            'اعمال بلاک روی پنل مدیریت',
            'با فعال بودن این گزینه، IP های مسدود به صفحه‌ی ورود مدیریت هم دسترسی ندارند (ضد حملات brute-force).'
            . ' IP مدیران به‌طور خودکار محافظت می‌شود.'
        );
        $form->addInput($blockAdmin);

        $protectAdminIps = new Radio(
            'protectAdminIps',
            ['1' => 'بله (پیشنهادی)', '0' => 'خیر'],
            '1',
            'محافظت خودکار از IP مدیران',
            'آدرس IP مدیرانِ واردشده به‌طور خودکار ثبت و هرگز مسدود نمی‌شود؛ همچنین افزودن بازه‌هایی که IP مدیر را پوشش دهند متوقف می‌شود.'
        );
        $form->addInput($protectAdminIps);

        $extraWhitelist = new Textarea(
            'extraWhitelist',
            null,
            '',
            'لیست سفید اضافی (اختیاری)',
            'هر خط یک آدرس IP یا بازه‌ی CIDR — مثل 203.0.113.10 یا 198.51.100.0/24 — که همیشه در دسترس است. خطوط با # کامنت می‌شوند.'
        );
        $extraWhitelist->setAttribute('rows', 4);
        $form->addInput($extraWhitelist);

        $logEnabled = new Radio(
            'logEnabled',
            ['1' => 'فعال', '0' => 'غیرفعال'],
            '1',
            'ثبت لاگ درخواست‌های مسدودشده',
            'زمان، IP، قانون، دلیل، URL و مرورگر هر درخواست مسدودشده ثبت می‌شود.'
        );
        $form->addInput($logEnabled);

        $logRetentionDays = new Number(
            'logRetentionDays',
            null,
            90,
            'سیاست پاکسازی خودکار لاگ (روز)',
            'لاگ‌های قدیمی‌تر از این تعداد روز به‌طور خودکار حذف می‌شوند؛ عدد ۰ یعنی نگهداری نامحدود.'
        );
        $logRetentionDays->setAttribute('min', 0);
        $logRetentionDays->setAttribute('max', 3650);
        $form->addInput($logRetentionDays);

        $logMaxPerHour = new Number(
            'logMaxPerHour',
            null,
            120,
            'حداکثر لاگ برای هر IP در ساعت',
            'برای جلوگیری از سیلابی شدن جدول لاگ؛ عدد ۰ یعنی بدون محدودیت.'
        );
        $logMaxPerHour->setAttribute('min', 0);
        $logMaxPerHour->setAttribute('max', 100000);
        $form->addInput($logMaxPerHour);
    }

    /**
     * پنل تنظیمات شخصی (استفاده نمی‌شود)
     */
    public static function personalConfig(Form $form)
    {
    }

    /**
     * اعتبارسنجی تنظیمات پس از ذخیره
     *
     * @return string|null پیام هشدار یا null
     */
    public static function configCheck(array $settings): ?string
    {
        $whitelist = trim((string) ($settings['extraWhitelist'] ?? ''));

        if ($whitelist !== '') {
            $invalid = [];

            foreach (preg_split('/\r\n|\r|\n/', $whitelist) ?: [] as $line) {
                $line = trim($line);
                if ($line === '' || str_starts_with($line, '#')) {
                    continue;
                }

                if (Ip::parseRule($line) === null) {
                    $invalid[] = $line;
                }
            }

            if (!empty($invalid)) {
                return 'این موارد لیست سفید معتبر نیستند و نادیده گرفته شدند: ' . implode('، ', array_slice($invalid, 0, 5));
            }
        }

        return null;
    }

    /**
     * پس از ذخیره‌ی تنظیمات: بازسازی کش
     */
    public static function configHandle(array $settings, bool $isInit = false)
    {
        try {
            Settings::flush();
            Cache::build();
        } catch (\Throwable $e) {
            // بازسازی در اولین فرصت بعدی انجام می‌شود
        }
    }

    // ------------------------------------------------------------------
    // هوک‌های اجرایی
    // ------------------------------------------------------------------

    /**
     * هوک index.php::begin — گارد مسدودسازی فرانت‌اند
     */
    public static function guard(): void
    {
        self::runBlockCheck(self::loadCache(), false);
    }

    /**
     * هوک admin/common.php::begin — ثبت IP مدیر + گارد پنل مدیریت
     */
    public static function adminGuard(): void
    {
        $cache = self::loadCache();
        $settings = $cache['settings'] ?? [];

        // ۱) ثبت خودکار IP مدیران (برای محافظت از قفل‌شدن)
        if (($settings['protectAdminIps'] ?? '1') === '1') {
            try {
                $user = \Widget\User::alloc();

                if ($user->hasLogin() && $user->pass('administrator', true)) {
                    $ip = Ip::normalize(Request::getInstance()->getIp());

                    if ($ip !== null && Store::touchProtectedIp($ip)) {
                        $cache = Cache::build(); // لیست محافظت‌شده تغییر کرد
                    }
                }
            } catch (\Throwable $e) {
                // محافظت اختیاری است؛ هرگز پنل را نمی‌شکند
            }
        }

        // ۲) اعمال مسدودسازی روی صفحات مدیریت
        if (($settings['blockAdmin'] ?? '1') === '1') {
            self::runBlockCheck($cache, true);
        }
    }

    /**
     * هوک admin/header.php::header — تزریق دارایی‌های پنل
     */
    public static function injectAssets(string $header): string
    {
        if (!self::isOwnPanelRequest()) {
            return $header;
        }

        $base = self::assetsUrl();

        $header .= '<link rel="stylesheet" href="' . htmlspecialchars($base . '/css/ipblocker.css?v=' . self::VERSION, ENT_QUOTES, 'UTF-8') . '">' . "\n";
        $header .= '<script src="' . htmlspecialchars($base . '/js/ipblocker.js?v=' . self::VERSION, ENT_QUOTES, 'UTF-8') . '" defer></script>' . "\n";

        return $header;
    }

    // ------------------------------------------------------------------
    // منطق مسدودسازی
    // ------------------------------------------------------------------

    /**
     * بارگذاری کش با لایه‌ی محافظ خطا
     */
    private static function loadCache(): array
    {
        try {
            return Cache::load();
        } catch (\Throwable $e) {
            return ['generated' => 0, 'settings' => ['enabled' => '0'], 'exact' => [], 'ranges' => [], 'protected' => ['ips' => [], 'ranges' => []]];
        }
    }

    /**
     * اجرای بررسی مسدودسازی
     *
     * @param array $cache ساختار کش
     * @param bool  $isAdmin آیا در پنل مدیریت هستیم؟
     */
    private static function runBlockCheck(array $cache, bool $isAdmin): void
    {
        try {
            $settings = $cache['settings'] ?? [];

            if (($settings['enabled'] ?? '1') !== '1') {
                return;
            }

            $request = Request::getInstance();
            $ip = Ip::normalize($request->getIp());

            if ($ip === null) {
                return; // آدرس نامعتبر/unknown → عبور
            }

            // محافظت‌شده‌ها هرگز مسدود نمی‌شوند (مدیران + لیست سفید)
            if (Ip::isProtected($ip, $cache)) {
                return;
            }

            $rule = Ip::findMatch($ip, $cache);

            if ($rule === null) {
                return;
            }

            self::sendBlockedResponse($rule, $ip, $settings, $request, $isAdmin);
        } catch (\Throwable $e) {
            // خطای غیرمنتظره هرگز نباید دسترسی سایت را قطع کند
        }
    }

    /**
     * ارسال پاسخ 403 به بازدیدکننده‌ی مسدود
     *
     * پاسخ سریع ارسال می‌شود؛ ثبت لاگ و شمارنده در پس‌زمینه
     * (background responder) انجام می‌گیرد تا سرعت پاسخ حفظ شود.
     */
    private static function sendBlockedResponse(array $rule, string $ip, array $settings, Request $request, bool $isAdmin): void
    {
        $response = Response::getInstance();

        $message = trim((string) ($settings['blockMessage'] ?? ''));
        if ($message === '') {
            $message = Settings::DEFAULTS['blockMessage'];
        }

        $html = self::blockedPageHtml($message);

        $logEnabled = ($settings['logEnabled'] ?? '1') === '1';
        $maxPerHour = (int) ($settings['logMaxPerHour'] ?? 120);
        $ruleId = (int) ($rule['id'] ?? 0);
        $ruleValue = (string) ($rule['value'] ?? '');
        $reason = (string) ($rule['reason'] ?? '');
        $matchedBy = (string) ($rule['matchedBy'] ?? '');

        $url = mb_substr((string) $request->getRequestUrl(), 0, 480, 'UTF-8');
        $method = mb_substr((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'), 0, 7, 'UTF-8');
        $agent = mb_substr((string) ($request->getAgent() ?? ''), 0, 280, 'UTF-8');

        if ($logEnabled || $ruleId > 0) {
            $response->addBackgroundResponder(static function () use ($logEnabled, $maxPerHour, $ip, $ruleId, $ruleValue, $reason, $url, $method, $agent, $matchedBy): void {
                try {
                    if ($logEnabled && !Logger::isThrottled($ip, $maxPerHour)) {
                        Logger::log([
                            'ip'        => $ip,
                            'ruleId'    => $ruleId,
                            'ruleValue' => $ruleValue !== '' ? $ruleValue : $matchedBy,
                            'reason'    => $reason,
                            'url'       => $url,
                            'method'    => $method,
                            'agent'     => $agent,
                        ]);
                    }

                    Store::incrementHits($ruleId);
                } catch (\Throwable $e) {
                    // پس‌زمینه‌ی آماری؛ بی‌صدا رد می‌شود
                }
            });
        }

        $response->setStatus(403);
        $response->setHeader('Cache-Control', 'no-store, max-age=0');
        $response->setHeader('X-Robots-Tag', 'noindex');

        $response->addResponder(static function () use ($html): void {
            echo $html;
        });

        $response->respond();
    }

    /**
     * صفحه‌ی HTML نمایش‌داده‌شده به IP مسدود (مستقل، RTL، سازگار با حالت روشن/تاریک)
     */
    private static function blockedPageHtml(string $message): string
    {
        $safeMessage = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');

        return <<<HTML
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>دسترسی محدود — 403</title>
<style>
:root {
    --bg: #f4f5f7;
    --surface: #ffffff;
    --text: #16181d;
    --muted: #6b7280;
    --accent: #dc2626;
    --border: rgba(0, 0, 0, .10);
}
@media (prefers-color-scheme: dark) {
    :root {
        --bg: #0f1115;
        --surface: #171a20;
        --text: #f2f4f8;
        --muted: #9aa3af;
        --border: rgba(255, 255, 255, .10);
    }
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
    font-family: system-ui, "Segoe UI", Tahoma, Arial, sans-serif;
    background: var(--bg);
    color: var(--text);
    min-height: 100vh;
    display: grid;
    place-items: center;
    padding: 24px;
    line-height: 1.9;
}
.card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 18px;
    max-width: 480px;
    width: 100%;
    padding: 40px 32px;
    text-align: center;
    box-shadow: 0 18px 50px rgba(0, 0, 0, .08);
}
.shield {
    width: 64px;
    height: 64px;
    margin: 0 auto 20px;
    border-radius: 20px;
    display: grid;
    place-items: center;
    background: rgba(220, 38, 38, .10);
}
.shield svg { width: 32px; height: 32px; stroke: var(--accent); }
h1 { font-size: 20px; font-weight: 800; margin-bottom: 10px; }
p { color: var(--muted); font-size: 14.5px; margin-bottom: 24px; }
.code {
    display: inline-block;
    direction: ltr;
    font-family: ui-monospace, "Courier New", monospace;
    font-size: 12.5px;
    letter-spacing: 1px;
    color: var(--muted);
    border: 1px solid var(--border);
    border-radius: 999px;
    padding: 6px 16px;
}
</style>
</head>
<body>
<main class="card" role="main">
    <div class="shield" aria-hidden="true">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            <line x1="12" y1="9" x2="12" y2="13"/>
            <line x1="12" y1="16.5" x2="12.01" y2="16.5"/>
        </svg>
    </div>
    <h1>دسترسی شما محدود شده است</h1>
    <p>{$safeMessage}</p>
    <span class="code">HTTP 403 — Forbidden</span>
</main>
</body>
</html>
HTML;
    }

    // ------------------------------------------------------------------
    // ابزارهای داخلی
    // ------------------------------------------------------------------

    /**
     * آیا درخواست فعلی مربوط به پنل‌های این افزونه است؟
     */
    public static function isOwnPanelRequest(): bool
    {
        $script = basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''));

        if ($script !== 'extending.php') {
            return false;
        }

        $panel = (string) ($_GET['panel'] ?? '');

        return str_starts_with($panel, 'IPBlocker/');
    }

    /**
     * آدرس عمومی دارایی‌های افزونه
     */
    public static function assetsUrl(): string
    {
        $options = \Widget\Options::alloc();

        return rtrim((string) $options->pluginUrl, '/') . '/IPBlocker/assets';
    }

    /**
     * آدرس یک پنل افزونه (با مسیر صحیح مدیریت)
     */
    public static function panelUrl(string $panel): string
    {
        return Helper::url($panel);
    }
}
