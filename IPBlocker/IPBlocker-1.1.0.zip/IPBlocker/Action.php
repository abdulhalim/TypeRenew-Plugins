<?php
/**
 * Action — پردازشگر عملیات پنل IP Blocker
 *
 * تمام عملیات تغییردهنده از طریق POST و با محافظت CSRF داخلی
 * TypeRenew (security->protect) انجام می‌شوند.
 *
 * @package IPBlocker
 * @since   1.0.0
 */

namespace TypechoPlugin\IPBlocker;

use TypechoPlugin\IPBlocker\lib\Cache;
use TypechoPlugin\IPBlocker\lib\Ip;
use TypechoPlugin\IPBlocker\lib\Logger;
use TypechoPlugin\IPBlocker\lib\Settings;
use TypechoPlugin\IPBlocker\lib\Store;
use TypechoPlugin\IPBlocker\lib\Transfer;
use Widget\ActionInterface;
use Widget\Base;
use Widget\Notice;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Action extends Base implements ActionInterface
{
    // ------------------------------------------------------------------
    // ورودی اکشن
    // ------------------------------------------------------------------

    public function action()
    {
        // فقط مدیر کل
        $this->user->pass('administrator');

        // محافظت CSRF (برای POST از فیلد _ و برای لینک‌های GET از توکن URL)
        $this->security->protect();

        $do = (string) $this->request->get('do', '');

        if ($this->request->isPost()) {
            $this->handlePost($do);

            return;
        }

        // تنها عملیات GET مجاز: دانلود اکسپورت
        if ($do === 'export') {
            $this->doExport();

            return;
        }

        $this->response->goBack();
    }

    /**
     * مسیریابی عملیات POST
     */
    private function handlePost(string $do): void
    {
        switch ($do) {
            case 'add':
                $this->doAdd();

                return;

            case 'delete':
                $this->doDelete();

                return;

            case 'toggle':
                $this->doToggle();

                return;

            case 'extend':
                $this->doExtend();

                return;

            case 'purge-expired':
                $this->doPurgeExpired();

                return;

            case 'rebuild-cache':
                $this->doRebuildCache();

                return;

            case 'clear-protected':
                $this->doClearProtected();

                return;

            case 'import':
                $this->doImport();

                return;

            case 'logs-delete':
                $this->doLogsDelete();

                return;

            case 'logs-purge':
                $this->doLogsPurge();

                return;

            case 'logs-cleanup':
                $this->doLogsCleanup();

                return;

            case 'quick-block':
                $this->doQuickBlock();

                return;
        }

        $this->response->goBack();
    }

    // ------------------------------------------------------------------
    // ابزارهای داخلی
    // ------------------------------------------------------------------

    /**
     * پیام موفقیت + بازگشت
     */
    private function success(string $message): void
    {
        Notice::alloc()->set($message, 'success');
        $this->rebuild();
        $this->response->goBack();
    }

    /**
     * پیام خطا + بازگشت
     */
    private function failure(string $message): void
    {
        Notice::alloc()->set($message, 'error');
        $this->response->goBack();
    }

    /**
     * بازسازی کش پس از هر تغییر
     */
    private function rebuild(): void
    {
        try {
            Settings::flush();
            Cache::build();
        } catch (\Throwable $e) {
            // بازسازی بعدی خودکار انجام می‌شود
        }
    }

    /**
     * هگز آدرس‌های محافظت‌شده + IP فعلی مدیر (همیشه در جریان است)
     *
     * @return string[]
     */
    private function protectedHexesWithSelf(): array
    {
        $hexes = Store::protectedHexes();

        $current = Ip::normalize($this->request->getIp());
        if ($current !== null) {
            $hex = Ip::toHex($current);
            if ($hex !== null) {
                $hexes[] = $hex;
            }
        }

        return array_values(array_unique($hexes));
    }

    /**
     * خواندن مدت زمان ارسال‌شده از فرم (عدد + واحد) و تبدیل به ثانیه
     */
    private function durationToSeconds(): int
    {
        $expires = (int) $this->request->get('expires', 0);

        if ($expires > 0) {
            return $expires > time() ? $expires - time() : 0;
        }

        $duration = (int) $this->request->get('duration', 0);
        $unit = (string) $this->request->get('unit', 'h');

        if ($duration <= 0) {
            return 0;
        }

        return match ($unit) {
            'm' => $duration * 60,
            'd' => $duration * 86400,
            'w' => $duration * 604800,
            default => $duration * 3600,
        };
    }

    // ------------------------------------------------------------------
    // عملیات قوانین
    // ------------------------------------------------------------------

    /**
     * افزودن قانون جدید
     */
    private function doAdd(): void
    {
        $value = (string) $this->request->get('value', '');
        $mode = (string) $this->request->get('mode', 'permanent');
        $reason = (string) $this->request->get('reason', '');

        $expires = 0;
        if ($mode === 'temporary') {
            $seconds = $this->durationToSeconds();
            $expires = time() + max(60, $seconds);

            if ($seconds <= 0) {
                $this->failure('برای بلاک موقت باید مدت زمان معتبری وارد کنید.');

                return;
            }
        }

        $result = Store::add($value, $mode, $expires, $reason, (int) $this->user->uid, $this->protectedHexesWithSelf());

        if ($result['ok']) {
            $this->success('آدرس «' . $result['rule']['value'] . '» با موفقیت ' . ($result['action'] === 'updated' ? 'به‌روزرسانی' : 'مسدود') . ' شد.');
        } else {
            $this->failure($result['message']);
        }
    }

    /**
     * حذف قوانین انتخابی
     */
    private function doDelete(): void
    {
        $ids = $this->getIdsArray('ids');
        $count = Store::delete($ids);

        $this->success($count > 0
            ? $count . ' قانون با موفقیت حذف شد.'
            : 'هیچ قانونی برای حذف انتخاب نشده بود.');
    }

    /**
     * فعال/غیرفعال‌کردن یک قانون
     */
    private function doToggle(): void
    {
        $id = (int) $this->request->get('id', 0);
        $enabled = (string) $this->request->get('state', '1') === '1';

        if ($id <= 0) {
            $this->failure('شناسه‌ی قانون نامعتبر است.');
        }

        Store::setEnabled($id, $enabled);
        $this->success($enabled ? 'قانون فعال شد.' : 'قانون غیرفعال شد (بدون حذف).');
    }

    /**
     * تمدید بلاک موقت
     */
    private function doExtend(): void
    {
        $id = (int) $this->request->get('id', 0);
        $seconds = $this->durationToSeconds();

        if ($id <= 0 || $seconds <= 0) {
            $this->failure('اطلاعات تمدید نامعتبر است.');

            return;
        }

        $newExpires = Store::extend($id, $seconds);

        if ($newExpires > 0) {
            $this->success('انقضای بلاک تمدید شد.');
        } else {
            $this->failure('قانون موردنظر یافت نشد.');
        }
    }

    /**
     * حذف قوانین منقضی‌شده
     */
    private function doPurgeExpired(): void
    {
        $count = Store::purgeExpired();
        $this->success($count > 0 ? $count . ' قانون منقضی حذف شد.' : 'قانون منقضی‌ای برای حذف وجود ندارد.');
    }

    /**
     * بازسازی دستی کش
     */
    private function doRebuildCache(): void
    {
        $this->rebuild();
        $this->success('کش با موفقیت بازسازی شد.');
    }

    /**
     * پاک‌سازی لیست IP های محافظت‌شده‌ی مدیران
     */
    private function doClearProtected(): void
    {
        Store::clearProtectedIps();
        $this->rebuild();

        // IP فعلی مدیر بلافاصله دوباره ثبت می‌شود
        $current = Ip::normalize($this->request->getIp());
        if ($current !== null) {
            Store::touchProtectedIp($current);
            $this->rebuild();
        }

        $this->success('لیست IP های محافظت‌شده به‌روزرسانی شد.');
    }

    /**
     * افزودن سریع IP از روی لاگ
     */
    private function doQuickBlock(): void
    {
        $ip = (string) $this->request->get('ip', '');
        $reason = (string) $this->request->get('reason', '');

        if ($reason === '') {
            $reason = 'مسدودسازی سریع از روی لاگ درخواست‌ها';
        }

        $result = Store::add($ip, 'permanent', 0, $reason, (int) $this->user->uid, $this->protectedHexesWithSelf());

        if ($result['ok']) {
            $this->success('IP «' . $result['rule']['value'] . '» مسدود شد.');
        } else {
            $this->failure($result['message']);
        }
    }

    // ------------------------------------------------------------------
    // عملیات لاگ
    // ------------------------------------------------------------------

    private function doLogsDelete(): void
    {
        $count = Logger::delete($this->getIdsArray('ids'));

        $this->success($count > 0 ? $count . ' رکورد لاگ حذف شد.' : 'هیچ رکوردی انتخاب نشده بود.');
    }

    private function doLogsPurge(): void
    {
        $count = Logger::purgeAll();
        $this->success($count . ' رکورد لاگ پاک‌سازی شد.');
    }

    private function doLogsCleanup(): void
    {
        $days = (int) $this->request->get('days', 30);
        $count = Logger::cleanup($days);

        $this->success($count . ' رکورد قدیمی‌تر از ' . $days . ' روز حذف شد.');
    }

    // ------------------------------------------------------------------
    // ایمپورت / اکسپورت
    // ------------------------------------------------------------------

    private function doImport(): void
    {
        $json = (string) $this->request->get('json', '');

        // پشتیبانی از فایل آپلودی
        if ($json === '' && isset($_FILES['file']) && ($_FILES['file']['error'] ?? 1) === UPLOAD_ERR_OK) {
            $size = (int) ($_FILES['file']['size'] ?? 0);

            if ($size > 0 && $size <= 5 * 1024 * 1024) {
                $content = @file_get_contents($_FILES['file']['tmp_name']);
                if (is_string($content) && $content !== '') {
                    $json = $content;
                }
            }
        }

        if (trim($json) === '') {
            $this->failure('محتوای JSON برای ایمپورت وارد نشده است.');

            return;
        }

        $mode = (string) $this->request->get('mode', Transfer::MODE_MERGE);
        if (!in_array($mode, [Transfer::MODE_MERGE, Transfer::MODE_UPDATE, Transfer::MODE_REPLACE], true)) {
            $mode = Transfer::MODE_MERGE;
        }

        $report = Transfer::import($json, $mode, $this->protectedHexesWithSelf());

        $message = 'ایمپورت انجام شد — ' . $report['added'] . ' قانون جدید، '
            . $report['updated'] . ' به‌روزرسانی، '
            . $report['skipped'] . ' رد شده، '
            . $report['invalid'] . ' نامعتبر.';

        if (!empty($report['notes'])) {
            $message .= "\n" . implode("\n", array_slice($report['notes'], 0, 8));
            if (count($report['notes']) > 8) {
                $message .= "\nو " . (count($report['notes']) - 8) . ' مورد دیگر...';
            }
        }

        $this->rebuild();
        Notice::alloc()->set($message, $report['ok'] ? 'success' : 'error');
        $this->response->goBack();
    }

    /**
     * دانلود فایل اکسپورت JSON (تنها عملیات GET)
     */
    private function doExport(): void
    {
        $json = Transfer::exportJson();

        $this->response
            ->setHeader('Content-Length', (string) strlen($json))
            ->setHeader('Content-Disposition', 'attachment; filename="ipblocker-rules-' . date('Ymd-His') . '.json"')
            ->setHeader('Cache-Control', 'no-store')
            ->setHeader('X-Content-Type-Options', 'nosniff')
            ->throwCallback(static function () use ($json): void {
                echo $json;
            }, 'application/json');
    }

    // ------------------------------------------------------------------
    // ابزار
    // ------------------------------------------------------------------

    /**
     * خواندن آرایه‌ی شناسه‌ها از درخواست (با اعتبارسنجی کامل)
     *
     * @return int[]
     */
    private function getIdsArray(string $key): array
    {
        $raw = $this->request->get($key, []);

        if (!is_array($raw)) {
            $raw = [$raw];
        }

        $ids = [];
        foreach ($raw as $value) {
            $id = (int) $value;
            if ($id > 0) {
                $ids[] = $id;
            }
        }

        return array_values(array_unique($ids));
    }
}
