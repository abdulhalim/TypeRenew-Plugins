<?php
/**
 * Settings — خواندن تنظیمات پلاگین با مقادیر پیش‌فرض امن
 *
 * @package IPBlocker
 * @since   1.0.0
 */

namespace TypechoPlugin\IPBlocker\lib;

use Typecho\Config;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Settings
{
    /**
     * مقادیر پیش‌فرض تنظیمات
     */
    public const DEFAULTS = [
        // کلید اصلی: آیا مسدودسازی فعال است؟
        'enabled' => '1',

        // پیام نمایش‌داده‌شده به بازدیدکننده‌ی مسدود (کد 403)
        'blockMessage' => 'دسترسی شما به این سایت محدود شده است. در صورت اعتراض لطفاً با مدیر سایت تماس بگیرید.',

        // اعمال مسدودسازی روی صفحات پنل مدیریت هم (ضد حمله‌ی brute-force)
        'blockAdmin' => '1',

        // ثبت و محافظت خودکار IP مدیران واردشده
        'protectAdminIps' => '1',

        // لیست سفید اضافی (هر خط: یک IP یا بازه CIDR)
        'extraWhitelist' => '',

        // فعال‌سازی ثبت لاگ
        'logEnabled' => '1',

        // پاکسازی خودکار لاگ‌های قدیمی‌تر از این تعداد روز (۰ = غیرفعال)
        'logRetentionDays' => '90',

        // حداکثر لاگ ثبت‌شده برای هر IP در هر ساعت — ضد سیلابی (۰ = نامحدود)
        'logMaxPerHour' => '120',
    ];

    /** کش درخواست‌جاری */
    private static ?array $cache = null;

    /**
     * دریافت تمام تنظیمات ادغام‌شده با پیش‌فرض‌ها
     *
     * @return array<string,mixed>
     */
    public static function get(): array
    {
        if (self::$cache !== null) {
            return self::$cache;
        }

        $values = self::DEFAULTS;

        try {
            /** @var Config $config */
            $config = \Widget\Options::alloc()->plugin('IPBlocker');
            $saved = $config->toArray();

            foreach ($values as $key => $default) {
                if (array_key_exists($key, $saved) && $saved[$key] !== null && $saved[$key] !== '') {
                    $values[$key] = $saved[$key];
                }
            }
        } catch (\Throwable $e) {
            // تنظیمات ذخیره نشده است؛ پیش‌فرض‌ها استفاده می‌شوند
        }

        // نرمال‌سازی مقادیر عددی و بولیِ رشته‌ای
        $values['enabled'] = self::toBool($values['enabled']) ? '1' : '0';
        $values['blockAdmin'] = self::toBool($values['blockAdmin']) ? '1' : '0';
        $values['protectAdminIps'] = self::toBool($values['protectAdminIps']) ? '1' : '0';
        $values['logEnabled'] = self::toBool($values['logEnabled']) ? '1' : '0';
        $values['logRetentionDays'] = (string) max(0, (int) $values['logRetentionDays']);
        $values['logMaxPerHour'] = (string) max(0, (int) $values['logMaxPerHour']);

        return self::$cache = $values;
    }

    /**
     * دریافت یک تنظیم خاص
     *
     * @param string $key نام تنظیم
     * @param mixed  $default مقدار جایگزین
     * @return mixed
     */
    public static function option(string $key, $default = null)
    {
        $all = self::get();

        return $all[$key] ?? $default;
    }

    /**
     * تبدیل مقدار به بولی (پشتیبانی از '0'/'1'/true/false)
     */
    private static function toBool($value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        return in_array((string) $value, ['1', 'true', 'yes', 'on'], true);
    }

    /**
     * پاک‌سازی کش درخواست (پس از ذخیره‌ی تنظیمات جدید)
     */
    public static function flush(): void
    {
        self::$cache = null;
    }
}
