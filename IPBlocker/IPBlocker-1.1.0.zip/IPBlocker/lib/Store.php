<?php
/**
 * Store — لایه‌ی دسترسی به دیتابیس برای قوانین مسدودسازی
 *
 * مسئولیت‌ها:
 *  - ساخت جداول پلاگین (سازگار با MySQL / PostgreSQL / SQLite)
 *  - افزودن، ویرایش، حذف و فهرست‌کردن قوانین با فیلتر و صفحه‌بندی
 *  - نگهداری لیست IP های مدیرانِ محافظت‌شده
 *  - آمار برای داشبورد پنل
 *
 * تمام کوئری‌ها از سازنده‌ی کوئری Typecho با پارامترهای مقیدشده استفاده
 * می‌کنند تا هیچ راهی برای SQL Injection باقی نماند.
 *
 * @package IPBlocker
 * @since   1.0.0
 */

namespace TypechoPlugin\IPBlocker\lib;

use Typecho\Db;
use Typecho\Db\Adapter\SQLException;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Store
{
    /** نام جدول قوانین (بدون پیشوند) */
    public const TABLE_BLOCKS = 'ipblocker_blocks';

    /** نام کلید گزینه‌ی IP های محافظت‌شده‌ی مدیران */
    public const OPTION_PROTECTED = 'ipblocker:protected';

    /** حداکثر تعداد IP مدیر که به‌صورت خودکار نگه داشته می‌شود */
    public const PROTECTED_MAX = 30;

    // ------------------------------------------------------------------
    // زیرساخت
    // ------------------------------------------------------------------

    /**
     * نام جدول با پیشوند
     */
    public static function table(string $name): string
    {
        return 'table.' . $name;
    }

    /**
     * تشخیص دیالکت دیتابیس
     */
    public static function dialect(): string
    {
        try {
            $adapter = strtolower((string) Db::get()->getAdapterName());
        } catch (\Throwable $e) {
            return 'mysql';
        }

        if (str_contains($adapter, 'sqlite')) {
            return 'sqlite';
        }

        if (str_contains($adapter, 'pgsql')) {
            return 'pgsql';
        }

        return 'mysql';
    }

    /**
     * ساخت جداول پلاگین (اگر موجود نباشند)
     */
    public static function ensureSchema(): void
    {
        $db = Db::get();
        $prefix = $db->getPrefix();

        $blocksTable = $prefix . self::TABLE_BLOCKS;

        $db->query(self::blocksSchemaSql($blocksTable), Db::WRITE);

        // ایندکس‌های تکمیلی (در MySQL داخل CREATE TABLE قرار دارند)
        foreach (self::extraIndexSql($prefix) as $indexSql) {
            try {
                $db->query($indexSql, Db::WRITE);
            } catch (\Throwable $e) {
                // ایندکس از قبل وجود دارد یا دیالکت پشتیبانی نمی‌کند — بی‌خطر است
            }
        }
    }

    /**
     * SQL ساخت جدول قوانین بر اساس دیالکت
     */
    private static function blocksSchemaSql(string $table): string
    {
        return match (self::dialect()) {
            'sqlite' => 'CREATE TABLE IF NOT EXISTS "' . $table . '" ('
                . '"id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,'
                . '"value" varchar(64) NOT NULL DEFAULT \'\','
                . '"isCidr" int(10) NOT NULL DEFAULT 0,'
                . '"prefix" int(10) NOT NULL DEFAULT 0,'
                . '"version" varchar(4) NOT NULL DEFAULT \'ipv4\','
                . '"mode" varchar(16) NOT NULL DEFAULT \'permanent\','
                . '"expires" int(10) NOT NULL DEFAULT 0,'
                . '"reason" varchar(500) NOT NULL DEFAULT \'\','
                . '"enabled" int(10) NOT NULL DEFAULT 1,'
                . '"hits" int(10) NOT NULL DEFAULT 0,'
                . '"created" int(10) NOT NULL DEFAULT 0,'
                . '"updated" int(10) NOT NULL DEFAULT 0,'
                . '"createdBy" int(10) NOT NULL DEFAULT 0,'
                . 'UNIQUE ("value"))',
            'pgsql' => 'CREATE TABLE IF NOT EXISTS "' . $table . '" ('
                . '"id" BIGSERIAL PRIMARY KEY,'
                . '"value" VARCHAR(64) NOT NULL DEFAULT \'\','
                . '"isCidr" SMALLINT NOT NULL DEFAULT 0,'
                . '"prefix" SMALLINT NOT NULL DEFAULT 0,'
                . '"version" VARCHAR(4) NOT NULL DEFAULT \'ipv4\','
                . '"mode" VARCHAR(16) NOT NULL DEFAULT \'permanent\','
                . '"expires" BIGINT NOT NULL DEFAULT 0,'
                . '"reason" VARCHAR(500) NOT NULL DEFAULT \'\','
                . '"enabled" SMALLINT NOT NULL DEFAULT 1,'
                . '"hits" BIGINT NOT NULL DEFAULT 0,'
                . '"created" BIGINT NOT NULL DEFAULT 0,'
                . '"updated" BIGINT NOT NULL DEFAULT 0,'
                . '"createdBy" BIGINT NOT NULL DEFAULT 0,'
                . 'CONSTRAINT "' . $table . '_uniq_value" UNIQUE ("value"))',
            default => 'CREATE TABLE IF NOT EXISTS `' . $table . '` ('
                . '`id` bigint unsigned NOT NULL auto_increment,'
                . '`value` varchar(64) NOT NULL DEFAULT \'\','
                . '`isCidr` tinyint unsigned NOT NULL DEFAULT 0,'
                . '`prefix` smallint unsigned NOT NULL DEFAULT 0,'
                . '`version` varchar(4) NOT NULL DEFAULT \'ipv4\','
                . '`mode` varchar(16) NOT NULL DEFAULT \'permanent\','
                . '`expires` int unsigned NOT NULL DEFAULT 0,'
                . '`reason` varchar(500) NOT NULL DEFAULT \'\','
                . '`enabled` tinyint unsigned NOT NULL DEFAULT 1,'
                . '`hits` int unsigned NOT NULL DEFAULT 0,'
                . '`created` int unsigned NOT NULL DEFAULT 0,'
                . '`updated` int unsigned NOT NULL DEFAULT 0,'
                . '`createdBy` int unsigned NOT NULL DEFAULT 0,'
                . 'PRIMARY KEY (`id`),'
                . 'UNIQUE KEY `uniq_value` (`value`),'
                . 'KEY `idx_expires` (`expires`),'
                . 'KEY `idx_mode_enabled` (`mode`, `enabled`),'
                . 'KEY `idx_created` (`created`))'
                . ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
        };
    }

    /**
     * ایندکس‌های تکمیلی برای PostgreSQL و SQLite
     *
     * @return string[]
     */
    private static function extraIndexSql(string $prefix): array
    {
        if (self::dialect() === 'mysql') {
            return [];
        }

        $t = $prefix . self::TABLE_BLOCKS;

        return [
            'CREATE INDEX IF NOT EXISTS "idx_' . $t . '_expires" ON "' . $t . '" ("expires")',
            'CREATE INDEX IF NOT EXISTS "idx_' . $t . '_created" ON "' . $t . '" ("created")',
        ];
    }

    // ------------------------------------------------------------------
    // عملیات قوانین
    // ------------------------------------------------------------------

    /**
     * افزودن یا به‌روزرسانی یک قانون
     *
     * @param string $input         ورودی کاربر (IP یا CIDR)
     * @param string $mode          permanent | temporary
     * @param int    $expires       زمان انقضا (Unix Timestamp؛ برای دائمی ۰)
     * @param string $reason        دلیل مسدودسازی
     * @param int    $uid           شناسه‌ی مدیر
     * @param array  $protectedHexes هگز آدرس‌های محافظت‌شده (برای جلوگیری از قفل‌شدن مدیر)
     *
     * @return array{ok:bool,action:string,message:string,rule?:array}
     */
    public static function add(string $input, string $mode, int $expires, string $reason, int $uid, array $protectedHexes = []): array
    {
        $rule = Ip::parseRule($input);

        if ($rule === null) {
            return ['ok' => false, 'action' => 'invalid', 'message' => 'فرمت آدرس واردشده معتبر نیست. نمونه‌های صحیح: 192.0.2.15 — 10.0.0.0/8 — 2001:db8::1 — 2001:db8::/32'];
        }

        if (!in_array($mode, ['permanent', 'temporary'], true)) {
            $mode = 'permanent';
        }

        if ($mode === 'temporary' && $expires <= time()) {
            return ['ok' => false, 'action' => 'invalid', 'message' => 'زمان انقضای بلاک موقت باید در آینده باشد.'];
        }

        if ($mode === 'permanent') {
            $expires = 0;
        }

        $reason = self::cleanReason($reason);

        // 🔒 محافظت از مدیر: قانون نباید هیچ IP محافظت‌شده‌ای را پوشش دهد
        foreach ($protectedHexes as $protectedHex) {
            if (Ip::ruleCoversHex($rule, (string) $protectedHex)) {
                return [
                    'ok' => false,
                    'action' => 'protected',
                    'message' => 'این قانون آدرس IP مدیر یا آدرس‌های لیست سفید را پوشش می‌دهد و به‌دلیل جلوگیری از قفل‌شدن پنل مدیریت اضافه نشد.',
                ];
            }
        }

        $db = Db::get();
        $now = time();

        $existing = $db->fetchRow(
            $db->select()->from(self::table(self::TABLE_BLOCKS))->where('value = ?', $rule['value'])->limit(1)
        );

        $row = [
            'value'   => $rule['value'],
            'isCidr'  => $rule['isCidr'] ? 1 : 0,
            'prefix'  => (int) $rule['prefix'],
            'version' => $rule['version'],
            'mode'    => $mode,
            'expires' => $expires,
            'reason'  => $reason,
            'enabled' => 1,
            'updated' => $now,
        ];

        try {
            if (!empty($existing)) {
                $db->query(
                    $db->update(self::table(self::TABLE_BLOCKS))
                        ->rows($row)
                        ->where('id = ?', (int) $existing['id'])
                );

                $row['id'] = (int) $existing['id'];

                return [
                    'ok'     => true,
                    'action' => 'updated',
                    'message' => 'قانون موجود با همین آدرس به‌روزرسانی شد.',
                    'rule'   => $row,
                ];
            }

            $row['created'] = $now;
            $row['createdBy'] = $uid;
            $row['hits'] = 0;

            $db->query($db->insert(self::table(self::TABLE_BLOCKS))->rows($row));

            return [
                'ok'     => true,
                'action' => 'added',
                'message' => 'قانون مسدودسازی جدید اضافه شد.',
                'rule'   => $row,
            ];
        } catch (SQLException $e) {
            // رخداد نادرِ هم‌زمانی: قانون همین حالا درج شده است
            return ['ok' => false, 'action' => 'conflict', 'message' => 'این قانون همین‌قبلاً ثبت شده بود؛ دوباره تلاش کنید.'];
        }
    }

    /**
     * پاک‌سازی متن دلیل (حذف کاراکترهای کنترلی، محدودکردن طول)
     */
    public static function cleanReason(string $reason): string
    {
        $reason = trim(preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $reason) ?? $reason);

        return mb_substr($reason, 0, 480, 'UTF-8');
    }

    /**
     * یافتن قانون بر اساس مقدار کانونی
     *
     * @param string $value مقدار (IP یا CIDR استاندارد)
     * @return array|null ردیف قانون یا null
     */
    public static function findValue(string $value): ?array
    {
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select()->from(self::table(self::TABLE_BLOCKS))
                    ->where('value = ?', $value)->limit(1)
            );

            return empty($row) ? null : $row;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * حذف قوانین بر اساس آرایه‌ای از شناسه‌ها
     *
     * @param int[] $ids
     * @return int تعداد حذف‌شده‌ها
     */
    public static function delete(array $ids): int
    {
        $ids = array_values(array_filter(array_map('intval', $ids), static fn ($id) => $id > 0));
        if (empty($ids)) {
            return 0;
        }

        $db = Db::get();
        $count = 0;

        foreach ($ids as $id) {
            $db->query($db->delete(self::table(self::TABLE_BLOCKS))->where('id = ?', $id));
            $count++;
        }

        return $count;
    }

    /**
     * فعال/غیرفعال‌کردن قانون
     */
    public static function setEnabled(int $id, bool $enabled): bool
    {
        $db = Db::get();

        $db->query(
            $db->update(self::table(self::TABLE_BLOCKS))
                ->rows(['enabled' => $enabled ? 1 : 0, 'updated' => time()])
                ->where('id = ?', $id)
        );

        return true;
    }

    /**
     * تمدید بلاک موقت (بر پایه‌ی زمان فعلی یا زمان انقضای موجود)
     *
     * @param int $id       شناسه‌ی قانون
     * @param int $seconds مدت تمدید به ثانیه
     * @return int زمان انقضای جدید
     */
    public static function extend(int $id, int $seconds): int
    {
        $db = Db::get();
        $row = $db->fetchRow(
            $db->select('expires', 'mode')->from(self::table(self::TABLE_BLOCKS))->where('id = ?', $id)->limit(1)
        );

        if (empty($row)) {
            return 0;
        }

        $base = max(time(), (int) $row['expires']);
        $newExpires = $base + max(60, $seconds);

        $db->query(
            $db->update(self::table(self::TABLE_BLOCKS))
                ->rows(['expires' => $newExpires, 'mode' => 'temporary', 'updated' => time(), 'enabled' => 1])
                ->where('id = ?', $id)
        );

        return $newExpires;
    }

    /**
     * حذف قوانین موقتِ منقضی‌شده
     *
     * @return int تعداد حذف‌شده‌ها
     */
    public static function purgeExpired(): int
    {
        $db = Db::get();
        $rows = $db->fetchAll(
            $db->select('id')->from(self::table(self::TABLE_BLOCKS))
                ->where('mode = ?', 'temporary')
                ->where('expires > 0 AND expires <= ?', time())
        );

        $ids = array_map(static fn ($r) => (int) $r['id'], $rows);

        return empty($ids) ? 0 : self::delete($ids);
    }

    /**
     * همه‌ی قوانینِ فعال برای ساخت کش
     *
     * @return array<int,array<string,mixed>>
     */
    public static function fetchForCache(): array
    {
        $db = Db::get();

        try {
            return $db->fetchAll(
                $db->select('id', 'value', 'isCidr', 'prefix', 'version', 'expires', 'reason')
                    ->from(self::table(self::TABLE_BLOCKS))
                    ->where('enabled = ?', 1)
                    ->order('prefix', Db::SORT_DESC)
            );
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * افزایش شمارنده‌ی بازدیدهای مسدودشده‌ی یک قانون
     */
    public static function incrementHits(int $id): void
    {
        if ($id <= 0) {
            return;
        }

        try {
            $db = Db::get();
            $db->query(
                $db->update(self::table(self::TABLE_BLOCKS))
                    ->expression('hits', 'hits + 1', false)
                    ->where('id = ?', $id)
            );
        } catch (\Throwable $e) {
            // شمارنده‌ی آماری است؛ خطا نباید جریان را متوقف کند
        }
    }

    // ------------------------------------------------------------------
    // فهرست‌کردن و آمار
    // ------------------------------------------------------------------

    /**
     * فهرست قوانین با فیلتر و صفحه‌بندی
     *
     * @param array $filters [q, type(all|permanent|temporary|expired), version(all|ipv4|ipv6), status(all|enabled|disabled)]
     * @param int   $page    شماره‌ی صفحه (از ۱)
     * @param int   $perPage تعداد ردیف در هر صفحه
     *
     * @return array{rows:array,total:int,page:int,perPage:int,pages:int}
     */
    public static function list(array $filters = [], int $page = 1, int $perPage = 20): array
    {
        $db = Db::get();
        $perPage = max(1, min(200, $perPage));
        $page = max(1, $page);

        $select = $db->select()->from(self::table(self::TABLE_BLOCKS));
        $countSelect = $db->select('COUNT(id) AS num')->from(self::table(self::TABLE_BLOCKS));

        $apply = static function ($select) use ($filters) {
            $q = trim((string) ($filters['q'] ?? ''));
            if ($q !== '') {
                $kw = '%' . addcslashes($q, "%_\\") . '%';
                $select->where('(value LIKE ? OR reason LIKE ?)', $kw, $kw);
            }

            $type = (string) ($filters['type'] ?? 'all');
            if ($type === 'permanent') {
                $select->where('mode = ?', 'permanent');
            } elseif ($type === 'temporary') {
                $select->where('mode = ? AND expires > ?', 'temporary', time());
            } elseif ($type === 'expired') {
                $select->where('mode = ? AND expires > 0 AND expires <= ?', 'temporary', time());
            }

            $version = (string) ($filters['version'] ?? 'all');
            if ($version === 'ipv4' || $version === 'ipv6') {
                $select->where('version = ?', $version);
            }

            $status = (string) ($filters['status'] ?? 'all');
            if ($status === 'enabled') {
                $select->where('enabled = ?', 1);
            } elseif ($status === 'disabled') {
                $select->where('enabled = ?', 0);
            }
        };

        $apply($select);
        $apply($countSelect);

        $total = (int) ($db->fetchRow($countSelect)['num'] ?? 0);
        $pages = max(1, (int) ceil($total / $perPage));

        // صفحه‌ی درخواستی نمی‌تواند از تعداد صفحات بیشتر باشد
        if ($page > $pages && $total > 0) {
            $page = $pages;
        }

        $rows = $db->fetchAll(
            $select->order('created', Db::SORT_DESC)
                ->offset(($page - 1) * $perPage)
                ->limit($perPage)
        );

        return [
            'rows'    => is_array($rows) ? $rows : [],
            'total'   => $total,
            'page'    => $page,
            'perPage' => $perPage,
            'pages'   => $pages,
        ];
    }

    /**
     * آمار کلی برای داشبورد پنل
     */
    public static function stats(): array
    {
        $db = Db::get();
        $now = time();

        $defaults = [
            'total'      => 0,
            'permanent'  => 0,
            'temporary'  => 0,
            'expired'    => 0,
            'disabled'   => 0,
            'hits'       => 0,
            'ipv4'       => 0,
            'ipv6'       => 0,
        ];

        try {
            $rows = $db->fetchAll(
                $db->select('mode', 'expires', 'enabled', 'version', 'hits')
                    ->from(self::table(self::TABLE_BLOCKS))
            );
        } catch (\Throwable $e) {
            return $defaults;
        }

        foreach ($rows as $row) {
            $defaults['total']++;
            $defaults['hits'] += (int) ($row['hits'] ?? 0);

            if ((int) ($row['enabled'] ?? 1) === 0) {
                $defaults['disabled']++;
            }

            if (($row['mode'] ?? '') === 'temporary') {
                if ((int) ($row['expires'] ?? 0) > 0 && (int) $row['expires'] <= $now) {
                    $defaults['expired']++;
                } else {
                    $defaults['temporary']++;
                }
            } else {
                $defaults['permanent']++;
            }

            if (($row['version'] ?? '') === Ip::VERSION_V6) {
                $defaults['ipv6']++;
            } else {
                $defaults['ipv4']++;
            }
        }

        return $defaults;
    }

    // ------------------------------------------------------------------
    // IP های محافظت‌شده‌ی مدیران
    // ------------------------------------------------------------------

    /**
     * دریافت لیست IP های محافظت‌شده‌ی مدیران
     *
     * @return array<string,int> [ip => آخرین بازدید]
     */
    public static function protectedIps(): array
    {
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('value')->from('table.options')->where('name = ? AND user = 0', self::OPTION_PROTECTED)->limit(1)
            );

            if (empty($row['value'])) {
                return [];
            }

            $data = json_decode((string) $row['value'], true);

            return is_array($data) ? $data : [];
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * هگز آدرس‌های محافظت‌شده (مدیران + لیست سفید)
     *
     * @return string[]
     */
    public static function protectedHexes(): array
    {
        $hexes = [];

        foreach (array_keys(self::protectedIps()) as $ip) {
            $hex = Ip::toHex((string) $ip);
            if ($hex !== null) {
                $hexes[] = $hex;
            }
        }

        // لیست سفید اضافی از تنظیمات
        $whitelist = (string) Settings::option('extraWhitelist', '');
        foreach (preg_split('/\r\n|\r|\n/', $whitelist) ?: [] as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#')) {
                continue;
            }

            $hex = Ip::toHex(Ip::sanitize($line));
            if ($hex !== null) {
                $hexes[] = $hex;
            }
        }

        return array_values(array_unique($hexes));
    }

    /**
     * ثبت/به‌روزرسانی IP مدیر در لیست محافظت‌شده‌ها
     *
     * @return bool آیا تغییری انجام شد؟
     */
    public static function touchProtectedIp(string $ip): bool
    {
        $ip = Ip::normalize($ip);
        if ($ip === null) {
            return false;
        }

        $list = self::protectedIps();
        $now = time();

        if (isset($list[$ip]) && $list[$ip] > $now - 3600) {
            return false; // همین‌قبلاً و همین‌اواخر ثبت شده است
        }

        $list[$ip] = $now;

        // هرس کردن قدیمی‌ترین‌ها در صورت عبور از سقف
        if (count($list) > self::PROTECTED_MAX) {
            asort($list);
            $list = array_slice($list, -self::PROTECTED_MAX, preserve_keys: true);
        }

        self::saveProtectedIps($list);

        return true;
    }

    /**
     * ذخیره‌ی لیست IP های محافظت‌شده
     *
     * @param array<string,int> $list
     */
    private static function saveProtectedIps(array $list): void
    {
        $db = Db::get();
        $json = json_encode($list, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '{}';

        try {
            $row = $db->fetchRow(
                $db->select('name')->from('table.options')
                    ->where('name = ? AND user = 0', self::OPTION_PROTECTED)->limit(1)
            );

            if (empty($row)) {
                $db->query(
                    $db->insert('table.options')->rows([
                        'name'  => self::OPTION_PROTECTED,
                        'user'  => 0,
                        'value' => $json,
                    ])
                );
            } else {
                $db->query(
                    $db->update('table.options')->rows(['value' => $json])
                        ->where('name = ? AND user = 0', self::OPTION_PROTECTED)
                );
            }
        } catch (\Throwable $e) {
            // ثبت محافظت اختیاری است؛ خطا نباید پنل را بشکند
        }
    }

    /**
     * حذف یک IP از لیست محافظت‌شده‌ها
     */
    public static function removeProtectedIp(string $ip): bool
    {
        $ip = Ip::normalize($ip);
        if ($ip === null) {
            return false;
        }

        $list = self::protectedIps();
        if (!isset($list[$ip])) {
            return false;
        }

        unset($list[$ip]);
        self::saveProtectedIps($list);

        return true;
    }

    /**
     * پاک‌سازی کامل لیست محافظت‌شده‌ها
     */
    public static function clearProtectedIps(): void
    {
        self::saveProtectedIps([]);
    }
}
