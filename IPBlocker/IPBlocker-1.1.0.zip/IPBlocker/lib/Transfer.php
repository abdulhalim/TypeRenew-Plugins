<?php
/**
 * Transfer — ایمپورت و اکسپورت لیست قوانین به فرمت JSON
 *
 * @package IPBlocker
 * @since   1.0.0
 */

namespace TypechoPlugin\IPBlocker\lib;

use Typecho\Common;
use Typecho\Db;
use TypechoPlugin\IPBlocker\Plugin as CorePlugin;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Transfer
{
    /** حالت‌های ایمپورت */
    public const MODE_MERGE = 'merge';       // نادیده‌گرفتن موارد تکراری
    public const MODE_UPDATE = 'update';     // به‌روزرسانی موارد تکراری
    public const MODE_REPLACE = 'replace';   // پاک‌سازی کامل و جایگزینی

    /**
     * ساخت ساختار اکسپورت کامل
     */
    public static function export(): array
    {
        $db = Db::get();

        $rows = $db->fetchAll(
            $db->select('value', 'mode', 'expires', 'reason', 'created')
                ->from(Store::table(Store::TABLE_BLOCKS))
                ->order('created', Db::SORT_DESC)
        );

        $rules = [];
        foreach ((array) $rows as $row) {
            $rules[] = [
                'value'   => (string) $row['value'],
                'mode'    => (string) $row['mode'],
                'expires' => (int) $row['expires'],
                'reason'  => (string) $row['reason'],
            ];
        }

        return [
            'plugin'     => 'IPBlocker',
            'format'     => 'ipblocker-rules',
            'formatVer'  => 1,
            'version'    => CorePlugin::VERSION,
            'exportedAt' => time(),
            'exportedAtJalali' => Jalali::full(time()),
            'count'      => count($rules),
            'rules'      => $rules,
        ];
        // نگه‌داشته‌شدن عمدی فیلدهای فنی (id, hits, ...) در اکسپورت؛
        // ایمپورت مقادیر آماری را بازسازی نمی‌کند.
    }

    /**
     * رشته‌ی JSON اکسپورت
     */
    public static function exportJson(): string
    {
        return (string) Common::jsonEncode(self::export(), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }

    /**
     * اعتبارسنجی اولیه‌ی ساختار JSON بدون درج
     *
     * @return array{ok:bool,count:int,error?:string}
     */
    public static function inspect(string $json): array
    {
        $data = json_decode($json, true);

        if (!is_array($data)) {
            return ['ok' => false, 'count' => 0, 'error' => 'فایل JSON معتبر نیست.'];
        }

        $rules = self::extractRules($data);
        if ($rules === null) {
            return ['ok' => false, 'count' => 0, 'error' => 'ساختار فایل شناسایی نشد. باید شامل آرایه‌ای از قوانین یا کلید rules باشد.'];
        }

        return ['ok' => true, 'count' => count($rules)];
    }

    /**
     * اجرای ایمپورت
     *
     * @param string $json           محتوای JSON
     * @param string $mode           merge | update | replace
     * @param array  $protectedHexes هگز IP های محافظت‌شده
     *
     * @return array{ok:bool,added:int,updated:int,skipped:int,invalid:int,total:int,notes:string[]}
     */
    public static function import(string $json, string $mode, array $protectedHexes = []): array
    {
        $report = [
            'ok'      => false,
            'added'   => 0,
            'updated' => 0,
            'skipped' => 0,
            'invalid' => 0,
            'total'   => 0,
            'notes'   => [],
        ];

        $data = json_decode($json, true);
        if (!is_array($data)) {
            $report['notes'][] = 'فایل JSON معتبر نیست.';

            return $report;
        }

        $rules = self::extractRules($data);
        if ($rules === null) {
            $report['notes'][] = 'ساختار فایل شناسایی نشد؛ آرایه‌ای از قوانین یا کلید rules لازم است.';

            return $report;
        }

        if (empty($rules)) {
            $report['notes'][] = 'هیچ قانونی در فایل یافت نشد.';

            return $report;
        }

        $db = Db::get();
        $uid = self::currentAdminUid();
        $now = time();

        // حالت جایگزینی: پاک‌سازی کامل قوانین فعلی
        if ($mode === self::MODE_REPLACE) {
            $db->query($db->delete(Store::table(Store::TABLE_BLOCKS)));
            $report['notes'][] = 'همه‌ی قوانین قبلی حذف شدند (حالت جایگزینی).';
        }

        foreach ($rules as $index => $rule) {
            $report['total']++;

            $value = trim((string) ($rule['value'] ?? $rule['ip'] ?? ''));
            $mode2 = (string) ($rule['mode'] ?? 'permanent');
            $expires = (int) ($rule['expires'] ?? 0);
            $reason = Store::cleanReason((string) ($rule['reason'] ?? ''));

            if ($value === '') {
                $report['invalid']++;
                $report['notes'][] = 'ردیف ' . Ip::faNumber((string) ($index + 1)) . ': مقدار خالی — نادیده گرفته شد.';

                continue;
            }

            // اعتبارسنجی فرمت قبل از هر عملیات
            $parsed = Ip::parseRule($value);
            if ($parsed === null) {
                $report['invalid']++;
                $report['notes'][] = 'ردیف ' . Ip::faNumber((string) ($index + 1)) . ' («' . $value . '»): فرمت آدرس نامعتبر است.';

                continue;
            }

            if ($mode2 !== 'permanent' && $mode2 !== 'temporary') {
                $mode2 = 'permanent';
            }

            if ($mode2 === 'permanent') {
                $expires = 0;
            } elseif ($expires > 0 && $expires <= $now) {
                $report['skipped']++;
                $report['notes'][] = 'ردیف ' . Ip::faNumber((string) ($index + 1)) . ' («' . $value . '»): تاریخ انقضا گذشته است — نادیده گرفته شد.';

                continue;
            }

            // در حالت «ادغام»، قوانین تکراری دست‌نخورده می‌مانند
            if ($mode === self::MODE_MERGE && Store::findValue($parsed['value']) !== null) {
                $report['skipped']++;

                continue;
            }

            $result = Store::add($parsed['value'], $mode2, $expires, $reason, $uid, $protectedHexes);

            if ($result['ok']) {
                if ($result['action'] === 'updated') {
                    $report['updated']++;
                } else {
                    $report['added']++;
                }
            } elseif ($result['action'] === 'protected') {
                $report['skipped']++;
                $report['notes'][] = 'ردیف ' . Ip::faNumber((string) ($index + 1)) . ' («' . $value . '»): IP مدیر را پوشش می‌دهد — به‌دلیل امنیت نادیده گرفته شد.';
            } else {
                $report['skipped']++;
            }
        }

        $report['ok'] = ($report['added'] + $report['updated']) > 0;

        return $report;
    }

    /**
     * استخراج آرایه‌ی قوانین از ساختارهای مختلف JSON
     *
     * @return array|null
     */
    private static function extractRules(array $data): ?array
    {
        if (isset($data['rules']) && is_array($data['rules'])) {
            return array_values($data['rules']);
        }

        // آرایه‌ی خام از قوانین
        $isList = array_keys($data) === range(0, count($data) - 1);

        return $isList ? array_values($data) : null;
    }

    /**
     * شناسه‌ی مدیر فعلی (برای ثبت createdBy)
     */
    private static function currentAdminUid(): int
    {
        try {
            $user = \Widget\User::alloc();

            return (int) ($user->uid ?? 0);
        } catch (\Throwable $e) {
            return 0;
        }
    }
}
