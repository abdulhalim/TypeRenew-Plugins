<?php
/**
 * Ip — ابزارهای پردازش آدرس‌های IPv4 / IPv6 و بازه‌های CIDR
 *
 * این کلاس تمام منطق اعتبارسنجی، نرمال‌سازی و تطبیق آدرس‌های IP را
 * بر عهده دارد و کاملاً مستقل از دیتابیس کار می‌کند.
 *
 * @package IPBlocker
 * @since   1.0.0
 */

namespace TypechoPlugin\IPBlocker\lib;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Ip
{
    /** نسخه آدرس: IPv4 */
    public const VERSION_V4 = 'ipv4';

    /** نسخه آدرس: IPv6 */
    public const VERSION_V6 = 'ipv6';

    /** بایت‌های پیشوند نگاشت IPv4 داخل IPv6 (::ffff:0:0/96) */
    private const V4_IN_V6_PREFIX = "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff";

    /**
     * پاک‌سازی ورودی خام کاربر
     *
     * فضاهای خالی، براکت‌های IPv6، شناسه‌ی اینترفیس (%eth0) و
     * پورت انتهایی را حذف می‌کند تا رشته‌ی قابل‌پارس به دست آید.
     *
     * @param string $raw ورودی خام
     * @return string رشته‌ی پاک‌سازی‌شده
     */
    public static function sanitize(string $raw): string
    {
        $ip = trim($raw);

        // حذف شناسه‌ی اینترفیس: fe80::1%eth0
        $zonePos = strpos($ip, '%');
        if ($zonePos !== false) {
            $ip = substr($ip, 0, $zonePos);
        }

        // حذف براکت: [2001:db8::1] یا [2001:db8::1]:443
        if ($ip !== '' && $ip[0] === '[') {
            $close = strpos($ip, ']');
            if ($close !== false) {
                $rest = trim(substr($ip, $close + 1));
                $ip = substr($ip, 1, $close - 1);
                // اگر بعد از براکت پورت بود، نادیده گرفته می‌شود
                unset($rest);
            }
        }

        // حذف پورت انتهایی برای IPv4: 1.2.3.4:8080
        if (strpos($ip, ':') !== false && !self::looksLikeIpv6($ip)) {
            $ip = preg_replace('/:\d+$/', '', $ip) ?? $ip;
        }

        // حذف صفرهای ابتدایی هر بخش IPv4: 192.168.001.005 → 192.168.1.5
        if (preg_match('/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/', $ip, $m)) {
            $ip = (int) $m[1] . '.' . (int) $m[2] . '.' . (int) $m[3] . '.' . (int) $m[4];
        }

        return trim($ip);
    }

    /**
     * تشخیص سریع این‌که رشته شبیه IPv6 است (بدون پارس کامل)
     */
    private static function looksLikeIpv6(string $ip): bool
    {
        if ($ip === '') {
            return false;
        }

        // بیش از یک «:» یا شروع/پایان با «::» نشانه‌ی IPv6 است
        return substr_count($ip, ':') > 1
            || str_starts_with($ip, ':')
            || str_ends_with($ip, ':');
    }

    /**
     * نرمال‌سازی آدرس IP به فرم استاندارد
     *
     * آدرس‌های نگاشت‌یافته‌ی IPv4 داخل IPv6 (::ffff:a.b.c.d) به‌صورت
     * IPv4 خالص بازگردانده می‌شوند تا مسیر دورزدن قوانین بسته شود.
     *
     * @param string|null $ip آدرس ورودی
     * @return string|null فرم استاندارد یا null در صورت نامعتبر بودن
     */
    public static function normalize(?string $ip): ?string
    {
        if ($ip === null) {
            return null;
        }

        $bin = @inet_pton($ip);
        if ($bin === false) {
            return null;
        }

        $bin = self::unmapV4($bin);

        $out = @inet_ntop($bin);
        return $out === false ? null : $out;
    }

    /**
     * تبدیل آدرس IPv4 نگاشت‌شده در IPv6 به بایت‌های IPv4
     */
    private static function unmapV4(string $bin): string
    {
        if (strlen($bin) === 16 && str_starts_with($bin, self::V4_IN_V6_PREFIX)) {
            return substr($bin, 12);
        }

        return $bin;
    }

    /**
     * نسخه‌ی آدرس (ipv4 / ipv6) یا null
     */
    public static function version(?string $ip): ?string
    {
        $bin = @inet_pton((string) $ip);
        if ($bin === false) {
            return null;
        }

        return strlen(self::unmapV4($bin)) === 4 ? self::VERSION_V4 : self::VERSION_V6;
    }

    /**
     * آیا رشته‌ی داده‌شده یک آدرس IP معتبر است؟
     */
    public static function isValid(?string $ip): bool
    {
        return self::normalize($ip) !== null;
    }

    /**
     * تبدیل آدرس به بایت‌های خام و سپس هگز (برای ذخیره‌سازی امن در کش)
     */
    public static function toHex(?string $ip): ?string
    {
        if ($ip === null) {
            return null;
        }

        $bin = @inet_pton($ip);
        if ($bin === false) {
            return null;
        }

        return bin2hex(self::unmapV4($bin));
    }

    /**
     * تبدیل هگز به فرمت متنی استاندارد
     */
    public static function fromHex(string $hex): ?string
    {
        if ($hex === '' || strlen($hex) % 2 !== 0 || !ctype_xdigit($hex)) {
            return null;
        }

        $out = @inet_ntop(@hex2bin($hex) ?: '');
        return $out === false ? null : $out;
    }

    /**
     * حداکثر مقدار پیشوند برای هر نسخه
     */
    public static function prefixMax(string $version): int
    {
        return $version === self::VERSION_V6 ? 128 : 32;
    }

    /**
     * آدرس خصوصی/داخلی است؟ (برای نمایش راهنما در پنل)
     */
    public static function isPrivate(?string $ip): bool
    {
        $norm = self::normalize($ip);
        if ($norm === null) {
            return false;
        }

        $hex = self::toHex($norm);
        $bin = hex2bin($hex);

        if (strlen($bin) === 4) {
            $n = unpack('N', $bin)[1];
            return ($n >> 24) === 10                    // 10.0.0.0/8
                || ($n >> 20) === 0xAC1                 // 172.16.0.0/12
                || ($n >> 16) === 0xC0A8                // 192.168.0.0/16
                || ($n >> 24) === 127                   // 127.0.0.0/8
                || ($n >> 28) === 0xE;                  // 224.0.0.0/4 (multicast)
        }

        // IPv6
        return $bin === str_repeat("\x00", 15) . "\x01" // ::1
            || str_starts_with($bin, "\xfe\x80")        // fe80::/10
            || str_starts_with($bin, "\xfc")            // fc00::/7 (ULA)
            || str_starts_with($bin, "\xfd");           // fd00::/8 (ULA)
    }

    /**
     * پارس یک قانون (تک آی‌پی یا بازه‌ی CIDR)
     *
     * خروجی در صورت موفقیت:
     * [
     *   'value'   => '192.0.2.0/24',   فرم استاندارد ذخیره در دیتابیس
     *   'display' => '192.0.2.0/24',   فرم نمایشی
     *   'isCidr'  => true,
     *   'prefix'  => 24,
     *   'version' => 'ipv4',
     *   'hex'     => 'c0000200',       بایت‌های شبکه به‌صورت هگز
     * ]
     *
     * @param string $input ورودی کاربر (مثلاً «192.168.1.0/24» یا «2001:db8::1»)
     * @return array|null آرایه‌ی قانون یا null در صورت نامعتبر بودن
     */
    public static function parseRule(string $input): ?array
    {
        $input = self::sanitize($input);
        if ($input === '') {
            return null;
        }

        $prefix = null;
        $body = $input;

        // جداسازی پیشوند CIDR
        $slash = strrpos($input, '/');
        if ($slash !== false) {
            $body = substr($input, 0, $slash);
            $prefixPart = substr($input, $slash + 1);

            if (!preg_match('/^\d{1,3}$/', $prefixPart)) {
                return null;
            }

            $prefix = (int) $prefixPart;
        }

        $bin = @inet_pton($body);
        if ($bin === false) {
            return null;
        }

        $bin = self::unmapV4($bin);
        $version = strlen($bin) === 4 ? self::VERSION_V4 : self::VERSION_V6;
        $maxPrefix = $version === self::VERSION_V6 ? 128 : 32;

        // تعیین پیشوند پیش‌فرض برای تک آی‌پی
        if ($prefix === null) {
            $prefix = $maxPrefix;
        } elseif ($prefix < 0 || $prefix > $maxPrefix) {
            return null;
        }

        $isCidr = $prefix < $maxPrefix;

        // اعمال ماسک شبکه: 192.168.1.77/24 → 192.168.1.0/24
        $masked = self::applyMask($bin, $prefix);

        $canonical = @inet_ntop($masked);
        if ($canonical === false) {
            return null;
        }

        $value = $isCidr ? $canonical . '/' . $prefix : $canonical;

        return [
            'value'   => $value,
            'display' => $value,
            'isCidr'  => $isCidr,
            'prefix'  => $prefix,
            'version' => $version,
            'hex'     => bin2hex($masked),
        ];
    }

    /**
     * اعمال ماسک پیشوند روی بایت‌های آدرس
     */
    private static function applyMask(string $bin, int $prefix): string
    {
        $len = strlen($bin);
        $full = intdiv($prefix, 8);
        $rem = $prefix % 8;

        $out = $full > 0 ? substr($bin, 0, $full) : '';

        if ($rem > 0) {
            $mask = (0xFF << (8 - $rem)) & 0xFF;
            $out .= chr(ord($bin[$full]) & $mask);
            $out .= str_repeat("\x00", $len - $full - 1);
        } else {
            $out .= str_repeat("\x00", $len - $full);
        }

        return $out;
    }

    /**
     * آیا آدرس (هگز) داخل بازه‌ی شبکه (هگز + پیشوند) قرار دارد؟
     *
     * هر دو پارامتر باید هم‌نسخه باشند (هر دو IPv4 یا هر دو IPv6)
     * وگرنه تطبیق ناموفق است.
     *
     * @param string $ipHex  بایت‌های آدرس بازدیدکننده به‌صورت هگز
     * @param string $netHex بایت‌های شبکه به‌صورت هگز
     * @param int    $prefix طول پیشوند (۰ تا ۳۲/۱۲۸)
     * @return bool
     */
    public static function matchesHex(string $ipHex, string $netHex, int $prefix): bool
    {
        $ipLen = strlen($ipHex);
        $netLen = strlen($netHex);

        // طول‌های نامعتبر یا ناهم‌نسخه
        if ($ipLen === 0 || $ipLen !== $netLen) {
            return false;
        }

        $byteLen = $ipLen / 2;
        $maxBits = $byteLen * 8;

        if ($prefix < 0 || $prefix > $maxBits) {
            return false;
        }

        if ($prefix === 0) {
            return true; // بازه‌ی کامل (0.0.0.0/0)
        }

        // مقایسه‌ی سریع با هگز: هر بایت = ۲ کاراکتر هگز
        $fullHex = intdiv($prefix, 8) * 2;
        $remBits = $prefix % 8;

        if ($fullHex > 0 && !self::hexStartsWith($ipHex, $netHex, $fullHex)) {
            return false;
        }

        if ($remBits > 0) {
            // ماسک نیبل‌ها: هر نیبل ۴ بیت است
            $mask = (0xFF << (8 - $remBits)) & 0xFF;
            $ipByte = hexdec(substr($ipHex, $fullHex, 2));
            $netByte = hexdec(substr($netHex, $fullHex, 2));

            if (($ipByte & $mask) !== ($netByte & $mask)) {
                return false;
            }
        }

        return true;
    }

    /**
     * مقایسه‌ی پیشوندی دو رشته‌ی هگز با طول مشخص (کاراکتر)
     */
    private static function hexStartsWith(string $haystack, string $needle, int $chars): bool
    {
        return strncasecmp(substr($haystack, 0, $chars), substr($needle, 0, $chars), $chars) === 0;
    }

    /**
     * پیدا کردن قانون منطبق از ساختار کش
     *
     * @param string $ip آدرس نرمال‌شده‌ی بازدیدکننده
     * @param array  $cache ساختار کش شامل exact و ranges
     * @return array|null قانون منطبق (مختص‌ترین در صورت چند تطبیق) یا null
     */
    public static function findMatch(string $ip, array $cache): ?array
    {
        $ipHex = self::toHex($ip);
        if ($ipHex === null) {
            return null;
        }

        $now = time();

        // ۱) تطبیق دقیق — O(1)
        $exact = $cache['exact'] ?? [];
        if (isset($exact[$ip])) {
            $rule = $exact[$ip];
            if (is_array($rule)) {
                $expires = (int) ($rule['expires'] ?? 0);

                if ($expires === 0 || $expires > $now) {
                    return $rule + ['matchedBy' => $ip];
                }

                // قانون دقیق منقضی است؛ به دنبال بازه‌های فعال می‌گردیم
            }
        }

        // ۲) تطبیق بازه‌ای — با انتخاب مختص‌ترین قانون
        $ranges = $cache['ranges'] ?? [];
        $best = null;
        $bestPrefix = -1;

        foreach ($ranges as $range) {
            if (!is_array($range)) {
                continue;
            }

            $expires = (int) ($range['expires'] ?? 0);
            if ($expires !== 0 && $expires <= $now) {
                continue; // قانون موقت منقضی
            }

            $prefix = (int) ($range['prefix'] ?? -1);
            if ($prefix < 0) {
                continue;
            }

            if ($prefix <= $bestPrefix) {
                continue; // از قبل قانون مختص‌تری پیدا شده
            }

            if (self::matchesHex($ipHex, (string) ($range['hex'] ?? ''), $prefix)) {
                $best = $range;
                $bestPrefix = $prefix;
            }
        }

        if ($best !== null) {
            $best['matchedBy'] = $best['value'] ?? '';
        }

        return $best;
    }

    /**
     * آیا آدرس در لیست محافظت‌شده‌ها (کش) هست؟
     */
    public static function isProtected(string $ip, array $cache): bool
    {
        $protected = $cache['protected'] ?? [];
        $ips = $protected['ips'] ?? [];
        $ranges = $protected['ranges'] ?? [];

        if (isset($ips[$ip])) {
            return true;
        }

        if (empty($ranges)) {
            return false;
        }

        $ipHex = self::toHex($ip);
        if ($ipHex === null) {
            return false;
        }

        foreach ($ranges as $range) {
            if (!is_array($range)) {
                continue;
            }

            if (self::matchesHex($ipHex, (string) ($range['hex'] ?? ''), (int) ($range['prefix'] ?? -1))) {
                return true;
            }
        }

        return false;
    }

    /**
     * آیا بازه‌ی داده‌شده آدرس خاصی را پوشش می‌دهد؟ (برای جلوگیری از بلاک IP مدیر)
     *
     * @param array  $rule   خروجی parseRule
     * @param string $ipHex  هگز آدرس (می‌تواند آرایه‌ای از هگزها باشد)
     * @return bool
     */
    public static function ruleCoversHex(array $rule, string $ipHex): bool
    {
        $ruleHex = (string) ($rule['hex'] ?? '');
        $prefix = (int) ($rule['prefix'] ?? 0);

        return self::matchesHex($ipHex, $ruleHex, $prefix);
    }

    /**
     * توضیح فارسی نوع قانون برای نمایش در پنل
     */
    public static function describeRule(array $rule): string
    {
        if (!empty($rule['isCidr'])) {
            $count = match ($rule['version']) {
                self::VERSION_V6 => self::rangeSize($rule['prefix'], 128),
                default => self::rangeSize($rule['prefix'], 32),
            };

            return $rule['version'] === self::VERSION_V6
                ? 'بازه‌ی IPv6 /' . $rule['prefix'] . ' — شامل ' . $count . ' آدرس'
                : 'بازه‌ی IPv4 /' . $rule['prefix'] . ' — شامل ' . $count . ' آدرس';
        }

        return $rule['version'] === self::VERSION_V6 ? 'تک آدرس IPv6' : 'تک آدرس IPv4';
    }

    /**
     * تعداد آدرس‌های یک بازه به‌صورت رشته‌ی خوانا
     *
     * فقط عدد (بدون واحد) برمی‌گرداند تا فراخواننده واحد را اضافه کند.
     */
    public static function rangeSize(int $prefix, int $maxPrefix): string
    {
        $bits = $maxPrefix - $prefix;

        if ($bits === 0) {
            return '۱';
        }

        if ($bits <= 20) {
            return self::faNumber((string) (2 ** $bits));
        }

        if ($bits <= 40) {
            return self::faNumber(number_format((float) (2 ** $bits), 0, '.', '،'));
        }

        // برای بازه‌های بسیار بزرگ از نمایش توانی استفاده می‌کنیم
        return '۲^' . self::faNumber((string) $bits);
    }

    /**
     * تبدیل ارقام لاتین به فارسی
     */
    public static function faNumber(string $number): string
    {
        return strtr($number, [
            '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
            '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
        ]);
    }
}
