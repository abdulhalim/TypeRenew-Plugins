<?php
/**
 * Jalali — تبدیل و قالب‌بندی تاریخ شمسی (تقویم جلالی)
 *
 * پیاده‌سازی الگوریتم استاندارد و پرکاربرد تبدیل میلادی ↔ شمسی
 * که سال‌ها در اکوسیستم PHP فارسی مورد استفاده و تأیید قرار گرفته است.
 * تاریخ‌ها به‌صورت Unix Timestamp ذخیره و با منطقه‌ی زمانی سایت نمایش داده می‌شوند.
 *
 * @package IPBlocker
 * @since   1.0.0
 */

namespace TypechoPlugin\IPBlocker\lib;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Jalali
{
    /** نام ماه‌های شمسی */
    public const MONTHS = [
        1 => 'فروردین', 2 => 'اردیبهشت', 3 => 'خرداد',
        4 => 'تیر', 5 => 'مرداد', 6 => 'شهریور',
        7 => 'مهر', 8 => 'آبان', 9 => 'آذر',
        10 => 'دی', 11 => 'بهمن', 12 => 'اسفند',
    ];

    /** روزهای ماه‌های غیرکبیسه */
    private const MONTH_DAYS = [
        1 => 31, 2 => 31, 3 => 31, 4 => 31, 5 => 31, 6 => 31,
        7 => 30, 8 => 30, 9 => 30, 10 => 30, 11 => 30, 12 => 29,
    ];

    /** منطقه‌ی زمانی کش‌شده */
    private static ?\DateTimeZone $tz = null;

    // ------------------------------------------------------------------
    // تبدیل‌های اصلی
    // ------------------------------------------------------------------

    /**
     * تبدیل میلادی به شمسی
     *
     * @return array{0:int,1:int,2:int} [سال، ماه، روز] شمسی
     */
    public static function toJalali(int $gy, int $gm, int $gd): array
    {
        $gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
        $gy2 = ($gm > 2) ? ($gy + 1) : $gy;

        $days = 355666
            + (365 * $gy)
            + intdiv($gy2 + 3, 4)
            - intdiv($gy2 + 99, 100)
            + intdiv($gy2 + 399, 400)
            + $gd
            + $gdm[$gm - 1];

        $jy = -1595 + (33 * intdiv($days, 12053));
        $days %= 12053;

        $jy += 4 * intdiv($days, 1461);
        $days %= 1461;

        if ($days > 365) {
            $jy += intdiv($days - 1, 365);
            $days = ($days - 1) % 365;
        }

        if ($days < 186) {
            $jm = 1 + intdiv($days, 31);
            $jd = 1 + ($days % 31);
        } else {
            $jm = 7 + intdiv($days - 186, 30);
            $jd = 1 + (($days - 186) % 30);
        }

        return [$jy, $jm, $jd];
    }

    /**
     * تبدیل شمسی به میلادی
     *
     * @return array{0:int,1:int,2:int} [سال، ماه، روز] میلادی
     */
    public static function toGregorian(int $jy, int $jm, int $jd): array
    {
        $jy += 1595;

        $days = -355668
            + (365 * $jy)
            + (intdiv($jy, 33) * 8)
            + intdiv(($jy % 33) + 3, 4)
            + $jd
            + (($jm < 7) ? ($jm - 1) * 31 : (($jm - 7) * 30) + 186);

        $gy = 400 * intdiv($days, 146097);
        $days %= 146097;

        if ($days > 36524) {
            $days--;
            $gy += 100 * intdiv($days, 36524);
            $days %= 36524;
            if ($days >= 365) {
                $days++;
            }
        }

        $gy += 4 * intdiv($days, 1461);
        $days %= 1461;

        if ($days > 365) {
            $gy += intdiv($days - 1, 365);
            $days = ($days - 1) % 365;
        }

        $gd = $days + 1;
        $leap = (($gy % 4 === 0) && ($gy % 100 !== 0)) || ($gy % 400 === 0);
        $salA = [0, 31, $leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

        $gm = 0;
        while ($gm < 13 && $gd > $salA[$gm]) {
            $gd -= $salA[$gm];
            $gm++;
        }

        return [$gy, $gm, $gd];
    }

    /**
     * طول سال شمسی (۳۶۵ یا ۳۶۶ روز)
     */
    public static function daysInJYear(int $jy): int
    {
        [$gy1, $gm1, $gd1] = self::toGregorian($jy, 1, 1);
        [$gy2, $gm2, $gd2] = self::toGregorian($jy + 1, 1, 1);

        $t1 = gmmktime(0, 0, 0, $gm1, $gd1, $gy1);
        $t2 = gmmktime(0, 0, 0, $gm2, $gd2, $gy2);

        return (int) round(($t2 - $t1) / 86400);
    }

    /**
     * سال شمسی کبیسه است؟
     */
    public static function isLeapYear(int $jy): bool
    {
        return self::daysInJYear($jy) === 366;
    }

    /**
     * تعداد روزهای یک ماه شمسی
     */
    public static function daysInJMonth(int $jy, int $jm): int
    {
        if ($jm < 1 || $jm > 12) {
            return 30;
        }

        if ($jm === 12) {
            return self::isLeapYear($jy) ? 30 : 29;
        }

        return self::MONTH_DAYS[$jm];
    }

    // ------------------------------------------------------------------
    // قالب‌بندی نمایشی
    // ------------------------------------------------------------------

    /**
     * دریافت منطقه‌ی زمانی سایت (با کش‌کردن نتیجه)
     */
    private static function tz(): \DateTimeZone
    {
        if (self::$tz !== null) {
            return self::$tz;
        }

        try {
            $tzId = (string) (\Widget\Options::alloc()->timezoneId ?? '');
            self::$tz = $tzId !== '' ? new \DateTimeZone($tzId) : new \DateTimeZone(date_default_timezone_get());
        } catch (\Throwable $e) {
            self::$tz = new \DateTimeZone(date_default_timezone_get());
        }

        return self::$tz;
    }

    /**
     * اجزای تاریخ/ساعت شمسی از یک Unix Timestamp (با منطقه‌ی زمانی سایت)
     *
     * @return array{jy:int,jm:int,jd:int,h:int,i:int,s:int}
     */
    public static function parts(int $ts): array
    {
        $dt = (new \DateTime('@' . $ts))->setTimezone(self::tz());

        [$jy, $jm, $jd] = self::toJalali(
            (int) $dt->format('Y'),
            (int) $dt->format('n'),
            (int) $dt->format('j')
        );

        return [
            'jy' => $jy,
            'jm' => $jm,
            'jd' => $jd,
            'h'  => (int) $dt->format('G'),
            'i'  => (int) $dt->format('i'),
            's'  => (int) $dt->format('s'),
        ];
    }

    /**
     * قالب‌بندی کامپکت: ۱۴۰۴/۰۷/۰۴ — ۱۴:۳۰
     */
    public static function short(int $ts, bool $withTime = true): string
    {
        $p = self::parts($ts);
        $out = self::faNum(sprintf('%04d/%02d/%02d', $p['jy'], $p['jm'], $p['jd']));

        return $withTime
            ? $out . ' — ' . self::faNum(sprintf('%02d:%02d', $p['h'], $p['i']))
            : $out;
    }

    /**
     * قالب‌بندی کامل: ۴ مهر ۱۴۰۴، ساعت ۱۴:۳۰
     */
    public static function full(int $ts): string
    {
        $p = self::parts($ts);

        return self::faNum((string) $p['jd'])
            . ' ' . self::MONTHS[$p['jm']]
            . ' ' . self::faNum((string) $p['jy'])
            . '، ساعت ' . self::faNum(sprintf('%02d:%02d', $p['h'], $p['i']));
    }

    /**
     * نمایش نسبی: «۳ دقیقه پیش»، «۲ روز پیش»، «۴ روز آینده»
     */
    public static function relative(int $ts): string
    {
        $diff = time() - $ts;

        if ($diff === 0) {
            return 'هم‌اکنون';
        }

        $future = $diff < 0;
        $diff = abs($diff);

        if ($diff < 60) {
            $text = self::faNum((string) $diff) . ' ثانیه';
        } elseif ($diff < 3600) {
            $text = self::faNum((string) intdiv($diff, 60)) . ' دقیقه';
        } elseif ($diff < 86400) {
            $text = self::faNum((string) intdiv($diff, 3600)) . ' ساعت';
        } elseif ($diff < 2592000) {
            $text = self::faNum((string) intdiv($diff, 86400)) . ' روز';
        } elseif ($diff < 31536000) {
            $text = self::faNum((string) intdiv($diff, 2592000)) . ' ماه';
        } else {
            $text = self::faNum((string) intdiv($diff, 31536000)) . ' سال';
        }

        return $future ? $text . ' آینده' : $text . ' پیش';
    }

    /**
     * زمان باقی‌مانده تا انقضا: «۳ روز و ۴ ساعت»
     */
    public static function remaining(int $expires): string
    {
        $diff = $expires - time();

        if ($diff <= 0) {
            return 'منقضی‌شده';
        }

        $days = intdiv($diff, 86400);
        $hours = intdiv($diff % 86400, 3600);
        $minutes = intdiv($diff % 3600, 60);

        if ($days > 0) {
            $out = self::faNum((string) $days) . ' روز';
            if ($hours > 0) {
                $out .= ' و ' . self::faNum((string) $hours) . ' ساعت';
            }

            return $out;
        }

        if ($hours > 0) {
            $out = self::faNum((string) $hours) . ' ساعت';
            if ($minutes > 0) {
                $out .= ' و ' . self::faNum((string) $minutes) . ' دقیقه';
            }

            return $out;
        }

        return self::faNum((string) $minutes) . ' دقیقه';
    }

    /**
     * تبدیل تاریخ شمسی به Unix Timestamp (ساعت اختیاری)
     */
    public static function toTimestamp(int $jy, int $jm, int $jd, int $hour = 0, int $minute = 0): int
    {
        [$gy, $gm, $gd] = self::toGregorian($jy, $jm, $jd);

        $dt = new \DateTime('now', self::tz());
        $dt->setDate($gy, $gm, $gd)->setTime($hour, $minute, 0);

        return $dt->getTimestamp();
    }

    /**
     * تبدیل ارقام لاتین به فارسی
     */
    public static function faNum(string $number): string
    {
        return Ip::faNumber($number);
    }
}
