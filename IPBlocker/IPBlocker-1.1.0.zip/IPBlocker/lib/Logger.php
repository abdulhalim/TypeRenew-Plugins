<?php
/**
 * Logger — ثبت و مدیریت لاگ درخواست‌های مسدودشده
 *
 * @package IPBlocker
 * @since   1.0.0
 */

namespace TypechoPlugin\IPBlocker\lib;

use Typecho\Db;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Logger
{
    /** نام جدول لاگ (بدون پیشوند) */
    public const TABLE_LOGS = 'ipblocker_logs';

    // ------------------------------------------------------------------
    // زیرساخت
    // ------------------------------------------------------------------

    /**
     * SQL ساخت جدول لاگ بر اساس دیالکت
     */
    public static function ensureSchema(): void
    {
        $db = Db::get();
        $table = $db->getPrefix() . self::TABLE_LOGS;
        $prefix = $db->getPrefix();

        $db->query(self::logsSchemaSql($table), Db::WRITE);

        foreach (self::extraIndexSql($prefix) as $sql) {
            try {
                $db->query($sql, Db::WRITE);
            } catch (\Throwable $e) {
                // ایندکس تکراری — بی‌خطر است
            }
        }
    }

    private static function logsSchemaSql(string $table): string
    {
        return match (Store::dialect()) {
            'sqlite' => 'CREATE TABLE IF NOT EXISTS "' . $table . '" ('
                . '"id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,'
                . '"ip" varchar(64) NOT NULL DEFAULT \'\','
                . '"ruleId" int(10) NOT NULL DEFAULT 0,'
                . '"ruleValue" varchar(64) NOT NULL DEFAULT \'\','
                . '"reason" varchar(500) NOT NULL DEFAULT \'\','
                . '"url" varchar(500) NOT NULL DEFAULT \'\','
                . '"method" varchar(8) NOT NULL DEFAULT \'\','
                . '"agent" varchar(300) NOT NULL DEFAULT \'\','
                . '"created" int(10) NOT NULL DEFAULT 0)',
            'pgsql' => 'CREATE TABLE IF NOT EXISTS "' . $table . '" ('
                . '"id" BIGSERIAL PRIMARY KEY,'
                . '"ip" VARCHAR(64) NOT NULL DEFAULT \'\','
                . '"ruleId" BIGINT NOT NULL DEFAULT 0,'
                . '"ruleValue" VARCHAR(64) NOT NULL DEFAULT \'\','
                . '"reason" VARCHAR(500) NOT NULL DEFAULT \'\','
                . '"url" VARCHAR(500) NOT NULL DEFAULT \'\','
                . '"method" VARCHAR(8) NOT NULL DEFAULT \'\','
                . '"agent" VARCHAR(300) NOT NULL DEFAULT \'\','
                . '"created" BIGINT NOT NULL DEFAULT 0)',
            default => 'CREATE TABLE IF NOT EXISTS `' . $table . '` ('
                . '`id` bigint unsigned NOT NULL auto_increment,'
                . '`ip` varchar(64) NOT NULL DEFAULT \'\','
                . '`ruleId` bigint unsigned NOT NULL DEFAULT 0,'
                . '`ruleValue` varchar(64) NOT NULL DEFAULT \'\','
                . '`reason` varchar(500) NOT NULL DEFAULT \'\','
                . '`url` varchar(500) NOT NULL DEFAULT \'\','
                . '`method` varchar(8) NOT NULL DEFAULT \'\','
                . '`agent` varchar(300) NOT NULL DEFAULT \'\','
                . '`created` int unsigned NOT NULL DEFAULT 0,'
                . 'PRIMARY KEY (`id`),'
                . 'KEY `idx_ip_created` (`ip`, `created`),'
                . 'KEY `idx_created` (`created`))'
                . ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
        };
    }

    /**
     * @return string[]
     */
    private static function extraIndexSql(string $prefix): array
    {
        if (Store::dialect() === 'mysql') {
            return [];
        }

        $t = $prefix . self::TABLE_LOGS;

        return [
            'CREATE INDEX IF NOT EXISTS "idx_' . $t . '_ip_created" ON "' . $t . '" ("ip", "created")',
            'CREATE INDEX IF NOT EXISTS "idx_' . $t . '_created" ON "' . $t . '" ("created")',
        ];
    }

    // ------------------------------------------------------------------
    // ثبت لاگ
    // ------------------------------------------------------------------

    /**
     * ثبت یک رویداد مسدودسازی
     *
     * این متد در «پس‌زمینه‌ی» پاسخ (background responder) فراخوانی می‌شود
     * تا سرعت پاسخ 403 به بازدیدکننده تحت تأثیر قرار نگیرد.
     */
    public static function log(array $entry): void
    {
        try {
            $db = Db::get();

            $db->query(
                $db->insert('table.' . self::TABLE_LOGS)->rows([
                    'ip'        => mb_substr((string) ($entry['ip'] ?? ''), 0, 60, 'UTF-8'),
                    'ruleId'    => (int) ($entry['ruleId'] ?? 0),
                    'ruleValue' => mb_substr((string) ($entry['ruleValue'] ?? ''), 0, 60, 'UTF-8'),
                    'reason'    => mb_substr((string) ($entry['reason'] ?? ''), 0, 480, 'UTF-8'),
                    'url'       => mb_substr((string) ($entry['url'] ?? ''), 0, 480, 'UTF-8'),
                    'method'    => mb_substr(strtoupper((string) ($entry['method'] ?? '')), 0, 7, 'UTF-8'),
                    'agent'     => mb_substr((string) ($entry['agent'] ?? ''), 0, 280, 'UTF-8'),
                    'created'   => time(),
                ])
            );
        } catch (\Throwable $e) {
            // ثبت لاگ هرگز نباید جریان سایت را متوقف کند
        }
    }

    /**
     * آیا IP در ساعات اخیر سیل لاگ ایجاد کرده است؟
     *
     * @param int $maxPerHour حداکثر مجاز (۰ = نامحدود)
     */
    public static function isThrottled(string $ip, int $maxPerHour): bool
    {
        if ($maxPerHour <= 0) {
            return false;
        }

        try {
            $db = Db::get();

            $num = (int) ($db->fetchRow(
                $db->select('COUNT(id) AS num')->from('table.' . self::TABLE_LOGS)
                    ->where('ip = ? AND created > ?', $ip, time() - 3600)
            )['num'] ?? 0);

            return $num >= $maxPerHour;
        } catch (\Throwable $e) {
            return false; // در صورت خطا ثبت می‌کنیم (ترجیح بر از دست دادن لاگ)
        }
    }

    // ------------------------------------------------------------------
    // فهرست و آمار
    // ------------------------------------------------------------------

    /**
     * فهرست لاگ‌ها با فیلتر و صفحه‌بندی
     *
     * @param array $filters [q, range(all|today|week|month)]
     * @param int   $page
     * @param int   $perPage
     *
     * @return array{rows:array,total:int,page:int,perPage:int,pages:int}
     */
    public static function list(array $filters = [], int $page = 1, int $perPage = 20): array
    {
        $db = Db::get();
        $perPage = max(1, min(200, $perPage));
        $page = max(1, $page);

        $select = $db->select()->from('table.' . self::TABLE_LOGS);
        $countSelect = $db->select('COUNT(id) AS num')->from('table.' . self::TABLE_LOGS);

        $apply = static function ($select) use ($filters) {
            $q = trim((string) ($filters['q'] ?? ''));
            if ($q !== '') {
                $kw = '%' . addcslashes($q, "%_\\") . '%';
                $select->where('(ip LIKE ? OR url LIKE ? OR reason LIKE ? OR ruleValue LIKE ?)', $kw, $kw, $kw, $kw);
            }

            $range = (string) ($filters['range'] ?? 'all');
            if ($range === 'today') {
                $select->where('created > ?', strtotime('today'));
            } elseif ($range === 'week') {
                $select->where('created > ?', time() - 7 * 86400);
            } elseif ($range === 'month') {
                $select->where('created > ?', time() - 30 * 86400);
            }
        };

        $apply($select);
        $apply($countSelect);

        $total = (int) ($db->fetchRow($countSelect)['num'] ?? 0);
        $pages = max(1, (int) ceil($total / $perPage));

        if ($page > $pages && $total > 0) {
            $page = $pages;
        }

        $rows = $db->fetchAll(
            $select->order('created', Db::SORT_DESC)
                ->offset(($page - 1) * $perPage)
                ->limit($perPage)
        );

        return [
            'rows'    => is_array($rows) ? $rows : [],
            'total'   => $total,
            'page'    => $page,
            'perPage' => $perPage,
            'pages'   => $pages,
        ];
    }

    /**
     * آمار لاگ‌ها
     */
    public static function stats(): array
    {
        $db = Db::get();

        try {
            $total = (int) ($db->fetchRow(
                $db->select('COUNT(id) AS num')->from('table.' . self::TABLE_LOGS)
            )['num'] ?? 0);

            $today = (int) ($db->fetchRow(
                $db->select('COUNT(id) AS num')->from('table.' . self::TABLE_LOGS)
                    ->where('created > ?', strtotime('today'))
            )['num'] ?? 0);

            $unique = 0;
            if ($total > 0) {
                $unique = (int) ($db->fetchRow(
                    $db->select('COUNT(DISTINCT ip) AS num')->from('table.' . self::TABLE_LOGS)
                )['num'] ?? 0);
            }

            $last = $db->fetchRow(
                $db->select('created', 'ip')->from('table.' . self::TABLE_LOGS)
                    ->order('created', Db::SORT_DESC)->limit(1)
            );

            // پرمخرب‌ترین IP ها (برای داشبورد)
            $top = $db->fetchAll(
                $db->select('ip', 'COUNT(id) AS num')->from('table.' . self::TABLE_LOGS)
                    ->group('ip')->order('num', Db::SORT_DESC)->limit(5)
            );
        } catch (\Throwable $e) {
            return ['total' => 0, 'today' => 0, 'unique' => 0, 'last' => null, 'top' => []];
        }

        return [
            'total'  => $total,
            'today'  => $today,
            'unique' => $unique,
            'last'   => empty($last) ? null : ['created' => (int) $last['created'], 'ip' => (string) $last['ip']],
            'top'    => is_array($top ?? null) ? array_map(static fn ($r) => [
                'ip'  => (string) $r['ip'],
                'num' => (int) $r['num'],
            ], $top) : [],
        ];
    }

    // ------------------------------------------------------------------
    // پاک‌سازی
    // ------------------------------------------------------------------

    /**
     * حذف لاگ‌های انتخابی
     *
     * @param int[] $ids
     */
    public static function delete(array $ids): int
    {
        $ids = array_values(array_filter(array_map('intval', $ids), static fn ($id) => $id > 0));
        if (empty($ids)) {
            return 0;
        }

        $db = Db::get();

        // حذف تک‌به‌تک با پارامتر مقیدشده (حتی برای فهرست‌های بلند)
        $count = 0;
        foreach ($ids as $id) {
            $db->query($db->delete('table.' . self::TABLE_LOGS)->where('id = ?', $id));
            $count++;
        }

        return $count;
    }

    /**
     * پاک‌سازی کامل لاگ‌ها
     */
    public static function purgeAll(): int
    {
        $db = Db::get();
        $table = 'table.' . self::TABLE_LOGS;

        $num = (int) ($db->fetchRow(
            $db->select('COUNT(id) AS num')->from($table)
        )['num'] ?? 0);

        if ($num > 0) {
            try {
                $db->truncate($table);
            } catch (\Throwable $e) {
                // برخی دیالکت‌ها TRUNCATE ندارند؛ DELETE جایگزین
                $db->query($db->delete($table));
            }
        }

        return $num;
    }

    /**
     * پاک‌سازی لاگ‌های قدیمی‌تر از N روز
     *
     * @param int $days تعداد روز (۰ = بدون تغییر)
     * @return int تعداد حذف‌شده‌ها
     */
    public static function cleanup(int $days): int
    {
        if ($days <= 0) {
            return 0;
        }

        $db = Db::get();
        $table = 'table.' . self::TABLE_LOGS;
        $threshold = time() - $days * 86400;

        $num = (int) ($db->fetchRow(
            $db->select('COUNT(id) AS num')->from($table)->where('created < ?', $threshold)
        )['num'] ?? 0);

        if ($num > 0) {
            $db->query($db->delete($table)->where('created < ?', $threshold));
        }

        return $num;
    }

    /**
     * اجرای سیاست نگهداری (فراخوانی شانس‌محور برای اجرای سبک در پنل)
     */
    public static function runRetentionPolicy(): void
    {
        $days = (int) Settings::option('logRetentionDays', '90');
        if ($days <= 0) {
            return;
        }

        try {
            self::cleanup($days);
        } catch (\Throwable $e) {
            // سیاست نگهداری پس‌زمینه‌ای است
        }
    }
}
