<?php
/**
 * Cache — کش فایلی سریع برای مسیر داغ (هر درخواست)
 *
 * ساختار کش در یک فایل PHP استاتیک ذخیره می‌شود تا:
 *  - با OPcache عملاً «رایگان» خوانده شود (بدون هیچ کوئری دیتابیس)
 *  - بایت‌های آدرس‌ها به‌صورت هگز ذخیره شوند (ایمن برای include)
 *  - بازسازی اتمی انجام شود (نوشتن در فایل موقت + rename)
 *
 * مسیر پیش‌فرض: usr/plugins/IPBlocker/cache/rules.php
 * در صورت غیرقابل‌نوشتن بودن، به دایرکتوری موقت سیستم fallback می‌شود.
 *
 * @package IPBlocker
 * @since   1.0.0
 */

namespace TypechoPlugin\IPBlocker\lib;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Cache
{
    /** نام فایل کش */
    private const FILE_NAME = 'rules.php';

    /** عمر مفید کش پیش از بازسازی خودکار (ثانیه) */
    public const STALE_AFTER = 300;

    /** مسیر کش‌شده‌ی فایل */
    private static ?string $path = null;

    // ------------------------------------------------------------------
    // مسیرها
    // ------------------------------------------------------------------

    /**
     * دایرکتوری کش (با fallback خودکار)
     */
    public static function dir(): string
    {
        $primary = __DIR__ . '/../cache';

        if (!is_dir($primary)) {
            @mkdir($primary, 0755, true);
        }

        if (is_dir($primary) && is_writable($primary)) {
            self::protectDirectory($primary);

            return $primary;
        }

        // مسیر جایگزین: دایرکتوری موقت سیستم
        $fallback = rtrim(sys_get_temp_dir(), '/\\') . '/ipblocker-cache-' . md5(__TYPECHO_ROOT_DIR__);

        if (!is_dir($fallback)) {
            @mkdir($fallback, 0755, true);
        }

        return is_writable($fallback) ? $fallback : $primary;
    }

    /**
     * محافظت از دایرکتوری در برابر دسترسی مستقیم وب
     */
    private static function protectDirectory(string $dir): void
    {
        $guards = [
            '.htaccess' => "Require all denied\n<IfModule !mod_authz_core.c>\n    Order allow,deny\n    Deny from all\n</IfModule>\n",
            'index.html' => '',
        ];

        foreach ($guards as $name => $content) {
            $file = $dir . '/' . $name;
            if (!file_exists($file)) {
                @file_put_contents($file, $content);
            }
        }
    }

    /**
     * مسیر کامل فایل کش
     */
    public static function path(): string
    {
        if (self::$path === null) {
            self::$path = self::dir() . '/' . self::FILE_NAME;
        }

        return self::$path;
    }

    // ------------------------------------------------------------------
    // بارگذاری (مسیر داغ)
    // ------------------------------------------------------------------

    /**
     * بارگذاری کش — با بازسازی خودکار در صورت نبود/کهنگی
     *
     * این متد در هر درخواست فرانت‌اند فراخوانی می‌شود و باید
     * فوق‌سریع باشد: یک include (کش‌شده در OPcache) + یک filemtime.
     */
    public static function load(): array
    {
        $file = self::path();

        if (is_file($file)) {
            $data = @include $file;

            if (is_array($data) && isset($data['generated'])) {
                // بازسازی دوره‌ای: هرس کردن قوانین منقضی + همگام‌سازی با DB
                if ((int) $data['generated'] < time() - self::STALE_AFTER) {
                    return self::build();
                }

                return $data;
            }
        }

        return self::build();
    }

    // ------------------------------------------------------------------
    // ساخت و نوشتن
    // ------------------------------------------------------------------

    /**
     * ساخت کامل کش از دیتابیس و تنظیمات
     *
     * @return array ساختار کش (مستقل از موفقیت نوشتن فایل)
     */
    public static function build(): array
    {
        $settings = Settings::get();

        $data = [
            'generated' => time(),
            'settings'  => [
                'enabled'         => (string) $settings['enabled'],
                'blockAdmin'      => (string) $settings['blockAdmin'],
                'protectAdminIps' => (string) $settings['protectAdminIps'],
                'logEnabled'      => (string) $settings['logEnabled'],
                'logMaxPerHour'   => (int) $settings['logMaxPerHour'],
                'blockMessage'    => (string) $settings['blockMessage'],
            ],
            'exact'     => [],
            'ranges'    => [],
            'protected' => ['ips' => [], 'ranges' => []],
        ];

        // قوانین فعال
        foreach (Store::fetchForCache() as $row) {
            $entry = [
                'id'      => (int) ($row['id'] ?? 0),
                'value'   => (string) ($row['value'] ?? ''),
                'expires' => (int) ($row['expires'] ?? 0),
                'reason'  => (string) ($row['reason'] ?? ''),
                'mode'    => (string) ($row['mode'] ?? 'permanent'),
            ];

            $isCidr = (int) ($row['isCidr'] ?? 0) === 1;
            $prefix = (int) ($row['prefix'] ?? 0);

            if ($isCidr) {
                // بازسازی هگز شبکه از روی مقدار ذخیره‌شده
                $hex = self::hexFromValue($entry['value'], $prefix);
                if ($hex !== null) {
                    $entry['hex'] = $hex;
                    $entry['prefix'] = $prefix;
                    $entry['version'] = (string) ($row['version'] ?? 'ipv4');
                    $data['ranges'][] = $entry;
                }
            } else {
                $data['exact'][$entry['value']] = $entry;
            }
        }

        // لیست محافظت‌شده‌ها: مدیران + لیست سفید
        foreach (array_keys(Store::protectedIps()) as $ip) {
            $data['protected']['ips'][$ip] = 1;
        }

        $whitelist = (string) ($settings['extraWhitelist'] ?? '');
        foreach (preg_split('/\r\n|\r|\n/', $whitelist) ?: [] as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#')) {
                continue;
            }

            $rule = Ip::parseRule($line);
            if ($rule === null) {
                continue;
            }

            if ($rule['isCidr']) {
                $data['protected']['ranges'][] = ['hex' => $rule['hex'], 'prefix' => $rule['prefix']];
            } else {
                $data['protected']['ips'][$rule['value']] = 1;
            }
        }

        self::write($data);

        return $data;
    }

    /**
     * استخراج هگز شبکه از روی مقدار «آدرس/پیشوند» ذخیره‌شده در DB
     */
    private static function hexFromValue(string $value, int $prefix): ?string
    {
        $ip = $value;
        $slash = strpos($value, '/');

        if ($slash !== false) {
            $ip = substr($value, 0, $slash);
        }

        $hex = Ip::toHex($ip);

        return $hex === null ? null : $hex;
    }

    /**
     * نوشتن اتمی کش روی دیسک
     */
    private static function write(array $data): bool
    {
        $file = self::path();
        $dir = dirname($file);

        if (!is_dir($dir) || !is_writable($dir)) {
            return false; // حالت بدون کش: از ساختار حافظه‌ای استفاده می‌شود
        }

        $content = "<?php\n/**\n * IP Blocker — فایل کش تولیدشده؛ آن را ویرایش نکنید.\n * تولید: " . date('Y-m-d H:i:s') . "\n */\n\nreturn " . var_export($data, true) . ";\n";

        $tmp = $file . '.' . uniqid('tmp', true) . '.php';

        if (@file_put_contents($tmp, $content, LOCK_EX) === false) {
            return false;
        }

        if (!@rename($tmp, $file)) {
            @unlink($tmp);

            return false;
        }

        @chmod($file, 0644);

        // بی‌اعتبارکردن OPcache برای اعمال فوری تغییرات
        if (function_exists('opcache_invalidate')) {
            @opcache_invalidate($file, true);
        }

        return true;
    }

    /**
     * حذف کش (پس از هر تغییر یا غیرفعال‌سازی)
     */
    public static function invalidate(): void
    {
        $file = self::path();

        if (is_file($file)) {
            @unlink($file);
        }

        if (function_exists('opcache_invalidate')) {
            @opcache_invalidate($file, true);
        }

        self::$path = null;
    }

    // ------------------------------------------------------------------
    // وضعیت (برای پنل ابزارها)
    // ------------------------------------------------------------------

    /**
     * وضعیت فعلی کش برای نمایش در پنل
     */
    public static function state(): array
    {
        $file = self::path();
        $exists = is_file($file);

        return [
            'path'     => $file,
            'dir'      => dirname($file),
            'exists'   => $exists,
            'writable' => is_writable(dirname($file)),
            'fallback' => dirname($file) !== realpath(__DIR__ . '/../cache'),
            'size'     => $exists ? (int) @filesize($file) : 0,
            'generated' => $exists ? (int) @filemtime($file) : 0,
        ];
    }
}
