/**
 * IP Blocker — اسکریپت پنل مدیریت (بدون هیچ وابستگی خارجی)
 *
 * وظایف:
 *  - اعتبارسنجی زنده‌ی آدرس IP/CIDR در فرم افزودن
 *  - پیش‌نمایش زنده‌ی زمان انقضا به تاریخ شمسی
 *  - انتخاب همه، تأیید حذف‌ها، تمدید سریع
 *  - خواندن فایل JSON ایمپورت داخل textarea
 */
(function () {
    'use strict';

    if (typeof window.IPB !== 'undefined') {
        return;
    }

    /* ------------------------------------------------------------------ */
    /* ابزار عمومی                                                          */
    /* ------------------------------------------------------------------ */

    var faDigits = {
        0: '۰', 1: '۱', 2: '۲', 3: '۳', 4: '۴',
        5: '۵', 6: '۶', 7: '۷', 8: '۸', 9: '۹'
    };

    function toFa(num) {
        return String(num).replace(/\d/g, function (d) {
            return faDigits[d];
        });
    }

    /* ------------------------------------------------------------------ */
    /* تبدیل تاریخ شمسی (پورت جاوااسکریپت همان الگوریتم PHP)                 */
    /* ------------------------------------------------------------------ */

    function gregorianToJalali(gy, gm, gd) {
        var gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
        var gy2 = gm > 2 ? gy + 1 : gy;
        var days = 355666 + 365 * gy + Math.floor((gy2 + 3) / 4)
            - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400)
            + gd + gdm[gm - 1];

        var jy = -1595 + 33 * Math.floor(days / 12053);
        days %= 12053;

        jy += 4 * Math.floor(days / 1461);
        days %= 1461;

        if (days > 365) {
            jy += Math.floor((days - 1) / 365);
            days = (days - 1) % 365;
        }

        var jm, jd;
        if (days < 186) {
            jm = 1 + Math.floor(days / 31);
            jd = 1 + (days % 31);
        } else {
            jm = 7 + Math.floor((days - 186) / 30);
            jd = 1 + ((days - 186) % 30);
        }

        return [jy, jm, jd];
    }

    var jMonths = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
        'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];

    function formatJalali(ts) {
        var d = new Date(ts * 1000);
        var parts = gregorianToJalali(d.getFullYear(), d.getMonth() + 1, d.getDate());
        var hh = String(d.getHours()).padStart(2, '0');
        var mm = String(d.getMinutes()).padStart(2, '0');

        return toFa(parts[2]) + ' ' + jMonths[parts[1] - 1] + ' ' + toFa(parts[0])
            + ' — ' + toFa(hh + ':' + mm);
    }

    /* ------------------------------------------------------------------ */
    /* اعتبارسنجی IP (آینه‌ی منطق سمت سرور)                                  */
    /* ------------------------------------------------------------------ */

    function parseIpValue(raw) {
        var input = String(raw || '').trim();
        if (!input) {
            return null;
        }

        // حذف براکت و پورت
        if (input.charAt(0) === '[') {
            var close = input.indexOf(']');
            if (close > 0) {
                input = input.slice(1, close);
            }
        }

        var slash = input.lastIndexOf('/');
        var body = input;
        var prefix = null;

        if (slash >= 0) {
            body = input.slice(0, slash);
            var p = input.slice(slash + 1);
            if (!/^\d{1,3}$/.test(p)) {
                return null;
            }
            prefix = parseInt(p, 10);
        }

        var bin = inetPton(body);
        if (bin === null) {
            return null;
        }

        // آدرس‌های نگاشت‌یافته‌ی IPv4 در IPv6 (::ffff:a.b.c.d) به‌صورت v4 دیده می‌شوند
        // توجه: بازنمایی IPv6 در این‌جا «گروه‌های ۱۶بیتی» است (۸ عضو)
        // پیشوند نگاشت /96 یعنی گروه‌های ۰ تا ۴ صفر و گروه ۵ برابر 0xffff
        var isMapped = bin.length === 8 && bin[0] === 0 && bin[1] === 0 && bin[2] === 0
            && bin[3] === 0 && bin[4] === 0 && bin[5] === 0xffff;

        var version = (bin.length === 4 || isMapped) ? 'ipv4' : 'ipv6';
        var maxPrefix = version === 'ipv6' ? 128 : 32;

        if (prefix === null) {
            prefix = maxPrefix;
        } else if (prefix > maxPrefix) {
            return null;
        }

        return {
            version: version,
            isCidr: prefix < maxPrefix,
            prefix: prefix
        };
    }

    /** شبیه‌سازی inet_pton برای اعتبارسنجی (پشتیبانی v4/v6 با درون‌یابی) */
    function inetPton(ip) {
        // IPv4 ساده
        if (/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.test(ip)) {
            var parts = ip.split('.');
            var bytes = [];

            for (var i = 0; i < 4; i++) {
                var n = parseInt(parts[i], 10);
                if (n > 255 || (parts[i].length > 1 && parts[i].charAt(0) === '0')) {
                    return null;
                }
                bytes.push(n);
            }

            return bytes;
        }

        // IPv6
        if (ip.indexOf(':') >= 0) {
            return parseIpv6(ip);
        }

        return null;
    }

    function parseIpv6(str) {
        str = str.split('%')[0];

        var doubleColon = str.indexOf('::');
        if (doubleColon >= 0 && str.indexOf('::', doubleColon + 1) >= 0) {
            return null; // فقط یک «::» مجاز است
        }

        var head, tail;
        if (doubleColon >= 0) {
            head = str.slice(0, doubleColon);
            tail = str.slice(doubleColon + 2);
        } else {
            head = str;
            tail = '';
        }

        var headGroups = head ? head.split(':') : [];
        var tailGroups = tail ? tail.split(':') : [];

        // نگاشت IPv4 انتهایی
        function expandV4(groups) {
            var out = [];
            for (var i = 0; i < groups.length; i++) {
                var g = groups[i];
                if (/^\d{1,3}(\.\d{1,3}){3}$/.test(g)) {
                    var b = g.split('.');
                    if (b.some(function (x) {
                        return parseInt(x, 10) > 255;
                    })) {
                        return null;
                    }
                    out.push(((+b[0] << 8) | +b[1]).toString(16));
                    out.push(((+b[2] << 8) | +b[3]).toString(16));
                } else {
                    out.push(g);
                }
            }
            return out;
        }

        headGroups = expandV4(headGroups);
        tailGroups = expandV4(tailGroups);
        if (headGroups === null || tailGroups === null) {
            return null;
        }

        var total = headGroups.length + tailGroups.length;
        if (doubleColon >= 0) {
            if (total > 7) {
                return null;
            }
            var missing = 8 - total;
            var groups = headGroups.concat(new Array(missing).fill('0')).concat(tailGroups);

            return groups.map(hexGroup);
        }

        if (total !== 8) {
            return null;
        }

        return headGroups.concat(tailGroups).map(hexGroup);
    }

    function hexGroup(g) {
        if (!/^[0-9a-fA-F]{1,4}$/.test(g)) {
            throw new Error('bad group');
        }

        return parseInt(g, 16);
    }

    /* ------------------------------------------------------------------ */
    /* راه‌اندازی UI                                                        */
    /* ------------------------------------------------------------------ */

    function init() {
        initAddForm();
        initSelectAll();
        initConfirms();
        initExtendButtons();
        initImportFile();
    }

    /* فرم افزودن: اعتبارسنجی زنده + پیش‌نمایش انقضا */
    function initAddForm() {
        var form = document.getElementById('ipb-add-form');
        if (!form) {
            return;
        }

        var valueInput = document.getElementById('ipb-value');
        var verdict = document.getElementById('ipb-input-verdict');
        var modeSelect = document.getElementById('ipb-mode');
        var durationField = document.getElementById('ipb-duration-field');
        var durationInput = document.getElementById('ipb-duration');
        var unitSelect = document.getElementById('ipb-unit');
        var preview = document.getElementById('ipb-expiry-preview');

        function unitSeconds(unit) {
            switch (unit) {
                case 'm': return 60;
                case 'd': return 86400;
                case 'w': return 604800;
                default: return 3600;
            }
        }

        function validate() {
            var parsed = null;
            try {
                parsed = parseIpValue(valueInput.value);
            } catch (e) {
                parsed = null;
            }

            if (!valueInput.value.trim()) {
                verdict.textContent = 'در انتظار ورودی…';
                verdict.className = 'ipb-badge';
                return false;
            }

            if (!parsed) {
                verdict.textContent = 'فرمت آدرس نامعتبر است';
                verdict.className = 'ipb-badge ipb-badge-danger';
                return false;
            }

            if (parsed.isCidr) {
                var count = Math.pow(2, (parsed.version === 'ipv6' ? 128 : 32) - parsed.prefix);
                verdict.textContent = (parsed.version === 'ipv6' ? 'IPv6' : 'IPv4')
                    + ' — بازه‌ی /' + toFa(parsed.prefix)
                    + ' (~' + toFa(count > 999999 ? count.toExponential(2) : count.toLocaleString('fa-IR')) + ' آدرس)';
            } else {
                verdict.textContent = (parsed.version === 'ipv6' ? 'IPv6' : 'IPv4') + ' — تک آدرس';
            }

            verdict.className = 'ipb-badge ipb-badge-ok';
            return true;
        }

        function syncDuration() {
            var isTemp = modeSelect.value === 'temporary';
            durationField.hidden = !isTemp;
            preview.hidden = !isTemp;

            if (isTemp) {
                updatePreview();
            }
        }

        function updatePreview() {
            var duration = parseInt(durationInput.value, 10);
            if (isNaN(duration) || duration <= 0) {
                preview.hidden = true;
                return;
            }

            var expires = Date.now() / 1000 + duration * unitSeconds(unitSelect.value);
            preview.textContent = 'انقضا: ' + formatJalali(expires);
            preview.hidden = false;
        }

        valueInput.addEventListener('input', validate);
        modeSelect.addEventListener('change', syncDuration);
        durationInput.addEventListener('input', updatePreview);
        unitSelect.addEventListener('change', updatePreview);

        form.addEventListener('submit', function (e) {
            if (!validate()) {
                e.preventDefault();
                valueInput.focus();
            }
        });

        validate();
        syncDuration();
    }

    /* انتخاب همه */
    function initSelectAll() {
        var selectAll = document.getElementById('ipb-select-all');
        if (!selectAll) {
            return;
        }

        selectAll.addEventListener('change', function () {
            var checked = selectAll.checked;
            document.querySelectorAll('.ipb-check').forEach(function (box) {
                box.checked = checked;
            });
        });
    }

    /* تأیید عملیات‌های حساس (دکمه‌های دارای lang) */
    function initConfirms() {
        document.querySelectorAll('button[lang], .ipb-mini-btn[lang]').forEach(function (btn) {
            btn.addEventListener('click', function (e) {
                if (!window.confirm(btn.getAttribute('lang'))) {
                    e.preventDefault();
                    e.stopPropagation();
                }
            });
        });
    }

    /* تمدید سریع ۲۴ ساعته */
    function initExtendButtons() {
        document.querySelectorAll('.ipb-extend-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var form = btn.closest('form');
                if (!form) {
                    return;
                }

                var action = form.getAttribute('action');
                var token = form.querySelector('input[name="_"]');

                var post = document.createElement('form');
                post.method = 'post';
                post.action = action.replace('do=add', 'do=extend');

                if (token) {
                    var t = document.createElement('input');
                    t.type = 'hidden';
                    t.name = '_';
                    t.value = token.value;
                    post.appendChild(t);
                }

                var fields = {
                    do: 'extend',
                    id: btn.getAttribute('data-id'),
                    duration: 24,
                    unit: 'h'
                };

                Object.keys(fields).forEach(function (name) {
                    var input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = name;
                    input.value = fields[name];
                    post.appendChild(input);
                });

                document.body.appendChild(post);
                post.submit();
            });
        });
    }

    /* خواندن فایل JSON ایمپورت */
    function initImportFile() {
        var fileInput = document.getElementById('ipb-import-file');
        var textarea = document.getElementById('ipb-import-json');

        if (!fileInput || !textarea) {
            return;
        }

        fileInput.addEventListener('change', function () {
            var file = fileInput.files && fileInput.files[0];
            if (!file) {
                return;
            }

            if (file.size > 5 * 1024 * 1024) {
                window.alert('حجم فایل بیش از ۵ مگابایت است.');
                fileInput.value = '';
                return;
            }

            var reader = new FileReader();
            reader.onload = function () {
                textarea.value = String(reader.result || '');
            };
            reader.readAsText(file, 'UTF-8');
        });
    }

    /* ------------------------------------------------------------------ */

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    window.IPB = { parseIpValue: parseIpValue, formatJalali: formatJalali, gregorianToJalali: gregorianToJalali, toFa: toFa };
})();
