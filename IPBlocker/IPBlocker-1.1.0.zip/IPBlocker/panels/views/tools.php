<?php
/**
 * نمای «ابزارها» — ایمپورت، اکسپورت، کش و نگهداری
 *
 * @package IPBlocker
 * @since   1.1.0 (از پنل مستقل نسخه‌ی ۱.۰.۰ به نمای داخلی تبدیل شد)
 */

use TypechoPlugin\IPBlocker\lib\Cache;
use TypechoPlugin\IPBlocker\lib\Ip;
use TypechoPlugin\IPBlocker\lib\Jalali;
use TypechoPlugin\IPBlocker\lib\Settings;
use TypechoPlugin\IPBlocker\lib\Store;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

// ---------------------------------------------------------------
// آماده‌سازی داده‌های این نمای
// ---------------------------------------------------------------

$stats = Store::stats();
$cacheState = Cache::state();
$settings = Settings::get();

$exportUrl = $security->getIndex('/action/' . \TypechoPlugin\IPBlocker\Plugin::ACTION_NAME . '?do=export');

$formatBytes = static function (int $bytes): string {
    if ($bytes >= 1048576) {
        return Ip::faNumber(number_format($bytes / 1048576, 1, '.', '،')) . ' مگابایت';
    }

    if ($bytes >= 1024) {
        return Ip::faNumber(number_format($bytes / 1024, 1, '.', '،')) . ' کیلوبایت';
    }

    return Ip::faNumber((string) $bytes) . ' بایت';
};

?>
    <div class="ipb-grid ipb-grid-tools">

        <!-- اکسپورت -->
        <div class="ipb-card">
            <div class="ipb-card-head">
                <div class="ipb-card-title">
                    <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-download"></use></svg>
                    اکسپورت لیست قوانین
                </div>
            </div>

            <p class="ipb-hint">
                همه‌ی <?= Ip::faNumber((string) $stats['total']) ?> قانون فعلی به‌همراه نوع، انقضا و دلیل،
                در یک فایل JSON استاندارد دانلود می‌شود — مناسب برای بکاپ یا انتقال به نصب دیگر.
            </p>

            <div class="ipb-stat-rows">
                <div class="ipb-stat-row">
                    <span>قوانین دائمی</span><b><?= Ip::faNumber((string) $stats['permanent']) ?></b>
                </div>
                <div class="ipb-stat-row">
                    <span>قوانین موقت فعال</span><b><?= Ip::faNumber((string) $stats['temporary']) ?></b>
                </div>
                <div class="ipb-stat-row">
                    <span>آدرس‌های IPv6</span><b><?= Ip::faNumber((string) $stats['ipv6']) ?></b>
                </div>
            </div>

            <div class="ipb-card-foot">
                <a class="tr-btn primary" href="<?= $e($exportUrl) ?>">
                    <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-download"></use></svg>
                    دانلود فایل JSON
                </a>
            </div>
        </div>

        <!-- ایمپورت -->
        <div class="ipb-card">
            <div class="ipb-card-head">
                <div class="ipb-card-title">
                    <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-upload"></use></svg>
                    ایمپورت لیست قوانین
                </div>
            </div>

            <form method="post" action="<?= $e($actionUrl) ?>?do=import" enctype="multipart/form-data" id="ipb-import-form">
                <input type="hidden" name="_" value="<?= $token ?>">
                <input type="hidden" name="do" value="import">

                <div class="ipb-field">
                    <label for="ipb-import-file">انتخاب فایل JSON</label>
                    <input type="file" id="ipb-import-file" accept=".json,application/json" class="ipb-input ipb-input-file">
                </div>

                <div class="ipb-field">
                    <label for="ipb-import-json">یا محتوای JSON را این‌جا بچسبانید</label>
                    <textarea id="ipb-import-json" name="json" class="ipb-input ipb-textarea" rows="6"
                              placeholder='{"rules": [{"value": "192.0.2.1", "mode": "permanent", "reason": "اسپم"}]}' dir="ltr"></textarea>
                </div>

                <div class="ipb-field">
                    <label>سیاست برخورد با موارد تکراری</label>
                    <div class="ipb-radios">
                        <label class="ipb-radio"><input type="radio" name="mode" value="merge" checked> <span>ادغام — تکراری‌ها دست‌نخورده بمانند</span></label>
                        <label class="ipb-radio"><input type="radio" name="mode" value="update"> <span>به‌روزرسانی — تکراری‌ها بازنویسی شوند</span></label>
                        <label class="ipb-radio"><input type="radio" name="mode" value="replace"> <span>جایگزینی — همه‌ی قوانین فعلی پاک شوند</span></label>
                    </div>
                </div>

                <div class="ipb-card-foot">
                    <span class="ipb-hint">قوانینی که IP مدیر را پوشش دهند به‌دلیل امنیت رد می‌شوند.</span>
                    <button type="submit" class="tr-btn primary" lang="لیست قوانین ایمپورت شود؟">
                        <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-upload"></use></svg>
                        اجرای ایمپورت
                    </button>
                </div>
            </form>
        </div>

        <!-- وضعیت کش -->
        <div class="ipb-card">
            <div class="ipb-card-head">
                <div class="ipb-card-title">
                    <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-zap"></use></svg>
                    وضعیت کش عملکرد
                </div>
                <span class="ipb-badge <?= $cacheState['exists'] ? 'ipb-badge-ok' : 'ipb-badge-warn' ?>">
                    <?= $cacheState['exists'] ? 'فعال' : 'غیرفعال' ?>
                </span>
            </div>

            <div class="ipb-stat-rows">
                <div class="ipb-stat-row">
                    <span>مسیر فایل کش</span>
                    <code class="ipb-code ipb-code-sm" dir="ltr" title="<?= $e($cacheState['path']) ?>"><?= $e(basename(dirname($cacheState['path'])) . '/' . basename($cacheState['path'])) ?></code>
                </div>
                <div class="ipb-stat-row">
                    <span>آخرین بازسازی</span>
                    <b><?= $cacheState['generated'] > 0 ? Jalali::relative($cacheState['generated']) : '—' ?></b>
                </div>
                <div class="ipb-stat-row">
                    <span>حجم</span>
                    <b><?= $cacheState['exists'] ? $formatBytes($cacheState['size']) : '—' ?></b>
                </div>
                <?php if (!empty($cacheState['fallback'])): ?>
                    <div class="ipb-stat-row ipb-stat-warn">
                        <span>حالت</span>
                        <b>مسیر جایگزین (دایرکتوری افزونه قابل نوشتن نیست)</b>
                    </div>
                <?php endif; ?>
            </div>

            <p class="ipb-hint">
                لیست قوانین در یک فایل PHP استاتیک کش می‌شود تا بررسی هر درخواست بدون
                کوئری دیتابیس و با پشتیبانی OPcache انجام شود. پس از هر تغییر، کش به‌طور خودکار بازسازی می‌شود.
            </p>

            <div class="ipb-card-foot">
                <form method="post" action="<?= $e($actionUrl) ?>?do=rebuild-cache" class="ipb-inline-form">
                    <input type="hidden" name="_" value="<?= $token ?>">
                    <input type="hidden" name="do" value="rebuild-cache">
                    <button type="submit" class="tr-btn">
                        <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-refresh"></use></svg>
                        بازسازی دستی کش
                    </button>
                </form>
            </div>
        </div>

        <!-- نگهداری -->
        <div class="ipb-card">
            <div class="ipb-card-head">
                <div class="ipb-card-title">
                    <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-settings"></use></svg>
                    عملیات نگهداری
                </div>
            </div>

            <div class="ipb-maint-list">
                <div class="ipb-maint-item">
                    <div>
                        <b>حذف قوانین منقضی</b>
                        <p class="ipb-hint"><?= $stats['expired'] > 0 ? Ip::faNumber((string) $stats['expired']) . ' قانون منقضی آماده‌ی حذف است.' : 'قانون منقضی‌ای وجود ندارد.' ?></p>
                    </div>
                    <form method="post" action="<?= $e($actionUrl) ?>?do=purge-expired" class="ipb-inline-form">
                        <input type="hidden" name="_" value="<?= $token ?>">
                        <input type="hidden" name="do" value="purge-expired">
                        <button type="submit" class="tr-btn">اجرا</button>
                    </form>
                </div>

                <div class="ipb-maint-item">
                    <div>
                        <b>بازنشانی لیست IP های محافظت‌شده</b>
                        <p class="ipb-hint">لیست IP مدیران پاک می‌شود؛ IP فعلی شما بلافاصله دوباره ثبت خواهد شد.</p>
                    </div>
                    <form method="post" action="<?= $e($actionUrl) ?>?do=clear-protected" class="ipb-inline-form">
                        <input type="hidden" name="_" value="<?= $token ?>">
                        <input type="hidden" name="do" value="clear-protected">
                        <button type="submit" class="tr-btn" lang="لیست IP های محافظت‌شده بازنشانی شود؟">اجرا</button>
                    </form>
                </div>

                <div class="ipb-maint-item">
                    <div>
                        <b>سیاست پاکسازی خودکار لاگ</b>
                        <p class="ipb-hint">
                            <?= (int) $settings['logRetentionDays'] > 0
                                ? 'لاگ‌های قدیمی‌تر از ' . Ip::faNumber((string) $settings['logRetentionDays']) . ' روز به‌طور خودکار حذف می‌شوند.'
                                : 'پاکسازی خودکار غیرفعال است (نگهداری نامحدود).' ?>
                        </p>
                    </div>
                    <a class="tr-btn" href="<?= $e($settingsUrl) ?>">تنظیمات</a>
                </div>
            </div>
        </div>
    </div>

    <!-- راهنمای فرمت -->
    <div class="ipb-card ipb-help-card">
        <div class="ipb-card-title">
            <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-info"></use></svg>
            فرمت فایل ایمپورت/اکسپورت
        </div>
        <p class="ipb-hint">
            فایل JSON باید آرایه‌ای از قوانین یا شیئی با کلید <code dir="ltr">rules</code> باشد.
            هر قانون این فیلدها را می‌پذیرد:
        </p>
        <ul class="ipb-help-list">
            <li><code dir="ltr">value</code> — آدرس IP یا بازه‌ی CIDR (الزامی)</li>
            <li><code dir="ltr">mode</code> — <code dir="ltr">permanent</code> یا <code dir="ltr">temporary</code></li>
            <li><code dir="ltr">expires</code> — زمان انقضای Unix Timestamp (برای حالت موقت)</li>
            <li><code dir="ltr">reason</code> — دلیل مسدودسازی (اختیاری)</li>
        </ul>
    </div>
