<?php
/**
 * نمای «لاگ درخواست‌ها» — آمار، پرتکرارترین‌ها، جدول و پاک‌سازی
 *
 * @package IPBlocker
 * @since   1.1.0 (از پنل مستقل نسخه‌ی ۱.۰.۰ به نمای داخلی تبدیل شد)
 */

use TypechoPlugin\IPBlocker\lib\Ip;
use TypechoPlugin\IPBlocker\lib\Jalali;
use TypechoPlugin\IPBlocker\lib\Logger;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

// ---------------------------------------------------------------
// آماده‌سازی داده‌های این نمای
// ---------------------------------------------------------------

$stats = Logger::stats();

$filters = [
    'q'     => trim((string) $request->get('q', '')),
    'range' => (string) $request->get('range', 'all'),
];
$page = max(1, (int) $request->get('page', 1));

$list = Logger::list($filters, $page, 20);

?>
    <!-- داشبورد آماری -->
    <div class="ipb-kpis">
        <div class="ipb-kpi">
            <div>
                <div class="ipb-kpi-label">کل رکوردها</div>
                <div class="ipb-kpi-value"><?= Ip::faNumber((string) $stats['total']) ?></div>
            </div>
            <div class="ipb-kpi-icon"><svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-database"></use></svg></div>
        </div>
        <div class="ipb-kpi">
            <div>
                <div class="ipb-kpi-label">آی‌پی‌های یکتا</div>
                <div class="ipb-kpi-value"><?= Ip::faNumber((string) $stats['unique']) ?></div>
            </div>
            <div class="ipb-kpi-icon ipb-tone-ok"><svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-users"></use></svg></div>
        </div>
        <div class="ipb-kpi">
            <div>
                <div class="ipb-kpi-label">مسدودشده امروز</div>
                <div class="ipb-kpi-value"><?= Ip::faNumber((string) $stats['today']) ?></div>
            </div>
            <div class="ipb-kpi-icon ipb-tone-warn"><svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-activity"></use></svg></div>
        </div>
        <div class="ipb-kpi">
            <div>
                <div class="ipb-kpi-label">آخرین رویداد</div>
                <div class="ipb-kpi-value ipb-kpi-value-sm"><?= $stats['last'] ? Jalali::relative((int) $stats['last']['created']) : '—' ?></div>
                <div class="ipb-kpi-sub"><?= $stats['last'] ? '<code dir="ltr">' . $e($stats['last']['ip']) . '</code>' : 'هنوز رویدادی ثبت نشده' ?></div>
            </div>
            <div class="ipb-kpi-icon"><svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-clock"></use></svg></div>
        </div>
    </div>

    <?php if (!empty($stats['top'])): ?>
        <div class="ipb-card ipb-top-card">
            <div class="ipb-card-title">
                <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-alert"></use></svg>
                پرتکرارترین آی‌پی‌های مسدودشده
            </div>
            <div class="ipb-top-list">
                <?php foreach ($stats['top'] as $top): ?>
                    <span class="ipb-chip">
                        <code dir="ltr"><?= $e($top['ip']) ?></code>
                        <b><?= Ip::faNumber((string) $top['num']) ?> بار</b>
                        <?php if (Ip::isValid($top['ip'])): ?>
                            <form class="ipb-inline-form" method="post" action="<?= $e($actionUrl) ?>?do=quick-block">
                                <input type="hidden" name="_" value="<?= $token ?>">
                                <input type="hidden" name="do" value="quick-block">
                                <input type="hidden" name="ip" value="<?= $e($top['ip']) ?>">
                                <button type="submit" class="ipb-mini-btn ipb-mini-danger">بلاک دائمی</button>
                            </form>
                        <?php endif; ?>
                    </span>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- فیلتر و جستجو -->
    <form class="ipb-card ipb-filters" method="get" action="">
        <input type="hidden" name="panel" value="<?= $e($request->get('panel', \TypechoPlugin\IPBlocker\Plugin::PANEL_MANAGE)) ?>">
        <input type="hidden" name="view" value="logs">

        <div class="ipb-filter-row">
            <div class="ipb-search">
                <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-search"></use></svg>
                <input type="text" name="q" class="ipb-input" placeholder="جستجو: IP، URL، دلیل یا قانون…"
                       value="<?= $e($filters['q']) ?>">
            </div>

            <select name="range" class="ipb-input ipb-input-slim">
                <option value="all" <?= $filters['range'] === 'all' ? 'selected' : '' ?>>همه‌ی زمان‌ها</option>
                <option value="today" <?= $filters['range'] === 'today' ? 'selected' : '' ?>>امروز</option>
                <option value="week" <?= $filters['range'] === 'week' ? 'selected' : '' ?>>۷ روز اخیر</option>
                <option value="month" <?= $filters['range'] === 'month' ? 'selected' : '' ?>>۳۰ روز اخیر</option>
            </select>

            <button type="submit" class="tr-btn">
                <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-filter"></use></svg>
                اعمال فیلتر
            </button>

            <?php if ($filters['q'] !== '' || $filters['range'] !== 'all'): ?>
                <a class="tr-btn ipb-btn-ghost" href="<?= $e($tabUrl('logs')) ?>">حذف فیلترها</a>
            <?php endif; ?>
        </div>
    </form>

    <!-- جدول لاگ -->
    <form class="ipb-card ipb-table-card" method="post" action="<?= $e($actionUrl) ?>?do=logs-delete" id="ipb-bulk-form">
        <input type="hidden" name="_" value="<?= $token ?>">
        <input type="hidden" name="do" value="logs-delete">

        <div class="ipb-card-head">
            <div class="ipb-card-title">
                <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-list"></use></svg>
                رکوردهای لاگ
                <span class="ipb-badge"><?= Ip::faNumber((string) $list['total']) ?> مورد</span>
            </div>

            <div class="ipb-card-actions">
                <label class="ipb-select-all">
                    <input type="checkbox" id="ipb-select-all">
                    انتخاب همه
                </label>
                <button type="submit" class="tr-btn ipb-btn-danger" lang="رکوردهای انتخاب‌شده حذف شوند؟">
                    <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-trash"></use></svg>
                    حذف انتخاب‌شده‌ها
                </button>
            </div>
        </div>

        <?php if (empty($list['rows'])): ?>
            <div class="ipb-empty">
                <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-inbox"></use></svg>
                رکوردی یافت نشد. تا زمانی که درخواستی مسدود نشود، لاگی ثبت نمی‌شود.
            </div>
        <?php else: ?>
            <div class="ipb-table-wrap">
                <table class="ipb-table">
                    <thead>
                    <tr>
                        <th class="ipb-col-check"></th>
                        <th>زمان</th>
                        <th>آدرس IP</th>
                        <th>قانون</th>
                        <th>URL درخواست</th>
                        <th>مرورگر</th>
                        <th class="ipb-col-actions">عملیات</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($list['rows'] as $row): ?>
                        <tr>
                            <td class="ipb-col-check"><input type="checkbox" name="ids[]" value="<?= (int) $row['id'] ?>" class="ipb-check"></td>

                            <td class="ipb-time-cell">
                                <div title="<?= $e(Jalali::full((int) $row['created'])) ?>"><?= Jalali::relative((int) $row['created']) ?></div>
                                <div class="ipb-sub"><?= Jalali::short((int) $row['created']) ?></div>
                            </td>

                            <td>
                                <code class="ipb-code" dir="ltr"><?= $e($row['ip']) ?></code>
                            </td>

                            <td>
                                <code class="ipb-code ipb-code-sm" dir="ltr"><?= $e($row['ruleValue'] ?: '—') ?></code>
                                <?php if (trim((string) $row['reason']) !== ''): ?>
                                    <div class="ipb-sub" title="<?= $e($row['reason']) ?>"><?= $e($row['reason']) ?></div>
                                <?php endif; ?>
                            </td>

                            <td class="ipb-url-cell">
                                <code class="ipb-code ipb-code-sm" dir="ltr" title="<?= $e($row['url']) ?>"><?= $e(mb_substr((string) $row['url'], 0, 60, 'UTF-8')) ?><?= mb_strlen((string) $row['url']) > 60 ? '…' : '' ?></code>
                                <?php if (!empty($row['method'])): ?>
                                    <span class="ipb-badge"><?= $e($row['method']) ?></span>
                                <?php endif; ?>
                            </td>

                            <td class="ipb-agent-cell">
                                <span title="<?= $e($row['agent']) ?>"><?= $e(mb_substr((string) $row['agent'], 0, 40, 'UTF-8')) ?><?= mb_strlen((string) $row['agent']) > 40 ? '…' : '' ?></span>
                            </td>

                            <td class="ipb-col-actions">
                                <div class="ipb-actions">
                                    <?php if (Ip::isValid((string) $row['ip'])): ?>
                                        <form class="ipb-inline-form" method="post" action="<?= $e($actionUrl) ?>?do=quick-block">
                                            <input type="hidden" name="_" value="<?= $token ?>">
                                            <input type="hidden" name="do" value="quick-block">
                                            <input type="hidden" name="ip" value="<?= $e($row['ip']) ?>">
                                            <input type="hidden" name="reason" value="مسدودسازی از روی لاگ — درخواست به <?= $e(mb_substr((string) $row['url'], 0, 120, 'UTF-8')) ?>">
                                            <button type="submit" class="ipb-mini-btn ipb-mini-danger" title="این IP را دائمی مسدود کن">
                                                <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-shield"></use></svg>
                                                بلاک
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </form>

    <!-- ابزار پاک‌سازی -->
    <div class="ipb-maintenance">
        <form method="post" action="<?= $e($actionUrl) ?>?do=logs-cleanup" class="ipb-inline-form ipb-maintenance-form">
            <input type="hidden" name="_" value="<?= $token ?>">
            <input type="hidden" name="do" value="logs-cleanup">
            <label class="ipb-hint" for="ipb-cleanup-days">پاک‌سازی رکوردهای قدیمی‌تر از</label>
            <input type="number" name="days" id="ipb-cleanup-days" class="ipb-input ipb-input-num" min="1" max="3650" value="30">
            <label class="ipb-hint" for="ipb-cleanup-days">روز</label>
            <button type="submit" class="tr-btn">
                <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-refresh"></use></svg>
                پاک‌سازی قدیمی‌ها
            </button>
        </form>

        <form method="post" action="<?= $e($actionUrl) ?>?do=logs-purge" class="ipb-inline-form">
            <input type="hidden" name="_" value="<?= $token ?>">
            <input type="hidden" name="do" value="logs-purge">
            <button type="submit" class="tr-btn ipb-btn-danger" lang="تمام لاگ‌ها برای همیشه پاک شوند؟">
                <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-trash"></use></svg>
                پاک‌سازی کامل لاگ‌ها
            </button>
        </form>
    </div>

    <!-- صفحه‌بندی -->
    <?php if ($list['pages'] > 1): ?>
        <div class="ipb-pagination">
            <?php
            $makeUrl = static function (int $p) use ($filters): string {
                $params = array_filter($filters, static fn ($v) => $v !== '' && $v !== 'all');
                $params['page'] = $p;
                $params['view'] = 'logs';

                return '?' . http_build_query(['panel' => \TypechoPlugin\IPBlocker\Plugin::PANEL_MANAGE] + $params);
            };

            if ($list['page'] > 1) {
                echo '<a class="ipb-page-btn" href="' . $e($makeUrl($list['page'] - 1)) . '">قبلی</a>';
            }

            $from = max(1, $list['page'] - 2);
            $to = min($list['pages'], $list['page'] + 2);

            for ($p = $from; $p <= $to; $p++) {
                $active = $p === $list['page'] ? ' ipb-page-active' : '';
                echo '<a class="ipb-page-btn' . $active . '" href="' . $e($makeUrl($p)) . '">' . Ip::faNumber((string) $p) . '</a>';
            }

            if ($list['page'] < $list['pages']) {
                echo '<a class="ipb-page-btn" href="' . $e($makeUrl($list['page'] + 1)) . '">بعدی</a>';
            }
            ?>
            <span class="ipb-page-info">صفحه‌ی <?= Ip::faNumber((string) $list['page']) ?> از <?= Ip::faNumber((string) $list['pages']) ?></span>
        </div>
    <?php endif; ?>
