<?php
/**
 * نمای «مدیریت آی‌پی‌ها» — داشبورد، فرم افزودن، فیلتر و جدول قوانین
 *
 * @package IPBlocker
 * @since   1.1.0 (از پنل مستقل نسخه‌ی ۱.۰.۰ به نمای داخلی تبدیل شد)
 */

use TypechoPlugin\IPBlocker\lib\Cache;
use TypechoPlugin\IPBlocker\lib\Ip;
use TypechoPlugin\IPBlocker\lib\Jalali;
use TypechoPlugin\IPBlocker\lib\Logger;
use TypechoPlugin\IPBlocker\lib\Settings;
use TypechoPlugin\IPBlocker\lib\Store;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

// ---------------------------------------------------------------
// آماده‌سازی داده‌های این نمای
// ---------------------------------------------------------------

$stats = Store::stats();
$logStats = Logger::stats();
$settings = Settings::get();
$cacheState = Cache::state();
$currentIp = Ip::normalize($request->getIp());

$filters = [
    'q'       => trim((string) $request->get('q', '')),
    'type'    => (string) $request->get('type', 'all'),
    'version' => (string) $request->get('version', 'all'),
    'status'  => (string) $request->get('status', 'all'),
];
$page = max(1, (int) $request->get('page', 1));

$list = Store::list($filters, $page, 20);

?>
    <?php if (($settings['enabled']) !== '1'): ?>
        <div class="ipb-alert ipb-alert-warn">
            <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-alert"></use></svg>
            مسدودسازی در حال حاضر در <a href="<?= $e($settingsUrl) ?>">تنظیمات افزونه</a> غیرفعال است و هیچ درخواستی مسدود نمی‌شود.
        </div>
    <?php endif; ?>

    <?php if (!$cacheState['writable']): ?>
        <div class="ipb-alert ipb-alert-warn">
            <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-alert"></use></svg>
            دایرکتوری کش قابل نوشتن نیست؛ از مسیر جایگزین سیستم استفاده می‌شود و عملکرد افت می‌کند. جزئیات در تب «ابزارها».
        </div>
    <?php endif; ?>

    <!-- داشبورد آماری -->
    <div class="ipb-kpis">
        <div class="ipb-kpi">
            <div>
                <div class="ipb-kpi-label">کل قوانین</div>
                <div class="ipb-kpi-value"><?= Ip::faNumber((string) $stats['total']) ?></div>
                <div class="ipb-kpi-sub"><?= Ip::faNumber((string) $stats['ipv4']) ?> آدرس IPv4 — <?= Ip::faNumber((string) $stats['ipv6']) ?> آدرس IPv6</div>
            </div>
            <div class="ipb-kpi-icon"><svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-shield"></use></svg></div>
        </div>
        <div class="ipb-kpi">
            <div>
                <div class="ipb-kpi-label">بلاک دائمی</div>
                <div class="ipb-kpi-value"><?= Ip::faNumber((string) $stats['permanent']) ?></div>
                <div class="ipb-kpi-sub"><?= Ip::faNumber((string) $stats['disabled']) ?> قانون غیرفعال</div>
            </div>
            <div class="ipb-kpi-icon ipb-tone-danger"><svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-x"></use></svg></div>
        </div>
        <div class="ipb-kpi">
            <div>
                <div class="ipb-kpi-label">بلاک موقت فعال</div>
                <div class="ipb-kpi-value"><?= Ip::faNumber((string) $stats['temporary']) ?></div>
                <div class="ipb-kpi-sub"><?= $stats['expired'] > 0 ? Ip::faNumber((string) $stats['expired']) . ' قانون منقضی‌شده' : 'بدون قانون منقضی' ?></div>
            </div>
            <div class="ipb-kpi-icon ipb-tone-warn"><svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-clock"></use></svg></div>
        </div>
        <div class="ipb-kpi">
            <div>
                <div class="ipb-kpi-label">بازدیدهای مسدودشده</div>
                <div class="ipb-kpi-value"><?= Ip::faNumber((string) $stats['hits']) ?></div>
                <div class="ipb-kpi-sub"><?= Ip::faNumber((string) $logStats['today']) ?> درخواست فقط امروز</div>
            </div>
            <div class="ipb-kpi-icon ipb-tone-ok"><svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-activity"></use></svg></div>
        </div>
    </div>

    <div class="ipb-grid">
        <!-- فرم افزودن -->
        <form class="ipb-card ipb-add-form" method="post" action="<?= $e($actionUrl) ?>?do=add" id="ipb-add-form">
            <input type="hidden" name="_" value="<?= $token ?>">
            <input type="hidden" name="do" value="add">

            <div class="ipb-card-head">
                <div class="ipb-card-title">
                    <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-plus"></use></svg>
                    افزودن قانون مسدودسازی
                </div>
                <span class="ipb-badge ipb-badge-ok" id="ipb-input-verdict">در انتظار ورودی…</span>
            </div>

            <div class="ipb-field">
                <label for="ipb-value">آدرس IP یا بازه‌ی CIDR <span class="ipb-req">*</span></label>
                <input type="text" id="ipb-value" name="value" class="ipb-input ipb-input-mono" required
                       placeholder="192.0.2.15 — 10.0.0.0/8 — 2001:db8::1 — 2001:db8::/32"
                       autocomplete="off" spellcheck="false" dir="ltr">
                <p class="ipb-hint">IPv4 و IPv6 پشتیبانی می‌شوند؛ آدرس‌های نگاشت‌یافته به‌صورت خودکار استاندارد می‌شوند.</p>
            </div>

            <div class="ipb-row">
                <div class="ipb-field">
                    <label for="ipb-mode">نوع مسدودسازی</label>
                    <select id="ipb-mode" name="mode" class="ipb-input">
                        <option value="permanent">دائمی</option>
                        <option value="temporary">موقت</option>
                    </select>
                </div>
                <div class="ipb-field ipb-duration" hidden id="ipb-duration-field">
                    <label for="ipb-duration">مدت مسدودسازی</label>
                    <div class="ipb-duration-controls">
                        <input type="number" id="ipb-duration" name="duration" class="ipb-input" min="1" max="1000" value="24">
                        <select id="ipb-unit" name="unit" class="ipb-input">
                            <option value="m">دقیقه</option>
                            <option value="h" selected>ساعت</option>
                            <option value="d">روز</option>
                            <option value="w">هفته</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="ipb-field">
                <label for="ipb-reason">دلیل مسدودسازی (اختیاری)</label>
                <input type="text" id="ipb-reason" name="reason" class="ipb-input" maxlength="480"
                       placeholder="مثلاً: تلاش مکرر برای نفوذ — اسپم نظرات">
            </div>

            <div class="ipb-card-foot">
                <span class="ipb-hint" id="ipb-expiry-preview" hidden></span>
                <button type="submit" class="tr-btn primary">
                    <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-shield"></use></svg>
                    مسدودسازی
                </button>
            </div>
        </form>

        <!-- وضعیت IP فعلی و محافظت‌ها -->
        <div class="ipb-card ipb-side">
            <div class="ipb-card-head">
                <div class="ipb-card-title">
                    <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-key"></use></svg>
                    محافظت مدیر
                </div>
            </div>

            <div class="ipb-selfip">
                <span class="ipb-hint">IP فعلی شما</span>
                <code class="ipb-code" dir="ltr"><?= $e($currentIp ?? 'نامشخص') ?></code>
                <?php if ($currentIp !== null): ?>
                    <span class="ipb-badge ipb-badge-ok">محافظت‌شده</span>
                <?php endif; ?>
            </div>

            <p class="ipb-hint">
                IP مدیرانِ واردشده به‌طور خودکار ثبت می‌شود و افزودن هر بازه‌ای که آن‌ها را پوشش دهد مسدود است،
                تا پنل مدیریت هرگز قفل نشود.
            </p>

            <?php $protectedList = Store::protectedIps(); ?>
            <?php if (!empty($protectedList)): ?>
                <div class="ipb-protected-list">
                    <div class="ipb-hint">آدرس‌های محافظت‌شده (<?= Ip::faNumber((string) count($protectedList)) ?>)</div>
                    <ul>
                        <?php foreach (array_slice($protectedList, -12, preserve_keys: true) as $pip => $ptime): ?>
                            <li><code dir="ltr"><?= $e($pip) ?></code><span><?= Jalali::relative((int) $ptime) ?></span></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- فیلتر و جستجو -->
    <form class="ipb-card ipb-filters" method="get" action="">
        <input type="hidden" name="panel" value="<?= $e($request->get('panel', \TypechoPlugin\IPBlocker\Plugin::PANEL_MANAGE)) ?>">
        <input type="hidden" name="view" value="manage">

        <div class="ipb-filter-row">
            <div class="ipb-search">
                <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-search"></use></svg>
                <input type="text" name="q" class="ipb-input" placeholder="جستجو در آدرس‌ها و دلایل…"
                       value="<?= $e($filters['q']) ?>">
            </div>

            <select name="type" class="ipb-input ipb-input-slim">
                <option value="all" <?= $filters['type'] === 'all' ? 'selected' : '' ?>>همه‌ی انواع</option>
                <option value="permanent" <?= $filters['type'] === 'permanent' ? 'selected' : '' ?>>دائمی</option>
                <option value="temporary" <?= $filters['type'] === 'temporary' ? 'selected' : '' ?>>موقت فعال</option>
                <option value="expired" <?= $filters['type'] === 'expired' ? 'selected' : '' ?>>منقضی‌شده</option>
            </select>

            <select name="version" class="ipb-input ipb-input-slim">
                <option value="all" <?= $filters['version'] === 'all' ? 'selected' : '' ?>>IPv4 و IPv6</option>
                <option value="ipv4" <?= $filters['version'] === 'ipv4' ? 'selected' : '' ?>>فقط IPv4</option>
                <option value="ipv6" <?= $filters['version'] === 'ipv6' ? 'selected' : '' ?>>فقط IPv6</option>
            </select>

            <select name="status" class="ipb-input ipb-input-slim">
                <option value="all" <?= $filters['status'] === 'all' ? 'selected' : '' ?>>همه‌ی وضعیت‌ها</option>
                <option value="enabled" <?= $filters['status'] === 'enabled' ? 'selected' : '' ?>>فعال</option>
                <option value="disabled" <?= $filters['status'] === 'disabled' ? 'selected' : '' ?>>غیرفعال</option>
            </select>

            <button type="submit" class="tr-btn">
                <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-filter"></use></svg>
                اعمال فیلتر
            </button>

            <?php if ($filters['q'] !== '' || $filters['type'] !== 'all' || $filters['version'] !== 'all' || $filters['status'] !== 'all'): ?>
                <a class="tr-btn ipb-btn-ghost" href="<?= $e($tabUrl('manage')) ?>">حذف فیلترها</a>
            <?php endif; ?>
        </div>
    </form>

    <!-- جدول قوانین -->
    <form class="ipb-card ipb-table-card" method="post" action="<?= $e($actionUrl) ?>?do=delete" id="ipb-bulk-form">
        <input type="hidden" name="_" value="<?= $token ?>">
        <input type="hidden" name="do" value="delete">

        <div class="ipb-card-head">
            <div class="ipb-card-title">
                <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-list"></use></svg>
                قوانین مسدودسازی
                <span class="ipb-badge"><?= Ip::faNumber((string) $list['total']) ?> مورد</span>
            </div>

            <div class="ipb-card-actions">
                <label class="ipb-select-all">
                    <input type="checkbox" id="ipb-select-all">
                    انتخاب همه
                </label>
                <button type="submit" class="tr-btn ipb-btn-danger" lang="قوانین انتخاب‌شده حذف شوند؟">
                    <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-trash"></use></svg>
                    حذف انتخاب‌شده‌ها
                </button>
            </div>
        </div>

        <?php if (empty($list['rows'])): ?>
            <div class="ipb-empty">
                <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-inbox"></use></svg>
                هیچ قانونی یافت نشد. اولین آدرس را از فرم بالا اضافه کنید.
            </div>
        <?php else: ?>
            <div class="ipb-table-wrap">
                <table class="ipb-table">
                    <thead>
                    <tr>
                        <th class="ipb-col-check"></th>
                        <th>آدرس / بازه</th>
                        <th>نوع</th>
                        <th>انقضا</th>
                        <th>دلیل</th>
                        <th class="ipb-col-num">بازدید</th>
                        <th class="ipb-col-actions">عملیات</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($list['rows'] as $row): ?>
                        <?php
                        $isExpired = (int) $row['expires'] > 0 && (int) $row['expires'] <= time();
                        $isTemp = ($row['mode'] ?? '') === 'temporary';
                        $isEnabled = (int) ($row['enabled'] ?? 1) === 1;
                        ?>
                        <tr class="<?= $isEnabled ? '' : 'ipb-row-disabled' ?><?= $isExpired ? ' ipb-row-expired' : '' ?>">
                            <td class="ipb-col-check"><input type="checkbox" name="ids[]" value="<?= (int) $row['id'] ?>" class="ipb-check"></td>

                            <td>
                                <div class="ipb-value">
                                    <code class="ipb-code" dir="ltr"><?= $e($row['value']) ?></code>
                                    <span class="ipb-badge <?= ($row['version'] ?? '') === 'ipv6' ? 'ipb-badge-v6' : 'ipb-badge-v4' ?>">
                                        <?= ($row['version'] ?? '') === 'ipv6' ? 'IPv6' : 'IPv4' ?>
                                    </span>
                                </div>
                                <?php if ((int) ($row['isCidr'] ?? 0) === 1): ?>
                                    <div class="ipb-sub">بازه‌ی /<?= $e($row['prefix']) ?> — <?= Ip::faNumber(Ip::rangeSize((int) $row['prefix'], ($row['version'] ?? '') === 'ipv6' ? 128 : 32)) ?> آدرس</div>
                                <?php endif; ?>
                            </td>

                            <td>
                                <?php if ($isTemp): ?>
                                    <span class="ipb-badge ipb-badge-warn">موقت</span>
                                <?php else: ?>
                                    <span class="ipb-badge ipb-badge-danger">دائمی</span>
                                <?php endif; ?>
                                <?php if (!$isEnabled): ?>
                                    <span class="ipb-badge">غیرفعال</span>
                                <?php endif; ?>
                            </td>

                            <td>
                                <?php if (!$isTemp): ?>
                                    <span class="ipb-sub">—</span>
                                <?php elseif ($isExpired): ?>
                                    <span class="ipb-badge">منقضی</span>
                                    <div class="ipb-sub"><?= Jalali::short((int) $row['expires']) ?></div>
                                <?php else: ?>
                                    <span class="ipb-expiry" title="تا <?= Jalali::full((int) $row['expires']) ?>"><?= Jalali::remaining((int) $row['expires']) ?></span>
                                    <div class="ipb-sub"><?= Jalali::short((int) $row['expires']) ?></div>
                                <?php endif; ?>
                            </td>

                            <td class="ipb-reason-cell">
                                <?php if (trim((string) $row['reason']) !== ''): ?>
                                    <span title="<?= $e($row['reason']) ?>"><?= $e($row['reason']) ?></span>
                                <?php else: ?>
                                    <span class="ipb-sub">—</span>
                                <?php endif; ?>
                            </td>

                            <td class="ipb-col-num"><?= Ip::faNumber((string) ($row['hits'] ?? 0)) ?></td>

                            <td class="ipb-col-actions">
                                <div class="ipb-actions">
                                    <?php if ($isTemp && !$isExpired): ?>
                                        <button type="button" class="ipb-mini-btn ipb-extend-btn" data-id="<?= (int) $row['id'] ?>" title="تمدید ۲۴ ساعت دیگر">
                                            <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-clock"></use></svg>
                                            تمدید
                                        </button>
                                    <?php endif; ?>

                                    <form class="ipb-inline-form" method="post" action="<?= $e($actionUrl) ?>?do=toggle">
                                        <input type="hidden" name="_" value="<?= $token ?>">
                                        <input type="hidden" name="do" value="toggle">
                                        <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                                        <input type="hidden" name="state" value="<?= $isEnabled ? '0' : '1' ?>">
                                        <button type="submit" class="ipb-mini-btn">
                                            <?= $isEnabled ? 'غیرفعال‌سازی' : 'فعال‌سازی' ?>
                                        </button>
                                    </form>

                                    <form class="ipb-inline-form" method="post" action="<?= $e($actionUrl) ?>?do=delete">
                                        <input type="hidden" name="_" value="<?= $token ?>">
                                        <input type="hidden" name="do" value="delete">
                                        <input type="hidden" name="ids[]" value="<?= (int) $row['id'] ?>">
                                        <button type="submit" class="ipb-mini-btn ipb-mini-danger" lang="این قانون حذف شود؟">
                                            <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-trash"></use></svg>
                                            حذف
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </form>

    <div class="ipb-maintenance">
        <form method="post" action="<?= $e($actionUrl) ?>?do=purge-expired" class="ipb-inline-form">
            <input type="hidden" name="_" value="<?= $token ?>">
            <input type="hidden" name="do" value="purge-expired">
            <button type="submit" class="tr-btn">
                <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-refresh"></use></svg>
                حذف قوانین منقضی<?= $stats['expired'] > 0 ? ' (' . Ip::faNumber((string) $stats['expired']) . ')' : '' ?>
            </button>
        </form>
    </div>

    <!-- صفحه‌بندی -->
    <?php if ($list['pages'] > 1): ?>
        <div class="ipb-pagination">
            <?php
            $pageLinks = [];
            $makeUrl = static function (int $p) use ($filters): string {
                $params = array_filter($filters, static fn ($v) => $v !== '' && $v !== 'all');
                $params['page'] = $p;
                $params['view'] = 'manage';

                return '?' . http_build_query(['panel' => \TypechoPlugin\IPBlocker\Plugin::PANEL_MANAGE] + $params);
            };

            if ($list['page'] > 1) {
                $pageLinks[] = '<a class="ipb-page-btn" href="' . $e($makeUrl($list['page'] - 1)) . '">قبلی</a>';
            }

            $from = max(1, $list['page'] - 2);
            $to = min($list['pages'], $list['page'] + 2);

            for ($p = $from; $p <= $to; $p++) {
                $active = $p === $list['page'] ? ' ipb-page-active' : '';
                $pageLinks[] = '<a class="ipb-page-btn' . $active . '" href="' . $e($makeUrl($p)) . '">' . Ip::faNumber((string) $p) . '</a>';
            }

            if ($list['page'] < $list['pages']) {
                $pageLinks[] = '<a class="ipb-page-btn" href="' . $e($makeUrl($list['page'] + 1)) . '">بعدی</a>';
            }

            echo implode('', $pageLinks);
            ?>
            <span class="ipb-page-info">صفحه‌ی <?= Ip::faNumber((string) $list['page']) ?> از <?= Ip::faNumber((string) $list['pages']) ?></span>
        </div>
    <?php endif; ?>
