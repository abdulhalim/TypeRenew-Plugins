<?php
/**
 * پنل یکپارچه‌ی IP Blocker — مدیریت، لاگ‌ها و ابزارها در سه نمای داخلی
 *
 * این فایل توسط extending.php در بستر پنل TypeRenew بارگذاری می‌شود
 * و $options / $security / $request / $user در دسترس است.
 *
 * تنها مدخل منوی این پنل ثبت شده است؛ نماهای «logs» و «tools» با
 * پارامتر view= در همین صفحه بارگذاری می‌شوند. فایل‌های
 * panels/logs.php و panels/tools.php صرفاً برای سازگاری نشانی‌های
 * نسخه‌ی ۱.۰.۰، همین فایل را با نمای متناظر فراخوانی می‌کنند.
 *
 * @package IPBlocker
 * @since   1.1.0
 */

use TypechoPlugin\IPBlocker\Plugin;
use TypechoPlugin\IPBlocker\lib\Ip;
use TypechoPlugin\IPBlocker\lib\Logger;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

// ---------------------------------------------------------------
// نمای فعال — فایل‌های alias قدیمی متغیر $ipbView را پیش‌تنظیم می‌کنند
// (نام اختصاصی تا هرگز با متغیرهای محیط پنل تصادم نکند)
// ---------------------------------------------------------------

if (isset($ipbView) && in_array($ipbView, Plugin::VIEWS, true)) {
    $view = $ipbView;
} else {
    $view = (string) $request->get('view', 'manage');
    $view = in_array($view, Plugin::VIEWS, true) ? $view : 'manage';
}

// ---------------------------------------------------------------
// داده‌ها و ابزارهای مشترک همه‌ی نماها
// ---------------------------------------------------------------

$actionUrl = $options->index . '/action/' . Plugin::ACTION_NAME;
$token = htmlspecialchars($security->getToken($request->getRequestUrl()), ENT_QUOTES, 'UTF-8');

$e = static function ($value): string {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
};

/** نشانی هر تب (همیشه به نشانی استاندارد پنل یکپارچه اشاره می‌کند) */
$tabUrl = static function (string $v): string {
    return \Utils\Helper::url(Plugin::PANEL_MANAGE) . '&view=' . $v;
};

$tabs = [
    'manage' => ['مدیریت آی‌پی‌ها', 'i-shield', 'مدیریت آی‌پی‌های مسدود'],
    'logs'   => ['لاگ درخواست‌ها', 'i-list', 'لاگ درخواست‌های مسدودشده'],
    'tools'  => ['ابزارها', 'i-settings', 'ابزارهای IP Blocker'],
];

$iconsUrl = $options->adminStaticUrl('img', 'icons.svg', true);
$settingsUrl = $options->adminUrl('options-plugin.php?config=IPBlocker');

// اجرای شانس‌محور سیاست نگهداری لاگ (مثل نسخه‌های قبل، هنگام بازدید پنل)
if (random_int(1, 20) === 1) {
    try {
        Logger::runRetentionPolicy();
    } catch (\Throwable $t) {
        // نگهداری اختیاری است
    }
}

?>
<div class="ipb-wrap" dir="rtl">

    <div class="typecho-page-title ipb-page-title">
        <h2><?= $e($tabs[$view][2]) ?></h2>
    </div>

    <!-- نوار تب — جایگزین مدخل‌های منوی جداگانه -->
    <nav class="ipb-tabs" role="tablist" aria-label="بخش‌های IP Blocker">
        <?php foreach ($tabs as $tabKey => [$tabLabel, $tabIcon, $tabTitle]): ?>
            <a class="ipb-tab<?= $view === $tabKey ? ' ipb-tab-active' : '' ?>"
               href="<?= $e($tabUrl($tabKey)) ?>" role="tab"
               aria-selected="<?= $view === $tabKey ? 'true' : 'false' ?>" title="<?= $e($tabTitle) ?>">
                <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#<?= $e($tabIcon) ?>"></use></svg>
                <span><?= $e($tabLabel) ?></span>
            </a>
        <?php endforeach; ?>

        <span class="ipb-tabs-aside">
            <a class="tr-btn" href="<?= $e($settingsUrl) ?>">
                <svg class="tr-ico" aria-hidden="true"><use href="<?= $e($iconsUrl) ?>#i-gear"></use></svg>
                تنظیمات
            </a>
        </span>
    </nav>

    <?php require __DIR__ . '/views/' . $view . '.php'; ?>

</div>
