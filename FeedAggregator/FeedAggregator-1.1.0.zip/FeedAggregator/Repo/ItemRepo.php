<?php
/**
 * انبار داده آیتم‌های خوراک (کش مطالب)
 *
 * عملیات ذخیره، بازیابی، پاک‌سازی و پرس‌وجوی آیتم‌های دریافتی از
 * خوراک‌ها. جلوگیری از ثبت مطالب تکراری از طریق کلید یکتای
 * (feedId + uidHash) در سطح دیتابیس انجام می‌شود.
 *
 * @package FeedAggregator
 */
namespace TypechoPlugin\FeedAggregator\Repo;

use Typecho\Db;
use TypechoPlugin\FeedAggregator\Install;
use TypechoPlugin\FeedAggregator\Util;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class ItemRepo
{
    /**
     * نام جدول برای query builder
     *
     * @return string
     */
    private static function table(): string
    {
        return 'table.' . Install::ITEMS_TABLE;
    }

    /**
     * درج یا نادیده‌گرفتن یک آیتم (جلوگیری از تکراری)
     *
     * اگر آیتمی با همین uid برای این خوراک قبلاً ذخیره شده باشد،
     * مقدار false برگردانده می‌شود و هیچ ردیفی ایجاد نمی‌شود.
     *
     * @param int                 $feedId شناسه خوراک
     * @param array<string, mixed> $item  داده‌های آیتم
     * @return int|null شناسه ردیف جدید یا null در صورت تکراری بودن
     */
    public static function store(int $feedId, array $item): ?int
    {
        $db = Db::get();
        $now = time();

        // بررسی وجود پیش از درج: آیتم تکراری در همین خوراک؟
        // (بررسی اولیه؛ رعایت نهایی کلید یکتا نیز در سطح دیتابیس است)
        $existing = $db->fetchRow(
            $db->select('id')->from(self::table())
                ->where('feedId = ? AND uidHash = ?', $feedId, (string) $item['uid'])
                ->limit(1)
        );

        if (!empty($existing)) {
            return null;
        }

        try {
            // پارامتر سوم Db::INSERT باعث می‌شود query شناسه ردیف جدید را برگرداند
            return (int) $db->query(
                $db->insert(self::table())->rows([
                    'feedId'    => $feedId,
                    'uidHash'   => (string) $item['uid'],
                    'title'     => mb_substr((string) $item['title'], 0, 480, 'UTF-8'),
                    'url'       => mb_substr((string) $item['url'], 0, 700, 'UTF-8'),
                    'author'    => mb_substr((string) $item['author'], 0, 180, 'UTF-8'),
                    'excerpt'   => mb_substr((string) $item['excerpt'], 0, 900, 'UTF-8'),
                    'content'   => (string) $item['content'],
                    'image'     => mb_substr((string) $item['image'], 0, 700, 'UTF-8'),
                    'postedAt'  => max(0, (int) $item['postedAt']),
                    'fetchedAt' => $now,
                    'postId'    => 0,
                    'status'    => 'visible',
                ]),
                Db::WRITE,
                Db::INSERT
            );
        } catch (\Throwable $e) {
            // نقض کلید یکتا = آیتم تکراری؛ سناریوی طبیعی است
            return null;
        }
    }

    /**
     * یافتن آیتم با شناسه
     *
     * @param int $id شناسه آیتم
     * @return array<string, mixed>|null
     */
    public static function find(int $id): ?array
    {
        $row = Db::get()->fetchRow(
            Db::get()->select()->from(self::table())->where('id = ?', $id)->limit(1)
        );

        return $row ?: null;
    }

    /**
     * فهرست آیتم‌ها با فیلتر و صفحه‌بندی
     *
     * @param array<string, mixed> $filters فیلترها: feedId, categoryId, search
     * @param int                  $page    شماره صفحه (از ۱)
     * @param int                  $perPage تعداد در صفحه
     * @return array<int, array<string, mixed>>
     */
    public static function paginate(array $filters = [], int $page = 1, int $perPage = 20): array
    {
        $db = Db::get();

        $select = $db->select(
            'table.' . Install::ITEMS_TABLE . '.*',
            'table.' . Install::FEEDS_TABLE . '.title AS feedTitle',
            'table.' . Install::FEEDS_TABLE . '.categoryId AS feedCategory'
        );

        $select->from(self::table())
            ->join('table.' . Install::FEEDS_TABLE, 'table.' . Install::FEEDS_TABLE . '.id = ' . self::table() . '.feedId', Db::LEFT_JOIN);

        self::applyFilters($select, $filters);

        $page = max(1, $page);
        $select->order(self::table() . '.postedAt', Db::SORT_DESC)
            ->order(self::table() . '.id', Db::SORT_DESC)
            ->page($page, $perPage);

        return $db->fetchAll($select);
    }

    /**
     * شمارش آیتم‌ها با فیلتر
     *
     * @param array<string, mixed> $filters
     * @return int
     */
    public static function countWith(array $filters = []): int
    {
        $db = Db::get();

        $select = $db->select('COUNT(*) AS c')
            ->from(self::table())
            ->join('table.' . Install::FEEDS_TABLE, 'table.' . Install::FEEDS_TABLE . '.id = ' . self::table() . '.feedId', Db::LEFT_JOIN);

        self::applyFilters($select, $filters);

        $row = $db->fetchRow($select);

        return (int) ($row['c'] ?? 0);
    }

    /**
     * آخرین آیتم‌های یک دسته‌بندی مشخص (برای نمایش در سایت)
     *
     * خروجی به‌صورت گروه‌بندی‌شده بر اساس دسته خوراک بازگردانده می‌شود.
     *
     * @param array<string, mixed> $opts گزینه‌ها: categoryId, feedId, count, includeHidden
     * @return array<int, array<string, mixed>> آیتم‌ها همراه با اطلاعات خوراک و دسته
     */
    public static function forFront(array $opts = []): array
    {
        $db = Db::get();

        $count = min(50, max(1, (int) ($opts['count'] ?? 10)));
        $categoryId = (int) ($opts['categoryId'] ?? 0);
        $feedId = (int) ($opts['feedId'] ?? 0);

        $select = $db->select(
            'table.' . Install::ITEMS_TABLE . '.id',
            'table.' . Install::ITEMS_TABLE . '.title',
            'table.' . Install::ITEMS_TABLE . '.url',
            'table.' . Install::ITEMS_TABLE . '.author',
            'table.' . Install::ITEMS_TABLE . '.excerpt',
            'table.' . Install::ITEMS_TABLE . '.content',
            'table.' . Install::ITEMS_TABLE . '.image',
            'table.' . Install::ITEMS_TABLE . '.postedAt',
            'table.' . Install::ITEMS_TABLE . '.postId',
            'table.' . Install::FEEDS_TABLE . '.id AS feedId',
            'table.' . Install::FEEDS_TABLE . '.title AS feedTitle',
            'table.' . Install::FEEDS_TABLE . '.categoryId'
        );

        $select->from(self::table())
            ->join('table.' . Install::FEEDS_TABLE, 'table.' . Install::FEEDS_TABLE . '.id = ' . self::table() . '.feedId', Db::INNER_JOIN);

        $select->where(self::table() . '.status = ?', 'visible')
            ->where('table.' . Install::FEEDS_TABLE . '.active = ?', 1);

        if ($categoryId > 0) {
            $select->where('table.' . Install::FEEDS_TABLE . '.categoryId = ?', $categoryId);
        }

        if ($feedId > 0) {
            $select->where('table.' . Install::FEEDS_TABLE . '.id = ?', $feedId);
        }

        $select->order(self::table() . '.postedAt', Db::SORT_DESC)
            ->order(self::table() . '.id', Db::SORT_DESC)
            ->limit($count);

        return $db->fetchAll($select);
    }

    /**
     * ثبت ارتباط آیتم با نوشته ایجادشده
     *
     * @param int $itemId شناسه آیتم
     * @param int $postId شناسه نوشته
     * @return void
     */
    public static function linkPost(int $itemId, int $postId): void
    {
        $db = Db::get();
        $db->query(
            $db->update(self::table())->rows(['postId' => $postId])->where('id = ?', $itemId)
        );
    }

    /**
     * حذف یک آیتم
     *
     * @param int $id شناسه آیتم
     * @return bool
     */
    public static function delete(int $id): bool
    {
        $item = self::find($id);

        if ($item === null) {
            return false;
        }

        $db = Db::get();
        $db->query($db->delete(self::table())->where('id = ?', $id));

        return true;
    }

    /**
     * حذف کل کش (همه آیتم‌ها از همه خوراک‌ها)
     *
     * @return int تعداد ردیف‌های حذف‌شده
     */
    public static function clearAll(): int
    {
        $db = Db::get();

        try {
            $deleted = 0;
            // حذف دسته‌ای برای سازگاری با هر سه دیالکت
            while (true) {
                $ids = $db->fetchAll(
                    $db->select('id')->from(self::table())->limit(500)
                );

                if (empty($ids)) {
                    break;
                }

                $deleted += count($ids);

                $db->query(
                    $db->delete(self::table())
                        ->where('id IN (' . implode(',', array_map('intval', array_column($ids, 'id'))) . ')')
                );
            }

            // صفر کردن شمارنده خوراک‌ها
            $db->query($db->update('table.' . Install::FEEDS_TABLE)->rows(['itemCount' => 0]));

            return $deleted;
        } catch (\Throwable $e) {
            return $deleted ?? 0;
        }
    }

    /**
     * حذف آیتم‌های قدیمی‌تر از بازه مشخص (پاک‌سازی خودکار)
     *
     * @param int $days تعداد روز (۰ = غیرفعال)
     * @return int تعداد حذف‌شده‌ها
     */
    public static function purgeOld(int $days): int
    {
        if ($days <= 0) {
            return 0;
        }

        $db = Db::get();
        $threshold = time() - ($days * 86400);

        try {
            $ids = $db->fetchAll(
                $db->select('id')->from(self::table())
                    ->where('postedAt > 0 AND postedAt < ?', $threshold)
                    ->limit(1000)
            );

            if (empty($ids)) {
                return 0;
            }

            $db->query(
                $db->delete(self::table())
                    ->where('id IN (' . implode(',', array_map('intval', array_column($ids, 'id'))) . ')')
            );

            return count($ids);
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /**
     * محدود کردن تعداد آیتم‌های یک خوراک به سقف تعیین‌شده
     *
     * @param int $feedId   شناسه خوراک
     * @param int $maxItems حداکثر تعداد مجاز
     * @return int تعداد حذف‌شده‌ها
     */
    public static function trimToLimit(int $feedId, int $maxItems): int
    {
        $db = Db::get();

        try {
            // شناسه آیتم‌هایی که خارج از سقف قرار می‌گیرند
            $ids = $db->fetchAll(
                $db->select('id')->from(self::table())
                    ->where('feedId = ?', $feedId)
                    ->order('postedAt', Db::SORT_DESC)
                    ->order('id', Db::SORT_DESC)
                    ->offset(max(0, $maxItems))
                    ->limit(1000)
            );

            if (empty($ids)) {
                return 0;
            }

            $db->query(
                $db->delete(self::table())
                    ->where('id IN (' . implode(',', array_map('intval', array_column($ids, 'id'))) . ')')
            );

            return count($ids);
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /**
     * آمار کلی آیتم‌ها
     *
     * @return array<string, int>
     */
    public static function stats(): array
    {
        $db = Db::get();

        $items = (int) ($db->fetchRow($db->select('COUNT(*) AS c')->from(self::table()))['c'] ?? 0);
        $posts = (int) ($db->fetchRow(
            $db->select('COUNT(*) AS c')->from(self::table())->where('postId > 0')
        )['c'] ?? 0);

        return ['items' => $items, 'posts' => $posts];
    }

    /**
     * اعمال فیلترهای مشترک روی کوئری
     *
     * @param \Typecho\Db\Query      $select  کوئری
     * @param array<string, mixed>   $filters فیلترها
     * @return void
     */
    private static function applyFilters(\Typecho\Db\Query $select, array $filters): void
    {
        if (!empty($filters['feedId'])) {
            $select->where(self::table() . '.feedId = ?', (int) $filters['feedId']);
        }

        if (!empty($filters['categoryId'])) {
            $select->where('table.' . Install::FEEDS_TABLE . '.categoryId = ?', (int) $filters['categoryId']);
        }

        if (!empty($filters['search'])) {
            $term = '%' . str_replace(['%', '_'], ['\\%', '\\_'], (string) $filters['search']) . '%';
            $select->where(self::table() . '.title LIKE ?', $term);
        }

        if (!empty($filters['hasError'])) {
            $select->where('table.' . Install::FEEDS_TABLE . '.lastError <> ?', '');
        }
    }
}
