<?php
/**
 * انبار داده خوراک‌ها
 *
 * تمام عملیات CRUD روی جدول خوراک‌ها در این کلاس متمرکز شده است تا
 * منطق کسب‌وکار از جزئیات دیتابیس جدا بماند.
 *
 * @package FeedAggregator
 */
namespace TypechoPlugin\FeedAggregator\Repo;

use Typecho\Db;
use TypechoPlugin\FeedAggregator\I18n;
use TypechoPlugin\FeedAggregator\Install;
use TypechoPlugin\FeedAggregator\Util;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class FeedRepo
{
    /**
     * نام جدول (با پیشوند، برای query builder)
     *
     * @return string
     */
    private static function table(): string
    {
        return 'table.' . Install::FEEDS_TABLE;
    }

    /**
     * یافتن یک خوراک با شناسه
     *
     * @param int $id شناسه خوراک
     * @return array<string, mixed>|null
     */
    public static function find(int $id): ?array
    {
        $row = Db::get()->fetchRow(
            Db::get()->select()->from(self::table())->where('id = ?', $id)->limit(1)
        );

        return $row ?: null;
    }

    /**
     * یافتن یک خوراک با نشانی (برای جلوگیری از ثبت تکراری)
     *
     * @param string $url نشانی نرمال‌شده
     * @return array<string, mixed>|null
     */
    public static function findByUrl(string $url): ?array
    {
        $row = Db::get()->fetchRow(
            Db::get()->select()->from(self::table())->where('url = ?', $url)->limit(1)
        );

        return $row ?: null;
    }

    /**
     * فهرست همه خوراک‌ها
     *
     * @param bool|null $active فیلتر وضعیت فعال
     * @return array<int, array<string, mixed>>
     */
    public static function all(?bool $active = null): array
    {
        $db = Db::get();
        $select = $db->select()->from(self::table())->order('id', Db::SORT_ASC);

        if ($active !== null) {
            $select->where('active = ?', $active ? 1 : 0);
        }

        return $db->fetchAll($select);
    }

    /**
     * تعداد خوراک‌ها
     *
     * @param bool|null $active فیلتر وضعیت
     * @return int
     */
    public static function count(?bool $active = null): int
    {
        $db = Db::get();
        $select = $db->select('COUNT(*) AS c')->from(self::table());

        if ($active !== null) {
            $select->where('active = ?', $active ? 1 : 0);
        }

        $row = $db->fetchRow($select);

        return (int) ($row['c'] ?? 0);
    }

    /**
     * افزودن خوراک جدید
     *
     * @param array<string, mixed> $data داده‌های خوراک
     * @return int شناسه خوراک جدید
     * @throws \Typecho\Db\Exception در صورت خطای دیتابیس
     */
    public static function add(array $data): int
    {
        $db = Db::get();
        $now = time();

        // پارامتر سوم Db::INSERT باعث می‌شود query شناسه ردیف جدید را برگرداند
        return (int) $db->query(
            $db->insert(self::table())->rows([
                'title'       => mb_substr((string) $data['title'], 0, 180, 'UTF-8'),
                'url'         => (string) $data['url'],
                'categoryId'  => max(0, (int) ($data['categoryId'] ?? 0)),
                'mode'        => in_array($data['mode'] ?? '', ['cache', 'post'], true) ? $data['mode'] : 'cache',
                'postStatus'  => in_array($data['postStatus'] ?? '', ['publish', 'draft', 'waiting', 'private'], true)
                    ? $data['postStatus'] : 'publish',
                'authorId'    => max(1, (int) ($data['authorId'] ?? 1)),
                'maxItems'    => min(500, max(1, (int) ($data['maxItems'] ?? 50))),
                'active'      => !empty($data['active']) ? 1 : 0,
                'etag'        => '',
                'lastModified' => '',
                'lastFetch'   => 0,
                'lastAttempt' => 0,
                'itemCount'   => 0,
                'lastError'   => '',
                'created'     => $now,
            ]),
            Db::WRITE,
            Db::INSERT
        );
    }

    /**
     * به‌روزرسانی خوراک
     *
     * @param int                 $id   شناسه خوراک
     * @param array<string, mixed> $data فیلدهای قابل به‌روزرسانی
     * @return bool
     */
    public static function update(int $id, array $data): bool
    {
        $allowed = [
            'title', 'url', 'categoryId', 'mode', 'postStatus',
            'authorId', 'maxItems', 'active',
        ];

        $row = [];
        foreach ($allowed as $field) {
            if (array_key_exists($field, $data)) {
                $row[$field] = $data[$field];
            }
        }

        if (empty($row)) {
            return false;
        }

        if (isset($row['title'])) {
            $row['title'] = mb_substr((string) $row['title'], 0, 180, 'UTF-8');
        }

        if (isset($row['mode'])) {
            $row['mode'] = in_array($row['mode'], ['cache', 'post'], true) ? $row['mode'] : 'cache';
        }

        if (isset($row['postStatus'])) {
            $row['postStatus'] = in_array($row['postStatus'], ['publish', 'draft', 'waiting', 'private'], true)
                ? $row['postStatus'] : 'publish';
        }

        if (isset($row['categoryId'])) {
            $row['categoryId'] = max(0, (int) $row['categoryId']);
        }

        if (isset($row['authorId'])) {
            $row['authorId'] = max(1, (int) $row['authorId']);
        }

        if (isset($row['maxItems'])) {
            $row['maxItems'] = min(500, max(1, (int) $row['maxItems']));
        }

        if (isset($row['url'])) {
            $url = Util::validateFeedUrl((string) $row['url']);
            if ($url === false) {
                return false;
            }
            $row['url'] = $url;
        }

        if (isset($row['active'])) {
            $row['active'] = !empty($row['active']) ? 1 : 0;
        }

        $db = Db::get();
        $db->query($db->update(self::table())->rows($row)->where('id = ?', $id));

        return true;
    }

    /**
     * حذف خوراک همراه با آیتم‌های کش آن
     *
     * @param int  $id          شناسه خوراک
     * @param bool $deletePosts حذف نوشته‌های واردشده هم؟
     * @return bool
     */
    public static function delete(int $id, bool $deletePosts = false): bool
    {
        $feed = self::find($id);

        if ($feed === null) {
            return false;
        }

        $db = Db::get();

        // حذف نوشته‌های واردشده — بر اساس فیلد سفارشی fag_feed که روی خود
        // نوشته ذخیره شده است (مستقل از جدول کش که ممکن است خالی باشد)
        if ($deletePosts) {
            $postRows = $db->fetchAll(
                $db->select('cid')->from('table.fields')
                    ->where('name = ? AND str_value = ?', 'fag_feed', (string) $id)
            );

            foreach ($postRows as $postRow) {
                self::deletePost((int) $postRow['cid']);
            }
        }

        // حذف آیتم‌های کش خوراک
        $db->query(
            $db->delete('table.' . Install::ITEMS_TABLE)->where('feedId = ?', $id)
        );

        // حذف خود خوراک
        $db->query($db->delete(self::table())->where('id = ?', $id));

        return true;
    }

    /**
     * تغییر وضعیت فعال/غیرفعال
     *
     * @param int $id شناسه خوراک
     * @return bool
     */
    public static function toggle(int $id): bool
    {
        $feed = self::find($id);

        if ($feed === null) {
            return false;
        }

        return self::update($id, ['active' => empty($feed['active']) ? 1 : 0]);
    }

    /**
     * به‌روزرسانی وضعیت دریافت یک خوراک
     *
     * @param int    $id      شناسه خوراک
     * @param bool   $ok      دریافت موفق؟
     * @param string $error   پیام خطا
     * @param string $etag    هدر ETag جدید
     * @param string $lastMod هدر Last-Modified جدید
     * @return void
     */
    public static function markFetch(int $id, bool $ok, string $error = '', string $etag = '', string $lastMod = ''): void
    {
        $db = Db::get();

        $row = [
            'lastAttempt' => time(),
        ];

        if ($ok) {
            $row['lastFetch'] = time();
            $row['lastError'] = '';
            if ($etag !== '') {
                $row['etag'] = $etag;
            }
            if ($lastMod !== '') {
                $row['lastModified'] = $lastMod;
            }
        } else {
            $row['lastError'] = mb_substr($error, 0, 480, 'UTF-8');
        }

        $db->query($db->update(self::table())->rows($row)->where('id = ?', $id));
    }

    /**
     * به‌روزرسانی شمارنده آیتم‌ها
     *
     * @param int $id شناسه خوراک
     * @return void
     */
    public static function refreshCount(int $id): void
    {
        $db = Db::get();

        $row = $db->fetchRow(
            $db->select('COUNT(*) AS c')->from('table.' . Install::ITEMS_TABLE)->where('feedId = ?', $id)
        );

        $db->query(
            $db->update(self::table())->rows(['itemCount' => (int) ($row['c'] ?? 0)])->where('id = ?', $id)
        );
    }

    /**
     * حذف امن یک نوشته واردشده از هسته
     *
     * @param int $postId شناسه نوشته
     * @return void
     */
    private static function deletePost(int $postId): void
    {
        try {
            $db = Db::get();

            // کاهش شمارنده دسته‌بندی
            $rows = $db->fetchAll(
                $db->select('mid')->from('table.relationships')->where('cid = ?', $postId)
            );

            foreach ($rows as $row) {
                $mid = (int) $row['mid'];
                $db->query(
                    $db->update('table.metas')
                        ->expression('count', 'count - 1')
                        ->where('mid = ?', $mid)
                );
            }

            $db->query($db->delete('table.relationships')->where('cid = ?', $postId));
            $db->query($db->delete('table.comments')->where('cid = ?', $postId));
            $db->query($db->delete('table.fields')->where('cid = ?', $postId));
            $db->query($db->delete('table.contents')->where('cid = ?', $postId));
        } catch (\Throwable $e) {
            // حذف نوشته اختیاری است؛ خطا نباید جریان اصلی را متوقف کند
        }
    }
}
