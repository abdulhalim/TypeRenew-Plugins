<?php
/**
 * مدیریت ساختار دیتابیس افزونه تجمیع‌کننده خوراک
 *
 * ساخت و ارتقای دو جدول «خوراک‌ها» و «آیتم‌ها» با پشتیبانی از هر سه
 * دیالکت پایگاه داده TypeRenew (MySQL، SQLite و PostgreSQL). الگوی
 * پیاده‌سازی مطابق کلاس Utils\Schema هسته است تا رفتار یکسانی با جداول
 * داخلی سیستم داشته باشد.
 *
 * @package FeedAggregator
 */
namespace TypechoPlugin\FeedAggregator;

use Typecho\Db;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Install
{
    /**
     * نام جدول خوراک‌ها (بدون پیشوند)
     */
    public const FEEDS_TABLE = 'feed_aggregator_feeds';

    /**
     * نام جدول آیتم‌ها (بدون پیشوند)
     */
    public const ITEMS_TABLE = 'feed_aggregator_items';

    /**
     * ساخت یا ارتقای جداول افزونه
     *
     * این متد ایدمپوتنت است و می‌تواند بدون نگرانی چند بار اجرا شود.
     *
     * @return void
     */
    public static function ensureTables(): void
    {
        $db = Db::get();
        $dialect = self::dialect($db);

        foreach ([self::FEEDS_TABLE, self::ITEMS_TABLE] as $tableKey) {
            $table = $db->getPrefix() . $tableKey;
            $sql = self::createTableSql($dialect, $tableKey, $table);

            if ($sql !== '') {
                $db->query($sql, Db::WRITE);
            }

            self::ensureColumns($db, $dialect, $tableKey, $table);
        }
    }

    /**
     * حذف کامل جداول افزونه
     *
     * تنها زمانی فراخوانی می‌شود که مدیر صراحتاً «حذف کامل داده‌ها» را
     * انتخاب کند. نوشته‌های واردشده به سیستم (در حالت post) دست‌نخورده
     * باقی می‌مانند چون بخشی از محتوای سایت هستند.
     *
     * @return void
     */
    public static function dropTables(): void
    {
        $db = Db::get();

        foreach ([self::ITEMS_TABLE, self::FEEDS_TABLE] as $tableKey) {
            $table = $db->getPrefix() . $tableKey;
            $db->query('DROP TABLE IF EXISTS ' . self::quote($table, self::dialect($db)), Db::WRITE);
        }

        // حذف سطر وضعیت اجرایی از جدول options
        try {
            $db->query(
                $db->delete('table.options')->where('name = ?', Util::STATE_OPTION),
                Db::WRITE
            );
        } catch (\Throwable $e) {
            // بی‌صدا رد می‌شود؛ سطر وضعیت بی‌ضرر است
        }
    }

    /**
     * تشخیص دیالکت پایگاه داده
     *
     * @param Db $db اتصال دیتابیس
     * @return string mysql|sqlite|pgsql
     */
    public static function dialect(Db $db): string
    {
        $adapter = strtolower($db->getAdapterName());

        if (strpos($adapter, 'sqlite') !== false) {
            return 'sqlite';
        }

        if (strpos($adapter, 'pgsql') !== false || strpos($adapter, 'postgres') !== false) {
            return 'pgsql';
        }

        return 'mysql';
    }

    /**
     * دستور CREATE TABLE برای هر دیالکت
     *
     * @param string $dialect  دیالکت
     * @param string $tableKey کلید جدول
     * @param string $table    نام کامل جدول با پیشوند
     * @return string
     */
    private static function createTableSql(string $dialect, string $tableKey, string $table): string
    {
        $name = self::quote($table, $dialect);

        if ($tableKey === self::FEEDS_TABLE) {
            return match ($dialect) {
                // جدول خوراک‌ها: هر سطر یک منبع RSS
                'sqlite' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                    . '"id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,'
                    . '"title" varchar(190) NOT NULL,'
                    . '"url" varchar(500) NOT NULL,'
                    . '"categoryId" int(10) NOT NULL default 0,'
                    . '"mode" varchar(10) NOT NULL default \'cache\','
                    . '"postStatus" varchar(20) NOT NULL default \'publish\','
                    . '"authorId" int(10) NOT NULL default 1,'
                    . '"maxItems" int(10) NOT NULL default 50,'
                    . '"active" int(1) NOT NULL default 1,'
                    . '"etag" varchar(300) NOT NULL default \'\','
                    . '"lastModified" varchar(64) NOT NULL default \'\','
                    . '"lastFetch" int(10) NOT NULL default 0,'
                    . '"lastAttempt" int(10) NOT NULL default 0,'
                    . '"itemCount" int(10) NOT NULL default 0,'
                    . '"lastError" varchar(500) NOT NULL default \'\','
                    . '"created" int(10) NOT NULL default 0,'
                    . 'UNIQUE ("url")'
                    . ')',
                'pgsql' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                    . '"id" BIGSERIAL PRIMARY KEY,'
                    . '"title" VARCHAR(190) NOT NULL,'
                    . '"url" VARCHAR(500) NOT NULL,'
                    . '"categoryId" INT NOT NULL DEFAULT 0,'
                    . '"mode" VARCHAR(10) NOT NULL DEFAULT \'cache\','
                    . '"postStatus" VARCHAR(20) NOT NULL DEFAULT \'publish\','
                    . '"authorId" INT NOT NULL DEFAULT 1,'
                    . '"maxItems" INT NOT NULL DEFAULT 50,'
                    . '"active" SMALLINT NOT NULL DEFAULT 1,'
                    . '"etag" VARCHAR(300) NOT NULL DEFAULT \'\','
                    . '"lastModified" VARCHAR(64) NOT NULL DEFAULT \'\','
                    . '"lastFetch" INT NOT NULL DEFAULT 0,'
                    . '"lastAttempt" INT NOT NULL DEFAULT 0,'
                    . '"itemCount" INT NOT NULL DEFAULT 0,'
                    . '"lastError" VARCHAR(500) NOT NULL DEFAULT \'\','
                    . '"created" INT NOT NULL DEFAULT 0,'
                    . 'UNIQUE ("url")'
                    . ')',
                default => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                    . '`id` bigint unsigned NOT NULL auto_increment,'
                    . '`title` varchar(190) NOT NULL,'
                    . '`url` varchar(500) NOT NULL,'
                    . '`categoryId` int unsigned NOT NULL default 0,'
                    . '`mode` varchar(10) NOT NULL default \'cache\','
                    . '`postStatus` varchar(20) NOT NULL default \'publish\','
                    . '`authorId` int unsigned NOT NULL default 1,'
                    . '`maxItems` int unsigned NOT NULL default 50,'
                    . '`active` tinyint unsigned NOT NULL default 1,'
                    . '`etag` varchar(300) NOT NULL default \'\','
                    . '`lastModified` varchar(64) NOT NULL default \'\','
                    . '`lastFetch` int unsigned NOT NULL default 0,'
                    . '`lastAttempt` int unsigned NOT NULL default 0,'
                    . '`itemCount` int unsigned NOT NULL default 0,'
                    . '`lastError` varchar(500) NOT NULL default \'\','
                    . '`created` int unsigned NOT NULL default 0,'
                    . 'PRIMARY KEY (`id`),'
                    . 'UNIQUE KEY `' . $table . '_url` (`url`(190)),'
                    . 'KEY `' . $table . '_active` (`active`)'
                    . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
            };
        }

        // جدول آیتم‌ها: کش مطالب دریافتی از خوراک‌ها
        return match ($dialect) {
            'sqlite' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,'
                . '"feedId" int(10) NOT NULL default 0,'
                . '"uidHash" char(40) NOT NULL,'
                . '"title" varchar(500) NOT NULL,'
                . '"url" varchar(750) NOT NULL default \'\','
                . '"author" varchar(190) NOT NULL default \'\','
                . '"excerpt" varchar(1000) NOT NULL default \'\','
                . '"content" mediumtext,'
                . '"image" varchar(750) NOT NULL default \'\','
                . '"postedAt" int(10) NOT NULL default 0,'
                . '"fetchedAt" int(10) NOT NULL default 0,'
                . '"postId" int(10) NOT NULL default 0,'
                . '"status" varchar(20) NOT NULL default \'visible\','
                . 'UNIQUE ("feedId", "uidHash")'
                . ')',
            'pgsql' => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '"id" BIGSERIAL PRIMARY KEY,'
                . '"feedId" INT NOT NULL DEFAULT 0,'
                . '"uidHash" CHAR(40) NOT NULL,'
                . '"title" VARCHAR(500) NOT NULL,'
                . '"url" VARCHAR(750) NOT NULL DEFAULT \'\','
                . '"author" VARCHAR(190) NOT NULL DEFAULT \'\','
                . '"excerpt" VARCHAR(1000) NOT NULL DEFAULT \'\','
                . '"content" TEXT NULL,'
                . '"image" VARCHAR(750) NOT NULL DEFAULT \'\','
                . '"postedAt" INT NOT NULL DEFAULT 0,'
                . '"fetchedAt" INT NOT NULL DEFAULT 0,'
                . '"postId" INT NOT NULL DEFAULT 0,'
                . '"status" VARCHAR(20) NOT NULL DEFAULT \'visible\','
                . 'UNIQUE ("feedId", "uidHash")'
                . ')',
            default => 'CREATE TABLE IF NOT EXISTS ' . $name . ' ('
                . '`id` bigint unsigned NOT NULL auto_increment,'
                . '`feedId` int unsigned NOT NULL default 0,'
                . '`uidHash` char(40) NOT NULL,'
                . '`title` varchar(500) NOT NULL,'
                . '`url` varchar(750) NOT NULL default \'\','
                . '`author` varchar(190) NOT NULL default \'\','
                . '`excerpt` varchar(1000) NOT NULL default \'\','
                . '`content` mediumtext,'
                . '`image` varchar(750) NOT NULL default \'\','
                . '`postedAt` int unsigned NOT NULL default 0,'
                . '`fetchedAt` int unsigned NOT NULL default 0,'
                . '`postId` int unsigned NOT NULL default 0,'
                . '`status` varchar(20) NOT NULL default \'visible\','
                . 'PRIMARY KEY (`id`),'
                . 'UNIQUE KEY `' . $table . '_feed_uid` (`feedId`, `uidHash`),'
                . 'KEY `' . $table . '_feed_posted` (`feedId`, `postedAt`),'
                . 'KEY `' . $table . '_posted` (`postedAt`),'
                . 'KEY `' . $table . '_uid` (`uidHash`),'
                . 'KEY `' . $table . '_post` (`postId`)'
                . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
        };
    }

    /**
     * افزودن ستون‌های جاافتاده (برای ارتقا از نسخه‌های قبلی)
     *
     * @param Db     $db       اتصال
     * @param string  $dialect دیالکت
     * @param string  $tableKey کلید جدول
     * @param string  $table    نام کامل جدول
     * @return void
     */
    private static function ensureColumns(Db $db, string $dialect, string $tableKey, string $table): void
    {
        foreach (self::columnDefinitions($dialect, $tableKey) as $definition) {
            [$column, $sql] = $definition;

            if (self::columnExists($db, $dialect, $table, $column)) {
                continue;
            }

            // SQLite ستون کلید اصلی را نمی‌تواند بعداً اضافه کند؛ در نسخه‌های جدید همیشه هست
            if ($dialect === 'sqlite' && $column === 'id') {
                continue;
            }

            $db->query(
                'ALTER TABLE ' . self::quote($table, $dialect) . ' ADD COLUMN ' . $sql,
                Db::WRITE
            );
        }
    }

    /**
     * تعریف ستون‌ها برای ارتقا (مطابق createTableSql)
     *
     * @param string $dialect  دیالکت
     * @param string $tableKey کلید جدول
     * @return array<array{0: string, 1: string}>
     */
    private static function columnDefinitions(string $dialect, string $tableKey): array
    {
        $feeds = [
            ['id', 'id bigint unsigned NOT NULL auto_increment PRIMARY KEY'],
            ['title', 'title varchar(190) NOT NULL'],
            ['url', 'url varchar(500) NOT NULL'],
            ['categoryId', 'categoryId int unsigned NOT NULL default 0'],
            ['mode', 'mode varchar(10) NOT NULL default \'cache\''],
            ['postStatus', 'postStatus varchar(20) NOT NULL default \'publish\''],
            ['authorId', 'authorId int unsigned NOT NULL default 1'],
            ['maxItems', 'maxItems int unsigned NOT NULL default 50'],
            ['active', 'active tinyint unsigned NOT NULL default 1'],
            ['etag', 'etag varchar(300) NOT NULL default \'\''],
            ['lastModified', 'lastModified varchar(64) NOT NULL default \'\''],
            ['lastFetch', 'lastFetch int unsigned NOT NULL default 0'],
            ['lastAttempt', 'lastAttempt int unsigned NOT NULL default 0'],
            ['itemCount', 'itemCount int unsigned NOT NULL default 0'],
            ['lastError', 'lastError varchar(500) NOT NULL default \'\''],
            ['created', 'created int unsigned NOT NULL default 0'],
        ];

        $items = [
            ['id', 'id bigint unsigned NOT NULL auto_increment PRIMARY KEY'],
            ['feedId', 'feedId int unsigned NOT NULL default 0'],
            ['uidHash', 'uidHash char(40) NOT NULL'],
            ['title', 'title varchar(500) NOT NULL'],
            ['url', 'url varchar(750) NOT NULL default \'\''],
            ['author', 'author varchar(190) NOT NULL default \'\''],
            ['excerpt', 'excerpt varchar(1000) NOT NULL default \'\''],
            ['content', 'content mediumtext'],
            ['image', 'image varchar(750) NOT NULL default \'\''],
            ['postedAt', 'postedAt int unsigned NOT NULL default 0'],
            ['fetchedAt', 'fetchedAt int unsigned NOT NULL default 0'],
            ['postId', 'postId int unsigned NOT NULL default 0'],
            ['status', 'status varchar(20) NOT NULL default \'visible\''],
        ];

        $rows = $tableKey === self::FEEDS_TABLE ? $feeds : $items;

        // تطبیق نوع ستون‌ها با دیالکت‌های دیگر
        if ($dialect !== 'mysql') {
            foreach ($rows as &$row) {
                $row[1] = str_replace(['bigint unsigned NOT NULL auto_increment PRIMARY KEY', 'tinyint unsigned'],
                    ['bigint NOT NULL', 'smallint'], $row[1]);
            }
            unset($row);
        }

        return $rows;
    }

    /**
     * بررسی وجود یک ستون در جدول
     *
     * @param Db     $db      اتصال
     * @param string  $dialect دیالکت
     * @param string  $table   نام کامل جدول
     * @param string  $column  نام ستون
     * @return bool
     */
    private static function columnExists(Db $db, string $dialect, string $table, string $column): bool
    {
        try {
            if ($dialect === 'sqlite') {
                $rows = $db->fetchAll('PRAGMA table_info(' . self::quote($table, 'sqlite') . ')');
                foreach ($rows as $row) {
                    if (strcasecmp((string) ($row['name'] ?? ''), $column) === 0) {
                        return true;
                    }
                }
                return false;
            }

            if ($dialect === 'pgsql') {
                $row = $db->fetchRow(
                    'SELECT COUNT(*) AS c FROM information_schema.columns '
                    . 'WHERE table_name = ' . $db->quoteValue($table)
                    . ' AND column_name = ' . $db->quoteValue($column)
                );
                return (int) ($row['c'] ?? 0) > 0;
            }

            $rows = $db->fetchAll('SHOW COLUMNS FROM ' . self::quote($table, 'mysql'));
            foreach ($rows as $row) {
                if (strcasecmp((string) ($row['Field'] ?? ''), $column) === 0) {
                    return true;
                }
            }
            return false;
        } catch (\Throwable $e) {
            // در صورت خطا فرض می‌کنیم ستون وجود دارد تا از خرابی داده جلوگیری شود
            return true;
        }
    }

    /**
     * نقل‌قول امن نام جدول بر اساس دیالکت
     *
     * @param string $name    نام
     * @param string $dialect دیالکت
     * @return string
     */
    public static function quote(string $name, string $dialect): string
    {
        if ($dialect === 'mysql') {
            return '`' . str_replace('`', '', $name) . '`';
        }

        return '"' . str_replace('"', '', $name) . '"';
    }
}
