<?php
/**
 * پنل مدیریت افزونه تجمیع‌کننده خوراک — نسخه یکپارچه با قالب مدیریت
 *
 * این فایل به‌صورت fragment (بدون doctype) خروجی می‌دهد تا TypeRenew آن
 * درون چارچوب مدیریت (extending.php + header + menu + footer) رندر کند.
 * تمام کلاس‌های tr-* و متغیرهای --tr-* از خود قالب ادمین می‌آیند؛ در
 * نتیجه پنل به‌صورت خودکار از حالت روز/شب، فونت وزیرمتن و زبان رابط
 * مدیریت پیروی می‌کند. فایل assets/admin/panel.css فقط تنظیمات اختصاصی
 * همین پنل را به‌صورت scoped اعمال می‌کند.
 *
 * @package FeedAggregator
 */
namespace TypechoPlugin\FeedAggregator;

use Typecho\Common;
use TypechoPlugin\FeedAggregator\Repo\FeedRepo;
use TypechoPlugin\FeedAggregator\Repo\ItemRepo;
use Utils\Helper;
use Widget\Options;
use Widget\Security;
use Widget\User;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

// ---------------------------------------------------------------------------
// زمینه اجرایی پنل (پیش از این فایل، admin/common.php بارگذاری شده است)
// ---------------------------------------------------------------------------

/** @var Options $options */
$options = Options::alloc();
$user = User::alloc();
$security = Security::alloc();

// فقط مدیران کل اجازه دسترسی دارند
if (!$user->hasLogin() || !$user->pass('administrator', true)) {
    \Typecho\Response::getInstance()->redirect(Common::url('index.php', $options->adminUrl));
}

$settings = Util::settings();
$pluginUrl = rtrim((string) $options->pluginUrl, '/') . '/FeedAggregator';
$version = Plugin::VERSION;

// توکن امنیتی برای درخواست‌های AJAX
$token = $security->getToken('FeedAggregator-admin');

// آدرس endpoint اکشن
$actionUrl = Util::actionUrl();

// اسپرایت آیکون‌های Lucide قالب مدیریت (برای آیکون‌های درون پنل)
$iconsUrl = (string) $options->adminStaticUrl('img', 'icons.svg', true);

/** درج آیکون از اسپرایت قالب مدیریت */
$icon = function (string $name, int $size = 16) use ($iconsUrl): string {
    return '<svg class="tr-ico" style="width:' . $size . 'px;height:' . $size . 'px" aria-hidden="true">'
        . '<use href="' . htmlspecialchars($iconsUrl, ENT_QUOTES, 'UTF-8')
        . '#i-' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '"></use></svg>';
};

// دسته‌بندی‌ها برای فرم خوراک
$categories = [];
try {
    $rows = \Typecho\Db::get()->fetchAll(
        \Typecho\Db::get()->select('mid', 'name', 'parent')->from('table.metas')
            ->where('type = ?', 'category')->order('order', \Typecho\Db::SORT_ASC)
    );

    $byParent = [];
    foreach ($rows as $row) {
        $byParent[(int) $row['parent']][] = $row;
    }

    $walk = function (int $parent, int $depth) use (&$walk, &$byParent, &$categories): void {
        foreach ($byParent[$parent] ?? [] as $row) {
            $categories[] = [
                'id' => (int) $row['mid'],
                'label' => str_repeat('— ', $depth) . (string) $row['name'],
            ];
            $walk((int) $row['mid'], $depth + 1);
        }
    };

    $walk(0, 0);
} catch (\Throwable $e) {
    $categories = [];
}

// فهرست نویسندگان برای حالت ثبت نوشته
$authors = [];
try {
    $rows = \Typecho\Db::get()->fetchAll(
        \Typecho\Db::get()->select('uid', 'name')->from('table.users')
            ->order('uid', \Typecho\Db::SORT_ASC)->limit(100)
    );

    foreach ($rows as $row) {
        $authors[] = ['id' => (int) $row['uid'], 'name' => (string) $row['name']];
    }
} catch (\Throwable $e) {
    $authors = [];
}

// پیام‌های مورد نیاز جاوااسکریپت (قابل ترجمه)
$jsMessages = [
    'confirmDelete' => I18n::t('Delete this feed? Its cached items will be removed too.'),
    'confirmDeletePosts' => I18n::t('Also delete imported posts of this feed?'),
    'confirmClearCache' => I18n::t('Clear all cached items? Feeds and settings remain untouched.'),
    'confirmWipe' => I18n::t('This will permanently delete ALL plugin data (feeds, cache and settings). Type the confirmation phrase to continue:'),
    'updating' => I18n::t('Updating…'),
    'fetching' => I18n::t('Fetching…'),
    'saving' => I18n::t('Saving…'),
    'loading' => I18n::t('Loading…'),
    'requestFailed' => I18n::t('Request failed. Check your connection and try again.'),
    'never' => I18n::t('never'),
    'feedTitle' => I18n::t('Feed title'),
    'feedUrl' => I18n::t('Feed URL'),
    'category' => I18n::t('Category'),
    'mode' => I18n::t('Mode'),
    'cacheMode' => I18n::t('Cache only'),
    'postMode' => I18n::t('Create posts'),
    'postStatus' => I18n::t('Post status'),
    'author' => I18n::t('Post author'),
    'maxItems' => I18n::t('Max cached items'),
    'active' => I18n::t('Active'),
    'test' => I18n::t('Test'),
    'save' => I18n::t('Save'),
    'cancel' => I18n::t('Cancel'),
    'edit' => I18n::t('Edit'),
    'delete' => I18n::t('Delete'),
    'updateNow' => I18n::t('Update now'),
    'addFeed' => I18n::t('Add feed'),
    'addFeedTitle' => I18n::t('Add a new feed'),
    'editFeedTitle' => I18n::t('Edit feed'),
    'noFeeds' => I18n::t('No feeds yet. Add your first RSS feed to get started.'),
    'noItems' => I18n::t('No items found.'),
    'page' => I18n::t('Page'),
    'of' => I18n::t('of'),
    'prev' => I18n::t('Previous'),
    'next' => I18n::t('Next'),
    'itemsCount' => I18n::t('%d items'),
    'copied' => I18n::t('Copied!'),
    'copy' => I18n::t('Copy'),
    'cronUrlHint' => I18n::t('Add this URL to your server cron (recommended: every 15 minutes):'),
    'errorsTitle' => I18n::t('Recent errors'),
    'lastRunTitle' => I18n::t('Last update'),
    'nextRunTitle' => I18n::t('Next update'),
    'duration' => I18n::t('Duration'),
    'newItems' => I18n::t('New items'),
    'newPosts' => I18n::t('New posts'),
    'notModified' => I18n::t('Not modified'),
    'viewPost' => I18n::t('View post'),
    'wipePhrase' => 'wipe-all-data',
    'allHealthy' => I18n::t('Everything is healthy'),
    'updatingNow' => I18n::t('Update in progress…'),
    'errorFeedsMsg' => I18n::t('%d feeds have errors'),
    'feedsLabel' => I18n::t('Feeds'),
    'itemsLabel' => I18n::t('Items'),
    'postsLabel' => I18n::t('New posts'),
    'errorFeedsLabel' => I18n::t('Errored feeds'),
    'allFeeds' => I18n::t('All feeds'),
    'allCategories' => I18n::t('All categories'),
    'categoryHint' => I18n::t('Items of this feed are displayed under this category and imported posts are filed into it too.'),
    'activeHint' => I18n::t('Stopped feeds are skipped during automatic updates.'),
    'statusPublish' => I18n::t('Published'),
    'statusDraft' => I18n::t('Draft'),
    'statusWaiting' => I18n::t('Pending review'),
    'statusPrivate' => I18n::t('Private'),
    'feedsChecked' => I18n::t('feeds checked'),
    'lastRunLabel' => I18n::t('Last update'),
    'nextRunLabel' => I18n::t('Next update'),
    'readyToRun' => I18n::t('Ready to run'),
    'hours' => I18n::t('hours'),
    'minutes' => I18n::t('minutes'),
    'later' => I18n::t('later'),
    'immediateFetch' => I18n::t('Fetch now'),
    'stop' => I18n::t('Stop'),
    'activate' => I18n::t('Activate'),
    'postModeLabel' => I18n::t('Create posts'),
    'cacheModeLabel' => I18n::t('Cache only'),
    'errorLabel' => I18n::t('Error'),
    'activeLabel' => I18n::t('Active'),
    'stoppedLabel' => I18n::t('Stopped'),
    'savedLabel' => I18n::t('Saved'),
    'resultsCount' => I18n::t('results'),
    'totalRuns' => I18n::t('feeds checked'),
    'feedValid' => I18n::t('Feed is valid'),
    'channelTitle' => I18n::t('Channel title'),
    'itemsFound' => I18n::t('items found'),
    'fetchError' => I18n::t('Failed to fetch the feed'),
    'deleteConfirmTitle' => I18n::t('Delete feed'),
    'deleteFinal' => I18n::t('Delete permanently'),
    'clearCacheTitle' => I18n::t('Clear cache'),
    'clearCacheDo' => I18n::t('Clear now'),
    'wipeTitle' => I18n::t('Delete all plugin data'),
    'wipeDo' => I18n::t('Delete everything'),
    'typeToConfirm' => I18n::t('Type the following phrase to confirm:'),
    'noReportYet' => I18n::t('No update has been performed yet.'),
    'noErrors' => I18n::t('No errors. All feeds are healthy.'),
    'loadFailed' => I18n::t('Failed to load the list'),
    'feedsTabEmpty' => I18n::t('No feeds yet. Add your first RSS feed to get started.'),
    'itemsTabEmpty' => I18n::t('No items found.'),
    'done' => I18n::t('Done'),
];

// داده راه‌اندازی برای جاوااسکریپت
$boot = [
    'actionUrl' => $actionUrl,
    'token' => $token,
    'adminUrl' => (string) $options->adminUrl,
    'siteUrl' => (string) $options->siteUrl,
    'version' => $version,
    'iconsUrl' => $iconsUrl,
    'settings' => [
        'update_interval' => (int) $settings['update_interval'],
        'lazy_update' => (string) $settings['lazy_update'],
        'cron_enabled' => (string) $settings['cron_enabled'],
        'cron_secret' => (string) $settings['cron_secret'],
        'fetch_timeout' => (int) $settings['fetch_timeout'],
        'purge_days' => (int) $settings['purge_days'],
        'default_mode' => (string) $settings['default_mode'],
        'default_post_status' => (string) $settings['default_post_status'],
        'default_max_items' => (int) $settings['default_max_items'],
        'show_source_link' => (string) $settings['show_source_link'],
    ],
    'cronUrl' => $settings['cron_secret'] !== ''
        ? $actionUrl . '?do=cron&key=' . $settings['cron_secret']
        : '',
    'categories' => $categories,
    'authors' => $authors,
    'i18n' => $jsMessages,
];

$bootJson = json_encode($boot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

// ---------------------------------------------------------------------------
// خروجی fragment — درون چارچوب قالب مدیریت رندر می‌شود
// ---------------------------------------------------------------------------
?>
<link rel="stylesheet" href="<?php echo Util::esc($pluginUrl); ?>/assets/admin/panel.css?v=<?php echo Util::esc($version); ?>">

<div class="fag-panel" dir="rtl">

    <!-- سربرگ: عنوان، وضعیت و عملیات کلی -->
    <section class="tr-card">
        <div class="tr-card-b">
            <div class="tr-panel-head">
                <div class="tr-panel-heading">
                    <h2 class="tr-panel-title fag-panel-title">
                        <?php echo $icon('layers', 20); ?>
                        <?php echo I18n::t('Feed Aggregator'); ?>
                        <span class="fag-version-badge" title="Feed Aggregator version">
                            v<?php echo Util::esc($version); ?>
                        </span>
                    </h2>
                </div>
                <div class="tr-panel-pills">
                    <span class="tr-pill fag-status-pill">
                        <span class="fag-dot fag-dot-ok" id="fag-dot"></span>
                        <span id="fag-status-text"><?php echo I18n::t('Loading…'); ?></span>
                    </span>
                    <span class="tr-pill" id="fag-last-run">—</span>
                    <span class="tr-pill" id="fag-next-run">—</span>
                </div>
            </div>
            <div class="tr-panel-actions fag-head-actions">
                <button type="button" class="tr-btn primary" id="fag-update-now">
                    <span class="fag-spin" hidden></span>
                    <?php echo $icon('refresh', 15); ?>
                    <?php echo I18n::t('Update now'); ?>
                </button>
                <a class="tr-btn" href="<?php echo Util::esc($options->siteUrl); ?>" target="_blank" rel="noopener">
                    <?php echo $icon('external', 14); ?>
                    <?php echo I18n::t('View site'); ?>
                </a>
            </div>
        </div>
    </section>

    <!-- تب‌ها -->
    <nav class="tr-panel-tabs" role="tablist" aria-label="<?php echo I18n::t('Feed Aggregator'); ?>">
        <button type="button" class="tr-panel-tab is-active" data-target="dashboard" role="tab">
            <?php echo $icon('grid', 14); ?>
            <span><?php echo I18n::t('Dashboard'); ?></span>
        </button>
        <button type="button" class="tr-panel-tab" data-target="feeds" role="tab">
            <?php echo $icon('layers', 14); ?>
            <span><?php echo I18n::t('Feeds'); ?></span>
            <span class="fag-tab-badge" id="fag-feeds-count">۰</span>
        </button>
        <button type="button" class="tr-panel-tab" data-target="items" role="tab">
            <?php echo $icon('list', 14); ?>
            <span><?php echo I18n::t('Items'); ?></span>
            <span class="fag-tab-badge" id="fag-items-count">۰</span>
        </button>
        <button type="button" class="tr-panel-tab" data-target="settings" role="tab">
            <?php echo $icon('sliders', 14); ?>
            <span><?php echo I18n::t('Settings'); ?></span>
        </button>
    </nav>

    <!-- نمای داشبورد -->
    <section class="tr-panel-pane is-active" data-tab="dashboard" role="tabpanel">
        <div class="tr-panel-kpis" id="fag-stat-cards">
            <div class="tr-panel-kpi"><span><?php echo I18n::t('Feeds'); ?></span><strong>—</strong></div>
            <div class="tr-panel-kpi"><span><?php echo I18n::t('Active'); ?></span><strong>—</strong></div>
            <div class="tr-panel-kpi"><span><?php echo I18n::t('Items'); ?></span><strong>—</strong></div>
            <div class="tr-panel-kpi"><span><?php echo I18n::t('New posts'); ?></span><strong>—</strong></div>
        </div>
        <div class="fag-grid-2">
            <article class="tr-card">
                <div class="tr-card-h">
                    <div class="tr-panel-section-head">
                        <h3><?php echo $icon('clock', 16); ?> <?php echo I18n::t('Last update report'); ?></h3>
                    </div>
                </div>
                <div class="tr-card-b" id="fag-last-report">
                    <p class="fag-muted"><?php echo I18n::t('No update has been performed yet.'); ?></p>
                </div>
            </article>
            <article class="tr-card">
                <div class="tr-card-h">
                    <div class="tr-panel-section-head">
                        <h3><?php echo $icon('alert', 16); ?> <?php echo I18n::t('Recent errors'); ?></h3>
                    </div>
                </div>
                <div class="tr-card-b" id="fag-recent-errors">
                    <p class="fag-muted"><?php echo I18n::t('No errors. All feeds are healthy.'); ?></p>
                </div>
            </article>
        </div>
    </section>

    <!-- نمای خوراک‌ها -->
    <section class="tr-panel-pane" data-tab="feeds" role="tabpanel">
        <article class="tr-card">
            <div class="tr-card-h">
                <div class="tr-panel-section-head">
                    <h3><?php echo $icon('layers', 16); ?> <?php echo I18n::t('Registered feeds'); ?></h3>
                    <button type="button" class="tr-btn primary fag-add-btn" id="fag-add-feed">
                        <?php echo $icon('plus', 15); ?>
                        <?php echo I18n::t('Add feed'); ?>
                    </button>
                </div>
            </div>
            <div class="tr-card-b">
                <div class="fag-table-wrap">
                    <table class="fag-table">
                        <thead>
                            <tr>
                                <th><?php echo I18n::t('Feed'); ?></th>
                                <th><?php echo I18n::t('Category'); ?></th>
                                <th><?php echo I18n::t('Mode'); ?></th>
                                <th class="fag-num"><?php echo I18n::t('Items'); ?></th>
                                <th><?php echo I18n::t('Last fetch'); ?></th>
                                <th><?php echo I18n::t('Status'); ?></th>
                                <th class="fag-th-actions"><?php echo I18n::t('Actions'); ?></th>
                            </tr>
                        </thead>
                        <tbody id="fag-feeds-tbody">
                            <tr><td colspan="7" class="fag-muted fag-center"><?php echo I18n::t('Loading…'); ?></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </article>
    </section>

    <!-- نمای آیتم‌ها -->
    <section class="tr-panel-pane" data-tab="items" role="tabpanel">
        <article class="tr-card">
            <div class="tr-card-h">
                <div class="tr-panel-section-head">
                    <h3><?php echo $icon('list', 16); ?> <?php echo I18n::t('Cached items'); ?></h3>
                </div>
            </div>
            <div class="tr-card-b">
                <div class="fag-filters">
                    <select id="fag-filter-feed" aria-label="<?php echo I18n::t('All feeds'); ?>">
                        <option value="0"><?php echo I18n::t('All feeds'); ?></option>
                    </select>
                    <select id="fag-filter-cat" aria-label="<?php echo I18n::t('All categories'); ?>">
                        <option value="0"><?php echo I18n::t('All categories'); ?></option>
                    </select>
                    <input type="search" id="fag-filter-search" placeholder="<?php echo I18n::t('Search title…'); ?>">
                    <button type="button" class="btn btn-s" id="fag-apply-filters"><?php echo $icon('filter', 13); ?> <?php echo I18n::t('Filter'); ?></button>
                </div>
                <div class="fag-table-wrap">
                    <table class="fag-table">
                        <thead>
                            <tr>
                                <th><?php echo I18n::t('Title'); ?></th>
                                <th><?php echo I18n::t('Feed'); ?></th>
                                <th><?php echo I18n::t('Date'); ?></th>
                                <th><?php echo I18n::t('Post'); ?></th>
                                <th class="fag-th-actions"><?php echo I18n::t('Actions'); ?></th>
                            </tr>
                        </thead>
                        <tbody id="fag-items-tbody">
                            <tr><td colspan="5" class="fag-muted fag-center"><?php echo I18n::t('Loading…'); ?></td></tr>
                        </tbody>
                    </table>
                </div>
                <div class="fag-pagination" id="fag-pagination"></div>
            </div>
        </article>
    </section>

    <!-- نمای تنظیمات -->
    <section class="tr-panel-pane" data-tab="settings" role="tabpanel">
        <form id="fag-settings-form" autocomplete="off">
            <div class="fag-grid-2">
                <article class="tr-card">
                    <div class="tr-card-h">
                        <div class="tr-panel-section-head">
                            <h3><?php echo $icon('refresh', 16); ?> <?php echo I18n::t('Automatic updates'); ?></h3>
                        </div>
                    </div>
                    <div class="tr-card-b">
                        <div class="fag-field">
                            <label for="fag-set-interval"><?php echo I18n::t('Update interval (minutes)'); ?></label>
                            <input type="number" id="fag-set-interval" name="update_interval" min="5" max="10080" required>
                            <p class="fag-hint"><?php echo I18n::t('Automatic feeds update frequency. Minimum is 5 minutes.'); ?></p>
                        </div>
                        <div class="fag-field fag-field-inline">
                            <label class="fag-switch">
                                <input type="checkbox" id="fag-set-lazy" name="lazy_update">
                                <span class="fag-switch-slider"></span>
                            </label>
                            <div>
                                <strong><?php echo I18n::t('Lazy update on visit'); ?></strong>
                                <p class="fag-hint"><?php echo I18n::t('When enabled, feeds are updated in the background on the first visit after the interval ends.'); ?></p>
                            </div>
                        </div>
                        <div class="fag-field">
                            <label for="fag-set-timeout"><?php echo I18n::t('Fetch timeout (seconds)'); ?></label>
                            <input type="number" id="fag-set-timeout" name="fetch_timeout" min="3" max="60" required>
                        </div>
                    </div>
                </article>

                <article class="tr-card">
                    <div class="tr-card-h">
                        <div class="tr-panel-section-head">
                            <h3><?php echo $icon('clock', 16); ?> <?php echo I18n::t('Server cron'); ?></h3>
                        </div>
                    </div>
                    <div class="tr-card-b">
                        <div class="fag-field fag-field-inline">
                            <label class="fag-switch">
                                <input type="checkbox" id="fag-set-cron" name="cron_enabled">
                                <span class="fag-switch-slider"></span>
                            </label>
                            <div>
                                <strong><?php echo I18n::t('Enable cron endpoint'); ?></strong>
                                <p class="fag-hint"><?php echo I18n::t('Provides a secret URL for real cron jobs.'); ?></p>
                            </div>
                        </div>
                        <div class="fag-field" id="fag-cron-url-box" hidden>
                            <label><?php echo I18n::t('Cron URL'); ?></label>
                            <div class="fag-cron-row">
                                <code id="fag-cron-url" class="fag-code"></code>
                                <button type="button" class="btn btn-s" id="fag-copy-cron"><?php echo $icon('files', 13); ?> <?php echo I18n::t('Copy'); ?></button>
                            </div>
                            <p class="fag-hint"><?php echo I18n::t('Add this URL to your server cron (recommended: every 15 minutes):'); ?></p>
                        </div>
                        <button type="button" class="btn btn-s" id="fag-regen-secret"><?php echo $icon('key', 13); ?> <?php echo I18n::t('Regenerate key'); ?></button>
                    </div>
                </article>

                <article class="tr-card">
                    <div class="tr-card-h">
                        <div class="tr-panel-section-head">
                            <h3><?php echo $icon('database', 16); ?> <?php echo I18n::t('Cache'); ?></h3>
                        </div>
                    </div>
                    <div class="tr-card-b">
                        <div class="fag-field">
                            <label for="fag-set-purge"><?php echo I18n::t('Keep cache for (days)'); ?></label>
                            <input type="number" id="fag-set-purge" name="purge_days" min="0" max="3650" required>
                            <p class="fag-hint"><?php echo I18n::t('Items older than this will be removed automatically. Set 0 to keep forever.'); ?></p>
                        </div>
                        <div class="fag-field">
                            <label for="fag-set-max"><?php echo I18n::t('Max cached items per feed'); ?></label>
                            <input type="number" id="fag-set-max" name="default_max_items" min="1" max="500" required>
                        </div>
                    </div>
                </article>

                <article class="tr-card">
                    <div class="tr-card-h">
                        <div class="tr-panel-section-head">
                            <h3><?php echo $icon('sliders', 16); ?> <?php echo I18n::t('Defaults for new feeds'); ?></h3>
                        </div>
                    </div>
                    <div class="tr-card-b">
                        <div class="fag-field">
                            <label for="fag-set-mode"><?php echo I18n::t('Mode'); ?></label>
                            <select id="fag-set-mode" name="default_mode">
                                <option value="cache"><?php echo I18n::t('Cache only (display via widget/shortcode)'); ?></option>
                                <option value="post"><?php echo I18n::t('Create real posts'); ?></option>
                            </select>
                        </div>
                        <div class="fag-field">
                            <label for="fag-set-status"><?php echo I18n::t('Default status of imported posts'); ?></label>
                            <select id="fag-set-status" name="default_post_status">
                                <option value="publish"><?php echo I18n::t('Published'); ?></option>
                                <option value="draft"><?php echo I18n::t('Draft'); ?></option>
                                <option value="waiting"><?php echo I18n::t('Pending review'); ?></option>
                                <option value="private"><?php echo I18n::t('Private'); ?></option>
                            </select>
                        </div>
                        <div class="fag-field fag-field-inline">
                            <label class="fag-switch">
                                <input type="checkbox" id="fag-set-source" name="show_source_link">
                                <span class="fag-switch-slider"></span>
                            </label>
                            <div>
                                <strong><?php echo I18n::t('Add source link to imported posts'); ?></strong>
                                <p class="fag-hint"><?php echo I18n::t('A link to the original article will be appended at the end of each imported post.'); ?></p>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
            <div class="fag-settings-save">
                <button type="submit" class="tr-btn primary" id="fag-save-settings">
                    <?php echo $icon('save', 15); ?>
                    <?php echo I18n::t('Save settings'); ?>
                </button>
            </div>
        </form>

        <article class="tr-card fag-card-danger">
            <div class="tr-card-h">
                <div class="tr-panel-section-head">
                    <h3><?php echo $icon('alert', 16); ?> <?php echo I18n::t('Danger zone'); ?></h3>
                </div>
            </div>
            <div class="tr-card-b">
                <div class="fag-danger-row">
                    <div>
                        <strong><?php echo I18n::t('Clear cache'); ?></strong>
                        <p class="fag-hint"><?php echo I18n::t('Removes all cached items. Feeds and settings remain untouched.'); ?></p>
                    </div>
                    <button type="button" class="tr-btn tr-btn-warn" id="fag-clear-cache"><?php echo $icon('trash', 14); ?> <?php echo I18n::t('Clear cache'); ?></button>
                </div>
                <div class="fag-danger-sep"></div>
                <div class="fag-danger-row">
                    <div>
                        <strong><?php echo I18n::t('Delete all plugin data'); ?></strong>
                        <p class="fag-hint"><?php echo I18n::t('Permanently removes feeds, cached items and settings. Imported posts remain in your site.'); ?></p>
                    </div>
                    <button type="button" class="tr-btn tr-btn-warn fag-btn-danger" id="fag-wipe"><?php echo $icon('trash', 14); ?> <?php echo I18n::t('Delete everything'); ?></button>
                </div>
            </div>
        </article>
    </section>
</div>

<!-- مودال -->
<div class="fag-modal" id="fag-modal" hidden>
    <div class="fag-modal-backdrop" data-close="1"></div>
    <div class="fag-modal-box" role="dialog" aria-modal="true">
        <div class="fag-modal-head">
            <h3 id="fag-modal-title"><?php echo I18n::t('Add a new feed'); ?></h3>
            <button type="button" class="fag-modal-close" data-close="1" aria-label="×">&times;</button>
        </div>
        <div class="fag-modal-body" id="fag-modal-body"></div>
    </div>
</div>

<!-- داده راه‌اندازی برای جاوااسکریپت -->
<script type="application/json" id="fag-boot"><?php echo $bootJson; ?></script>
<script src="<?php echo Util::esc($pluginUrl); ?>/assets/admin/panel.js?v=<?php echo Util::esc($version); ?>" defer></script>
