<?php
/**
 * موتور نمایش مطالب خوراک در سایت
 *
 * خروجی این کلاس کاملاً خودکفاست: استایل‌ها درون خطی (فقط یک بار در هر
 * صفحه) تزریق می‌شوند و هیچ وابستگی به قالب فعال وجود ندارد. مطالب
 * به‌صورت دسته‌بندی‌شده (بر اساس دسته متصل هر خوراک) نمایش داده
 * می‌شوند، تاریخ‌ها شمسی و اعداد فارسی هستند و در صورت فعال بودن
 * به‌روزرسانی تنبل، یک اسکریپت کوچک سرور را از سرآمدن زمان به‌روزرسانی
 * باخبر می‌کند.
 *
 * @package FeedAggregator
 */
namespace TypechoPlugin\FeedAggregator;

use TypechoPlugin\FeedAggregator\Repo\ItemRepo;
use Widget\Options;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Renderer
{
    /**
     * آیا استایل به این صفحه تزریق شده است؟
     *
     * @var bool
     */
    private static bool $stylePrinted = false;

    /**
     * آیا اسکریپت پین به‌روزرسانی تزریق شده است؟
     *
     * @var bool
     */
    private static bool $scriptPrinted = false;

    /**
     * رندر فهرست دسته‌بندی‌شده مطالب
     *
     * گزینه‌های پشتیبانی‌شده:
     * cat (شناسه یا نامک دسته)، feed (شناسه خوراک)، count (تعداد کل)،
     * title (عنوان بلوک)، layout (list یا cards)، excerpt (نمایش خلاصه)،
     * image (نمایش تصویر)، date (نمایش تاریخ)، dateFormat، feedName (نام خوراک)
     *
     * @param array<string, mixed> $opts گزینه‌ها
     * @return string HTML خروجی
     */
    public static function render(array $opts = []): string
    {
        $options = Options::alloc();

        $opts = array_merge([
            'cat' => 0,
            'feed' => 0,
            'count' => 10,
            'title' => '',
            'layout' => 'list',
            'excerpt' => true,
            'image' => true,
            'date' => true,
            'dateFormat' => 'j F Y',
            'feedName' => true,
        ], $opts);

        $categoryId = self::resolveCategory($opts['cat']);
        $feedId = (int) $opts['feed'];
        $count = (int) $opts['count'];
        $layout = $opts['layout'] === 'cards' ? 'cards' : 'list';

        // بازیابی آیتم‌ها از کش (بدون هیچ دریافت شبکه‌ای در مسیر نمایش)
        $items = ItemRepo::forFront([
            'categoryId' => $categoryId,
            'feedId' => $feedId,
            'count' => $count,
        ]);

        $html = '<div class="fag-wrap" dir="rtl">';

        $html .= self::style($options);

        if ($opts['title'] !== '') {
            $html .= '<h3 class="fag-block-title">' . Util::esc((string) $opts['title']) . '</h3>';
        }

        if (empty($items)) {
            $html .= '<p class="fag-empty">' . I18n::t('No feed items yet. Items will appear after the next update.') . '</p>';
            $html .= '</div>';
            return $html;
        }

        // گروه‌بندی آیتم‌ها بر اساس دسته‌بندی خوراک
        $groups = [];
        $order = [];
        foreach ($items as $item) {
            $key = (int) ($item['categoryId'] ?? 0);
            if (!isset($groups[$key])) {
                $groups[$key] = ['label' => self::categoryLabel($key, (string) $item['feedTitle']), 'items' => []];
                $order[] = $key;
            }
            $groups[$key]['items'][] = $item;
        }

        foreach ($order as $key) {
            $group = $groups[$key];

            $html .= '<section class="fag-group">';
            $html .= '<div class="fag-group-head">';
            $html .= '<span class="fag-group-title">' . Util::esc($group['label']) . '</span>';
            $html .= '<span class="fag-badge">' . I18n::n('%d item', '%d items', count($group['items'])) . '</span>';
            $html .= '</div>';

            $html .= '<div class="fag-items fag-' . $layout . '">';

            foreach ($group['items'] as $item) {
                $html .= self::item($item, $opts);
            }

            $html .= '</div></section>';
        }

        $html .= self::pingScript();

        $html .= '</div>';

        return $html;
    }

    /**
     * رندر یک آیتم
     *
     * @param array<string, mixed> $item سطر آیتم
     * @param array<string, mixed> $opts گزینه‌ها
     * @return string
     */
    private static function item(array $item, array $opts): string
    {
        $url = (string) $item['url'];
        $title = (string) $item['title'];

        // مطالب خوراک همیشه به منبع اصلی لینک می‌شوند (رفتار استاندارد
        // تجمیع‌کننده)؛ نوشته‌های واردشده در حالت post نیز permalink
        // مستقل خود را در آرشیو دسته‌بندی دارند
        $attrs = 'href="' . Util::esc($url !== '' ? $url : '#') . '" target="_blank" rel="nofollow noopener"';

        $hasImage = !empty($item['image']) && $opts['image'];

        $html = '<article class="fag-item' . ($hasImage ? ' fag-has-thumb' : '') . '">';
        $html .= '<a class="fag-item-link" ' . $attrs . '>';

        if ($hasImage) {
            $html .= '<span class="fag-thumb-wrap">'
                . '<img class="fag-thumb" src="' . Util::esc((string) $item['image']) . '" alt="' . Util::esc($title) . '" loading="lazy" decoding="async" />'
                . '</span>';
        }

        $html .= '<span class="fag-item-body">';
        $html .= '<span class="fag-item-title">' . Util::esc($title) . '</span>';

        if ($opts['excerpt'] && !empty($item['excerpt'])) {
            $html .= '<span class="fag-item-excerpt">' . Util::esc((string) $item['excerpt']) . '</span>';
        }

        $html .= '<span class="fag-item-meta">';

        if ($opts['feedName'] && !empty($item['feedTitle'])) {
            $html .= '<span class="fag-source">' . Util::esc((string) $item['feedTitle']) . '</span>';
        }

        if ($opts['date'] && !empty($item['postedAt'])) {
            $html .= '<time class="fag-date" datetime="' . date('c', (int) $item['postedAt']) . '">'
                . Date::format((int) $item['postedAt'], (string) $opts['dateFormat'])
                . '</time>';
        }

        $html .= '</span></span></a></article>';

        return $html;
    }

    /**
     * استایل خودکفا (فقط یک بار در هر صفحه)
     *
     * @param Options $options گزینه‌های سایت
     * @return string
     */
    private static function style(Options $options): string
    {
        if (self::$stylePrinted) {
            return '';
        }

        self::$stylePrinted = true;

        // استایل به‌صورت فایل خارجی بارگذاری می‌شود (مجاز در body طبق
        // HTML5) تا متن CSS وارد خلاصه/توضیحات متای صفحه نشود و کش
        // مرورگر هم بتواند از آن استفاده کند
        $cssUrl = rtrim((string) $options->pluginUrl, '/')
            . '/FeedAggregator/assets/front/front.css?v=' . Plugin::VERSION;

        return '<link rel="stylesheet" href="' . Util::esc($cssUrl) . '" media="all">';
    }

    /**
     * اسکریپت پین به‌روزرسانی تنبل (فقط یک بار در هر صفحه)
     *
     * @return string
     */
    private static function pingScript(): string
    {
        if (self::$scriptPrinted) {
            return '';
        }

        // فقط در صورت فعال بودن به‌روزرسانی تنبل
        if (Util::setting('lazy_update', '1') !== '1') {
            return '';
        }

        self::$scriptPrinted = true;

        $actionUrl = json_encode(Util::actionUrl(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        // زمان انتظار بین دو پین برای هر بازدیدکننده (۵ دقیقه)
        $gap = 300000;

        return '<script class="fag-script">
(function(){
"use strict";
if(typeof fetch!=="function"){return;}
var url=' . $actionUrl . ',gap=' . (int) $gap . ',key="fagPingAt";
var now=Date.now();
try{
var last=parseInt(sessionStorage.getItem(key)||"0",10);
if(now-last<gap){return;}
sessionStorage.setItem(key,String(now));
}catch(e){}
fetch(url,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"},body:"do=ping",credentials:"same-origin",keepalive:true}).catch(function(){});
})();
</script>';
    }

    /**
     * تبدیل ورودی دسته (شناسه عددی یا نامک) به شناسه عددی
     *
     * @param mixed $cat شناسه یا نامک
     * @return int
     */
    private static function resolveCategory($cat): int
    {
        if (is_numeric($cat)) {
            return max(0, (int) $cat);
        }

        $slug = trim((string) $cat);

        if ($slug === '') {
            return 0;
        }

        try {
            $row = \Typecho\Db::get()->fetchRow(
                \Typecho\Db::get()->select('mid')->from('table.metas')
                    ->where('slug = ? AND type = ?', $slug, 'category')
                    ->limit(1)
            );

            return $row ? (int) $row['mid'] : 0;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /**
     * برچسب گروه دسته‌بندی
     *
     * @param int    $categoryId شناسه دسته
     * @param string $fallback نام جایگزین (نام خوراک)
     * @return string
     */
    private static function categoryLabel(int $categoryId, string $fallback): string
    {
        if ($categoryId <= 0) {
            return I18n::t('Uncategorized');
        }

        try {
            $row = \Typecho\Db::get()->fetchRow(
                \Typecho\Db::get()->select('name')->from('table.metas')
                    ->where('mid = ? AND type = ?', $categoryId, 'category')
                    ->limit(1)
            );

            if (!empty($row['name'])) {
                return (string) $row['name'];
            }
        } catch (\Throwable $e) {
            // در صورت خطا از نام جایگزین استفاده می‌شود
        }

        return $fallback !== '' ? $fallback : I18n::t('Uncategorized');
    }
}
