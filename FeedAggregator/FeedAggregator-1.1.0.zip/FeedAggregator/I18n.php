<?php
/**
 * سیستم بین‌المللی‌سازی (i18n) افزونه تجمیع‌کننده خوراک
 *
 * بارگذاری ترجمه‌ها بر اساس زبان جاری سایت. اگر ترجمه‌ای برای زبان سایت
 * موجود نباشد، پیش‌فرض فارسی (fa_IR) بارگذاری می‌شود تا خروجی افزونه
 * همیشه فارسی باشد. برای افزودن زبان جدید کافی است فایلی با نام زبان
 * (مثلاً en_US.php) در پوشه langs بسازید که یک آرایه «متن اصلی => ترجمه»
 * را return کند.
 *
 * @package FeedAggregator
 */
namespace TypechoPlugin\FeedAggregator;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class I18n
{
    /**
     * ترجمه‌های بارگذاری‌شده
     *
     * @var array<string, string>|null
     */
    private static ?array $dict = null;

    /**
     * زبان بارگذاری‌شده
     *
     * @var string|null
     */
    private static ?string $loadedLang = null;

    /**
     * پوشه فایل‌های زبان
     *
     * @var string
     */
    private const LANG_DIR = __DIR__ . '/langs';

    /**
     * زبان پیش‌فرض (فارسی)
     *
     * @var string
     */
    public const DEFAULT_LANG = 'fa_IR';

    /**
     * اطمینان از بارگذاری فرهنگ لغت
     *
     * ترتیب بارگذاری:
     * ۱. زبان جاری سایت (از Typecho\I18n)
     * ۲. در صورت نبود فایل، زبان پیش‌فرض فارسی
     *
     * @return void
     */
    private static function load(): void
    {
        if (self::$dict !== null) {
            return;
        }

        // تعیین زبان جاری سایت؛ در صورت عدم دسترسی به پیش‌فرض فارسی برمی‌گردیم
        $lang = '';
        if (class_exists('\Typecho\I18n')) {
            try {
                $lang = (string) \Typecho\I18n::getLang();
            } catch (\Throwable $e) {
                $lang = '';
            }
        }

        $lang = preg_replace('/[^a-zA-Z0-9_\-]/', '', $lang) ?: self::DEFAULT_LANG;

        if (!is_file(self::LANG_DIR . '/' . $lang . '.php')) {
            $lang = self::DEFAULT_LANG;
        }

        $dict = @include self::LANG_DIR . '/' . $lang . '.php';
        self::$dict = is_array($dict) ? $dict : [];
        self::$loadedLang = $lang;
    }

    /**
     * ترجمه یک عبارت
     *
     * متن‌های اصلی به انگلیسی نوشته می‌شوند و از طریق فایل‌های زبان
     * ترجمه می‌شوند. اگر ترجمه‌ای وجود نداشته باشد، خود متن اصلی
     * برگردانده می‌شود.
     *
     * @param string $text متن اصلی (انگلیسی)
     * @param mixed  ...$args آرگومان‌های اختیاری برای vsprintf
     * @return string
     */
    public static function t(string $text, ...$args): string
    {
        self::load();

        $translated = isset(self::$dict[$text]) ? self::$dict[$text] : $text;

        if (!empty($args)) {
            $translated = vsprintf($translated, $args);
        }

        return $translated;
    }

    /**
     * ترجمه و چاپ یک عبارت
     *
     * @param string $text متن اصلی
     * @param mixed  ...$args آرگومان‌های اختیاری
     * @return void
     */
    public static function e(string $text, ...$args): void
    {
        echo self::t($text, ...$args);
    }

    /**
     * ترجمه جمع و مفرد بر اساس عدد
     *
     * @param string $single فرم مفرد
     * @param string $plural فرم جمع
     * @param int    $number عدد تعیین‌کننده
     * @return string
     */
    public static function n(string $single, string $plural, int $number): string
    {
        self::load();

        $key = $number === 1 ? $single : $plural;
        $translated = isset(self::$dict[$key]) ? self::$dict[$key] : $key;

        return str_replace('%d', Util::faNum((string) $number), $translated);
    }

    /**
     * نام زبان بارگذاری‌شده (برای دیباگ)
     *
     * @return string
     */
    public static function lang(): string
    {
        self::load();
        return (string) self::$loadedLang;
    }
}
