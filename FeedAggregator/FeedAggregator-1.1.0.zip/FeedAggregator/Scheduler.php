<?php
/**
 * زمان‌بند به‌روزرسانی خوراک‌ها
 *
 * این کلاس منطق «چه زمانی» و «چگونه» به‌روزرسانی انجام می‌شود را نگه
 * می‌دارد و از سه مسیر قابل فراخوانی است:
 * ۱. به‌روزرسانی تنبل: هنگام بازدید بازدیدکننده در صورت سرآمدن فاصله
 *    زمانی (با پین async از سمت خروجی سایت)
 * ۲. کرون سرور: فراخوانی endpoint مخفی با کلید امن
 * ۳. دستی: دکمه «به‌روزرسانی فوری» در داشبورد مدیریت
 *
 * قفل دوچرخه‌ای (lock) تضمین می‌کند دو فرآیند همزمان اجرا نشوند.
 *
 * @package FeedAggregator
 */
namespace TypechoPlugin\FeedAggregator;

use TypechoPlugin\FeedAggregator\Repo\FeedRepo;
use TypechoPlugin\FeedAggregator\Repo\ItemRepo;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Scheduler
{
    /**
     * مدت اعتبار قفل اجرا (ثانیه) — مهلت امن برای خوراک‌های کند
     */
    private const LOCK_SECONDS = 600;

    /**
     * آیا زمان به‌روزرسانی خودکار رسیده است؟
     *
     * @return bool
     */
    public static function isDue(): bool
    {
        if (self::isLocked()) {
            return false;
        }

        $settings = Util::settings();
        $state = Util::state();

        $interval = (int) $settings['update_interval'] * 60;
        $lastRun = (int) ($state['lastRun'] ?? 0);

        // اگر هنوز هیچ اجرایی ثبت نشده، تنها در صورت وجود خوراک فعال اجرا می‌کنیم
        if ($lastRun === 0) {
            return FeedRepo::count(true) > 0;
        }

        return (time() - $lastRun) >= $interval;
    }

    /**
     * آیا فرآیندی در حال اجراست؟
     *
     * @return bool
     */
    public static function isLocked(): bool
    {
        return Util::isLocked();
    }

    /**
     * زمان باقی‌مانده تا به‌روزرسانی بعدی (ثانیه)
     *
     * @return int منفی = سرآمده
     */
    public static function nextDueIn(): int
    {
        $settings = Util::settings();
        $state = Util::state();

        $interval = (int) $settings['update_interval'] * 60;
        $lastRun = (int) ($state['lastRun'] ?? 0);

        return ($lastRun + $interval) - time();
    }

    /**
     * به‌روزرسانی تنبل: در صورت سرآمدن زمان، اجرا می‌شود
     *
     * @return array<string, mixed>|null آمار اجرا یا null اگر اجرا نشد
     */
    public static function maybeUpdate(): ?array
    {
        if (!self::isDue()) {
            return null;
        }

        return self::run('lazy');
    }

    /**
     * اجرای کامل یک دوره به‌روزرسانی
     *
     * @param string $trigger نوع محرک: lazy | cron | manual | single
     * @param int    $feedId  شناسه خوراک خاص (فقط در حالت single)
     * @return array<string, mixed> آمار اجرا
     */
    public static function run(string $trigger = 'manual', int $feedId = 0): array
    {
        $startedAt = microtime(true);

        // قفل فعال: از اجرای موازی جلوگیری می‌شود
        if (self::isLocked()) {
            return [
                'ran' => false,
                'reason' => I18n::t('Another update is currently running'),
                'trigger' => $trigger,
            ];
        }

        self::acquireLock();

        $stats = [
            'ran' => true,
            'trigger' => $trigger,
            'feeds' => 0,
            'ok' => 0,
            'failed' => 0,
            'itemsNew' => 0,
            'postsNew' => 0,
            'notModified' => 0,
            'duration' => 0,
            'errors' => [],
        ];

        try {
            // انتخاب خوراک‌های هدف
            if ($feedId > 0) {
                $feed = FeedRepo::find($feedId);
                $feeds = $feed === null ? [] : [$feed];
            } else {
                $feeds = FeedRepo::all(true);
            }

            $settings = Util::settings();
            $timeout = (int) $settings['fetch_timeout'];
            $purgeDays = (int) $settings['purge_days'];

            foreach ($feeds as $feed) {
                $stats['feeds']++;

                $result = self::updateFeed($feed, $timeout);

                if ($result['ok']) {
                    $stats['ok']++;
                    $stats['itemsNew'] += $result['itemsNew'];
                    $stats['postsNew'] += $result['postsNew'];

                    if ($result['notModified']) {
                        $stats['notModified']++;
                    }
                } else {
                    $stats['failed']++;

                    if (count($stats['errors']) < 10) {
                        $stats['errors'][] = [
                            'feed' => (string) $feed['title'],
                            'error' => (string) $result['error'],
                        ];
                    }
                }
            }

            // پاک‌سازی خودکار آیتم‌های قدیمی
            if ($feedId <= 0 && $purgeDays > 0) {
                ItemRepo::purgeOld($purgeDays);

                // محدود کردن سقف آیتم هر خوراک
                foreach ($feeds as $feed) {
                    ItemRepo::trimToLimit((int) $feed['id'], (int) $feed['maxItems']);
                    FeedRepo::refreshCount((int) $feed['id']);
                }
            } elseif ($feedId > 0 && !empty($feeds)) {
                ItemRepo::trimToLimit((int) $feeds[0]['id'], (int) $feeds[0]['maxItems']);
                FeedRepo::refreshCount((int) $feeds[0]['id']);
            }

            $stats['duration'] = (int) round((microtime(true) - $startedAt) * 1000);

            // ثبت وضعیت نهایی
            Util::saveState([
                'lockUntil' => 0,
                'lastRun' => time(),
                'lastStats' => $stats,
            ]);

            return $stats;
        } catch (\Throwable $e) {
            // حتی در صورت خطای کلی، قفل آزاد می‌شود
            Util::saveState([
                'lockUntil' => 0,
                'lastRun' => (int) (Util::state()['lastRun'] ?? 0),
                'lastStats' => [
                    'ran' => false,
                    'error' => $e->getMessage(),
                ],
            ]);

            return [
                'ran' => false,
                'reason' => $e->getMessage(),
                'trigger' => $trigger,
            ];
        }
    }

    /**
     * به‌روزرسانی یک خوراک مشخص
     *
     * @param array<string, mixed> $feed    سطر خوراک
     * @param int                  $timeout مهلت HTTP
     * @return array<string, mixed> نتیجه
     */
    private static function updateFeed(array $feed, int $timeout): array
    {
        $result = [
            'ok' => false,
            'error' => '',
            'notModified' => false,
            'itemsNew' => 0,
            'postsNew' => 0,
        ];

        $maxItems = min(500, max(10, (int) $feed['maxItems'] + 10));

        $fetcher = new Fetcher();
        $fetch = $fetcher->fetch((string) $feed['url'], $feed, $timeout, $maxItems);

        if (!$fetch['ok']) {
            FeedRepo::markFetch((int) $feed['id'], false, (string) $fetch['error']);
            $result['error'] = (string) $fetch['error'];
            return $result;
        }

        FeedRepo::markFetch(
            (int) $feed['id'],
            true,
            '',
            (string) $fetch['etag'],
            (string) $fetch['lastModified']
        );

        if ($fetch['notModified']) {
            // سرور می‌گوید خوراک تغییری نکرده؛ اما اگر کش این خوراک خالی
            // باشد (مثلاً پس از پاک‌سازی دستی کش)، دریافت کامل بدون
            // شرط‌های ETag تکرار می‌شود تا آیتم‌ها بازسازی شوند
            if ((int) ($feed['itemCount'] ?? 0) > 0) {
                $result['ok'] = true;
                $result['notModified'] = true;
                return $result;
            }

            $retry = new Fetcher();
            $fetch = $retry->fetch((string) $feed['url'], ['etag' => '', 'lastModified' => ''], $timeout, $maxItems);

            if (!$fetch['ok']) {
                $result['error'] = (string) $fetch['error'];
                return $result;
            }

            if ($fetch['notModified']) {
                // وضعیت غیرمنتظره؛ همانند موفق بدون آیتم رفتار می‌کنیم
                $result['ok'] = true;
                return $result;
            }
        }

        // اگر عنوان خوراک خالی است از متادیتای دریافتی پر می‌شود
        if (trim((string) $feed['title']) === '' && !empty($fetch['meta']['title'])) {
            FeedRepo::update((int) $feed['id'], ['title' => (string) $fetch['meta']['title']]);
        }

        $isPostMode = ($feed['mode'] ?? 'cache') === 'post';

        foreach ((array) $fetch['items'] as $item) {
            // ذخیره در کش؛ مقدار null یعنی تکراری بوده است
            $itemId = ItemRepo::store((int) $feed['id'], $item);

            if ($itemId === null) {
                continue;
            }

            $result['itemsNew']++;

            // ساخت نوشته واقعی در حالت post
            if ($isPostMode) {
                $postId = Importer::import($itemId, $feed, $item);

                if ($postId !== null) {
                    $result['postsNew']++;
                }
            }
        }

        // محدود کردن سقف و به‌روزرسانی شمارنده
        ItemRepo::trimToLimit((int) $feed['id'], (int) $feed['maxItems']);
        FeedRepo::refreshCount((int) $feed['id']);

        $result['ok'] = true;
        return $result;
    }

    /**
     * فعال‌سازی قفل اجرا
     *
     * @return void
     */
    private static function acquireLock(): void
    {
        $state = Util::state();
        $state['lockUntil'] = time() + self::LOCK_SECONDS;
        $state['busySince'] = time();
        Util::saveState($state);
    }
}
