<?php
/**
 * افزونه تجمیع‌کننده خوراک RSS/ATOM
 *
 * @package FeedAggregator
 * @author  پوردریایی
 * @link    https://pourdaryaei.ir
 * @since   1.6.0
 * @version 1.0.0
 * @license GPLv3
 */
namespace TypechoPlugin\FeedAggregator;

use Typecho\Plugin as TypechoPlugin;
use Typecho\Plugin\PluginInterface;
use Typecho\Widget\Helper\Form;
use Typecho\Widget\Helper\Form\Element\Number;
use Typecho\Widget\Helper\Form\Element\Radio;
use Typecho\Widget\Helper\Form\Element\Select;
use Typecho\Widget\Helper\Form\Element\Text;
use TypechoPlugin\FeedAggregator\Repo\FeedRepo;
use TypechoPlugin\FeedAggregator\Repo\ItemRepo;
use Utils\Helper;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Plugin implements PluginInterface
{
    /**
     * نسخه فعلی افزونه
     */
    public const VERSION = '1.1.0';

    /**
     * نام فایل پنل مدیریت (نسبت به ریشه افزونه)
     */
    public const PANEL_FILE = 'FeedAggregator/panel/dashboard.php';

    /**
     * نام اکشن ثبت‌شده
     */
    public const ACTION_NAME = 'feed-aggregator';

    /**
     * فعال‌سازی افزونه
     *
     * جداول ساخته می‌شوند، پنل مدیریت و اکشن ثبت می‌گردند، هوک‌های
     * نمایش متصل شده و تنظیمات پیش‌فرض (در صورت نبود) نوشته می‌شوند.
     *
     * @return string پیام موفقیت
     * @throws \Throwable در صورت خطای ساخت جداول
     */
    public static function activate(): string
    {
        // ۱. ساخت یا ارتقای جداول
        Install::ensureTables();

        // ۲. ثبت پنل مدیریت در منوی مدیریت (با آیکون اسپرایت قالب).
        //    نخست ثبت قبلی حذف می‌شود تا در فعال‌سازی‌های مکرر، ورودی
        //    تکراری در منو ساخته نشود.
        Helper::removePanel(10, self::PANEL_FILE);
        Helper::addPanel(
            10,
            self::PANEL_FILE,
            I18n::t('Feed Aggregator'),
            I18n::t('RSS feed aggregator management'),
            'administrator',
            false,
            '',
            ['icon' => 'i-layers']
        );

        // ۳. ثبت اکشن برای AJAX، کرون و پین به‌روزرسانی
        Helper::addAction(self::ACTION_NAME, '\TypechoPlugin\FeedAggregator\Action');

        // ۴. هوک پردازش شورت‌کد در محتوای نوشته‌ها
        TypechoPlugin::factory('Widget\Base\Contents')->contentEx = [__CLASS__, 'onContentEx'];
        TypechoPlugin::factory('Widget\Base\Contents')->excerptEx = [__CLASS__, 'onExcerptEx'];

        // ۵. نوشتن تنظیمات پیش‌فرض (فقط در نخستین فعال‌سازی)
        self::seedSettings();

        // ۶. اجرای نخستین به‌روزرسانی در نخستین بازدید پس از فعال‌سازی
        Util::saveState(['lockUntil' => 0, 'lastRun' => 0, 'lastStats' => []]);

        return I18n::t('Feed Aggregator plugin activated. Manage your feeds from the admin panel.');
    }

    /**
     * غیرفعال‌سازی افزونه
     *
     * تنها منو، اکشن و هوک‌ها حذف می‌شوند؛ داده‌ها (خوراک‌ها، کش و
     * نوشته‌های واردشده) دست‌نخورده باقی می‌مانند تا با فعال‌سازی
     * مجدد، همه چیز سر جای قبلی خود باشد.
     *
     * @return string
     */
    public static function deactivate(): string
    {
        Helper::removePanel(10, self::PANEL_FILE);
        Helper::removeAction(self::ACTION_NAME);

        return I18n::t('Feed Aggregator plugin deactivated. All data has been preserved.');
    }

    /**
     * فرم تنظیمات افزونه (صفحه مدیریت افزونه‌ها)
     *
     * نسخه کامل و گرافیکی همین تنظیمات در داشبورد اختصاصی افزونه در
     * دسترس است؛ این فرم مسیر کلاسیک و بدون جاوااسکریپت است و هر دو
     * روی یک مخزن واحد ذخیره می‌شوند.
     *
     * @param Form $form فرم
     * @return void
     */
    public static function config(Form $form): void
    {
        $interval = new Number(
            'update_interval',
            null,
            60,
            I18n::t('Update interval (minutes)'),
            I18n::t('Automatic feeds update frequency. Minimum is 5 minutes.') . ' — '
                . I18n::t('Full settings are available in the plugin dashboard.')
        );
        $interval->input->setAttribute('min', 5)->setAttribute('max', 10080);
        $form->addInput($interval);

        $lazy = new Radio(
            'lazy_update',
            ['1' => I18n::t('Enabled'), '0' => I18n::t('Disabled')],
            '1',
            I18n::t('Lazy update on visit'),
            I18n::t('When enabled, feeds are updated in the background on the first visit after the interval ends.')
        );
        $form->addInput($lazy);

        $cron = new Radio(
            'cron_enabled',
            ['1' => I18n::t('Enabled'), '0' => I18n::t('Disabled')],
            '0',
            I18n::t('Server cron endpoint'),
            I18n::t('Provides a secret URL for real cron jobs. Generate the key from the plugin dashboard.')
        );
        $form->addInput($cron);

        $timeout = new Number(
            'fetch_timeout',
            null,
            15,
            I18n::t('Fetch timeout (seconds)'),
            I18n::t('Maximum time to wait for each feed server.')
        );
        $timeout->input->setAttribute('min', 3)->setAttribute('max', 60);
        $form->addInput($timeout);

        $purge = new Number(
            'purge_days',
            null,
            30,
            I18n::t('Keep cache for (days)'),
            I18n::t('Items older than this will be removed automatically. Set 0 to keep forever.')
        );
        $purge->input->setAttribute('min', 0)->setAttribute('max', 3650);
        $form->addInput($purge);

        $mode = new Radio(
            'default_mode',
            ['cache' => I18n::t('Cache only (display via widget/shortcode)'), 'post' => I18n::t('Create real posts')],
            'cache',
            I18n::t('Default mode for new feeds'),
            I18n::t('Each feed can override this setting individually.')
        );
        $form->addInput($mode);

        $status = new Select(
            'default_post_status',
            [
                'publish' => I18n::t('Published'),
                'draft' => I18n::t('Draft'),
                'waiting' => I18n::t('Pending review'),
                'private' => I18n::t('Private'),
            ],
            'publish',
            I18n::t('Default status of imported posts'),
            I18n::t('Applies to feeds in post mode.')
        );
        $form->addInput($status);

        $maxItems = new Number(
            'default_max_items',
            null,
            50,
            I18n::t('Max cached items per feed'),
            I18n::t('Oldest items will be trimmed automatically.')
        );
        $maxItems->input->setAttribute('min', 1)->setAttribute('max', 500);
        $form->addInput($maxItems);

        $sourceLink = new Radio(
            'show_source_link',
            ['1' => I18n::t('Yes'), '0' => I18n::t('No')],
            '1',
            I18n::t('Add source link to imported posts'),
            I18n::t('A link to the original article will be appended at the end of each imported post.')
        );
        $form->addInput($sourceLink);
    }

    /**
     * تنظیمات شخصی (در این نسخه استفاده نمی‌شود)
     *
     * @param Form $form فرم
     * @return void
     */
    public static function personalConfig(Form $form): void
    {
    }

    /**
     * هوک محتوای نوشته: جایگزینی شورت‌کد با خروجی رندرشده
     *
     * @param string|null $content محتوا
     * @param mixed       $widget  ویجت
     * @param string|null $last    نتیجه قبلی زنجیره
     * @return string
     */
    public static function onContentEx(?string $content, $widget = null, ?string $last = null): string
    {
        return Shortcode::filter($content, $widget, $last);
    }

    /**
     * هوک خلاصه نوشته: حذف شورت‌کد از خلاصه‌ها
     *
     * @param string|null $excerpt خلاصه
     * @param mixed       $widget  ویجت
     * @param string|null $last    نتیجه قبلی زنجیره
     * @return string
     */
    public static function onExcerptEx(?string $excerpt, $widget = null, ?string $last = null): string
    {
        return Shortcode::strip($excerpt);
    }

    /**
     * نوشتن تنظیمات اولیه (فقط اگر کانفیگی وجود نداشته باشد)
     *
     * @return void
     */
    private static function seedSettings(): void
    {
        try {
            $db = \Typecho\Db::get();
            $row = $db->fetchRow(
                $db->select('value')->from('table.options')
                    ->where('name = ?', 'plugin:FeedAggregator')
                    ->limit(1)
            );

            if (!empty($row)) {
                $settings = json_decode((string) $row['value'], true);

                // فقط کلید مخفی کرون در صورت نبود تولید می‌شود
                if (is_array($settings) && empty($settings['cron_secret'])) {
                    $settings['cron_secret'] = bin2hex(random_bytes(20));
                    Helper::configPlugin('FeedAggregator', $settings);
                }

                return;
            }

            // نخستین فعال‌سازی: نوشتن همه پیش‌فرض‌ها
            $settings = Util::DEFAULT_SETTINGS;
            $settings['cron_secret'] = bin2hex(random_bytes(20));
            Helper::configPlugin('FeedAggregator', $settings);
        } catch (\Throwable $e) {
            // خطای نوشتن تنظیمات نباید فعال‌سازی را متوقف کند؛ مقادیر
            // پیش‌فرض به‌صورت خودکار در زمان اجرا اعمال می‌شوند
        }
    }
}

/**
 * تابع سراسری کمکی برای استفاده مستقیم در فایل‌های پوسته
 *
 * نمونه استفاده در قالب:
 *
 *   <?php feed_aggregator(['count' => 5, 'cat' => 'news']); ?>
 *
 * @param array<string, mixed> $opts گزینه‌های نمایش (مشروع Renderer::render)
 * @return void
 */
if (!function_exists('feed_aggregator')) {
    function feed_aggregator(array $opts = []): void
    {
        echo Renderer::render($opts);
    }
}
