<?php
/**
 * ویجت نمایش مطالب خوراک برای پوسته‌ها
 *
 * قالب‌سازان می‌توانند از این ویجت در فایل‌های پوسته استفاده کنند:
 *
 *   $this->widget('\TypechoPlugin\FeedAggregator\Widget')->render([
 *       'cat' => 3, 'count' => 5, 'layout' => 'cards'
 *   ]);
 *
 * یا از تابع سراسری کمکی (که در Plugin.php تعریف شده است):
 *
 *   feed_aggregator(['count' => 10]);
 *
 * @package FeedAggregator
 */
namespace TypechoPlugin\FeedAggregator;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * توجه: نام کلاس Widget است و به‌صورت کامل مسیری‌شده از \Typecho\Widget
 * ارث‌بری می‌کند تا با import تداخل پیش نیاید.
 */
class Widget extends \Typecho\Widget
{
    /**
     * مقداردهی اولیه ویجت (بدون نیاز به منطق خاص)
     *
     * @return void
     */
    public function execute()
    {
    }

    /**
     * رندر خروجی مطالب خوراک
     *
     * @param array<string, mixed> $opts گزینه‌های نمایش (مشروع Renderer::render)
     * @return void
     */
    public function render(array $opts = []): void
    {
        echo Renderer::render($opts);
    }

    /**
     * دریافت HTML به‌جای چاپ مستقیم
     *
     * @param array<string, mixed> $opts گزینه‌های نمایش
     * @return string
     */
    public function fetch(array $opts = []): string
    {
        return Renderer::render($opts);
    }
}
