<?php
/**
 * تقویم جلالی (شمسی) برای افزونه تجمیع‌کننده خوراک
 *
 * پیاده‌سازی الگوریتم دقیق تبدیل تاریخ میلادی به هجری شمسی بر پایه
 * الگوریتم شناخته‌شده jalaali (نسخه مرجع: پروژه jalaali-js با مجوز MIT).
 * زمان‌ها بر اساس منطقه زمانی سایت (تنظیم TypeRenew) محاسبه می‌شوند و
 * خروجی به‌صورت پیش‌فرض همراه اعداد فارسی است.
 *
 * @package FeedAggregator
 */
namespace TypechoPlugin\FeedAggregator;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Date
{
    /**
     * نقاط عطف تقویم جلالی برای محاسبه سال کبیسه
     *
     * @var array<int>
     */
    private const BREAKS = [
        -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181,
        1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178,
    ];

    /**
     * نام ماه‌های شمسی
     *
     * @var array<int, string>
     */
    private const MONTHS = [
        1 => 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
        'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
    ];

    /**
     * نام روزهای هفته (اندیس‌گذاری مطابق تابع date با w: ۰ = یکشنبه)
     *
     * @var array<int, string>
     */
    private const DAYS = [
        0 => 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه',
    ];

    /**
     * تبدیل تاریخ میلادی به جلالی
     *
     * @param int $gy سال میلادی
     * @param int $gm ماه میلادی (۱ تا ۱۲)
     * @param int $gd روز میلادی
     * @return array{0: int, 1: int, 2: int} [سال، ماه، روز] شمسی
     */
    public static function toJalali(int $gy, int $gm, int $gd): array
    {
        return self::dayToJalali(self::gregorianToDay($gy, $gm, $gd));
    }

    /**
     * قالب‌بندی زمان یونیکس به تاریخ شمسی فارسی
     *
     * کاراکترهای پشتیبانی‌شده (مشابه date در PHP):
     * Y سال ۴ رقمی، y سال ۲ رقمی، m ماه با صفر، n ماه بدون صفر،
     * d روز با صفر، j روز بدون صفر، F نام ماه، l نام روز هفته،
     * H ساعت ۲۴ ساعته با صفر، G بدون صفر، i دقیقه، s ثانیه
     *
     * @param int    $timestamp زمان یونیکس
     * @param string $format    قالب خروجی
     * @param bool   $faDigits  تبدیل اعداد به فارسی (پیش‌فرض: بله)
     * @return string
     */
    public static function format(int $timestamp, string $format = 'j F Y', bool $faDigits = true): string
    {
        if ($timestamp <= 0) {
            $timestamp = time();
        }

        // مؤلفه‌های میلادی بر اساس منطقه زمانی سایت
        $date = new \Typecho\Date($timestamp);
        $gy = (int) $date->format('Y');
        $gm = (int) $date->format('n');
        $gd = (int) $date->format('j');
        $weekday = (int) $date->format('w');
        $hour = $date->format('G');
        $hourPadded = $date->format('H');
        $minute = $date->format('i');
        $second = $date->format('s');

        [$jy, $jm, $jd] = self::toJalali($gy, $gm, $gd);

        $replacements = [
            'Y' => (string) $jy,
            'y' => substr((string) $jy, -2),
            'm' => str_pad((string) $jm, 2, '0', STR_PAD_LEFT),
            'n' => (string) $jm,
            'd' => str_pad((string) $jd, 2, '0', STR_PAD_LEFT),
            'j' => (string) $jd,
            'F' => self::MONTHS[$jm] ?? '',
            'l' => self::DAYS[$weekday] ?? '',
            'H' => $hourPadded,
            'G' => $hour,
            'i' => $minute,
            's' => $second,
        ];

        $out = strtr($format, $replacements);

        return $faDigits ? Util::faNum($out) : $out;
    }

    /**
     * قالب‌بندی «نسبی» زمان (مثلاً: ۳ ساعت پیش)
     *
     * @param int $timestamp زمان یونیکس
     * @return string
     */
    public static function relative(int $timestamp): string
    {
        $diff = time() - $timestamp;

        if ($diff < 0) {
            $diff = 0;
        }

        if ($diff < 60) {
            return I18n::t('just now');
        }

        if ($diff < 3600) {
            return I18n::t('%d minutes ago', ceil($diff / 60));
        }

        if ($diff < 86400) {
            return I18n::t('%d hours ago', ceil($diff / 3600));
        }

        if ($diff < 2592000) {
            return I18n::t('%d days ago', ceil($diff / 86400));
        }

        return self::format($timestamp);
    }

    /**
     * محاسبه عدد روز جولیَن از تاریخ میلادی
     *
     * @param int $gy سال میلادی
     * @param int $gm ماه میلادی
     * @param int $gd روز میلادی
     * @return int
     */
    private static function gregorianToDay(int $gy, int $gm, int $gd): int
    {
        $d = intdiv(($gy + intdiv($gm - 8, 6) + 100100) * 1461, 4)
            + intdiv(153 * self::positiveMod($gm + 9, 12) + 2, 5)
            + $gd - 34840408;

        return $d - intdiv(intdiv($gy + 100100 + intdiv($gm - 8, 6), 100) * 3, 4) + 752;
    }

    /**
     * محاسبه تاریخ جلالی از عدد روز جولیَن
     *
     * @param int $jdn عدد روز جولیَن
     * @return array{0: int, 1: int, 2: int}
     */
    private static function dayToJalali(int $jdn): array
    {
        $gregorian = self::dayToGregorian($jdn);
        $gy = $gregorian[0];
        $jy = $gy - 621;
        $r = self::jalaliCalendar($jy);

        // روز جولیَنِ اول فروردین سال jy: march = شماره روز ماه مارس میلادی
        // در همان سال میلادی (gy) است — نه سال جلالی
        $jdn1f = self::gregorianToDay($gy, 3, $r['march']);
        $k = $jdn - $jdn1f;

        if ($k >= 0) {
            if ($k <= 185) {
                // ۶ ماه اول سال: ۳۱ روزه
                return [$jy, 1 + intdiv($k, 31), self::positiveMod($k, 31) + 1];
            }
            $k -= 186;
        } else {
            // روزهای پایانی سال قبل
            $jy -= 1;
            $k += 179;
            if ($r['leap'] === 1) {
                $k += 1;
            }
        }

        return [$jy, 7 + intdiv($k, 30), self::positiveMod($k, 30) + 1];
    }

    /**
     * محاسبه تاریخ میلادی از عدد روز جولیَن
     *
     * @param int $jdn عدد روز جولیَن
     * @return array{0: int, 1: int, 2: int}
     */
    private static function dayToGregorian(int $jdn): array
    {
        $j = 4 * $jdn + 139361631;
        $j += intdiv(intdiv(4 * $jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
        $i = intdiv(self::positiveMod($j, 1461), 4) * 5 + 308;
        $gd = intdiv(self::positiveMod($i, 153), 5) + 1;
        $gm = self::positiveMod(intdiv($i, 153), 12) + 1;
        $gy = intdiv($j, 1461) - 100100 + intdiv(8 - $gm, 6);

        return [$gy, $gm, $gd];
    }

    /**
     * محاسبه اطلاعات تقویمی سال جلالی (کبیسه و روز اول فروردین)
     *
     * @param int $jy سال جلالی
     * @return array{leap: int, gy: int, march: int}
     */
    private static function jalaliCalendar(int $jy): array
    {
        $bl = count(self::BREAKS);
        $gy = $jy + 621;
        $leapJ = -14;
        $jp = self::BREAKS[0];
        $jump = 0;

        for ($i = 1; $i < $bl; $i++) {
            $jm = self::BREAKS[$i];
            $jump = $jm - $jp;

            if ($jy < $jm) {
                break;
            }

            $leapJ += intdiv($jump, 33) * 8 + intdiv(self::positiveMod($jump, 33), 4);
            $jp = $jm;
        }

        $n = $jy - $jp;
        $leapJ += intdiv($n, 33) * 8 + intdiv(self::positiveMod($n, 33) + 3, 4);

        if (self::positiveMod($jump, 33) === 4 && $jump - $n === 4) {
            $leapJ += 1;
        }

        $leapG = intdiv($gy, 4) - intdiv((intdiv($gy, 100) + 1) * 3, 4) - 150;
        $march = 20 + $leapJ - $leapG;

        // محاسبه سال کبیسه جلالی
        if ($jump - $n < 6) {
            $n = $n - $jump + intdiv($jump + 4, 33) * 33;
        }

        $leap = self::positiveMod(self::positiveMod($n + 1, 33) - 1, 4);
        if ($leap === -1) {
            $leap = 4;
        }

        return ['leap' => $leap, 'gy' => $gy, 'march' => $march];
    }

    /**
     * باقیمانده مثبت تقسیم
     *
     * @param int $a عدد
     * @param int $b مقسوم‌علیه
     * @return int
     */
    private static function positiveMod(int $a, int $b): int
    {
        return $a - $b * intdiv($a, $b);
    }
}
