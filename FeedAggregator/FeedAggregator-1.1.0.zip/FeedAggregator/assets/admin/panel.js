/**
 * منطق تعاملی پنل مدیریت افزونه تجمیع‌کننده خوراک — نسخه یکپارچه با قالب ادمین
 *
 * بدون هیچ وابستگی خارجی (Vanilla JS). داده راه‌اندازی از تگ
 * <script type="application/json" id="fag-boot"> خوانده می‌شود، پیام‌ها از
 * طریق سازوکار اعلان‌های خود قالب مدیریت (TypechoNotice) نمایش می‌یابند
 * و آیکون‌ها از اسپرایت Lucide قالب ادمین درج می‌گردند تا ظاهر پنل
 * کاملاً با محیط مدیریت (از جمله حالت شب) هماهنگ بماند.
 */
(function () {
    'use strict';

    // -------------------------------------------------------------------------
    // داده راه‌اندازی
    // -------------------------------------------------------------------------

    var bootEl = document.getElementById('fag-boot');
    var BOOT = {};
    try {
        BOOT = JSON.parse(bootEl ? bootEl.textContent : '{}') || {};
    } catch (e) {
        BOOT = {};
    }

    var API = BOOT.actionUrl || '';
    var TOKEN = BOOT.token || '';
    var T = BOOT.i18n || {};
    var ICONS = BOOT.iconsUrl || '';

    // -------------------------------------------------------------------------
    // ابزارهای عمومی
    // -------------------------------------------------------------------------

    /** تبدیل ارقام لاتین به فارسی */
    function faNum(value) {
        return String(value == null ? '' : value).replace(/[0-9]/g, function (d) {
            return '۰۱۲۳۴۵۶۷۸۹'[+d];
        });
    }

    /** فرار امن HTML */
    function esc(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    /** درج آیکون از اسپرایت قالب مدیریت (Lucide) */
    function ic(name, size) {
        if (!ICONS || !name) { return ''; }
        size = size || 13;
        return '<svg class="tr-ico" style="width:' + size + 'px;height:' + size + 'px;flex:0 0 ' + size + 'px" aria-hidden="true">'
            + '<use href="' + esc(ICONS) + '#i-' + esc(name) + '"></use></svg>';
    }

    /** انتخابگر کوتاه */
    function $(selector, root) {
        return (root || document).querySelector(selector);
    }

    /** انتخاب همه عناصر */
    function $$(selector, root) {
        return Array.prototype.slice.call((root || document).querySelectorAll(selector));
    }

    /** نمایش پیام از طریق سیستم اعلان قالب مدیریت (با پشتیبان محلی) */
    function toast(message, type) {
        if (!message) { return; }

        if (window.TypechoNotice && typeof window.TypechoNotice.show === 'function') {
            var kind = type === 'ok' ? 'success' : (type === 'error' ? 'error' : 'notice');
            window.TypechoNotice.show(kind, [message]);
            return;
        }

        // پشتیبان: اعلان شناور ساده در بالا-چپ صفحه
        var host = $('#fag-notice-fallback');
        if (!host) {
            host = document.createElement('div');
            host.id = 'fag-notice-fallback';
            host.style.cssText = 'position:fixed;top:16px;inset-inline-end:16px;z-index:2000;display:flex;flex-direction:column;gap:8px';
            document.body.appendChild(host);
        }

        var el = document.createElement('div');
        el.style.cssText = 'padding:12px 18px;border-radius:12px;box-shadow:0 10px 30px rgba(2,6,23,.25);font-size:13px;font-weight:600;max-width:340px;'
            + (type === 'error' ? 'background:#fee2e2;color:#b91c1c' : (type === 'ok' ? 'background:#d1fae5;color:#047857' : 'background:#e2e8f0;color:#0f172a'));
        el.textContent = message;
        host.appendChild(el);
        setTimeout(function () { el.remove(); }, 4200);
    }

    /** فعال/غیرفعال کردن دکمه همراه با نشانگر انتظار */
    function busy(button, isBusy) {
        if (!button) { return; }
        button.disabled = isBusy;

        var spin = button.querySelector('.fag-spin');
        if (spin) { spin.hidden = !isBusy; }
    }

    /** ارسال درخواست به سرور */
    function api(action, data) {
        var form = new FormData();
        form.append('do', action);
        form.append('fag_token', TOKEN);

        if (data) {
            Object.keys(data).forEach(function (key) {
                form.append(key, data[key]);
            });
        }

        return fetch(API, {
            method: 'POST',
            body: form,
            credentials: 'same-origin',
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        }).then(function (response) {
            return response.json().catch(function () {
                throw new Error(T.requestFailed);
            });
        });
    }

    // -------------------------------------------------------------------------
    // مودال
    // -------------------------------------------------------------------------

    var modal = $('#fag-modal');
    var modalTitle = $('#fag-modal-title');
    var modalBody = $('#fag-modal-body');

    function openModal(title, html) {
        modalTitle.textContent = title;
        modalBody.innerHTML = html;
        modal.hidden = false;
        var firstInput = modalBody.querySelector('input:not([type=hidden]), select, textarea');
        if (firstInput) { firstInput.focus(); }
    }

    function closeModal() {
        modal.hidden = true;
        modalBody.innerHTML = '';
    }

    if (modal) {
        modal.addEventListener('click', function (event) {
            if (event.target.getAttribute('data-close')) { closeModal(); }
        });

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && !modal.hidden) { closeModal(); }
        });
    }

    /** نمایش تأیید ساده داخل مودال */
    function confirmModal(title, message, confirmLabel, onConfirm, extraHtml) {
        var html = '<p>' + esc(message) + '</p>' + (extraHtml || '') +
            '<div class="fag-modal-actions">' +
            '<button type="button" class="tr-btn tr-btn-warn" data-confirm="1">' + ic('trash', 13) + ' ' + esc(confirmLabel) + '</button>' +
            '<button type="button" class="tr-btn" data-close="1">' + esc(T.cancel || 'Cancel') + '</button>' +
            '</div>';

        openModal(title, html);

        var btn = modalBody.querySelector('[data-confirm]');
        btn.addEventListener('click', function () {
            var phraseInput = modalBody.querySelector('[data-phrase]');
            if (phraseInput && phraseInput.value.trim() !== phraseInput.getAttribute('data-phrase')) {
                phraseInput.focus();
                phraseInput.style.borderColor = 'var(--tr-danger)';
                return;
            }
            closeModal();
            onConfirm();
        });
    }

    // -------------------------------------------------------------------------
    // تب‌ها (سازوکار استاندارد قالب: tr-panel-tab + tr-panel-pane)
    // -------------------------------------------------------------------------

    function activateTab(name) {
        $$('.fag-panel .tr-panel-tab').forEach(function (tab) {
            tab.classList.toggle('is-active', tab.getAttribute('data-target') === name);
        });
        $$('.fag-panel .tr-panel-pane').forEach(function (pane) {
            pane.classList.toggle('is-active', pane.getAttribute('data-tab') === name);
        });
    }

    $$('.fag-panel .tr-panel-tab').forEach(function (tab) {
        tab.addEventListener('click', function () {
            var name = tab.getAttribute('data-target');
            activateTab(name);

            if (name === 'feeds') { loadFeeds(); }
            if (name === 'items') { loadItems(1); }
            if (name === 'dashboard') { refreshStatus(); }
        });
    });

    // -------------------------------------------------------------------------
    // داشبورد: آمار و وضعیت
    // -------------------------------------------------------------------------

    function renderStats(data) {
        var cards = $('#fag-stat-cards');
        if (!cards) { return; }

        var defs = [
            [T.feedsLabel || 'Feeds', data.feeds, 'layers'],
            [T.activeLabel || 'Active', data.activeFeeds, 'check'],
            [T.itemsLabel || 'Items', data.items, 'list'],
            [T.newPosts || 'New posts', data.posts, 'file-text'],
            [T.errorFeedsLabel || 'Errored feeds', data.errorFeeds, 'alert']
        ];

        cards.innerHTML = defs.map(function (def) {
            return '<div class="tr-panel-kpi">'
                + '<span>' + esc(def[0]) + '</span>'
                + '<strong>' + faNum(def[1] == null ? 0 : def[1]) + '</strong>'
                + '</div>';
        }).join('');
    }

    function renderStatus(data) {
        var dot = $('#fag-dot');
        var text = $('#fag-status-text');
        var lastRun = $('#fag-last-run');
        var nextRun = $('#fag-next-run');

        if (dot && text) {
            dot.className = 'fag-dot';
            if (data.locked) {
                dot.classList.add('fag-dot-busy');
                text.textContent = T.updatingNow || 'در حال به‌روزرسانی…';
            } else if (data.errorFeeds > 0) {
                dot.classList.add('fag-dot-err');
                text.textContent = (T.errorFeedsMsg || '%d خوراک خطا دارند').replace('%d', faNum(data.errorFeeds));
            } else {
                dot.classList.add('fag-dot-ok');
                text.textContent = T.allHealthy || 'همه چیز سالم است';
            }
        }

        if (lastRun) {
            lastRun.textContent = (T.lastRunLabel || 'آخرین به‌روزرسانی') + ': ' + (data.lastRun || '—');
        }

        if (nextRun) {
            var seconds = data.nextRunIn;
            if (seconds === null || seconds === undefined) {
                nextRun.textContent = '';
            } else if (seconds <= 0) {
                nextRun.textContent = (T.nextRunLabel || 'به‌روزرسانی بعدی') + ': ' + (T.readyToRun || 'آماده اجرا');
            } else {
                var minutes = Math.ceil(seconds / 60);
                nextRun.textContent = (T.nextRunLabel || 'به‌روزرسانی بعدی') + ': ' +
                    (minutes >= 60
                        ? faNum(Math.floor(minutes / 60)) + ' ' + (T.hours || 'ساعت') + ' و ' + faNum(minutes % 60) + ' ' + (T.minutes || 'دقیقه')
                        : faNum(minutes) + ' ' + (T.minutes || 'دقیقه')) +
                    ' ' + (T.later || 'دیگر');
            }
        }
    }

    function renderReport(stats, data) {
        var report = $('#fag-last-report');
        if (!report) { return; }

        if (!stats || !stats.ran) {
            report.innerHTML = '<p class="fag-muted">' + esc(T.noReportYet || 'هنوز گزارشی از به‌روزرسانی ثبت نشده است.') + '</p>';
        } else {
            report.innerHTML =
                '<div class="fag-report-grid">' +
                '<div class="fag-report-cell"><b>' + faNum(stats.feeds || 0) + '</b><span>' + esc(T.totalRuns || 'خوراک بررسی‌شده') + '</span></div>' +
                '<div class="fag-report-cell"><b>' + faNum(stats.itemsNew || 0) + '</b><span>' + esc(T.newItems || 'آیتم جدید') + '</span></div>' +
                '<div class="fag-report-cell"><b>' + faNum(stats.postsNew || 0) + '</b><span>' + esc(T.newPosts || 'نوشته جدید') + '</span></div>' +
                '<div class="fag-report-cell"><b>' + faNum(stats.notModified || 0) + '</b><span>' + esc(T.notModified || 'بدون تغییر') + '</span></div>' +
                '<div class="fag-report-cell"><b>' + faNum(stats.failed || 0) + '</b><span>' + esc(T.errorLabel || 'خطا') + '</span></div>' +
                '</div>' +
                '<p class="fag-hint" style="margin-top:10px">' + esc(T.lastRunLabel || 'زمان اجرا') + ': ' + esc(data.lastRun || '—') +
                (stats.duration ? ' · ' + esc(T.duration || 'مدت') + ': ' + faNum(stats.duration) + ' ms' : '') + '</p>';
        }
    }

    function renderErrors(data) {
        var box = $('#fag-recent-errors');
        if (!box) { return; }

        var stats = data.lastStats || {};
        var errors = (stats && stats.errors) || [];

        if (data.errorFeeds === 0 && errors.length === 0) {
            box.innerHTML = '<p class="fag-muted">' + esc(T.noErrors || 'خطایی وجود ندارد. همه خوراک‌ها سالم هستند.') + '</p>';
            return;
        }

        var html = '<ul class="fag-error-list">';
        errors.slice(0, 6).forEach(function (error) {
            html += '<li><span class="fag-err-feed">' + esc(error.feed) + '</span>' +
                '<span class="fag-err-msg">' + esc(error.error) + '</span></li>';
        });
        html += '</ul>';

        box.innerHTML = html;
    }

    function refreshStatus() {
        api('stats').then(function (response) {
            if (!response.ok) { return; }
            var data = response.data;
            renderStats(data);
            renderStatus(data);
            renderReport(data.lastStats, data);
            renderErrors(data);

            var feedsBadge = $('#fag-feeds-count');
            var itemsBadge = $('#fag-items-count');
            if (feedsBadge) { feedsBadge.textContent = faNum(data.feeds || 0); }
            if (itemsBadge) { itemsBadge.textContent = faNum(data.items || 0); }
        }).catch(function () { });
    }

    // به‌روزرسانی خودکار وضعیت هر ۳۰ ثانیه
    setInterval(refreshStatus, 30000);

    // دکمه به‌روزرسانی فوری
    var updateBtn = $('#fag-update-now');
    if (updateBtn) {
        updateBtn.addEventListener('click', function () {
            busy(updateBtn, true);
            api('update').then(function (response) {
                toast(response.msg || (response.ok ? (T.done || 'انجام شد') : (T.errorLabel || 'خطا')), response.ok ? 'ok' : 'error');
                refreshStatus();
            }).catch(function () {
                toast(T.requestFailed, 'error');
            }).finally(function () {
                busy(updateBtn, false);
            });
        });
    }

    // -------------------------------------------------------------------------
    // خوراک‌ها
    // -------------------------------------------------------------------------

    var feedsCache = [];

    function renderFeeds(feeds) {
        var tbody = $('#fag-feeds-tbody');
        if (!tbody) { return; }
        feedsCache = feeds;

        if (!feeds.length) {
            tbody.innerHTML = '<tr><td colspan="7" class="fag-muted fag-center">' +
                esc(T.feedsTabEmpty || 'هنوز خوراکی ثبت نشده است. نخستین خوراک RSS خود را اضافه کنید.') + '</td></tr>';
            return;
        }

        tbody.innerHTML = feeds.map(function (feed) {
            var modeBadge = feed.mode === 'post'
                ? '<span class="fag-badge fag-badge-violet">' + ic('pencil', 11) + ' ' + esc(T.postModeLabel || 'ثبت نوشته') + '</span>'
                : '<span class="fag-badge fag-badge-blue">' + ic('database', 11) + ' ' + esc(T.cacheModeLabel || 'فقط کش') + '</span>';

            var statusBadge = feed.lastError
                ? '<span class="fag-badge fag-badge-red" title="' + esc(feed.lastError) + '">' + ic('alert', 11) + ' ' + esc(T.errorLabel || 'خطا') + '</span>'
                : (feed.active
                    ? '<span class="fag-badge fag-badge-green">' + ic('check', 11) + ' ' + esc(T.activeLabel || 'فعال') + '</span>'
                    : '<span class="fag-badge">' + esc(T.stoppedLabel || 'متوقف') + '</span>');

            return '<tr>' +
                '<td><div class="fag-feed-name"><strong>' + esc(feed.title) + '</strong>' +
                (feed.url ? '<a class="fag-feed-link" href="' + esc(feed.url) + '" target="_blank" rel="noopener">' + esc(feed.url) + '</a>' : '') +
                '</div></td>' +
                '<td>' + esc(feed.categoryName) + '</td>' +
                '<td>' + modeBadge + '</td>' +
                '<td class="fag-num">' + faNum(feed.itemCount) + '</td>' +
                '<td>' + esc(feed.lastFetch) + '</td>' +
                '<td>' + statusBadge + '</td>' +
                '<td><div class="fag-row-actions">' +
                '<button type="button" class="btn btn-s" data-act="fetch" data-id="' + feed.id + '" title="' + esc(T.immediateFetch || 'دریافت فوری') + '">' + ic('refresh', 12) + '</button>' +
                '<button type="button" class="btn btn-s" data-act="edit" data-id="' + feed.id + '">' + ic('edit', 12) + ' ' + esc(T.edit) + '</button>' +
                '<button type="button" class="btn btn-s" data-act="toggle" data-id="' + feed.id + '">' + (feed.active ? esc(T.stop || 'توقف') : esc(T.activate || 'فعال‌سازی')) + '</button>' +
                '<button type="button" class="btn btn-s fag-btn-danger" data-act="delete" data-id="' + feed.id + '">' + ic('trash', 12) + '</button>' +
                '</div></td>' +
                '</tr>';
        }).join('');
    }

    function loadFeeds() {
        api('feeds').then(function (response) {
            if (response.ok) {
                renderFeeds(response.data || []);
            }
        }).catch(function () {
            var tbody = $('#fag-feeds-tbody');
            if (tbody) { tbody.innerHTML = '<tr><td colspan="7" class="fag-muted fag-center">' + esc(T.loadFailed || 'خطا در دریافت فهرست') + '</td></tr>'; }
        });
    }

    /** فرم افزودن/ویرایش خوراک داخل مودال */
    function feedForm(feed) {
        var settings = BOOT.settings || {};
        var isNew = !feed;
        feed = feed || {};

        var catOptions = '<option value="0">— ' + esc(T.category || 'بدون دسته') + ' —</option>' +
            (BOOT.categories || []).map(function (cat) {
                return '<option value="' + cat.id + '"' + (feed.categoryId === cat.id ? ' selected' : '') + '>' + esc(cat.label) + '</option>';
            }).join('');

        var authorOptions = (BOOT.authors || []).map(function (author) {
            return '<option value="' + author.id + '"' + ((feed.authorId || 1) === author.id ? ' selected' : '') + '>' + esc(author.name) + '</option>';
        }).join('');

        return '<form id="fag-feed-form">' +
            '<div class="fag-field"><label>' + esc(T.feedTitle || 'عنوان خوراک') + '</label>' +
            '<input type="text" name="title" value="' + esc(feed.title || '') + '" placeholder="…" required maxlength="180"></div>' +

            '<div class="fag-field"><label>' + esc(T.feedUrl || 'نشانی خوراک (RSS/Atom)') + '</label>' +
            '<input type="url" name="url" dir="ltr" style="text-align:left" value="' + esc(feed.url || '') + '" placeholder="https://example.com/feed" required maxlength="480"></div>' +

            '<div class="fag-field"><label>' + esc(T.category || 'دسته‌بندی اتصال') + '</label>' +
            '<select name="categoryId">' + catOptions + '</select>' +
            '<p class="fag-hint">' + esc(T.categoryHint || 'مطالب این خوراک در گروه همین دسته نمایش داده می‌شوند و نوشته‌ها نیز در همین دسته ثبت می‌گردند.') + '</p></div>' +

            '<div class="fag-form-row">' +
            '<div class="fag-field"><label>' + esc(T.mode || 'حالت') + '</label>' +
            '<select name="mode">' +
            '<option value="cache"' + ((feed.mode || settings.default_mode) !== 'post' ? ' selected' : '') + '>' + esc(T.cacheMode || 'فقط کش (نمایش با ویجت/شورت‌کد)') + '</option>' +
            '<option value="post"' + ((feed.mode || settings.default_mode) === 'post' ? ' selected' : '') + '>' + esc(T.postMode || 'ثبت به‌عنوان نوشته') + '</option>' +
            '</select></div>' +

            '<div class="fag-field"><label>' + esc(T.postStatus || 'وضعیت نوشته‌ها') + '</label>' +
            '<select name="postStatus">' +
            '<option value="publish"' + ((feed.postStatus || settings.default_post_status) === 'publish' ? ' selected' : '') + '>' + esc(T.statusPublish || 'انتشار فوری') + '</option>' +
            '<option value="draft"' + ((feed.postStatus || settings.default_post_status) === 'draft' ? ' selected' : '') + '>' + esc(T.statusDraft || 'پیش‌نویس') + '</option>' +
            '<option value="waiting"' + ((feed.postStatus || settings.default_post_status) === 'waiting' ? ' selected' : '') + '>' + esc(T.statusWaiting || 'در انتظار بررسی') + '</option>' +
            '<option value="private"' + ((feed.postStatus || settings.default_post_status) === 'private' ? ' selected' : '') + '>' + esc(T.statusPrivate || 'خصوصی') + '</option>' +
            '</select></div>' +
            '</div>' +

            '<div class="fag-form-row">' +
            '<div class="fag-field"><label>' + esc(T.author || 'نویسنده نوشته‌ها') + '</label>' +
            '<select name="authorId">' + authorOptions + '</select></div>' +

            '<div class="fag-field"><label>' + esc(T.maxItems || 'حداکثر آیتم کش') + '</label>' +
            '<input type="number" name="maxItems" min="1" max="500" value="' + (feed.maxItems || settings.default_max_items || 50) + '"></div>' +
            '</div>' +

            '<div class="fag-field fag-field-inline">' +
            '<label class="fag-switch"><input type="checkbox" name="active" ' + (isNew || feed.active ? 'checked' : '') + '><span class="fag-switch-slider"></span></label>' +
            '<div><strong>' + esc(T.active || 'خوراک فعال باشد') + '</strong>' +
            '<p class="fag-hint">' + esc(T.activeHint || 'خوراک‌های متوقف در به‌روزرسانی خودکار بررسی نمی‌شوند.') + '</p></div></div>' +

            '<div class="fag-modal-actions">' +
            '<button type="submit" class="tr-btn primary">' + ic('save', 13) + ' ' + esc(T.save) + '</button>' +
            '<button type="button" class="tr-btn" data-close="1">' + esc(T.cancel) + '</button>' +
            (isNew ? '<button type="button" class="tr-btn" id="fag-test-feed-btn">' + ic('zap', 13) + ' ' + esc(T.test) + '</button>' : '') +
            '</div></form>';
    }

    function saveFeedFromForm() {
        var form = $('#fag-feed-form');
        if (!form || !form.reportValidity()) { return; }

        var data = {
            id: form.getAttribute('data-id') || 0,
            title: form.elements.title.value.trim(),
            url: form.elements.url.value.trim(),
            categoryId: form.elements.categoryId.value,
            mode: form.elements.mode.value,
            postStatus: form.elements.postStatus.value,
            authorId: form.elements.authorId.value,
            maxItems: form.elements.maxItems.value,
            active: form.elements.active.checked ? 1 : 0
        };

        api('save-feed', data).then(function (response) {
            if (response.ok) {
                closeModal();
                toast(response.msg, 'ok');
                loadFeeds();
                refreshStatus();
            } else {
                toast(response.msg, 'error');
            }
        }).catch(function () { toast(T.requestFailed, 'error'); });
    }

    /** تست نشانی خوراک بدون ذخیره */
    function testFeedUrl(url) {
        if (!url) { return; }

        api('test-feed', { url: url }).then(function (response) {
            var box = $('#fag-test-result');
            if (!box) { return; }

            if (!response.ok) {
                box.innerHTML = '<div class="fag-test-result is-error">' +
                    '<h4>' + esc(T.fetchError || 'خطا در دریافت خوراک') + '</h4><p style="font-size:12.5px;margin:0">' + esc(response.msg) + '</p></div>';
                return;
            }

            var data = response.data;
            var items = (data.preview || []).map(function (item) {
                return '<li><a href="' + esc(item.url) + '" target="_blank" rel="noopener">' + esc(item.title) + '</a>' +
                    (item.date ? ' <span class="fag-muted">· ' + esc(item.date) + '</span>' : '') + '</li>';
            }).join('');

            box.innerHTML = '<div class="fag-test-result">' +
                '<h4>' + esc(T.feedValid || 'خوراک معتبر است') + ' ✓</h4>' +
                '<p style="font-size:12.5px;margin:0 0 6px">' + esc(T.channelTitle || 'عنوان کانال') + ': <strong>' + esc(data.meta.title) + '</strong> · ' +
                esc(T.itemsFound || 'آیتم‌های یافت‌شده') + ': ' + faNum(data.totalItems) + '</p>' +
                (items ? '<ul class="fag-test-list">' + items + '</ul>' : '') +
                '</div>';
        }).catch(function () { toast(T.requestFailed, 'error'); });
    }

    // رویدادهای جدول خوراک‌ها
    var feedsTable = $('#fag-feeds-tbody');
    if (feedsTable) {
        feedsTable.addEventListener('click', function (event) {
            var btn = event.target.closest('[data-act]');
            if (!btn) { return; }

            var act = btn.getAttribute('data-act');
            var id = +btn.getAttribute('data-id');
            var feed = feedsCache.filter(function (f) { return f.id === id; })[0];

            if (act === 'edit') {
                openModal(T.editFeedTitle || 'ویرایش خوراک', feedForm(feed));
                var form = $('#fag-feed-form');
                form.setAttribute('data-id', id);
                form.addEventListener('submit', function (e) { e.preventDefault(); saveFeedFromForm(); });
            }

            if (act === 'toggle') {
                busy(btn, true);
                api('toggle-feed', { id: id }).then(function () {
                    loadFeeds();
                    refreshStatus();
                }).catch(function () { busy(btn, false); });
            }

            if (act === 'fetch') {
                busy(btn, true);
                api('fetch-feed', { id: id }).then(function (response) {
                    toast(response.msg, response.ok ? 'ok' : 'error');
                    loadFeeds();
                    refreshStatus();
                }).catch(function () {
                    toast(T.requestFailed, 'error');
                    busy(btn, false);
                });
            }

            if (act === 'delete') {
                confirmModal(T.deleteConfirmTitle || 'حذف خوراک',
                    '«' + (feed ? feed.title : '') + '» ' + (T.confirmDelete || 'حذف شود؟ آیتم‌های کش این خوراک نیز پاک می‌شوند.'),
                    T.deleteFinal || 'حذف قطعی', function () {
                        api('delete-feed', { id: id }).then(function (response) {
                            toast(response.msg, response.ok ? 'ok' : 'error');
                            loadFeeds();
                            refreshStatus();
                        }).catch(function () { toast(T.requestFailed, 'error'); });
                    });
            }
        });
    }

    // دکمه افزودن خوراک
    var addBtn = $('#fag-add-feed');
    if (addBtn) {
        addBtn.addEventListener('click', function () {
            openModal(T.addFeedTitle || 'افزودن خوراک جدید', feedForm(null) + '<div id="fag-test-result"></div>');

            var form = $('#fag-feed-form');
            form.setAttribute('data-id', 0);
            form.addEventListener('submit', function (e) { e.preventDefault(); saveFeedFromForm(); });

            var testBtn = $('#fag-test-feed-btn');
            if (testBtn) {
                testBtn.addEventListener('click', function () {
                    var url = form.elements.url.value.trim();
                    if (!url) { form.elements.url.focus(); return; }
                    testBtn.disabled = true;
                    testFeedUrl(url);
                    setTimeout(function () { testBtn.disabled = false; }, 4000);
                });
            }
        });
    }

    // -------------------------------------------------------------------------
    // آیتم‌ها
    // -------------------------------------------------------------------------

    var itemsState = { page: 1, pages: 1 };

    function renderItems(response) {
        var tbody = $('#fag-items-tbody');
        var pagination = $('#fag-pagination');
        if (!tbody) { return; }

        itemsState.page = response.page || 1;
        itemsState.pages = response.pages || 1;

        var items = response.data || [];

        if (!items.length) {
            tbody.innerHTML = '<tr><td colspan="5" class="fag-muted fag-center">' + esc(T.itemsTabEmpty || 'موردی یافت نشد.') + '</td></tr>';
            if (pagination) { pagination.innerHTML = ''; }
            return;
        }

        tbody.innerHTML = items.map(function (item) {
            var postCell = item.postId > 0
                ? '<span class="fag-badge fag-badge-green">' + ic('check', 11) + ' ' + esc(T.savedLabel || 'ثبت شد') + '</span>'
                : '<span class="fag-badge">—</span>';

            return '<tr>' +
                '<td class="fag-item-title-cell">' +
                (item.url ? '<a href="' + esc(item.url) + '" target="_blank" rel="noopener" title="' + esc(item.title) + '">' + esc(item.title) + '</a>' : esc(item.title)) +
                '</td>' +
                '<td>' + esc(item.feedTitle) + '</td>' +
                '<td>' + esc(item.postedAt) + '</td>' +
                '<td>' + postCell + '</td>' +
                '<td><div class="fag-row-actions">' +
                '<button type="button" class="btn btn-s fag-btn-danger" data-act="delete-item" data-id="' + item.id + '">' + ic('trash', 12) + '</button>' +
                '</div></td>' +
                '</tr>';
        }).join('');

        if (pagination) {
            if (itemsState.pages <= 1) {
                pagination.innerHTML = '<span>' + faNum(response.total) + ' ' + esc(T.resultsCount || 'مورد') + '</span>';
            } else {
                pagination.innerHTML =
                    '<button type="button" data-page="' + (itemsState.page - 1) + '"' + (itemsState.page <= 1 ? ' disabled' : '') + '>' + esc(T.prev || 'قبلی') + '</button>' +
                    '<span>' + (T.page || 'صفحه') + ' ' + faNum(itemsState.page) + ' ' + (T.of || 'از') + ' ' + faNum(itemsState.pages) + ' · ' + faNum(response.total) + ' ' + esc(T.resultsCount || 'مورد') + '</span>' +
                    '<button type="button" data-page="' + (itemsState.page + 1) + '"' + (itemsState.page >= itemsState.pages ? ' disabled' : '') + '>' + esc(T.next || 'بعدی') + '</button>';
            }
        }
    }

    function loadItems(page) {
        api('items', {
            page: page || 1,
            perPage: 15,
            feedId: ($('#fag-filter-feed') || {}).value || 0,
            categoryId: ($('#fag-filter-cat') || {}).value || 0,
            search: (($('#fag-filter-search') || {}).value || '').trim()
        }).then(function (response) {
            if (response.ok) { renderItems(response); }
        }).catch(function () { toast(T.requestFailed, 'error'); });
    }

    // پر کردن فیلترها
    function fillFilters() {
        var feedFilter = $('#fag-filter-feed');
        var catFilter = $('#fag-filter-cat');

        if (feedFilter) {
            api('feeds').then(function (response) {
                if (!response.ok) { return; }
                var current = feedFilter.value;
                feedFilter.innerHTML = '<option value="0">' + esc(T.allFeeds || 'همه خوراک‌ها') + '</option>' +
                    (response.data || []).map(function (f) {
                        return '<option value="' + f.id + '">' + esc(f.title) + '</option>';
                    }).join('');
                feedFilter.value = current;
            }).catch(function () { });
        }

        if (catFilter) {
            catFilter.innerHTML = '<option value="0">' + esc(T.allCategories || 'همه دسته‌ها') + '</option>' +
                (BOOT.categories || []).map(function (cat) {
                    return '<option value="' + cat.id + '">' + esc(cat.label) + '</option>';
                }).join('');
        }
    }

    var itemsSection = $('.fag-panel .tr-panel-pane[data-tab="items"]');
    if (itemsSection) {
        itemsSection.addEventListener('click', function (event) {
            var pageBtn = event.target.closest('[data-page]');
            if (pageBtn && !pageBtn.disabled) {
                loadItems(+pageBtn.getAttribute('data-page'));
            }

            var delBtn = event.target.closest('[data-act="delete-item"]');
            if (delBtn) {
                var id = +delBtn.getAttribute('data-id');
                api('delete-item', { id: id }).then(function (response) {
                    toast(response.msg, response.ok ? 'ok' : 'error');
                    loadItems(itemsState.page);
                    refreshStatus();
                }).catch(function () { toast(T.requestFailed, 'error'); });
            }
        });

        var applyBtn = $('#fag-apply-filters');
        if (applyBtn) { applyBtn.addEventListener('click', function () { loadItems(1); }); }

        var searchInput = $('#fag-filter-search');
        if (searchInput) {
            searchInput.addEventListener('keydown', function (e) {
                if (e.key === 'Enter') { loadItems(1); }
            });
        }
    }

    // -------------------------------------------------------------------------
    // تنظیمات
    // -------------------------------------------------------------------------

    function fillSettings() {
        var s = BOOT.settings || {};

        var interval = $('#fag-set-interval');
        if (interval) { interval.value = s.update_interval || 60; }

        var lazy = $('#fag-set-lazy');
        if (lazy) { lazy.checked = s.lazy_update === '1'; }

        var timeout = $('#fag-set-timeout');
        if (timeout) { timeout.value = s.fetch_timeout || 15; }

        var cron = $('#fag-set-cron');
        if (cron) { cron.checked = s.cron_enabled === '1'; }

        var purge = $('#fag-set-purge');
        if (purge) { purge.value = s.purge_days != null ? s.purge_days : 30; }

        var max = $('#fag-set-max');
        if (max) { max.value = s.default_max_items || 50; }

        var mode = $('#fag-set-mode');
        if (mode) { mode.value = s.default_mode || 'cache'; }

        var status = $('#fag-set-status');
        if (status) { status.value = s.default_post_status || 'publish'; }

        var source = $('#fag-set-source');
        if (source) { source.checked = s.show_source_link !== '0'; }

        updateCronBox();
    }

    function updateCronBox() {
        var box = $('#fag-cron-url-box');
        var urlEl = $('#fag-cron-url');
        var enabled = ($('#fag-set-cron') || {}).checked;

        if (box) { box.hidden = !enabled; }

        if (urlEl && BOOT.cronUrl) {
            urlEl.textContent = BOOT.cronUrl;
        }
    }

    var settingsForm = $('#fag-settings-form');
    if (settingsForm) {
        settingsForm.addEventListener('submit', function (event) {
            event.preventDefault();

            var data = {
                update_interval: $('#fag-set-interval').value,
                lazy_update: $('#fag-set-lazy').checked ? '1' : '0',
                fetch_timeout: $('#fag-set-timeout').value,
                cron_enabled: $('#fag-set-cron').checked ? '1' : '0',
                purge_days: $('#fag-set-purge').value,
                default_max_items: $('#fag-set-max').value,
                default_mode: $('#fag-set-mode').value,
                default_post_status: $('#fag-set-status').value,
                show_source_link: $('#fag-set-source').checked ? '1' : '0'
            };

            var btn = $('#fag-save-settings');
            busy(btn, true);

            api('save-settings', data).then(function (response) {
                toast(response.msg, response.ok ? 'ok' : 'error');
                refreshStatus();
            }).catch(function () {
                toast(T.requestFailed, 'error');
            }).finally(function () { busy(btn, false); });
        });

        var cronToggle = $('#fag-set-cron');
        if (cronToggle) { cronToggle.addEventListener('change', updateCronBox); }

        // کپی نشانی کرون
        var copyBtn = $('#fag-copy-cron');
        if (copyBtn) {
            copyBtn.addEventListener('click', function () {
                var text = $('#fag-cron-url').textContent;
                if (navigator.clipboard && text) {
                    navigator.clipboard.writeText(text).then(function () {
                        toast(T.copied || 'کپی شد!', 'ok');
                    }).catch(function () { });
                }
            });
        }

        // تولید کلید جدید
        var regenBtn = $('#fag-regen-secret');
        if (regenBtn) {
            regenBtn.addEventListener('click', function () {
                busy(regenBtn, true);
                api('regen-secret').then(function (response) {
                    if (response.ok) {
                        BOOT.cronUrl = response.url;
                        BOOT.settings.cron_secret = response.secret;
                        updateCronBox();
                        toast(response.msg, 'ok');
                    } else {
                        toast(response.msg, 'error');
                    }
                }).catch(function () { toast(T.requestFailed, 'error'); })
                    .finally(function () { busy(regenBtn, false); });
            });
        }

        // خالی کردن کش
        var clearBtn = $('#fag-clear-cache');
        if (clearBtn) {
            clearBtn.addEventListener('click', function () {
                confirmModal(T.clearCacheTitle || 'خالی کردن کش',
                    T.confirmClearCache || 'تمام آیتم‌های کش حذف شوند؟ خوراک‌ها و تنظیمات دست‌نخورده می‌مانند.',
                    T.clearCacheDo || 'خالی کن', function () {
                        busy(clearBtn, true);
                        api('clear-cache').then(function (response) {
                            toast(response.msg, response.ok ? 'ok' : 'error');
                            refreshStatus();
                        }).catch(function () { toast(T.requestFailed, 'error'); })
                            .finally(function () { busy(clearBtn, false); });
                    });
            });
        }

        // حذف کامل داده‌ها
        var wipeBtn = $('#fag-wipe');
        if (wipeBtn) {
            wipeBtn.addEventListener('click', function () {
                var extra = '<div class="fag-field" style="margin-top:12px"><label>' + esc(T.typeToConfirm || 'برای تأیید عبارت زیر را بنویسید:') + '</label>' +
                    '<code class="fag-code" style="display:block;margin-bottom:8px">' + esc(T.wipePhrase) + '</code>' +
                    '<input type="text" data-phrase="' + esc(T.wipePhrase) + '" dir="ltr" style="text-align:left" placeholder="' + esc(T.wipePhrase) + '"></div>';

                confirmModal(T.wipeTitle || 'حذف کامل داده‌ها',
                    T.confirmWipe || 'همه داده‌های افزونه برای همیشه حذف می‌شوند. نوشته‌های واردشده در سایت باقی می‌مانند.',
                    T.wipeDo || 'حذف همه چیز', function () {
                        busy(wipeBtn, true);
                        api('wipe', { confirm: T.wipePhrase }).then(function (response) {
                            toast(response.msg, response.ok ? 'ok' : 'error');
                            if (response.ok) {
                                setTimeout(function () { window.location.reload(); }, 1600);
                            }
                        }).catch(function () { toast(T.requestFailed, 'error'); })
                            .finally(function () { busy(wipeBtn, false); });
                    }, extra);
            });
        }
    }

    // -------------------------------------------------------------------------
    // راه‌اندازی
    // -------------------------------------------------------------------------

    function init() {
        fillFilters();
        fillSettings();
        refreshStatus();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
