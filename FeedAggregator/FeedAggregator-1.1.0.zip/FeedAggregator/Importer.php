<?php
/**
 * واردکننده مطالب خوراک به‌صورت نوشته واقعی TypeRenew
 *
 * در حالت «post» هر آیتم جدید خوراک به یک نوشته واقعی در دسته‌بندی
 * متصل تبدیل می‌شود. این کلاس مسئول درج امن ردیف محتوا، اتصال به
 * دسته‌بندی، درج فیلد تصویر شاخص (برای پوسته‌هایی که پشتیبانی
 * می‌کنند) و جلوگیری از ثبت نوشته تکراری است.
 *
 * @package FeedAggregator
 */
namespace TypechoPlugin\FeedAggregator;

use Typecho\Db;
use TypechoPlugin\FeedAggregator\Repo\ItemRepo;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Importer
{
    /**
     * وارد کردن یک آیتم کش‌شده به‌عنوان نوشته
     *
     * @param int                 $itemId شناسه آیتم در جدول کش
     * @param array<string, mixed> $feed   سطر خوراک
     * @param array<string, mixed> $item   داده‌های آیتم
     * @return int|null شناسه نوشته ساخته‌شده یا null در صورت رد شدن
     */
    public static function import(int $itemId, array $feed, array $item): ?int
    {
        $db = Db::get();

        // اگر قبلاً برای این آیتم نوشته‌ای ساخته شده است
        if (!empty($item['postId'])) {
            return null;
        }

        // جلوگیری از ساخت نوشته تکراری — حتی اگر کش آیتم‌ها پاک شده باشد،
        // شناسه یکتا (fag_uid) به‌صورت فیلد سفارشی روی خود نوشته ذخیره شده
        // و پیش از درج جدید بررسی می‌شود
        $uid = (string) ($item['uid'] ?? '');

        if ($uid !== '') {
            $existing = $db->fetchRow(
                $db->select('cid')->from('table.fields')
                    ->where('name = ? AND str_value = ?', 'fag_uid', $uid)
                    ->limit(1)
            );

            if (!empty($existing)) {
                // نوشته قبلاً ساخته شده؛ فقط ارتباط آیتم کش ثبت می‌شود
                ItemRepo::linkPost($itemId, (int) $existing['cid']);
                return null;
            }
        }

        $title = trim((string) ($item['title'] ?? ''));

        if ($title === '') {
            $title = Util::makeExcerpt((string) ($item['content'] ?? ''), 80);

            if ($title === '') {
                return null;
            }
        }

        $now = time();

        // زمان انتشار از خود مطلب منبع گرفته می‌شود
        $created = (int) ($item['postedAt'] ?? 0);
        if ($created <= 0) {
            $created = $now;
        }

        // ساخت متن نوشته همراه با اشاره به منبع
        $text = self::buildText($item, $feed);

        // نامک یکتا بر اساس عنوان
        $slug = Util::uniqueSlug(Util::buildSlug($title, 'feed'));

        // اعتبارسنجی نویسنده
        $authorId = (int) ($feed['authorId'] ?? 1);
        $authorRow = $db->fetchRow(
            $db->select('uid')->from('table.users')->where('uid = ?', $authorId)->limit(1)
        );

        if (empty($authorRow)) {
            $authorId = 1;
        }

        $row = [
            'title'        => mb_substr($title, 0, 150, 'UTF-8'),
            'slug'         => $slug,
            'created'      => $created,
            'modified'     => $now,
            'text'         => $text,
            'authorId'     => $authorId,
            'type'         => 'post',
            'status'       => self::mapStatus((string) ($feed['postStatus'] ?? 'publish')),
            'commentsNum'  => 0,
            'allowComment' => 0,
            'allowPing'    => 0,
            'allowFeed'    => 1,
            'parent'       => 0,
            'order'        => 0,
        ];

        // پارامتر سوم Db::INSERT باعث می‌شود query شناسه نوشته جدید را برگرداند
        $postId = (int) $db->query($db->insert('table.contents')->rows($row), Db::WRITE, Db::INSERT);

        if ($postId <= 0) {
            return null;
        }

        // درج فیلدهای سفارشی: شناسه یکتا (برای جلوگیری از تکرار پس از پاک‌سازی
        // کش)، شناسه خوراک (برای حذف مطمئن نوشته‌ها هنگام حذف خوراک) و
        // تصویر شاخص (thumb برای پوسته‌هایی که پشتیبانی می‌کنند)
        $fields = [];

        if ($uid !== '') {
            $fields[] = ['name' => 'fag_uid', 'type' => 'str', 'value' => $uid];
        }

        $fields[] = ['name' => 'fag_feed', 'type' => 'str', 'value' => (string) ($feed['id'] ?? '')];

        if (!empty($item['image'])) {
            $fields[] = ['name' => 'thumb', 'type' => 'str', 'value' => (string) $item['image']];
        }

        foreach ($fields as $field) {
            try {
                $db->query(
                    $db->insert('table.fields')->rows([
                        'cid'        => $postId,
                        'name'       => $field['name'],
                        'type'       => $field['type'],
                        'str_value'  => $field['value'],
                        'int_value'  => 0,
                        'float_value' => 0,
                    ])
                );
            } catch (\Throwable $e) {
                // فیلد سفارشی افزونه‌ای است؛ شکست آن نقشی در جریان اصلی ندارد
            }
        }

        // اتصال به دسته‌بندی
        $categoryId = (int) ($feed['categoryId'] ?? 0);

        if ($categoryId > 0) {
            $meta = $db->fetchRow(
                $db->select('mid')->from('table.metas')
                    ->where('mid = ? AND type = ?', $categoryId, 'category')
                    ->limit(1)
            );

            if (!empty($meta)) {
                $db->query(
                    $db->insert('table.relationships')->rows(['cid' => $postId, 'mid' => $categoryId])
                );

                // به‌روزرسانی شمارنده دسته
                $db->query(
                    $db->update('table.metas')
                        ->expression('count', 'count + 1')
                        ->where('mid = ?', $categoryId)
                );
            }
        }

        // ثبت ارتباط آیتم با نوشته
        ItemRepo::linkPost($itemId, $postId);

        return $postId;
    }

    /**
     * ساخت متن نوشته با محتوای کامل و ارجاع به منبع
     *
     * @param array<string, mixed> $item داده‌های آیتم
     * @param array<string, mixed> $feed سطر خوراک
     * @return string
     */
    private static function buildText(array $item, array $feed): string
    {
        $content = (string) ($item['content'] ?? '');

        if ($content === '') {
            $content = '<p>' . Util::esc((string) ($item['excerpt'] ?? '')) . '</p>';
        }

        $showSource = Util::setting('show_source_link', '1') === '1';

        if ($showSource) {
            $sourceUrl = (string) ($item['url'] ?? '');
            $sourceName = (string) ($feed['title'] ?? '');

            if ($sourceName === '') {
                $sourceName = (string) ($item['author'] ?? '');
            }

            if ($sourceName === '') {
                $sourceName = I18n::t('Original source');
            }

            if ($sourceUrl !== '') {
                $source = '<p class="feed-aggregator-source">'
                    . I18n::t('Source') . ': <a href="' . Util::esc($sourceUrl)
                    . '" rel="nofollow noopener" target="_blank">' . Util::esc($sourceName) . '</a></p>';
            } else {
                $source = '<p class="feed-aggregator-source">' . I18n::t('Source') . ': ' . Util::esc($sourceName) . '</p>';
            }

            $content = rtrim($content) . "\n" . $source;
        }

        return $content;
    }

    /**
     * تطبیق وضعیت انتشار با وضعیت‌های معتبر TypeRenew
     *
     * @param string $status وضعیت درخواستی
     * @return string
     */
    private static function mapStatus(string $status): string
    {
        return match ($status) {
            'draft' => 'draft',
            'waiting' => 'waiting',
            'private' => 'private',
            default => 'publish',
        };
    }
}
