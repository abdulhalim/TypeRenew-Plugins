<?php
/**
 * پاک‌ساز HTML محتوای خوراک‌ها
 *
 * محتوای دریافتی از خوراک‌های RSS کاملاً «غیرقابل اعتماد» است؛ این
 * کلاس با استفاده از DOMDocument و فهرست سفید تگ‌ها/ویژگی‌ها، تمام
 * عناصر و کدهای خطرناک (script، استایل‌های درون‌خطی، رویدادهای on*
 * و نشانی‌های javascript:) را حذف می‌کند و خروجی امن برای نمایش در
 * سایت تولید می‌کند.
 *
 * @package FeedAggregator
 */
namespace TypechoPlugin\FeedAggregator;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Sanitizer
{
    /**
     * تگ‌های مجاز
     *
     * @var array<string, true>
     */
    private const ALLOWED_TAGS = [
        'p' => true, 'br' => true, 'hr' => true, 'a' => true,
        'h1' => true, 'h2' => true, 'h3' => true, 'h4' => true, 'h5' => true, 'h6' => true,
        'ul' => true, 'ol' => true, 'li' => true, 'blockquote' => true,
        'pre' => true, 'code' => true, 'em' => true, 'strong' => true,
        'b' => true, 'i' => true, 'u' => true, 's' => true, 'del' => true, 'ins' => true,
        'img' => true, 'figure' => true, 'figcaption' => true,
        'table' => true, 'thead' => true, 'tbody' => true, 'tr' => true, 'td' => true, 'th' => true,
        'span' => true, 'div' => true, 'small' => true, 'sub' => true, 'sup' => true,
        'dl' => true, 'dt' => true, 'dd' => true, 'abbr' => true, 'cite' => true, 'q' => true,
    ];

    /**
     * ویژگی‌های مجاز هر تگ
     *
     * @var array<string, array<string, true>>
     */
    private const ALLOWED_ATTRS = [
        'a' => ['href' => true, 'title' => true, 'target' => true],
        'img' => ['src' => true, 'alt' => true, 'title' => true, 'width' => true, 'height' => true, 'loading' => true],
        'td' => ['colspan' => true, 'rowspan' => true],
        'th' => ['colspan' => true, 'rowspan' => true],
        'ol' => ['start' => true],
        'abbr' => ['title' => true],
        'q' => ['cite' => true],
        'blockquote' => ['cite' => true],
    ];

    /**
     * حداکثر طول محتوای پاک‌شده (کاراکتر) برای جلوگیری از انفجار حجم
     *
     * @var int
     */
    private const MAX_CONTENT_LENGTH = 200000;

    /**
     * پاک‌سازی یک قطعه HTML
     *
     * @param string $html   محتوای ورودی
     * @param string $baseUrl نشانی پایه برای تبدیل لینک‌های نسبی
     * @return string HTML امن
     */
    public static function clean(string $html, string $baseUrl = ''): string
    {
        $html = trim($html);

        if ($html === '') {
            return '';
        }

        // محتوای متنی ساده (بدون هیچ تگی) بدون تغییر اعتبار می‌شود
        if (strip_tags($html) === $html) {
            return Util::cleanText($html);
        }

        $dom = new \DOMDocument();

        $useErrors = libxml_use_internal_errors(true);

        // بارگذاری با پوشش یونیکد؛ کاراکتر یونیکد مرزی تزریق می‌شود تا
        // DOMDocument ورودی را UTF-8 تفسیر کند
        $loaded = @$dom->loadHTML(
            '<?xml encoding="UTF-8"?><div id="fag-root">' . $html . '</div>',
            LIBXML_NOWARNING | LIBXML_NOERROR | LIBXML_NONET
        );

        libxml_clear_errors();
        libxml_use_internal_errors($useErrors);

        if (!$loaded) {
            // در صورت خرابی کامل XML، فقط متن خالص برگردانده می‌شود
            return Util::cleanText(strip_tags($html));
        }

        $root = $dom->getElementById('fag-root');

        if ($root === null && $dom->documentElement !== null) {
            $root = $dom->documentElement;
        }

        if ($root === null) {
            return '';
        }

        self::walk($root, $baseUrl);

        // استخراج HTML داخلی ریشه
        $out = '';
        foreach ($root->childNodes as $child) {
            $out .= $dom->saveHTML($child);
        }

        $out = Util::cleanText($out);

        if (mb_strlen($out, 'UTF-8') > self::MAX_CONTENT_LENGTH) {
            $out = mb_substr($out, 0, self::MAX_CONTENT_LENGTH, 'UTF-8');
        }

        return trim($out);
    }

    /**
     * پیمایش بازگشتی گره‌ها و اعمال قوانین فهرست سفید
     *
     * @param \DOMNode $node    گره جاری
     * @param string   $baseUrl نشانی پایه
     * @return void
     */
    private static function walk(\DOMNode $node, string $baseUrl): void
    {
        // حذف ایمن گره‌های نامعتبر (از انتها به ابتدا حرکت می‌کنیم)
        $children = [];
        foreach ($node->childNodes as $child) {
            $children[] = $child;
        }

        foreach ($children as $child) {
            if ($child instanceof \DOMElement) {
                $tag = strtolower($child->tagName);

                if (!isset(self::ALLOWED_TAGS[$tag])) {
                    // جایگزینی عنصر مجاز نیست با محتوایش یا حذف کامل
                    if (in_array($tag, ['script', 'style', 'iframe', 'object', 'embed', 'noscript', 'template', 'link', 'meta', 'base', 'form', 'input', 'button', 'select', 'textarea', 'video', 'audio', 'source', 'track', 'canvas', 'svg', 'math'], true)) {
                        // عناصر خطرناک همراه با محتوایشان حذف می‌شوند
                        $node->removeChild($child);
                        continue;
                    }

                    // عناصر خنثی (مثل section/article) با محتوایشان باز می‌شوند
                    self::unwrap($node, $child);
                    continue;
                }

                self::cleanAttributes($child, $tag, $baseUrl);
                self::walk($child, $baseUrl);
            } elseif ($child->nodeType === XML_COMMENT_NODE) {
                $node->removeChild($child);
            } elseif ($child->nodeType === XML_TEXT_NODE) {
                // متن‌ها به حال خود رها می‌شوند (saveHTML فرار لازم را انجام می‌دهد)
                continue;
            } else {
                $node->removeChild($child);
            }
        }
    }

    /**
     * باز کردن یک عنصر و جایگزینی آن با فرزندانش
     *
     * @param \DOMNode     $parent والد
     * @param \DOMElement  $element عنصر نامعتبر
     * @return void
     */
    private static function unwrap(\DOMNode $parent, \DOMElement $element): void
    {
        while ($element->firstChild !== null) {
            $parent->insertBefore($element->firstChild, $element);
        }

        $parent->removeChild($element);
    }

    /**
     * پاک‌سازی ویژگی‌های یک عنصر مجاز
     *
     * @param \DOMElement $element عنصر
     * @param string      $tag     نام تگ
     * @param string      $baseUrl نشانی پایه
     * @return void
     */
    private static function cleanAttributes(\DOMElement $element, string $tag, string $baseUrl): void
    {
        $allowed = self::ALLOWED_ATTRS[$tag] ?? [];

        $attrs = [];
        foreach ($element->attributes as $attr) {
            $attrs[] = $attr->name;
        }

        foreach ($attrs as $name) {
            $nameLower = strtolower($name);
            $value = (string) $element->getAttribute($name);

            // حذف ویژگی‌های رویدادی (onclick و مشابه) و ویژگی‌های خارج از فهرست
            if (!isset($allowed[$nameLower])) {
                $element->removeAttribute($name);
                continue;
            }

            // بررسی امنیت نشانی‌ها در ویژگی‌های لینک/منبع
            if (in_array($nameLower, ['href', 'src', 'cite'], true)) {
                $clean = self::safeUrl($value, $baseUrl, $nameLower === 'src');
                if ($clean === null) {
                    $element->removeAttribute($name);
                    continue;
                }
                $element->setAttribute($name, $clean);
            }
        }

        // افزودن rel امن به لینک‌های خارجی
        if ($tag === 'a' && $element->getAttribute('href') !== '') {
            $element->setAttribute('rel', 'nofollow noopener');
            if ($element->getAttribute('target') === '') {
                $element->setAttribute('target', '_blank');
            }
        }

        // بارگذاری تنبل تصاویر
        if ($tag === 'img') {
            $element->setAttribute('loading', 'lazy');
            $element->setAttribute('decoding', 'async');
            if ($element->getAttribute('alt') === '') {
                $element->setAttribute('alt', '');
            }
        }
    }

    /**
     * اعتبارسنجی و نرمال‌سازی یک نشانی
     *
     * @param string $value   نشانی ورودی
     * @param string $baseUrl نشانی پایه
     * @param bool   $isImage آیا نشانی تصویر است؟ (data:image مجاز است)
     * @return string|null نشانی امن یا null
     */
    private static function safeUrl(string $value, string $baseUrl, bool $isImage): bool|string|null
    {
        $value = trim($value);

        if ($value === '' || strcasecmp($value, 'javascript:') === 0) {
            return null;
        }

        $lower = strtolower($value);

        // نشانی‌های طرح‌های خطرناک حذف می‌شوند
        if (preg_match('#^\s*(javascript|vbscript|data|file|about|blob)\s*:#i', $value)) {
            // تنها استثنا: تصاویر کوچک درون‌خطی data:image
            if ($isImage && preg_match('#^data:image/(png|jpe?g|gif|webp|avif);base64,#i', $value)) {
                return $value;
            }
            return null;
        }

        // لینک‌های نسبی نسبت به خوراک مبدأ کامل می‌شوند
        $isAbsolute = (bool) preg_match('#^https?://#i', $value);
        $isSchemeRelative = strpos($value, '//') === 0;
        $isAnchor = ($value !== '' && $value[0] === '#') || strcasecmp($value, 'mailto:') === 0;

        if ($baseUrl !== '' && !$isAbsolute && !$isSchemeRelative && !$isAnchor) {
            if ($value[0] === '/') {
                $parts = parse_url($baseUrl);
                if (!empty($parts['scheme']) && !empty($parts['host'])) {
                    $value = $parts['scheme'] . '://' . $parts['host'] . (isset($parts['port']) ? ':' . $parts['port'] : '') . $value;
                }
            } else {
                $value = rtrim($baseUrl, '/') . '/' . ltrim($value, '/');
            }
        }

        return Util::cleanText($value);
    }
}
