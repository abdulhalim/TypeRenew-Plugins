<?php
/**
 * ابزارهای مشترک افزونه تجمیع‌کننده خوراک
 *
 * شامل توابع کمکی عمومی: خواندن تنظیمات با مقادیر پیش‌فرض ایمن،
 * مدیریت وضعیت اجرایی (قفل و آمار)، تبدیل اعداد به فارسی، نرمال‌سازی
 * نشانی‌ها و تولید خلاصه متن.
 *
 * @package FeedAggregator
 */
namespace TypechoPlugin\FeedAggregator;

use Typecho\Db;
use Widget\Options;
use Utils\Helper;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Util
{
    /**
     * نام سطر وضعیت در جدول options
     */
    public const STATE_OPTION = 'feedAggregatorState';

    /**
     * مقادیر پیش‌فرض تنظیمات افزونه
     *
     * این مقادیر هنگام فعال‌سازی در کانفیگ افزونه نوشته می‌شوند و هر
     * جا تنظیمی ذخیره نشده باشد، همین پیش‌فرض‌ها به کار می‌روند.
     *
     * @var array<string, mixed>
     */
    public const DEFAULT_SETTINGS = [
        'update_interval'    => 60,      // فاصله به‌روزرسانی خودکار (دقیقه)
        'lazy_update'        => '1',     // به‌روزرسانی تنبل هنگام بازدید
        'cron_enabled'       => '0',     // endpoint کرون فعال باشد؟
        'cron_secret'        => '',      // کلید مخفی کرون
        'fetch_timeout'      => 15,      // مهلت دریافت هر خوراک (ثانیه)
        'purge_days'         => 30,      // حذف آیتم‌های قدیمی‌تر از این تعداد روز (۰ = هرگز)
        'default_mode'       => 'cache', // حالت پیش‌فرض خوراک جدید: cache یا post
        'default_post_status' => 'publish', // وضعیت پیش‌فرض نوشته‌های واردشده
        'default_max_items'  => 50,      // حد نگهداری آیتم در کش برای هر خوراک
        'show_source_link'   => '1',     // درج لینک منبع در انتهای نوشته واردشده
    ];

    /**
     * کش درون‌درخواستی تنظیمات
     *
     * @var array<string, mixed>|null
     */
    private static ?array $settingsCache = null;

    /**
     * خواندن تنظیمات افزونه به‌همراه پیش‌فرض‌ها
     *
     * خواندن مستقیم از options->plugin() در صورت نبودِ کانفیگ خطا
     * می‌دهد؛ این متد خطا را مهار کرده و پیش‌فرض‌ها را برمی‌گرداند تا
     * افزونه بلافاصله پس از فعال‌سازی هم کار کند.
     *
     * @return array<string, mixed>
     */
    public static function settings(): array
    {
        if (self::$settingsCache !== null) {
            return self::$settingsCache;
        }

        $stored = [];
        try {
            $config = Options::alloc()->plugin('FeedAggregator');
            $stored = $config instanceof \Typecho\Config ? $config->toArray() : (array) $config;
        } catch (\Throwable $e) {
            $stored = [];
        }

        $settings = array_merge(self::DEFAULT_SETTINGS, is_array($stored) ? $stored : []);

        // اعمال محدوده‌های امن روی مقادیر عددی
        $settings['update_interval'] = max(5, (int) $settings['update_interval']);
        $settings['fetch_timeout'] = min(60, max(3, (int) $settings['fetch_timeout']));
        $settings['purge_days'] = max(0, (int) $settings['purge_days']);
        $settings['default_max_items'] = min(500, max(1, (int) $settings['default_max_items']));

        if (!in_array($settings['default_mode'], ['cache', 'post'], true)) {
            $settings['default_mode'] = 'cache';
        }

        if (!in_array($settings['default_post_status'], ['publish', 'draft', 'waiting', 'private'], true)) {
            $settings['default_post_status'] = 'publish';
        }

        self::$settingsCache = $settings;
        return $settings;
    }

    /**
     * مقدار تک‌تک تنظیمات
     *
     * @param string $key نام تنظیم
     * @param mixed  $default مقدار جایگزین
     * @return mixed
     */
    public static function setting(string $key, $default = null)
    {
        $settings = self::settings();
        return array_key_exists($key, $settings) ? $settings[$key] : $default;
    }

    /**
     * باطل‌کردن کش تنظیمات درون‌درخواستی (پس از ذخیره تنظیمات)
     *
     * @return void
     */
    public static function flushSettingsCache(): void
    {
        self::$settingsCache = null;
    }

    /**
     * ذخیره تنظیمات افزونه (با merge روی مقادیر فعلی)
     *
     * @param array<string, mixed> $settings تنظیمات جدید
     * @return void
     */
    public static function saveSettings(array $settings): void
    {
        $current = self::settings();

        // فقط کلیدهای شناخته‌شده پذیرفته می‌شوند
        $clean = [];
        foreach (self::DEFAULT_SETTINGS as $key => $unused) {
            if (array_key_exists($key, $settings)) {
                $clean[$key] = $settings[$key];
            }
        }

        Helper::configPlugin('FeedAggregator', array_merge($current, $clean));
        self::flushSettingsCache();
    }

    /**
     * خواندن وضعیت اجرایی افزونه (قفل، آخرین اجرا، آمار)
     *
     * @return array<string, mixed>
     */
    public static function state(): array
    {
        $raw = null;
        try {
            $raw = Options::alloc()->{self::STATE_OPTION};
        } catch (\Throwable $e) {
            $raw = null;
        }

        $state = [];
        if (is_string($raw) && $raw !== '') {
            $decoded = json_decode($raw, true);
            $state = is_array($decoded) ? $decoded : [];
        } elseif (is_array($raw)) {
            $state = $raw;
        }

        return array_merge([
            'lockUntil' => 0,
            'lastRun'   => 0,
            'lastStats' => [],
        ], $state);
    }

    /**
     * ذخیره وضعیت اجرایی
     *
     * @param array<string, mixed> $state وضعیت جدید
     * @return void
     */
    public static function saveState(array $state): void
    {
        Helper::setOption(self::STATE_OPTION, $state);
    }

    /**
     * آیا فرآیند به‌روزرسانی در حال اجراست (قفل فعال)؟
     *
     * @return bool
     */
    public static function isLocked(): bool
    {
        $state = self::state();
        return (int) $state['lockUntil'] > time();
    }

    /**
     * تبدیل اعداد لاتین یک رشته به اعداد فارسی
     *
     * @param string|int|float|null $text متن ورودی
     * @return string
     */
    public static function faNum($text): string
    {
        return strtr((string) $text, [
            '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
            '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
        ]);
    }

    /**
     * فرار امن کاراکترهای ویژه HTML
     *
     * @param string|null $text متن ورودی
     * @return string
     */
    public static function esc(?string $text): string
    {
        return htmlspecialchars((string) $text, ENT_QUOTES, 'UTF-8');
    }

    /**
     * اعتبارسنجی نشانی خوراک
     *
     * فقط http و https پذیرفته می‌شود و نشانی‌های داخل شبکه محلی
     * (برای کاهش خطر SSRF) رد می‌شوند.
     *
     * @param string $url نشانی ورودی
     * @return string|false نشانی تمیز یا false در صورت نامعتبر بودن
     */
    public static function validateFeedUrl(string $url)
    {
        $url = trim($url);

        if ($url === '' || strlen($url) > 480) {
            return false;
        }

        $parts = @parse_url($url);
        if ($parts === false || empty($parts['scheme']) || empty($parts['host'])) {
            return false;
        }

        $scheme = strtolower($parts['scheme']);
        if (!in_array($scheme, ['http', 'https'], true)) {
            return false;
        }

        $host = strtolower($parts['host']);

        // جلوگیری از درخواست به میزبان‌های محلی و آی‌پی‌های خصوصی
        $blockedNames = ['localhost', '127.0.0.1', '0.0.0.0', '[::1]', 'metadata.google.internal'];
        if (in_array($host, $blockedNames, true) || substr($host, -6) === '.local' || substr($host, -6) === '.inner' || substr($host, -5) === '.arpa') {
            return false;
        }

        if (filter_var($host, FILTER_VALIDATE_IP)) {
            $long = ip2long($host);
            if ($long !== false &&
                (($long & 0xFF000000) >> 24 === 10 ||              // 10.0.0.0/8
                ($long & 0xFFF00000) >> 20 === 0xAC1 ||            // 172.16.0.0/12
                ($long & 0xFFFF0000) >> 16 === 0xC0A8 ||           // 192.168.0.0/16
                ($long & 0xFFFF0000) >> 16 === 0xA9FE)) {          // 169.254.0.0/16
                return false;
            }
        }

        return $scheme . '://' . $parts['host']
            . (isset($parts['port']) ? ':' . (int) $parts['port'] : '')
            . (isset($parts['path']) ? $parts['path'] : '/')
            . (isset($parts['query']) ? '?' . $parts['query'] : '');
    }

    /**
     * نرمال‌سازی نشانی برای مقایسه و تولید شناسه یکتا
     *
     * @param string $url نشانی ورودی
     * @return string
     */
    public static function normalizeUrl(string $url): string
    {
        $url = trim($url);
        $parts = @parse_url($url);
        if ($parts === false || empty($parts['host'])) {
            return rtrim($url, '/');
        }

        $scheme = strtolower($parts['scheme'] ?? 'http');
        $host = strtolower($parts['host']);
        $path = isset($parts['path']) ? rtrim($parts['path'], '/') : '';
        $query = isset($parts['query']) ? '?' . $parts['query'] : '';

        // حذف پارامترهای ردیاب رایج
        if ($query !== '') {
            parse_str($parts['query'], $params);
            foreach (array_keys($params) as $name) {
                if (in_array($name, ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'fbclid', 'gclid'], true)) {
                    unset($params[$name]);
                }
            }
            $query = empty($params) ? '' : '?' . http_build_query($params);
        }

        return $scheme . '://' . $host . $path . $query;
    }

    /**
     * تولید شناسه یکتای آیتم (برای جلوگیری از ثبت تکراری)
     *
     * اولویت: لینک نرمال‌شده، سپس guid، سپس عنوان
     *
     * @param string      $link  لینک آیتم
     * @param string      $guid  شناسه خوراک
     * @param string      $title عنوان آیتم
     * @return string هش ۴۰ کاراکتری
     */
    public static function itemUid(string $link, string $guid, string $title): string
    {
        $base = $link !== '' ? self::normalizeUrl($link) : '';
        if ($base === '') {
            $base = $guid !== '' ? self::normalizeUrl($guid) : '';
        }
        if ($base === '') {
            $base = trim($title);
        }

        return sha1(mb_strtolower($base, 'UTF-8'));
    }

    /**
     * تولید خلاصه متنی از HTML
     *
     * @param string $html   محتوای HTML
     * @param int    $length حداکثر طول (کاراکتر)
     * @return string
     */
    public static function makeExcerpt(string $html, int $length = 220): string
    {
        $text = html_entity_decode(strip_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = preg_replace('/\s+/u', ' ', $text) ?? '';
        $text = trim($text);

        if (mb_strlen($text, 'UTF-8') > $length) {
            $cut = mb_substr($text, 0, $length, 'UTF-8');
            $space = mb_strrpos($cut, ' ', 0, 'UTF-8');
            $text = ($space !== false && $space > (int) ($length * 0.6)) ? mb_substr($cut, 0, $space, 'UTF-8') : $cut;
            $text .= '…';
        }

        return $text;
    }

    /**
     * حذف کاراکترهای کنترلی نامعتبر از متن
     *
     * @param string $text متن ورودی
     * @return string
     */
    public static function cleanText(string $text): string
    {
        // حذف BOM و کاراکترهای کنترلی به‌جز خط جدید و تب
        $text = str_replace("\xEF\xBB\xBF", '', $text);
        return preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $text) ?? $text;
    }

    /**
     * تولید یک شناسه یکتا برای slug نوشته
     *
     * @param string $seed دانه اولیه (عنوان یا هش)
     * @param string $fallback مقدار جایگزین
     * @return string
     */
    public static function buildSlug(string $seed, string $fallback = 'feed-item'): string
    {
        // تبدیل فاصله‌ها به خط تیره و حذف کاراکترهای نامناسب
        // (\p{Arabic} حروف فارسی را هم پوشش می‌دهد)
        $slug = trim($seed);
        $slug = preg_replace('/[\s\x{200c}]+/u', '-', $slug) ?? '';
        $slug = preg_replace('/[^0-9a-zA-Z\p{Arabic}\-_.]/u', '', $slug) ?? '';
        $slug = trim($slug, '-._');

        if ($slug === '' || mb_strlen($slug, 'UTF-8') < 2) {
            $slug = $fallback . '-' . substr(bin2hex(random_bytes(4)), 0, 6);
        }

        return mb_substr($slug, 0, 120, 'UTF-8');
    }

    /**
     * بررسی یکتا بودن slug در جدول محتواها
     *
     * @param string   $slug   نامک پیشنهادی
     * @param int|null $exceptCid شناسه نوشته که باید نادیده گرفته شود
     * @return string نامک یکتا (در صورت تکرار با پسوند عددی برگردانده می‌شود)
     */
    public static function uniqueSlug(string $slug, ?int $exceptCid = null): string
    {
        $db = Db::get();
        $base = $slug;
        $i = 2;

        while (true) {
            $select = $db->select('cid')
                ->from('table.contents')
                ->where('slug = ?', $slug)
                ->limit(1);

            if ($exceptCid !== null) {
                $select->where('cid <> ?', $exceptCid);
            }

            $row = $db->fetchRow($select);

            if (empty($row)) {
                return $slug;
            }

            $slug = $base . '-' . $i;
            $i++;

            if ($i > 200) {
                return $base . '-' . substr(bin2hex(random_bytes(4)), 0, 8);
            }
        }
    }

    /**
     * آدرس endpoint اکشن افزونه
     *
     * @return string
     */
    public static function actionUrl(): string
    {
        $options = Options::alloc();
        return \Typecho\Router::url('do', ['action' => 'feed-aggregator'], $options->index);
    }
}
