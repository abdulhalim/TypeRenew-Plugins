<?php
/**
 * نقطه پایانی اکشن افزونه (AJAX مدیریت + کرون + پین به‌روزرسانی)
 *
 * این کلاس از طریق مسیر /action/feed-aggregator در دسترس است و سه گروه
 * عملیات را ارائه می‌دهد:
 *
 * ۱. عمومی:
 *    do=ping              پین به‌روزرسانی تنبل از سمت خروجی سایت
 *    do=cron&key=SECRET   فراخوانی کرون سرور با کلید مخفی
 *
 * ۲. مدیریتی (نیازمند ورود مدیر + توکن CSRF):
 *    do=stats             آمار داشبورد
 *    do=feeds             فهرست خوراک‌ها
 *    do=items             فهرست آیتم‌ها با فیلتر و صفحه‌بندی
 *    do=save-feed         افزودن/ویرایش خوراک
 *    do=delete-feed       حذف خوراک
 *    do=toggle-feed       فعال/غیرفعال کردن خوراک
 *    do=fetch-feed        دریافت فوری یک خوراک
 *    do=update            به‌روزرسانی فوری همه خوراک‌ها
 *    do=test-feed         تست نشانی خوراک بدون ذخیره
 *    do=save-settings     ذخیره تنظیمات
 *    do=clear-cache       خالی کردن کش
 *    do=regen-secret      تولید کلید کرون جدید
 *    do=wipe              حذف کامل داده‌های افزونه
 *    do=delete-item       حذف یک آیتم کش
 *
 * @package FeedAggregator
 */
namespace TypechoPlugin\FeedAggregator;

use TypechoPlugin\FeedAggregator\Repo\FeedRepo;
use TypechoPlugin\FeedAggregator\Repo\ItemRepo;
use Widget\Security;
use Widget\User;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Action extends \Typecho\Widget implements \Widget\ActionInterface
{
    /**
     * پسوند توکن امنیتی مدیر
     */
    private const TOKEN_SUFFIX = 'FeedAggregator-admin';

    /**
     * مقداردهی اولیه (الزامی رابط ویجت)
     *
     * @return void
     */
    public function execute()
    {
    }

    /**
     * روتر اصلی اکشن
     *
     * @return void
     * @throws \Typecho\Widget\Exception
     */
    public function action()
    {
        $do = (string) $this->request->get('do', '');

        // عملیات عمومی (بدون ورود)
        if ($do === 'ping') {
            $this->ping();
        }

        if ($do === 'cron') {
            $this->cron();
        }

        // بقیه عملیات نیازمند دسترسی مدیر + توکن CSRF هستند
        if (!$this->authAdmin()) {
            $this->json(['ok' => false, 'msg' => I18n::t('Access denied')], 403);
        }

        switch ($do) {
            case 'stats':
                $this->stats();
                break;
            case 'feeds':
                $this->feeds();
                break;
            case 'items':
                $this->items();
                break;
            case 'save-feed':
                $this->saveFeed();
                break;
            case 'delete-feed':
                $this->deleteFeed();
                break;
            case 'toggle-feed':
                $this->toggleFeed();
                break;
            case 'fetch-feed':
                $this->fetchFeed();
                break;
            case 'update':
                $this->update();
                break;
            case 'test-feed':
                $this->testFeed();
                break;
            case 'save-settings':
                $this->saveSettings();
                break;
            case 'clear-cache':
                $this->clearCache();
                break;
            case 'regen-secret':
                $this->regenSecret();
                break;
            case 'wipe':
                $this->wipe();
                break;
            case 'delete-item':
                $this->deleteItem();
                break;
            default:
                $this->json(['ok' => false, 'msg' => I18n::t('Unknown action')], 404);
        }
    }

    /**
     * پین به‌روزرسانی تنبل (عمومی، بدون احراز هویت)
     *
     * این درخواست بسیار سبک است: اگر زمان به‌روزرسانی نرسیده باشد
     * بلافاصله پاسخ داده می‌شود و هیچ عملیات سنگینی اجرا نمی‌شود.
     *
     * @return void
     */
    private function ping(): void
    {
        if (Util::setting('lazy_update', '1') !== '1') {
            $this->json(['ok' => true, 'ran' => false]);
        }

        $ran = null;

        // اجرا با محدودیت زمانی برای جلوگیری از قفل شدن طولانی
        @set_time_limit(60);

        try {
            $ran = Scheduler::maybeUpdate();
        } catch (\Throwable $e) {
            $ran = null;
        }

        $this->json([
            'ok' => true,
            'ran' => $ran !== null,
            'stats' => $ran,
        ]);
    }

    /**
     * فراخوانی کرون سرور (عمومی با کلید مخفی)
     *
     * @return void
     */
    private function cron(): void
    {
        if (Util::setting('cron_enabled', '0') !== '1') {
            $this->json(['ok' => false, 'msg' => I18n::t('Cron endpoint is disabled')], 403);
        }

        $secret = (string) $this->request->get('key', '');
        $expected = (string) Util::setting('cron_secret', '');

        if ($expected === '' || !is_string($secret) || !hash_equals($expected, $secret)) {
            $this->json(['ok' => false, 'msg' => I18n::t('Invalid cron key')], 403);
        }

        @set_time_limit(120);

        $stats = Scheduler::run('cron');

        $this->json([
            'ok' => !empty($stats['ran']),
            'stats' => $stats,
            'time' => Date::format(time(), 'Y/m/d H:i:s'),
        ]);
    }

    /**
     * آمار داشبورد
     *
     * @return void
     */
    private function stats(): void
    {
        $settings = Util::settings();
        $state = Util::state();

        $itemStats = ItemRepo::stats();
        $feeds = FeedRepo::all();
        $activeFeeds = 0;
        $errorFeeds = 0;

        foreach ($feeds as $feed) {
            if (!empty($feed['active'])) {
                $activeFeeds++;
            }
            if (!empty($feed['lastError'])) {
                $errorFeeds++;
            }
        }

        $lastRun = (int) ($state['lastRun'] ?? 0);
        $interval = (int) $settings['update_interval'];
        $nextRun = $lastRun > 0 ? $lastRun + $interval * 60 : time();

        $this->json([
            'ok' => true,
            'data' => [
                'feeds' => count($feeds),
                'activeFeeds' => $activeFeeds,
                'errorFeeds' => $errorFeeds,
                'items' => $itemStats['items'],
                'posts' => $itemStats['posts'],
                'lastRun' => $lastRun > 0 ? Date::format($lastRun, 'j F Y، H:i') : I18n::t('never'),
                'lastRunTs' => $lastRun,
                'nextRunIn' => Scheduler::nextDueIn(),
                'locked' => Scheduler::isLocked(),
                'interval' => $interval,
                'lastStats' => $state['lastStats'] ?? [],
            ],
        ]);
    }

    /**
     * فهرست خوراک‌ها همراه با اطلاعات دسته‌بندی
     *
     * @return void
     */
    private function feeds(): void
    {
        $feeds = FeedRepo::all();
        $categories = $this->categoriesMap();

        $out = [];
        foreach ($feeds as $feed) {
            $out[] = [
                'id' => (int) $feed['id'],
                'title' => (string) $feed['title'],
                'url' => (string) $feed['url'],
                'categoryId' => (int) $feed['categoryId'],
                'categoryName' => $categories[(int) $feed['categoryId']] ?? I18n::t('Uncategorized'),
                'mode' => (string) $feed['mode'],
                'postStatus' => (string) $feed['postStatus'],
                'authorId' => (int) $feed['authorId'],
                'maxItems' => (int) $feed['maxItems'],
                'active' => (int) $feed['active'] === 1,
                'itemCount' => (int) $feed['itemCount'],
                'lastFetch' => (int) $feed['lastFetch'] > 0
                    ? Date::relative((int) $feed['lastFetch'])
                    : I18n::t('never'),
                'lastFetchTs' => (int) $feed['lastFetch'],
                'lastError' => (string) $feed['lastError'],
            ];
        }

        $this->json(['ok' => true, 'data' => $out, 'categories' => $this->categoriesTree()]);
    }

    /**
     * فهرست آیتم‌ها با فیلتر و صفحه‌بندی
     *
     * @return void
     */
    private function items(): void
    {
        $page = max(1, (int) $this->request->get('page', 1));
        $perPage = min(50, max(5, (int) $this->request->get('perPage', 15)));

        $filters = [
            'feedId' => (int) $this->request->get('feedId', 0),
            'categoryId' => (int) $this->request->get('categoryId', 0),
            'search' => trim((string) $this->request->get('search', '')),
        ];

        $rows = ItemRepo::paginate($filters, $page, $perPage);
        $total = ItemRepo::countWith($filters);

        $out = [];
        foreach ($rows as $row) {
            $out[] = [
                'id' => (int) $row['id'],
                'title' => (string) $row['title'],
                'url' => (string) $row['url'],
                'author' => (string) $row['author'],
                'excerpt' => (string) $row['excerpt'],
                'image' => (string) $row['image'],
                'postedAt' => (int) $row['postedAt'] > 0
                    ? Date::format((int) $row['postedAt'], 'j F Y، H:i')
                    : I18n::t('unknown'),
                'fetchedAt' => Date::relative((int) $row['fetchedAt']),
                'feedTitle' => (string) ($row['feedTitle'] ?? ''),
                'postId' => (int) $row['postId'],
            ];
        }

        $this->json([
            'ok' => true,
            'data' => $out,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'pages' => (int) ceil($total / $perPage),
        ]);
    }

    /**
     * افزودن یا ویرایش خوراک
     *
     * @return void
     */
    private function saveFeed(): void
    {
        $id = (int) $this->request->get('id', 0);

        $url = Util::validateFeedUrl((string) $this->request->get('url', ''));

        if ($url === false) {
            $this->json(['ok' => false, 'msg' => I18n::t('The feed URL is invalid (only http/https is allowed)')]);
        }

        $title = trim((string) $this->request->get('title', ''));

        // بررسی تکراری نبودن نشانی
        $existing = FeedRepo::findByUrl($url);
        if ($existing !== null && (int) $existing['id'] !== $id) {
            $this->json(['ok' => false, 'msg' => I18n::t('This feed URL is already registered')]);
        }

        $data = [
            'title' => $title,
            'url' => $url,
            'categoryId' => (int) $this->request->get('categoryId', 0),
            'mode' => (string) $this->request->get('mode', 'cache'),
            'postStatus' => (string) $this->request->get('postStatus', 'publish'),
            'authorId' => (int) $this->request->get('authorId', 1),
            'maxItems' => (int) $this->request->get('maxItems', 50),
            'active' => (int) $this->request->get('active', 1),
        ];

        // اعتبارسنجی دسته‌بندی
        if ($data['categoryId'] > 0 && !$this->categoryExists($data['categoryId'])) {
            $data['categoryId'] = 0;
        }

        try {
            if ($id > 0) {
                if (FeedRepo::find($id) === null) {
                    $this->json(['ok' => false, 'msg' => I18n::t('Feed not found')], 404);
                }

                FeedRepo::update($id, $data);
                $msg = I18n::t('Feed updated successfully');
            } else {
                $id = FeedRepo::add($data);
                $msg = I18n::t('Feed added successfully');
            }
        } catch (\Throwable $e) {
            $this->json(['ok' => false, 'msg' => I18n::t('Database error: %s', $e->getMessage())]);
        }

        $this->json(['ok' => true, 'msg' => $msg, 'id' => $id]);
    }

    /**
     * حذف خوراک
     *
     * @return void
     */
    private function deleteFeed(): void
    {
        $id = (int) $this->request->get('id', 0);
        $deletePosts = $this->request->get('deletePosts', '0') === '1';

        if (FeedRepo::find($id) === null) {
            $this->json(['ok' => false, 'msg' => I18n::t('Feed not found')], 404);
        }

        FeedRepo::delete($id, $deletePosts);

        $this->json(['ok' => true, 'msg' => I18n::t('Feed deleted')]);
    }

    /**
     * فعال/غیرفعال کردن خوراک
     *
     * @return void
     */
    private function toggleFeed(): void
    {
        $id = (int) $this->request->get('id', 0);

        if (!FeedRepo::toggle($id)) {
            $this->json(['ok' => false, 'msg' => I18n::t('Feed not found')], 404);
        }

        $this->json(['ok' => true]);
    }

    /**
     * دریافت فوری یک خوراک
     *
     * @return void
     */
    private function fetchFeed(): void
    {
        $id = (int) $this->request->get('id', 0);

        @set_time_limit(90);

        $stats = Scheduler::run('single', $id);

        $this->json(['ok' => !empty($stats['ran']), 'msg' => $this->statsMessage($stats), 'stats' => $stats]);
    }

    /**
     * به‌روزرسانی فوری همه خوراک‌ها
     *
     * @return void
     */
    private function update(): void
    {
        @set_time_limit(120);

        $stats = Scheduler::run('manual');

        $this->json(['ok' => !empty($stats['ran']), 'msg' => $this->statsMessage($stats), 'stats' => $stats]);
    }

    /**
     * تست نشانی خوراک بدون ذخیره
     *
     * @return void
     */
    private function testFeed(): void
    {
        $url = Util::validateFeedUrl((string) $this->request->get('url', ''));

        if ($url === false) {
            $this->json(['ok' => false, 'msg' => I18n::t('The feed URL is invalid (only http/https is allowed)')]);
        }

        @set_time_limit(60);

        $fetcher = new Fetcher();
        $result = $fetcher->fetch($url, [], Util::setting('fetch_timeout', 15), 10);

        if (!$result['ok']) {
            $this->json(['ok' => false, 'msg' => (string) $result['error']]);
        }

        $preview = [];
        $count = 0;
        foreach ((array) $result['items'] as $item) {
            if ($count >= 5) {
                break;
            }

            $preview[] = [
                'title' => (string) $item['title'],
                'url' => (string) $item['url'],
                'date' => (int) $item['postedAt'] > 0 ? Date::format((int) $item['postedAt']) : '',
                'author' => (string) $item['author'],
            ];
            $count++;
        }

        $this->json([
            'ok' => true,
            'msg' => I18n::t('Feed parsed successfully'),
            'data' => [
                'meta' => $result['meta'],
                'totalItems' => count((array) $result['items']),
                'preview' => $preview,
            ],
        ]);
    }

    /**
     * ذخیره تنظیمات
     *
     * @return void
     */
    private function saveSettings(): void
    {
        $settings = [
            'update_interval' => max(5, (int) $this->request->get('update_interval', 60)),
            'lazy_update' => $this->request->get('lazy_update', '1') === '1' ? '1' : '0',
            'cron_enabled' => $this->request->get('cron_enabled', '0') === '1' ? '1' : '0',
            'fetch_timeout' => min(60, max(3, (int) $this->request->get('fetch_timeout', 15))),
            'purge_days' => max(0, (int) $this->request->get('purge_days', 30)),
            'default_mode' => $this->request->get('default_mode', 'cache') === 'post' ? 'post' : 'cache',
            'default_post_status' => in_array(
                (string) $this->request->get('default_post_status', 'publish'),
                ['publish', 'draft', 'waiting', 'private'],
                true
            ) ? (string) $this->request->get('default_post_status', 'publish') : 'publish',
            'default_max_items' => min(500, max(1, (int) $this->request->get('default_max_items', 50))),
            'show_source_link' => $this->request->get('show_source_link', '1') === '1' ? '1' : '0',
        ];

        Util::saveSettings($settings);

        $this->json(['ok' => true, 'msg' => I18n::t('Settings saved')]);
    }

    /**
     * خالی کردن کامل کش آیتم‌ها
     *
     * @return void
     */
    private function clearCache(): void
    {
        $count = ItemRepo::clearAll();

        $this->json([
            'ok' => true,
            'msg' => I18n::t('%d cached items were removed', $count),
        ]);
    }

    /**
     * تولید کلید کرون جدید
     *
     * @return void
     */
    private function regenSecret(): void
    {
        $secret = bin2hex(random_bytes(20));
        Util::saveSettings(['cron_secret' => $secret]);
        Util::flushSettingsCache();

        $this->json([
            'ok' => true,
            'msg' => I18n::t('A new cron key was generated'),
            'secret' => $secret,
            'url' => Util::actionUrl() . '?do=cron&key=' . $secret,
        ]);
    }

    /**
     * حذف کامل داده‌های افزونه (جداول + وضعیت + تنظیمات)
     *
     * @return void
     */
    private function wipe(): void
    {
        $confirm = (string) $this->request->get('confirm', '');

        if ($confirm !== 'wipe-all-data') {
            $this->json(['ok' => false, 'msg' => I18n::t('Confirmation phrase is incorrect')]);
        }

        \TypechoPlugin\FeedAggregator\Install::dropTables();
        Util::flushSettingsCache();

        $this->json(['ok' => true, 'msg' => I18n::t('All plugin data was removed. Deactivate and reactivate the plugin to start fresh.')]);
    }

    /**
     * حذف یک آیتم کش
     *
     * @return void
     */
    private function deleteItem(): void
    {
        $id = (int) $this->request->get('id', 0);

        if (!ItemRepo::delete($id)) {
            $this->json(['ok' => false, 'msg' => I18n::t('Item not found')], 404);
        }

        $this->json(['ok' => true, 'msg' => I18n::t('Item deleted')]);
    }

    /**
     * احراز هویت مدیر + توکن CSRF
     *
     * @return bool
     */
    private function authAdmin(): bool
    {
        $user = User::alloc();

        if (!($user instanceof User) || !$user->hasLogin() || !$user->pass('administrator', true)) {
            return false;
        }

        $token = (string) $this->request->get('fag_token', '');

        return $token !== '' && hash_equals(Security::alloc()->getToken(self::TOKEN_SUFFIX), $token);
    }

    /**
     * پاسخ JSON و پایان درخواست
     *
     * @param mixed $data  داده پاسخ
     * @param int   $status کد وضعیت HTTP
     * @return void
     */
    private function json($data, int $status = 200): void
    {
        if ($status !== 200) {
            $this->response->setStatus($status);
        }

        $this->response->throwJson($data);
    }

    /**
     * پیام خلاصه نتیجه به‌روزرسانی
     *
     * @param array<string, mixed> $stats آمار
     * @return string
     */
    private function statsMessage(array $stats): string
    {
        if (empty($stats['ran'])) {
            return (string) ($stats['reason'] ?? I18n::t('Update did not run'));
        }

        return I18n::t(
            '%d feeds checked, %d new items, %d new posts',
            (int) ($stats['feeds'] ?? 0),
            (int) ($stats['itemsNew'] ?? 0),
            (int) ($stats['postsNew'] ?? 0)
        );
    }

    /**
     * نقشه شناسه دسته به نام
     *
     * @return array<int, string>
     */
    private function categoriesMap(): array
    {
        $map = [];
        foreach ($this->categoriesTree() as $cat) {
            $map[(int) $cat['id']] = $cat['label'];
        }

        return $map;
    }

    /**
     * درخت دسته‌بندی‌ها (تخت با تورفتگی)
     *
     * @return array<int, array<string, mixed>>
     */
    private function categoriesTree(): array
    {
        try {
            $rows = \Typecho\Db::get()->fetchAll(
                \Typecho\Db::get()->select('mid', 'name', 'slug', 'parent')
                    ->from('table.metas')
                    ->where('type = ?', 'category')
                    ->order('order', \Typecho\Db::SORT_ASC)
            );
        } catch (\Throwable $e) {
            return [];
        }

        // ساخت درخت با تورفتگی
        $byParent = [];
        foreach ($rows as $row) {
            $byParent[(int) $row['parent']][] = $row;
        }

        $out = [];
        $walk = function (int $parent, int $depth) use (&$walk, &$out, $byParent): void {
            foreach ($byParent[$parent] ?? [] as $row) {
                $out[] = [
                    'id' => (int) $row['mid'],
                    'name' => (string) $row['name'],
                    'slug' => (string) $row['slug'],
                    'label' => str_repeat('— ', $depth) . (string) $row['name'],
                ];
                $walk((int) $row['mid'], $depth + 1);
            }
        };

        $walk(0, 0);

        return $out;
    }

    /**
     * بررسی وجود دسته‌بندی
     *
     * @param int $mid شناسه دسته
     * @return bool
     */
    private function categoryExists(int $mid): bool
    {
        try {
            $row = \Typecho\Db::get()->fetchRow(
                \Typecho\Db::get()->select('mid')->from('table.metas')
                    ->where('mid = ? AND type = ?', $mid, 'category')
                    ->limit(1)
            );

            return !empty($row);
        } catch (\Throwable $e) {
            return false;
        }
    }
}
