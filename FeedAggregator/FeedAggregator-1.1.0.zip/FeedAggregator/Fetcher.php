<?php
/**
 * دریافت‌کننده و تجزیه‌گر خوراک‌های RSS / Atom / RDF
 *
 * مسئولیت این کلاس:
 * ۱. دریافت امن محتوای خوراک با پشتیبانی از ETag و Last-Modified
 *    برای کاهش پهنای باند
 * ۲. تشخیص و تبدیل کدگذاری به UTF-8
 * ۳. تجزیه سه قالب رایج (RSS 2.0، Atom 1.0، RDF/RSS 1.0) با SimpleXML
 * ۴. استخراج عنوان، لینک، نویسنده، تاریخ، خلاصه، محتوای کامل و تصویر
 *
 * @package FeedAggregator
 */
namespace TypechoPlugin\FeedAggregator;

use Typecho\Http\Client;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Fetcher
{
    /**
     * حداکثر حجم مجاز پاسخ خوراک (بایت)
     */
    private const MAX_BODY_SIZE = 3145728; // ۳ مگابایت

    /**
     * ساختار نتیجه استاندارد
     *
     * @var array<string, mixed>
     */
    private array $result = [
        'ok' => false,
        'error' => '',
        'http' => 0,
        'notModified' => false,
        'etag' => '',
        'lastModified' => '',
        'meta' => ['title' => '', 'link' => '', 'description' => ''],
        'items' => [],
    ];

    /**
     * دریافت و تجزیه یک خوراک
     *
     * @param string $url          نشانی خوراک
     * @param array  $feed         سطر خوراک از دیتابیس (برای etag و lastModified)
     * @param int    $timeout      مهلت در ثانیه
     * @param int    $maxItems     حداکثر تعداد آیتم قابل پردازش
     * @return array<string, mixed>
     */
    public function fetch(string $url, array $feed = [], int $timeout = 15, int $maxItems = 60): array
    {
        $url = Util::validateFeedUrl($url);

        if ($url === false) {
            $this->result['error'] = I18n::t('Invalid feed URL');
            return $this->result;
        }

        $client = Client::get();

        if ($client === null) {
            $this->result['error'] = I18n::t('No HTTP transport available on this server');
            return $this->result;
        }

        // ارسال شرطی برای صرفه‌جویی در پهنای باند
        $etag = (string) ($feed['etag'] ?? '');
        $lastModified = (string) ($feed['lastModified'] ?? '');

        $client->setTimeout(max(3, $timeout));
        $client->setAgent('TypeRenew FeedAggregator (+https://typerenew.ir)');
        $client->setHeader('Accept', 'application/rss+xml, application/atom+xml, application/xml, text/xml, */*');

        if ($etag !== '') {
            $client->setHeader('If-None-Match', $etag);
        }

        if ($lastModified !== '') {
            $client->setHeader('If-Modified-Since', $lastModified);
        }

        try {
            $client->send($url);
        } catch (\Throwable $e) {
            $this->result['error'] = I18n::t('Connection failed: %s', $e->getMessage());
            return $this->result;
        }

        $status = $client->getResponseStatus();

        // دنبال‌کردن ریدایرکت‌ها (تا ۴ hops) — برخی سرورها نشانی نهایی را با
        // 301/302/307/308 معرفی می‌کنند
        $hops = 0;
        while (in_array($status, [301, 302, 303, 307, 308], true) && $hops < 4) {
            $location = (string) ($client->getResponseHeader('location') ?? $client->getResponseHeader('Location') ?? '');

            if ($location === '') {
                break;
            }

            // تبدیل نشانی نسبی به مطلق
            $next = $this->absoluteUrl($location, $url);
            $next = Util::validateFeedUrl($next);

            if ($next === false || $next === $url) {
                break;
            }

            $url = $next;
            $client = Client::get();

            if ($client === null) {
                break;
            }

            $client->setTimeout(max(3, $timeout));
            $client->setAgent('TypeRenew FeedAggregator (+https://typerenew.ir)');
            $client->setHeader('Accept', 'application/rss+xml, application/atom+xml, application/xml, text/xml, */*');

            try {
                $client->send($url);
            } catch (\Throwable $e) {
                $this->result['error'] = I18n::t('Connection failed: %s', $e->getMessage());
                return $this->result;
            }

            $status = $client->getResponseStatus();
            $hops++;
        }

        $this->result['http'] = $status;

        // خوراک از آخرین بار تغییری نکرده است
        if ($status === 304) {
            $this->result['notModified'] = true;
            $this->result['ok'] = true;
            return $this->result;
        }

        if ($status !== 200) {
            $this->result['error'] = I18n::t('Feed server responded with HTTP %d', $status);
            return $this->result;
        }

        $body = $client->getResponseBody();

        if (!is_string($body) || $body === '') {
            $this->result['error'] = I18n::t('Empty response from feed server');
            return $this->result;
        }

        if (strlen($body) > self::MAX_BODY_SIZE) {
            $this->result['error'] = I18n::t('Feed content is too large (over 3MB)');
            return $this->result;
        }

        $this->result['etag'] = (string) ($client->getResponseHeader('etag') ?? $client->getResponseHeader('ETag') ?? '');
        $this->result['lastModified'] = (string) ($client->getResponseHeader('last-modified') ?? $client->getResponseHeader('Last-Modified') ?? '');

        return $this->parse($body, $url, $maxItems);
    }

    /**
     * تجزیه بدنه XML خوراک
     *
     * @param string $body    بدنه پاسخ
     * @param string $baseUrl نشانی خوراک (برای لینک‌های نسبی)
     * @param int    $maxItems حداکثر آیتم
     * @return array<string, mixed>
     */
    public function parse(string $body, string $baseUrl = '', int $maxItems = 60): array
    {
        $xml = $this->prepareXml($body);

        if ($xml === null) {
            $this->result['error'] = I18n::t('Feed content is not valid XML');
            return $this->result;
        }

        $rootName = strtolower($xml->getName());
        $parsed = false;

        if ($rootName === 'rss') {
            $parsed = $this->parseRss2($xml, $baseUrl, $maxItems);
        } elseif ($rootName === 'feed') {
            $parsed = $this->parseAtom($xml, $baseUrl, $maxItems);
        } elseif ($rootName === 'rdf') {
            $parsed = $this->parseRdf($xml, $baseUrl, $maxItems);
        }

        if (!$parsed) {
            $this->result['error'] = I18n::t('Unsupported feed format (expected RSS 2.0, Atom or RDF)');
            return $this->result;
        }

        $this->result['ok'] = true;
        return $this->result;
    }

    /**
     * آماده‌سازی XML: حذف BOM، تشخیص کدگذاری و تبدیل به UTF-8
     *
     * @param string $body بدنه خام
     * @return \SimpleXMLElement|null
     */
    private function prepareXml(string $body): ?\SimpleXMLElement
    {
        $body = Util::cleanText($body);
        $body = trim($body);

        if ($body === '') {
            return null;
        }

        // تشخیص کدگذاری از سرآیند XML
        $encoding = 'UTF-8';
        if (preg_match('#^<\?xml[^>]*encoding=["\']([a-zA-Z0-9_\-]+)["\']#i', $body, $match)) {
            $encoding = strtoupper($match[1]);
        }

        if ($encoding !== 'UTF-8' && $encoding !== 'UTF8') {
            $converted = @mb_convert_encoding($body, 'UTF-8', $encoding);
            if (is_string($converted) && $converted !== '') {
                $body = preg_replace('#^(<\?xml[^>]*encoding=["\'])[^"\'](["\'])#i', '$1UTF-8$2', $converted) ?? $converted;
            }
        }

        $useErrors = libxml_use_internal_errors(true);

        $xml = simplexml_load_string(
            $body,
            \SimpleXMLElement::class,
            LIBXML_NOWARNING | LIBXML_NOERROR | LIBXML_NONET
        );

        // تلاش دوم: حذف بلاک‌های CDATA مشکل‌دار و کاراکترهای کنترلی عمیق
        if ($xml === false || $xml === null) {
            $body2 = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $body) ?? $body;
            $xml = simplexml_load_string($body2, \SimpleXMLElement::class, LIBXML_NOWARNING | LIBXML_NOERROR | LIBXML_NONET);
        }

        libxml_clear_errors();
        libxml_use_internal_errors($useErrors);

        return $xml instanceof \SimpleXMLElement ? $xml : null;
    }

    /**
     * تجزیه خوراک RSS 2.0 (و 0.9x)
     *
     * @param \SimpleXMLElement $xml
     * @param string $baseUrl
     * @param int    $maxItems
     * @return bool
     */
    private function parseRss2(\SimpleXMLElement $xml, string $baseUrl, int $maxItems): bool
    {
        $channel = $xml->channel;

        if ($channel === null) {
            return false;
        }

        $this->result['meta'] = [
            'title' => $this->text($channel->title),
            'link' => $this->text($channel->link),
            'description' => $this->text($channel->description),
        ];

        // تصویر کانال به‌عنوان منبع جایگزین تصویر آیتم‌ها
        $channelImage = $this->text($channel->image->url ?? null);

        $count = 0;
        foreach ($channel->item as $item) {
            if ($count >= $maxItems) {
                break;
            }

            // برخی خوراک‌های RSS 1.0 داخل پوشش RSS قرار می‌گیرند
            $link = $this->text($item->link);
            $guid = $this->text($item->guid);
            $title = $this->text($item->title);

            $contentNode = $item->children('http://purl.org/rss/1.0/modules/content/');
            $content = $this->text($contentNode->encoded ?? null);

            $description = $this->text($item->description);
            if ($content === '') {
                $content = $description;
            }

            $date = $this->text($item->pubDate);

            if ($date === '') {
                // سازگاری با خوراک‌های RSS 1.0 (dc:date)
                $dc = $item->children('http://purl.org/dc/elements/1.1/');
                $date = $this->text($dc->date ?? null);
            }

            $author = $this->text($item->author ?? null);
            if ($author === '') {
                $dc = $item->children('http://purl.org/dc/elements/1.1/');
                $author = $this->text($dc->creator ?? null);
            }

            $image = $this->itemImage($item);

            if ($image === '' && $channelImage !== '') {
                $image = $channelImage;
            }

            $this->pushItem($title, $link, $guid, $author, $description, $content, $image, $date, $baseUrl);
            $count++;
        }

        return true;
    }

    /**
     * تجزیه خوراک Atom 1.0
     *
     * @param \SimpleXMLElement $xml
     * @param string $baseUrl
     * @param int    $maxItems
     * @return bool
     */
    private function parseAtom(\SimpleXMLElement $xml, string $baseUrl, int $maxItems): bool
    {
        $this->result['meta'] = [
            'title' => $this->text($xml->title),
            'link' => $this->atomLink($xml, 'alternate') ?: $this->atomLink($xml, ''),
            'description' => $this->text($xml->subtitle ?? null),
        ];

        $count = 0;
        foreach ($xml->entry as $entry) {
            if ($count >= $maxItems) {
                break;
            }

            $link = $this->atomLink($entry, 'alternate') ?: $this->atomLink($entry, '');

            $title = $this->text($entry->title);
            $guid = $this->text($entry->id ?? null);

            $content = $this->text($entry->content ?? null);
            $summary = $this->text($entry->summary ?? null);

            if ($content === '') {
                $content = $summary;
            }

            $date = $this->text($entry->published ?? null);
            if ($date === '') {
                $date = $this->text($entry->updated ?? null);
            }

            $author = $this->text($entry->author->name ?? null);

            $image = $this->itemImage($entry);

            $this->pushItem($title, $link, $guid, $author, $summary, $content, $image, $date, $baseUrl);
            $count++;
        }

        return true;
    }

    /**
     * تجزیه خوراک RDF / RSS 1.0
     *
     * @param \SimpleXMLElement $xml
     * @param string $baseUrl
     * @param int    $maxItems
     * @return bool
     */
    private function parseRdf(\SimpleXMLElement $xml, string $baseUrl, int $maxItems): bool
    {
        $channel = $xml->channel;

        if ($channel === null) {
            return false;
        }

        $this->result['meta'] = [
            'title' => $this->text($channel->title),
            'link' => $this->text($channel->link),
            'description' => $this->text($channel->description ?? null),
        ];

        $rss1 = 'http://purl.org/rss/1.0/';
        $dc = 'http://purl.org/dc/elements/1.1/';

        $count = 0;
        foreach ($xml->item as $item) {
            if ($count >= $maxItems) {
                break;
            }

            // عنوان و لینک RSS 1.0 در فضای نام rss1 قرار دارند
            $rss1Children = $item->children($rss1);
            $dcChildren = $item->children($dc);

            $title = $this->text($rss1Children->title ?? $item->title);
            $description = $this->text($rss1Children->description ?? $item->description);

            // لینک آیتم RDF در ویژگی rdf:about قرار دارد
            $about = (string) ($item->attributes('http://www.w3.org/1999/02/22-rdf-syntax-ns#')['about'] ?? '');
            $link = $about !== '' ? $about : $this->text($rss1Children->link ?? null);

            $date = $this->text($dcChildren->date ?? null);
            $author = $this->text($dcChildren->creator ?? null);

            $this->pushItem($title, $link, '', $author, $description, $description, '', $date, $baseUrl);
            $count++;
        }

        return true;
    }

    /**
     * افزودن یک آیتم استخراج‌شده به نتیجه
     *
     * @param string $title
     * @param string $link
     * @param string $guid
     * @param string $author
     * @param string $summary
     * @param string $content
     * @param string $image
     * @param string $date
     * @param string $baseUrl
     * @return void
     */
    private function pushItem(
        string $title,
        string $link,
        string $guid,
        string $author,
        string $summary,
        string $content,
        string $image,
        string $date,
        string $baseUrl
    ): void {
        // نرمال‌سازی لینک نسبی
        if ($link === '' && $guid !== '' && preg_match('#^https?://#i', $guid)) {
            $link = $guid;
        }

        if ($link !== '' && !preg_match('#^https?://#i', $link)) {
            $link = $this->absoluteUrl($link, $baseUrl);
        }

        // اعتبارسنجی لینک نهایی
        if ($link !== '') {
            $safeLink = Util::validateFeedUrl($link);
            $link = $safeLink === false ? '' : $safeLink;
        }

        // پاک‌سازی محتوا با فهرست سفید
        $content = Sanitizer::clean($content, $baseUrl);
        $summary = Util::makeExcerpt($summary !== '' ? $summary : $content);
        $title = Util::cleanText(html_entity_decode($title, ENT_QUOTES | ENT_HTML5, 'UTF-8'));

        if ($image !== '') {
            $image = $this->absoluteUrl($image, $baseUrl);
            $safeImage = Util::validateFeedUrl($image);
            $image = $safeImage === false ? '' : $safeImage;
        }

        $timestamp = $this->parseDate($date);

        // آیتم‌های کاملاً خالی رد می‌شوند
        if ($title === '' && $link === '' && $content === '') {
            return;
        }

        $this->result['items'][] = [
            'uid' => Util::itemUid($link, $guid, $title),
            'title' => mb_substr($title, 0, 240, 'UTF-8'),
            'url' => mb_substr($link, 0, 500, 'UTF-8'),
            'author' => mb_substr(Util::cleanText($author), 0, 120, 'UTF-8'),
            'excerpt' => mb_substr($summary, 0, 500, 'UTF-8'),
            'content' => $content,
            'image' => mb_substr($image, 0, 500, 'UTF-8'),
            'postedAt' => $timestamp,
        ];
    }

    /**
     * استخراج نشانی لینک با رابطه مشخص در عناصر link فرمت Atom
     *
     * @param \SimpleXMLElement $element
     * @param string            $rel نوع رابطه
     * @return string
     */
    private function atomLink(\SimpleXMLElement $element, string $rel): string
    {
        foreach ($element->link as $link) {
            $attrs = $link->attributes();

            if ($attrs === null) {
                continue;
            }

            $linkRel = (string) ($attrs['rel'] ?? '');
            $href = (string) ($attrs['href'] ?? '');

            if ($href !== '' && ($rel === '' ? $linkRel === '' : $linkRel === $rel)) {
                return $href;
            }
        }

        return '';
    }

    /**
     * استخراج تصویر آیتم از فضاهای نام media و enclosure
     *
     * @param \SimpleXMLElement $item
     * @return string
     */
    private function itemImage(\SimpleXMLElement $item): string
    {
        // media:content با نوع تصویر
        $media = $item->children('http://search.yahoo.com/mrss/');
        if (isset($media->content)) {
            foreach ($media->content as $content) {
                $attrs = $content->attributes();
                $url = (string) ($attrs['url'] ?? '');
                $medium = strtolower((string) ($attrs['medium'] ?? ''));
                $type = strtolower((string) ($attrs['type'] ?? ''));

                if ($url !== '' && ($medium === 'image' || strpos($type, 'image/') === 0)) {
                    return $url;
                }
            }
        }

        // media:thumbnail
        if (isset($media->thumbnail)) {
            $attrs = $media->thumbnail->attributes();
            $url = (string) ($attrs['url'] ?? '');
            if ($url !== '') {
                return $url;
            }
        }

        // enclosure از نوع تصویر
        foreach ($item->enclosure as $enclosure) {
            $attrs = $enclosure->attributes();
            $url = (string) ($attrs['url'] ?? '');
            $type = strtolower((string) ($attrs['type'] ?? ''));

            if ($url !== '' && strpos($type, 'image/') === 0) {
                return $url;
            }
        }

        // اولین تصویر داخل محتوای HTML (تگ img)
        $candidates = [
            $item->children('http://purl.org/rss/1.0/modules/content/')->encoded ?? null,
            $item->description ?? null,
            $item->content ?? null,
            $item->summary ?? null,
        ];

        foreach ($candidates as $node) {
            $html = $this->text($node);
            if ($html !== '' && preg_match('#<img[^>]+src=["\']([^"\']+)["\']#i', $html, $match)) {
                return $match[1];
            }
        }

        return '';
    }

    /**
     * تبدیل متن تاریخ خوراک به زمان یونیکس
     *
     * @param string $date متن تاریخ
     * @return int زمان یونیکس (۰ در صورت ناموفق)
     */
    private function parseDate(string $date): int
    {
        $date = trim($date);

        if ($date === '') {
            return 0;
        }

        $ts = strtotime($date);

        if ($ts === false) {
            return 0;
        }

        // تاریخ‌های نامعتبر دور از محدوده منطقی حذف می‌شوند
        if ($ts > 2147483647 || $ts < 946684800) { // بعد از ۲۰۳۸ یا قبل از ۲۰۰۰
            return 0;
        }

        return (int) $ts;
    }

    /**
     * خواندن متن امن یک گره SimpleXML
     *
     * @param mixed $node
     * @return string
     */
    private function text($node): string
    {
        if ($node === null) {
            return '';
        }

        $text = (string) $node;
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = Util::cleanText($text);

        return trim($text);
    }

    /**
     * تبدیل نشانی نسبی به مطلق
     *
     * @param string $url
     * @param string $baseUrl
     * @return string
     */
    private function absoluteUrl(string $url, string $baseUrl): string
    {
        $url = trim($url);

        if ($url === '' || preg_match('#^(https?:)?//#i', $url)) {
            return $url;
        }

        $parts = @parse_url($baseUrl);
        if ($parts === false || empty($parts['scheme']) || empty($parts['host'])) {
            return $url;
        }

        $origin = $parts['scheme'] . '://' . $parts['host'] . (isset($parts['port']) ? ':' . $parts['port'] : '');

        if ($url[0] === '/') {
            return $origin . $url;
        }

        return rtrim($baseUrl, '/') . '/' . ltrim($url, '/');
    }
}
