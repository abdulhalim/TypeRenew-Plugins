<?php
/**
 * پردازشگر شورت‌کد [FeedAggregator]
 *
 * نحوه استفاده در محتوای هر نوشته یا برگه:
 *
 *   [FeedAggregator]
 *   [FeedAggregator cat="news" count="8" title="آخرین اخبار"]
 *   [FeedAggregator feed="3" layout="cards" excerpt="0"]
 *
 * پارامترها:
 * cat      شناسه یا نامک دسته‌بندی
 * feed     شناسه خوراک مشخص
 * count    تعداد آیتم‌ها (پیش‌فرض ۱۰)
 * title    عنوان بلوک
 * layout   چیدمان: list یا cards
 * excerpt  نمایش خلاصه: 1 یا 0
 * image    نمایش تصویر: 1 یا 0
 * date     نمایش تاریخ: 1 یا 0
 *
 * @package FeedAggregator
 */
namespace TypechoPlugin\FeedAggregator;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Shortcode
{
    /**
     * الگوی شناسایی شورت‌کد
     *
     * @var string
     */
    private const PATTERN = '/\[FeedAggregator(([^\]]*))\]/ui';

    /**
     * جایگزینی شورت‌کدها در محتوای نوشته
     *
     * به‌عنوان hook روی contentEx متصل می‌شود.
     *
     * @param string|null          $content  محتوای اصلی
     * @param \Typecho\Widget|null $widget   ویجت محتوا
     * @param string|null          $lastResult نتیجه زنجیره قبلی
     * @return string
     */
    public static function filter(?string $content, $widget = null, ?string $lastResult = null): string
    {
        $content = (string) $content;

        if ($content === '' || stripos($content, '[FeedAggregator') === false) {
            return $content;
        }

        // در خروجی فید سایت (RSS/Atom) شورت‌کد حذف می‌شود تا HTML ویجت
        // داخل خوراک سایت تزریق نشود
        if (self::inFeedContext()) {
            return self::strip($content);
        }

        return preg_replace_callback(self::PATTERN, function (array $match): string {
            $attrs = self::parseAttrs($match[1]);
            return Renderer::render($attrs);
        }, $content) ?? $content;
    }

    /**
     * حذف شورت‌کد از محتوا (برای خلاصه‌ها و فیدها)
     *
     * @param string|null $content محتوای اصلی
     * @return string
     */
    public static function strip(?string $content): string
    {
        $content = (string) $content;

        if ($content === '' || stripos($content, '[FeedAggregator') === false) {
            return $content;
        }

        return preg_replace(self::PATTERN, '', $content) ?? $content;
    }

    /**
     * تجزیه پارامترهای شورت‌کد
     *
     * @param string $text متن پارامترها
     * @return array<string, mixed>
     */
    private static function parseAttrs(string $text): array
    {
        $attrs = [];

        // پارامترهای key="value" یا key='value' یا key=value
        if (preg_match_all('/([a-zA-Z_][a-zA-Z0-9_\-]*)\s*=\s*("([^"]*)"|\'([^\']*)\'|([^\s"\']+))/', $text, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $value = $match[3] ?? ($match[4] ?? ($match[5] ?? ''));
                $attrs[strtolower($match[1])] = $value;
            }
        }

        return [
            'cat' => isset($attrs['cat']) ? $attrs['cat'] : (isset($attrs['category']) ? $attrs['category'] : 0),
            'feed' => (int) ($attrs['feed'] ?? 0),
            'count' => (int) ($attrs['count'] ?? 10),
            'title' => (string) ($attrs['title'] ?? ''),
            'layout' => ($attrs['layout'] ?? 'list') === 'cards' ? 'cards' : 'list',
            'excerpt' => !isset($attrs['excerpt']) || $attrs['excerpt'] !== '0',
            'image' => !isset($attrs['image']) || $attrs['image'] !== '0',
            'date' => !isset($attrs['date']) || $attrs['date'] !== '0',
        ];
    }

    /**
     * تشخیص زمینه فید (RSS/Atom سایت)
     *
     * @return bool
     */
    private static function inFeedContext(): bool
    {
        try {
            $request = \Typecho\Request::getInstance();
            $url = (string) $request->getRequestUrl();

            // مسیرهای پیش‌فرض و رایج فید: /feed، /feed/...، ?feed=...
            if (preg_match('#/feed(/|$|\?)#i', $url) || isset($_GET['feed']) || isset($_GET['rss'])) {
                return true;
            }
        } catch (\Throwable $e) {
            return false;
        }

        return false;
    }
}
