/**
 * SiteCare Panel JavaScript
 *
 * مدیریت ذخیره تنظیمات، toggle سریع و آپدیت زنده شمارنده در پنل.
 */
(function () {
    'use strict';

    var config = window.SiteCarePanel || {};
    var urls = {
        save: config.save || '',
        toggle: config.toggle || '',
        reset: config.reset || '',
    };
    var state = config.state || {};
    var lang = config.lang || {};

    var PER_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    function toPersian(n) {
        return String(n).replace(/\d/g, function (d) { return PER_DIGITS[+d]; });
    }
    function pad(n) { return n < 10 ? '0' + n : String(n); }

    // عناصر DOM
    var toggleBtn = document.getElementById('sitecareToggleBtn');
    var saveBtn = document.getElementById('sitecareSaveBtn');
    var resetBtn = document.getElementById('sitecareResetBtn');
    var statusPill = document.getElementById('sitecareStatusPill');
    var saveStatus = document.getElementById('sitecareSaveStatus');

    var titleInput = document.getElementById('sitecareTitle');
    var messageInput = document.getElementById('sitecareMessage');
    var hoursInput = document.getElementById('sitecareHours');
    var minutesInput = document.getElementById('sitecareMinutes');
    var secondsInput = document.getElementById('sitecareSeconds');
    var countdownEnabledInput = document.getElementById('sitecareCountdownEnabled');
    var showAdminLinkInput = document.getElementById('sitecareShowAdminLink');
    var animateIconInput = document.getElementById('sitecareAnimateIcon');

    var liveHours = document.getElementById('sitecareLiveHours');
    var liveMinutes = document.getElementById('sitecareLiveMinutes');
    var liveSeconds = document.getElementById('sitecareLiveSeconds');

    // وضعیت محلی شمارنده
    var remaining = state.remaining || 0;
    var startedAt = state.countdownStartedAt || 0;
    var totalSeconds = state.totalSeconds || 0;

    /**
     * ساخت آبجکت تنظیمات از روی مقادیر فعلی فرم
     */
    function gatherSettings() {
        return {
            title: titleInput ? titleInput.value : '',
            message: messageInput ? messageInput.value : '',
            countdownHours: hoursInput ? parseInt(hoursInput.value, 10) || 0 : 0,
            countdownMinutes: minutesInput ? parseInt(minutesInput.value, 10) || 0 : 0,
            countdownSeconds: secondsInput ? parseInt(secondsInput.value, 10) || 0 : 0,
            countdownEnabled: countdownEnabledInput && countdownEnabledInput.checked ? '1' : '0',
            showAdminLink: showAdminLinkInput && showAdminLinkInput.checked ? '1' : '0',
            animateIcon: animateIconInput && animateIconInput.checked ? '1' : '0',
            // enabled را از state فعلی می‌گیریم
            enabled: state.enabled || '0',
        };
    }

    /**
     * ارسال درخواست POST با توکن امنیتی
     */
    function post(url, payload, onSuccess, onError) {
        if (!url) {
            if (onError) onError('URL خالی است');
            return;
        }
        var xhr = new XMLHttpRequest();
        xhr.open('POST', url, true);
        xhr.setRequestHeader('Accept', 'application/json');
        xhr.setRequestHeader('Content-Type', 'application/json; charset=UTF-8');
        xhr.onreadystatechange = function () {
            if (xhr.readyState !== 4) return;
            try {
                var data = JSON.parse(xhr.responseText);
                if (xhr.status >= 200 && xhr.status < 300 && data.success) {
                    if (onSuccess) onSuccess(data);
                } else {
                    if (onError) onError(data && data.error ? data.error : 'خطای سرور');
                }
            } catch (e) {
                if (onError) onError('پاسخ نامعتبر سرور');
            }
        };
        xhr.send(JSON.stringify(payload || {}));
    }

    /**
     * نمایش پیام وضعیت ذخیره
     */
    function setSaveStatus(message, type) {
        if (!saveStatus) return;
        saveStatus.textContent = message;
        saveStatus.className = 'sitecare-status';
        if (type === 'success') saveStatus.classList.add('is-success');
        else if (type === 'error') saveStatus.classList.add('is-error');
        else if (type === 'loading') saveStatus.classList.add('is-loading');
    }

    /**
     * آپدیت pill وضعیت و متن دکمه toggle
     */
    function updateUI(isEnabled) {
        state.enabled = isEnabled ? '1' : '0';
        if (statusPill) {
            statusPill.textContent = isEnabled ? 'فعال' : 'غیرفعال';
            statusPill.className = 'tr-pill' + (isEnabled ? ' tr-pill-accent' : '');
        }
        if (toggleBtn) {
            toggleBtn.textContent = isEnabled ? 'خاموش کردن حالت نگهداری' : 'روشن کردن حالت نگهداری';
            toggleBtn.className = 'btn ' + (isEnabled ? 'btn-warn' : 'primary');
        }
    }

    /**
     * آپدیت زنده شمارنده
     */
    function updateLiveCountdown() {
        if (!liveHours || !liveMinutes || !liveSeconds) return;
        if (state.enabled !== '1' || totalSeconds <= 0) return;
        if (remaining <= 0) {
            liveHours.textContent = '۰۰';
            liveMinutes.textContent = '۰۰';
            liveSeconds.textContent = '۰۰';
            return;
        }
        var h = Math.floor(remaining / 3600);
        var m = Math.floor((remaining % 3600) / 60);
        var s = remaining % 60;
        liveHours.textContent = toPersian(pad(h));
        liveMinutes.textContent = toPersian(pad(m));
        liveSeconds.textContent = toPersian(pad(s));
    }

    /**
     * محاسبه ثانیه‌های باقی‌مانده بر اساس زمان شروع
     */
    function recomputeRemaining() {
        if (totalSeconds <= 0 || startedAt <= 0) {
            remaining = totalSeconds;
            return;
        }
        var now = Math.floor(Date.now() / 1000);
        var elapsed = Math.max(0, now - startedAt);
        remaining = Math.max(0, totalSeconds - elapsed);
    }

    /**
     * هندلر دکمه toggle
     */
    function handleToggle() {
        var newEnabled = state.enabled !== '1';
        if (newEnabled) {
            // در حال روشن شدن
            post(urls.toggle, { enabled: '1' }, function (data) {
                state.enabled = '1';
                state.countdownStartedAt = data.countdownStartedAt || Math.floor(Date.now() / 1000);
                startedAt = state.countdownStartedAt;
                recomputeRemaining();
                updateUI(true);
                updateLiveCountdown();
                // reload صفحه برای نمایش بخش وضعیت زنده
                setTimeout(function () { window.location.reload(); }, 800);
            }, function (err) {
                setSaveStatus(lang.toggleError || 'خطا', 'error');
            });
        } else {
            // در حال خاموش شدن
            if (!confirm(lang.confirmOff || 'آیا مطمئن هستید؟')) return;
            post(urls.toggle, { enabled: '0' }, function (data) {
                state.enabled = '0';
                updateUI(false);
                setSaveStatus(lang.toggleOff || 'غیرفعال شد', 'success');
                setTimeout(function () { window.location.reload(); }, 800);
            }, function (err) {
                setSaveStatus(lang.toggleError || 'خطا', 'error');
            });
        }
    }

    /**
     * هندلر دکمه ذخیره
     */
    function handleSave() {
        if (saveBtn) {
            saveBtn.disabled = true;
            saveBtn.textContent = lang.saving || 'در حال ذخیره...';
        }
        setSaveStatus(lang.saving || 'در حال ذخیره...', 'loading');

        var settings = gatherSettings();
        post(urls.save, settings, function (data) {
            if (saveBtn) {
                saveBtn.disabled = false;
                saveBtn.textContent = 'ذخیره تنظیمات';
            }
            setSaveStatus(lang.saved || 'ذخیره شد', 'success');
            // آپدیت state از پاسخ سرور
            if (data.settings) {
                state.enabled = data.settings.enabled || state.enabled;
                state.countdownStartedAt = parseInt(data.settings.countdownStartedAt, 10) || 0;
                startedAt = state.countdownStartedAt;
                totalSeconds = (parseInt(data.settings.countdownHours, 10) || 0) * 3600
                              + (parseInt(data.settings.countdownMinutes, 10) || 0) * 60
                              + (parseInt(data.settings.countdownSeconds, 10) || 0);
                if (typeof data.remaining === 'number') {
                    remaining = data.remaining;
                } else {
                    recomputeRemaining();
                }
                updateUI(state.enabled === '1');
                updateLiveCountdown();
            }
            setTimeout(function () {
                if (saveStatus) saveStatus.textContent = '';
            }, 3000);
        }, function (err) {
            if (saveBtn) {
                saveBtn.disabled = false;
                saveBtn.textContent = 'ذخیره تنظیمات';
            }
            setSaveStatus(lang.saveError || 'خطا در ذخیره', 'error');
        });
    }

    /**
     * هندلر دکمه ریست شمارنده
     */
    function handleReset() {
        if (!resetBtn) return;
        if (!confirm('شمارنده از ابتدا شمارش شود؟')) return;
        resetBtn.disabled = true;
        post(urls.reset, {}, function (data) {
            startedAt = data.countdownStartedAt || Math.floor(Date.now() / 1000);
            state.countdownStartedAt = startedAt;
            remaining = totalSeconds;
            updateLiveCountdown();
            resetBtn.disabled = false;
            setSaveStatus(lang.resetDone || 'ریست شد', 'success');
            setTimeout(function () { if (saveStatus) saveStatus.textContent = ''; }, 3000);
        }, function (err) {
            resetBtn.disabled = false;
            setSaveStatus(lang.resetError || 'خطا', 'error');
        });
    }

    /**
     * محدودسازی ورودی اعداد
     */
    function bindNumberConstraint(input, min, max) {
        if (!input) return;
        input.addEventListener('input', function () {
            var v = parseInt(input.value, 10);
            if (isNaN(v)) v = min;
            if (v < min) v = min;
            if (v > max) v = max;
            input.value = v;
        });
    }

    // ثبت رویدادها
    if (toggleBtn) toggleBtn.addEventListener('click', handleToggle);
    if (saveBtn) saveBtn.addEventListener('click', handleSave);
    if (resetBtn) resetBtn.addEventListener('click', handleReset);

    bindNumberConstraint(hoursInput, 0, 720);
    bindNumberConstraint(minutesInput, 0, 59);
    bindNumberConstraint(secondsInput, 0, 59);

    // آپدیت زنده شمارنده هر ثانیه
    recomputeRemaining();
    updateLiveCountdown();
    setInterval(function () {
        if (state.enabled !== '1' || totalSeconds <= 0) return;
        if (remaining <= 0) return;
        remaining -= 1;
        updateLiveCountdown();
    }, 1000);
})();
