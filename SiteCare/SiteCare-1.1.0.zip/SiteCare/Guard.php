<?php
declare(strict_types=1);

namespace TypechoPlugin\SiteCare;

use Typecho\Common;
use Typecho\Response;
use Utils\Helper;
use Widget\User;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * کنترل دسترسی و رندر صفحه نگهداری
 *
 * این کلاس در ابتدای هر درخواست front-end اجرا می‌شود و در صورت
 * فعال بودن حالت نگهداری، صفحه اختصاصی را نمایش می‌دهد.
 *
 * اگر شمارنده معکوس به پایان رسیده باشد، حالت نگهداری به‌صورت
 * خودکار خاموش می‌شود و درخواست به‌صورت عادی ادامه می‌یابد تا
 * سایت در دسترس قرار گیرد.
 */
class Guard
{
    /**
     * نقطه ورود hook - در ابتدای هر درخواست اجرا می‌شود
     */
    public static function boot(): void
    {
        $settings = Settings::load();

        // پیش‌نمایش: مدیر می‌تواند با ?sitecare_preview=1 صفحه را ببیند
        // حتی اگر حالت نگهداری فعال نباشد
        $isPreview = (string) ($_GET['sitecare_preview'] ?? '') === '1';
        if ($isPreview && User::alloc()->pass('administrator', true)) {
            self::render($settings);
            return;
        }

        if ((string) $settings['enabled'] !== '1') {
            return;
        }

        // اگر شمارنده معکوس به پایان رسیده باشد، حالت نگهداری را
        // به‌صورت خودکار خاموش کن و اجازه بده درخواست به‌صورت عادی
        // ادامه پیدا کند تا سایت در دسترس قرار گیرد.
        if (self::countdownExpired($settings)) {
            Settings::autoDisable();
            return;
        }

        // مدیران وارد شده سایت را به‌صورت عادی می‌بینند
        if (User::alloc()->pass('administrator', true)) {
            return;
        }

        // مسیر admin و action همیشه در دسترس باشند
        $path = self::requestPath();
        if (self::isAllowedPath($path)) {
            return;
        }

        // نشانه‌گذاری endpoint خود افزونه (برای toggle و ... )
        if (self::isOwnActionPath($path)) {
            return;
        }

        // اجازه دسترسی به فایل‌های استاتیک افزونه‌ها (مثل فونت خود این افزونه)
        if (self::isPluginAssetPath($path)) {
            return;
        }

        // در غیر این صورت، صفحه نگهداری را نمایش بده
        self::render($settings);
    }

    /**
     * مسیر درخواست فعلی
     */
    private static function requestPath(): string
    {
        $uri = (string) ($_SERVER['REQUEST_URI'] ?? '');
        $path = parse_url($uri, PHP_URL_PATH);
        return $path ?: '/';
    }

    /**
     * آیا مسیر در لیست مسیرهای مجاز است؟
     */
    private static function isAllowedPath(string $path): bool
    {
        $options = Helper::options();

        // مسیر پنل مدیریت
        $adminUrl = (string) $options->adminUrl;
        $adminPath = (string) (parse_url($adminUrl, PHP_URL_PATH) ?: '');
        if ($adminPath !== '' && $adminPath !== '/' && str_starts_with($path, $adminPath)) {
            return true;
        }

        // مسیر اکشن‌ها (/index.php/action/...)
        $actionBase = Common::url('action', (string) $options->index);
        $actionPath = (string) (parse_url($actionBase, PHP_URL_PATH) ?: '');
        if ($actionPath !== '' && str_starts_with($path, $actionPath)) {
            return true;
        }

        // مسیر فایل XML-RPC (برای اپ‌های موبایل) - اگر وجود داشته باشد
        try {
            $xmlRpcUrl = (string) $options->xmlRpcUrl;
        } catch (\Throwable $e) {
            $xmlRpcUrl = '';
        }
        if ($xmlRpcUrl !== '') {
            $xmlRpcPath = rtrim((string) (parse_url($xmlRpcUrl, PHP_URL_PATH) ?: ''), '/');
            if ($xmlRpcPath !== '' && $path === $xmlRpcPath) {
                return true;
            }
        }

        return false;
    }

    /**
     * آیا مسیر به endpoint خود این افزونه اشاره دارد؟
     */
    private static function isOwnActionPath(string $path): bool
    {
        $ownPath = Common::url('action/site-care', (string) Helper::options()->index);
        $ownPathParsed = parse_url($ownPath, PHP_URL_PATH);
        return $ownPathParsed !== false && str_starts_with($path, (string) $ownPathParsed);
    }

    /**
     * آیا مسیر به یک asset از افزونه‌ها اشاره دارد؟
     */
    private static function isPluginAssetPath(string $path): bool
    {
        $pluginUrl = (string) Helper::options()->pluginUrl;
        $pluginPath = parse_url($pluginUrl, PHP_URL_PATH);
        return $pluginPath !== false && $pluginPath !== '' && str_starts_with($path, $pluginPath);
    }

    /**
     * آیا شمارنده معکوس به پایان رسیده است؟
     *
     * اگر هیچ شمارنده‌ای تنظیم نشده باشد (همه مقادیر صفر)،
     * حالت نگهداری تا خاموش شدن دستی فعال می‌ماند.
     */
    private static function countdownExpired(array $settings): bool
    {
        $total = self::totalCountdownSeconds($settings);
        $startedAt = (int) ($settings['countdownStartedAt'] ?? 0);
        if ($total <= 0 || $startedAt <= 0) {
            return false;
        }
        return (time() - $startedAt) >= $total;
    }

    /**
     * رندر صفحه نگهداری
     */
    public static function render(array $settings): void
    {
        // پاک کردن همه‌ی output bufferها تا هدرها به‌درستی ارسال بشن
        // و هیچ خروجی اضافی قبل از صفحه نگهداری نمایش داده نشه
        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        $response = Response::getInstance();
        $response->setStatus(503);
        $response->setHeader('Content-Type', 'text/html; charset=UTF-8');
        $response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $response->setHeader('X-SiteCare', 'maintenance');

        // Retry-After بر اساس مدت کل شمارنده
        $totalSecs = self::totalCountdownSeconds($settings);
        $retryAfter = $totalSecs > 0 ? min($totalSecs, 86400) : 3600;
        $response->setHeader('Retry-After', (string) $retryAfter);

        // محاسبه زمان باقی‌مانده شمارنده
        $remaining = self::remainingSeconds($settings);

        // متغیرهایی که در template استفاده می‌شوند
        $pageTitle = (string) ($settings['title'] ?? 'در حال تعمیر و نگهداری');
        $siteTitle = (string) Helper::options()->title;
        $message = (string) ($settings['message'] ?? '');
        $adminUrl = (string) Helper::options()->adminUrl;
        $homeUrl = (string) Helper::options()->siteUrl;
        $fontUrl = Plugin::assetUrl('assets/fonts/');
        $showAdminLink = (string) ($settings['showAdminLink'] ?? '1') === '1';
        $animateIcon = (string) ($settings['animateIcon'] ?? '1') === '1';
        $countdownEnabled = (string) ($settings['countdownEnabled'] ?? '1') === '1';
        $remainingSeconds = $remaining;
        $totalSeconds = $totalSecs;

        // آیا در حالت پیش‌نمایش مدیر هستیم؟ (در پیش‌نمایش رفرش خودکار انجام نمی‌شود)
        $isPreview = (string) ($_GET['sitecare_preview'] ?? '') === '1';

        // تبدیل اعداد فارسی برای نمایش اولیه (در صورت فعال بودن JS هم به‌روزرسانی می‌شود)
        $initialHours = Plugin::toPersianDigits((int) floor($remaining / 3600));
        $initialMinutes = Plugin::toPersianDigits((int) floor(($remaining % 3600) / 60));
        $initialSeconds = Plugin::toPersianDigits((int) ($remaining % 60));

        include __DIR__ . '/view/maintenance.php';
        exit;
    }

    /**
     * کل ثانیه‌های شمارنده
     */
    private static function totalCountdownSeconds(array $settings): int
    {
        $hours = (int) ($settings['countdownHours'] ?? 0);
        $minutes = (int) ($settings['countdownMinutes'] ?? 0);
        $seconds = (int) ($settings['countdownSeconds'] ?? 0);
        return $hours * 3600 + $minutes * 60 + $seconds;
    }

    /**
     * ثانیه‌های باقی‌مانده از شمارنده
     */
    private static function remainingSeconds(array $settings): int
    {
        $total = self::totalCountdownSeconds($settings);
        $startedAt = (int) ($settings['countdownStartedAt'] ?? 0);
        if ($total <= 0) {
            return 0;
        }
        if ($startedAt <= 0) {
            return $total;
        }
        $elapsed = time() - $startedAt;
        return max(0, $total - $elapsed);
    }
}
