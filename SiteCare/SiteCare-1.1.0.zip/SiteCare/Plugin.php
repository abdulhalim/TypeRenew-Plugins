<?php
declare(strict_types=1);

namespace TypechoPlugin\SiteCare;

use Typecho\Common;
use Typecho\Plugin as Hook;
use Typecho\Plugin\PluginInterface;
use Typecho\Widget\Helper\Form;
use Utils\Helper;
use Utils\NoPersonal;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * افزونه حالت تعمیر و نگهداری
 *
 * @package SiteCare
 * @author پوردریایی
 * @link https://pourdaryaei.ir
 * @version 1.1.0
 * @since 1.6.0
 */
class Plugin implements PluginInterface
{
    use NoPersonal;

    public const NAME = 'SiteCare';
    public const CACHE_KEY = 'sitecare:settings:v1';

    /**
     * فعال‌سازی افزونه
     */
    public static function activate(): string
    {
        Settings::ensureStored();
        self::registerHooks();

        // پاک‌سازی باقی‌مانده‌های نسخه قبلی RenewCare (اگر بدون غیرفعال‌سازی حذف شده باشد)
        Helper::removeRoute('renew_care_action');
        Helper::removePanel(3, 'RenewCare/Panel.php');

        Helper::removeRoute('site_care_action');
        Helper::addRoute('site_care_action', '/action/site-care', Action::class, 'action');

        Helper::removePanel(3, 'SiteCare/Panel.php');
        Helper::addPanel(
            3,
            'SiteCare/Panel.php',
            'حالت نگهداری',
            'حالت نگهداری سایت',
            'administrator',
            false,
            '',
            ['icon' => 'i-settings']
        );

        Settings::clearCache();
        return _t('افزونه SiteCare فعال شد. می‌توانید حالت نگهداری را از پنل مدیریت کنترل کنید.');
    }

    /**
     * غیرفعال‌سازی افزونه
     */
    public static function deactivate(): string
    {
        Helper::removeRoute('site_care_action');
        Helper::removePanel(3, 'SiteCare/Panel.php');
        Settings::clearCache();
        return _t('افزونه SiteCare غیرفعال شد.');
    }

    /**
     * تنظیمات قابل نمایش در صفحه تنظیمات افزونه
     * (فقط وضعیت on/off، بقیه تنظیمات در پنل اختصاصی)
     */
    public static function config(Form $form): void
    {
        $settings = Settings::load();

        $enabled = new Form\Element\Radio(
            'enabled',
            ['1' => _t('فعال'), '0' => _t('غیرفعال')],
            (string) $settings['enabled'],
            _t('وضعیت حالت نگهداری'),
            _t('برای پیکربندی پیام، شمارنده معکوس و سایر گزینه‌ها از «حالت نگهداری» در منوی افزونه‌ها استفاده کنید.')
        );
        $form->addInput($enabled);

        // سایر تنظیمات به‌صورت hidden نگه داشته می‌شوند تا هنگام ذخیره از بین نروند
        foreach (Settings::defaults() as $key => $default) {
            if ($key === 'enabled') {
                continue;
            }
            $form->addInput(new Form\Element\Hidden(
                $key,
                null,
                (string) ($settings[$key] ?? $default)
            ));
        }
    }

    /**
     * ذخیره تنظیمات از فرم پیکربندی استاندارد
     */
    public static function configHandle(array $settings, bool $_isInit): void
    {
        $current = Settings::load();
        Settings::store(array_merge($current, $settings));
    }

    /**
     * ثبت hookهای افزونه
     */
    private static function registerHooks(): void
    {
        // اجرا در ابتدای هر درخواست front-end
        Hook::factory('index.php')->begin = [Guard::class, 'boot'];
    }

    /**
     * ساخت URL برای assetهای پلاگین
     */
    public static function assetUrl(string $path): string
    {
        return Common::url(self::NAME . '/' . ltrim($path, '/'), Helper::options()->pluginUrl);
    }

    /**
     * ساخت URL برای endpoint اکشن پلاگین با توکن امنیتی
     */
    public static function apiUrl(string $do): string
    {
        $path = Common::url('action/site-care?do=' . rawurlencode($do), Helper::options()->index);
        return \Widget\Security::alloc()->getTokenUrl($path, 'site-care-admin');
    }

    /**
     * تبدیل اعداد انگلیسی به فارسی
     */
    public static function toPersianDigits(string|int $value): string
    {
        $map = ['0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
                '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹'];
        return strtr((string) $value, $map);
    }
}
