<?php
/**
 * صفحه تعمیر و نگهداری - سبک Minimal نور با پالت اسلیت-رز
 *
 * متغیرهای موجود (همگی از Guard::render پاس داده می‌شوند):
 * @var string $pageTitle       عنوان صفحه (از تنظیمات مدیر)
 * @var string $siteTitle        عنوان سایت
 * @var string $message          پیام مدیر
 * @var string $adminUrl         URL ورود مدیر
 * @var string $homeUrl          URL صفحه اصلی
 * @var string $fontUrl          URL پوشه فونت (برای @font-face)
 * @var string $iconsUrl         URL فایل اسپرایت آیکون Lucide
 * @var bool   $showAdminLink    آیا لینک مدیر نمایش داده شود
 * @var bool   $animateIcon      آیا آیکون انیمیشن داشته باشد
 * @var bool   $countdownEnabled آیا شمارنده فعال باشد
 * @var int    $remainingSeconds ثانیه‌های باقی‌مانده شمارنده
 * @var int    $totalSeconds     کل ثانیه‌های شمارنده
 * @var string $initialHours     نمایش فارسی ساعت اولیه
 * @var string $initialMinutes   نمایش فارسی دقیقه اولیه
 * @var string $initialSeconds   نمایش فارسی ثانیه اولیه
 * @var bool   $isPreview        آیا در حالت پیش‌نمایش مدیر هستیم
 */
if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
$escape = static function ($value): string {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
};
$messageHtml = $message;

// رفرش خودکار برای مرورگرهای بدون جاوااسکریپت:
// در لحظه پایان شمارنده صفحه رفرش می‌شود؛ سرور حالت نگهداری را
// خودکار خاموش کرده و سایت اصلی نمایش داده می‌شود.
$refreshSecs = 0;
if ($totalSeconds > 0 && empty($isPreview)) {
    $refreshSecs = $remainingSeconds > 0 ? (int) $remainingSeconds : 30;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
    <meta name="robots" content="noindex, nofollow, noarchive">
    <meta name="theme-color" content="#fafafa">
    <title><?php echo $escape($pageTitle); ?> — <?php echo $escape($siteTitle); ?></title>
    <?php if ($refreshSecs > 0): ?><meta http-equiv="refresh" content="<?php echo (int) $refreshSecs; ?>"><?php endif; ?>
    <style>
        /* فونت Vazirmatn به‌صورت embed شده در پلاگین */
        @font-face {
            font-family: 'Vazirmatn';
            src: url('<?php echo $escape($fontUrl); ?>Vazirmatn-Regular.woff2') format('woff2');
            font-weight: 400;
            font-style: normal;
            font-display: swap;
        }
        @font-face {
            font-family: 'Vazirmatn';
            src: url('<?php echo $escape($fontUrl); ?>Vazirmatn-Medium.woff2') format('woff2');
            font-weight: 500;
            font-style: normal;
            font-display: swap;
        }
        @font-face {
            font-family: 'Vazirmatn';
            src: url('<?php echo $escape($fontUrl); ?>Vazirmatn-Bold.woff2') format('woff2');
            font-weight: 700;
            font-style: normal;
            font-display: swap;
        }

        :root {
            /* پالت اسلیت-رز - سبک Minimal نور */
            --rc-bg: #fafafa;
            --rc-bg-soft: #f1f5f9;
            --rc-surface: #ffffff;
            --rc-fg: #0f172a;       /* slate-900 */
            --rc-fg-soft: #334155;  /* slate-700 */
            --rc-muted: #64748b;    /* slate-500 */
            --rc-faint: #94a3b8;    /* slate-400 */
            --rc-border: #e2e8f0;   /* slate-200 */
            --rc-border-soft: #f1f5f9;
            --rc-accent: #e11d48;   /* rose-600 */
            --rc-accent-soft: #fff1f2; /* rose-50 */
            --rc-accent-border: #fecdd3; /* rose-200 */
            --rc-radius: 24px;
            --rc-radius-sm: 14px;
            --rc-shadow-sm: 0 1px 2px rgba(15, 23, 42, 0.04), 0 1px 3px rgba(15, 23, 42, 0.06);
            --rc-shadow-md: 0 4px 6px -1px rgba(15, 23, 42, 0.05), 0 10px 30px -10px rgba(15, 23, 42, 0.08);
            --rc-shadow-lg: 0 20px 50px -20px rgba(15, 23, 42, 0.15), 0 8px 16px -8px rgba(15, 23, 42, 0.06);
        }

        @media (prefers-color-scheme: dark) {
            :root {
                --rc-bg: #0a0e1a;
                --rc-bg-soft: #0f172a;
                --rc-surface: #111827;
                --rc-fg: #f8fafc;
                --rc-fg-soft: #e2e8f0;
                --rc-muted: #94a3b8;
                --rc-faint: #64748b;
                --rc-border: #1f2937;
                --rc-border-soft: #111827;
                --rc-accent: #fb7185;
                --rc-accent-soft: rgba(225, 29, 72, 0.10);
                --rc-accent-border: rgba(225, 29, 72, 0.25);
                --rc-shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.4);
                --rc-shadow-md: 0 10px 30px -10px rgba(0, 0, 0, 0.5);
                --rc-shadow-lg: 0 30px 60px -20px rgba(0, 0, 0, 0.6);
            }
        }

        * { box-sizing: border-box; }
        *::before, *::after { box-sizing: border-box; }

        html, body {
            margin: 0;
            padding: 0;
        }

        body {
            min-height: 100vh;
            font-family: 'Vazirmatn', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: var(--rc-bg);
            color: var(--rc-fg);
            line-height: 1.6;
            font-weight: 400;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            text-rendering: optimizeLegibility;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 32px 20px;
            position: relative;
            overflow-x: hidden;
        }

        /* پس‌زمینه: blob‌های ملایم برای عمق بصری */
        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background:
                radial-gradient(900px 600px at 85% 110%, rgba(225, 29, 72, 0.05), transparent 60%),
                radial-gradient(800px 500px at 5% -10%, rgba(71, 85, 105, 0.04), transparent 60%);
            pointer-events: none;
            z-index: 0;
        }

        .rc-wrap {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 720px;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        /* آیکون بزرگ مرکزی */
        .rc-icon-wrap {
            width: 120px;
            height: 120px;
            border-radius: 32px;
            background: var(--rc-surface);
            border: 1px solid var(--rc-border);
            box-shadow: var(--rc-shadow-md);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 32px;
            position: relative;
        }
        .rc-icon-wrap::after {
            content: '';
            position: absolute;
            inset: -2px;
            border-radius: 32px;
            background: linear-gradient(135deg, var(--rc-accent), transparent 60%);
            opacity: 0.08;
            z-index: -1;
            pointer-events: none;
        }

        .rc-icon {
            width: 64px;
            height: 64px;
            color: var(--rc-accent);
            stroke-width: 1.5;
        }

        /* انیمیشن چرخش آیکون */
        @keyframes rc-spin {
            from { transform: rotate(0deg); }
            to   { transform: rotate(360deg); }
        }
        .rc-icon-spin {
            animation: rc-spin 8s linear infinite;
            transform-origin: center;
        }
        @media (prefers-reduced-motion: reduce) {
            .rc-icon-spin {
                animation: none;
            }
        }

        /* برچسب وضعیت */
        .rc-status-pill {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 14px;
            background: var(--rc-accent-soft);
            border: 1px solid var(--rc-accent-border);
            color: var(--rc-accent);
            border-radius: 999px;
            font-size: 13px;
            font-weight: 500;
            margin-bottom: 20px;
        }
        .rc-status-pill::before {
            content: '';
            width: 7px;
            height: 7px;
            background: var(--rc-accent);
            border-radius: 50%;
            box-shadow: 0 0 0 4px color-mix(in srgb, var(--rc-accent) 25%, transparent);
        }

        /* عنوان اصلی */
        .rc-title {
            font-size: clamp(28px, 5vw, 40px);
            font-weight: 700;
            color: var(--rc-fg);
            margin: 0 0 16px 0;
            line-height: 1.2;
            letter-spacing: -0.02em;
        }

        /* پیام مدیر */
        .rc-message {
            font-size: 16px;
            line-height: 1.8;
            color: var(--rc-muted);
            max-width: 540px;
            margin: 0 0 40px 0;
            white-space: pre-wrap;
            word-break: break-word;
        }
        .rc-message:empty { display: none; }
        .rc-message a {
            color: var(--rc-accent);
            text-decoration: none;
            border-bottom: 1px solid color-mix(in srgb, var(--rc-accent) 40%, transparent);
            transition: border-color .18s ease;
        }
        .rc-message a:hover {
            border-bottom-color: var(--rc-accent);
        }
        .rc-message strong, .rc-message b { color: var(--rc-fg); font-weight: 700; }
        .rc-message em, .rc-message i { font-style: italic; }

        /* شمارنده معکوس */
        .rc-countdown {
            display: <?php echo $countdownEnabled && $totalSeconds > 0 ? 'flex' : 'none'; ?>;
            gap: 16px;
            margin: 0 0 40px 0;
            width: 100%;
            justify-content: center;
            flex-wrap: wrap;
        }

        .rc-count-block {
            min-width: 110px;
            flex: 1 1 110px;
            max-width: 180px;
            background: var(--rc-surface);
            border: 1px solid var(--rc-border);
            border-radius: var(--rc-radius-sm);
            padding: 24px 12px;
            box-shadow: var(--rc-shadow-sm);
            transition: transform .2s ease, box-shadow .2s ease;
        }
        .rc-count-block:hover {
            transform: translateY(-2px);
            box-shadow: var(--rc-shadow-md);
        }

        .rc-count-num {
            font-size: clamp(40px, 8vw, 56px);
            font-weight: 700;
            color: var(--rc-fg);
            line-height: 1;
            font-variant-numeric: tabular-nums;
            letter-spacing: -0.03em;
            margin-bottom: 8px;
            font-feature-settings: 'ss01';
        }
        .rc-count-num.is-final {
            color: var(--rc-accent);
        }

        .rc-count-label {
            font-size: 13px;
            color: var(--rc-muted);
            font-weight: 500;
            margin: 0;
        }

        /* نوار پیشرفت پایین شمارنده */
        .rc-progress-wrap {
            width: 100%;
            max-width: 540px;
            margin: 0 0 32px 0;
            display: <?php echo $countdownEnabled && $totalSeconds > 0 ? 'block' : 'none'; ?>;
        }
        .rc-progress-bar {
            width: 100%;
            height: 4px;
            background: var(--rc-border-soft);
            border-radius: 999px;
            overflow: hidden;
            position: relative;
        }
        .rc-progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--rc-accent), color-mix(in srgb, var(--rc-accent) 60%, #fb7185));
            border-radius: 999px;
            transition: width .5s ease;
        }
        .rc-progress-text {
            font-size: 12px;
            color: var(--rc-faint);
            margin-top: 8px;
            text-align: center;
        }

        /* پیام پایان شمارش معکوس */
        .rc-done-msg {
            display: none;
            background: var(--rc-accent-soft);
            border: 1px solid var(--rc-accent-border);
            color: var(--rc-accent);
            padding: 16px 24px;
            border-radius: var(--rc-radius-sm);
            margin-bottom: 32px;
            font-weight: 500;
            font-size: 15px;
        }
        .rc-done-msg.is-visible {
            display: block;
        }

        /* لینک ورود مدیر */
        .rc-admin-link {
            display: <?php echo $showAdminLink ? 'inline-flex' : 'none'; ?>;
            align-items: center;
            gap: 6px;
            color: var(--rc-faint);
            font-size: 13px;
            text-decoration: none;
            padding: 8px 14px;
            border-radius: 999px;
            transition: color .2s ease, background .2s ease;
        }
        .rc-admin-link:hover {
            color: var(--rc-fg-soft);
            background: var(--rc-bg-soft);
        }
        .rc-admin-link svg {
            width: 14px;
            height: 14px;
            stroke-width: 2;
        }

        /* فوتر */
        .rc-footer {
            margin-top: 48px;
            padding-top: 24px;
            border-top: 1px solid var(--rc-border);
            width: 100%;
            max-width: 540px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            flex-wrap: wrap;
            color: var(--rc-faint);
            font-size: 12px;
        }
        .rc-footer-brand {
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .rc-footer-brand svg {
            width: 14px;
            height: 14px;
            color: var(--rc-accent);
        }

        /* ریسپانسیو */
        @media (max-width: 540px) {
            .rc-countdown {
                gap: 10px;
            }
            .rc-count-block {
                min-width: 88px;
                padding: 18px 8px;
            }
            .rc-icon-wrap {
                width: 96px;
                height: 96px;
                border-radius: 24px;
            }
            .rc-icon {
                width: 48px;
                height: 48px;
            }
            .rc-footer {
                flex-direction: column;
                text-align: center;
            }
        }

        /* حالت réduire motion */
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.01ms !important;
                transition-duration: 0.01ms !important;
            }
        }
    </style>
</head>
<body>

<!-- اسپرایت آیکون Lucide -->
<svg width="0" height="0" style="position:absolute" aria-hidden="true">
    <defs>
        <!-- آیکون چرخ‌دنده (settings) - Lucide -->
        <symbol id="rc-i-settings" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/>
            <circle cx="12" cy="12" r="3"/>
        </symbol>
        <!-- آیکون قفل (admin login) - Lucide -->
        <symbol id="rc-i-lock" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect width="18" height="11" x="3" y="11" rx="2" ry="2"/>
            <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
        </symbol>
        <!-- آیکون همبستگی (heart) - برای فوتر -->
        <symbol id="rc-i-heart" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>
        </symbol>
        <!-- آیکون چک (check-circle) - برای پایان شمارش -->
        <symbol id="rc-i-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21.801 10A10 10 0 1 1 17 3.335"/>
            <path d="m9 11 3 3L22 4"/>
        </symbol>
    </defs>
</svg>

<div class="rc-wrap">

    <!-- آیکون بزرگ مرکزی -->
    <div class="rc-icon-wrap">
        <svg class="rc-icon<?php echo $animateIcon ? ' rc-icon-spin' : ''; ?>" aria-hidden="true">
            <use href="#rc-i-settings"></use>
        </svg>
    </div>

    <!-- برچسب وضعیت -->
    <span class="rc-status-pill">حالت نگهداری فعال است</span>

    <!-- عنوان صفحه -->
    <h1 class="rc-title"><?php echo $escape($pageTitle); ?></h1>

    <!-- پیام مدیر -->
    <p class="rc-message"><?php echo $messageHtml; ?></p>

    <!-- پیام پایان شمارش -->
    <div class="rc-done-msg" id="rcDoneMsg" role="status" aria-live="polite">
        <svg class="rc-i-inline" style="width:16px;height:16px;vertical-align:-3px;margin-left:6px"><use href="#rc-i-check"></use></svg>
        <?php _e('زمان تخمینی پایان رسید؛ در حال بازگردانی سایت...'); ?>
    </div>

    <!-- شمارنده معکوس -->
    <div class="rc-countdown" id="rcCountdown" role="timer" aria-live="off">
        <div class="rc-count-block">
            <div class="rc-count-num" id="rcHours" data-val="<?php echo (int) floor($remainingSeconds / 3600); ?>"><?php echo $escape($initialHours); ?></div>
            <p class="rc-count-label"><?php _e('ساعت'); ?></p>
        </div>
        <div class="rc-count-block">
            <div class="rc-count-num" id="rcMinutes" data-val="<?php echo (int) floor(($remainingSeconds % 3600) / 60); ?>"><?php echo $escape($initialMinutes); ?></div>
            <p class="rc-count-label"><?php _e('دقیقه'); ?></p>
        </div>
        <div class="rc-count-block">
            <div class="rc-count-num" id="rcSeconds" data-val="<?php echo (int) ($remainingSeconds % 60); ?>"><?php echo $escape($initialSeconds); ?></div>
            <p class="rc-count-label"><?php _e('ثانیه'); ?></p>
        </div>
    </div>

    <!-- نوار پیشرفت -->
    <div class="rc-progress-wrap" id="rcProgressWrap">
        <div class="rc-progress-bar">
            <div class="rc-progress-fill" id="rcProgressFill" style="width: 0%"></div>
        </div>
        <div class="rc-progress-text" id="rcProgressText"></div>
    </div>

    <!-- لینک ورود مدیر -->
    <?php if ($showAdminLink): ?>
    <a class="rc-admin-link" href="<?php echo $escape($adminUrl); ?>">
        <svg aria-hidden="true"><use href="#rc-i-lock"></use></svg>
        <span><?php _e('ورود مدیر'); ?></span>
    </a>
    <?php endif; ?>

    <!-- فوتر -->
    <div class="rc-footer">
        <span class="rc-footer-brand">
            <svg aria-hidden="true"><use href="#rc-i-heart"></use></svg>
            <span><?php echo $escape($siteTitle); ?></span>
        </span>
        <span><?php _e('صفحه نگهداری SiteCare'); ?></span>
    </div>
</div>

<script>
(function () {
    'use strict';

    var PER_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    function toPersian(n) {
        return String(n).replace(/\d/g, function (d) { return PER_DIGITS[+d]; });
    }
    function pad(n) {
        return n < 10 ? '0' + n : String(n);
    }

    // آیا در حالت پیش‌نمایش مدیر هستیم؟ (در پیش‌نمایش رفرش خودکار انجام نمی‌شود)
    var isPreview = <?php echo !empty($isPreview) ? 'true' : 'false'; ?>;

    // مقادیر اولیه از data attribute
    var hoursEl   = document.getElementById('rcHours');
    var minutesEl = document.getElementById('rcMinutes');
    var secondsEl = document.getElementById('rcSeconds');
    var countdown = document.getElementById('rcCountdown');
    var progressFill = document.getElementById('rcProgressFill');
    var progressText = document.getElementById('rcProgressText');
    var progressWrap = document.getElementById('rcProgressWrap');
    var doneMsg = document.getElementById('rcDoneMsg');

    // کل زمان شمارنده از سرور (همیشه ثابت)
    var initialTotal = <?php echo (int) $totalSeconds; ?>;
    // زمان باقی‌مانده (محاسبه از data-val)
    var totalRemaining = parseInt(hoursEl ? hoursEl.getAttribute('data-val') : '0', 10) * 3600
                       + parseInt(minutesEl ? minutesEl.getAttribute('data-val') : '0', 10) * 60
                       + parseInt(secondsEl ? secondsEl.getAttribute('data-val') : '0', 10);

    if (!countdown || initialTotal <= 0) {
        if (progressWrap) progressWrap.style.display = 'none';
        return;
    }

    // زمان پایان بر اساس ساعت واقعی مرورگر؛ این‌طوری تب‌های غیر فعال
    // (که تایمرشان کند می‌شود) هم دقیق در لحظه پایان همگام می‌شوند.
    var endTime = Math.floor(Date.now() / 1000) + totalRemaining;

    function remainingNow() {
        return Math.max(0, endTime - Math.floor(Date.now() / 1000));
    }

    function render() {
        if (totalRemaining <= 0) {
            hoursEl.textContent = toPersian('00');
            minutesEl.textContent = toPersian('00');
            secondsEl.textContent = toPersian('00');
            hoursEl.classList.add('is-final');
            minutesEl.classList.add('is-final');
            secondsEl.classList.add('is-final');
            if (doneMsg) doneMsg.classList.add('is-visible');
            if (progressFill) progressFill.style.width = '100%';
            if (progressText) progressText.textContent = toPersian(100) + '٪ کامل شد';
            return;
        }

        var h = Math.floor(totalRemaining / 3600);
        var m = Math.floor((totalRemaining % 3600) / 60);
        var s = totalRemaining % 60;

        if (hoursEl)   hoursEl.textContent   = toPersian(pad(h));
        if (minutesEl) minutesEl.textContent = toPersian(pad(m));
        if (secondsEl) secondsEl.textContent = toPersian(pad(s));

        // نوار پیشرفت: elapsed = total - remaining
        var elapsed = initialTotal - totalRemaining;
        var pct = initialTotal > 0 ? (elapsed / initialTotal) * 100 : 0;
        if (progressFill) progressFill.style.width = pct.toFixed(2) + '%';
        if (progressText) {
            var pctInt = Math.round(pct);
            progressText.textContent = toPersian(pctInt) + '٪ کامل شد';
        }
    }

    /**
     * درخواست رفرش فوری صفحه همراه با محافظ ضد حلقه:
     * اگر صفحه بعد از رفرش هنوز صفحه نگهداری بود، به‌جای رفرش
     * بی‌درنگ، حداکثر یک بار در دقیقه تلاش می‌شود.
     */
    function requestReload() {
        if (isPreview) return;

        var KEY = 'sitecare-reload-at';
        var now = Date.now();
        var last = 0;
        try {
            last = parseInt(sessionStorage.getItem(KEY) || '0', 10) || 0;
        } catch (e) { /* sessionStorage در دسترس نیست */ }

        if (!last || now - last > 60000) {
            try { sessionStorage.setItem(KEY, String(now)); } catch (e) {}
            window.location.reload();
        } else {
            var wait = Math.max(5000, 60000 - (now - last));
            setTimeout(function () {
                try { sessionStorage.removeItem(KEY); } catch (e) {}
                requestReload();
            }, wait);
        }
    }

    function tick() {
        totalRemaining = remainingNow();
        render();

        if (totalRemaining <= 0) {
            clearInterval(timer);
            // پایان شمارنده: سرور حالت نگهداری را خودکار خاموش می‌کند،
            // بنابراین رفرش فوری سایت اصلی را نمایش می‌دهد.
            requestReload();
        }
    }

    // رندر اولیه
    render();

    // تایمر هر ثانیه
    var timer = setInterval(tick, 1000);

    // وقتی تب دوباره فعال شد، فوراً همگام‌سازی کن
    // (کاربر ممکن است تب را مدتی باز نگه داشته باشد)
    document.addEventListener('visibilitychange', function () {
        if (document.visibilityState === 'visible') {
            tick();
        }
    });
})();
</script>

</body>
</html>
