<?php
if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$user->pass('administrator');

$settings = TypechoPlugin\SiteCare\Settings::load();
$options = Utils\Helper::options();

// محاسبه کل ثانیه‌های شمارنده
$totalSeconds = (int) $settings['countdownHours'] * 3600
              + (int) $settings['countdownMinutes'] * 60
              + (int) $settings['countdownSeconds'];
$startedAt = (int) $settings['countdownStartedAt'];

// اگر شمارنده به پایان رسیده باشد، هم‌اکنون غیرفعال‌سازی خودکار را
// همگام‌سازی کن تا وضعیت پنل با واقعیت مطابقت داشته باشد
// (مسیرهای admin از Guard عبور نمی‌کنند).
if ((string) $settings['enabled'] === '1'
    && $totalSeconds > 0
    && $startedAt > 0
    && (time() - $startedAt) >= $totalSeconds) {
    TypechoPlugin\SiteCare\Settings::autoDisable();
    $settings = TypechoPlugin\SiteCare\Settings::load();
}

$isEnabled = (string) $settings['enabled'] === '1';

// محاسبه زمان باقی‌مانده شمارنده
$remaining = $totalSeconds;
if ($totalSeconds > 0 && $startedAt > 0) {
    $elapsed = max(0, time() - $startedAt);
    $remaining = max(0, $totalSeconds - $elapsed);
}

$urlSave   = TypechoPlugin\SiteCare\Plugin::apiUrl('save');
$urlToggle = TypechoPlugin\SiteCare\Plugin::apiUrl('toggle');
$urlReset  = TypechoPlugin\SiteCare\Plugin::apiUrl('reset');
$previewUrl = (string) $options->siteUrl . '?sitecare_preview=1';
$cssUrl    = TypechoPlugin\SiteCare\Plugin::assetUrl('assets/panel.css');
$jsUrl     = TypechoPlugin\SiteCare\Plugin::assetUrl('assets/panel.js');
?>
<link rel="stylesheet" href="<?php echo htmlspecialchars($cssUrl, ENT_QUOTES, 'UTF-8'); ?>">
<div class="tr-panel sitecare-panel" dir="rtl">

    <!-- کارت وضعیت و دکمه‌های سریع -->
    <section class="tr-card">
        <div class="tr-card-b">
            <div class="tr-panel-head">
                <div class="tr-panel-heading">
                    <h2 class="tr-panel-title"><?php _e('حالت نگهداری سایت'); ?></h2>
                    <p class="tr-panel-desc"><?php _e('با فعال‌سازی این حالت، سایت برای بازدیدکنندگان عادی به‌صورت موقت غیرفعال می‌شود و یک صفحه شکیل با پیام دلخواه شما و شمارنده معکوس نمایش داده می‌شود. مدیران وارد شده همچنان سایت را می‌بینند. با پایان رسیدن شمارنده، حالت نگهداری به‌صورت خودکار خاموش می‌شود و صفحه به‌صورت خودکار رفرش می‌گردد تا سایت در دسترس قرار گیرد.'); ?></p>
                </div>
                <div class="tr-panel-pills">
                    <span class="tr-pill<?php echo $isEnabled ? ' tr-pill-accent' : ''; ?>" id="sitecareStatusPill">
                        <?php echo $isEnabled ? _t('فعال') : _t('غیرفعال'); ?>
                    </span>
                </div>
            </div>

            <div class="sitecare-actions">
                <button id="sitecareToggleBtn" type="button"
                        class="btn <?php echo $isEnabled ? 'btn-warn' : 'primary'; ?>">
                    <?php echo $isEnabled ? _t('خاموش کردن حالت نگهداری') : _t('روشن کردن حالت نگهداری'); ?>
                </button>
                <a class="btn btn-sub" href="<?php echo htmlspecialchars($previewUrl, ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener noreferrer">
                    <?php _e('پیش‌نمایش صفحه'); ?>
                </a>
            </div>
        </div>
    </section>

    <?php if ($isEnabled && $totalSeconds > 0): ?>
    <!-- نمایش وضعیت زنده شمارنده -->
    <section class="tr-card">
        <div class="tr-card-h">
            <div class="tr-panel-section-head">
                <h3><?php _e('وضعیت شمارنده زنده'); ?></h3>
            </div>
        </div>
        <div class="tr-card-b">
            <div class="sitecare-live-grid">
                <div class="sitecare-live-item">
                    <strong id="sitecareLiveHours"><?php echo TypechoPlugin\SiteCare\Plugin::toPersianDigits((int) floor($remaining / 3600)); ?></strong>
                    <span><?php _e('ساعت'); ?></span>
                </div>
                <div class="sitecare-live-item">
                    <strong id="sitecareLiveMinutes"><?php echo TypechoPlugin\SiteCare\Plugin::toPersianDigits((int) floor(($remaining % 3600) / 60)); ?></strong>
                    <span><?php _e('دقیقه'); ?></span>
                </div>
                <div class="sitecare-live-item">
                    <strong id="sitecareLiveSeconds"><?php echo TypechoPlugin\SiteCare\Plugin::toPersianDigits((int) ($remaining % 60)); ?></strong>
                    <span><?php _e('ثانیه'); ?></span>
                </div>
            </div>
            <p class="tr-panel-note">
                <?php _e('این شمارنده به‌صورت زنده در پنل نمایش داده می‌شود. زمان شروع:'); ?>
                <?php echo $startedAt > 0 ? (new Typecho\Date($startedAt))->format('Y-m-d H:i:s') : '-'; ?>
            </p>
            <p class="tr-panel-note">
                <?php _e('پس از پایان شمارنده، حالت نگهداری به‌صورت خودکار خاموش می‌شود و سایت در دسترس قرار می‌گیرد.'); ?>
            </p>
            <div class="sitecare-actions">
                <button id="sitecareResetBtn" type="button" class="btn btn-s"><?php _e('ریست شمارنده'); ?></button>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- فرم تنظیمات پیام -->
    <section class="tr-card">
        <div class="tr-card-h">
            <div class="tr-panel-section-head">
                <h3><?php _e('پیام به بازدیدکنندگان'); ?></h3>
            </div>
        </div>
        <div class="tr-card-b">
            <div class="sitecare-form">
                <div class="sitecare-field">
                    <label for="sitecareTitle"><?php _e('عنوان صفحه'); ?></label>
                    <input type="text" id="sitecareTitle" class="sitecare-input"
                           value="<?php echo htmlspecialchars((string) $settings['title'], ENT_QUOTES, 'UTF-8'); ?>"
                           maxlength="120" placeholder="<?php _e('مثلاً: در حال تعمیر و نگهداری'); ?>">
                </div>
                <div class="sitecare-field">
                    <label for="sitecareMessage"><?php _e('پیام توضیحی مدیر'); ?></label>
                    <textarea id="sitecareMessage" class="sitecare-input sitecare-textarea"
                              maxlength="2000" placeholder="<?php _e('به کاربران توضیح دهید چرا سایت غیرفعال است و کی برمی‌گردد...'); ?>"><?php echo htmlspecialchars((string) $settings['message'], ENT_QUOTES, 'UTF-8'); ?></textarea>
                    <p class="sitecare-hint"><?php _e('می‌توانید از تگ‌های ایمن مثل &lt;b&gt;، &lt;i&gt;، &lt;a&gt; و &lt;br&gt; استفاده کنید.'); ?></p>
                </div>
            </div>
        </div>
    </section>

    <!-- تنظیمات شمارنده -->
    <section class="tr-card">
        <div class="tr-card-h">
            <div class="tr-panel-section-head">
                <h3><?php _e('تنظیمات شمارنده معکوس'); ?></h3>
            </div>
        </div>
        <div class="tr-card-b">
            <div class="sitecare-countdown-grid">
                <div class="sitecare-field">
                    <label for="sitecareHours"><?php _e('ساعت'); ?></label>
                    <input type="number" id="sitecareHours" class="sitecare-input sitecare-num"
                           min="0" max="720" step="1"
                           value="<?php echo (int) $settings['countdownHours']; ?>">
                </div>
                <div class="sitecare-field">
                    <label for="sitecareMinutes"><?php _e('دقیقه'); ?></label>
                    <input type="number" id="sitecareMinutes" class="sitecare-input sitecare-num"
                           min="0" max="59" step="1"
                           value="<?php echo (int) $settings['countdownMinutes']; ?>">
                </div>
                <div class="sitecare-field">
                    <label for="sitecareSeconds"><?php _e('ثانیه'); ?></label>
                    <input type="number" id="sitecareSeconds" class="sitecare-input sitecare-num"
                           min="0" max="59" step="1"
                           value="<?php echo (int) $settings['countdownSeconds']; ?>">
                </div>
            </div>
            <p class="tr-panel-note sitecare-countdown-note">
                <?php _e('مثال: ۳ ساعت ۰ دقیقه ۰ ثانیه. اگر همه مقادیر ۰ باشند، شمارنده نمایش داده نمی‌شود و حالت نگهداری تا خاموش شدن دستی فعال می‌ماند.'); ?>
            </p>

            <div class="sitecare-checkboxes">
                <label class="sitecare-checkbox">
                    <input type="checkbox" id="sitecareCountdownEnabled"
                           <?php echo (string) $settings['countdownEnabled'] === '1' ? 'checked' : ''; ?>>
                    <span><?php _e('نمایش شمارنده معکوس در صفحه'); ?></span>
                </label>
                <label class="sitecare-checkbox">
                    <input type="checkbox" id="sitecareShowAdminLink"
                           <?php echo (string) $settings['showAdminLink'] === '1' ? 'checked' : ''; ?>>
                    <span><?php _e('نمایش لینک ورود مدیر در پایین صفحه'); ?></span>
                </label>
                <label class="sitecare-checkbox">
                    <input type="checkbox" id="sitecareAnimateIcon"
                           <?php echo (string) $settings['animateIcon'] === '1' ? 'checked' : ''; ?>>
                    <span><?php _e('انیمیشن چرخان آیکون چرخ‌دنده'); ?></span>
                </label>
            </div>
        </div>
    </section>

    <!-- دکمه ذخیره -->
    <section class="tr-card">
        <div class="tr-card-b">
            <div class="sitecare-save-bar">
                <button id="sitecareSaveBtn" type="button" class="btn primary"><?php _e('ذخیره تنظیمات'); ?></button>
                <span class="sitecare-status" id="sitecareSaveStatus" aria-live="polite"></span>
            </div>
        </div>
    </section>

</div>

<script>
window.SiteCarePanel = <?php echo json_encode([
    'save'   => $urlSave,
    'toggle' => $urlToggle,
    'reset'  => $urlReset,
    'state'  => [
        'enabled'           => (string) $settings['enabled'],
        'countdownStartedAt'=> (int) $settings['countdownStartedAt'],
        'totalSeconds'      => $totalSeconds,
        'remaining'         => $remaining,
    ],
    'lang' => [
        'saving'       => _t('در حال ذخیره...'),
        'saved'        => _t('تنظیمات ذخیره شد.'),
        'saveError'    => _t('خطا در ذخیره تنظیمات.'),
        'toggleOn'     => _t('حالت نگهداری فعال شد.'),
        'toggleOff'    => _t('حالت نگهداری غیرفعال شد.'),
        'toggleError'  => _t('خطا در تغییر وضعیت.'),
        'resetDone'    => _t('شمارنده ریست شد.'),
        'resetError'   => _t('خطا در ریست شمارنده.'),
        'confirmOff'   => _t('آیا از خاموش کردن حالت نگهداری مطمئن هستید؟'),
    ],
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;
</script>
<script src="<?php echo htmlspecialchars($jsUrl, ENT_QUOTES, 'UTF-8'); ?>"></script>
