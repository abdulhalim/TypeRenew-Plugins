<?php
declare(strict_types=1);

namespace TypechoPlugin\SiteCare;

use Typecho\Cache;
use Utils\Helper;
use Widget\Plugins\Edit as PluginsEdit;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * مدیریت ذخیره و بازیابی تنظیمات SiteCare
 *
 * از مکانیزم Pref برای کش و normalize استفاده می‌کند تا
 * با الگوی استاندارد پلاگین‌های TypeRenew هم‌خوان باشد.
 */
class Settings
{
    private const NAME = 'SiteCare';
    private const CACHE_KEY = 'sitecare:settings:v1';

    private static ?array $runtime = null;

    /**
     * مقادیر پیش‌فرض تنظیمات
     */
    public static function defaults(): array
    {
        return [
            // وضعیت کلی افزونه
            'enabled' => '0',

            // پیام مدیر به کاربران
            'title' => 'در حال تعمیر و نگهداری',
            'message' => 'در حال حاضر سایت در حال به‌روزرسانی است تا تجربه بهتری برای شما فراهم کنیم. لطفاً کمی بعد دوباره سر بزنید. ممنون از صبوری شما!',

            // شمارنده معکوس (ساعت / دقیقه / ثانیه)
            'countdownHours' => 3,
            'countdownMinutes' => 0,
            'countdownSeconds' => 0,
            'countdownEnabled' => '1',

            // زمان شروع شمارنده (epoch) - وقتی مدیر حالت را فعال کند ثبت می‌شود
            'countdownStartedAt' => 0,

            // گزینه‌های نمایشی
            'showAdminLink' => '1',
            'animateIcon' => '1',

            // صفحه‌سازی و کش
            'cacheTtl' => 60,
        ];
    }

    /**
     * بارگذاری تنظیمات (با کش)
     */
    public static function load(): array
    {
        if (is_array(self::$runtime)) {
            return self::$runtime;
        }

        $cache = Cache::getInstance();
        if ($cache->enabled()) {
            try {
                $hit = false;
                $cached = $cache->get(self::CACHE_KEY, $hit);
                if ($hit && is_array($cached)) {
                    self::$runtime = $cached;
                    return self::$runtime;
                }
            } catch (\Throwable $e) {
                self::report('cache.get', $e);
            }
        }

        self::$runtime = self::readResolved();
        if ($cache->enabled()) {
            try {
                $cache->set(
                    self::CACHE_KEY,
                    self::$runtime,
                    max(30, (int) (self::$runtime['cacheTtl'] ?? 60))
                );
            } catch (\Throwable $e) {
                self::report('cache.set', $e);
            }
        }

        return self::$runtime;
    }

    /**
     * ذخیره تنظیمات
     */
    public static function store(array $settings): void
    {
        // merge با تنظیمات فعلی (از دیتابیس خوانده می‌شود) تا مقادیری که در $settings نیستن
        // (مثل countdownStartedAt) از بین نرن
        $previous = self::load();
        $settings = array_merge($previous, $settings);
        $settings = self::normalize($settings);

        // اگر حالت برای اولین بار فعال شد، زمان شروع شمارنده را ثبت کن
        $wasOff = (string) $previous['enabled'] !== '1';
        $isOn = (string) $settings['enabled'] === '1';
        if ($isOn && $wasOff) {
            $settings['countdownStartedAt'] = time();
        }

        // اگر مدت شمارنده هنگام فعال بودن تغییر کرد، زمان شروع را ریست کن
        $countdownChanged = (
            (int) $settings['countdownHours'] !== (int) $previous['countdownHours']
            || (int) $settings['countdownMinutes'] !== (int) $previous['countdownMinutes']
            || (int) $settings['countdownSeconds'] !== (int) $previous['countdownSeconds']
        );
        if ($isOn && $countdownChanged) {
            $settings['countdownStartedAt'] = time();
        }

        // اگر شمارنده قبلاً تمام شده و کاربر دوباره فعال می‌کند، خودکار ریست کن
        if ($isOn) {
            $totalSecs = (int) $settings['countdownHours'] * 3600
                       + (int) $settings['countdownMinutes'] * 60
                       + (int) $settings['countdownSeconds'];
            $startedAt = (int) $settings['countdownStartedAt'];
            if ($totalSecs > 0 && $startedAt > 0 && (time() - $startedAt) >= $totalSecs) {
                $settings['countdownStartedAt'] = time();
            }
        }

        try {
            PluginsEdit::configPlugin(self::NAME, $settings);
        } catch (\Throwable $e) {
            self::report('settings.store', $e);
        }

        self::$runtime = $settings;
        self::clearCache();
    }

    /**
     * غیرفعال‌سازی خودکار حالت نگهداری
     *
     * وقتی شمارنده معکوس به پایان می‌رسد از سمت Guard فراخوانی می‌شود.
     * وضعیت enabled در دیتابیس و کش به‌روزرسانی می‌شود تا در پنل
     * مدیریت هم «غیرفعال» نمایش داده شود.
     */
    public static function autoDisable(): void
    {
        try {
            $current = self::load();
            if ((string) $current['enabled'] !== '1') {
                // قبلاً غیرفعال شده است
                return;
            }

            $current['enabled'] = '0';
            self::store($current);
        } catch (\Throwable $e) {
            // حتی اگر ذخیره‌سازی شکست بخورد، درخواست ادامه می‌یابد
            // تا سایت در دسترس قرار گیرد.
            self::report('autoDisable', $e);
        }
    }

    /**
     * اطمینان از ذخیره بودن تنظیمات (در زمان فعال‌سازی اولیه)
     */
    public static function ensureStored(): void
    {
        try {
            $raw = (array) Helper::options()->plugin(self::NAME)->toArray();
        } catch (\Throwable $e) {
            $raw = [];
        }

        if (empty($raw)) {
            self::store(self::defaults());
        }
    }

    /**
     * پاک کردن کش
     */
    public static function clearCache(): void
    {
        try {
            Cache::getInstance()->delete(self::CACHE_KEY);
        } catch (\Throwable $e) {
            self::report('cache.delete', $e);
        }
        self::$runtime = null;
        \Widget\Options::destroy();
    }

    /**
     * خواندن و normalize کردن تنظیمات از دیتابیس
     */
    private static function readResolved(): array
    {
        try {
            $raw = (array) Helper::options()->plugin(self::NAME)->toArray();
        } catch (\Throwable $e) {
            self::report('settings.read', $e);
            $raw = [];
        }

        if (empty($raw)) {
            return self::defaults();
        }

        return self::normalize(array_merge(self::defaults(), $raw));
    }

    /**
     * نرمال‌سازی و اعتبارسنجی تنظیمات
     */
    public static function normalize(array $settings): array
    {
        $out = self::defaults();

        foreach ($out as $key => $default) {
            if (!array_key_exists($key, $settings)) {
                continue;
            }
            $value = $settings[$key];
            if (is_array($default)) {
                $out[$key] = is_array($value) ? $value : $default;
                continue;
            }
            if (is_int($default)) {
                $out[$key] = (int) $value;
                continue;
            }
            $out[$key] = is_string($value) ? $value : (string) $value;
        }

        // محدود کردن مقادیر عددی
        $out['countdownHours'] = max(0, min(720, (int) $out['countdownHours']));
        $out['countdownMinutes'] = max(0, min(59, (int) $out['countdownMinutes']));
        $out['countdownSeconds'] = max(0, min(59, (int) $out['countdownSeconds']));
        $out['cacheTtl'] = max(30, min(86400, (int) $out['cacheTtl']));
        $out['countdownStartedAt'] = max(0, (int) $out['countdownStartedAt']);

        // sanitize پیام و عنوان
        $out['title'] = self::sanitizeText((string) $out['title'], 120);
        $out['message'] = self::sanitizeText((string) $out['message'], 2000);

        // مقادیر bool
        foreach (['enabled', 'countdownEnabled', 'showAdminLink', 'animateIcon'] as $boolKey) {
            $out[$boolKey] = in_array((string) $out[$boolKey], ['1', 'true', 'yes'], true) ? '1' : '0';
        }

        return $out;
    }

    /**
     * پاکسازی متن (حذف تگ‌های خطرناک HTML، حفظ خطوط جدید)
     */
    private static function sanitizeText(string $text, int $maxLen): string
    {
        $text = trim($text);
        // فقط تگ‌های ایمن مجازند
        $text = strip_tags($text, '<br><b><strong><i><em><p><a><ul><ol><li>');
        if (function_exists('mb_substr') && mb_strlen($text, 'UTF-8') > $maxLen) {
            $text = mb_substr($text, 0, $maxLen, 'UTF-8');
        }
        return $text;
    }

    /**
     * گزارش خطا به لاگ
     */
    private static function report(string $scope, \Throwable $e): void
    {
        error_log('SiteCare.Settings [' . $scope . ']: ' . $e->getMessage());
    }
}
