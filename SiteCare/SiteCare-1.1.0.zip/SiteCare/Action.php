<?php
declare(strict_types=1);

namespace TypechoPlugin\SiteCare;

use Typecho\Widget;
use Widget\Security;
use Widget\User;
use Utils\Helper;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * Endpoint اکشن SiteCare
 *
 * - ?do=save   : ذخیره تنظیمات از فرم پنل
 * - ?do=toggle : روشن/خاموش سریع حالت نگهداری
 * - ?do=reset  : ریست شمارنده (ریست زمان شروع)
 */
class Action extends Widget
{
    private const MAX_JSON_SIZE = 32768;

    /**
     * نقطه ورود اکشن
     */
    public function action()
    {
        $do = (string) $this->request->get('do', '');

        $this->guardAdmin();

        switch ($do) {
            case 'save':
                $this->requirePost();
                $this->handleSave();
                return;

            case 'toggle':
                $this->requirePost();
                $this->handleToggle();
                return;

            case 'reset':
                $this->requirePost();
                $this->handleReset();
                return;

            default:
                $this->jsonError(_t('عملیات نامعتبر است'), 400, 'invalid_action');
        }
    }

    /**
     * ذخیره تنظیمات دریافتی از پنل مدیریت
     * منطق ریست شمارنده در Settings::store انجام می‌شود
     */
    private function handleSave(): void
    {
        $raw = $this->rawJson();
        $current = Settings::load();
        // فقط فیلدهایی که از فرم میان رو با current merge کن تا countdownStartedAt حفظ بشه
        $settings = array_merge($current, $raw);
        Settings::store($settings);

        // تنظیمات ذخیره‌شده رو دوباره بخوان تا countdownStartedAt به‌روز شده رو بگیری
        $stored = Settings::load();

        $this->jsonSuccess([
            'settings' => $stored,
            'remaining' => $this->computeRemaining($stored),
        ]);
    }

    /**
     * روشن/خاموش سریع حالت نگهداری
     * منطق ریست شمارنده در Settings::store انجام می‌شود
     */
    private function handleToggle(): void
    {
        $raw = $this->rawJson();
        $enabled = (string) ($raw['enabled'] ?? '') === '1' ? '1' : '0';

        $current = Settings::load();
        $current['enabled'] = $enabled;
        Settings::store($current);

        // تنظیمات ذخیره‌شده را دوباره بخوان تا countdownStartedAt به‌روز شده را بگیرد
        $stored = Settings::load();

        $this->jsonSuccess([
            'enabled' => $enabled,
            'countdownStartedAt' => (int) $stored['countdownStartedAt'],
            'remaining' => $this->computeRemaining($stored),
        ]);
    }

    /**
     * ریست شمارنده معکوس
     */
    private function handleReset(): void
    {
        $current = Settings::load();
        $current['countdownStartedAt'] = time();
        Settings::store($current);

        // تنظیمات ذخیره‌شده رو دوباره بخوان تا مطمئن بشیم
        $stored = Settings::load();

        $this->jsonSuccess([
            'countdownStartedAt' => (int) $stored['countdownStartedAt'],
            'remaining' => $this->computeRemaining($stored),
        ]);
    }

    /**
     * محاسبه ثانیه‌های باقی‌مانده شمارنده
     */
    private function computeRemaining(array $settings): int
    {
        $hours = (int) ($settings['countdownHours'] ?? 0);
        $minutes = (int) ($settings['countdownMinutes'] ?? 0);
        $seconds = (int) ($settings['countdownSeconds'] ?? 0);
        $total = $hours * 3600 + $minutes * 60 + $seconds;
        $startedAt = (int) ($settings['countdownStartedAt'] ?? 0);
        if ($total <= 0 || $startedAt <= 0) {
            return $total;
        }
        $elapsed = time() - $startedAt;
        return max(0, $total - $elapsed);
    }

    /**
     * اعتبارسنجی درخواست: فقط مدیران
     */
    private function guardAdmin(): void
    {
        User::alloc()->pass('administrator');
        $token = (string) $this->request->get('_');
        $expect = Security::alloc()->getToken('site-care-admin');
        if (!hash_equals($expect, $token)) {
            $this->jsonError(_t('اعتبارسنجی درخواست ناموفق بود'), 403, 'forbidden');
        }
    }

    /**
     * فقط POST مجاز است
     */
    private function requirePost(): void
    {
        if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
            $this->jsonError(_t('این روش درخواست مجاز نیست'), 405, 'method_not_allowed');
        }
    }

    /**
     * خواندن بدنه JSON از درخواست
     */
    private function rawJson(): array
    {
        $body = $this->request->getRawBody();
        if (strlen($body) > self::MAX_JSON_SIZE) {
            $this->jsonError(_t('حجم درخواست بیش از حد مجاز است'), 413, 'payload_too_large');
        }
        if (trim($body) === '') {
            return [];
        }
        try {
            $json = json_decode($body, true, 32, JSON_THROW_ON_ERROR);
        } catch (\JsonException $e) {
            $this->jsonError(_t('JSON درخواست نامعتبر است'), 400, 'invalid_json');
        }
        return is_array($json) ? $json : [];
    }

    /**
     * پاسخ خطای JSON
     */
    private function jsonError(string $message, int $status, string $code): void
    {
        $this->response->setStatus($status);
        $this->response->throwJson([
            'success' => 0,
            'error' => $message,
            'code' => $code,
        ]);
    }

    /**
     * پاسخ موفقیت JSON
     */
    private function jsonSuccess(array $data): void
    {
        if (!isset($data['success'])) {
            $data['success'] = 1;
        }
        $this->response->throwJson($data);
    }
}
