<?php
declare(strict_types=1);

namespace TypechoPlugin\ZipInstaller;

use Typecho\Plugin\PluginInterface;
use Utils\Helper;
use Utils\NoPersonal;
use Typecho\Widget\Helper\Form;
use Widget\Options;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * نصب پوسته و افزونه به سادگی از فایل‌های زیپ همانند وردپرس
 *
 * @package ZipInstaller
 * @author پوردریایی
 * @link https://pourdaryaei.ir/
 * @version 1.1.0
 * @since 1.6.0
 */
class Plugin implements PluginInterface
{
    use NoPersonal;

    /** نام افزونه */
    public const NAME = 'ZipInstaller';

    /** فایل پنل مدیریت */
    public const PANEL_FILE = 'ZipInstaller/Panel.php';

    /** شمارهٔ بخش منوی مدیریت که پنل زیر آن می‌نشیند (بخش افزونه‌ها) */
    public const PANEL_MENU = 5;

    /** کلید نتیجهٔ نصب در نشست */
    public const SESSION_RESULT_KEY = '__zipinstaller_result';

    /** کلید نتیجهٔ حذف بسته‌ها در نشست */
    public const SESSION_CLEANUP_KEY = '__zipinstaller_cleanup';

    /** کش تنظیمات افزونه برای درخواست جاری */
    private static ?array $settingsCache = null;

    /**
     * فعال‌سازی: ثبت پنل «نصب از فایل زیپ» در منوی مدیریت
     */
    public static function activate(): string
    {
        Helper::removePanel(self::PANEL_MENU, self::PANEL_FILE);
        Helper::addPanel(
            self::PANEL_MENU,
            self::PANEL_FILE,
            'نصب از فایل زیپ',
            'نصب پوسته و افزونه از فایل ZIP',
            'administrator',
            false,
            '',
            ['icon' => 'i-upload']
        );

        return 'افزونهٔ «نصب از فایل زیپ» فعال شد؛ از بخش «افزونه‌ها» در پنل مدیریت می‌توانید بسته‌های ZIP را نصب کنید.';
    }

    /**
     * غیرفعال‌سازی: حذف پنل و پاک‌سازی مسیرهای موقت
     */
    public static function deactivate(): string
    {
        Helper::removePanel(self::PANEL_MENU, self::PANEL_FILE);

        $cleaned = Installer::cleanupStaging();

        return 'افزونهٔ «نصب از فایل زیپ» غیرفعال شد'
            . ($cleaned > 0 ? sprintf(' و %d مسیر موقت قدیمی پاک‌سازی شد', $cleaned) : '') . '.';
    }

    /**
     * تنظیمات افزونه
     */
    public static function config(Form $form): void
    {
        $maxZipMB = new Form\Element\Number(
            'maxZipMB',
            null,
            50,
            'حداکثر حجم فایل زیپ (مگابایت)',
            'سقف حجم فایل ZIP قابل آپلود توسط این افزونه. توجه کنید که سقف آپلود PHP سرور (upload_max_filesize و post_max_size) '
            . 'نیز به‌طور خودکار اعمال می‌شود و مقدار مؤثر، کوچک‌ترین این سقف‌ها خواهد بود.'
        );
        $form->addInput($maxZipMB);

        $maxTotalMB = new Form\Element\Number(
            'maxTotalMB',
            null,
            200,
            'حداکثر حجم پس از استخراج (مگابایت)',
            'سقف مجموع حجم فایل‌های استخراج‌شده از بسته؛ محافظی در برابر بسته‌های خراب یا بمب‌های زیپ.'
        );
        $form->addInput($maxTotalMB);

        $maxEntries = new Form\Element\Number(
            'maxEntries',
            null,
            10000,
            'حداکثر تعداد فایل‌های بسته',
            'سقف تعداد فایل‌ها و پوشه‌های درون بستهٔ ZIP.'
        );
        $form->addInput($maxEntries);
    }

    /**
     * خواندن تنظیمات (با مقدارهای پیش‌فرض امن)
     */
    public static function settings(): array
    {
        if (self::$settingsCache !== null) {
            return self::$settingsCache;
        }

        $settings = [
            'maxZipMB'   => 50,
            'maxTotalMB' => 200,
            'maxEntries' => 10000,
        ];

        try {
            $config = Options::alloc()->plugin(self::NAME);
            $stored = method_exists($config, 'toArray') ? (array) $config->toArray() : [];
        } catch (\Throwable) {
            $stored = [];
        }

        foreach (['maxZipMB' => [1, 4096], 'maxTotalMB' => [1, 8192], 'maxEntries' => [1, 100000]] as $key => [$lo, $hi]) {
            if (isset($stored[$key])) {
                $value = is_scalar($stored[$key]) ? (int) $stored[$key] : $lo;
                $settings[$key] = max($lo, min($hi, $value));
            }
        }

        return self::$settingsCache = $settings;
    }

    /** نشانی صفحهٔ پنل مدیریت */
    public static function panelUrl(): string
    {
        return Helper::url(self::PANEL_FILE);
    }
}
