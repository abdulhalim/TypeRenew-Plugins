<?php
declare(strict_types=1);

namespace TypechoPlugin\ZipInstaller;

use Throwable;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * موتور نصب بسته‌ها: تشخیص پوسته/افزونه، اعتبارسنجی امن، استخراج با Rollback،
 * تنظیم مجوزهای 755/644 و پاک‌سازی کامل پس از نصب.
 */
class Installer
{
    public const TYPE_PLUGIN = 'plugin';
    public const TYPE_THEME = 'theme';

    /** پیشوند پوشهٔ کاری موقت (نام مستتر برای پویشگرهای پنل) */
    private const STAGING_PREFIX = '.zi-';

    /** حداکثر نام پوشهٔ بسته */
    private const DIR_NAME_MAX = 64;

    public static function typeLabel(string $type): string
    {
        return $type === self::TYPE_PLUGIN ? 'افزونه' : 'پوسته';
    }

    public static function rootDir(): string
    {
        return rtrim(str_replace('\\', '/', __TYPECHO_ROOT_DIR__), '/');
    }

    public static function pluginBase(): string
    {
        $dir = defined('__TYPECHO_PLUGIN_DIR__') ? __TYPECHO_PLUGIN_DIR__ : '/usr/plugins';

        return self::rootDir() . '/' . ltrim(str_replace('\\', '/', $dir), '/');
    }

    public static function themeBase(): string
    {
        $dir = defined('__TYPECHO_THEME_DIR__') ? __TYPECHO_THEME_DIR__ : '/usr/themes';

        return self::rootDir() . '/' . ltrim(str_replace('\\', '/', $dir), '/');
    }

    /**
     * وضعیت محیط سرور برای نمایش در پنل.
     */
    public static function environment(): array
    {
        $pluginBase = self::pluginBase();
        $themeBase = self::themeBase();
        $usrDir = self::rootDir() . '/usr';

        return [
            'zipExtension'  => Archive::zipExtensionLoaded(),
            'nativeSupport' => Archive::nativeSupported(),
            'pluginBase'    => $pluginBase,
            'themeBase'     => $themeBase,
            'pluginsWritable' => is_dir($pluginBase) && is_writable($pluginBase),
            'themesWritable'  => is_dir($themeBase) && is_writable($themeBase),
            'usrWritable'   => is_dir($usrDir) && is_writable($usrDir),
            'uploadMax'     => Text::iniBytes((string) ini_get('upload_max_filesize')),
            'postMax'       => Text::iniBytes((string) ini_get('post_max_size')),
        ];
    }

    /**
     * نصب فایل آپلودشده از آرایهٔ $_FILES.
     *
     * فایل زیپ پس از نصب (موفق یا ناموفق) به‌طور کامل حذف می‌شود.
     *
     * @param array $upload   عضو آرایهٔ $_FILES
     * @param array $options  گزینه‌ها: forcedType، upgrade، maxZipMB، maxTotalMB، maxEntries، forceNative
     */
    public static function installUploaded(array $upload, array $options = []): array
    {
        $forceNative = !empty($options['forceNative']);

        if (!isset($upload['error']) || is_array($upload['error'])) {
            throw new InstallerException('فایلی برای نصب ارسال نشده است.');
        }

        if ((int) $upload['error'] !== UPLOAD_ERR_OK) {
            throw new InstallerException(self::uploadErrorMessage((int) $upload['error']));
        }

        $tmpName = (string) ($upload['tmp_name'] ?? '');
        if ($tmpName === '' || !is_uploaded_file($tmpName)) {
            throw new InstallerException('فایل آپلودشدهٔ معتبری یافت نشد.');
        }

        $sourceName = (string) ($upload['name'] ?? '');
        if ($sourceName === '') {
            $sourceName = 'package.zip';
        }

        if (strtolower((string) pathinfo($sourceName, PATHINFO_EXTENSION)) !== 'zip') {
            throw new InstallerException('تنها فایل‌های ZIP (با پسوند .zip) پذیرفته می‌شوند.');
        }

        $size = (int) ($upload['size'] ?? 0);
        $maxZipBytes = self::optionInt($options, 'maxZipMB', 50) * 1_048_576;
        if ($size > 0 && $size > $maxZipBytes) {
            throw new InstallerException('حجم فایل زیپ از سقف تنظیم‌شده (' . Text::bytes($maxZipBytes) . ') بیشتر است.');
        }

        $staging = self::createStaging();
        $stagedZip = $staging . '/package.zip';

        try {
            // بررسی سلامت: هر ZIP معتبری با بایت‌های PK شروع می‌شود
            $probe = @fopen($tmpName, 'rb');
            if ($probe === false) {
                throw new InstallerException('خواندن فایل آپلودشده ممکن نشد.');
            }

            $magic = (string) fread($probe, 2);
            fclose($probe);

            if ($magic !== 'PK') {
                throw new InstallerException('فایل انتخاب‌شده یک آرشیو ZIP معتبر نیست.');
            }

            if (!@move_uploaded_file($tmpName, $stagedZip)) {
                throw new InstallerException('جابه‌جایی فایل آپلودشده به مسیر کاری ممکن نشد.');
            }

            $options['sourceName'] = $sourceName;
            $options['forceNative'] = $forceNative;

            return self::install($stagedZip, $options);
        } finally {
            // فایل زیپ در هر حالت (موفق/خطا) کاملاً حذف می‌شود
            self::removeDir($staging);
        }
    }

    /**
     * نصب یک فایل زیپ موجود روی دیسک.
     *
     * @param array $options forcedType | upgrade | maxZipMB | maxTotalMB | maxEntries | sourceName | forceNative
     */
    public static function install(string $zipPath, array $options = []): array
    {
        $forcedType = (string) ($options['forcedType'] ?? '');
        $upgrade = !empty($options['upgrade']);
        $maxZipBytes = self::optionInt($options, 'maxZipMB', 50) * 1_048_576;
        $maxTotalBytes = self::optionInt($options, 'maxTotalMB', 200) * 1_048_576;
        $maxEntries = self::optionInt($options, 'maxEntries', 10000);
        $sourceName = (string) ($options['sourceName'] ?? '');
        $forceNative = !empty($options['forceNative']);

        if (!is_file($zipPath) || !is_readable($zipPath)) {
            throw new InstallerException('فایل زیپ قابل خواندن نیست.');
        }

        $zipBytes = (int) @filesize($zipPath);
        if ($zipBytes < 22) {
            throw new InstallerException('فایل زیپ خالی یا بسیار کوچک است؛ لطفاً یک بستهٔ ZIP معتبر انتخاب کنید.');
        }

        if ($zipBytes > $maxZipBytes) {
            throw new InstallerException('حجم فایل زیپ از سقف تنظیم‌شده (' . Text::bytes($maxZipBytes) . ') بیشتر است.');
        }

        $staging = null;

        try {
            $archive = Archive::open($zipPath, $forceNative);

            try {
                // ۱) پالایش فایل‌های سیستمی/زباله
                [$keep, $junkCount] = self::filterJunk($archive->entries());
                if ($keep === []) {
                    throw new InstallerException('بستهٔ زیپ هیچ فایل مفیدی ندارد (فقط فایل‌های سیستمی مانند __MACOSX یا .DS_Store).');
                }

                // ۲) اعتبارسنجی امنیتی ساختار و مسیرها (پیش از هرگونه استخراج)
                self::validateEntries($keep, $maxEntries, $maxTotalBytes);

                // ۳) یافتن ریشهٔ بسته
                [$rootPrefix, $ignoredCount] = self::findRoot($archive, $keep);

                // ۴) تشخیص نوع بسته
                $type = self::detectType($archive, $rootPrefix, $forcedType);

                // ۵) نام پوشهٔ مقصد
                $rawDir = $rootPrefix !== ''
                    ? $rootPrefix
                    : (string) pathinfo($sourceName !== '' ? $sourceName : basename($zipPath), PATHINFO_FILENAME);
                [$dirName, $nameWarnings] = self::normalizeDirName($rawDir, $type);

                $targetBase = $type === self::TYPE_PLUGIN ? self::pluginBase() : self::themeBase();
                if (!is_dir($targetBase)) {
                    throw new InstallerException('پوشهٔ مقصد نصب (' . basename($targetBase) . ') روی سرور یافت نشد.');
                }

                $finalDir = $targetBase . '/' . $dirName;
                $conflict = self::findConflict($targetBase, $dirName);

                if ($conflict !== null && !$upgrade) {
                    throw new InstallerException(
                        self::typeLabel($type) . ' «' . $dirName . '» از قبل در مسیر '
                        . self::relativePath($conflict) . ' وجود دارد؛ برای جایگزینی، گزینهٔ «به‌روزرسانی نسخهٔ موجود» را فعال کنید.'
                    );
                }

                // ۶) استخراج در مسیر کاری موقت + نهایی‌سازی
                $staging = self::createStaging();
                $work = $staging . '/work';
                $backup = $staging . '/backup';
                $didBackup = false;

                if (!@mkdir($work, 0755, true) && !is_dir($work)) {
                    throw new InstallerException('ساخت مسیر کاری موقت ممکن نشد؛ دسترسی نوشتن پوشهٔ usr را بررسی کنید.');
                }

                if ($conflict !== null) {
                    if (!@rename($conflict, $backup)) {
                        throw new InstallerException('پشتیبان‌گیری از نسخهٔ موجود برای جایگزینی ممکن نشد.');
                    }
                    $didBackup = true;
                }

                try {
                    $stats = self::extractAll($archive, $keep, $rootPrefix, $work);
                    self::applyPermissions($work);

                    if (!@rename($work, $finalDir)) {
                        throw new InstallerException(
                            'انتقال بسته به مسیر نهایی ممکن نشد؛ دسترسی نوشتن پوشهٔ '
                            . self::relativePath($targetBase) . ' را بررسی کنید.'
                        );
                    }
                } catch (Throwable $e) {
                    // Rollback: هیچ فایل ناقصی باقی نمی‌ماند
                    if (is_dir($work)) {
                        self::removeDir($work);
                    }

                    if ($didBackup && is_dir($backup) && !is_dir($finalDir)) {
                        @rename($backup, $conflict);
                    }

                    throw $e;
                }
            } finally {
                $archive->close();
            }
        } finally {
            // پاک‌سازی کامل مسیر موقت: زیپ، فایل‌های ناقص و نسخهٔ پشتیبان قدیمی
            if (is_string($staging) && is_dir($staging)) {
                self::removeDir($staging);
            }
        }

        $info = self::packageInfo($type, $finalDir);

        return [
            'ok'         => true,
            'type'       => $type,
            'typeLabel'  => self::typeLabel($type),
            'dirName'    => $dirName,
            'rawDirName' => trim($rawDir, '/'),
            'target'     => self::relativePath($finalDir),
            'upgraded'   => $conflict !== null,
            'sourceName' => $sourceName,
            'stats'      => $stats + ['junk' => $junkCount, 'ignored' => $ignoredCount],
            'info'       => $info,
            'warnings'   => $nameWarnings,
        ];
    }

    /** پاک‌سازی مسیرهای موقت به‌جا‌مانده (در غیرفعال‌سازی افزونه) */
    public static function cleanupStaging(): int
    {
        $count = 0;
        $usrDir = self::rootDir() . '/usr';
        if (!is_dir($usrDir)) {
            return 0;
        }

        $items = @scandir($usrDir) ?: [];
        foreach ($items as $item) {
            if ($item === '.' || $item === '..' || !str_starts_with($item, self::STAGING_PREFIX)) {
                continue;
            }

            $path = $usrDir . '/' . $item;
            if (is_dir($path)) {
                self::removeDir($path);
                $count++;
            }
        }

        return $count;
    }

    // ------------------------------------------------------------------
    //  مدیریت بسته‌ها: فهرست‌کردن و حذف موارد غیرفعال
    // ------------------------------------------------------------------

    /**
     * فهرست پوسته‌ها و افزونه‌های نصب‌شده به‌همراه وضعیت فعال بودن.
     *
     * قاعدهٔ «فعال» دقیقاً مطابق منطق هسته است: افزونه‌ای فعال است که در
     * فهرست افزونه‌های فعال باشد (یا چرخهٔ حیات نداشته باشد که هسته آن را
     * همیشه‌فعال می‌شمارد) و پوسته‌ای فعال است که پوستهٔ جاری سایت باشد.
     */
    public static function listPackages(): array
    {
        return [
            self::TYPE_PLUGIN => self::scanPackages(self::pluginBase(), self::TYPE_PLUGIN),
            self::TYPE_THEME  => self::scanPackages(self::themeBase(), self::TYPE_THEME),
        ];
    }

    /**
     * حذف بسته‌های انتخاب‌شده — تنها و تنها موارد غیرفعال، به‌صورت همه‌یا‌هیچ.
     *
     * بسته‌ها ابتدا به یک زباله‌دان موقت منتقل و سپس حذف می‌شوند تا در صورت
     * خطا، وضعیت پیشین به‌طور کامل بازگردانی شود (Rollback).
     *
     * @param array $selected به‌صورت ['plugin' => [names], 'theme' => [names]]
     *
     * @return array{ok: bool, deleted: array<int, array<string,string>>, errors: array<int, string>, warnings: array<int, string>}
     */
    public static function deleteSelected(array $selected): array
    {
        $result = ['ok' => false, 'deleted' => [], 'errors' => [], 'warnings' => []];

        // گردآوری و یکتاسازی نام‌ها (پذیرش کلید مفرد و جمع)
        $items = [];
        foreach ([
            self::TYPE_PLUGIN => ['plugin', 'plugins'],
            self::TYPE_THEME  => ['theme', 'themes'],
        ] as $type => $keys) {
            foreach ($keys as $key) {
                $names = $selected[$key] ?? [];
                if (!is_array($names)) {
                    continue;
                }
                foreach ($names as $name) {
                    $items[] = $type . "\x00" . trim((string) $name);
                }
            }
        }
        $items = array_values(array_unique($items));
        $items = array_map(static fn (string $pair): array => explode("\x00", $pair, 2), $items);

        if ($items === []) {
            $result['errors'][] = 'هیچ بسته‌ای برای حذف انتخاب نشده است.';
            return $result;
        }

        // مرحلهٔ ۱: اعتبارسنجی همهٔ موارد پیش از هرگونه تغییر (همه‌یا‌هیچ)
        $activated = [];
        try {
            $exported = \Typecho\Plugin::export();
            if (is_array($exported['activated'] ?? null)) {
                $activated = $exported['activated'];
            }
        } catch (Throwable) {
            // در نبود داده، فهرست فعال خالی می‌ماند
        }

        $currentTheme = '';
        try {
            $currentTheme = trim((string) \Widget\Options::alloc()->theme);
        } catch (Throwable) {
        }

        $targets = [];
        foreach ($items as [$type, $name]) {
            try {
                $targets[] = self::assertDeletable($type, $name, $activated, $currentTheme);
            } catch (InstallerException $e) {
                $result['errors'][] = $e->getMessage();
            }
        }

        if ($result['errors'] !== []) {
            $result['errors'][] = 'به دلیل خطاهای بالا، هیچ بسته‌ای حذف نشد و وضعیت پیشین دست‌نخورده ماند.';
            return $result;
        }

        // مرحلهٔ ۲: انتقال به زباله‌دان موقت با بازگردانی در صورت خطا
        $staging = self::createStaging();
        $trash = $staging . '/trash';

        if (!@mkdir($trash, 0755, true) && !is_dir($trash)) {
            self::removeDir($staging);
            $result['errors'][] = 'ساخت مسیر موقت برای حذف ممکن نشد؛ هیچ بسته‌ای حذف نشد.';
            return $result;
        }

        $moved = [];
        $failed = null;

        foreach ($targets as $target) {
            $slot = $trash . '/' . $target['type'] . '__' . $target['name'];

            if (!@rename($target['path'], $slot)) {
                $failed = $target;
                break;
            }

            $moved[] = ['from' => $target['path'], 'to' => $slot, 'target' => $target];
        }

        if ($failed !== null) {
            $rollbackFailed = [];

            foreach ($moved as $m) {
                if (!@rename($m['to'], $m['from'])) {
                    $rollbackFailed[] = $m['target']['name'];
                }
            }

            if ($rollbackFailed !== []) {
                // زباله‌دان را نگه می‌داریم تا بسته‌ها از دست نروند
                $result['errors'][] = 'جابه‌جایی برخی بسته‌ها ممکن نشد و بازگردانی آن‌ها نیز با خطا روبه‌رو شد: '
                    . implode('، ', $rollbackFailed)
                    . '. این بسته‌ها به‌صورت موقت و امن در مسیر «' . self::relativePath($trash) . '» نگه داشته شده‌اند.';
                return $result;
            }

            self::removeDir($staging);

            $result['errors'][] = 'جابه‌جایی ' . self::typeLabel($failed['type']) . ' «' . $failed['name']
                . '» برای حذف ممکن نشد؛ هیچ بسته‌ای حذف نشد و وضعیت پیشین بازگردانی شد.';
            return $result;
        }

        // مرحلهٔ ۳: حذف نهایی و بازگردانی‌ناپذیر
        self::removeDir($staging);

        if (is_dir($staging)) {
            $result['warnings'][] = 'پاک‌سازی نهایی فایل‌های حذف‌شده ناقص ماند؛ باقی‌مانده در مسیر «'
                . self::relativePath($staging) . '» است و با غیرفعال‌سازی افزونه به‌طور کامل پاک می‌شود.';
        }

        foreach ($moved as $m) {
            $result['deleted'][] = [
                'type'      => $m['target']['type'],
                'typeLabel' => self::typeLabel($m['target']['type']),
                'name'      => $m['target']['name'],
                'title'     => $m['target']['title'],
            ];
        }

        $result['ok'] = true;
        return $result;
    }

    // ------------------------------------------------------------------
    //  بخش داخلی: مراحل نصب
    // ------------------------------------------------------------------

    private static function extractAll(Archive $archive, array $keep, string $rootPrefix, string $work): array
    {
        $files = 0;
        $dirs = 0;
        $bytes = 0;
        $prefixLen = strlen($rootPrefix);

        foreach ($keep as $entry) {
            $rel = substr($entry['path'], $prefixLen);
            $rel = self::assertSafeRelative($rel);

            if ($rel === '') {
                continue;
            }

            $dest = $work . '/' . $rel;

            if (!self::isInside($work, $dest)) {
                throw new InstallerException('مسیر ناامن (Zip Slip) در ورودی «' . $entry['path'] . '» شناسایی شد؛ نصب متوقف شد.');
            }

            if ($entry['isDir']) {
                self::ensureDir($dest, $work);
                $dirs++;
                continue;
            }

            self::ensureDir(dirname($dest), $work);
            $written = $archive->extractFile($entry['path'], $dest);
            $bytes += $written;
            $files++;
        }

        return ['files' => $files, 'dirs' => $dirs, 'bytes' => $bytes];
    }

    /**
     * اعتبارسنجی مسیر نسبی ورودی پس از حذف پیشوند ریشه.
     *
     * @return string مسیر نسبی امن (بدون اسلش آغازین/پایانی)
     */
    private static function assertSafeRelative(string $rel): string
    {
        $rel = str_replace('\\', '/', $rel);

        foreach (explode('/', $rel) as $seg) {
            if ($seg === '.' || $seg === '..') {
                throw new InstallerException('مسیر ناامن (Zip Slip) در بسته شناسایی شد؛ نصب متوقف شد.');
            }
        }

        return trim($rel, '/');
    }

    /** بررسی قراردادن یک مسیر درون پوشهٔ پایه (دفاع دوم در برابر Zip Slip) */
    private static function isInside(string $base, string $child): bool
    {
        $base = rtrim($base, '/');
        $child = rtrim($child, '/');

        return $child === $base || str_starts_with($child, $base . '/');
    }

    private static function ensureDir(string $dir, string $workRoot): void
    {
        if (is_dir($dir)) {
            return;
        }

        if (!self::isInside($workRoot, $dir)) {
            throw new InstallerException('مسیر پوشهٔ مقصد خارج از محیط کاری است؛ نصب متوقف شد.');
        }

        if (!@mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new InstallerException('ساخت پوشهٔ «' . self::relativePath($dir) . '» ممکن نشد؛ دسترسی نوشتن را بررسی کنید.');
        }
    }

    /** پالایش ورودی‌های سیستمی/زباله */
    private static function filterJunk(array $entries): array
    {
        $keep = [];
        $junk = 0;

        foreach ($entries as $entry) {
            if (self::isJunk($entry['path'])) {
                $junk++;
                continue;
            }

            $keep[] = $entry;
        }

        return [$keep, $junk];
    }

    private static function isJunk(string $path): bool
    {
        $segments = explode('/', rtrim(str_replace('\\', '/', $path), '/'));
        $last = count($segments) - 1;

        foreach ($segments as $i => $seg) {
            if ($seg === '') {
                continue;
            }

            if (in_array($seg, ['.git', '.svn', '.hg', '.bzr', '__MACOSX'], true)) {
                return true;
            }

            if ($i === $last && (
                in_array($seg, ['.DS_Store', 'Thumbs.db', 'desktop.ini', '.gitignore', '.gitattributes', '.gitmodules'], true)
                || str_starts_with($seg, '._')
            )) {
                return true;
            }
        }

        return false;
    }

    /** اعتبارسنجی کامل ورودی‌ها پیش از استخراج: مسیر، تعداد و حجم */
    private static function validateEntries(array $entries, int $maxEntries, int $maxTotalBytes): void
    {
        if (count($entries) > $maxEntries) {
            throw new InstallerException(
                'تعداد ورودی‌های بسته (' . Text::fa(count($entries)) . ') از حد مجاز ('
                . Text::fa($maxEntries) . ') بیشتر است.'
            );
        }

        $total = 0;
        foreach ($entries as $entry) {
            self::assertSafeEntryName($entry['path']);

            if (!$entry['isDir']) {
                $total += (int) $entry['size'];
            }
        }

        if ($total > $maxTotalBytes) {
            throw new InstallerException(
                'حجم استخراج‌شدهٔ بسته (' . Text::bytes($total) . ') از سقف مجاز ('
                . Text::bytes($maxTotalBytes) . ') بیشتر است.'
            );
        }
    }

    /** قواعد امنیتی نام ورودی: بدون مسیر مطلق، بدون پیمایش، بدون بایت تهی */
    private static function assertSafeEntryName(string $path): void
    {
        if ($path === '') {
            throw new InstallerException('نام ورودی خالی در فایل زیپ یافت شد.');
        }

        if (str_contains($path, "\0")) {
            throw new InstallerException('بایت تهی (Null Byte) در نام ورودی فایل زیپ شناسایی شد؛ نصب متوقف شد.');
        }

        $norm = str_replace('\\', '/', $path);

        if (str_starts_with($norm, '/')) {
            throw new InstallerException('مسیر مطلق در ورودی «' . $norm . '» مجاز نیست؛ نصب متوقف شد.');
        }

        if (preg_match('/^[A-Za-z]:/', $norm)) {
            throw new InstallerException('نشانی درایو در ورودی «' . $norm . '» مجاز نیست؛ نصب متوقف شد.');
        }

        foreach (explode('/', $norm) as $seg) {
            if ($seg === '' || $seg === '.') {
                continue;
            }

            if ($seg === '..') {
                throw new InstallerException('پیمایش مسیر (Zip Slip) در ورودی «' . $norm . '» شناسایی شد؛ نصب متوقف شد.');
            }

            if (preg_match('#[\x00-\x1f\x7f]#', $seg)) {
                throw new InstallerException('کاراکتر کنترلی در نام ورودی «' . $norm . '» شناسایی شد؛ نصب متوقف شد.');
            }
        }
    }

    /**
     * یافتن ریشهٔ بسته.
     *
     * @return array{0: string, 1: int} پیشوند ریشه و تعداد ورودی‌های بیرون از بستهٔ اصلی
     */
    private static function findRoot(Archive $archive, array $entries): array
    {
        $topDirs = [];
        $topFiles = 0;

        foreach ($entries as $entry) {
            $path = $entry['path'];
            $trimmed = rtrim($path, '/');

            if ($trimmed === '') {
                continue;
            }

            if (str_contains($trimmed, '/')) {
                $topDirs[explode('/', $trimmed, 2)[0]] = true;
            } elseif ($entry['isDir']) {
                $topDirs[$trimmed] = true;
            } else {
                $topFiles++;
            }
        }

        // حالت رایج: همه‌چیز درون یک پوشهٔ سطح‌بالای واحد
        if ($topFiles === 0 && count($topDirs) === 1) {
            return [array_key_first($topDirs) . '/', 0];
        }

        // جست‌وجوی پوشهٔ دارای نشانهٔ بسته (Plugin.php یا index.php مستقیم درون آن)
        $candidates = [];
        foreach (array_keys($topDirs) as $dir) {
            if ($archive->hasFile($dir . '/Plugin.php') || $archive->hasFile($dir . '/index.php')) {
                $candidates[] = $dir;
            }
        }

        if (count($candidates) === 1) {
            return [$candidates[0] . '/', count($topDirs) - 1 + $topFiles];
        }

        if (count($candidates) > 1) {
            throw new InstallerException(
                'ساختار بسته مبهم است؛ چند پوشهٔ محتمل برای نصب یافت شد: '
                . implode('، ', $candidates) . '. لطفاً بسته را با ساختار استاندارد (یک پوشهٔ اصلی) بسازید.'
            );
        }

        if ($topFiles > 0) {
            // زیپ تخت: فایل‌ها مستقیماً در ریشهٔ آرشیو هستند
            return ['', 0];
        }

        throw new InstallerException(
            'ریشهٔ بسته شناسایی نشد؛ نه Plugin.php (نشانهٔ افزونه) و نه index.php (نشانهٔ پوسته) در ساختار زیپ یافت نشد.'
        );
    }

    /** تشخیص نوع بسته: افزونه یا پوسته */
    private static function detectType(Archive $archive, string $rootPrefix, string $forcedType): string
    {
        $hasPluginFile = $archive->hasFile($rootPrefix . 'Plugin.php');
        $hasIndexFile = $archive->hasFile($rootPrefix . 'index.php');

        if ($forcedType !== '' && !in_array($forcedType, [self::TYPE_PLUGIN, self::TYPE_THEME], true)) {
            throw new InstallerException('نوع بستهٔ انتخاب‌شده معتبر نیست.');
        }

        if ($forcedType === self::TYPE_PLUGIN) {
            if (!$hasPluginFile) {
                throw new InstallerException('این بسته فایل Plugin.php ندارد؛ افزونه‌های TypeRenew باید در ریشه، Plugin.php داشته باشند.');
            }

            return self::TYPE_PLUGIN;
        }

        if ($forcedType === self::TYPE_THEME) {
            if (!$hasIndexFile) {
                throw new InstallerException('این بسته فایل index.php ندارد؛ پوسته‌های TypeRenew باید در ریشه، index.php داشته باشند.');
            }

            return self::TYPE_THEME;
        }

        // تشخیص خودکار
        $looksPlugin = false;
        if ($hasPluginFile) {
            $src = $archive->readLimited($rootPrefix . 'Plugin.php');
            $looksPlugin = $src !== null && self::pluginSignature($src);
        }

        if ($looksPlugin) {
            return self::TYPE_PLUGIN;
        }

        if ($hasIndexFile) {
            return self::TYPE_THEME;
        }

        if ($hasPluginFile) {
            return self::TYPE_PLUGIN;
        }

        throw new InstallerException(
            'نوع بسته شناسایی نشد؛ نه Plugin.php (نشانهٔ افزونه) و نه index.php (نشانهٔ پوسته) در ریشهٔ بسته یافت نشد.'
        );
    }

    /** نشانهٔ ساختاری افزونه در محتوای Plugin.php */
    private static function pluginSignature(string $src): bool
    {
        return (bool) preg_match('/PluginInterface|Typecho_Plugin_Interface/i', $src)
            || (bool) preg_match('/\bclass\s+[A-Za-z0-9_]+_Plugin\b/', $src);
    }

    /**
     * تعیین نام پوشهٔ نهایی؛ نام افزونه باید کلاس معتبر PHP بسازد.
     *
     * @return array{0: string, 1: array<string>}
     */
    private static function normalizeDirName(string $raw, string $type): array
    {
        $raw = trim($raw);
        if ($raw === '' || $raw === '.' || $raw === '..') {
            throw new InstallerException('نام پوشهٔ بسته در فایل زیپ قابل استفاده نیست.');
        }

        if ($type === self::TYPE_PLUGIN) {
            // نام پوشه = نام کلاس افزونه در TypeRenew
            if (preg_match('/^[A-Za-z_][A-Za-z0-9_]{0,49}$/', $raw)) {
                return [$raw, []];
            }

            $camel = self::camelize($raw);
            if ($camel === null) {
                throw new InstallerException(
                    'نام پوشهٔ افزونه («' . $raw . '») به نام کلاس معتبر PHP قابل تبدیل نیست؛ '
                    . 'نام پوشه را با حروف لاتین و بدون فاصله بسازید.'
                );
            }

            return [$camel, ['نام پوشهٔ افزونه برای سازگاری با ساختار کلاس از «' . $raw . '» به «' . $camel . '» عادی‌سازی شد.']];
        }

        // پوسته: نام لاتین ساده کافی است
        $slug = trim((string) preg_replace('/[^A-Za-z0-9._-]+/', '-', $raw), '-.');

        if ($slug === '' || strlen($slug) > self::DIR_NAME_MAX || !preg_match('/^[A-Za-z0-9]/', $slug)) {
            throw new InstallerException(
                'نام پوشهٔ پوسته («' . $raw . '») قابل استفاده نیست؛ نامی لاتین مانند my-theme انتخاب کنید.'
            );
        }

        if ($slug !== $raw) {
            return [$slug, ['نام پوشهٔ پوسته برای سازگاری از «' . $raw . '» به «' . $slug . '» عادی‌سازی شد.']];
        }

        return [$slug, []];
    }

    private static function camelize(string $raw): ?string
    {
        $parts = preg_split('/[^A-Za-z0-9]+/', $raw) ?: [];
        $parts = array_values(array_filter($parts, static fn ($p) => $p !== ''));

        if ($parts === []) {
            return null;
        }

        $name = implode('', array_map('ucfirst', $parts));

        return preg_match('/^[A-Za-z_][A-Za-z0-9_]{0,49}$/', $name) ? $name : null;
    }

    /** یافتن تعارض نام با پوشه/فایل موجود (حساس به بزرگی/کوچکی برای میزبان‌های مک) */
    private static function findConflict(string $base, string $dirName): ?string
    {
        if (is_dir($base . '/' . $dirName) || is_file($base . '/' . $dirName)) {
            return $base . '/' . $dirName;
        }

        $items = @scandir($base) ?: [];
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }

            if (strcasecmp($item, $dirName) === 0 && (is_dir($base . '/' . $item) || is_file($base . '/' . $item))) {
                return $base . '/' . $item;
            }
        }

        return null;
    }

    /** اعمال و وارسی مجوزهای نهایی: پوشه‌ها 755 و فایل‌ها 644 */
    private static function applyPermissions(string $root): void
    {
        if (!@chmod($root, 0755) && ((int) @fileperms($root) & 0777) !== 0755) {
            throw new InstallerException('تنظیم مجوز 755 برای پوشهٔ ریشهٔ بسته ممکن نشد.');
        }

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($iterator as $path => $info) {
            $want = $info->isDir() ? 0755 : 0644;
            $have = @fileperms((string) $path);

            if ($have !== false && ($have & 0777) === $want) {
                continue;
            }

            if (!@chmod((string) $path, $want)) {
                throw new InstallerException('تنظیم مجوز ' . decoct($want) . ' برای «' . self::relativePath((string) $path) . '» ممکن نشد.');
            }
        }
    }

    /** حذف بازگشتی یک پوشه (در حد امکان؛ خطاها نادیده گرفته می‌شوند) */
    private static function removeDir(string $dir): void
    {
        if (!is_dir($dir)) {
            return;
        }

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST
        );

        foreach ($iterator as $path => $info) {
            if ($info->isDir()) {
                @rmdir((string) $path);
            } else {
                @unlink((string) $path);
            }
        }

        @rmdir($dir);
    }

    private static function createStaging(): string
    {
        $usrDir = self::rootDir() . '/usr';

        if (!is_dir($usrDir) || !is_writable($usrDir)) {
            throw new InstallerException('پوشهٔ usr قابل نوشتن نیست؛ دسترسی نوشتن سرور را بررسی کنید.');
        }

        $dir = $usrDir . '/' . self::STAGING_PREFIX . bin2hex(random_bytes(8));

        if (!@mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new InstallerException('ساخت مسیر کاری موقت ممکن نشد.');
        }

        // جلوگیری از دسترسی وب (آپاچی) و فهرست‌شدن مسیر
        @file_put_contents($dir . '/.htaccess', "Require all denied\n");
        @file_put_contents($dir . '/index.html', '');

        return $dir;
    }

    /** خواندن اطلاعات سربرگ بستهٔ نصب‌شده (عنوان/نسخه/نویسنده) */
    private static function packageInfo(string $type, string $finalDir): array
    {
        $info = [
            'title'       => basename($finalDir),
            'version'     => '',
            'description' => '',
            'author'      => '',
        ];

        try {
            $file = $finalDir . ($type === self::TYPE_PLUGIN ? '/Plugin.php' : '/index.php');

            if (!is_readable($file)) {
                return $info;
            }

            $parsed = \Typecho\Plugin::parseInfo($file);

            $info['title'] = trim((string) ($parsed['title'] ?? '')) ?: $info['title'];
            $info['version'] = trim((string) ($parsed['version'] ?? ''));
            $info['description'] = trim((string) ($parsed['description'] ?? ''));
            $info['author'] = trim((string) ($parsed['author'] ?? ''));
        } catch (Throwable) {
            // اطلاعات سربرگ اختیاری است
        }

        return $info;
    }

    /** اعتبارسنجی یک بستهٔ درخواستی برای حذف: نام، وضعیت فعال، مسیر امن */
    private static function assertDeletable(string $type, string $name, array $activated, string $currentTheme): array
    {
        if ($type !== self::TYPE_PLUGIN && $type !== self::TYPE_THEME) {
            throw new InstallerException('نوع بستهٔ درخواستی معتبر نیست.');
        }

        if (!self::isValidPackageName($name)) {
            throw new InstallerException('نام بستهٔ «' . $name . '» معتبر نیست.');
        }

        $label = self::typeLabel($type);

        if ($type === self::TYPE_PLUGIN) {
            if ($name === Plugin::NAME) {
                throw new InstallerException('افزونهٔ «' . $name . '» (خودِ ابزار نصب) از این پنل قابل حذف نیست.');
            }
        } elseif ($name === $currentTheme && $currentTheme !== '') {
            throw new InstallerException('پوستهٔ «' . $name . '» پوستهٔ فعال سایت است و حذف آن ممکن نیست.');
        }

        $base = $type === self::TYPE_PLUGIN ? self::pluginBase() : self::themeBase();
        $path = $base . '/' . $name;

        if (!is_dir($path)) {
            throw new InstallerException($label . ' «' . $name . '» روی دیسک یافت نشد.');
        }

        if (is_link($path)) {
            throw new InstallerException($label . ' «' . $name . '» یک پیوند نمادین است و برای امنیت سرور حذف نشد.');
        }

        $real = (string) realpath($path);
        $realBase = (string) realpath($base);

        if ($real === '' || $realBase === '' || dirname($real) !== $realBase) {
            throw new InstallerException(
                'مسیر ' . $label . ' «' . $name . '» با ساختار پوشهٔ موردانتظار هم‌خوانی ندارد و حذف نشد.'
            );
        }

        // بررسی فعال بودن افزونه با همان منطق هسته (Widget\Plugins\Rows)
        if ($type === self::TYPE_PLUGIN) {
            $entry = $path . '/Plugin.php';
            $info = is_readable($entry) ? \Typecho\Plugin::parseInfo($entry) : [];
            $hasLifecycle = !empty($info['activate']) || !empty($info['deactivate'])
                || !empty($info['config']) || !empty($info['personalConfig']);
            $isActive = array_key_exists($name, $activated)
                || (is_readable($entry) && !$hasLifecycle);

            if ($isActive) {
                throw new InstallerException(
                    'افزونهٔ «' . $name . '» فعال است؛ ابتدا آن را از فهرست افزونه‌ها غیرفعال کنید.'
                );
            }
        }

        return [
            'type'  => $type,
            'name'  => $name,
            'path'  => $path,
            'title' => self::packageInfo($type, $path)['title'],
        ];
    }

    /** پویش پوشهٔ افزونه‌ها یا پوسته‌ها و ساخت فهرست وضعیت‌دار */
    private static function scanPackages(string $base, string $type): array
    {
        $list = [];

        if (!is_dir($base)) {
            return $list;
        }

        $activated = [];
        try {
            $exported = \Typecho\Plugin::export();
            if (is_array($exported['activated'] ?? null)) {
                $activated = $exported['activated'];
            }
        } catch (Throwable) {
        }

        $currentTheme = '';
        try {
            $currentTheme = trim((string) \Widget\Options::alloc()->theme);
        } catch (Throwable) {
        }

        $items = @scandir($base) ?: [];

        foreach ($items as $name) {
            $path = $base . '/' . $name;

            if ($name === '.' || $name === '..' || str_starts_with($name, '.') || !is_dir($path) || is_link($path)) {
                continue;
            }

            $entry = $path . ($type === self::TYPE_PLUGIN ? '/Plugin.php' : '/index.php');
            $broken = !is_readable($entry);
            $info = $broken ? [] : \Typecho\Plugin::parseInfo($entry);

            $title = trim((string) ($info['title'] ?? '')) ?: $name;
            $version = trim((string) ($info['version'] ?? ''));

            if ($type === self::TYPE_PLUGIN) {
                $hasLifecycle = !empty($info['activate']) || !empty($info['deactivate'])
                    || !empty($info['config']) || !empty($info['personalConfig']);
                $active = array_key_exists($name, $activated) || (!$broken && !$hasLifecycle);
                $self = $name === Plugin::NAME;
            } else {
                $active = $name === $currentTheme;
                $self = false;
            }

            $list[] = [
                'name'      => $name,
                'title'     => $title,
                'version'   => $version,
                'broken'    => $broken,
                'active'    => $active,
                'self'      => $self,
                'deletable' => !$active && !$self,
            ];
        }

        usort($list, static fn (array $a, array $b): int => strcasecmp($a['name'], $b['name']));

        return $list;
    }

    /** نام معتبر پوشهٔ بسته برای حذف: بدون پیمایش، بدون نقطهٔ آغازین، بدون جداکنندهٔ مسیر */
    private static function isValidPackageName(string $name): bool
    {
        return $name !== ''
            && !str_starts_with($name, '.')
            && !str_contains($name, "\0")
            && !str_contains($name, '/')
            && !str_contains($name, '\\')
            && strlen($name) <= self::DIR_NAME_MAX;
    }

    private static function relativePath(string $path): string
    {
        $path = str_replace('\\', '/', $path);
        $root = self::rootDir();
        $relative = str_starts_with($path, $root) ? substr($path, strlen($root)) : $path;

        return $relative ?: '/';
    }

    private static function optionInt(array $options, string $key, int $default): int
    {
        $value = $options[$key] ?? $default;
        $value = is_scalar($value) ? (int) $value : $default;

        return max(1, min($value, 1_048_576));
    }

    private static function uploadErrorMessage(int $code): string
    {
        return match ($code) {
            UPLOAD_ERR_INI_SIZE => 'حجم فایل از سقف مجاز آپلود سرور بیشتر است.',
            UPLOAD_ERR_FORM_SIZE => 'حجم فایل از سقف تعیین‌شده در فرم بیشتر است.',
            UPLOAD_ERR_PARTIAL => 'آپلود فایل ناقص ماند؛ دوباره تلاش کنید.',
            UPLOAD_ERR_NO_FILE => 'فایلی برای آپلود انتخاب نشده است.',
            UPLOAD_ERR_NO_TMP_DIR => 'پوشهٔ موقت آپلود روی سرور وجود ندارد.',
            UPLOAD_ERR_CANT_WRITE => 'نوشتن فایل آپلودشده روی دیسک ممکن نشد.',
            UPLOAD_ERR_EXTENSION => 'یک افزونهٔ PHP آپلود را متوقف کرد.',
            default => 'خطای ناشناخته در آپلود فایل (کد: ' . $code . ').',
        };
    }
}
