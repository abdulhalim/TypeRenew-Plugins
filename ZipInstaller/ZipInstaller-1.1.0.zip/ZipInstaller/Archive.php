<?php
declare(strict_types=1);

namespace TypechoPlugin\ZipInstaller;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * خواندن یکسان آرشیوهای ZIP با دو موتور:
 *  - «zip»:     افزونهٔ استاندارد ZipArchive (در صورت وجود on سرور)
 *  - «native»:  خوانندهٔ خالص PHP (فهرست مرکزی + gzinflate) بدون هیچ وابستگی خارجی
 *
 * هر دو موتور همان API را ارائه می‌کنند و صحت داده با CRC32 بررسی می‌شود.
 */
class Archive
{
    /** موتور فعال */
    public const ENGINE_ZIP = 'zip';
    public const ENGINE_NATIVE = 'native';

    private string $file;
    private string $engine;

    /** @var \ZipArchive|null */
    private $zip = null;

    /** @var resource|null هندل فایل موتور داخلی */
    private $fh = null;

    /** @var array<int, array{name:string,path:string,size:int,crc:int,method:int,isDir:bool,offset:int,compSize:int}> */
    private array $entries = [];

    /** @var array<string, int> نگاشت مسیر نرمال‌شده → اندیس */
    private array $byName = [];

    private function __construct(string $file, string $engine)
    {
        $this->file = $file;
        $this->engine = $engine;
    }

    public static function nativeSupported(): bool
    {
        return function_exists('gzinflate') && function_exists('fopen');
    }

    public static function zipExtensionLoaded(): bool
    {
        return class_exists('ZipArchive');
    }

    /**
     * باز کردن فایل زیپ.
     *
     * @param bool $forceNative اجبار به موتور داخلی (برای تست یا دور زدن ZipArchive)
     * @throws InstallerException
     */
    public static function open(string $file, bool $forceNative = false): self
    {
        if (!is_file($file) || !is_readable($file)) {
            throw new InstallerException('فایل زیپ قابل خواندن نیست.');
        }

        $size = (int) @filesize($file);
        if ($size < 22) {
            throw new InstallerException('فایل زیپ خالی یا بسیار کوچک است؛ لطفاً یک بستهٔ ZIP معتبر انتخاب کنید.');
        }

        if (!$forceNative && self::zipExtensionLoaded()) {
            $zip = new \ZipArchive();
            $result = $zip->open($file, \ZipArchive::RDONLY);
            if ($result !== true) {
                throw new InstallerException('فایل انتخاب‌شده یک آرشیو ZIP معتبر نیست (کد خطا: ' . (int) $result . ').');
            }

            $archive = new self($file, self::ENGINE_ZIP);
            $archive->zip = $zip;
            $archive->indexZip($zip);

            return $archive;
        }

        if (!self::nativeSupported()) {
            throw new InstallerException('نه افزونهٔ ZipArchive روی سرور فعال است و نه امکان خواندن داخلی (zlib) وجود دارد.');
        }

        $archive = new self($file, self::ENGINE_NATIVE);
        $archive->parseNative();

        return $archive;
    }

    public function engine(): string
    {
        return $this->engine;
    }

    /** @return array<int, array{name:string,path:string,size:int,crc:int,method:int,isDir:bool,offset:int,compSize:int}> */
    public function entries(): array
    {
        return $this->entries;
    }

    /** یافتن ورودی بر اساس مسیر نرمال‌شده */
    private function entryByPath(string $path): ?array
    {
        $path = str_replace('\\', '/', $path);

        return isset($this->byName[$path]) ? $this->entries[$this->byName[$path]] : null;
    }

    /** آیا ورودیِ فایلی با این مسیر وجود دارد؟ (پوشه‌ها را فایل نمی‌شماریم) */
    public function hasFile(string $path): bool
    {
        $entry = $this->entryByPath($path);

        return $entry !== null && !$entry['isDir'];
    }

    /**
     * خواندن کامل یک ورودی (فقط برای فایل‌های کوچک؛ سقف دلخواه)
     *
     * @return string|null در صورت نبود یا بزرگ‌تر بودن از سقف null
     */
    public function readLimited(string $path, int $maxBytes = 262_144): ?string
    {
        $entry = $this->entryByPath($path);
        if ($entry === null || $entry['isDir'] || $entry['size'] > $maxBytes) {
            return null;
        }

        if ($this->engine === self::ENGINE_ZIP) {
            $data = $this->zip->getFromName($entry['name'], $maxBytes + 1);
            if (!is_string($data) || strlen($data) > $maxBytes) {
                return null;
            }

            return $data;
        }

        $data = $this->readNative($entry);

        return strlen($data) <= $maxBytes ? $data : null;
    }

    /**
     * استخراج یک ورودی فایل به مسیر مقصد با بررسی CRC32.
     *
     * @param string $path مسیر نرمال‌شدهٔ ورودی در آرشیو
     * @return int تعداد بایت‌های نوشته‌شده
     * @throws InstallerException
     */
    public function extractFile(string $path, string $destFile): int
    {
        $entry = $this->entryByPath($path);
        if ($entry === null || $entry['isDir']) {
            throw new InstallerException('ورودی «' . $path . '» در فایل زیپ یافت نشد.');
        }

        if ($this->engine === self::ENGINE_ZIP) {
            return $this->extractZip($entry, $destFile);
        }

        $data = $this->readNative($entry);
        self::assertCrc($data, $entry['crc'], $entry['name']);

        if (file_put_contents($destFile, $data) !== strlen($data)) {
            throw new InstallerException('نوشتن فایل «' . $entry['name'] . '» روی دیسک ناتمام ماند.');
        }

        return strlen($data);
    }

    public function close(): void
    {
        if ($this->zip instanceof \ZipArchive) {
            $this->zip->close();
            $this->zip = null;
        }

        if (is_resource($this->fh)) {
            fclose($this->fh);
            $this->fh = null;
        }
    }

    /** ایندکس‌گذاری ورودی‌ها با موتور ZipArchive */
    private function indexZip(\ZipArchive $zip): void
    {
        $count = $zip->numFiles;
        for ($i = 0; $i < $count; $i++) {
            $name = $zip->getNameIndex($i);
            $stat = $zip->statIndex($i);
            if (!is_string($name) || $stat === false) {
                continue;
            }

            $isDir = str_ends_with($name, '/');
            $entry = [
                'name'     => $name,
                'path'     => str_replace('\\', '/', $name),
                'size'     => (int) ($stat['size'] ?? 0),
                'crc'      => (int) ($stat['crc'] ?? 0),
                'method'   => (int) ($stat['comp_method'] ?? 0),
                'isDir'    => $isDir,
                'offset'   => 0,
                'compSize' => (int) ($stat['comp_size'] ?? 0),
            ];

            $this->entries[] = $entry;
            $this->byName[$entry['path']] = count($this->entries) - 1;
        }
    }

    /** استخراج جریانی با ZipArchive (حافظهٔ کم) */
    private function extractZip(array $entry, string $destFile): int
    {
        $name = $entry['name'];
        $stream = $this->zip->getStream($name);

        if ($stream === false) {
            $data = $this->zip->getFromName($name);
            if (!is_string($data)) {
                throw new InstallerException('خواندن فایل «' . $name . '» از آرشیو ممکن نشد.');
            }

            self::assertCrc($data, $entry['crc'], $name);
            if (file_put_contents($destFile, $data) !== strlen($data)) {
                throw new InstallerException('نوشتن فایل «' . $name . '» روی دیسک ناتمام ماند.');
            }

            return strlen($data);
        }

        $out = @fopen($destFile, 'wb');
        if ($out === false) {
            fclose($stream);
            throw new InstallerException('ساخت فایل مقصد برای «' . $name . '» ممکن نشد.');
        }

        $ctx = hash_init('crc32b');
        $bytes = 0;

        try {
            while (!feof($stream)) {
                $chunk = fread($stream, 65_536);
                if ($chunk === false || $chunk === '') {
                    break;
                }

                $bytes += strlen($chunk);
                if ($bytes > (64 * 1_048_576)) {
                    throw new InstallerException('فایل «' . $name . '» از حد مجاز عبور کرد.');
                }

                if (fwrite($out, $chunk) !== strlen($chunk)) {
                    throw new InstallerException('نوشتن فایل «' . $name . '» روی دیسک ناتمام ماند.');
                }

                hash_update($ctx, $chunk);
            }
        } finally {
            fclose($out);
            fclose($stream);
        }

        self::assertCrcHash(hash_final($ctx), $entry['crc'], $name);

        if ($bytes !== (int) $entry['size']) {
            throw new InstallerException('حجم فایل استخراج‌شدهٔ «' . $name . '» با فهرست زیپ نمی‌خواند.');
        }

        return $bytes;
    }

    /** خواندن کامل یک ورودی با موتور داخلی */
    private function readNative(array $entry): string
    {
        if ($this->fh === null) {
            throw new InstallerException('فایل زیپ باز نیست.');
        }

        fseek($this->fh, (int) $entry['offset']);
        $header = fread($this->fh, 30);

        if (strlen($header) !== 30 || substr($header, 0, 4) !== "PK\x03\x04") {
            throw new InstallerException('ساختار داخلی فایل زیپ خراب است.');
        }

        $nameLen = unpack('v', substr($header, 26, 2))[1] ?? 0;
        $extraLen = unpack('v', substr($header, 28, 2))[1] ?? 0;
        fseek($this->fh, (int) $entry['offset'] + 30 + $nameLen + $extraLen);

        $need = (int) $entry['compSize'];
        $comp = '';
        while (strlen($comp) < $need && !feof($this->fh)) {
            $comp .= fread($this->fh, $need - strlen($comp));
        }

        if (strlen($comp) !== $need) {
            throw new InstallerException('دادهٔ فایل «' . $entry['name'] . '» در آرشیو ناقص است.');
        }

        $method = (int) $entry['method'];
        if ($method === 0) {
            $data = $comp;
        } elseif ($method === 8) {
            $data = @gzinflate($comp, (int) $entry['size']);
            if ($data === false) {
                throw new InstallerException('بازگشایی فایل فشردهٔ «' . $entry['name'] . '» شکست خورد.');
            }
        } else {
            throw new InstallerException('روش فشرده‌سازی فایل «' . $entry['name'] . '» پشتیبانی نمی‌شود.');
        }

        if (strlen($data) !== (int) $entry['size']) {
            throw new InstallerException('حجم فایل «' . $entry['name'] . '» با فهرست زیپ نمی‌خواند.');
        }

        return $data;
    }

    /** تجزیهٔ End of Central Directory و فهرست مرکزی با موتور خالص PHP */
    private function parseNative(): void
    {
        $fh = @fopen($this->file, 'rb');
        if ($fh === false) {
            throw new InstallerException('باز کردن فایل زیپ ممکن نشد.');
        }

        try {
            $size = (int) @filesize($this->file);
            $scan = min($size, 65_557);
            fseek($fh, $size - $scan);
            $tail = '';
            while (strlen($tail) < $scan && !feof($fh)) {
                $tail .= fread($fh, $scan - strlen($tail));
            }

            $pos = strrpos($tail, "PK\x05\x06");
            if ($pos === false) {
                throw new InstallerException('ساختار ZIP در فایل یافت نشد؛ فایل معتبر نیست.');
            }

            $eocd = substr($tail, $pos, 22);
            $total = unpack('v', substr($eocd, 10, 2))[1] ?? 0;
            $cdSize = unpack('V', substr($eocd, 12, 4))[1] ?? 0;
            $cdOff = unpack('V', substr($eocd, 16, 4))[1] ?? 0;

            if ($total === 0xFFFF || $cdSize === 0xFFFFFFFF || $cdOff === 0xFFFFFFFF) {
                throw new InstallerException('بسته‌های Zip64 پشتیبانی نمی‌شوند؛ لطفاً زیپ را به‌صورت استاندارد بسته‌بندی کنید.');
            }

            if ($total === 0) {
                throw new InstallerException('فایل زیپ هیچ ورودی ندارد.');
            }

            fseek($fh, $cdOff);
            $cd = '';
            while (strlen($cd) < $cdSize && !feof($fh)) {
                $cd .= fread($fh, $cdSize - strlen($cd));
            }

            if (strlen($cd) < $cdSize) {
                throw new InstallerException('فهرست مرکزی فایل زیپ ناقص است.');
            }

            $p = 0;
            for ($i = 0; $i < $total; $i++) {
                if (strlen($cd) < $p + 46 || substr($cd, $p, 4) !== "PK\x01\x02") {
                    throw new InstallerException('فهرست مرکزی فایل زیپ خراب است.');
                }

                $flags = unpack('v', substr($cd, $p + 8, 2))[1] ?? 0;
                $method = unpack('v', substr($cd, $p + 10, 2))[1] ?? 0;
                $crc = unpack('V', substr($cd, $p + 16, 4))[1] ?? 0;
                $csize = unpack('V', substr($cd, $p + 20, 4))[1] ?? 0;
                $usize = unpack('V', substr($cd, $p + 24, 4))[1] ?? 0;
                $nameLen = unpack('v', substr($cd, $p + 28, 2))[1] ?? 0;
                $extraLen = unpack('v', substr($cd, $p + 30, 2))[1] ?? 0;
                $commentLen = unpack('v', substr($cd, $p + 32, 2))[1] ?? 0;
                $offset = unpack('V', substr($cd, $p + 42, 4))[1] ?? 0;
                $name = substr($cd, $p + 46, $nameLen);

                if ($name === false || strlen($name) !== $nameLen) {
                    throw new InstallerException('نام ورودی در فهرست زیپ ناقص است.');
                }

                if (($flags & 0x1) === 1) {
                    throw new InstallerException('فایل زیپ رمزگذاری‌شده است؛ بسته‌های محافظت‌شده با رمز پشتیبانی نمی‌شوند.');
                }

                if ($csize === 0xFFFFFFFF || $usize === 0xFFFFFFFF || $offset === 0xFFFFFFFF) {
                    throw new InstallerException('بسته‌های Zip64 پشتیبانی نمی‌شوند؛ لطفاً زیپ را به‌صورت استاندارد بسته‌بندی کنید.');
                }

                if ($method !== 0 && $method !== 8) {
                    throw new InstallerException('روش فشرده‌سازی ورودی «' . $name . '» پشتیبانی نمی‌شود.');
                }

                $entry = [
                    'name'     => $name,
                    'path'     => str_replace('\\', '/', $name),
                    'size'     => (int) $usize,
                    'crc'      => (int) $crc,
                    'method'   => (int) $method,
                    'isDir'    => str_ends_with($name, '/'),
                    'offset'   => (int) $offset,
                    'compSize' => (int) $csize,
                ];

                $this->entries[] = $entry;
                $this->byName[$entry['path']] = count($this->entries) - 1;

                $p += 46 + $nameLen + $extraLen + $commentLen;
            }

            $this->fh = $fh;
        } catch (\Throwable $e) {
            fclose($fh);
            $this->fh = null;
            throw $e;
        }
    }

    private static function assertCrc(string $data, int $crc, string $name): void
    {
        self::assertCrcHash(hash('crc32b', $data), $crc, $name);
    }

    private static function assertCrcHash(string $actual, int $expected, string $name): void
    {
        if ($expected !== 0 && sprintf('%08x', $expected) !== $actual) {
            throw new InstallerException('خرابی داده: بررسی CRC32 برای فایل «' . $name . '» ناموفق بود.');
        }
    }
}
