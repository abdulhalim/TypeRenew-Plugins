<?php
declare(strict_types=1);

namespace TypechoPlugin\ZipInstaller;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * توابع کمکی نمایش و تبدیل برای افزونهٔ نصب از فایل زیپ.
 */
class Text
{
    /** گریختن امن کاراکترهای HTML */
    public static function e(?string $value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }

    /**
     * تبدیل مقدار بایتی php.ini (مانند 2M یا 512K یا 1G) به بایت
     */
    public static function iniBytes(string $value): int
    {
        $value = trim($value);
        if ($value === '' || $value === '-1' || $value === '0') {
            return 0;
        }

        if (preg_match('/^(\d+)([kmgt]?)b?$/i', $value, $m)) {
            $num = (int) $m[1];

            return (int) match (strtolower($m[2])) {
                't' => $num * 1_099_511_627_776,
                'g' => $num * 1_073_741_824,
                'm' => $num * 1_048_576,
                'k' => $num * 1024,
                default => $num,
            };
        }

        return (int) $value;
    }

    /** نمایش خوانای حجم بر حسب بایت */
    public static function bytes(int $bytes): string
    {
        if ($bytes >= 1_073_741_824) {
            return number_format($bytes / 1_073_741_824, 1) . ' گیگابایت';
        }

        if ($bytes >= 1_048_576) {
            return number_format($bytes / 1_048_576, 1) . ' مگابایت';
        }

        if ($bytes >= 1024) {
            return number_format($bytes / 1024, 1) . ' کیلوبایت';
        }

        return $bytes . ' بایت';
    }

    /** تبدیل عدد به ارقام فارسی برای نمایش رابط کاربری */
    public static function fa(int|string $number): string
    {
        return str_replace(
            ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
            ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'],
            (string) $number
        );
    }

    /** قالب‌بندی حجم با ارقام فارسی */
    public static function faBytes(int $bytes): string
    {
        return self::fa(self::bytes($bytes));
    }
}
