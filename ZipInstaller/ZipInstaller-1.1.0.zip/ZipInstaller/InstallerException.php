<?php
declare(strict_types=1);

namespace TypechoPlugin\ZipInstaller;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * خطای فرایند نصب با پیام فارسی مناسب نمایش در پنل.
 */
class InstallerException extends \RuntimeException
{
}
