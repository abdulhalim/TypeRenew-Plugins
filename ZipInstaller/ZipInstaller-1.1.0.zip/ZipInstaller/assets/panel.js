/**
 * افزونهٔ نصب از فایل زیپ — رفتار سمت مرورگر
 * (کشیدن‌ورهاکردن فایل، چیپ فایل انتخاب‌شده، اعتبارسنجی پیش از ارسال
 *  و مدیریت حذف پوسته‌ها/افزونه‌های غیرفعال)
 */
(function () {
    'use strict';

    var panel = document.getElementById('zipinstaller-panel');
    if (!panel) {
        return;
    }

    var form = document.getElementById('zi-upload-form');
    var dropzone = document.getElementById('zi-dropzone');
    var input = document.getElementById('zi-file');
    var chip = document.getElementById('zi-file-chip');
    var chipName = chip ? chip.querySelector('.zi-file-name') : null;
    var chipSize = chip ? chip.querySelector('.zi-file-size') : null;
    var chipRemove = document.getElementById('zi-file-remove');
    var errorBox = document.getElementById('zi-form-error');
    var maxBytes = form ? (parseInt(form.getAttribute('data-max'), 10) || 0) : 0;

    function formatBytes(bytes) {
        if (bytes >= 1073741824) {
            return (bytes / 1073741824).toFixed(1) + ' گیگابایت';
        }
        if (bytes >= 1048576) {
            return (bytes / 1048576).toFixed(1) + ' مگابایت';
        }
        if (bytes >= 1024) {
            return (bytes / 1024).toFixed(1) + ' کیلوبایت';
        }
        return bytes + ' بایت';
    }

    function faDigits(text) {
        var fa = '۰۱۲۳۴۵۶۷۸۹';
        return String(text).replace(/\d/g, function (d) {
            return fa.charAt(parseInt(d, 10));
        });
    }

    function showError(message) {
        if (!errorBox) {
            return;
        }
        errorBox.textContent = message;
        errorBox.hidden = false;
    }

    function clearError() {
        if (errorBox) {
            errorBox.hidden = true;
            errorBox.textContent = '';
        }
    }

    function showFile(file) {
        clearError();

        if (!file) {
            if (chip) {
                chip.hidden = true;
            }
            return;
        }

        var name = file.name || '';
        var size = file.size || 0;

        if (!/\.zip$/i.test(name)) {
            showError('فقط فایل‌هایی با پسوند zip. پذیرفته می‌شوند؛ فایل انتخاب‌شده «' + name + '» معتبر نیست.');
            input.value = '';
            if (chip) {
                chip.hidden = true;
            }
            return;
        }

        if (maxBytes > 0 && size > maxBytes) {
            showError('حجم فایل انتخاب‌شده (' + formatBytes(size) + ') از سقف مجاز (' + formatBytes(maxBytes) + ') بیشتر است.');
            input.value = '';
            if (chip) {
                chip.hidden = true;
            }
            return;
        }

        if (chip) {
            if (chipName) {
                chipName.textContent = name;
            }
            if (chipSize) {
                chipSize.textContent = formatBytes(size);
            }
            chip.hidden = false;
        }
    }

    if (dropzone && input) {
        dropzone.addEventListener('click', function () {
            input.click();
        });

        dropzone.addEventListener('keydown', function (event) {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                input.click();
            }
        });

        ['dragenter', 'dragover'].forEach(function (type) {
            dropzone.addEventListener(type, function (event) {
                event.preventDefault();
                event.stopPropagation();
                dropzone.classList.add('is-dragover');
            });
        });

        ['dragleave', 'drop'].forEach(function (type) {
            dropzone.addEventListener(type, function (event) {
                event.preventDefault();
                event.stopPropagation();
                dropzone.classList.remove('is-dragover');
            });
        });

        dropzone.addEventListener('drop', function (event) {
            var files = event.dataTransfer && event.dataTransfer.files;
            if (files && files.length > 0) {
                input.files = files;
                showFile(files[0]);
            }
        });

        input.addEventListener('change', function () {
            showFile(input.files && input.files.length > 0 ? input.files[0] : null);
        });
    }

    // حذف فایل انتخاب‌شده از چیپ (بدون باز شدن پنجرهٔ انتخاب فایل)
    if (chipRemove && input) {
        chipRemove.addEventListener('click', function (event) {
            event.preventDefault();
            event.stopPropagation();
            input.value = '';
            showFile(null);
        });
    }

    if (form) {
        form.addEventListener('submit', function (event) {
            clearError();

            if (!input || !input.files || input.files.length === 0) {
                event.preventDefault();
                showError('ابتدا یک فایل ZIP انتخاب کنید.');
                if (dropzone) {
                    dropzone.focus();
                }
                return;
            }

            var button = document.getElementById('zi-submit');
            if (button) {
                button.disabled = true;
                button.textContent = 'در حال آپلود و نصب…';
            }
        });
    }

    // ------------------------------------------------------------------
    //  مدیریت بسته‌ها: انتخاب همه، تأیید حذف و ارسال فرم
    // ------------------------------------------------------------------

    var cleanupForm = document.getElementById('zi-cleanup-form');

    if (cleanupForm) {
        var cleanupError = document.getElementById('zi-cleanup-error');
        var cleanupButton = document.getElementById('zi-cleanup-submit');

        var selectedBoxes = function () {
            return cleanupForm.querySelectorAll('.zi-pkg-check:checked');
        };

        var showCleanupError = function (message) {
            if (!cleanupError) {
                return;
            }
            cleanupError.textContent = message;
            cleanupError.hidden = false;
        };

        var hideCleanupError = function () {
            if (cleanupError) {
                cleanupError.hidden = true;
                cleanupError.textContent = '';
            }
        };

        // انتخاب/لغو انتخاب همهٔ بسته‌های غیرفعال هر ستون
        Array.prototype.forEach.call(
            cleanupForm.querySelectorAll('.zi-select-all-check'),
            function (master) {
                master.addEventListener('change', function () {
                    var scope = master.getAttribute('data-scope');
                    var boxes = cleanupForm.querySelectorAll('.zi-pkg-check[data-type="' + scope + '"]');

                    Array.prototype.forEach.call(boxes, function (box) {
                        box.checked = master.checked;
                    });

                    hideCleanupError();
                });
            }
        );

        cleanupForm.addEventListener('submit', function (event) {
            hideCleanupError();

            var count = selectedBoxes().length;

            if (count === 0) {
                event.preventDefault();
                showCleanupError('هیچ بسته‌ای برای حذف انتخاب نشده است.');
                return;
            }

            var message = 'حذف ' + faDigits(count) + ' بستهٔ غیرفعال به‌صورت دائمی انجام می‌شود و بازگشتی ندارد. ادامه می‌دهید؟';

            if (!window.confirm(message)) {
                event.preventDefault();
                return;
            }

            if (cleanupButton) {
                cleanupButton.disabled = true;
                cleanupButton.textContent = 'در حال حذف…';
            }
        });
    }

    // پیمایش به کارت نتیجه پس از نصب یا حذف
    var resultTarget = document.getElementById('zi-result') || document.getElementById('zi-cleanup-result');
    if (resultTarget && window.location.hash !== '#zi-result' && window.location.hash !== '#zi-cleanup') {
        resultTarget.scrollIntoView({behavior: 'smooth', block: 'center'});
    }
})();
