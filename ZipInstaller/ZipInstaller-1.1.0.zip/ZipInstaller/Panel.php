<?php
declare(strict_types=1);

use TypechoPlugin\ZipInstaller\Installer;
use TypechoPlugin\ZipInstaller\InstallerException;
use TypechoPlugin\ZipInstaller\Plugin;
use TypechoPlugin\ZipInstaller\Text;
use Typecho\Common;
use Utils\Session;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$user->pass('administrator');

$settings = Plugin::settings();
$env = Installer::environment();
$panelUrl = Plugin::panelUrl();
$assetUrl = static fn (string $file): string => Common::url(
    'ZipInstaller/assets/' . ltrim($file, '/'),
    (string) $options->pluginUrl
);

// سقف مؤثر آپلود: کوچک‌ترینِ سقف افزونه و سقف‌های PHP
$effectiveMax = $env['uploadMax'] > 0 ? $env['uploadMax'] : ($settings['maxZipMB'] * 1048576);
$effectiveMax = min($effectiveMax, $settings['maxZipMB'] * 1048576);

// ------------------------------------------------------------------
//  پردازش آپلود/نصب و حذف بسته‌ها (پیش از هرگونه خروجی)
// ------------------------------------------------------------------
if ($request->isPost()) {
    $security->protect();

    // ---- حذف بسته‌های غیرفعال انتخاب‌شده ----
    if ((string) ($_POST['do'] ?? '') === 'cleanup') {
        $cleanup = Installer::deleteSelected([
            'plugin' => $_POST['delete']['plugin'] ?? [],
            'theme'  => $_POST['delete']['theme'] ?? [],
        ]);

        if (Session::start()) {
            $_SESSION[Plugin::SESSION_CLEANUP_KEY] = $cleanup;
        }

        $response->redirect($panelUrl);
        return;
    }

    // ---- نصب از فایل زیپ ----
    $forcedType = (string) ($_POST['type'] ?? '');
    if (!in_array($forcedType, ['', Installer::TYPE_PLUGIN, Installer::TYPE_THEME], true)) {
        $forcedType = '';
    }

    $result = null;

    try {
        $result = Installer::installUploaded($_FILES['zipfile'] ?? [], [
            'forcedType' => $forcedType,
            'upgrade'    => !empty($_POST['upgrade']),
            'maxZipMB'   => $settings['maxZipMB'],
            'maxTotalMB' => $settings['maxTotalMB'],
            'maxEntries' => $settings['maxEntries'],
        ]);
    } catch (InstallerException $e) {
        $result = ['ok' => false, 'message' => $e->getMessage()];
    } catch (\Throwable $e) {
        $result = ['ok' => false, 'message' => 'خطای غیرمنتظرهٔ سرور: ' . $e->getMessage()];
    }

    if (Session::start()) {
        $_SESSION[Plugin::SESSION_RESULT_KEY] = $result;
    }

    $response->redirect($panelUrl);
    return;
}

// ------------------------------------------------------------------
//  خواندن نتیجهٔ عملیات قبلی از نشست (الگوی POST-Redirect-GET)
// ------------------------------------------------------------------
$lastResult = null;
if (Session::start() && isset($_SESSION[Plugin::SESSION_RESULT_KEY])) {
    $lastResult = $_SESSION[Plugin::SESSION_RESULT_KEY];
    unset($_SESSION[Plugin::SESSION_RESULT_KEY]);
}

$lastCleanup = null;
if (Session::start() && isset($_SESSION[Plugin::SESSION_CLEANUP_KEY])) {
    $lastCleanup = $_SESSION[Plugin::SESSION_CLEANUP_KEY];
    unset($_SESSION[Plugin::SESSION_CLEANUP_KEY]);
}

$engineOk = $env['zipExtension'] || $env['nativeSupport'];
$packages = Installer::listPackages();
$deletableCount = 0;
foreach ($packages as $list) {
    foreach ($list as $pkg) {
        if (!empty($pkg['deletable'])) {
            $deletableCount++;
        }
    }
}

/** رندر یک ستون فهرست بسته (افزونه‌ها یا پوسته‌ها) */
$renderList = static function (string $type, array $list): void {
    $labels = [Installer::TYPE_PLUGIN => 'افزونه‌ها', Installer::TYPE_THEME => 'پوسته‌ها'];
    $hasDeletable = false;
    foreach ($list as $pkg) {
        if (!empty($pkg['deletable'])) {
            $hasDeletable = true;
            break;
        }
    }
    ?>
    <div class="zi-cleanup-col">
        <div class="zi-cleanup-col-head">
            <h4 class="zi-cleanup-col-title">
                <?php echo $labels[$type]; ?>
                <span class="zi-count"><?php echo Text::fa(count($list)); ?></span>
            </h4>
            <?php if ($hasDeletable): ?>
                <label class="zi-select-all">
                    <input type="checkbox" class="zi-select-all-check" data-scope="<?php echo $type; ?>">
                    انتخاب همهٔ غیرفعال‌ها
                </label>
            <?php endif; ?>
        </div>

        <?php if ($list === []): ?>
            <p class="zi-cleanup-empty">هیچ بسته‌ای در این بخش یافت نشد.</p>
        <?php else: ?>
            <ul class="zi-pkg-list">
                <?php foreach ($list as $pkg): ?>
                    <li class="zi-pkg<?php echo empty($pkg['deletable']) ? ' is-locked' : ' is-deletable'; ?>">
                        <label class="zi-pkg-row"
                               <?php if (empty($pkg['deletable'])): ?>
                               title="ابتدا این بسته را غیرفعال کنید تا قابل حذف شود"
                               <?php endif; ?>>
                            <?php if (!empty($pkg['deletable'])): ?>
                                <input type="checkbox" class="zi-pkg-check" data-type="<?php echo $type; ?>"
                                       name="delete[<?php echo $type; ?>][]" value="<?php echo Text::e($pkg['name']); ?>">
                            <?php else: ?>
                                <input type="checkbox" disabled>
                            <?php endif; ?>
                            <span class="zi-pkg-body">
                                <span class="zi-pkg-title">
                                    <?php echo Text::e($pkg['title']); ?>
                                    <code class="zi-pkg-dir" dir="ltr"><?php echo Text::e($pkg['name']); ?></code>
                                </span>
                                <span class="zi-pkg-meta">
                                    <?php if ($pkg['version'] !== ''): ?>
                                        نسخهٔ <span dir="ltr"><?php echo Text::e($pkg['version']); ?></span>
                                    <?php endif; ?>
                                    <?php if (!empty($pkg['broken'])): ?>
                                        <span class="zi-pkg-broken">ساختار ناقص — فایل شناسه یافت نشد</span>
                                    <?php endif; ?>
                                </span>
                            </span>
                            <?php if (!empty($pkg['self'])): ?>
                                <span class="zi-badge zi-badge-accent">این افزونه</span>
                            <?php elseif (!empty($pkg['active'])): ?>
                                <span class="zi-badge zi-badge-ok">فعال</span>
                            <?php else: ?>
                                <span class="zi-badge zi-badge-off">غیرفعال</span>
                            <?php endif; ?>
                        </label>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
    <?php
};

?>
<link rel="stylesheet" href="<?php echo Text::e($assetUrl('panel.css')); ?>">
<div class="tr-panel tr-panel-zipinstaller" dir="rtl" id="zipinstaller-panel">

    <section class="tr-card zi-hero">
        <div class="tr-card-b">
            <div class="tr-panel-head">
                <div class="tr-panel-heading">
                    <h2 class="tr-panel-title">نصب از فایل زیپ</h2>
                    <p class="tr-panel-desc">
                        فایل ZIP پوسته یا افزونه را انتخاب کنید؛ نوع بسته به‌صورت خودکار تشخیص داده می‌شود،
                        پس از بررسی امنیتی ساختار، در مسیر درست استخراج می‌شود و مجوز‌های استاندارد
                        (پوشه‌ها 755 و فایل‌ها 644) روی آن اعمال می‌گردد.
                    </p>
                </div>
                <div class="tr-panel-pills">
                    <span class="tr-pill tr-pill-accent">مثل نصب وردپرس، با چند کلیک</span>
                    <span class="tr-pill"><?php echo $env['zipExtension'] ? 'موتور ZipArchive' : 'موتور داخلی PHP'; ?></span>
                    <span class="tr-pill">سقف آپلود: <?php echo Text::fa(Text::bytes($effectiveMax)); ?></span>
                </div>
            </div>

            <div class="zi-security-note" role="note">
                <span class="zi-security-icon" aria-hidden="true">
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                </span>
                <p>پیش از نصب هر پوسته یا افزونه، از سایت خود پشتیبان کامل بگیرید و بسته‌ها را تنها از منابع معتبر دریافت کنید؛ نصب امن، رمز آرامش سایت شماست.</p>
            </div>
        </div>
    </section>

    <?php if (is_array($lastResult) && !empty($lastResult)): ?>
        <?php if (!empty($lastResult['ok'])): ?>
            <section class="tr-card zi-result zi-result-success" id="zi-result">
                <div class="tr-card-b">
                    <div class="zi-result-head">
                        <span class="zi-result-icon" aria-hidden="true">
                            <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                        </span>
                        <div>
                            <h3 class="zi-result-title">
                                <?php echo Text::e($lastResult['typeLabel']); ?> «<?php echo Text::e($lastResult['info']['title'] ?? $lastResult['dirName']); ?>» با موفقیت نصب شد
                            </h3>
                            <p class="zi-result-sub">
                                نصب <?php echo empty($lastResult['upgraded']) ? 'تازه' : 'و جایگزینی نسخهٔ قبلی'; ?>
                                — مسیر نصب: <code dir="ltr"><?php echo Text::e($lastResult['target']); ?></code>
                                <?php if (!empty($lastResult['info']['version'])): ?>
                                    — نسخهٔ <span dir="ltr"><?php echo Text::e($lastResult['info']['version']); ?></span>
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>

                    <div class="zi-stat-grid">
                        <div class="zi-stat"><strong><?php echo Text::fa($lastResult['stats']['files']); ?></strong><span>فایل</span></div>
                        <div class="zi-stat"><strong><?php echo Text::fa($lastResult['stats']['dirs']); ?></strong><span>پوشه</span></div>
                        <div class="zi-stat"><strong><?php echo Text::fa(Text::bytes((int) $lastResult['stats']['bytes'])); ?></strong><span>حجم استخراج‌شده</span></div>
                        <?php if ((int) $lastResult['stats']['junk'] > 0): ?>
                            <div class="zi-stat"><strong><?php echo Text::fa($lastResult['stats']['junk']); ?></strong><span>فایل سیستمی حذف‌شده</span></div>
                        <?php endif; ?>
                    </div>

                    <?php if (!empty($lastResult['warnings'])): ?>
                        <div class="zi-warn-box" role="note">
                            <ul>
                                <?php foreach ($lastResult['warnings'] as $warning): ?>
                                    <li><?php echo Text::e((string) $warning); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <div class="zi-result-actions">
                        <?php if ($lastResult['type'] === Installer::TYPE_PLUGIN): ?>
                            <a class="btn primary" href="<?php echo $options->adminUrl('plugins.php', true); ?>">مشاهدهٔ فهرست افزونه‌ها</a>
                        <?php else: ?>
                            <a class="btn primary" href="<?php echo $options->adminUrl('themes.php', true); ?>">مشاهدهٔ فهرست پوسته‌ها</a>
                        <?php endif; ?>
                        <a class="btn" href="#zi-form">نصب بستهٔ بعدی</a>
                    </div>
                </div>
            </section>
        <?php else: ?>
            <section class="tr-card zi-result zi-result-error" id="zi-result">
                <div class="tr-card-b">
                    <div class="zi-result-head">
                        <span class="zi-result-icon" aria-hidden="true">
                            <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                        </span>
                        <div>
                            <h3 class="zi-result-title">نصب انجام نشد</h3>
                            <p class="zi-result-sub zi-error-message"><?php echo Text::e((string) ($lastResult['message'] ?? 'خطای ناشناخته')); ?></p>
                        </div>
                    </div>
                    <div class="zi-note-box">
                        در پی خطا، همهٔ فایل‌های ناقص به‌طور کامل پاک‌سازی شده (Rollback) و فایل زیپ نیز حذف شده است؛
                        وضعیت پوسته‌ها و افزونه‌های موجود دست‌نخورده باقی مانده است.
                    </div>
                    <div class="zi-result-actions">
                        <a class="btn" href="#zi-form">تلاش دوباره</a>
                    </div>
                </div>
            </section>
        <?php endif; ?>
    <?php endif; ?>

    <?php if (!$engineOk || !$env['pluginsWritable'] || !$env['themesWritable'] || !$env['usrWritable']): ?>
        <section class="tr-card zi-env-card zi-env-alert">
            <div class="tr-card-b">
                <h3 class="zi-section-title">برای نصب، ابتدا موارد زیر را برطرف کنید</h3>
                <ul class="zi-checks">
                    <?php if (!$engineOk): ?>
                        <li class="is-bad">نه افزونهٔ ZipArchive روی سرور فعال است و نه امکان خواندن داخلی (zlib) وجود دارد.</li>
                    <?php endif; ?>
                    <?php if (!$env['usrWritable']): ?>
                        <li class="is-bad">پوشهٔ <code dir="ltr">usr/</code> قابل نوشتن نیست؛ دسترسی نوشتن را به میزبان خود اعلام کنید.</li>
                    <?php endif; ?>
                    <?php if (!$env['pluginsWritable']): ?>
                        <li class="is-bad">پوشهٔ <code dir="ltr"><?php echo Text::e($env['pluginBase']); ?></code> قابل نوشتن نیست؛ نصب افزونه ممکن نیست.</li>
                    <?php endif; ?>
                    <?php if (!$env['themesWritable']): ?>
                        <li class="is-bad">پوشهٔ <code dir="ltr"><?php echo Text::e($env['themeBase']); ?></code> قابل نوشتن نیست؛ نصب پوسته ممکن نیست.</li>
                    <?php endif; ?>
                </ul>
            </div>
        </section>
    <?php endif; ?>

    <section class="tr-card" id="zi-form">
        <div class="tr-card-b">
            <h3 class="zi-section-title">آپلود بسته</h3>

            <form method="post" action="<?php echo Text::e($panelUrl); ?>"
                  enctype="multipart/form-data" id="zi-upload-form" data-max="<?php echo (int) $effectiveMax; ?>">
                <input type="hidden" name="_" value="<?php echo Text::e($security->getToken($request->getRequestUrl())); ?>">
                <input type="hidden" name="MAX_FILE_SIZE" value="<?php echo (int) $effectiveMax; ?>">

                <div class="zi-dropzone" id="zi-dropzone" tabindex="0" role="button"
                     aria-label="انتخاب فایل زیپ">
                    <input type="file" name="zipfile" id="zi-file" accept=".zip,application/zip,application/x-zip-compressed" hidden>
                    <span class="zi-dropzone-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                            <polyline points="17 8 12 3 7 8"/>
                            <line x1="12" y1="3" x2="12" y2="15"/>
                        </svg>
                    </span>
                    <p class="zi-dropzone-title">فایل ZIP پوسته یا افزونه را اینجا بکشید و رها کنید</p>
                    <p class="zi-dropzone-sub">
                        یا برای انتخاب فایل کلیک کنید — حداکثر حجم مجاز: <?php echo Text::fa(Text::bytes($effectiveMax)); ?>
                    </p>
                    <span class="zi-file-chip" id="zi-file-chip" hidden>
                        <span class="zi-file-chip-icon" aria-hidden="true">
                            <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                                <polyline points="14 2 14 8 20 8"/>
                            </svg>
                        </span>
                        <span class="zi-file-name" dir="ltr"></span>
                        <span class="zi-file-size"></span>
                        <button type="button" class="zi-file-remove" id="zi-file-remove" aria-label="حذف فایل انتخاب‌شده" title="حذف فایل انتخاب‌شده">
                            <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                        </button>
                    </span>
                </div>

                <p class="zi-form-error" id="zi-form-error" role="alert" hidden></p>

                <fieldset class="zi-type-fieldset">
                    <legend class="zi-legend">نوع بسته</legend>
                    <div class="zi-type-grid">
                        <label class="zi-type-card">
                            <input type="radio" name="type" value="" checked>
                            <span class="zi-type-name">تشخیص خودکار</span>
                            <span class="zi-type-desc">پیشنهادی — نوع بسته از ساختار آن شناسایی می‌شود</span>
                        </label>
                        <label class="zi-type-card">
                            <input type="radio" name="type" value="plugin">
                            <span class="zi-type-name">افزونه</span>
                            <span class="zi-type-desc">بسته باید در ریشهٔ خود Plugin.php داشته باشد</span>
                        </label>
                        <label class="zi-type-card">
                            <input type="radio" name="type" value="theme">
                            <span class="zi-type-name">پوسته</span>
                            <span class="zi-type-desc">بسته باید در ریشهٔ خود index.php داشته باشد</span>
                        </label>
                    </div>
                </fieldset>

                <label class="zi-upgrade">
                    <input type="checkbox" name="upgrade" value="1">
                    <span>به‌روزرسانی نسخهٔ موجود — اگر بسته‌ای با همین نام نصب است، جایگزین شود
                        <small>نسخهٔ فعلی ابتدا به‌صورت پشتیبان کنار گذاشته می‌شود و در صورت خطا به‌طور کامل بازگردانی می‌گردد.</small>
                    </span>
                </label>

                <div class="zi-form-actions">
                    <button type="submit" class="btn primary" id="zi-submit">آپلود و نصب</button>
                    <span class="zi-form-hint">پیش از استخراج، ساختار بسته و امنیت مسیرها بررسی می‌شود.</span>
                </div>
            </form>
        </div>
    </section>

    <section class="tr-card" id="zi-cleanup">
        <div class="tr-card-b">
            <h3 class="zi-section-title">مدیریت بسته‌ها — حذف پوسته‌ها و افزونه‌های غیرفعال</h3>

            <?php if (is_array($lastCleanup) && !empty($lastCleanup)): ?>
                <section class="zi-cleanup-result <?php echo !empty($lastCleanup['ok']) ? 'is-ok' : 'is-bad'; ?>" id="zi-cleanup-result">
                    <?php if (!empty($lastCleanup['ok'])): ?>
                        <div class="zi-cleanup-result-head">
                            <span class="zi-cleanup-result-icon is-ok" aria-hidden="true">
                                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            </span>
                            <strong><?php echo Text::fa(count($lastCleanup['deleted'] ?? [])); ?> بسته با موفقیت حذف شد</strong>
                        </div>
                        <ul class="zi-cleanup-result-list">
                            <?php foreach (($lastCleanup['deleted'] ?? []) as $del): ?>
                                <li>
                                    <?php echo Text::e($del['typeLabel']); ?>
                                    «<?php echo Text::e($del['title'] ?? $del['name']); ?>»
                                    (<code dir="ltr"><?php echo Text::e($del['name']); ?></code>)
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <div class="zi-cleanup-result-head">
                            <span class="zi-cleanup-result-icon is-bad" aria-hidden="true">
                                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                            </span>
                            <strong>حذف انجام نشد</strong>
                        </div>
                    <?php endif; ?>

                    <?php foreach (($lastCleanup['errors'] ?? []) as $err): ?>
                        <p class="zi-cleanup-error"><?php echo Text::e((string) $err); ?></p>
                    <?php endforeach; ?>

                    <?php foreach (($lastCleanup['warnings'] ?? []) as $warn): ?>
                        <p class="zi-cleanup-warning"><?php echo Text::e((string) $warn); ?></p>
                    <?php endforeach; ?>
                </section>
            <?php endif; ?>

            <p class="zi-cleanup-desc">
                بسته‌های غیرفعالِ ناخواسته را انتخاب و حذف کنید. افزونه‌های فعال و پوستهٔ جاری سایت
                به‌صورت خودکار قفل می‌شوند و پیش از حذف، فعال نبودن همهٔ موارد سمت سرور نیز مجدداً بررسی می‌گردد.
            </p>

            <form method="post" action="<?php echo Text::e($panelUrl); ?>" id="zi-cleanup-form">
                <input type="hidden" name="_" value="<?php echo Text::e($security->getToken($request->getRequestUrl())); ?>">
                <input type="hidden" name="do" value="cleanup">

                <div class="zi-cleanup-grid">
                    <?php $renderList(Installer::TYPE_PLUGIN, $packages[Installer::TYPE_PLUGIN] ?? []); ?>
                    <?php $renderList(Installer::TYPE_THEME, $packages[Installer::TYPE_THEME] ?? []); ?>
                </div>

                <p class="zi-form-error" id="zi-cleanup-error" role="alert" hidden></p>

                <div class="zi-form-actions">
                    <button type="submit" class="btn zi-btn-danger" id="zi-cleanup-submit"
                            <?php echo $deletableCount === 0 ? 'disabled' : ''; ?>>
                        حذف بسته‌های انتخاب‌شده
                    </button>
                    <span class="zi-form-hint">حذف، دائمی و بازگشت‌ناپذیر است؛ در صورت بروز خطا هیچ بسته‌ای حذف نمی‌شود.</span>
                </div>
            </form>
        </div>
    </section>

    <section class="tr-card zi-env-card">
        <div class="tr-card-b">
            <h3 class="zi-section-title">وضعیت محیط سرور</h3>
            <ul class="zi-checks">
                <li class="<?php echo $env['zipExtension'] ? 'is-ok' : 'is-ok'; ?>">
                    موتور خواندن زیپ:
                    <?php echo $env['zipExtension']
                        ? 'افزونهٔ ZipArchive (استاندارد)'
                        : 'موتور داخلی خالص PHP (بدون نیاز به افزونهٔ ZipArchive)'; ?>
                </li>
                <li class="<?php echo $env['uploadMax'] > 0 ? 'is-ok' : 'is-warn'; ?>">
                    سقف آپلود سرور (upload_max_filesize):
                    <span dir="ltr"><?php echo Text::e((string) ini_get('upload_max_filesize')); ?></span>
                    — سقف فرم (post_max_size): <span dir="ltr"><?php echo Text::e((string) ini_get('post_max_size')); ?></span>
                </li>
                <li class="<?php echo $env['pluginsWritable'] ? 'is-ok' : 'is-bad'; ?>">
                    دسترسی نوشتن پوشهٔ افزونه‌ها: <?php echo Text::e($env['pluginBase']); ?>
                </li>
                <li class="<?php echo $env['themesWritable'] ? 'is-ok' : 'is-bad'; ?>">
                    دسترسی نوشتن پوشهٔ پوسته‌ها: <?php echo Text::e($env['themeBase']); ?>
                </li>
                <li class="is-ok">
                    مسیر کاری موقت: <code dir="ltr">usr/.zi-*</code> — پس از هر نصب (موفق یا ناموفق) به‌طور کامل حذف می‌شود.
                </li>
            </ul>
            <div class="zi-note-box">
                <strong>چه چیزهایی به‌طور خودکار بررسی می‌شود؟</strong>
                مقابله با حملهٔ Zip Slip (پیمایش مسیر)، پالایش فایل‌های سیستنی مانند
                <code dir="ltr">__MACOSX</code> و <code dir="ltr">.DS_Store</code> و <code dir="ltr">.git</code>،
                وارسی صحت داده‌ها با CRC32، سقف حجم و تعداد فایل، و بازگردانی کامل (Rollback) در صورت بروز خطا.
                فایل زیپ پس از پایان فرایند نیز کاملاً حذف می‌شود.
            </div>
        </div>
    </section>

</div>
<script src="<?php echo Text::e($assetUrl('panel.js')); ?>"></script>
