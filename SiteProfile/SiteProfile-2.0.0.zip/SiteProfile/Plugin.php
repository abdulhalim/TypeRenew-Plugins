<?php
declare(strict_types=1);

namespace TypechoPlugin\SiteProfile;

use Typecho\Common;
use Typecho\Cookie;
use Typecho\Plugin as Hook;
use Typecho\Plugin\PluginInterface;
use Typecho\Request as HttpRequest;
use Typecho\Response as HttpResponse;
use Typecho\Router;
use Typecho\Widget\Response as WidgetResponse;
use Typecho\Widget\Helper\Form;
use Utils\Helper;
use Utils\NoPersonal;
use Utils\Session;
use Widget\Archive;
use Widget\Options;
use Widget\User;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * پروفایل کامل کاربران در محیط سایت: ویرایش حساب، آواتار محلی، صفحهٔ عمومی و باکس نویسنده (مخصوص TypeRenew).
 *
 * @package SiteProfile
 * @author TypeRenew
 * @link https://typerenew.ir/
 * @version 2.0.0
 * @since 1.6.0
 */
class Plugin implements PluginInterface
{
    use NoPersonal;

    /** نام مسیر صفحه ویرایش پروفایل */
    public const ROUTE_NAME = 'siteprofile';

    /** مسیر صفحه ویرایش پروفایل در محیط سایت */
    public const ROUTE_PATH = '/profile';

    /** نام مسیر صفحهٔ عمومی کاربر */
    public const MEMBER_ROUTE_NAME = 'siteprofile_member';

    /** مسیر صفحهٔ عمومی هر کاربر (پارامتر uid) */
    public const MEMBER_ROUTE_PATH = '/profile/[uid:digital]';

    /** کلید پیام‌های یک‌بارمصرف در نشست */
    private const FLASH_KEY = '__site_profile_flash';

    /** گروه‌های مجاز برای تنظیم آستانه دسترسی به پنل مدیریت */
    private const GROUPS = ['contributor', 'editor', 'administrator'];

    /** صفحات عمومی پنل مدیریت که نباید برای کاربر عادی بسته شوند */
    private const PUBLIC_ADMIN_PAGES = ['login.php', 'register.php', 'forgot.php', 'reset.php'];

    /** آیا جریان فعلی از مسیر ثبت‌نام آمده است؟ */
    private static bool $fromRegister = false;

    /** کش تنظیمات افزونه برای درخواست جاری */
    private static ?array $settingsCache = null;

    /**
     * فعال‌سازی افزونه: ساخت جدول داده‌ها، ثبت مسیرها و هوک‌ها
     */
    public static function activate(): string
    {
        Meta::ensureTable();
        Avatar::ensureDir();

        Helper::removeRoute(self::MEMBER_ROUTE_NAME);
        Helper::removeRoute(self::ROUTE_NAME);
        Helper::addRoute(self::MEMBER_ROUTE_NAME, self::MEMBER_ROUTE_PATH, Action::class, 'member');
        Helper::addRoute(self::ROUTE_NAME, self::ROUTE_PATH, Action::class, 'page');

        // پس از ورود موفق از فرم ورود (پس از پاک‌سازی محدودیت ورود و نوسازی نشست هسته)
        //
        // وزن ۵- (اجرا پیش از وزن ۰): افزونهٔ انجمن (Forum) هم روی همین سیگنال،
        // کاربران عادی را به پروفایل انجمن هدایت می‌کند؛ چون طبق طراحی این
        // افزونه صفحهٔ پروفایل محیط سایت مرجع اصلی کاربر است (و انجمن با آن
        // همگام می‌شود)، هدایت ما تقدم دارد. پاک‌سازی محدودیت ورود (LoginGuard)
        // و نوسازی نشست پیش از خودِ سیگنال در Widget\Login::action انجام
        // می‌شود، بنابراین پیش‌دستی هیچ رفتار امنیتی هسته را دور نمی‌زند.
        Hook::factory('Widget\Login')->loginSuccess_5 = [Plugin::class, 'onLoginSuccess'];

        // پس از ورود خودکار در پایان ثبت‌نام
        Hook::factory('Widget\User')->loginSucceed_100 = [Plugin::class, 'onUserLoginSucceed'];

        // تشخیص جریان ثبت‌نام (برای پیام خوش‌آمد مناسب و پاک‌سازی کوکی‌ها)
        //
        // وزن ۵-: پیش از افزونهٔ انجمن اجرا می‌شود تا پرچم «جریان ثبت‌نام»
        // پیش از ورود خودکارِ احتمالی آن افزونه فعال باشد و هدایت ثبت‌نام
        // توسط همین افزونه انجام شود.
        Hook::factory('Widget\Register')->finishRegister_5 = [Plugin::class, 'onFinishRegister'];

        // بستن پنل مدیریت برای کاربران عادی + هدایت admin/profile.php
        //
        // وزن ۵-: برای تعیین تکلیف هم‌زیستی با افزونهٔ انجمن (که کاربران
        // عادی را به پروفایل انجمن می‌فرستد) پیش از آن اجرا می‌شویم؛ مقصد
        // همیشگی این افزونه صفحهٔ پروفایل محیط سایت است.
        Hook::factory('admin/common.php')->begin_5 = [Plugin::class, 'onAdminBegin'];

        // درج باکس نویسنده در انتهای محتوای نوشته‌ها (درست پیش از رندر قالب)
        Hook::factory('Widget\Archive')->beforeRender = [Plugin::class, 'onBeforeRender'];

        // تعویض گراواتار با آواتار محلی در صفحات انجمن (بدون دست‌بردن به افزونهٔ انجمن)
        //
        // صفحات انجمن با کلاس‌های ویجت خودِ افزونهٔ Forum رندر می‌شوند و
        // سیگنال header با همان کلاس نهایی فراخوانده می‌شود؛ بنابراین علاوه
        // بر Widget\Archive، روی خود ویجت‌های انجمن نیز ثبت می‌کنیم.
        Hook::factory('Widget\Archive')->header = [Plugin::class, 'onArchiveHeader'];

        foreach (ForumSync::FORUM_PAGE_WIDGETS as $forumWidget) {
            Hook::factory($forumWidget)->header = [Plugin::class, 'onArchiveHeader'];
        }

        return 'افزونه پروفایل کاربری فعال شد. صفحهٔ ویرایش پروفایل: '
            . self::profileUrl();
    }

    /**
     * غیرفعال‌سازی افزونه: حذف مسیرها
     *
     * جدول داده‌های تکمیلی (بیوگرافی و شبکه‌های اجتماعی) عمداً حذف نمی‌شود
     * تا با خاموش/روشن‌کردن افزونه، داده‌های کاربران از بین نرود.
     */
    public static function deactivate(): string
    {
        Helper::removeRoute(self::MEMBER_ROUTE_NAME);
        Helper::removeRoute(self::ROUTE_NAME);

        return 'افزونه پروفایل کاربری غیرفعال شد. (داده‌های بیوگرافی و شبکه‌های اجتماعی در دیتابیس باقی می‌ماند.)';
    }

    /**
     * فرم تنظیمات افزونه در پنل مدیریت
     */
    public static function config(Form $form): void
    {
        $minGroup = new Form\Element\Select(
            'minGroup',
            [
                'contributor' => 'نویسنده همکار و بالاتر (پیشنهادی)',
                'editor' => 'ویراستار و بالاتر',
                'administrator' => 'فقط مدیر کل'
            ],
            'contributor',
            'حداقل سطح مجاز به استفاده از پنل مدیریت',
            'کاربرانی که سطحشان از گروه انتخاب‌شده پایین‌تر باشد «کاربر عادی» در نظر گرفته می‌شوند؛'
                . ' پس از ورود یا ثبت‌نام به صفحه پروفایل سایت هدایت می‌شوند و با باز کردن پنل مدیریت نیز به همان صفحه برمی‌گردند.'
        );
        $form->addInput($minGroup);

        $loginRedirect = new Form\Element\Radio(
            'loginRedirect',
            ['1' => 'فعال', '0' => 'غیرفعال'],
            '1',
            'هدایت کاربران عادی به صفحه پروفایل پس از ورود/ثبت‌نام',
            'پس از ورود یا ثبت‌نام موفق، کاربران عادی به‌جای پروفایل پنل مدیریت به صفحه پروفایل محیط سایت منتقل می‌شوند.'
        );
        $form->addInput($loginRedirect);

        $blockAdmin = new Form\Element\Radio(
            'blockAdmin',
            ['1' => 'فعال', '0' => 'غیرفعال'],
            '1',
            'بستن پنل مدیریت برای کاربران عادی',
            'کاربران عادی با باز کردن هر آدرسی از پنل مدیریت (/admin) به صفحه پروفایل سایت منتقل می‌شوند؛ مدیران دسترسی کامل دارند.'
        );
        $form->addInput($blockAdmin);

        $adminProfileRedirect = new Form\Element\Radio(
            'adminProfileRedirect',
            ['1' => 'فعال', '0' => 'غیرفعال'],
            '1',
            'هدایت صفحهٔ پروفایل پنل (admin/profile.php) به همین صفحه',
            'صفحهٔ «پروفایل» پنل مدیریت نیز به صفحهٔ پروفایل محیط سایت هدایت می‌شود تا همهٔ کاربران — از جمله مدیر — اطلاعات حساب خود را از همان‌جا ویرایش کنند.'
        );
        $form->addInput($adminProfileRedirect);

        $embedTheme = new Form\Element\Radio(
            'embedTheme',
            ['1' => 'فعال', '0' => 'غیرفعال'],
            '1',
            'نمایش صفحه‌های پروفایل در قالب پوسته سایت',
            'صفحه پروفایل و صفحهٔ عمومی کاربران با هدر و فوتر پوسته فعال سایت رندر می‌شوند و همراه پوسته، حالت روز/شب را پشتیبانی می‌کنند. اگر پوسته فایل هدر یا فوتر نداشته باشد، به‌طور خودکار صفحه مستقل افزونه نمایش داده می‌شود.'
        );
        $form->addInput($embedTheme);

        $publicProfile = new Form\Element\Radio(
            'publicProfile',
            ['1' => 'فعال', '0' => 'غیرفعال'],
            '1',
            'صفحهٔ عمومی کاربران در /profile/شناسه',
            'هر کاربر یک صفحهٔ اختصاصی عمومی دارد؛ شامل بیوگرافی، شبکه‌های اجتماعی، تاریخ عضویت، آخرین ورود، نوشته‌ها و فهرست نظرات. این صفحه در باکس نویسنده هم به نام کاربر پیوند داده می‌شود.'
        );
        $form->addInput($publicProfile);

        $showLastLogin = new Form\Element\Radio(
            'showLastLogin',
            ['1' => 'فعال', '0' => 'غیرفعال'],
            '1',
            'نمایش تاریخ آخرین ورود در صفحهٔ عمومی',
            'اگر نمی‌خواهید زمان آخرین ورود کاربران برای بازدیدکنندگان نمایش داده شود، این گزینه را خاموش کنید.'
        );
        $form->addInput($showLastLogin);

        $autoAuthorBox = new Form\Element\Radio(
            'autoAuthorBox',
            ['1' => 'فعال', '0' => 'غیرفعال'],
            '1',
            'باکس نویسنده در انتهای نوشته‌ها',
            'اطلاعات نویسنده (آواتار، بیوگرافی، شبکه‌های اجتماعی و پیوند صفحه‌اش) به‌صورت خودکار در انتهای هر نوشته نمایش داده می‌شود. برای کنترل دقیق‌تر می‌توانید این گزینه را خاموش کنید و باکس را به‌صورت دستی در post.php پوسته با کد مستندشده در README فراخوانی کنید.'
        );
        $form->addInput($autoAuthorBox);

        $perPage = new Form\Element\Text(
            'perPage',
            null,
            '10',
            'تعداد آیتم در هر صفحه (صفحهٔ عمومی کاربر)',
            'حداکثر تعداد نوشته/نظر/پرسش در هر صفحهٔ تب‌های صفحهٔ عمومی کاربر. عددی بین ۱ تا ۵۰.'
        );
        $perPage->input->setAttribute('class', 'w-20');
        $form->addInput($perPage);

        $avatarTab = new Form\Element\Radio(
            'avatarTab',
            ['1' => 'فعال', '0' => 'غیرفعال'],
            '1',
            'تب آواتار محلی (جایگزین گراواتار)',
            'با فعال‌بودن این گزینه، تب «آواتار» پس از تب پروفایل نمایش داده می‌شود و کاربران می‌توانند به‌جای گراواتار تصویر اختصاصی خود را بارگذاری کنند. تصویر به‌صورت خودکار به WebP تبدیل و مربع مرکزی آن برش می‌خورد.'
        );
        $form->addInput($avatarTab);

        $avatarMinKB = new Form\Element\Text(
            'avatarMinKB',
            null,
            '50',
            'حداقل حجم تصویر آواتار (کیلوبایت)',
            'تصاویر کوچک‌تر از این حجم پذیرفته نمی‌شوند (۰ = بدون حداقل).'
        );
        $avatarMinKB->input->setAttribute('class', 'w-20');
        $form->addInput($avatarMinKB);

        $avatarMaxKB = new Form\Element\Text(
            'avatarMaxKB',
            null,
            '1024',
            'حداکثر حجم تصویر آواتار (کیلوبایت)',
            'تصاویر بزرگ‌تر از این حجم پذیرفته نمی‌شوند؛ پیش‌فرض ۱۰۲۴ کیلوبایت (۱ مگابایت).'
        );
        $avatarMaxKB->input->setAttribute('class', 'w-20');
        $form->addInput($avatarMaxKB);

        $avatarSize = new Form\Element\Text(
            'avatarSize',
            null,
            '150',
            'ابعاد آواتار (پیکسل، مربع)',
            'تصویر بارگذاری‌شده به همین ابعاد مربعی (برش مرکزی) تبدیل می‌شود؛ مثلاً ۱۵۰ یعنی ۱۵۰×۱۵۰ پیکسل. عددی بین ۳۲ تا ۵۱۲.'
        );
        $avatarSize->input->setAttribute('class', 'w-20');
        $form->addInput($avatarSize);

        $avatarFormats = new Form\Element\Checkbox(
            'avatarFormats',
            [
                'jpg'  => 'JPG',
                'png'  => 'PNG',
                'webp' => 'WebP',
                'gif'  => 'GIF',
            ],
            ['jpg', 'png', 'webp'],
            'فرمت‌های مجاز تصویر آواتار',
            'فایل‌های بارگذاری‌شده باید یکی از این فرمت‌ها را داشته باشند؛ خروجی همیشه به WebP تبدیل می‌شود.'
        );
        $form->addInput($avatarFormats);

        $forumSync = new Form\Element\Radio(
            'forumSync',
            ['1' => 'فعال', '0' => 'غیرفعال'],
            '1',
            'همگام‌سازی با افزونهٔ انجمن (Forum)',
            'در صورت نصب و فعال‌بودن افزونهٔ Forum: بیوگرافی و شبکه‌های اجتماعی بین صفحه پروفایل و انجمن دوطرفه همگام می‌شود، آواتار محلی کاربران در صفحات انجمن جایگزین گراواتار می‌شود و تب «پرسش و پاسخ» به صفحهٔ عمومی کاربران افزوده می‌شود.'
        );
        $form->addInput($forumSync);
    }

    /**
     * خواندن تنظیمات افزونه (همراه با کش و مقادیر پیش‌فرض امن)
     */
    public static function settings(): array
    {
        if (self::$settingsCache !== null) {
            return self::$settingsCache;
        }

        $settings = [
            'minGroup'             => 'contributor',
            'loginRedirect'        => '1',
            'blockAdmin'           => '1',
            'adminProfileRedirect' => '1',
            'embedTheme'           => '1',
            'publicProfile'        => '1',
            'showLastLogin'        => '1',
            'autoAuthorBox'        => '1',
            'perPage'              => 10,
            'avatarTab'            => '1',
            'avatarMinKB'          => 50,
            'avatarMaxKB'          => 1024,
            'avatarSize'           => 150,
            'avatarFormats'        => ['jpg', 'png', 'webp'],
            'forumSync'            => '1'
        ];

        try {
            $config = Options::alloc()->plugin('SiteProfile');
            $stored = method_exists($config, 'toArray') ? (array) $config->toArray() : [];
        } catch (\Throwable) {
            $stored = [];
        }

        if (isset($stored['minGroup']) && in_array((string) $stored['minGroup'], self::GROUPS, true)) {
            $settings['minGroup'] = (string) $stored['minGroup'];
        }

        foreach (['loginRedirect', 'blockAdmin', 'adminProfileRedirect', 'embedTheme', 'publicProfile', 'showLastLogin', 'autoAuthorBox', 'avatarTab', 'forumSync'] as $key) {
            if (isset($stored[$key]) && in_array((string) $stored[$key], ['0', '1'], true)) {
                $settings[$key] = (string) $stored[$key];
            }
        }

        // تنظیم‌های عددی صفحه‌بندی و آواتار
        foreach (['perPage' => [1, 50], 'avatarMinKB' => [0, 10240], 'avatarMaxKB' => [1, 10240], 'avatarSize' => [32, 512]] as $key => [$lo, $hi]) {
            if (isset($stored[$key])) {
                $value = (int) $stored[$key];
                $settings[$key] = max($lo, min($hi, $value));
            }
        }

        // سقف حجم نباید از کف حجم کمتر شود
        if ((int) $settings['avatarMaxKB'] < (int) $settings['avatarMinKB']) {
            $settings['avatarMaxKB'] = $settings['avatarMinKB'];
        }

        // فرمت‌های مجاز آواتار
        $formats = (array) ($stored['avatarFormats'] ?? []);
        $settings['avatarFormats'] = array_values(array_intersect(
            ['jpg', 'png', 'webp', 'gif'],
            array_map('strval', $formats)
        ));

        return self::$settingsCache = $settings;
    }

    /**
     * آدرس کامل صفحه ویرایش پروفایل در محیط سایت
     */
    public static function profileUrl(): string
    {
        $index = (string) Options::alloc()->index;

        if (Router::get(self::ROUTE_NAME) !== null) {
            return Router::url(self::ROUTE_NAME, [], $index);
        }

        return Common::url(ltrim(self::ROUTE_PATH, '/'), $index);
    }

    /**
     * آدرس صفحهٔ عمومی یک کاربر
     */
    public static function memberUrl(int $uid): string
    {
        $index = (string) Options::alloc()->index;

        if (Router::get(self::MEMBER_ROUTE_NAME) !== null) {
            return Router::url(self::MEMBER_ROUTE_NAME, ['uid' => $uid], $index);
        }

        return Common::url('profile/' . $uid, $index);
    }

    /**
     * هدایت کاربر به آدرس مشخص و پایان درخواست (خارج از چرخه ویجت‌ها)
     */
    public static function redirect(string $url): void
    {
        $response = new WidgetResponse(HttpRequest::getInstance(), HttpResponse::getInstance());
        $response->redirect($url);
    }

    /**
     * ثبت پیام یک‌بارمصرف برای نمایش در صفحه پروفایل
     */
    public static function flash(string $type, string $message): void
    {
        if (Session::start()) {
            $_SESSION[self::FLASH_KEY] = ['type' => $type, 'message' => $message];
        }
    }

    /**
     * خواندن و حذف پیام یک‌بارمصرف
     *
     * @return array{type: string, message: string}|null
     */
    public static function pullFlash(): ?array
    {
        if (!Session::start() || empty($_SESSION[self::FLASH_KEY]) || !is_array($_SESSION[self::FLASH_KEY])) {
            return null;
        }

        $flash = $_SESSION[self::FLASH_KEY];
        unset($_SESSION[self::FLASH_KEY]);

        return $flash;
    }

    /**
     * آیا این کاربر باید به صفحه پروفایل سایت هدایت شود؟
     *
     * کاربران «عادی» (پایین‌تر از آستانه تنظیم‌شده) بله؛ بقیه رفتار
     * پیش‌فرض سیستم را می‌گیرند.
     */
    private static function shouldRedirect($user): bool
    {
        if (!($user instanceof User) || !$user->hasLogin()) {
            return false;
        }

        return !$user->pass(self::settings()['minGroup'], true);
    }

    /**
     * هوک: ورود موفق از فرم ورود (Widget\Login)
     *
     * این هوک پس از پاک‌سازی محدودیت ورود (LoginGuard) و نوسازی شناسه
     * نشست اجرا می‌شود تا هیچ رفتار امنیتی هسته از کار نیفتد.
     */
    public static function onLoginSuccess($user, string $name, $password, bool $remember): void
    {
        // جریان ثبت‌نام در هوک مخصوص خودش مدیریت می‌شود
        if (self::$fromRegister) {
            return;
        }

        if (self::settings()['loginRedirect'] !== '1' || !self::shouldRedirect($user)) {
            return;
        }

        self::flash('success', 'خوش آمدید! از همین صفحه می‌توانید اطلاعات حساب خود را ویرایش کنید.');
        self::redirect(self::profileUrl());
    }

    /**
     * هوک: ورود خودکار پس از ثبت‌نام (Widget\User)
     *
     * در جریان ثبت‌نام، تنها نقطه مداخله پیش از انتقال کاربر به پنل
     * مدیریت همین هوک است؛ بنابراین هدایت ثبت‌نام‌شده‌ها این‌جا انجام
     * می‌شود.
     */
    public static function onUserLoginSucceed($user, string $name, string $password, bool $temporarily, int $expire): void
    {
        // فقط جریان ثبت‌نام؛ ورودهای عادی در onLoginSuccess مدیریت می‌شوند
        if (!self::$fromRegister || $temporarily) {
            return;
        }

        if (self::settings()['loginRedirect'] !== '1' || !self::shouldRedirect($user)) {
            return;
        }

        self::flash('success', 'ثبت‌نام شما با موفقیت کامل شد؛ از همین صفحه می‌توانید اطلاعات حساب خود را تکمیل کنید.');
        self::redirect(self::profileUrl());
    }

    /**
     * هوک: پایان ثبت‌نام موفق (Widget\Register)
     */
    public static function onFinishRegister($widget): void
    {
        self::$fromRegister = true;

        // این کوکی‌ها در جریان پیش‌فرض پس از ثبت‌نام پاک می‌شوند؛
        // چون ورود خودکار به صفحه پروفایل هدایت می‌شود، همین‌جا پاک‌سازی می‌کنیم
        Cookie::delete('__typecho_first_run');
        Cookie::delete('__typecho_remember_name');
        Cookie::delete('__typecho_remember_mail');
    }

    /**
     * هوک: آغاز هر صفحه از پنل مدیریت
     *
     * - صفحهٔ پروفایل پنل (admin/profile.php) برای همهٔ کاربران واردشده
     *   (از جمله مدیر) به صفحهٔ پروفایل محیط سایت هدایت می‌شود تا ویرایش
     *   اطلاعات حساب از همان‌جا انجام شود.
     * - کاربران عادی از بقیهٔ صفحات پنل به صفحه پروفایل سایت برمی‌گردند و
     *   پنل مدیریت فقط برای گروه‌های مجاز باقی می‌ماند.
     */
    public static function onAdminBegin(): void
    {
        $settings = self::settings();
        $script = strtolower(basename((string) ($_SERVER['SCRIPT_NAME'] ?? '')));

        // صفحات عمومی پنل (ورود، ثبت‌نام، فراموشی و بازیابی رمز) نباید بسته شوند
        if (in_array($script, self::PUBLIC_ADMIN_PAGES, true)) {
            return;
        }

        $user = User::alloc();

        // صفحهٔ «پروفایل» پنل مدیریت → صفحهٔ پروفایل محیط سایت
        if ($settings['adminProfileRedirect'] === '1' && $script === 'profile.php' && $user->hasLogin()) {
            self::flash('notice', 'ویرایش اطلاعات حساب شما از این‌جا انجام می‌شود؛ همهٔ تنظیمات پروفایل در صفحه پروفایل محیط سایت در دسترس است.');
            self::redirect(self::profileUrl());
        }

        if ($settings['blockAdmin'] !== '1' || !self::shouldRedirect($user)) {
            return;
        }

        self::flash('notice', 'ویرایش اطلاعات حساب شما در محیط سایت انجام می‌شود؛ پنل مدیریت مخصوص مدیران است.');
        self::redirect(self::profileUrl());
    }

    /**
     * هوک: پیش از رندر آرشیو (Widget\Archive::beforeRender)
     *
     * باکس نویسنده درست پیش از رندر قالب به انتهای محتوای نوشته‌های تکی
     * اضافه می‌شود. انجام این کار در این نقطه (و نه contentEx) دو دلیل
     * فنی دارد:
     *
     * ۱. نخستین دسترسی به محتوای مطلب پیش از تعیین نوع آرشیو از مسیر
     *   محاسبهٔ «چکیده» انجام می‌شود و نتیجه در کش ویجت می‌ماند؛ فیلتر
     *   contentEx در آن لحظه هنوز نوع صفحه را نمی‌داند.
     * ۲. در آن نقطه افزودن باکس، چکیده‌ها، فیدها و توضیحات متا را هم
     *   آلوده می‌کرد؛ این‌جا محتوای نهایی قالب تغییر می‌کند و چکیده‌ها
     *   پاک می‌مانند.
     *
     * این هوک روی فهرست‌ها، برگه‌ها، فیدها و نظرات اثری ندارد.
     */
    public static function onBeforeRender($archive): void
    {
        if (self::settings()['autoAuthorBox'] !== '1' || !($archive instanceof Archive)) {
            return;
        }

        if (!$archive->is('post')) {
            return;
        }

        try {
            $uid = (int) $archive->author->uid;
        } catch (\Throwable) {
            return;
        }

        if ($uid <= 0) {
            return;
        }

        $box = Box::html($uid);

        if ($box === '') {
            return;
        }

        // نوشتن مستقیم در کش ویژگی content (الگوی __set ویجت)
        $archive->content = (string) $archive->content . $box;
    }

    /**
     * هوک: سربرگ صفحات (Widget\Archive::header)
     *
     * در صفحات انجمن، اگر کاربرانی با آواتار محلی وجود داشته باشند،
     * اسکریپتی سبک تزریق می‌شود که تصویر گراواتار آن کاربران را با آواتار
     * محلی‌شان تعویض می‌کند (نشانی گراواتار بر پایهٔ md5 ایمیل ساخته
     * می‌شود؛ نگاشت همان هش‌ها در سمت سرور آماده می‌شود). این کار بدون
     * هیچ تغییری در فایل‌های افزونهٔ انجمن انجام می‌شود.
     */
    public static function onArchiveHeader($header, $archive): void
    {
        if (!($archive instanceof Archive)) {
            return;
        }

        // فقط صفحات افزونهٔ Forum (مسیرهای /forum...)
        $path = (string) ($_SERVER['REQUEST_URI'] ?? '');

        if ($path === '' || !str_contains($path, '/forum')) {
            return;
        }

        $script = Avatar::forumSwapScript();

        if ($script !== '') {
            echo $script;
        }
    }
}
