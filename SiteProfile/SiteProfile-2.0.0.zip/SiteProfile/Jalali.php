<?php
declare(strict_types=1);

namespace TypechoPlugin\SiteProfile;

/**
 * تبدیل تاریخ میلادی به شمسی (تقویم جلالی) و قالب‌بندی تاریخ‌های فارسی
 *
 * این کلاس خودکفا است و به هیچ افزونهٔ دیگری (مانند JalaliDate) وابستگی
 * ندارد. الگوریتم تبدیل، روش صحیحِ حسابیِ متداول (jdf) است که برای
 * بازهٔ سال‌های ۱۳۰۰ تا ۱۵۰۰ شمسی دقیق است.
 *
 * @package SiteProfile
 * @since 2.0.0
 */
class Jalali
{
    /** نام ماه‌های شمسی */
    private const MONTHS = [
        'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
        'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
    ];

    /** روزهای سپری‌شده از ابتدای سال میلادی (سال غیر کبیسه) */
    private const G_DAYS = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];

    /**
     * تبدیل تاریخ میلادی به شمسی
     *
     * @return array{0: int, 1: int, 2: int} [سال، ماه، روز] شمسی
     */
    public static function toJalali(int $gy, int $gm, int $gd): array
    {
        $gy2 = $gm > 2 ? $gy + 1 : $gy;
        $days = 355666 + (365 * $gy)
            + intdiv($gy2 + 3, 4) - intdiv($gy2 + 99, 100) + intdiv($gy2 + 399, 400)
            + $gd + self::G_DAYS[$gm - 1];

        $jy = -1595 + 33 * intdiv($days, 12053);
        $days %= 12053;
        $jy += 4 * intdiv($days, 1461);
        $days %= 1461;

        if ($days > 365) {
            $jy += intdiv($days - 1, 365);
            $days = ($days - 1) % 365;
        }

        if ($days < 186) {
            $jm = 1 + intdiv($days, 31);
            $jd = 1 + ($days % 31);
        } else {
            $jm = 7 + intdiv($days - 186, 30);
            $jd = 1 + (($days - 186) % 30);
        }

        return [$jy, $jm, $jd];
    }

    /**
     * تاریخ شمسی «۲۳ شهریور ۱۴۰۴» با اعمال منطقهٔ زمانی سایت
     */
    public static function date(?int $timestamp): string
    {
        if (empty($timestamp)) {
            return '—';
        }

        [$jy, $jm, $jd] = self::toJalali(...self::gregorian($timestamp));

        return self::digits(sprintf('%d %s %d', $jd, self::MONTHS[$jm - 1], $jy));
    }

    /**
     * تاریخ و ساعت شمسی «۲۳ شهریور ۱۴۰۴، ۱۴:۰۵»
     */
    public static function dateTime(?int $timestamp): string
    {
        if (empty($timestamp)) {
            return '—';
        }

        $shifted = $timestamp + self::zoneOffset();
        $time = gmdate('G:i', $shifted);

        return self::date($timestamp) . '، ' . self::digits($time);
    }

    /**
     * اجزای میلادی یک timestamp با اعمال منطقهٔ زمانی سایت
     *
     * @return array{0: int, 1: int, 2: int} [سال، ماه، روز] میلادی
     */
    private static function gregorian(int $timestamp): array
    {
        $shifted = $timestamp + self::zoneOffset();

        return [(int) gmdate('Y', $shifted), (int) gmdate('n', $shifted), (int) gmdate('j', $shifted)];
    }

    /**
     * اختلاف منطقهٔ زمانی سایت از UTC بر حسب ثانیه
     *
     * تنظیم «timezone» سایت می‌تواند اختلاف عددی (نصب‌های قدیمی) یا شناسهٔ
     * منطقهٔ زمانی (مانند Asia/Tehran) باشد؛ هر دو حالت پشتیبانی می‌شود.
     */
    private static function zoneOffset(): int
    {
        static $offset = null;

        if ($offset !== null) {
            return $offset;
        }

        try {
            $timezone = \Widget\Options::alloc()->timezone;

            if (is_numeric($timezone)) {
                return $offset = (int) $timezone;
            }

            return $offset = (int) (new \DateTimeZone((string) $timezone))
                ->getOffset(new \DateTime('now', new \DateTimeZone('UTC')));
        } catch (\Throwable) {
            return $offset = 0;
        }
    }

    /**
     * تبدیل ارقام انگلیسی به ارقام فارسی
     */
    public static function digits(string $value): string
    {
        return strtr($value, [
            '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
            '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹'
        ]);
    }
}
