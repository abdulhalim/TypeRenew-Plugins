<?php
declare(strict_types=1);

namespace TypechoPlugin\SiteProfile;

use Typecho\Db;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * لایهٔ ذخیره‌سازی اطلاعات تکمیلی کاربران (بیوگرافی + شبکه‌های اجتماعی)
 *
 * داده‌های هستهٔ کاربر (نام مستعار، ایمیل، وب‌سایت، رمز و...) در جدول
 * users نگهداری می‌شوند؛ این کلاس جدول اختصاصی افزونه
 * ({پیشوند}siteprofile) را برای بقیهٔ داده‌ها مدیریت می‌کند.
 *
 * استفادهٔ مستقیم در قالب‌ها (post.php و...) برای خواندن داده‌های نویسنده:
 *
 *   $data = \TypechoPlugin\SiteProfile\Meta::authorData($uid);
 *   echo $data['bio'];
 *   echo $data['avatarUrl']; // آواتار محلی یا گراواتار
 *
 * @package SiteProfile
 * @since 2.0.0
 */
class Meta
{
    /**
     * شبکه‌های اجتماعی پشتیبانی‌شده
     *
     * کلید => [برچسب فارسی، الگوی ساخت نشانی از نام کاربری]
     */
    public const SOCIALS = [
        'telegram'  => ['label' => 'تلگرام',       'url' => 'https://t.me/%s'],
        'instagram' => ['label' => 'اینستاگرام',   'url' => 'https://instagram.com/%s'],
        'twitter'   => ['label' => 'توییتر (X)',   'url' => 'https://x.com/%s'],
        'github'    => ['label' => 'گیت‌هاب',      'url' => 'https://github.com/%s'],
        'linkedin'  => ['label' => 'لینکدین',      'url' => 'https://linkedin.com/in/%s'],
        'youtube'   => ['label' => 'یوتیوب',       'url' => 'https://youtube.com/@%s'],
    ];

    /** بیشینهٔ طول بیوگرافی */
    public const MAX_BIO = 500;

    /** بیشینهٔ طول هر نشانی/نام کاربری شبکهٔ اجتماعی */
    public const MAX_HANDLE = 200;

    /** ستون‌های مدیریتی جدول (خارج از داده‌های متای عمومی) */
    private const EXTRA_COLUMNS = ['avatar_file', 'forum_sync'];

    /**
     * نام کامل جدول افزونه (همراه با پیشوند دیتابیس)
     */
    public static function tableName(): string
    {
        return Db::get()->getPrefix() . 'siteprofile';
    }

    /**
     * ساخت جدول افزونه در صورت نبود (در فعال‌سازی فراخوانی می‌شود)
     *
     * هم SQLite و هم MySQL/MariaDB پشتیبانی می‌شود. جدول عمداً هنگام
     * غیرفعال‌سازی حذف نمی‌شود تا داده‌های کاربران با خاموش/روشن‌کردن
     * افزونه از بین نرود. نصب‌های موجود نسخه‌های قبلی نیز ستون‌های جدید
     * (avatar_file و forum_sync) را به‌صورت افزایشی می‌گیرند.
     */
    public static function ensureTable(): void
    {
        $db = Db::get();
        $table = self::tableName();

        if (self::isSqlite($db)) {
            $columns = '"uid" INTEGER NOT NULL PRIMARY KEY'
                . ', "bio" TEXT'
                . ', ' . implode(', ', array_map(static fn ($key): string => '"' . $key . '" VARCHAR(200)', array_keys(self::SOCIALS)))
                . ', "avatar_file" VARCHAR(100)'
                . ', "forum_sync" TEXT';
            $tail = '';
        } else {
            $columns = '`uid` INT UNSIGNED NOT NULL PRIMARY KEY'
                . ', `bio` VARCHAR(500) DEFAULT NULL'
                . ', ' . implode(', ', array_map(static fn ($key): string => '`' . $key . '` VARCHAR(200) DEFAULT NULL', array_keys(self::SOCIALS)))
                . ', `avatar_file` VARCHAR(100) DEFAULT NULL'
                . ', `forum_sync` TEXT DEFAULT NULL';
            $tail = ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4';
        }

        $db->query("CREATE TABLE IF NOT EXISTS `{$table}` ({$columns}){$tail}");

        self::ensureExtraColumns($db, $table);
    }

    /**
     * افزودن ستون‌های مدیریتی به نصب‌های موجود (مهاجرت افزایشی)
     */
    private static function ensureExtraColumns(Db $db, string $table): void
    {
        $existing = self::tableColumns($db, $table);

        $wanted = self::isSqlite($db)
            ? ['avatar_file' => 'VARCHAR(100)', 'forum_sync' => 'TEXT']
            : ['avatar_file' => 'VARCHAR(100) DEFAULT NULL', 'forum_sync' => 'TEXT DEFAULT NULL'];

        foreach ($wanted as $column => $definition) {
            if (!in_array(strtolower($column), $existing, true)) {
                $quote = self::isSqlite($db) ? '"' : '`';
                try {
                    $db->query(
                        sprintf('ALTER TABLE %s ADD COLUMN %s%s%s %s', $table, $quote, $column, $quote, $definition)
                    );
                } catch (\Throwable) {
                    // ستون هم‌زمان توسط فرایند دیگری ساخته شد
                }
            }
        }
    }

    /** فهرست نام ستون‌های موجود یک جدول (حروف کوچک) */
    private static function tableColumns(Db $db, string $table): array
    {
        $columns = [];

        try {
            if (self::isSqlite($db)) {
                foreach ($db->fetchAll("PRAGMA table_info('{$table}')") as $row) {
                    $columns[] = strtolower((string) ($row['name'] ?? ''));
                }
            } else {
                foreach ($db->fetchAll("SHOW COLUMNS FROM `{$table}`") as $row) {
                    $columns[] = strtolower((string) ($row['Field'] ?? ''));
                }
            }
        } catch (\Throwable) {
            // خواندن ساختار ممکن نبود — CREATE TABLE تازه کار را انجام می‌دهد
        }

        return $columns;
    }

    private static function isSqlite(Db $db): bool
    {
        return str_contains(strtolower((string) $db->getAdapterName()), 'sqlite');
    }

    /**
     * مقادیر پیش‌فرض ستون‌های متا (همهٔ کلیدها همیشه موجودند)
     */
    public static function defaults(): array
    {
        return array_merge(
            ['bio' => ''],
            array_fill_keys(array_keys(self::SOCIALS), '')
        );
    }

    /**
     * سطر متای یک کاربر (همیشه شامل همهٔ کلیدها، حتی اگر رکورد نداشته باشد)
     *
     * در صورت فعال‌بودن همگام‌سازی انجمن، پیش از خواندن، تغییرات احتمالیِ
     * اعمال‌شده از سمت انجمن (صفحهٔ ویرایش پروفایل انجمن) به جدول افزونه
     * منتقل می‌شود تا هر دو سمت همیشه یک دست داده داشته باشند.
     */
    public static function getRow(int $uid): array
    {
        ForumSync::pullIfNeeded($uid);

        $db = Db::get();

        // نکته: select() بدون آرگومان = همهٔ ستون‌ها؛ فرستادن آرایهٔ نام ستون‌ها
        // به select به‌عنوان جفت‌های «فیلد => نام مستعار» تفسیر می‌شود.
        $row = $db->fetchRow(
            $db->select()->from('table.siteprofile')->where('uid = ?', $uid)->limit(1)
        );

        if (!$row) {
            return self::defaults();
        }

        // ستون‌های مدیریتی جزو داده‌های متای عمومی نیستند
        foreach (self::EXTRA_COLUMNS as $column) {
            unset($row[$column]);
        }

        return array_merge(self::defaults(), $row);
    }

    /**
     * ذخیرهٔ ستون‌های متا برای یک کاربر (به‌روزرسانی یا درج)
     *
     * @param array $rows فقط کلیدهای معتبر ذخیره می‌شوند (bio + شبکه‌ها + ستون‌های مدیریتی)
     */
    public static function save(int $uid, array $rows): void
    {
        $db = Db::get();
        $rows = array_intersect_key($rows, array_merge(self::defaults(), array_fill_keys(self::EXTRA_COLUMNS, null)));

        if (empty($rows)) {
            return;
        }

        $updated = $db->query(
            $db->update('table.siteprofile')->rows($rows)->where('uid = ?', $uid)
        );

        if (!$updated) {
            $db->query(
                $db->insert('table.siteprofile')->rows(array_merge($rows, ['uid' => $uid]))
            );
        }
    }

    /**
     * نرمال‌سازی ورودی شبکهٔ اجتماعی:
     *
     * - اگر نشانی کامل http(s) باشد، دست‌نخورده می‌ماند؛
     * - در غیر این صورت نام کاربری در نظر گرفته شده و «@» ابتدایی حذف می‌شود.
     */
    public static function normalizeHandle(string $value): string
    {
        $value = trim($value);

        if ($value === '' || preg_match('#^https?://#i', $value)) {
            return $value;
        }

        return ltrim($value, '@');
    }

    /**
     * نشانی نهایی شبکهٔ اجتماعی برای نمایش (از نام کاربری یا نشانی ذخیره‌شده)
     */
    public static function socialUrl(string $key, string $value): string
    {
        $value = trim($value);

        if ($value === '') {
            return '';
        }

        if (preg_match('#^https?://#i', $value)) {
            return $value;
        }

        $pattern = self::SOCIALS[$key]['url'] ?? '%s';

        return sprintf($pattern, ltrim($value, '@'));
    }

    /**
     * بستهٔ کامل داده‌های عمومی یک کاربر
     *
     * داده‌های این متد برای باکس نویسنده (Box) و صفحهٔ عمومی کاربر
     * (/profile/{uid}) استفاده می‌شود و برای استفادهٔ مستقیم قالب‌ها
     * نیز عمومی است.
     *
     * @return array|null در نبود کاربر null برمی‌گردد
     */
    public static function authorData(int $uid): ?array
    {
        $db = Db::get();

        $user = $db->fetchRow(
            $db->select()->from('table.users')->where('uid = ?', $uid)->limit(1)
        );

        if (!$user) {
            return null;
        }

        $meta = self::getRow($uid);
        $prefix = $db->getPrefix();

        $avatar = Avatar::resolve($uid, (string) $user['mail'], 96);

        $postsNum = (int) $db->fetchObject(
            $db->select(['COUNT(cid)' => 'num'])->from('table.contents')
                ->where('authorId = ?', $uid)
                ->where('type = ?', 'post')
                ->where('status = ?', 'publish')
        )->num;

        // نظرات تأییدشدهٔ کاربر روی مطالب منتشرشده (همان تعریف صفحهٔ عمومی)
        $commentsNum = (int) $db->fetchObject(sprintf(
            'SELECT COUNT(*) AS num FROM %scomments AS c '
            . 'INNER JOIN %scontents AS ct ON ct.cid = c.cid '
            . "WHERE c.authorId = %d AND c.status = 'approved' AND c.type = 'comment' "
            . "AND ct.status = 'publish' AND ct.type IN ('post', 'page')",
            $prefix,
            $prefix,
            $uid
        ))->num;

        return [
            'uid'          => (int) $user['uid'],
            'name'         => (string) $user['name'],
            'screenName'   => (string) ($user['screenName'] !== '' && $user['screenName'] !== null ? $user['screenName'] : $user['name']),
            'mail'         => (string) $user['mail'],
            'url'          => (string) $user['url'],
            'group'        => (string) $user['group'],
            'created'      => (int) $user['created'],
            'logged'       => (int) $user['logged'],
            'bio'          => (string) $meta['bio'],
            'socials'      => $meta,
            'avatarUrl'    => $avatar['url'],
            'avatarLocal'  => $avatar['local'],
            'postsNum'     => $postsNum,
            'commentsNum'  => $commentsNum,
        ];
    }

    /**
     * برچسب فارسی گروه کاربری
     */
    public static function groupLabel(string $group): string
    {
        return match ($group) {
            'administrator' => 'مدیر کل',
            'editor' => 'ویراستار',
            'contributor' => 'نویسنده همکار',
            'subscriber' => 'کاربر',
            default => 'کاربر',
        };
    }
}
