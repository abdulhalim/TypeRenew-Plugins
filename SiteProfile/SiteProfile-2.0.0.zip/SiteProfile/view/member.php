<?php
/**
 * صفحهٔ عمومی کاربر (/profile/{uid})
 *
 * این نما هم در قالب پوستهٔ سایت (میان header.php و footer.php) و هم در
 * پوستهٔ مستقل افزونه (standalone.php) رندر می‌شود.
 *
 * محتوا در سه تب نمایش داده می‌شود: نوشته‌ها، نظرات و (در صورت فعال‌بودن
 * افزونهٔ انجمن) پرسش و پاسخ انجمن. هر تب صفحه‌بندی مستقل دارد و تعداد
 * آیتم هر صفحه از تنظیمات افزونه خوانده می‌شود.
 *
 * متغیرهای در دسترس (از TypechoPlugin\SiteProfile\Action::member):
 *
 * @var bool   $embedTheme    آیا صفحه در قالب پوسته سایت رندر می‌شود؟
 * @var string $siteTitle     عنوان سایت
 * @var string $siteUrl       آدرس سایت
 * @var string $logoutUrl     نشانی خروج (همراه توکن امنیتی)
 * @var array  $author        بستهٔ داده‌های کاربر (Meta::authorData)
 * @var string $tab           تب فعال (posts|comments|forum)
 * @var int    $page          شمارهٔ صفحهٔ جاری
 * @var int    $perPage       تعداد آیتم در هر صفحه
 * @var array  $posts         نوشته‌های صفحهٔ جاری
 * @var int    $postsTotal    شمار کل نوشته‌ها
 * @var int    $postsPages    شمار صفحه‌های نوشته‌ها
 * @var array  $comments      نظرات صفحهٔ جاری
 * @var int    $commentsTotal شمار کل نظرات
 * @var int    $commentsPages شمار صفحه‌های نظرات
 * @var bool   $forumActive   آیا تب انجمن فعال است؟
 * @var array|null $forum     داده‌های تب انجمن (در نبود انجمن null)
 * @var string $forumSub      زیرتب فعال انجمن (questions|answers)
 * @var bool   $showLastLogin آیا تاریخ آخرین ورود نمایش داده شود؟
 * @var bool   $isOwner       آیا بازدیدکننده، خودِ صاحب صفحه است؟
 * @var array  $menuItems     گزینه‌های منوی «دسترسی سریع» (برای کاربر واردشده)
 */

use TypechoPlugin\SiteProfile\Box;
use TypechoPlugin\SiteProfile\Jalali;
use TypechoPlugin\SiteProfile\Meta;
use TypechoPlugin\SiteProfile\Plugin;

$e = static function ($value): string {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
};

$standalone = !($embedTheme ?? false);
$author = $author ?? [];
$posts = $posts ?? [];
$comments = $comments ?? [];
$tab = (string) ($tab ?? 'posts');
$page = (int) ($page ?? 1);
$perPage = (int) ($perPage ?? 10);
$postsTotal = (int) ($postsTotal ?? 0);
$postsPages = (int) ($postsPages ?? 1);
$commentsTotal = (int) ($commentsTotal ?? 0);
$commentsPages = (int) ($commentsPages ?? 1);
$forumActive = (bool) ($forumActive ?? false);
$forum = is_array($forum ?? null) ? $forum : null;
$forumSub = (string) ($forumSub ?? 'questions');
$showLastLogin = (bool) ($showLastLogin ?? true);
$isOwner = (bool) ($isOwner ?? false);
$menuItems = $menuItems ?? [];

$displayName = (string) ($author['screenName'] ?? '');
$memberBase = Plugin::memberUrl((int) ($author['uid'] ?? 0));

/** نشانی یک صفحه از یک تب مشخص */
$tabUrl = static function (string $forTab, int $n, string $ftab = '') use ($memberBase): string {
    $params = [];

    if ($forTab !== 'posts') {
        $params['tab'] = $forTab;
    }

    if ($ftab !== '' && $ftab !== 'questions') {
        $params['ftab'] = $ftab;
    }

    if ($n > 1) {
        $params['page'] = $n;
    }

    return $params === [] ? $memberBase : $memberBase . '?' . http_build_query($params);
};

/** خلاصهٔ متن نظر */
$excerpt = static function (string $text): string {
    $text = trim(strip_tags($text));
    $text = preg_replace('/\s+/u', ' ', $text) ?? '';
    return mb_strlen($text, 'UTF-8') > 140 ? mb_substr($text, 0, 140, 'UTF-8') . '…' : $text;
};

/** رندر صفحه‌بندی یک تب
 *
 * چیدمان راست‌چین بر محور زمان است: گذشته (قدیمی‌تر) در راست و
 * حال (جدیدتر) در چپ؛ پس «قدیمی‌تر» نخست و «جدیدتر» پس از شمارهٔ
 * صفحه می‌نشیند. جهتِ ناموجود به‌جای جعبهٔ خالی، دکمهٔ غیرفعالِ
 * بامتن (خط‌چین و کم‌‌رنگ) می‌گیرد تا جای دکمه‌ها همیشه معلوم باشد.
 */
$pagination = static function (int $current, int $pages, string $forTab, string $ftab = '') use ($e, $tabUrl): string {
    if ($pages <= 1) {
        return '';
    }

    // برچسب جهت‌ها متناسب با محتوای تب
    if ($forTab === 'comments') {
        [$olderLabel, $newerLabel] = ['نظرات قدیمی‌تر', 'نظرات جدیدتر'];
    } elseif ($forTab === 'forum') {
        $noun = $ftab === 'answers' ? 'پاسخ‌های' : 'پرسش‌های';
        [$olderLabel, $newerLabel] = [$noun . ' قدیمی‌تر', $noun . ' جدیدتر'];
    } else {
        [$olderLabel, $newerLabel] = ['مطالب قدیمی‌تر', 'مطالب جدیدتر'];
    }

    // فلش‌های جهت‌دار (قدیمی‌تر به سمت راست، جدیدتر به سمت چپ)
    $chevOlder = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor"'
        . ' stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
        . '<polyline points="9 18 15 12 9 6"></polyline></svg>';
    $chevNewer = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor"'
        . ' stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
        . '<polyline points="15 18 9 12 15 6"></polyline></svg>';

    $html = '<nav class="sp-pagination" aria-label="صفحه‌بندی">';

    // راست: مطالب قدیمی‌تر (جهتِ پیش‌روی به سمت گذشته)
    if ($current < $pages) {
        $html .= '<a class="sp-page-btn" href="' . $e($tabUrl($forTab, $current + 1, $ftab)) . '">'
            . $chevOlder . '<span>' . $olderLabel . '</span></a>';
    } else {
        $html .= '<span class="sp-page-btn is-disabled" aria-hidden="true">'
            . $chevOlder . '<span>' . $olderLabel . '</span></span>';
    }

    $html .= '<span class="sp-pagenum">صفحهٔ ' . $e(Jalali::digits((string) $current))
        . ' از ' . $e(Jalali::digits((string) $pages)) . '</span>';

    // چپ: مطالب جدیدتر (بازگشت به سمت اکنون)
    if ($current > 1) {
        $html .= '<a class="sp-page-btn" href="' . $e($tabUrl($forTab, $current - 1, $ftab)) . '">'
            . '<span>' . $newerLabel . '</span>' . $chevNewer . '</a>';
    } else {
        $html .= '<span class="sp-page-btn is-disabled" aria-hidden="true">'
            . '<span>' . $newerLabel . '</span>' . $chevNewer . '</span>';
    }

    return $html . '</nav>';
};
?>
<div class="sp-scope sp-member<?php echo $standalone ? ' sp-standalone' : ''; ?>">
<style>
    /* توکن‌های رنگی — همان زنجیرهٔ ارث‌بری از پوسته + فالبک افزونه */
    .sp-scope.sp-member {
        direction: rtl;
        text-align: right;

        --sp-card: var(--surface, var(--bg-primary, #ffffff));
        --sp-field: var(--surface-soft, var(--bg-secondary, #fbfcfe));
        --sp-ink: var(--ink, var(--text-primary, #1f2937));
        --sp-ink-soft: var(--ink-soft, var(--text-secondary, #4b5563));
        --sp-ink-mute: var(--ink-mute, var(--text-tertiary, #6b7280));
        --sp-line: var(--line, var(--border-color, #e5e7eb));
        --sp-line-strong: var(--line-strong, var(--border-hover, #d1d5db));
        --sp-accent: var(--primary, var(--accent-color, #2563eb));
        --sp-btn-bg: var(--primary, var(--accent-color, #2563eb));
        --sp-btn-bg-hover: var(--primary-strong, var(--accent-hover, #1d4ed8));
        --sp-btn-ink: var(--primary-contrast, #ffffff);
        --sp-accent-soft: var(--primary-soft, rgba(37, 99, 235, 0.08));
        --sp-ring: var(--primary-glow, var(--focus-ring, rgba(37, 99, 235, 0.16)));
        --sp-radius: var(--radius-lg, 14px);
        --sp-radius-sm: var(--radius-md, 10px);
        --sp-shadow: var(--shadow-md, 0 14px 34px -16px rgba(15, 23, 42, 0.18));
        --sp-err: #dc2626;
        --sp-err-bg: rgba(220, 38, 38, 0.08);

        color: var(--sp-ink);
        line-height: 1.9;
    }

    html[data-theme='dark'] .sp-scope.sp-member,
    html.dark .sp-scope.sp-member,
    body.dark .sp-scope.sp-member {
        --sp-card: var(--surface, var(--bg-primary, #131a23));
        --sp-field: var(--surface-soft, var(--bg-secondary, #0e141c));
        --sp-ink: var(--ink, var(--text-primary, #e6edf3));
        --sp-ink-soft: var(--ink-soft, var(--text-secondary, #b6c2cf));
        --sp-ink-mute: var(--ink-mute, var(--text-tertiary, #8b98a5));
        --sp-line: var(--line, var(--border-color, #243040));
        --sp-line-strong: var(--line-strong, var(--border-hover, #33414f));
        --sp-accent: var(--primary, var(--accent-color, #6ea8fe));
        --sp-btn-bg: var(--primary, #3b82f6);
        --sp-btn-bg-hover: var(--primary-strong, #2563eb);
        --sp-btn-ink: var(--primary-contrast, #ffffff);
        --sp-accent-soft: var(--primary-soft, rgba(59, 130, 246, 0.14));
        --sp-ring: var(--primary-glow, var(--focus-ring, rgba(59, 130, 246, 0.25)));
        --sp-shadow: var(--shadow-md, 0 14px 34px -16px rgba(0, 0, 0, 0.55));
        --sp-err: #f87171;
        --sp-err-bg: rgba(248, 113, 113, 0.10);
    }

    @media (prefers-color-scheme: dark) {
        html:not([data-theme]):not(.dark) .sp-scope.sp-member.sp-standalone {
            --sp-card: #131a23;
            --sp-field: #0e141c;
            --sp-ink: #e6edf3;
            --sp-ink-soft: #b6c2cf;
            --sp-ink-mute: #8b98a5;
            --sp-line: #243040;
            --sp-line-strong: #33414f;
            --sp-accent: #6ea8fe;
            --sp-btn-bg: #3b82f6;
            --sp-btn-bg-hover: #2563eb;
            --sp-btn-ink: #ffffff;
            --sp-accent-soft: rgba(59, 130, 246, 0.14);
            --sp-ring: rgba(59, 130, 246, 0.25);
            --sp-shadow: 0 14px 34px -16px rgba(0, 0, 0, 0.55);
            --sp-err: #f87171;
            --sp-err-bg: rgba(248, 113, 113, 0.10);
        }
    }

    .sp-scope.sp-member .sp-page {
        max-width: 760px;
        margin-inline: auto;
        padding-block: 14px 44px;
    }

    .sp-scope.sp-member.sp-standalone .sp-page {
        padding-inline: 16px;
        padding-top: 26px;
    }

    /* بنر صاحب صفحه */
    .sp-scope.sp-member .sp-ownerbar {
        display: flex;
        align-items: center;
        gap: 10px;
        justify-content: space-between;
        flex-wrap: wrap;
        margin-bottom: 14px;
        padding: 12px 16px;
        background: var(--sp-accent-soft);
        border: 1px solid var(--sp-line);
        border-radius: var(--sp-radius-sm);
        font-size: 13.5px;
        color: var(--sp-ink-soft);
    }

    .sp-scope.sp-member .sp-ownerbar a {
        font-weight: 700;
        color: var(--sp-accent);
        text-decoration: none;
    }

    .sp-scope.sp-member .sp-ownerbar a:hover { text-decoration: underline; }

    /* کارت سربرگ کاربر */
    .sp-scope.sp-member .sp-card {
        background: var(--sp-card);
        border: 1px solid var(--sp-line);
        border-radius: var(--sp-radius);
        box-shadow: var(--sp-shadow);
        overflow: hidden;
    }

    /* هیرو: آواتار در آغاز (راست)، متن در میانه و دکمهٔ «دسترسی سریع»
       در انتهای سطر (چپ) — همان چیدمان هیروی کارت ویرایش */
    .sp-scope.sp-member .sp-hero {
        display: flex;
        align-items: center;
        gap: 18px;
        padding: 26px 28px 22px;
        background:
            linear-gradient(215deg, var(--sp-accent-soft), transparent 68%),
            var(--sp-card);
        border-bottom: 1px solid var(--sp-line);
    }

    .sp-scope.sp-member .sp-hero-text { min-width: 0; flex: 1 1 auto; }

    .sp-scope.sp-member .sp-hero-text h1 {
        margin: 0;
        font-size: 19px;
        font-weight: 800;
        color: var(--sp-ink);
    }

    .sp-scope.sp-member .sp-badge {
        display: inline-block;
        margin-inline-start: 8px;
        padding: 1px 10px;
        font-size: 11.5px;
        font-weight: 600;
        border-radius: 999px;
        background: var(--sp-accent-soft);
        color: var(--sp-accent);
        vertical-align: 1.5px;
    }

    .sp-scope.sp-member .sp-hero-text .sp-bio {
        margin: 8px 0 0;
        font-size: 14px;
        color: var(--sp-ink-soft);
        max-width: 560px;
    }

    /* آواتار مربعی با انحنای کم + افکت پرتوی چرخان دور حاشیه */
    .sp-scope.sp-member .sp-avatar-beam {
        position: relative;
        flex: none;
        width: 92px;
        height: 92px;
        padding: 4px;
        border-radius: 20px;
        overflow: hidden;
        background: var(--sp-card);
        box-shadow: inset 0 0 0 1px var(--sp-line), var(--sp-shadow);
    }

    .sp-scope.sp-member .sp-avatar-beam::before {
        content: '';
        position: absolute;
        inset: -120%;
        background: conic-gradient(
            from 0deg,
            transparent 0deg 300deg,
            var(--sp-accent) 345deg,
            transparent 360deg
        );
        animation: sp-beam-spin 9s linear infinite;
    }

    @supports (background: color-mix(in srgb, red 50%, blue)) {
        .sp-scope.sp-member .sp-avatar-beam::before {
            background: conic-gradient(
                from 0deg,
                transparent 0deg 265deg,
                color-mix(in srgb, var(--sp-accent) 30%, transparent) 305deg,
                color-mix(in srgb, var(--sp-accent) 65%, transparent) 330deg,
                var(--sp-accent) 347deg,
                transparent 360deg
            );
        }
    }

    @keyframes sp-beam-spin {
        to { transform: rotate(1turn); }
    }

    @media (prefers-reduced-motion: reduce) {
        .sp-scope.sp-member .sp-avatar-beam::before { animation: none; }
    }

    .sp-scope.sp-member .sp-avatar {
        position: relative;
        z-index: 1;
        display: block;
        width: 100%;
        height: 100%;
        border: none;
        border-radius: 16px;
        background: var(--sp-field);
        object-fit: cover;
    }

    /* ===== منوی «دسترسی سریع» (انتهای هیرو — سمت چپ) ===== */

    .sp-scope.sp-member .sp-menu {
        position: relative;
        display: inline-block;
        flex: none;
    }

    .sp-scope.sp-member .sp-hero-menu { align-self: center; }

    .sp-scope.sp-member .sp-menu-btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 7px 15px;
        border: 1px solid var(--sp-line);
        border-radius: var(--sp-radius-sm);
        background: var(--sp-card);
        color: var(--sp-ink-soft);
        font: inherit;
        font-size: 13px;
        font-weight: 700;
        cursor: pointer;
        transition: color .15s, border-color .15s, background .15s;
    }

    .sp-scope.sp-member .sp-menu-btn:hover,
    .sp-scope.sp-member .sp-menu-btn[aria-expanded='true'] {
        color: var(--sp-accent);
        border-color: var(--sp-accent);
        background: var(--sp-accent-soft);
    }

    .sp-scope.sp-member .sp-menu-btn svg { flex: none; }

    .sp-scope.sp-member .sp-menu-btn .sp-chevron {
        transition: transform .15s;
    }

    .sp-scope.sp-member .sp-menu-btn[aria-expanded='true'] .sp-chevron {
        transform: rotate(180deg);
    }

    .sp-scope.sp-member .sp-menu-panel {
        position: absolute;
        top: calc(100% + 7px);
        inset-inline-end: 0;
        z-index: 40;
        min-width: 225px;
        padding: 6px;
        background: var(--sp-card);
        border: 1px solid var(--sp-line);
        border-radius: var(--sp-radius-sm);
        box-shadow: var(--sp-shadow);
    }

    .sp-scope.sp-member .sp-menu-panel[hidden] { display: none; }

    .sp-scope.sp-member .sp-menu-item {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 8px 12px;
        border-radius: 8px;
        color: var(--sp-ink-soft);
        font-size: 13.5px;
        font-weight: 600;
        text-decoration: none;
        white-space: nowrap;
        transition: color .12s, background .12s;
    }

    .sp-scope.sp-member .sp-menu-item:hover {
        color: var(--sp-accent);
        background: var(--sp-accent-soft);
    }

    .sp-scope.sp-member .sp-menu-item svg { color: var(--sp-ink-mute); flex: none; }
    .sp-scope.sp-member .sp-menu-item:hover svg { color: var(--sp-accent); }

    .sp-scope.sp-member .sp-menu-sep {
        height: 1px;
        margin: 5px 8px;
        background: var(--sp-line);
    }

    .sp-scope.sp-member .sp-menu-item.sp-menu-danger { color: var(--sp-err); }

    .sp-scope.sp-member .sp-menu-item.sp-menu-danger svg { color: var(--sp-err); }

    .sp-scope.sp-member .sp-menu-item.sp-menu-danger:hover {
        color: var(--sp-err);
        background: var(--sp-err-bg);
    }

    .sp-scope.sp-member .sp-menu-item.sp-menu-danger:hover svg { color: var(--sp-err); }

    /* آمار */
    .sp-scope.sp-member .sp-stats {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        border-bottom: 1px solid var(--sp-line);
    }

    .sp-scope.sp-member .sp-stat {
        padding: 14px 10px;
        text-align: center;
        border-inline-start: 1px solid var(--sp-line);
    }

    .sp-scope.sp-member .sp-stat:first-child { border-inline-start: none; }

    .sp-scope.sp-member .sp-stat b {
        display: block;
        font-size: 17px;
        font-weight: 800;
        color: var(--sp-ink);
    }

    .sp-scope.sp-member .sp-stat span {
        font-size: 12px;
        color: var(--sp-ink-mute);
    }

    /* شبکه‌های اجتماعی */
    .sp-scope.sp-member .sp-socials {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        align-items: center;
        padding: 18px 28px;
        border-bottom: 1px solid var(--sp-line);
    }

    .sp-scope.sp-member .sp-socials-title {
        font-size: 12.5px;
        font-weight: 700;
        color: var(--sp-ink-mute);
        margin-inline-end: 4px;
    }

 

    .sp-scope.sp-member .sp-social {
    width: 42px;
    height: 42px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    border: 1px solid var(--sp-line);
    border-radius: 12px;
    color: var(--sp-ink-soft);
    text-decoration: none;
    transition: color .15s, border-color .15s, background .15s, transform .15s;
    }

    .sp-scope.sp-member .sp-social:hover {
        color: var(--sp-accent);
        border-color: var(--sp-accent);
        background: var(--sp-accent-soft);
        transform: translateY(-2px);
    }

    /* نوار تب‌ها — نوار اسکرول مخفی (رفع آرتیفکت اسکرول‌بار هنگام هاور) */
    .sp-scope.sp-member .sp-tabs {
        display: flex;
        gap: 2px;
        padding: 0 14px;
        border-bottom: 1px solid var(--sp-line);
        background: var(--sp-field);
        overflow-x: auto;
        overscroll-behavior-x: contain;
        scrollbar-width: none;
        -ms-overflow-style: none;
    }

    .sp-scope.sp-member .sp-tabs::-webkit-scrollbar { display: none; width: 0; height: 0; }

    .sp-scope.sp-member .sp-tab {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        padding: 12px 18px;
        margin-bottom: -1px;
        border: none;
        border-bottom: 2.5px solid transparent;
        background: transparent;
        color: var(--sp-ink-mute);
        font: inherit;
        font-size: 14px;
        font-weight: 700;
        cursor: pointer;
        white-space: nowrap;
        text-decoration: none;
        transition: color .15s, border-color .15s, background .15s;
    }

    .sp-scope.sp-member .sp-tab svg { flex: none; }
    .sp-scope.sp-member .sp-tab:hover { color: var(--sp-ink); }

    .sp-scope.sp-member .sp-tab.is-active {
        color: var(--sp-accent);
        border-bottom-color: var(--sp-accent);
        background: var(--sp-card);
        border-start-start-radius: 8px;
        border-start-end-radius: 8px;
    }

    .sp-scope.sp-member .sp-tab .sp-count {
        padding: 0 8px;
        font-size: 11px;
        font-weight: 700;
        border-radius: 999px;
        background: var(--sp-accent-soft);
        color: var(--sp-accent);
    }

    /* زیرتب‌های انجمن (پرسش‌ها/پاسخ‌ها) */
    .sp-scope.sp-member .sp-subtabs {
        display: flex;
        gap: 8px;
        margin-bottom: 14px;
    }

    .sp-scope.sp-member .sp-subtab {
        padding: 6px 16px;
        border: 1px solid var(--sp-line);
        border-radius: 999px;
        background: var(--sp-field);
        color: var(--sp-ink-soft);
        font-size: 13px;
        font-weight: 700;
        text-decoration: none;
        transition: color .15s, border-color .15s, background .15s;
    }

    .sp-scope.sp-member .sp-subtab:hover {
        color: var(--sp-accent);
        border-color: var(--sp-accent);
    }

    .sp-scope.sp-member .sp-subtab.is-active {
        color: var(--sp-accent);
        border-color: var(--sp-accent);
        background: var(--sp-accent-soft);
    }

    /* آمار انجمن */
    .sp-scope.sp-member .sp-forum-stats {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 8px;
        margin-bottom: 18px;
    }

    .sp-scope.sp-member .sp-forum-stat {
        padding: 10px 8px;
        border: 1px solid var(--sp-line);
        border-radius: var(--sp-radius-sm);
        background: var(--sp-field);
        text-align: center;
    }

    .sp-scope.sp-member .sp-forum-stat b {
        display: block;
        font-size: 16px;
        font-weight: 800;
        color: var(--sp-ink);
    }

    .sp-scope.sp-member .sp-forum-stat span {
        font-size: 11.5px;
        color: var(--sp-ink-mute);
    }

    .sp-scope.sp-member .sp-forum-more {
        margin-top: 16px;
        text-align: center;
    }

    .sp-scope.sp-member .sp-forum-more a {
        display: inline-block;
        padding: 9px 22px;
        border: 1px solid var(--sp-line-strong);
        border-radius: var(--sp-radius-sm);
        color: var(--sp-accent);
        font-size: 13.5px;
        font-weight: 700;
        text-decoration: none;
        transition: border-color .15s, background .15s;
    }

    .sp-scope.sp-member .sp-forum-more a:hover {
        border-color: var(--sp-accent);
        background: var(--sp-accent-soft);
    }

    /* بخش‌ها */
    .sp-scope.sp-member .sp-section {
        padding: 22px 28px 26px;
    }

    .sp-scope.sp-member .sp-section > h2 {
        display: flex;
        align-items: center;
        gap: 8px;
        margin: 0 0 14px;
        font-size: 15.5px;
        font-weight: 700;
        color: var(--sp-ink);
    }

    .sp-scope.sp-member .sp-section > h2 svg { color: var(--sp-accent); }

    .sp-scope.sp-member .sp-list {
        list-style: none;
        margin: 0;
        padding: 0;
    }

    .sp-scope.sp-member .sp-list > li {
        padding: 11px 0;
        border-bottom: 1px dashed var(--sp-line);
    }

    .sp-scope.sp-member .sp-list > li:last-child { border-bottom: none; }

    .sp-scope.sp-member .sp-list a {
        color: var(--sp-ink);
        font-weight: 600;
        text-decoration: none;
    }

    .sp-scope.sp-member .sp-list a:hover { color: var(--sp-accent); }

    .sp-scope.sp-member .sp-list time {
        display: block;
        font-size: 12px;
        color: var(--sp-ink-mute);
        margin-top: 1px;
    }

    .sp-scope.sp-member .sp-comment-text,
    .sp-scope.sp-member .sp-forum-excerpt {
        margin: 2px 0 0;
        font-size: 13.5px;
        color: var(--sp-ink-soft);
    }

    .sp-scope.sp-member .sp-list-meta {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-top: 2px;
        font-size: 12px;
        color: var(--sp-ink-mute);
    }

    .sp-scope.sp-member .sp-list-meta .sp-pill {
        padding: 0 9px;
        border-radius: 999px;
        background: var(--sp-accent-soft);
        color: var(--sp-accent);
        font-size: 11px;
        font-weight: 700;
    }

    .sp-scope.sp-member .sp-empty {
        margin: 0;
        padding: 10px 14px;
        border: 1px dashed var(--sp-line-strong);
        border-radius: var(--sp-radius-sm);
        color: var(--sp-ink-mute);
        font-size: 13px;
        text-align: center;
    }

    /* صفحه‌بندی — «قدیمی‌تر» در راست (محور زمانی راست‌چین) و «جدیدتر» در چپ؛
       جهت ناموجود دکمهٔ غیرفعالِ بامتن می‌گیرد (خط‌چین و کم‌رنگ) */
    .sp-scope.sp-member .sp-pagination {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        margin-top: 16px;
    }

    .sp-scope.sp-member .sp-page-btn {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 7px 16px;
        border: 1px solid var(--sp-line);
        border-radius: var(--sp-radius-sm);
        font-size: 13px;
        color: var(--sp-ink-soft);
        text-decoration: none;
        white-space: nowrap;
        transition: color .15s, border-color .15s, background .15s;
    }

    .sp-scope.sp-member .sp-pagination a.sp-page-btn:hover {
        color: var(--sp-accent);
        border-color: var(--sp-accent);
        background: var(--sp-accent-soft);
    }

    .sp-scope.sp-member .sp-page-btn svg { flex: none; }

    .sp-scope.sp-member .sp-pagination span.sp-page-btn {
        border-style: dashed;
        color: var(--sp-ink-mute);
        opacity: .55;
        cursor: default;
        pointer-events: none;
    }

    .sp-scope.sp-member .sp-pagination .sp-pagenum {
        padding: 0;
        border: none;
        color: var(--sp-ink-mute);
        font-size: 12.5px;
        text-align: center;
    }

    .sp-scope.sp-member .sp-foot {
        padding: 16px 28px 22px;
        border-top: 1px solid var(--sp-line);
        background: var(--sp-field);
        color: var(--sp-ink-mute);
        font-size: 12.5px;
        text-align: center;
    }

    .sp-scope.sp-member .sp-foot a {
        color: var(--sp-accent);
        text-decoration: none;
    }

    .sp-scope.sp-member .sp-foot a:hover { text-decoration: underline; }

    @media (max-width: 560px) {
        .sp-scope.sp-member .sp-stats,
        .sp-scope.sp-member .sp-forum-stats { grid-template-columns: repeat(2, 1fr); }
        .sp-scope.sp-member .sp-stat:nth-child(3) { border-inline-start: none; }
        .sp-scope.sp-member .sp-stat:nth-child(n + 3) { border-top: 1px solid var(--sp-line); }
        .sp-scope.sp-member .sp-hero { padding: 20px; gap: 14px; }
        .sp-scope.sp-member .sp-avatar-beam { width: 72px; height: 72px; border-radius: 16px; }
        .sp-scope.sp-member .sp-avatar { border-radius: 12px; }
        .sp-scope.sp-member .sp-hero-text h1 { font-size: 17px; }
        .sp-scope.sp-member .sp-section { padding: 20px; }
        .sp-scope.sp-member .sp-socials { padding: 16px 20px; }
        .sp-scope.sp-member .sp-tabs { padding: 0 6px; }
        .sp-scope.sp-member .sp-tab { padding: 11px 13px; font-size: 13px; }
        .sp-scope.sp-member .sp-menu-panel { max-width: calc(100vw - 40px); }
    }

    @media (max-width: 480px) {
        .sp-scope.sp-member .sp-hero { flex-wrap: wrap; }
        .sp-scope.sp-member .sp-hero-menu {
            flex: 1 1 100%;
        }
        .sp-scope.sp-member .sp-hero-menu .sp-menu-btn {
            width: 100%;
            justify-content: center;
        }
        .sp-scope.sp-member .sp-menu-panel { inset-inline: 0; }
        .sp-scope.sp-member .sp-pagination { flex-wrap: wrap; justify-content: center; }
        .sp-scope.sp-member .sp-pagenum { flex: 1 1 100%; order: 3; }
    }
</style>

<div class="sp-page">

    <?php if ($isOwner): ?>
        <div class="sp-ownerbar">
            <span>این صفحهٔ عمومی شماست؛ هر کسی می‌تواند آن را ببیند.</span>
            <a href="<?php echo $e(Plugin::profileUrl()); ?>">ویرایش پروفایل ←</a>
        </div>
    <?php endif; ?>

    <main class="sp-card">

        <div class="sp-hero">
            <div class="sp-avatar-beam">
                <img class="sp-avatar" src="<?php echo $e((string) ($author['avatarUrl'] ?? '')); ?>"
                     alt="<?php echo $e($displayName); ?>" width="84" height="84">
            </div>
            <div class="sp-hero-text">
                <h1><?php echo $e($displayName); ?>
                    <span class="sp-badge"><?php echo $e(Meta::groupLabel((string) ($author['group'] ?? ''))); ?></span>
                </h1>
                <?php if (($author['bio'] ?? '') !== ''): ?>
                    <p class="sp-bio"><?php echo $e($author['bio']); ?></p>
                <?php endif; ?>
            </div>
            <?php if ($menuItems !== []): ?>
                <div class="sp-menu sp-hero-menu" id="sp-quick-menu">
                    <button type="button" class="sp-menu-btn" id="sp-menu-btn"
                            aria-haspopup="menu" aria-expanded="false" aria-controls="sp-menu-panel">
                        <?php echo Box::icon('dashboard'); ?>
                        دسترسی سریع
                        <svg class="sp-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"></polyline></svg>
                    </button>
                    <div class="sp-menu-panel" id="sp-menu-panel" role="menu" aria-labelledby="sp-menu-btn" hidden>
                        <?php foreach ($menuItems as $item): ?>
                            <?php if (!empty($item['divider'])): ?>
                                <div class="sp-menu-sep" role="separator"></div>
                            <?php endif; ?>
                            <a class="sp-menu-item<?php echo $item['icon'] === 'logout' ? ' sp-menu-danger' : ''; ?>"
                               role="menuitem" href="<?php echo $e($item['url']); ?>">
                                <?php echo Box::icon((string) $item['icon']); ?>
                                <?php echo $e($item['label']); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <div class="sp-stats">
            <div class="sp-stat">
                <b><?php echo $e(Jalali::digits((string) ($author['postsNum'] ?? 0))); ?></b>
                <span>نوشته</span>
            </div>
            <div class="sp-stat">
                <b><?php echo $e(Jalali::digits((string) ($author['commentsNum'] ?? 0))); ?></b>
                <span>نظر</span>
            </div>
            <div class="sp-stat">
                <b><?php echo $e(Jalali::date($author['created'] ?? 0)); ?></b>
                <span>تاریخ عضویت</span>
            </div>
            <div class="sp-stat">
                <?php if ($showLastLogin): ?>
                    <b><?php echo $e(($author['logged'] ?? 0) > 0 ? Jalali::date($author['logged']) : '—'); ?></b>
                    <span>آخرین ورود</span>
                <?php else: ?>
                    <b>—</b>
                    <span>آخرین ورود</span>
                <?php endif; ?>
            </div>
        </div>

        <?php
        $socialLinks = [];
        if (($author['url'] ?? '') !== '') {
            $socialLinks[] = ['label' => 'وب‌سایت', 'url' => (string) $author['url'], 'icon' => 'website'];
        }
        foreach (Meta::SOCIALS as $key => $definition) {
            $socialUrl = Meta::socialUrl($key, (string) ($author['socials'][$key] ?? ''));
            if ($socialUrl !== '') {
                $socialLinks[] = ['label' => $definition['label'], 'url' => $socialUrl, 'icon' => $key];
            }
        }
        if ($socialLinks !== []):
            ?>
            <div class="sp-socials">
                <span class="sp-socials-title">ارتباط با من:</span>
                <?php foreach ($socialLinks as $link): ?>
                    <a class="sp-social" href="<?php echo $e($link['url']); ?>" target="_blank" rel="noopener nofollow">
                        <?php echo Box::icon($link['icon']); ?>                        
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <nav class="sp-tabs" aria-label="محتوای کاربر">
            <a class="sp-tab<?php echo $tab === 'posts' ? ' is-active' : ''; ?>"
               href="<?php echo $e($tabUrl('posts', 1)); ?>"<?php echo $tab === 'posts' ? ' aria-current="page"' : ''; ?>>
                <?php echo Box::icon('post'); ?>
                نوشته‌ها
                <span class="sp-count"><?php echo $e(Jalali::digits((string) $postsTotal)); ?></span>
            </a>
            <a class="sp-tab<?php echo $tab === 'comments' ? ' is-active' : ''; ?>"
               href="<?php echo $e($tabUrl('comments', 1)); ?>"<?php echo $tab === 'comments' ? ' aria-current="page"' : ''; ?>>
                <?php echo Box::icon('comment'); ?>
                نظرات
                <span class="sp-count"><?php echo $e(Jalali::digits((string) $commentsTotal)); ?></span>
            </a>
            <?php if ($forumActive): ?>
                <a class="sp-tab<?php echo $tab === 'forum' ? ' is-active' : ''; ?>"
                   href="<?php echo $e($tabUrl('forum', 1)); ?>"<?php echo $tab === 'forum' ? ' aria-current="page"' : ''; ?>>
                    <?php echo Box::icon('comment'); ?>
                    پرسش و پاسخ انجمن
                </a>
            <?php endif; ?>
        </nav>

        <?php if ($tab === 'posts'): ?>
            <section class="sp-section" aria-label="نوشته‌های کاربر">
                <?php if ($posts === []): ?>
                    <p class="sp-empty">این کاربر تاکنون نوشته‌ای منتشر نکرده است.</p>
                <?php else: ?>
                    <ul class="sp-list">
                        <?php foreach ($posts as $post): ?>
                            <li>
                                <a href="<?php echo $e($post['permalink']); ?>"><?php echo $e($post['title']); ?></a>
                                <time><?php echo $e(Jalali::date((int) $post['created'])); ?></time>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php echo $pagination($page, $postsPages, 'posts'); ?>
                <?php endif; ?>
            </section>
        <?php elseif ($tab === 'comments'): ?>
            <section class="sp-section" aria-label="نظرات کاربر">
                <?php if ($comments === []): ?>
                    <p class="sp-empty">هنوز نظری از این کاربر ثبت نشده است.</p>
                <?php else: ?>
                    <ul class="sp-list">
                        <?php foreach ($comments as $comment): ?>
                            <li>
                                <a href="<?php echo $e($comment['permalink']); ?>"><?php echo $e($comment['title']); ?></a>
                                <p class="sp-comment-text"><?php echo $e($excerpt((string) $comment['text'])); ?></p>
                                <time><?php echo $e(Jalali::dateTime((int) $comment['created'])); ?></time>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php echo $pagination($page, $commentsPages, 'comments'); ?>
                <?php endif; ?>
            </section>
        <?php elseif ($tab === 'forum' && $forum !== null): ?>
            <section class="sp-section" aria-label="پرسش و پاسخ انجمن">
                <div class="sp-forum-stats">
                    <div class="sp-forum-stat">
                        <b><?php echo $e(Jalali::digits((string) ($forum['stats']['questions'] ?? 0))); ?></b>
                        <span>پرسش</span>
                    </div>
                    <div class="sp-forum-stat">
                        <b><?php echo $e(Jalali::digits((string) ($forum['stats']['answers'] ?? 0))); ?></b>
                        <span>پاسخ</span>
                    </div>
                    <div class="sp-forum-stat">
                        <b><?php echo $e(Jalali::digits((string) ($forum['stats']['bestAnswers'] ?? 0))); ?></b>
                        <span>بهترین پاسخ</span>
                    </div>
                    <div class="sp-forum-stat">
                        <b><?php echo $e(Jalali::digits((string) ($forum['stats']['score'] ?? 0))); ?></b>
                        <span>امتیاز</span>
                    </div>
                </div>

                <div class="sp-subtabs">
                    <a class="sp-subtab<?php echo $forumSub === 'questions' ? ' is-active' : ''; ?>"
                       href="<?php echo $e($tabUrl('forum', 1)); ?>">پرسش‌ها</a>
                    <a class="sp-subtab<?php echo $forumSub === 'answers' ? ' is-active' : ''; ?>"
                       href="<?php echo $e($tabUrl('forum', 1, 'answers')); ?>">پاسخ‌ها</a>
                </div>

                <?php if (($forum['rows'] ?? []) === []): ?>
                    <p class="sp-empty"><?php echo $forumSub === 'answers' ? 'این کاربر تاکنون در انجمن پاسخی ننوشته است.' : 'این کاربر تاکنون در انجمن پرسشی مطرح نکرده است.'; ?></p>
                <?php else: ?>
                    <ul class="sp-list">
                        <?php foreach ($forum['rows'] as $row): ?>
                            <li>
                                <a href="<?php echo $e((string) $row['url']); ?>"><?php echo $e((string) $row['title']); ?></a>
                                <p class="sp-forum-excerpt"><?php echo $e((string) $row['excerpt']); ?></p>
                                <div class="sp-list-meta">
                                    <time><?php echo $e(Jalali::dateTime((int) $row['created'])); ?></time>
                                    <?php if ($row['replies'] !== null): ?>
                                        <span class="sp-pill"><?php echo $e(Jalali::digits((string) $row['replies'])); ?> پاسخ</span>
                                    <?php else: ?>
                                        <span class="sp-pill">پاسخ</span>
                                    <?php endif; ?>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php echo $pagination((int) $forum['page'], (int) $forum['pages'], 'forum', $forumSub === 'answers' ? 'answers' : ''); ?>
                <?php endif; ?>

                <?php if (!empty($forum['profileUrl'])): ?>
                    <div class="sp-forum-more">
                        <a href="<?php echo $e((string) $forum['profileUrl']); ?>" target="_blank" rel="noopener">مشاهدهٔ کامل پروفایل در انجمن ←</a>
                    </div>
                <?php endif; ?>
            </section>
        <?php endif; ?>

        <footer class="sp-foot">
            صفحهٔ عمومی کاربران در <a href="<?php echo $e($siteUrl); ?>"><?php echo $e($siteTitle); ?></a>
        </footer>

    </main>
</div>

<script>
    (function () {
        'use strict';

        // ===== منوی «دسترسی سریع» =====
        var menuBtn = document.getElementById('sp-menu-btn');
        var menuPanel = document.getElementById('sp-menu-panel');

        if (menuBtn && menuPanel) {
            var setMenu = function (open) {
                menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
                menuPanel.hidden = !open;
            };

            menuBtn.addEventListener('click', function (ev) {
                ev.stopPropagation();
                setMenu(menuPanel.hidden);
            });

            document.addEventListener('click', function (ev) {
                if (!menuPanel.hidden && !menuPanel.contains(ev.target) && ev.target !== menuBtn) {
                    setMenu(false);
                }
            });

            document.addEventListener('keydown', function (ev) {
                if (ev.key === 'Escape' && !menuPanel.hidden) {
                    setMenu(false);
                    menuBtn.focus();
                }
            });
        }
    })();
</script>
</div>
