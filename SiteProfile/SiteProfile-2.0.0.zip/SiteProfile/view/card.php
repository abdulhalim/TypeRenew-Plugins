<?php
/**
 * کارت ویرایش پروفایل با تب‌ها (پارشال)
 *
 * این فایل هم به‌عنوان بخش میانی صفحهٔ «در قالب پوسته» (میان header.php و
 * footer.php پوستهٔ فعال) و هم به‌عنوان هستهٔ صفحهٔ مستقلِ جایگزین رندر
 * می‌شود.
 *
 * متغیرهای در دسترس (از TypechoPlugin\SiteProfile\Action::renderInView):
 *
 * @var bool     $embedTheme    آیا صفحه در قالب پوسته سایت رندر می‌شود؟
 * @var string   $siteTitle     عنوان سایت
 * @var string   $siteUrl       آدرس سایت
 * @var string   $userName      نام کاربری
 * @var string   $screenName    نام مستعار فعلی
 * @var string   $mail          ایمیل فعلی
 * @var string   $url           نشانی وب‌سایت فعلی
 * @var string   $bio           بیوگرافی فعلی
 * @var array    $socials       نام‌های کاربری شبکه‌های اجتماعی فعلی (کلید => مقدار)
 * @var string   $groupLabel    برچسب فارسی گروه کاربری
 * @var string   $memberUrl     نشانی صفحهٔ عمومی این کاربر
 * @var int      $createdAt     تاریخ ثبت‌نام (timestamp)
 * @var int      $loggedAt      تاریخ آخرین ورود (timestamp)
 * @var string   $avatarUrl     نشانی آواتار فعلی (محلی یا گراواتار)
 * @var bool     $avatarLocal   آیا آواتار محلی دارد؟
 * @var bool     $avatarOn      آیا تب آواتار محلی فعال است؟
 * @var int      $avatarMinKB   حداقل حجم مجاز آواتار (کیلوبایت)
 * @var int      $avatarMaxKB   حداکثر حجم مجاز آواتار (کیلوبایت)
 * @var int      $avatarSize    ابعاد آواتار (پیکسل)
 * @var string   $avatarFormats برچسب فرمت‌های مجاز
 * @var array    $menuItems     گزینه‌های منوی «دسترسی سریع»
 * @var string   $formAction    آدرس ارسال فرم (همراه توکن امنیتی)
 * @var string   $logoutUrl     آدرس خروج از حساب (همراه توکن امنیتی)
 * @var int      $minPassword   حداقل طول رمز عبور
 * @var array|null $flash       پیام یک‌بارمصرف ['type' => ..., 'message' => ...]
 */

use TypechoPlugin\SiteProfile\Box;
use TypechoPlugin\SiteProfile\Jalali;
use TypechoPlugin\SiteProfile\Meta;

$e = static function ($value): string {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
};

$standalone = !($embedTheme ?? false);
$displayName = ($screenName ?? '') !== '' ? $screenName : ($userName ?? '');

$flashType = is_array($flash ?? null) ? (string) ($flash['type'] ?? '') : '';
$flashMessage = is_array($flash ?? null) ? (string) ($flash['message'] ?? '') : '';

$socials = is_array($socials ?? null) ? $socials : [];
$menuItems = is_array($menuItems ?? null) ? $menuItems : [];

$avatarOn = (bool) ($avatarOn ?? false);
$avatarLocal = (bool) ($avatarLocal ?? false);

// تب‌های موجود — «آواتار» فقط در صورت فعال‌بودن قابلیت
$tabs = ['profile'];
if ($avatarOn) {
    $tabs[] = 'avatar';
}
$tabs[] = 'security';
$tabs[] = 'social';
?>
<div class="sp-scope<?php echo $standalone ? ' sp-standalone' : ''; ?>">
<style>
    /* ===== توکن‌های رنگی =====
       توکن‌های افزونه هر جا پوسته توکن هم‌نام داشته باشد از آن ارث می‌برند
       (پوستهٔ «پرنیان»: --surface/--ink/--primary/... و پوستهٔ «پیش‌فرض»:
       --bg-primary/--text-primary/--accent-color/...) و در نبودِ آن‌ها به
       مقدار ثابت خود افزونه برمی‌گردند. چون پوسته‌ها توکن‌های خود را در
       حالت تیره ([data-theme='dark']) برمی‌گردانند، کارت هم همراه کل سایت
       بین روز و شب جابه‌جا می‌شود. */

    .sp-scope {
        direction: rtl;
        text-align: right;

        --sp-card: var(--surface, var(--bg-primary, #ffffff));
        --sp-field: var(--surface-soft, var(--bg-secondary, #fbfcfe));
        --sp-ink: var(--ink, var(--text-primary, #1f2937));
        --sp-ink-soft: var(--ink-soft, var(--text-secondary, #4b5563));
        --sp-ink-mute: var(--ink-mute, var(--text-tertiary, #6b7280));
        --sp-line: var(--line, var(--border-color, #e5e7eb));
        --sp-line-strong: var(--line-strong, var(--border-hover, #d1d5db));
        --sp-accent: var(--primary, var(--accent-color, #2563eb));
        --sp-btn-bg: var(--primary, var(--accent-color, #2563eb));
        --sp-btn-bg-hover: var(--primary-strong, var(--accent-hover, #1d4ed8));
        --sp-btn-ink: var(--primary-contrast, #ffffff);
        --sp-accent-soft: var(--primary-soft, rgba(37, 99, 235, 0.08));
        --sp-ring: var(--primary-glow, var(--focus-ring, rgba(37, 99, 235, 0.16)));
        --sp-radius: var(--radius-lg, 14px);
        --sp-radius-sm: var(--radius-md, 10px);
        --sp-shadow: var(--shadow-md, 0 14px 34px -16px rgba(15, 23, 42, 0.18));

        --sp-ok: #067647;
        --sp-ok-bg: #ecfdf5;
        --sp-ok-line: #a7f3d0;
        --sp-err: #b42318;
        --sp-err-bg: #fef3f2;
        --sp-err-line: #fecdca;
        --sp-note: #b54708;
        --sp-note-bg: #fffaeb;
        --sp-note-line: #fedf89;

        color: var(--sp-ink);
        line-height: 1.9;
    }

    /* حالت تیره: توکن‌های پوسته (در صورت وجود) خودکار حل می‌شوند؛
       در غیر این صورت پالت تیرهٔ خود افزونه اعمال می‌شود. */
    html[data-theme='dark'] .sp-scope,
    html.dark .sp-scope,
    body.dark .sp-scope {
        --sp-card: var(--surface, var(--bg-primary, #131a23));
        --sp-field: var(--surface-soft, var(--bg-secondary, #0e141c));
        --sp-ink: var(--ink, var(--text-primary, #e6edf3));
        --sp-ink-soft: var(--ink-soft, var(--text-secondary, #b6c2cf));
        --sp-ink-mute: var(--ink-mute, var(--text-tertiary, #8b98a5));
        --sp-line: var(--line, var(--border-color, #243040));
        --sp-line-strong: var(--line-strong, var(--border-hover, #33414f));
        --sp-accent: var(--primary, var(--accent-color, #6ea8fe));
        --sp-btn-bg: var(--primary, #3b82f6);
        --sp-btn-bg-hover: var(--primary-strong, #2563eb);
        --sp-btn-ink: var(--primary-contrast, #ffffff);
        --sp-accent-soft: var(--primary-soft, rgba(59, 130, 246, 0.14));
        --sp-ring: var(--primary-glow, var(--focus-ring, rgba(59, 130, 246, 0.25)));
        --sp-shadow: var(--shadow-md, 0 14px 34px -16px rgba(0, 0, 0, 0.55));

        --sp-ok: #7ee2a8;
        --sp-ok-bg: rgba(94, 234, 148, 0.10);
        --sp-ok-line: rgba(94, 234, 148, 0.32);
        --sp-err: #ff9d92;
        --sp-err-bg: rgba(248, 113, 113, 0.10);
        --sp-err-line: rgba(248, 113, 113, 0.32);
        --sp-note: #fcd34d;
        --sp-note-bg: rgba(251, 191, 36, 0.10);
        --sp-note-line: rgba(251, 191, 36, 0.32);
    }

    /* صفحهٔ مستقل: در نبود انتخاب صریح، از تنظیم سیستم‌عامل پیروی می‌کند */
    @media (prefers-color-scheme: dark) {
        html:not([data-theme]):not(.dark) .sp-scope.sp-standalone {
            --sp-card: #131a23;
            --sp-field: #0e141c;
            --sp-ink: #e6edf3;
            --sp-ink-soft: #b6c2cf;
            --sp-ink-mute: #8b98a5;
            --sp-line: #243040;
            --sp-line-strong: #33414f;
            --sp-accent: #6ea8fe;
            --sp-btn-bg: #3b82f6;
            --sp-btn-bg-hover: #2563eb;
            --sp-btn-ink: #ffffff;
            --sp-accent-soft: rgba(59, 130, 246, 0.14);
            --sp-ring: rgba(59, 130, 246, 0.25);
            --sp-shadow: 0 14px 34px -16px rgba(0, 0, 0, 0.55);

            --sp-ok: #7ee2a8;
            --sp-ok-bg: rgba(94, 234, 148, 0.10);
            --sp-ok-line: rgba(94, 234, 148, 0.32);
            --sp-err: #ff9d92;
            --sp-err-bg: rgba(248, 113, 113, 0.10);
            --sp-err-line: rgba(248, 113, 113, 0.32);
            --sp-note: #fcd34d;
            --sp-note-bg: rgba(251, 191, 36, 0.10);
            --sp-note-line: rgba(251, 191, 36, 0.32);
        }
    }

    /* ===== چیدمان ===== */

    .sp-scope .sp-page {
        max-width: 760px;
        margin-inline: auto;
        padding-block: 14px 44px;
    }

    .sp-scope.sp-standalone .sp-page {
        padding-inline: 16px;
        padding-top: 26px;
    }

    /* نوار بالای صفحهٔ مستقل */
    .sp-scope .sp-toprow {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding-block: 0 16px;
    }

    .sp-scope .sp-site {
        font-weight: 800;
        font-size: 16.5px;
        color: var(--sp-ink);
        text-decoration: none;
    }

    .sp-scope .sp-site:hover { color: var(--sp-accent); }

    .sp-scope .sp-toprow-actions {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .sp-scope .sp-toggle {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 38px;
        height: 38px;
        padding: 0;
        border: 1px solid var(--sp-line);
        border-radius: 50%;
        background: var(--sp-card);
        color: var(--sp-ink-soft);
        cursor: pointer;
        transition: color .15s, border-color .15s;
    }

    .sp-scope .sp-toggle:hover {
        color: var(--sp-accent);
        border-color: var(--sp-accent);
    }

    .sp-scope .sp-toggle .icon-sun { display: none; }
    html[data-theme='dark'] .sp-scope .sp-toggle .icon-sun,
    html.dark .sp-scope .sp-toggle .icon-sun { display: block; }
    html[data-theme='dark'] .sp-scope .sp-toggle .icon-moon,
    html.dark .sp-scope .sp-toggle .icon-moon { display: none; }
    @media (prefers-color-scheme: dark) {
        html:not([data-theme]):not(.dark) .sp-scope.sp-standalone .sp-toggle .icon-sun { display: block; }
        html:not([data-theme]):not(.dark) .sp-scope.sp-standalone .sp-toggle .icon-moon { display: none; }
    }

    /* ===== کارت اصلی ===== */

    /* برش فرزندان به منحنی گوشه‌های کارت: بدون این، پس‌زمینهٔ هیرو و
       پانوشت گوشه‌های گردِ بوردر کارت را می‌پوشاند و خطِ حاشیه در
       چهار گوشه قطع می‌شود. */
    .sp-scope .sp-card {
        background: var(--sp-card);
        border: 1px solid var(--sp-line);
        border-radius: var(--sp-radius);
        box-shadow: var(--sp-shadow);
        overflow: hidden;
    }

    /* هیرو: آواتار در آغاز (راست)، متن در میانه و دکمهٔ منو در
       انتهای سطر (چپ) */
    .sp-scope .sp-hero {
        display: flex;
        align-items: center;
        gap: 18px;
        padding: 26px 28px 22px;
        background:
            linear-gradient(215deg, var(--sp-accent-soft), transparent 68%),
            var(--sp-card);
        border-bottom: 1px solid var(--sp-line);
    }

    .sp-scope .sp-hero-text { min-width: 0; flex: 1 1 auto; }

    .sp-scope .sp-hero-text h1 {
        margin: 0;
        font-size: 19px;
        font-weight: 800;
        color: var(--sp-ink);
    }

    .sp-scope .sp-hero-text p {
        margin: 2px 0 0;
        color: var(--sp-ink-mute);
        font-size: 13.5px;
    }

    .sp-scope .sp-username {
        font-family: inherit;
        unicode-bidi: plaintext;
        direction: ltr;
    }

    .sp-scope .sp-badge {
        display: inline-block;
        margin-inline-start: 8px;
        padding: 1px 10px;
        font-size: 11.5px;
        border-radius: 999px;
        background: var(--sp-accent-soft);
        color: var(--sp-accent);
        vertical-align: 1px;
    }

    /* آواتار مربعی با انحنای کم + افکت پرتوی چرخان دور حاشیه */
    .sp-scope .sp-avatar-beam {
        position: relative;
        flex: none;
        width: 92px;
        height: 92px;
        padding: 4px;
        border-radius: 20px;
        overflow: hidden;
        background: var(--sp-card);
        box-shadow: inset 0 0 0 1px var(--sp-line), var(--sp-shadow);
    }

    .sp-scope .sp-avatar-beam::before {
        content: '';
        position: absolute;
        inset: -120%;
        background: conic-gradient(
            from 0deg,
            transparent 0deg 300deg,
            var(--sp-accent) 345deg,
            transparent 360deg
        );
        animation: sp-beam-spin 9s linear infinite;
    }

    @supports (background: color-mix(in srgb, red 50%, blue)) {
        .sp-scope .sp-avatar-beam::before {
            background: conic-gradient(
                from 0deg,
                transparent 0deg 265deg,
                color-mix(in srgb, var(--sp-accent) 30%, transparent) 305deg,
                color-mix(in srgb, var(--sp-accent) 65%, transparent) 330deg,
                var(--sp-accent) 347deg,
                transparent 360deg
            );
        }
    }

    @keyframes sp-beam-spin {
        to { transform: rotate(1turn); }
    }

    @media (prefers-reduced-motion: reduce) {
        .sp-scope .sp-avatar-beam::before { animation: none; }
    }

    .sp-scope .sp-avatar {
        position: relative;
        z-index: 1;
        display: block;
        width: 100%;
        height: 100%;
        border: none;
        border-radius: 16px;
        background: var(--sp-field);
        object-fit: cover;
    }

    /* ===== منوی «دسترسی سریع» (انتهای هیرو — سمت چپ) ===== */

    .sp-scope .sp-menu {
        position: relative;
        display: inline-block;
        flex: none;
    }

    .sp-scope .sp-hero-menu { align-self: center; }

    .sp-scope .sp-menu-btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 7px 15px;
        border: 1px solid var(--sp-line);
        border-radius: var(--sp-radius-sm);
        background: var(--sp-card);
        color: var(--sp-ink-soft);
        font: inherit;
        font-size: 13px;
        font-weight: 700;
        cursor: pointer;
        transition: color .15s, border-color .15s, background .15s;
    }

    .sp-scope .sp-menu-btn:hover,
    .sp-scope .sp-menu-btn[aria-expanded='true'] {
        color: var(--sp-accent);
        border-color: var(--sp-accent);
        background: var(--sp-accent-soft);
    }

    .sp-scope .sp-menu-btn svg { flex: none; }

    .sp-scope .sp-menu-btn .sp-chevron {
        transition: transform .15s;
    }

    .sp-scope .sp-menu-btn[aria-expanded='true'] .sp-chevron {
        transform: rotate(180deg);
    }

    .sp-scope .sp-menu-panel {
        position: absolute;
        top: calc(100% + 7px);
        inset-inline-end: 0;
        z-index: 40;
        min-width: 225px;
        padding: 6px;
        background: var(--sp-card);
        border: 1px solid var(--sp-line);
        border-radius: var(--sp-radius-sm);
        box-shadow: var(--sp-shadow);
    }

    .sp-scope .sp-menu-panel[hidden] { display: none; }

    .sp-scope .sp-menu-item {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 8px 12px;
        border-radius: 8px;
        color: var(--sp-ink-soft);
        font-size: 13.5px;
        font-weight: 600;
        text-decoration: none;
        white-space: nowrap;
        transition: color .12s, background .12s;
    }

    .sp-scope .sp-menu-item:hover {
        color: var(--sp-accent);
        background: var(--sp-accent-soft);
    }

    .sp-scope .sp-menu-item svg { color: var(--sp-ink-mute); flex: none; }
    .sp-scope .sp-menu-item:hover svg { color: var(--sp-accent); }

    .sp-scope .sp-menu-sep {
        height: 1px;
        margin: 5px 8px;
        background: var(--sp-line);
    }

    .sp-scope .sp-menu-item.sp-menu-danger:hover {
        color: var(--sp-err);
        background: var(--sp-err-bg);
    }

    .sp-scope .sp-menu-item.sp-menu-danger:hover svg { color: var(--sp-err); }

    /* ===== پیام‌ها ===== */

    .sp-scope .sp-flash {
        margin: 20px 28px 0;
        padding: 12px 16px;
        border-radius: var(--sp-radius-sm);
        font-size: 14px;
        line-height: 1.8;
        border: 1px solid transparent;
    }

    .sp-scope .sp-flash-success { background: var(--sp-ok-bg); color: var(--sp-ok); border-color: var(--sp-ok-line); }
    .sp-scope .sp-flash-error   { background: var(--sp-err-bg); color: var(--sp-err); border-color: var(--sp-err-line); }
    .sp-scope .sp-flash-notice  { background: var(--sp-note-bg); color: var(--sp-note); border-color: var(--sp-note-line); }

    /* ===== نوار تب‌ها ===== */

    /* نوار اسکرول مخفی (قابل اسکرول با لمس/چرخ؛ بدون نمایش نوار —
       آرتیفکت اسکرول‌بار کوتاه هنگام هاور برطرف می‌شود) */
    .sp-scope .sp-tabs {
        display: flex;
        gap: 2px;
        margin-top: 20px;
        padding: 0 14px;
        border-bottom: 1px solid var(--sp-line);
        background: var(--sp-field);
        overflow-x: auto;
        overscroll-behavior-x: contain;
        scrollbar-width: none;
        -ms-overflow-style: none;
    }

    .sp-scope .sp-tabs::-webkit-scrollbar { display: none; width: 0; height: 0; }

    .sp-scope .sp-tab {
        appearance: none;
        display: inline-flex;
        align-items: center;
        gap: 7px;
        padding: 12px 18px;
        margin-bottom: -1px;
        border: none;
        border-bottom: 2.5px solid transparent;
        background: transparent;
        color: var(--sp-ink-mute);
        font: inherit;
        font-size: 14px;
        font-weight: 700;
        cursor: pointer;
        white-space: nowrap;
        transition: color .15s, border-color .15s, background .15s;
    }

    .sp-scope .sp-tab svg { flex: none; }
    .sp-scope .sp-tab:hover { color: var(--sp-ink); }

    .sp-scope .sp-tab[aria-selected='true'] {
        color: var(--sp-accent);
        border-bottom-color: var(--sp-accent);
        background: var(--sp-card);
        border-start-start-radius: 8px;
        border-start-end-radius: 8px;
    }

    .sp-scope .sp-panel { padding: 26px 28px 30px; }
    .sp-scope .sp-panel[hidden] { display: none; }

    .sp-scope .sp-section > h2 {
        margin: 0 0 6px;
        font-size: 16px;
        font-weight: 700;
        color: var(--sp-ink);
    }

    .sp-scope .sp-section > p.sp-lead {
        margin: 0 0 18px;
        color: var(--sp-ink-mute);
        font-size: 13.5px;
    }

    /* ===== فهرست اطلاعات (تب امنیت) ===== */

    .sp-scope .sp-infolist {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 10px;
        margin: 0 0 22px;
    }

    .sp-scope .sp-infoitem {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 10px 14px;
        background: var(--sp-field);
        border: 1px solid var(--sp-line);
        border-radius: var(--sp-radius-sm);
        font-size: 13px;
        color: var(--sp-ink-soft);
    }

    .sp-scope .sp-infoitem svg { color: var(--sp-accent); flex: none; }
    .sp-scope .sp-infoitem b { color: var(--sp-ink); font-weight: 700; }

    /* ===== تب آواتار ===== */

    .sp-scope .sp-avatar-head {
        display: flex;
        align-items: center;
        gap: 20px;
        flex-wrap: wrap;
        margin-bottom: 20px;
    }

    /* پیش‌نمایش تب آواتار: مربع با انحنای کم (هم‌شکل آواتار هیرو) */
    .sp-scope .sp-avatar-preview {
        width: 128px;
        height: 128px;
        border-radius: 28px;
        border: 1px solid var(--sp-line);
        box-shadow: var(--sp-shadow);
        object-fit: cover;
        background: var(--sp-field);
        flex: none;
    }

    .sp-scope .sp-avatar-note {
        flex: 1 1 220px;
        min-width: 0;
        margin: 0;
        font-size: 13px;
        color: var(--sp-ink-mute);
        line-height: 2;
    }

    .sp-scope .sp-avatar-note b { color: var(--sp-ink); }

    .sp-scope .sp-dropzone {
        position: relative;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 30px 20px;
        border: 2px dashed var(--sp-line-strong);
        border-radius: var(--sp-radius-sm);
        background: var(--sp-field);
        text-align: center;
        cursor: pointer;
        transition: border-color .15s, background .15s;
    }

    .sp-scope .sp-dropzone:hover,
    .sp-scope .sp-dropzone.is-drag {
        border-color: var(--sp-accent);
        background: var(--sp-accent-soft);
    }

    .sp-scope .sp-dropzone svg { color: var(--sp-ink-mute); }
    .sp-scope .sp-dropzone:hover svg { color: var(--sp-accent); }

    .sp-scope .sp-dropzone-title {
        font-size: 14px;
        font-weight: 700;
        color: var(--sp-ink);
    }

    .sp-scope .sp-dropzone-hint {
        font-size: 12.5px;
        color: var(--sp-ink-mute);
    }

    .sp-scope .sp-dropzone input[type='file'] {
        position: absolute;
        inset: 0;
        opacity: 0;
        cursor: pointer;
        width: 100%;
        height: 100%;
    }

    .sp-scope .sp-avatar-filename {
        display: none;
        margin-top: 10px;
        padding: 8px 14px;
        border: 1px solid var(--sp-line);
        border-radius: var(--sp-radius-sm);
        background: var(--sp-card);
        font-size: 13px;
        color: var(--sp-ink-soft);
        text-align: center;
        direction: ltr;
        unicode-bidi: plaintext;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .sp-scope .sp-avatar-actions {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
        margin-top: 16px;
    }

    .sp-scope .sp-btn-danger {
        background: transparent;
        color: var(--sp-err);
        border: 1px solid var(--sp-err-line);
    }

    .sp-scope .sp-btn-danger:hover {
        background: var(--sp-err-bg);
        color: var(--sp-err);
        border-color: var(--sp-err);
    }

    .sp-scope .sp-hint {
        margin: 14px 0 0;
        font-size: 12.5px;
        color: var(--sp-ink-mute);
        line-height: 1.9;
    }

    /* ===== فرم‌ها ===== */

    .sp-scope .sp-field {
        margin-bottom: 16px;
    }

    .sp-scope .sp-field label {
        display: block;
        margin-bottom: 6px;
        font-weight: 600;
        font-size: 14px;
        color: var(--sp-ink);
    }

    .sp-scope .sp-req {
        color: var(--sp-err);
    }

    .sp-scope .sp-field input,
    .sp-scope .sp-field textarea {
        display: block;
        width: 100%;
        padding: 10px 14px;
        font: inherit;
        font-size: 14.5px;
        color: var(--sp-ink);
        background: var(--sp-field);
        border: 1px solid var(--sp-line);
        border-radius: var(--sp-radius-sm);
        outline: none;
        transition: border-color .15s, box-shadow .15s;
    }

    .sp-scope .sp-field textarea {
        min-height: 104px;
        resize: vertical;
        line-height: 1.9;
    }

    .sp-scope .sp-field input:focus,
    .sp-scope .sp-field textarea:focus {
        border-color: var(--sp-accent);
        box-shadow: 0 0 0 3px var(--sp-ring);
    }

    .sp-scope .sp-field input::placeholder,
    .sp-scope .sp-field textarea::placeholder {
        color: var(--sp-ink-mute);
        opacity: .75;
    }

    .sp-scope .sp-desc {
        margin: 6px 0 0;
        font-size: 12.5px;
        color: var(--sp-ink-mute);
        line-height: 1.8;
    }

    /* فیلد با آیکن (شبکه‌های اجتماعی) */
    .sp-scope .sp-inputwrap {
        position: relative;
    }

    .sp-scope .sp-inputwrap > svg {
        position: absolute;
        inset-inline-start: 13px;
        top: 50%;
        transform: translateY(-50%);
        color: var(--sp-ink-mute);
        pointer-events: none;
    }

    .sp-scope .sp-inputwrap > input { padding-inline-start: 38px; }
    .sp-scope .sp-inputwrap > input:focus ~ svg { color: var(--sp-accent); }

    .sp-scope .sp-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        column-gap: 16px;
    }

    .sp-scope .sp-btn {
        display: inline-block;
        padding: 11px 26px;
        font: inherit;
        font-size: 14.5px;
        font-weight: 700;
        color: var(--sp-btn-ink);
        background: var(--sp-btn-bg);
        border: none;
        border-radius: var(--sp-radius-sm);
        cursor: pointer;
        transition: background .15s, transform .06s;
    }

    .sp-scope .sp-btn:hover { background: var(--sp-btn-bg-hover); }
    .sp-scope .sp-btn:active { transform: translateY(1px); }

    .sp-scope .sp-btn-secondary {
        background: transparent;
        color: var(--sp-accent);
        border: 1px solid var(--sp-line-strong);
    }

    .sp-scope .sp-btn-secondary:hover {
        background: var(--sp-accent-soft);
        color: var(--sp-accent);
        border-color: var(--sp-accent);
    }

    /* ===== پانوشت ===== */

    .sp-scope .sp-foot {
        padding: 16px 28px 22px;
        border-top: 1px solid var(--sp-line);
        background: var(--sp-field);
        color: var(--sp-ink-mute);
        font-size: 12.5px;
        text-align: center;
    }

    .sp-scope .sp-foot a {
        color: var(--sp-accent);
        text-decoration: none;
    }

    .sp-scope .sp-foot a:hover { text-decoration: underline; }

    /* ===== واکنش‌گرا ===== */

    @media (max-width: 620px) {
        .sp-scope .sp-grid { grid-template-columns: 1fr; }
        .sp-scope .sp-infolist { grid-template-columns: 1fr; }
        .sp-scope .sp-avatar-head { align-items: flex-start; }
    }

    @media (max-width: 480px) {
        .sp-scope .sp-hero { flex-wrap: wrap; padding: 20px; gap: 14px; }
        .sp-scope .sp-avatar-beam { width: 72px; height: 72px; border-radius: 16px; }
        .sp-scope .sp-avatar { border-radius: 12px; }
        .sp-scope .sp-hero-menu {
            order: 3;
            flex-basis: 100%;
            margin-top: 2px;
        }
        .sp-scope .sp-hero-menu .sp-menu-btn { width: 100%; justify-content: center; }
        .sp-scope .sp-panel { padding: 22px 20px 26px; }
        .sp-scope .sp-flash { margin: 18px 20px 0; }
        .sp-scope .sp-hero-text h1 { font-size: 17px; }
        .sp-scope .sp-btn { width: 100%; }
        .sp-scope .sp-avatar-actions .sp-btn { width: 100%; }
        .sp-scope .sp-page { padding-block: 6px 36px; }
        .sp-scope .sp-tabs { padding: 0 6px; }
        .sp-scope .sp-tab { padding: 11px 13px; font-size: 13px; }
        .sp-scope .sp-menu-panel { max-width: calc(100vw - 40px); }
    }
</style>

<div class="sp-page">

    <?php if ($standalone): ?>
        <nav class="sp-toprow">
            <a class="sp-site" href="<?php echo $e($siteUrl); ?>"><?php echo $e($siteTitle); ?></a>
            <div class="sp-toprow-actions">
                <button type="button" class="sp-toggle" id="sp-theme-toggle"
                        aria-label="تغییر حالت روشن/تیره" title="حالت روشن/تیره">
                    <svg class="icon-moon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
                    </svg>
                    <svg class="icon-sun" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <circle cx="12" cy="12" r="4.5"></circle>
                        <path d="M12 1.5v2.5M12 20v2.5M4.2 4.2l1.8 1.8M18 18l1.8 1.8M1.5 12h2.5M20 12h2.5M4.2 19.8l1.8-1.8M18 6l1.8-1.8"></path>
                    </svg>
                </button>
            </div>
        </nav>
    <?php endif; ?>

    <main class="sp-card">

        <div class="sp-hero">
            <div class="sp-avatar-beam">
                <img class="sp-avatar" src="<?php echo $e($avatarUrl); ?>" alt="<?php echo $e($displayName); ?>" width="84" height="84">
            </div>
            <div class="sp-hero-text">
                <h1>پروفایل کاربری <span class="sp-badge"><?php echo $e($groupLabel); ?></span></h1>
                <p>خوش آمدید، <strong><?php echo $e($displayName); ?></strong>!</p>
                <p>نام کاربری شما: <span class="sp-username"><?php echo $e($userName); ?></span></p>
            </div>
            <?php if ($menuItems !== []): ?>
                <div class="sp-menu sp-hero-menu" id="sp-quick-menu">
                    <button type="button" class="sp-menu-btn" id="sp-menu-btn"
                            aria-haspopup="menu" aria-expanded="false" aria-controls="sp-menu-panel">
                        <?php echo Box::icon('dashboard'); ?>
                        دسترسی سریع
                        <svg class="sp-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"></polyline></svg>
                    </button>
                    <div class="sp-menu-panel" id="sp-menu-panel" role="menu" aria-labelledby="sp-menu-btn" hidden>
                        <?php foreach ($menuItems as $item): ?>
                            <?php if (!empty($item['divider'])): ?>
                                <div class="sp-menu-sep" role="separator"></div>
                            <?php endif; ?>
                            <a class="sp-menu-item<?php echo $item['icon'] === 'logout' ? ' sp-menu-danger' : ''; ?>"
                               role="menuitem" href="<?php echo $e($item['url']); ?>">
                                <?php echo Box::icon((string) $item['icon']); ?>
                                <?php echo $e($item['label']); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <?php if ($flashMessage !== ''): ?>
            <div class="sp-flash sp-flash-<?php echo $e($flashType); ?>" role="alert">
                <?php echo $e($flashMessage); ?>
            </div>
        <?php endif; ?>

        <nav class="sp-tabs" role="tablist" aria-label="بخش‌های پروفایل">
            <button type="button" class="sp-tab" id="sp-btn-profile" role="tab"
                    aria-controls="sp-panel-profile" aria-selected="true" data-sp-tab="profile">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                پروفایل
            </button>
            <?php if ($avatarOn): ?>
                <button type="button" class="sp-tab" id="sp-btn-avatar" role="tab"
                        aria-controls="sp-panel-avatar" aria-selected="false" data-sp-tab="avatar" tabindex="-1">
                    <?php echo Box::icon('camera'); ?>
                    آواتار محلی
                </button>
            <?php endif; ?>
            <button type="button" class="sp-tab" id="sp-btn-security" role="tab"
                    aria-controls="sp-panel-security" aria-selected="false" data-sp-tab="security" tabindex="-1">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                امنیت
            </button>
            <button type="button" class="sp-tab" id="sp-btn-social" role="tab"
                    aria-controls="sp-panel-social" aria-selected="false" data-sp-tab="social" tabindex="-1">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"></path></svg>
                شبکه‌های اجتماعی
            </button>
        </nav>

        <section class="sp-panel sp-section" id="sp-panel-profile" role="tabpanel" aria-labelledby="sp-btn-profile">
            <h2>اطلاعات پروفایل</h2>
            <p class="sp-lead">نام مستعار، ایمیل و بیوگرافی کوتاه شما؛ این اطلاعات در باکس نویسنده و صفحهٔ عمومی‌تان نمایش داده می‌شود.</p>

            <form class="sp-form" method="post" action="<?php echo $e($formAction); ?>">
                <input type="hidden" name="do" value="profile">

                <div class="sp-field">
                    <label for="sp-screen-name">نام مستعار</label>
                    <input id="sp-screen-name" type="text" name="screenName"
                           value="<?php echo $e($screenName); ?>" maxlength="32" autocomplete="nickname">
                    <p class="sp-desc">نامی که به‌جای نام کاربری در سایت نمایش داده می‌شود. اگر خالی بماند، نام کاربری شما استفاده خواهد شد.</p>
                </div>

                <div class="sp-field">
                    <label for="sp-mail">نشانی ایمیل <span class="sp-req">*</span></label>
                    <input id="sp-mail" type="email" name="mail"
                           value="<?php echo $e($mail); ?>" maxlength="150" required autocomplete="email">
                    <p class="sp-desc">نشانی ایمیل اصلی حساب شما. برای تغییر آن، وارد کردن رمز عبور فعلی لازم است.</p>
                </div>

                <div class="sp-field">
                    <label for="sp-bio">بیوگرافی کوتاه</label>
                    <textarea id="sp-bio" name="bio" maxlength="<?php echo (int) Meta::MAX_BIO; ?>"
                              placeholder="چند خط دربارهٔ خودتان؛ مثلاً علاقه‌مندی‌ها، مهارت‌ها یا جایگاه شما در این سایت…"><?php echo $e($bio); ?></textarea>
                    <p class="sp-desc">حداکثر <?php echo $e(Jalali::digits((string) Meta::MAX_BIO)); ?> کاراکتر. این متن در باکس نویسندهٔ نوشته‌ها و صفحهٔ عمومی شما نمایش داده می‌شود.</p>
                </div>

                <div class="sp-field" id="sp-current-wrap">
                    <label for="sp-current-profile">رمز عبور فعلی</label>
                    <input id="sp-current-profile" type="password" name="currentPassword" autocomplete="current-password">
                    <p class="sp-desc">این فیلد فقط هنگام تغییر ایمیل الزامی است.</p>
                </div>

                <button type="submit" class="sp-btn">ذخیره اطلاعات</button>
            </form>
        </section>

        <?php if ($avatarOn): ?>
            <section class="sp-panel sp-section" id="sp-panel-avatar" role="tabpanel" aria-labelledby="sp-btn-avatar" hidden>
                <h2>آواتار محلی</h2>
                <p class="sp-lead">به‌جای گراواتار، تصویر اختصاصی خود را بارگذاری کنید؛ تصویر شما در پروفایل، صفحهٔ عمومی، باکس نویسنده و انجمن (در صورت فعال‌بودن) نمایش داده می‌شود.</p>

                <div class="sp-avatar-head">
                    <img class="sp-avatar-preview" id="sp-avatar-preview" src="<?php echo $e($avatarUrl); ?>"
                         alt="<?php echo $e($displayName); ?>" width="128" height="128">
                    <p class="sp-avatar-note">
                        <?php if ($avatarLocal): ?>
                            در حال حاضر <b>آواتار محلی</b> شما نمایش داده می‌شود. با بارگذاری تصویر جدید، تصویر قبلی جایگزین می‌شود.
                        <?php else: ?>
                            در حال حاضر تصویر <b>گراواتار</b> شما (بر پایهٔ ایمیل) نمایش داده می‌شود. با بارگذاری تصویر، از آن به‌جای گراواتار استفاده می‌شود.
                        <?php endif; ?>
                    </p>
                </div>

                <form method="post" action="<?php echo $e($formAction); ?>" enctype="multipart/form-data" id="sp-avatar-form">
                    <input type="hidden" name="do" value="avatar">

                    <label class="sp-dropzone" id="sp-dropzone">
                        <?php echo Box::icon('upload'); ?>
                        <span class="sp-dropzone-title">انتخاب تصویر یا رها کردن آن این‌جا</span>
                        <span class="sp-dropzone-hint">
                            <?php
                                $constraints = ['فرمت‌ها: ' . $avatarFormats];
                                if ((int) $avatarMinKB > 0) {
                                    $constraints[] = 'حداقل حجم: ' . Jalali::digits((string) $avatarMinKB) . ' کیلوبایت';
                                }
                                $constraints[] = 'حداکثر حجم: ' . Jalali::digits((string) $avatarMaxKB) . ' کیلوبایت';
                                $constraints[] = 'حداقل ابعاد: ' . Jalali::digits((string) $avatarSize) . '×' . Jalali::digits((string) $avatarSize) . ' پیکسل';
                                echo $e(implode(' — ', $constraints));
                            ?>
                        </span>
                        <input type="file" name="avatar" id="sp-avatar-input"
                               accept="image/jpeg,image/png,image/webp,image/gif">
                    </label>

                    <div class="sp-avatar-filename" id="sp-avatar-filename"></div>

                    <div class="sp-avatar-actions">
                        <button type="submit" class="sp-btn" id="sp-avatar-submit" disabled>بارگذاری آواتار</button>
                    </div>
                </form>

                <?php if ($avatarLocal): ?>
                    <form method="post" action="<?php echo $e($formAction); ?>" id="sp-avatar-delete-form">
                        <input type="hidden" name="do" value="avatarDelete">
                        <div class="sp-avatar-actions">
                            <button type="submit" class="sp-btn sp-btn-danger">حذف آواتار محلی و بازگشت به گراواتار</button>
                        </div>
                    </form>
                <?php endif; ?>

                <p class="sp-hint">تصویر بارگذاری‌شده به‌صورت خودکار به فرمت WebP (سبک‌تر) تبدیل و مربع مرکزی آن برش می‌خورد؛ پس نیازی به ویرایش دقیق ابعاد نیست — فقط ابعاد تصویر نباید از حداقل تنظیم‌شده کمتر باشد.</p>
            </section>
        <?php endif; ?>

        <section class="sp-panel sp-section" id="sp-panel-security" role="tabpanel" aria-labelledby="sp-btn-security" hidden>
            <h2>امنیت و رمز عبور</h2>
            <p class="sp-lead">برای امنیت بیشتر، رمز عبور فعلی برای تعیین رمز جدید الزامی است.</p>

            <div class="sp-infolist">
                <div class="sp-infoitem">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                    <span>تاریخ عضویت: <b><?php echo $e(Jalali::date($createdAt ?? 0)); ?></b></span>
                </div>
                <div class="sp-infoitem">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path><polyline points="10 17 15 12 10 7"></polyline><line x1="15" y1="12" x2="3" y2="12"></line></svg>
                    <span>آخرین ورود شما: <b><?php echo $e(($loggedAt ?? 0) > 0 ? Jalali::dateTime($loggedAt) : 'این نخستین ورود شماست'); ?></b></span>
                </div>
            </div>

            <form class="sp-form" method="post" action="<?php echo $e($formAction); ?>">
                <input type="hidden" name="do" value="password">

                <div class="sp-field">
                    <label for="sp-current-pass">رمز عبور فعلی <span class="sp-req">*</span></label>
                    <input id="sp-current-pass" type="password" name="currentPassword" required autocomplete="current-password">
                </div>

                <div class="sp-field">
                    <label for="sp-new-pass">رمز عبور جدید <span class="sp-req">*</span></label>
                    <input id="sp-new-pass" type="password" name="password" minlength="<?php echo (int) $minPassword; ?>" required autocomplete="new-password">
                    <p class="sp-desc">حداقل <?php echo (int) $minPassword; ?> کاراکتر؛ ترکیب حروف، عدد و نماد امنیت بیشتری دارد.</p>
                </div>

                <div class="sp-field">
                    <label for="sp-confirm-pass">تکرار رمز عبور جدید <span class="sp-req">*</span></label>
                    <input id="sp-confirm-pass" type="password" name="confirm" required autocomplete="new-password">
                </div>

                <button type="submit" class="sp-btn sp-btn-secondary">تغییر رمز عبور</button>
            </form>
        </section>

        <section class="sp-panel sp-section" id="sp-panel-social" role="tabpanel" aria-labelledby="sp-btn-social" hidden>
            <h2>وب‌سایت و شبکه‌های اجتماعی</h2>
            <p class="sp-lead">نشانی‌های شما؛ کافی است نام کاربری هر شبکه را وارد کنید (یا نشانی کامل پروفایل‌تان را).</p>

            <form class="sp-form" method="post" action="<?php echo $e($formAction); ?>">
                <input type="hidden" name="do" value="social">

                <div class="sp-field">
                    <label for="sp-url">وب‌سایت</label>
                    <div class="sp-inputwrap">
                        <input id="sp-url" type="url" name="url"
                               value="<?php echo $e($url); ?>" maxlength="150" placeholder="https://example.com" autocomplete="url">
                        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>
                    </div>
                    <p class="sp-desc">نشانی سایت یا صفحه شخصی شما؛ خالی گذاشتن آن اختیاری است.</p>
                </div>

                <div class="sp-grid">
                    <?php foreach (Meta::SOCIALS as $key => $definition): ?>
                        <div class="sp-field">
                            <label for="sp-social-<?php echo $e($key); ?>"><?php echo $e($definition['label']); ?></label>
                            <div class="sp-inputwrap">
                                <input id="sp-social-<?php echo $e($key); ?>" type="text" name="<?php echo $e($key); ?>"
                                       value="<?php echo $e($socials[$key] ?? ''); ?>" maxlength="<?php echo (int) Meta::MAX_HANDLE; ?>"
                                       placeholder="نام کاربری" autocomplete="off">
                                <?php echo Box::icon($key); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <p class="sp-desc" style="margin: -6px 0 18px;">اگر مقدار هر شبکه را با نام کاربری وارد کنید، پیوند پروفایل شما خودکار ساخته می‌شود؛ نشانی کامل هم پذیرفته می‌شود.</p>

                <button type="submit" class="sp-btn">ذخیره شبکه‌های اجتماعی</button>
            </form>
        </section>

        <footer class="sp-foot">
            حساب شما در <a href="<?php echo $e($siteUrl); ?>"><?php echo $e($siteTitle); ?></a> نگهداری می‌شود.
        </footer>

    </main>
</div>

<script>
    (function () {
        // ===== تب‌ها =====
        var TABS = <?php echo json_encode($tabs, JSON_UNESCAPED_SLASHES); ?>;

        function activate(name) {
            if (TABS.indexOf(name) < 0) {
                name = 'profile';
            }

            TABS.forEach(function (tab) {
                var btn = document.getElementById('sp-btn-' + tab);
                var panel = document.getElementById('sp-panel-' + tab);
                var active = tab === name;

                if (btn) {
                    btn.setAttribute('aria-selected', active ? 'true' : 'false');
                    btn.tabIndex = active ? 0 : -1;
                }
                if (panel) {
                    panel.hidden = !active;
                }
            });
        }

        TABS.forEach(function (tab) {
            var btn = document.getElementById('sp-btn-' + tab);
            if (btn) {
                btn.addEventListener('click', function () {
                    activate(tab);
                    try { history.replaceState(null, '', '#sp-panel-' + tab); } catch (e) { /* noop */ }
                });
            }
        });

        // فعال‌سازی تبِ اشاره‌شده در نشانی (پس از ذخیره و بازگشت)
        var tabNames = TABS.join('|');
        var match = (location.hash || '').match(new RegExp('^#sp-panel-(' + tabNames + ')$'));
        activate(match ? match[1] : 'profile');

        // ===== منوی «دسترسی سریع» =====
        var menuBtn = document.getElementById('sp-menu-btn');
        var menuPanel = document.getElementById('sp-menu-panel');

        if (menuBtn && menuPanel) {
            var setMenu = function (open) {
                menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
                menuPanel.hidden = !open;
            };

            menuBtn.addEventListener('click', function (ev) {
                ev.stopPropagation();
                setMenu(menuPanel.hidden);
            });

            document.addEventListener('click', function (ev) {
                if (!menuPanel.hidden && !menuPanel.contains(ev.target) && ev.target !== menuBtn) {
                    setMenu(false);
                }
            });

            document.addEventListener('keydown', function (ev) {
                if (ev.key === 'Escape' && !menuPanel.hidden) {
                    setMenu(false);
                    menuBtn.focus();
                }
            });
        }

        // ===== نمایش شرطی رمز فعلی هنگام تغییر ایمیل =====
        var mail = document.getElementById('sp-mail');
        var wrap = document.getElementById('sp-current-wrap');
        var field = document.getElementById('sp-current-profile');

        if (mail && wrap && field) {
            var initialMail = mail.value;

            var sync = function () {
                var changed = mail.value !== initialMail;
                wrap.hidden = !changed;
                if (!changed) {
                    field.value = '';
                }
            };

            wrap.hidden = true;
            mail.addEventListener('input', sync);
        }

        // ===== فرم آواتار: پیش‌نمایش محلی + نام فایل + فعال‌شدن دکمه =====
        var input = document.getElementById('sp-avatar-input');
        var submit = document.getElementById('sp-avatar-submit');
        var nameBox = document.getElementById('sp-avatar-filename');
        var preview = document.getElementById('sp-avatar-preview');
        var dropzone = document.getElementById('sp-dropzone');

        if (input && submit) {
            input.addEventListener('change', function () {
                var file = input.files && input.files[0];

                if (file && nameBox) {
                    nameBox.style.display = 'block';
                    nameBox.textContent = file.name + ' (' + Math.max(1, Math.round(file.size / 1024)) + ' KB)';
                }

                if (file && preview && window.FileReader && /^image\//.test(file.type)) {
                    var reader = new FileReader();
                    reader.onload = function (ev) {
                        preview.src = ev.target.result;
                    };
                    reader.readAsDataURL(file);
                }

                submit.disabled = !file;
            });
        }

        if (dropzone) {
            ['dragenter', 'dragover'].forEach(function (evName) {
                dropzone.addEventListener(evName, function (ev) {
                    ev.preventDefault();
                    dropzone.classList.add('is-drag');
                });
            });

            ['dragleave', 'drop'].forEach(function (evName) {
                dropzone.addEventListener(evName, function (ev) {
                    ev.preventDefault();
                    dropzone.classList.remove('is-drag');
                });
            });
        }

        // ===== دکمهٔ حالت روشن/تیره (فقط صفحهٔ مستقل) =====
        var toggle = document.getElementById('sp-theme-toggle');

        if (toggle) {
            toggle.addEventListener('click', function () {
                var html = document.documentElement;
                var isDark = html.getAttribute('data-theme') === 'dark';
                var next = isDark ? 'light' : 'dark';

                html.setAttribute('data-theme', next);

                try {
                    localStorage.setItem('siteprofile-theme', next);
                } catch (e) { /* دسترسی به localStorage ممکن نیست */ }
            });
        }
    })();
</script>
</div>
