<?php
/**
 * صفحهٔ مستقل جایگزین پوسته (در نبود هدر/فوتر پوستهٔ فعال)
 *
 * وقتی «ادغام با پوسته» خاموش است یا پوستهٔ فعال فایل‌های header.php و
 * footer.php ندارد، این پوستهٔ حداقلیِ خود افزونه به‌جای قالب پوسته
 * استفاده می‌شود. حالت روشن/تیرهٔ آن از تنظیم سیستم‌عامل کاربر پیروی
 * می‌کند و با دکمهٔ ماه/خورشید قابل تغییر و در مرورگر ذخیره است.
 *
 * متغیرهای در دسترس: مانند نمای میانی ($view) به‌علاوهٔ $pageTitle
 */

$e = static function ($value): string {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
};

$viewFile = __DIR__ . '/' . preg_replace('/[^a-z]/', '', (string) ($view ?? 'card')) . '.php';
$pageTitle = (string) ($pageTitle ?? 'پروفایل کاربری');
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title><?php echo $e($pageTitle); ?> — <?php echo $e($siteTitle); ?></title>
    <script>
        // تعیین حالت رنگی پیش از رندر (بدون پرش رنگ)
        (function () {
            var stored = null;
            try { stored = localStorage.getItem('siteprofile-theme'); } catch (e) {}
            var isDark = false;
            if (stored === 'dark' || stored === 'light') {
                isDark = (stored === 'dark');
            } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
                isDark = true;
            }
            if (isDark) {
                document.documentElement.setAttribute('data-theme', 'dark');
            }
        })();
    </script>
    <style>
        html { color-scheme: light; }
        html[data-theme='dark'] { color-scheme: dark; }

        body {
            margin: 0;
            font-family: "Vazirmatn", "IRANSans", "Segoe UI", Tahoma, Arial, sans-serif;
            font-size: 15px;
            line-height: 1.9;
            color: #1f2937;
            background: radial-gradient(900px 480px at 85% -10%, rgba(37, 99, 235, .07), transparent 60%), #f2f5fa;
            min-height: 100vh;
        }

        html[data-theme='dark'] body {
            color: #e6edf3;
            background: radial-gradient(900px 480px at 85% -10%, rgba(59, 130, 246, .09), transparent 60%), #0b0f14;
        }
    </style>
</head>
<body>
<?php include $viewFile; ?>
</body>
</html>
