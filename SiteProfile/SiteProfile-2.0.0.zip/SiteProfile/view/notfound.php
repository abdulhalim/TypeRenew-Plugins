<?php
/**
 * صفحهٔ «کاربر یافت نشد» (خطای ۴۰۴ صفحهٔ عمومی)
 *
 * @var bool   $embedTheme آیا صفحه در قالب پوسته سایت رندر می‌شود؟
 * @var string $siteTitle  عنوان سایت
 * @var string $siteUrl    آدرس سایت
 */

$e = static function ($value): string {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
};

$standalone = !($embedTheme ?? false);
?>
<div class="sp-scope sp-member<?php echo $standalone ? ' sp-standalone' : ''; ?>">
<style>
    .sp-scope.sp-member {
        direction: rtl;
        text-align: right;

        --sp-card: var(--surface, var(--bg-primary, #ffffff));
        --sp-ink: var(--ink, var(--text-primary, #1f2937));
        --sp-ink-mute: var(--ink-mute, var(--text-tertiary, #6b7280));
        --sp-line: var(--line, var(--border-color, #e5e7eb));
        --sp-accent: var(--primary, var(--accent-color, #2563eb));
        --sp-radius: var(--radius-lg, 14px);
        --sp-shadow: var(--shadow-md, 0 14px 34px -16px rgba(15, 23, 42, 0.18));

        color: var(--sp-ink);
        line-height: 1.9;
    }

    html[data-theme='dark'] .sp-scope.sp-member,
    html.dark .sp-scope.sp-member,
    body.dark .sp-scope.sp-member {
        --sp-card: var(--surface, var(--bg-primary, #131a23));
        --sp-ink: var(--ink, var(--text-primary, #e6edf3));
        --sp-ink-mute: var(--ink-mute, var(--text-tertiary, #8b98a5));
        --sp-line: var(--line, var(--border-color, #243040));
        --sp-accent: var(--primary, var(--accent-color, #6ea8fe));
        --sp-shadow: var(--shadow-md, 0 14px 34px -16px rgba(0, 0, 0, 0.55));
    }

    .sp-scope.sp-member .sp-page {
        max-width: 620px;
        margin-inline: auto;
        padding-block: 34px 54px;
    }

    .sp-scope.sp-member.sp-standalone .sp-page { padding-inline: 16px; }

    .sp-scope.sp-member .sp-card {
        padding: 40px 32px;
        background: var(--sp-card);
        border: 1px solid var(--sp-line);
        border-radius: var(--sp-radius);
        box-shadow: var(--sp-shadow);
        text-align: center;
    }

    .sp-scope.sp-member .sp-code {
        font-size: 34px;
        font-weight: 800;
        color: var(--sp-accent);
    }

    .sp-scope.sp-member h1 {
        margin: 4px 0 8px;
        font-size: 18px;
        font-weight: 800;
        color: var(--sp-ink);
    }

    .sp-scope.sp-member p {
        margin: 0 0 20px;
        font-size: 13.5px;
        color: var(--sp-ink-mute);
    }

    .sp-scope.sp-member a {
        display: inline-block;
        padding: 9px 24px;
        background: var(--sp-card);
        border: 1px solid var(--sp-line);
        border-radius: 10px;
        color: var(--sp-accent);
        font-size: 13.5px;
        font-weight: 700;
        text-decoration: none;
    }

    .sp-scope.sp-member a:hover { border-color: var(--sp-accent); }
</style>

<div class="sp-page">
    <div class="sp-card">
        <div class="sp-code">۴۰۴</div>
        <h1>کاربر یافت نشد</h1>
        <p>این صفحهٔ عمومی کاربر وجود ندارد یا نمایش صفحه‌های عمومی کاربران توسط مدیر سایت خاموش شده است.</p>
        <a href="<?php echo $e($siteUrl); ?>">بازگشت به <?php echo $e($siteTitle); ?></a>
    </div>
</div>
</div>
