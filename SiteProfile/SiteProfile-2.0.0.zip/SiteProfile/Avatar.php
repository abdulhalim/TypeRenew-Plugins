<?php
declare(strict_types=1);

namespace TypechoPlugin\SiteProfile;

use Typecho\Common;
use Typecho\Db;
use Typecho\Plugin as Hook;
use Widget\Options;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * موتور آواتار محلی — آپلود، تبدیل WebP و ذخیره‌سازی
 *
 * کاربران به‌جای گراواتار می‌توانند تصویر اختصاصی خود را بارگذاری کنند.
 * تصویر بارگذاری‌شده پس از اعتبارسنجی (سایز فایل، ابعاد و فرمت) با کتابخانهٔ
 * GD برش می‌خورد (مربع مرکزی)، به ابعاد تنظیم‌شدهٔ مدیر تبدیل می‌شود و در
 * قالب WebP (در صورت پشتیبانی سرور) در مسیر usr/uploads/avatars ذخیره
 * می‌شود. چون فایل نهایی همیشه توسط GD از نو کدگذاری می‌شود، محتوای
 * آپلودی هرگز مستقیم سرو نمی‌شود.
 *
 * API عمومی برای توسعه‌دهندگان پوسته/افزونه:
 *
 *   Avatar::url($uid);      // نشانی آواتار محلی کاربر یا ''
 *   Avatar::exists($uid);   // آیا کاربر آواتار محلی دارد؟
 *   Avatar::resolve($uid, $mail, $size);  // ['url' => ..., 'local' => bool]
 *   Avatar::html($uid, $mail, $size);     // تگ <img> نهایی (محلی یا گراواتار)
 *
 * @package SiteProfile
 * @since 2.0.0
 */
class Avatar
{
    /** نام ستون نام فایل آواتار در جدول افزونه */
    public const FILE_COLUMN = 'avatar_file';

    /** بیشینهٔ ابعاد مجاز تصویر ورودی (ایمنی حافظهٔ GD) */
    private const MAX_SOURCE_DIM = 5000;

    /** کیفیت فشرده‌سازی WebP خروجی */
    private const WEBP_QUALITY = 82;

    /** بیشینهٔ تعداد مدخل‌های نگاشت تعویض آواتار انجمن */
    private const SWAP_MAP_LIMIT = 500;

    /** کش درخواست جاری: uid => نام فایل (null = بدون آواتار) */
    private static array $cache = [];

    /** کش درخواست جاری: نام ستون‌های موجود جدول */
    private static ?array $tableColumns = null;

    // ------------------------------------------------------------------
    //  تنظیمات
    // ------------------------------------------------------------------

    /** آیا قابلیت آواتار محلی فعال است؟ (کلید تنظیم: avatarTab) */
    public static function enabled(): bool
    {
        return Plugin::settings()['avatarTab'] === '1';
    }

    /** ابعاد مربع آواتار (پیکسل) */
    public static function size(): int
    {
        return (int) Plugin::settings()['avatarSize'];
    }

    /** حداقل حجم مجاز (کیلوبایت؛ صفر = بدون حداقل) */
    public static function minKB(): int
    {
        return (int) Plugin::settings()['avatarMinKB'];
    }

    /** حداکثر حجم مجاز (کیلوبایت) */
    public static function maxKB(): int
    {
        return (int) Plugin::settings()['avatarMaxKB'];
    }

    /** فرمت‌های ورودی مجاز: ['jpg' => ['ext'..., 'mime'...], ...] */
    public static function allowedFormats(): array
    {
        $all = [
            'jpg'  => ['ext' => ['jpg', 'jpeg'], 'mime' => ['image/jpeg'], 'label' => 'JPG'],
            'png'  => ['ext' => ['png'],         'mime' => ['image/png'],  'label' => 'PNG'],
            'webp' => ['ext' => ['webp'],        'mime' => ['image/webp'], 'label' => 'WebP'],
            'gif'  => ['ext' => ['gif'],         'mime' => ['image/gif'],  'label' => 'GIF'],
        ];

        $enabled = (array) (Plugin::settings()['avatarFormats'] ?? []);

        return array_filter(
            $all,
            static fn (string $key): bool => in_array($key, $enabled, true),
            ARRAY_FILTER_USE_KEY
        );
    }

    /** برچسب فارسی فرمت‌های مجاز برای نمایش در فرم */
    public static function formatLabel(): string
    {
        $labels = array_map(static fn ($f): string => $f['label'], self::allowedFormats());

        return $labels === [] ? '—' : implode('، ', $labels);
    }

    // ------------------------------------------------------------------
    //  مسیرها
    // ------------------------------------------------------------------

    /** پوشهٔ ذخیرهٔ آواتارها (سیستم فایل) */
    public static function dir(): string
    {
        $uploadDir = defined('__TYPECHO_UPLOAD_DIR__') ? __TYPECHO_UPLOAD_DIR__ : '/usr/uploads';
        $root = defined('__TYPECHO_UPLOAD_ROOT_DIR__') ? __TYPECHO_UPLOAD_ROOT_DIR__ : __TYPECHO_ROOT_DIR__;

        return rtrim(Common::url($uploadDir, $root), '/') . '/avatars';
    }

    /** پیشوند نشانی وب آواتارها */
    private static function urlBase(): string
    {
        $uploadDir = defined('__TYPECHO_UPLOAD_DIR__') ? __TYPECHO_UPLOAD_DIR__ : '/usr/uploads';

        return rtrim(Common::url($uploadDir . '/avatars', (string) Options::alloc()->siteUrl), '/');
    }

    /** نشانی وب آواتار محلی یک کاربر ('' در نبود آواتار) */
    public static function url(int $uid): string
    {
        $file = self::fileOf($uid);

        return $file === '' ? '' : self::urlBase() . '/' . rawurlencode($file);
    }

    /** آیا کاربر آواتار محلی دارد؟ (مستقل از فعال‌بودن قابلیت) */
    public static function exists(int $uid): bool
    {
        return self::fileOf($uid) !== '';
    }

    /**
     * آواتار نهایی برای نمایش: آواتار محلی در صورت وجود و فعال‌بودن
     * قابلیت، وگرنه گراواتار.
     *
     * @return array{url: string, local: bool}
     */
    public static function resolve(int $uid, string $mail = '', int $size = 96): array
    {
        if (self::enabled() && self::exists($uid)) {
            return ['url' => self::url($uid), 'local' => true];
        }

        try {
            $secure = (bool) \Typecho\Request::getInstance()->isSecure();
        } catch (\Throwable) {
            $secure = false;
        }

        return ['url' => Common::gravatarUrl($mail, $size, 'X', 'mm', $secure), 'local' => false];
    }

    /** تگ <img> آمادهٔ نمایش (آواتار محلی یا گراواتار) */
    public static function html(int $uid, string $mail = '', int $size = 96, string $alt = ''): string
    {
        $resolved = self::resolve($uid, $mail, $size);
        $alt = $alt !== '' ? $alt : 'آواتار کاربر';
        $e = static fn ($v): string => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');

        return '<img src="' . $e($resolved['url']) . '" alt="' . $e($alt) . '" width="' . (int) $size . '" height="' . (int) $size . '" loading="lazy" decoding="async">';
    }

    // ------------------------------------------------------------------
    //  ذخیره‌سازی
    // ------------------------------------------------------------------

    /** نام فایل آواتار فعلی کاربر ('' در نبود) */
    public static function fileOf(int $uid): string
    {
        if ($uid < 1) {
            return '';
        }

        if (!array_key_exists($uid, self::$cache)) {
            $row = null;

            try {
                $db = Db::get();
                $row = $db->fetchRow(
                    $db->select(self::FILE_COLUMN)->from('table.siteprofile')->where('uid = ?', $uid)->limit(1)
                );
            } catch (\Throwable) {
                // جدول یا ستون هنوز ساخته نشده
            }

            $file = (string) ($row[self::FILE_COLUMN] ?? '');

            // صحت وجود فیزیکی فایل — رکورد بدون فایل (مثلاً حذف دستی) بی‌اعتبار است
            if ($file !== '' && !is_file(self::dir() . '/' . $file)) {
                $file = '';
            }

            self::$cache[$uid] = $file;
        }

        return self::$cache[$uid];
    }

    /**
     * ذخیرهٔ رکورد فایل آواتار (بدون دستکاری فایل‌ها)
     */
    private static function record(int $uid, string $file): void
    {
        Meta::save($uid, [self::FILE_COLUMN => $file]);
        self::$cache[$uid] = $file;
    }

    /**
     * ساخت پوشهٔ avatars در usr/uploads (در فعال‌سازی و پیش از هر آپلود)
     *
     * پوشه با یک index.html خالی (ضد فهرست‌کردن) و htaccess برای مهار
     * اجرای اسکریپت‌ها ایمن می‌شود.
     */
    public static function ensureDir(): bool
    {
        $dir = self::dir();

        if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
            return false;
        }

        $index = $dir . '/index.html';
        if (!is_file($index)) {
            @file_put_contents($index, '');
        }

        $htaccess = $dir . '/.htaccess';
        if (!is_file($htaccess)) {
            @file_put_contents(
                $htaccess,
                "# SiteProfile local avatars\n"
                . "Options -Indexes\n"
                . "<IfModule mod_php.c>\nphp_flag engine off\n</IfModule>\n"
                . "<IfModule mod_php7.c>\nphp_flag engine off\n</IfModule>\n"
                . "<FilesMatch \"\\.(php|phtml|phar|php[0-9]|pht|cgi|pl|py|sh|shtml)$\">\n"
                . "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n"
                . "<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n"
                . "</FilesMatch>\n"
            );
        }

        return true;
    }

    /**
     * اعتبارسنجی و ذخیرهٔ آواتار بارگذاری‌شده
     *
     * @param array $file عضو $_FILES (مثلاً $_FILES['avatar'])
     * @return array{ok: bool, error?: string, file?: string}
     */
    public static function save(int $uid, array $file): array
    {
        if ($uid < 1) {
            return ['ok' => false, 'error' => 'کاربر معتبر نیست.'];
        }

        if (!self::enabled()) {
            return ['ok' => false, 'error' => 'قابلیت آواتار محلی توسط مدیر سایت خاموش شده است.'];
        }

        if (!self::ensureDir()) {
            return ['ok' => false, 'error' => 'پوشهٔ ذخیرهٔ آواتارها روی سرور قابل نوشتن نیست.'];
        }

        // خطاهای خودِ PHP در بارگذاری
        $errorCode = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($errorCode !== UPLOAD_ERR_OK) {
            return ['ok' => false, 'error' => self::uploadError($errorCode)];
        }

        $tmp = (string) ($file['tmp_name'] ?? '');
        if ($tmp === '' || !is_uploaded_file($tmp)) {
            return ['ok' => false, 'error' => 'فایل بارگذاری‌شده معتبر نیست.'];
        }

        // حجم فایل
        $bytes = (int) ($file['size'] ?? 0);
        $min = self::minKB() * 1024;
        $max = self::maxKB() * 1024;

        if ($bytes < 1) {
            return ['ok' => false, 'error' => 'فایلی برای بارگذاری انتخاب نشده است.'];
        }

        if ($max > 0 && $bytes > $max) {
            return ['ok' => false, 'error' => sprintf(
                'حجم تصویر بیش از حد مجاز است (حداکثر %s کیلوبایت).',
                Jalali::digits((string) self::maxKB())
            )];
        }

        if ($min > 0 && $bytes < $min) {
            return ['ok' => false, 'error' => sprintf(
                'حجم تصویر کمتر از حد مجاز است (حداقل %s کیلوبایت).',
                Jalali::digits((string) self::minKB())
            )];
        }

        // فرمت واقعی فایل (نه پسوند)
        $info = @getimagesize($tmp);
        if ($info === false) {
            return ['ok' => false, 'error' => 'فایل انتخاب‌شده یک تصویر معتبر نیست.'];
        }

        [$width, $height] = $info;
        $mime = strtolower((string) ($info['mime'] ?? ''));

        $format = null;
        foreach (self::allowedFormats() as $key => $definition) {
            if (in_array($mime, $definition['mime'], true)) {
                $format = $key;
                break;
            }
        }

        if ($format === null) {
            return ['ok' => false, 'error' => sprintf(
                'این فرمت پذیرفته نمی‌شود؛ فرمت‌های مجاز: %s.',
                self::formatLabel()
            )];
        }

        if ($width < 1 || $height < 1 || $width > self::MAX_SOURCE_DIM || $height > self::MAX_SOURCE_DIM) {
            return ['ok' => false, 'error' => sprintf(
                'ابعاد تصویر باید بین ۱ و %s پیکسل باشد.',
                Jalali::digits((string) self::MAX_SOURCE_DIM)
            )];
        }

        $size = self::size();
        if ($width < $size || $height < $size) {
            return ['ok' => false, 'error' => sprintf(
                'تصویر باید حداقل %s×%s پیکسل باشد؛ تصویر شما %s×%s پیکسل است.',
                Jalali::digits((string) $size),
                Jalali::digits((string) $size),
                Jalali::digits((string) $width),
                Jalali::digits((string) $height)
            )];
        }

        // پردازش با GD و ذخیره
        try {
            $stored = self::process($tmp, $format, $uid);
        } catch (\Throwable $e) {
            return ['ok' => false, 'error' => 'پردازش تصویر روی سرور ممکن نشد: ' . $e->getMessage()];
        }

        if ($stored === null) {
            return ['ok' => false, 'error' => 'پردازش تصویر ممکن نشد؛ فرمت دیگری (مثلاً JPG یا PNG) را امتحان کنید.'];
        }

        // حذف فایل قبلی و ثبت فایل جدید
        self::unlinkOld($uid);
        self::record($uid, $stored);

        return ['ok' => true, 'file' => $stored];
    }

    /**
     * حذف آواتار محلی کاربر (بازگشت به گراواتار)
     */
    public static function remove(int $uid): bool
    {
        if ($uid < 1) {
            return false;
        }

        self::unlinkOld($uid);
        self::record($uid, '');

        return true;
    }

    /**
     * خواندن تصویر ورودی، برش مربع مرکزی و تبدیل به WebP/PNG
     */
    private static function process(string $tmp, string $format, int $uid): ?string
    {
        $size = self::size();

        $source = match ($format) {
            'jpg'  => @imagecreatefromjpeg($tmp),
            'png'  => @imagecreatefrompng($tmp),
            'webp' => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($tmp) : false,
            'gif'  => @imagecreatefromgif($tmp),
            default => false,
        };

        if ($source === false) {
            return null;
        }

        // برش مربع مرکزی به ابعاد هدف
        $srcW = imagesx($source);
        $srcH = imagesy($source);
        $crop = min($srcW, $srcH);
        $srcX = (int) (($srcW - $crop) / 2);
        $srcY = (int) (($srcH - $crop) / 2);

        $target = imagecreatetruecolor($size, $size);

        // پس‌زمینهٔ شفاف برای PNG با شفافیت
        imagealphablending($target, false);
        imagesavealpha($target, true);
        $transparent = imagecolorallocatealpha($target, 0, 0, 0, 127);
        imagefilledrectangle($target, 0, 0, $size, $size, $transparent);

        imagecopyresampled($target, $source, 0, 0, $srcX, $srcY, $size, $size, $crop, $crop);
        imagedestroy($source);

        // نام فایل یکتا + کش‌شکن (بازگذاری آواتار = نشانی تازه)
        $name = 'u' . $uid . '-' . bin2hex(random_bytes(4));
        $dir = self::dir();
        $stored = null;

        if (function_exists('imagewebp')) {
            $path = $dir . '/' . $name . '.webp';
            if (@imagewebp($target, $path, self::WEBP_QUALITY)) {
                $stored = $name . '.webp';
            }
        }

        if ($stored === null) {
            // سرور بدون پشتیبانی WebP — فallback با PNG
            $path = $dir . '/' . $name . '.png';
            if (@imagepng($target, $path, 6)) {
                $stored = $name . '.png';
            }
        }

        imagedestroy($target);

        return $stored;
    }

    /** حذف امن فایل آواتار فعلی کاربر */
    private static function unlinkOld(int $uid): void
    {
        $current = self::fileOf($uid);

        if ($current !== '' && preg_match('/^u\d+-[a-f0-9]{8}\.(webp|png)$/i', $current)) {
            @unlink(self::dir() . '/' . $current);
        }
    }

    /** پیام فارسی خطاهای بارگذاری PHP */
    private static function uploadError(int $code): string
    {
        return match ($code) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'حجم فایل بیش از سقف مجاز سرور است.',
            UPLOAD_ERR_NO_FILE => 'فایلی برای بارگذاری انتخاب نشده است.',
            UPLOAD_ERR_PARTIAL => 'بارگذاری فایل ناتمام ماند؛ دوباره تلاش کنید.',
            default => 'خطا در بارگذاری فایل؛ دوباره تلاش کنید.',
        };
    }

    // ------------------------------------------------------------------
    //  همگام‌سازی نمایش آواتار در افزونهٔ انجمن
    // ------------------------------------------------------------------

    /**
     * نگاشت md5(ایمیل) => نشانی آواتار محلی برای تعویض گراواتار در صفحات انجمن
     *
     * افزونهٔ Forum آواتار را از گراواتار (بر پایهٔ ایمیل) می‌سازد؛ این نگاشت
     * به اسکریپت سبکی که در صفحات انجمن تزریق می‌شود اجازه می‌دهد تصویر
     * کاربران دارای آواتار محلی، بدون دست‌بردن به افزونهٔ انجمن، جایگزین شود.
     *
     * @return array<string, string>
     */
    public static function forumSwapMap(): array
    {
        if (!self::enabled() || Plugin::settings()['forumSync'] !== '1' || !ForumSync::active()) {
            return [];
        }

        static $map = null;
        if ($map !== null) {
            return $map;
        }

        $map = [];

        try {
            $db = Db::get();
            $rows = $db->fetchAll(
                $db->select('u.uid', 'u.mail', 's.avatar_file')
                    ->from('table.users AS u')
                    ->join('table.siteprofile AS s', 's.uid = u.uid', Db::LEFT_JOIN)
                    ->where("s.avatar_file IS NOT NULL AND s.avatar_file <> ''")
                    ->limit(self::SWAP_MAP_LIMIT)
            );

            $dir = self::dir();
            $base = self::urlBase();

            foreach ($rows as $row) {
                $mail = strtolower(trim((string) $row['mail']));
                $file = (string) $row['avatar_file'];

                if ($mail === '' || $file === '' || !is_file($dir . '/' . $file)) {
                    continue;
                }

                $map[md5($mail)] = $base . '/' . rawurlencode($file);
            }
        } catch (\Throwable) {
            // انجمن یا جدول در دسترس نیست
        }

        return $map;
    }

    /**
     * اسکریپت تعویض آواتار در صفحات انجمن
     *
     * پیش از آنکه اسکریپت اصلی انجمن (که در پانوشت صفحه با defer بار
     * می‌شود) شنوندهٔ خطای خود را ثبت کند، این اسکریپت در سربرگ تزریق
     * می‌شود؛ بنابراین نخستین شنوندهٔ ماست و درخواست‌های گراواتارِ کاربران
     * دارای آواتار محلی را پیش از خطا تصاحب می‌کند.
     */
    public static function forumSwapScript(): string
    {
        $map = self::forumSwapMap();

        if ($map === []) {
            return '';
        }

        $json = json_encode($map, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

        if (!is_string($json)) {
            return '';
        }

        return '<script data-siteprofile-avatars>(function(){'
            . 'var MAP=' . $json . ';'
            // هش گراواتار از نشانی تصویر استخراج می‌شود
            . 'function hash(img){var m=/\\/([a-f0-9]{32})\\?/.exec(img.getAttribute("src")||"");return m?m[1]:"";}'
            . 'function swap(img){var h=hash(img);if(!h||!MAP[h]){return false;}'
            . 'img.setAttribute("src",MAP[h]);img.removeAttribute("onerror");return true;}'
            // تعویض پیش‌دستانه در لحظهٔ خطا (پیش از شنوندهٔ انجمن که تصویر را حذف می‌کند)
            . 'document.addEventListener("error",function(ev){'
            . 'var t=ev.target;'
            . 'if(t&&t.tagName==="IMG"&&t.classList&&t.classList.contains("qa-grava")&&swap(t)){ev.stopImmediatePropagation();}'
            . '},true);'
            // پیمایش اولیه پس از آماده‌شدن DOM
            . 'function scan(){var list=document.querySelectorAll("img.qa-grava");'
            . 'for(var i=0;i<list.length;i++){swap(list[i]);}}'
            . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",scan);}'
            . 'else{scan();}'
            // درخت‌ناظر برای گره‌های تازه (مثلاً پیام‌های زنده)
            . 'if(window.MutationObserver){new MutationObserver(function(){scan();})'
            . '.observe(document.documentElement,{childList:true,subtree:true});}'
            . '})();</script>';
    }
}
