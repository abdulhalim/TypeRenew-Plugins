<?php
declare(strict_types=1);

namespace TypechoPlugin\SiteProfile;

use Typecho\Request;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * باکس نویسنده (Author Box)
 *
 * این باکس اطلاعات نویسندهٔ مطلب (آواتار، نام، بیوگرافی کوتاه، شبکه‌های
 * اجتماعی و پیوند به صفحهٔ اختصاصی‌اش) در یک کارت خوش‌ساخت نشان می‌دهد.
 *
 * دو راه استفاده:
 *
 * ۱) درج خودکار در انتهای هر نوشته (تنظیم «باکس نویسنده» در تنظیمات افزونه)
 *
 * ۲) فراخوانی دستی در post.php پوسته:
 *
 *    \TypechoPlugin\SiteProfile\Box::render($this->author->uid);
 *
 *    یا برای گرفتن خروجی رشته‌ای:
 *
 *    $html = \TypechoPlugin\SiteProfile\Box::html($this->author->uid);
 *
 * ورودی می‌تواند شناسهٔ کاربر (int) یا هر شیء/سطری باشد که خاصیت uid
 * داشته باشد (مانند $this->author در حلقهٔ مطالب).
 *
 * @package SiteProfile
 * @since 2.0.0
 */
class Box
{
    /** جلوگیری از چاپ دوبارهٔ CSS در همان درخواست */
    private static bool $styleEmitted = false;

    /**
     * چاپ مستقیم باکس نویسنده
     *
     * @param int|object $author شناسهٔ کاربر یا شیء دارای uid
     */
    public static function render($author): void
    {
        echo self::html($author);
    }

    /**
     * ساخت HTML باکس نویسنده
     *
     * @param int|object $author شناسهٔ کاربر یا شیء دارای uid
     */
    public static function html($author): string
    {
        $uid = self::resolveUid($author);

        if ($uid <= 0) {
            return '';
        }

        $data = Meta::authorData($uid);

        if ($data === null) {
            return '';
        }

        $e = static fn ($value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');

        $avatarUrl = $data['avatarUrl'];
        $memberUrl = Plugin::memberUrl($uid);
        $profileEnabled = Plugin::settings()['publicProfile'] === '1';

        $links = '';

        if ($data['url'] !== '') {
            $links .= '<a class="sp-ab-link" href="' . $e($data['url']) . '" target="_blank" rel="noopener nofollow"'
                . ' title="' . $e('وب‌سایت') . '" aria-label="' . $e('وب‌سایت') . '">'
                . self::icon('website') . '</a>';
        }

        foreach (Meta::SOCIALS as $key => $definition) {
            $url = Meta::socialUrl($key, (string) ($data['socials'][$key] ?? ''));

            if ($url === '') {
                continue;
            }

            $links .= '<a class="sp-ab-link" href="' . $e($url) . '" target="_blank" rel="noopener nofollow"'
                . ' title="' . $e($definition['label']) . '" aria-label="' . $e($definition['label']) . '">'
                . self::icon($key) . '</a>';
        }

        $style = self::$styleEmitted ? '' : self::style();
        self::$styleEmitted = true;

        $profileLink = $profileEnabled
            ? '<a class="sp-ab-profile" href="' . $e($memberUrl) . '">مشاهدهٔ پروفایل ←</a>'
            : '';

        $bio = $data['bio'] !== ''
            ? '<p class="sp-ab-bio">' . $e($data['bio']) . '</p>'
            : '';

        return <<<HTML
{$style}<aside class="sp-scope sp-authorbox" itemscope itemtype="https://schema.org/Person">
    <div class="sp-authorbox-inner">
        <img class="sp-ab-avatar" src="{$e($avatarUrl)}" alt="{$e($data['screenName'])}" width="64" height="64" itemprop="image">
        <div class="sp-ab-main">
            <div class="sp-ab-head">
                <span class="sp-ab-title">دربارهٔ نویسنده</span>
                <span class="sp-ab-badge">{$e(Meta::groupLabel($data['group']))}</span>
            </div>
            <div class="sp-ab-name" itemprop="name">{$e($data['screenName'])}</div>
            {$bio}
            <div class="sp-ab-meta">
                <span itemprop="articleCount">{$e(Jalali::digits((string) $data['postsNum']))} نوشته</span>
                <span class="sp-ab-dot">•</span>
                <span>{$e(Jalali::digits((string) $data['commentsNum']))} نظر</span>
            </div>
            <div class="sp-ab-links">
                {$links}
                {$profileLink}
            </div>
        </div>
    </div>
</aside>
HTML;
    }

    /**
     * استخراج شناسهٔ کاربر از ورودی (int یا شیء دارای uid)
     */
    private static function resolveUid($author): int
    {
        if (is_int($author) || (is_string($author) && ctype_digit($author))) {
            return (int) $author;
        }

        if (is_object($author)) {
            try {
                return (int) $author->uid;
            } catch (\Throwable) {
                return 0;
            }
        }

        if (is_array($author) && isset($author['uid'])) {
            return (int) $author['uid'];
        }

        return 0;
    }

    private static function isSecure(): bool
    {
        try {
            return (bool) Request::getInstance()->isSecure();
        } catch (\Throwable) {
            return false;
        }
    }

    /**
     * آیکن‌های SVG سبک خطی (هماهنگ با ظاهر پوسته‌ها)
     */
    public static function icon(string $key): string
    {
        $start = '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">';
        $end = '</svg>';

        return match ($key) {
            'website' => $start
                . '<circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line>'
                . '<path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>' . $end,
            'telegram' => $start
                . '<line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>' . $end,
            'instagram' => $start
                . '<rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>'
                . '<path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>'
                . '<line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>' . $end,
            'twitter' => $start . '<path d="M4 4l16 16M20 4L4 20"></path>' . $end,
            'github' => '<svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.11.79-.25.79-.55 0-.27-.01-1.17-.02-2.12-3.2.7-3.88-1.36-3.88-1.36-.52-1.33-1.28-1.68-1.28-1.68-1.04-.71.08-.7.08-.7 1.15.08 1.76 1.19 1.76 1.19 1.03 1.75 2.69 1.25 3.35.95.1-.74.4-1.25.72-1.54-2.55-.29-5.24-1.28-5.24-5.68 0-1.26.45-2.28 1.19-3.09-.12-.29-.52-1.46.11-3.05 0 0 .97-.31 3.18 1.18a11.1 11.1 0 0 1 5.8 0c2.2-1.49 3.17-1.18 3.17-1.18.63 1.59.23 2.76.11 3.05.74.81 1.19 1.83 1.19 3.09 0 4.42-2.7 5.39-5.27 5.67.41.36.78 1.06.78 2.14 0 1.55-.01 2.79-.01 3.17 0 .31.21.67.8.55A11.52 11.52 0 0 0 23.5 12C23.5 5.65 18.35.5 12 .5z"></path></svg>',
            'linkedin' => $start
                . '<path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4V8h4v2a6 6 0 0 1 2-2z"></path>'
                . '<rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle>' . $end,
            'youtube' => $start
                . '<path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z"></path>'
                . '<polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"></polygon>' . $end,
            'calendar' => $start
                . '<rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>'
                . '<line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line>'
                . '<line x1="3" y1="10" x2="21" y2="10"></line>' . $end,
            'login' => $start
                . '<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path>'
                . '<polyline points="10 17 15 12 10 7"></polyline><line x1="15" y1="12" x2="3" y2="12"></line>' . $end,
            'user' => $start
                . '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle>' . $end,
            'dashboard' => $start
                . '<rect x="3" y="3" width="7" height="9" rx="1.5"></rect>'
                . '<rect x="14" y="3" width="7" height="5" rx="1.5"></rect>'
                . '<rect x="14" y="12" width="7" height="9" rx="1.5"></rect>'
                . '<rect x="3" y="16" width="7" height="5" rx="1.5"></rect>' . $end,
            'page' => $start
                . '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>'
                . '<polyline points="14 2 14 8 20 8"></polyline>' . $end,
            'users' => $start
                . '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>'
                . '<circle cx="9" cy="7" r="4"></circle>'
                . '<path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>'
                . '<path d="M16 3.13a4 4 0 0 1 0 7.75"></path>' . $end,
            'settings' => $start
                . '<circle cx="12" cy="12" r="3"></circle>'
                . '<path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path>' . $end,
            'logout' => $start
                . '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>'
                . '<polyline points="16 17 21 12 16 7"></polyline>'
                . '<line x1="21" y1="12" x2="9" y2="12"></line>' . $end,
            'camera' => $start
                . '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path>'
                . '<circle cx="12" cy="13" r="4"></circle>' . $end,
            'upload' => $start
                . '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>'
                . '<polyline points="17 8 12 3 7 8"></polyline>'
                . '<line x1="12" y1="3" x2="12" y2="15"></line>' . $end,
            'edit' => $start
                . '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>'
                . '<path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>' . $end,
            'post' => $start
                . '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>'
                . '<polyline points="14 2 14 8 20 8"></polyline>' . $end,
            'comment' => $start
                . '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>' . $end,
            'forum' => $start
                . '<path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3z"></path>'
                . '<path d="M7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path>' . $end,
            default => '',
        };
    }

    /**
     * CSS باکس (توکن‌های رنگی هماهنگ با پوسته + حالت شب/روز)
     */
    private static function style(): string
    {
        return <<<'CSS'
<style>
    .sp-scope.sp-authorbox {
        direction: rtl;
        text-align: right;
        margin: 34px 0 8px;

        --sp-card: var(--surface, var(--bg-primary, #ffffff));
        --sp-ink: var(--ink, var(--text-primary, #1f2937));
        --sp-ink-mute: var(--ink-soft, var(--text-secondary, #6b7280));
        --sp-line: var(--line, var(--border-color, #e5e7eb));
        --sp-accent: var(--primary, var(--accent-color, #2563eb));
        --sp-accent-soft: var(--primary-soft, rgba(37, 99, 235, 0.08));
        --sp-radius: var(--radius-lg, 14px);
        --sp-shadow: var(--shadow-md, 0 14px 34px -16px rgba(15, 23, 42, 0.18));
    }

    html[data-theme='dark'] .sp-scope.sp-authorbox,
    html.dark .sp-scope.sp-authorbox,
    body.dark .sp-scope.sp-authorbox {
        --sp-card: var(--surface, var(--bg-primary, #131a23));
        --sp-ink: var(--ink, var(--text-primary, #e6edf3));
        --sp-ink-mute: var(--ink-soft, var(--text-secondary, #8b98a5));
        --sp-line: var(--line, var(--border-color, #243040));
        --sp-accent: var(--primary, var(--accent-color, #6ea8fe));
        --sp-accent-soft: var(--primary-soft, rgba(59, 130, 246, 0.14));
        --sp-shadow: var(--shadow-md, 0 14px 34px -16px rgba(0, 0, 0, 0.55));
    }

    .sp-authorbox .sp-authorbox-inner {
        display: flex;
        gap: 16px;
        padding: 20px 22px;
        background: var(--sp-card);
        border: 1px solid var(--sp-line);
        border-radius: var(--sp-radius);
        box-shadow: var(--sp-shadow);
        color: var(--sp-ink);
        line-height: 1.9;
    }

    .sp-authorbox .sp-ab-avatar {
        width: 64px;
        height: 64px;
        border-radius: 50%;
        flex: none;
        border: 3px solid var(--sp-card);
        box-shadow: var(--sp-shadow);
        background: var(--sp-card);
    }

    .sp-authorbox .sp-ab-main { min-width: 0; flex: 1; }

    .sp-authorbox .sp-ab-head {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 2px;
    }

    .sp-authorbox .sp-ab-title {
        font-size: 12px;
        font-weight: 700;
        letter-spacing: .2px;
        color: var(--sp-ink-mute);
    }

    .sp-authorbox .sp-ab-badge {
        font-size: 11px;
        padding: 1px 10px;
        border-radius: 999px;
        background: var(--sp-accent-soft);
        color: var(--sp-accent);
    }

    .sp-authorbox .sp-ab-name {
        font-size: 16.5px;
        font-weight: 800;
        color: var(--sp-ink);
    }

    .sp-authorbox .sp-ab-bio {
        margin: 6px 0 4px;
        font-size: 13.5px;
        color: var(--sp-ink-mute);
    }

    .sp-authorbox .sp-ab-meta {
        font-size: 12.5px;
        color: var(--sp-ink-mute);
    }

    .sp-authorbox .sp-ab-dot { opacity: .5; margin: 0 6px; }

    .sp-authorbox .sp-ab-links {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 8px;
        margin-top: 10px;
    }

    .sp-authorbox .sp-ab-link {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 34px;
        height: 34px;
        border-radius: 50%;
        border: 1px solid var(--sp-line);
        color: var(--sp-ink-mute);
        transition: color .15s, border-color .15s, background .15s;
    }

    .sp-authorbox .sp-ab-link:hover {
        color: var(--sp-accent);
        border-color: var(--sp-accent);
        background: var(--sp-accent-soft);
    }

    .sp-authorbox .sp-ab-profile {
        margin-inline-start: auto;
        font-size: 13px;
        font-weight: 700;
        color: var(--sp-accent);
        text-decoration: none;
    }

    .sp-authorbox .sp-ab-profile:hover { text-decoration: underline; }

    @media (max-width: 480px) {
        .sp-authorbox .sp-authorbox-inner { padding: 16px; }
        .sp-authorbox .sp-ab-profile { margin-inline-start: 0; width: 100%; }
    }
</style>
CSS;
    }
}
