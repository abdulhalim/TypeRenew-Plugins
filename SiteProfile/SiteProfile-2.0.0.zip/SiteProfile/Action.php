<?php
declare(strict_types=1);

namespace TypechoPlugin\SiteProfile;

use Typecho\Common;
use Typecho\Cookie;
use Typecho\Request as HttpRequest;
use Typecho\Router;
use Typecho\Router\Exception as RouterException;
use Typecho\Validate;
use Utils\Comment;
use Utils\Password;
use Widget\Archive;
use Widget\Users\EditTrait;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * ویجت صفحه‌های پروفایل در محیط سایت
 *
 * دو مسیر به این ویجت نگاشت می‌شوند:
 *
 * - /profile        → page()   : ویرایش پروفایل خود کاربر (نیازمند ورود)
 * - /profile/{uid}  → member() : صفحهٔ عمومی یک کاربر (در دسترس همه)
 *
 * این ویجت از Widget\Archive ارث‌بری می‌کند تا صفحه‌ها درون چیدمان خودِ
 * پوسته سایت (هدر، فوتر، فونت و حالت روز/شب پوسته) رندر شوند؛ اما
 * برخلاف آرشیوهای واقعی، هیچ کوئری محتوایی اجرا نمی‌شود.
 *
 * درخواست‌های GET صفحه‌ها را در قالب پوسته نمایش می‌دهند و درخواست‌های
 * POST اطلاعات پروفایل، شبکه‌های اجتماعی، رمز عبور یا آواتار کاربر را
 * به‌روزرسانی می‌کنند (الگوی Post/Redirect/Get).
 */
class Action extends Archive
{
    use EditTrait;

    /** عنوان صفحه ویرایش پروفایل (برای زبانه مرورگر و متادیتاها) */
    private const PAGE_TITLE = 'پروفایل کاربری';

    /**
     * آماده‌سازی ویجت
     *
     * به‌جای execute والد (که کل منطق کوئری محتوای آرشیو را اجرا می‌کند)
     * تنها محیط حداقلی لازم برای رندر در قالب پوسته فراهم می‌شود: فیلدهای
     * سربرگ (فید، اسلاگ، عنوان و...) و علامت‌گذاری نوع آرشیو. الزام ورود
     * در page() انجام می‌شود چون صفحهٔ عمومی کاربر (member) بدون ورود هم
     * باید باز باشد.
     */
    public function execute()
    {
        // فیلدهایی که Widget\Archive::header() برای خروجی سربرگ نیاز دارد
        $this->setArchiveSlug('');
        $this->setArchiveType('profile');
        $this->setArchiveTitle(self::PAGE_TITLE);
        $this->setArchiveUrl(Plugin::profileUrl());
        $this->setArchiveFeedUrl((string) $this->options->feedUrl);
        $this->setArchiveFeedRssUrl((string) $this->options->feedRssUrl);
        $this->setArchiveFeedAtomUrl((string) $this->options->feedAtomUrl);
        $this->setArchiveDescription((string) $this->options->description);
        $this->setArchiveKeywords((string) $this->options->keywords);

        // محافظ تداخل با ویجت feedback هسته:
        //
        // مسیر «feedback» با الگوی حریص خود ([permalink:string]/[type:alpha])
        // پیش از مسیرهای افزونه‌ها، نشانی‌های دوبخشی (مانند /profile/5) را
        // امتحان می‌کند و درون Feedback::action این ویجت با مسیر ناقص
        // «/profile» از طریق Router::match ساخته و در کش ویجت‌ها نگه داشته
        // می‌شود؛ سپس مسیر واقعی صفحهٔ عمومی همان نمونهٔ بی‌پارامتر را
        // بازمی‌خواند. اگر مسیر واقعی درخواست با مسیر این ویجت نخواند،
        // خطای ۴۰۴ می‌دهیم تا هسته همان نمونهٔ اشتباه را از کش حذف کند و
        // نمونهٔ درست (با پارامترهای مسیر) ساخته شود.
        $pathInfo = (string) HttpRequest::getInstance()->getPathInfo();
        if (
            $pathInfo !== ''
            && (string) $this->parameter->type === Plugin::ROUTE_NAME
            && rtrim($pathInfo, '/') !== rtrim(Plugin::ROUTE_PATH, '/')
        ) {
            throw new RouterException('Not Found', 404);
        }
    }

    /**
     * نقطه ورود مسیر /profile — ویرایش پروفایل خود کاربر
     */
    public function page(): void
    {
        if (!$this->user->hasLogin()) {
            $this->response->redirect(
                $this->options->loginUrl . '?referer=' . urlencode($this->request->makeUriByRequest())
            );
        }

        // تا اعتبارسنج‌های یکتایی، رکورد خود کاربر را مستثنا کنند
        $this->request->setParam('uid', $this->user->uid);

        if ($this->request->isPost()) {
            // محافظ بارگذاری سنگین‌تر از سقف سرور (بدنهٔ multipart دور ریخته می‌شود)
            if (empty($_POST) && empty($_FILES) && (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
                Plugin::flash('error', 'حجم فایل ارسالی بیش از سقف مجاز سرور است؛ فایل کوچک‌تری انتخاب کنید.');
                $this->response->redirect(Plugin::profileUrl() . '#sp-panel-avatar');
            }

            $this->security->protect();

            $this->on($this->request->is('do=profile'))->updateProfile();
            $this->on($this->request->is('do=social'))->updateSocial();
            $this->on($this->request->is('do=password'))->updatePassword();
            $this->on($this->request->is('do=avatar'))->uploadAvatar();
            $this->on($this->request->is('do=avatarDelete'))->deleteAvatar();

            Plugin::flash('error', 'درخواست نامعتبر است؛ لطفاً دوباره تلاش کنید.');
            $this->response->redirect(Plugin::profileUrl());
        }

        $this->renderProfile();
    }

    /**
     * نقطه ورود مسیر /profile/{uid} — صفحهٔ عمومی کاربر
     */
    public function member(): void
    {
        // پارامترهای مسیر (مانند uid) از طریق request در دسترس‌اند (الگوی authorHandle هسته)
        $uid = (int) $this->request->filter('int')->get('uid', 0);

        if (Plugin::settings()['publicProfile'] !== '1' || $uid <= 0) {
            $this->renderNotFound();
            return;
        }

        $author = Meta::authorData($uid);

        if ($author === null) {
            $this->renderNotFound();
            return;
        }

        $this->setArchiveTitle('پروفایل ' . $author['screenName']);
        $this->setArchiveSlug((string) $uid);
        $this->setArchiveUrl(Plugin::memberUrl($uid));

        $showLastLogin = Plugin::settings()['showLastLogin'] === '1';
        $perPage = max(1, (int) Plugin::settings()['perPage']);

        // تب فعال و شمارهٔ صفحه
        $tab = (string) $this->request->get('tab', 'posts');
        if (!in_array($tab, ['posts', 'comments', 'forum'], true)) {
            $tab = 'posts';
        }

        $forumActive = Plugin::settings()['forumSync'] === '1' && ForumSync::active();

        if ($tab === 'forum' && !$forumActive) {
            $tab = 'posts';
        }

        $page = max(1, (int) $this->request->filter('int')->get('page', 1));

        // ---------------- تب نوشته‌ها ----------------
        $posts = [];
        $postsTotal = (int) $author['postsNum'];
        $postsPages = max(1, (int) ceil($postsTotal / $perPage));

        if ($tab === 'posts' && $postsTotal > 0) {
            $page = min($page, $postsPages);

            foreach ($this->fetchRaw(sprintf(
                'SELECT cid, title, slug, type, created FROM %scontents '
                . "WHERE authorId = %d AND type = 'post' AND status = 'publish' "
                . 'ORDER BY created DESC LIMIT %d OFFSET %d',
                $this->db->getPrefix(),
                $uid,
                $perPage,
                ($page - 1) * $perPage
            )) as $row) {
                $row['permalink'] = Router::url(
                    $row['type'] === 'page' ? 'page' : 'post',
                    ['cid' => (int) $row['cid'], 'slug' => (string) $row['slug']],
                    $this->options->index
                );
                $posts[] = $row;
            }
        }

        // ---------------- تب نظرات ----------------
        $comments = [];
        $commentsTotal = (int) $author['commentsNum'];
        $commentsPages = max(1, (int) ceil($commentsTotal / $perPage));

        if ($tab === 'comments' && $commentsTotal > 0) {
            $page = min($page, $commentsPages);

            foreach ($this->fetchRaw(sprintf(
                'SELECT c.coid, c.text, c.created, ct.title, ct.slug, ct.type AS postType, ct.cid AS postCid '
                . 'FROM %scomments AS c INNER JOIN %scontents AS ct ON ct.cid = c.cid '
                . "WHERE c.authorId = %d AND c.status = 'approved' AND c.type = 'comment' "
                . "AND ct.status = 'publish' AND ct.type IN ('post', 'page') "
                . 'ORDER BY c.created DESC LIMIT %d OFFSET %d',
                $this->db->getPrefix(),
                $this->db->getPrefix(),
                $uid,
                $perPage,
                ($page - 1) * $perPage
            )) as $row) {
                $row['permalink'] = Router::url(
                    $row['postType'] === 'page' ? 'page' : 'post',
                    ['cid' => (int) $row['postCid'], 'slug' => (string) $row['slug']],
                    $this->options->index
                );
                $comments[] = $row;
            }
        }

        // ---------------- تب پرسش و پاسخ انجمن ----------------
        $forum = null;
        $forumSub = (string) $this->request->get('ftab', 'questions');

        if (!in_array($forumSub, ['questions', 'answers'], true)) {
            $forumSub = 'questions';
        }

        if ($tab === 'forum') {
            $forum = ForumSync::memberForumData($uid, $forumSub, $page, $perPage);

            if ($forum === null) {
                $tab = 'posts';
            } else {
                $page = (int) $forum['page'];
            }
        }

        $this->renderInView('member', [
            'view'          => 'member',
            'pageTitle'     => 'پروفایل ' . $author['screenName'],
            'author'        => $author,
            'tab'           => $tab,
            'page'          => $page,
            'perPage'       => $perPage,
            'posts'         => $posts,
            'postsTotal'    => $postsTotal,
            'postsPages'    => $postsPages,
            'comments'      => $comments,
            'commentsTotal' => $commentsTotal,
            'commentsPages' => $commentsPages,
            'forumActive'   => $forumActive,
            'forum'         => $forum,
            'forumSub'      => $forumSub,
            'showLastLogin' => $showLastLogin,
            'isOwner'       => $this->user->hasLogin() && (int) $this->user->uid === $uid,
            'menuItems'     => $this->memberMenuItems($uid),
        ]);
    }

    /**
     * فهرست گزینه‌های منوی «دسترسی سریع» صفحهٔ عمومی
     *
     * همان منوی صفحهٔ ویرایش است؛ تنها تفاوت: وقتی بازدیدکننده خودش
     * صاحب همین صفحه است، گزینهٔ «صفحهٔ عمومی من» (که به همین نشانی
     * اشاره می‌کند) حذف می‌شود تا منو تکراری نشود.
     *
     * @param int $uid شناسهٔ صاحب صفحهٔ عمومی
     * @return array<int, array{label: string, url: string, icon: string, divider?: bool}>
     */
    private function memberMenuItems(int $uid): array
    {
        $menu = $this->quickMenu();

        if ($menu === [] || !$this->user->hasLogin() || (int) $this->user->uid !== $uid) {
            return $menu;
        }

        $selfUrl = Plugin::memberUrl($uid);
        $menu = array_values(array_filter(
            $menu,
            static fn (array $item): bool => $item['url'] !== $selfUrl
        ));

        // جداکننده‌ها را دوباره و فقط پیش از «خروج» می‌چینیم
        foreach ($menu as $i => $item) {
            unset($menu[$i]['divider']);
        }

        $count = count($menu);
        if ($count >= 2) {
            $menu[$count - 2]['divider'] = true;
        }

        return $menu;
    }

    /**
     * نمایش صفحه ویرایش پروفایل (تب‌ها)
     */
    private function renderProfile(): void
    {
        $row = $this->db->fetchRow(
            $this->db->select()->from('table.users')->where('uid = ?', $this->user->uid)->limit(1)
        );

        $meta = Meta::getRow((int) $this->user->uid);
        $mail = (string) ($row['mail'] ?? '');
        $uid = (int) $this->user->uid;
        $avatar = Avatar::resolve($uid, $mail, 96);

        $this->renderInView('card', [
            'view'        => 'card',
            'pageTitle'   => self::PAGE_TITLE,
            'uid'         => $uid,
            'userName'    => (string) ($row['name'] ?? ''),
            'screenName'  => (string) ($row['screenName'] ?? ''),
            'mail'        => $mail,
            'url'         => (string) ($row['url'] ?? ''),
            'bio'         => (string) $meta['bio'],
            'socials'     => $meta,
            'groupLabel'  => Meta::groupLabel((string) ($row['group'] ?? 'subscriber')),
            'memberUrl'   => Plugin::memberUrl($uid),
            'createdAt'   => (int) ($row['created'] ?? 0),
            'loggedAt'    => (int) ($row['logged'] ?? 0),
            'avatarUrl'   => $avatar['url'],
            'avatarLocal' => $avatar['local'],
            'avatarOn'    => Avatar::enabled(),
            'avatarMinKB' => Avatar::minKB(),
            'avatarMaxKB' => Avatar::maxKB(),
            'avatarSize'  => Avatar::size(),
            'avatarFormats' => Avatar::formatLabel(),
            'menuItems'   => $this->quickMenu(),
            'formAction'  => $this->security->getIndex(Plugin::ROUTE_PATH),
            'logoutUrl'   => $this->security->getIndex('/action/logout'),
            'minPassword' => Password::minLength(),
            'flash'       => Plugin::pullFlash(),
        ]);
    }

    /**
     * فهرست گزینه‌های منوی «دسترسی سریع» (بر اساس سطح دسترسی کاربر)
     *
     * کاربرانی که بر اساس تنظیمات افزونه به پنل مدیریت دسترسی دارند
     * (مثل مدیر و نویسندگان) پیوندهای مرتبط با پنل را می‌بینند؛ بقیه
     * فقط گزینه‌های عمومی (صفحهٔ عمومی و خروج) را می‌بینند.
     *
     * @return array<int, array{label: string, url: string, icon: string, divider?: bool}>
     */
    private function quickMenu(): array
    {
        if (!$this->user->hasLogin()) {
            return [];
        }

        $settings = Plugin::settings();
        $menu = [];

        // آیا این کاربر عملاً می‌تواند از پنل مدیریت استفاده کند؟
        // (با فعال‌بودن «بستن پنل»، فقط گروه‌های بالای آستانه؛ در غیر این
        // صورت پنل برای همه باز است و دسترسی‌ها را هسته تعیین می‌کند)
        $panelOpen = $settings['blockAdmin'] !== '1' || $this->user->pass($settings['minGroup'], true);

        if ($panelOpen) {
            $adminUrl = (string) $this->options->adminUrl;

            $menu[] = ['label' => 'بازگشت به پنل مدیریت', 'url' => Common::url('index.php', $adminUrl), 'icon' => 'dashboard'];

            if ($this->user->pass('contributor', true)) {
                $menu[] = ['label' => 'نوشتن مطلب جدید', 'url' => Common::url('write-post.php', $adminUrl), 'icon' => 'edit'];
                $menu[] = ['label' => 'مدیریت نوشته‌ها', 'url' => Common::url('manage-posts.php', $adminUrl), 'icon' => 'post'];
            }

            if ($this->user->pass('editor', true)) {
                $menu[] = ['label' => 'مدیریت نظرات', 'url' => Common::url('manage-comments.php', $adminUrl), 'icon' => 'comment'];
            }

            if ($this->user->pass('administrator', true)) {
                $menu[] = ['label' => 'برگهٔ جدید', 'url' => Common::url('write-page.php', $adminUrl), 'icon' => 'page'];
                $menu[] = ['label' => 'مدیریت کاربران', 'url' => Common::url('manage-users.php', $adminUrl), 'icon' => 'users'];
                $menu[] = ['label' => 'تنظیمات سایت', 'url' => Common::url('options-general.php', $adminUrl), 'icon' => 'settings'];
            }
        }

        // گزینه‌های عمومی برای همهٔ کاربران
        $menu[] = ['label' => 'صفحهٔ عمومی من', 'url' => Plugin::memberUrl((int) $this->user->uid), 'icon' => 'user'];

        // انجمن (فقط در صورت فعال‌بودن افزونهٔ Forum)
        $forumUrl = ForumSync::forumUrl();

        if ($forumUrl !== '') {
            $menu[] = ['label' => 'انجمن پرسش و پاسخ', 'url' => $forumUrl, 'icon' => 'forum'];
        }

        if ($menu !== []) {
            $menu[count($menu) - 1]['divider'] = true; // جداکننده پیش از خروج
        }

        $menu[] = ['label' => 'خروج از حساب', 'url' => $this->security->getIndex('/action/logout'), 'icon' => 'logout'];

        return $menu;
    }

    /**
     * رندر یک نمای در قالب پوسته (یا مستقل در نبود پوسته)
     *
     * اگر «ادغام با پوسته» فعال باشد و پوستهٔ فعال، سربرگ و پانوشت داشته
     * باشد، نتیجه میان header.php و footer.php خودِ پوسته رندر می‌شود
     * (و توابع functions.php پوسته، مطابق الگوی Widget\Archive::execute،
     * پیش از رندر بارگذاری می‌شوند). در غیر این صورت، پوستهٔ مستقلِ خودِ
     * افزونه به‌عنوان جایگزین نمایش داده می‌شود.
     *
     * @param string $view نام فایل نمای میانی در view/ (مثلاً 'card')
     * @param array  $vars متغیرهایی که در اختیار نما قرار می‌گیرند
     */
    private function renderInView(string $view, array $vars): void
    {
        $themeDir = (string) $this->getThemeDir();

        $embedTheme = Plugin::settings()['embedTheme'] === '1'
            && $themeDir !== ''
            && is_file($themeDir . 'header.php')
            && is_file($themeDir . 'footer.php');

        // بارگذاری توابع پوسته و themeInit (همان الگوی هسته)
        if ($embedTheme) {
            $functionsFile = $themeDir . 'functions.php';

            if (file_exists($functionsFile)) {
                require_once $functionsFile;

                if (function_exists('themeInit')) {
                    themeInit($this);
                }
            }
        }

        $vars += [
            'embedTheme' => $embedTheme,
            'siteTitle'  => (string) $this->options->title,
            'siteUrl'    => (string) $this->options->siteUrl,
            'logoutUrl'  => $this->security->getIndex('/action/logout'),
        ];

        // متغیر نمای میانی برای پوستهٔ مستقل (standalone.php)
        $vars['view'] = $vars['view'] ?? $view;

        extract($vars, EXTR_SKIP);

        if ($embedTheme) {
            $this->need('header.php');
            include __DIR__ . '/view/' . $view . '.php';
            $this->need('footer.php');
        } else {
            include __DIR__ . '/view/standalone.php';
        }
    }

    /**
     * نمایش خطای ۴۰۴ (کاربر یافت نشد / صفحه عمومی خاموش است)
     */
    private function renderNotFound(): void
    {
        $this->response->setStatus(404);
        $this->setArchiveTitle('کاربر یافت نشد');

        $this->renderInView('notfound', [
            'view'      => 'notfound',
            'pageTitle' => 'کاربر یافت نشد',
        ]);
    }

    /**
     * اجرای یک کوئری خام (فقط با مقادیر عددی امن interpolate شده)
     *
     * @return array<int, array<string, mixed>>
     */
    private function fetchRaw(string $sql): array
    {
        $rows = $this->db->fetchAll($sql);

        return is_array($rows) ? $rows : [];
    }

    /**
     * به‌روزرسانی اطلاعات پروفایل: نام مستعار، ایمیل و بیوگرافی کوتاه
     */
    private function updateProfile(): void
    {
        $data = $this->request->from('mail', 'screenName', 'bio');

        // نرمال‌سازی پیش از اعتبارسنجی (فیلدهای غایب = رشتهٔ خالی)
        $data['bio'] = trim((string) ($data['bio'] ?? ''));

        $validator = new Validate();
        $validator->addRule('screenName', 'xssCheck', 'در نام مستعار از کاراکترهای خاص استفاده نکنید');
        $validator->addRule('screenName', 'maxLength', 'نام مستعار حداکثر می‌تواند ۳۲ کاراکتر باشد', 32);
        $validator->addRule('screenName', [$this, 'screenNameExists'], 'این نام مستعار قبلاً توسط کاربر دیگری استفاده شده است');
        $validator->addRule('mail', 'required', 'نشانی ایمیل را وارد کنید');
        $validator->addRule('mail', 'email', 'فرمت نشانی ایمیل معتبر نیست');
        $validator->addRule('mail', 'maxLength', 'نشانی ایمیل حداکثر می‌تواند ۱۵۰ کاراکتر باشد', 150);
        $validator->addRule('mail', [$this, 'mailExists'], 'این نشانی ایمیل قبلاً توسط کاربر دیگری ثبت شده است');
        $validator->addRule('bio', 'xssCheck', 'در بیوگرافی از کاراکترهای خاص استفاده نکنید');
        $validator->addRule('bio', 'maxLength', sprintf('بیوگرافی حداکثر می‌تواند %s کاراکتر باشد', Jalali::digits((string) Meta::MAX_BIO)), Meta::MAX_BIO);

        if ($errors = $validator->run($data)) {
            Plugin::flash('error', implode(' — ', $errors));
            $this->response->redirect(Plugin::profileUrl() . '#sp-panel-profile');
        }

        // طبق تنظیم امنیتی، تغییر ایمیل نیازمند تأیید رمز عبور فعلی است
        $newMail = (string) ($data['mail'] ?? '');
        if (strcasecmp($newMail, (string) $this->user->mail) !== 0) {
            $currentPassword = (string) $this->request->get('currentPassword', '');

            if ($currentPassword === '') {
                Plugin::flash('error', 'برای تغییر ایمیل، وارد کردن رمز عبور فعلی الزامی است.');
                $this->response->redirect(Plugin::profileUrl() . '#sp-panel-profile');
            }

            if (!Password::verify($currentPassword, (string) $this->user->password)) {
                Plugin::flash('error', 'رمز عبور فعلی نادرست است؛ لطفاً دوباره تلاش کنید.');
                $this->response->redirect(Plugin::profileUrl() . '#sp-panel-profile');
            }
        }

        $currentScreenName = (string) $this->user->screenName;

        $user = [
            'screenName' => Common::strBy(trim((string) ($data['screenName'] ?? '')), (string) $this->user->name),
            'mail' => $newMail
        ];

        try {
            $updateRows = $this->updateUser($user);
        } catch (\Throwable $e) {
            $conflict = $this->userWriteConflict($e);

            if ($conflict !== null) {
                Plugin::flash('error', 'مقدار واردشده (نام مستعار یا ایمیل) تکراری است؛ لطفاً مقدار دیگری انتخاب کنید.');
                $this->response->redirect(Plugin::profileUrl() . '#sp-panel-profile');
            }

            throw $e;
        }

        // همگام‌سازی نام نویسنده در نظرات قبلی، در صورت تغییر نام مستعار
        if ($updateRows > 0 && $currentScreenName !== $user['screenName']) {
            Comment::syncUserAuthor(
                $this->db,
                (int) $this->user->uid,
                $user['screenName'],
                null,
                (int) ($this->options->cacheCommentFlush ?? 1)
            );
        }

        // بیوگرافی در جدول اختصاصی افزونه + همگام‌سازی با انجمن
        $bio = mb_substr(trim((string) ($data['bio'] ?? '')), 0, Meta::MAX_BIO);
        $socials = Meta::getRow((int) $this->user->uid);
        Meta::save((int) $this->user->uid, ['bio' => $bio]);

        // تغییر ایمیل، هش گراواتار انجمن را هم عوض می‌کند؛ نگاشت تازه شود
        ForumSync::push((int) $this->user->uid, array_merge($socials, ['bio' => $bio]));

        Plugin::flash('success', 'اطلاعات پروفایل شما با موفقیت به‌روزرسانی شد.');
        $this->response->redirect(Plugin::profileUrl() . '#sp-panel-profile');
    }

    /**
     * به‌روزرسانی وب‌سایت و شبکه‌های اجتماعی
     */
    private function updateSocial(): void
    {
        $data = $this->request->from(...array_merge(['url'], array_keys(Meta::SOCIALS)));

        // نرمال‌سازی پیش از اعتبارسنجی (فیلدهای غایب = رشتهٔ خالی)
        foreach (array_merge(['url'], array_keys(Meta::SOCIALS)) as $key) {
            $data[$key] = trim((string) ($data[$key] ?? ''));
        }

        // اگر نشانی وب‌سایت بدون اسکیما وارد شده باشد، خودکار تکمیل می‌شود
        $url = (string) $data['url'];
        if ($url !== '' && !preg_match('#^https?://#i', $url)) {
            $url = 'https://' . $url;
        }
        $data['url'] = $url;

        $validator = new Validate();
        $validator->addRule('url', 'url', 'نشانی وب‌سایت معتبر نیست؛ باید مانند https://example.com باشد');
        $validator->addRule('url', 'maxLength', 'نشانی وب‌سایت حداکثر می‌تواند ۱۵۰ کاراکتر باشد', 150);

        foreach (Meta::SOCIALS as $key => $definition) {
            $validator->addRule($key, 'xssCheck', 'در مقدار ' . $definition['label'] . ' از کاراکترهای خاص استفاده نکنید');
            $validator->addRule($key, 'maxLength', 'مقدار ' . $definition['label'] . ' حداکثر می‌تواند ۲۰۰ کاراکتر باشد', Meta::MAX_HANDLE);
        }

        if ($errors = $validator->run($data)) {
            Plugin::flash('error', implode(' — ', $errors));
            $this->response->redirect(Plugin::profileUrl() . '#sp-panel-social');
        }

        $handles = [];
        foreach (Meta::SOCIALS as $key => $definition) {
            $handles[$key] = Meta::normalizeHandle((string) ($data[$key] ?? ''));
        }

        $this->updateUser(['url' => $url]);
        Meta::save((int) $this->user->uid, $handles);

        // همگام‌سازی شبکه‌های اجتماعی با انجمن (وب‌سایت در جدول users مشترک است)
        ForumSync::push((int) $this->user->uid, array_merge(['bio' => (string) Meta::getRow((int) $this->user->uid)['bio']], $handles));

        Plugin::flash('success', 'وب‌سایت و شبکه‌های اجتماعی شما با موفقیت به‌روزرسانی شد.');
        $this->response->redirect(Plugin::profileUrl() . '#sp-panel-social');
    }

    /**
     * تغییر رمز عبور (با تأیید رمز فعلی)
     */
    private function updatePassword(): void
    {
        $data = $this->request->from('currentPassword', 'password', 'confirm');

        $validator = new Validate();
        $validator->addRule('currentPassword', 'required', 'رمز عبور فعلی را وارد کنید');
        $validator->addRule('password', 'required', 'رمز عبور جدید را وارد کنید');
        $validator->addRule(
            'password',
            [Password::class, 'validateLength'],
            sprintf('رمز عبور جدید باید حداقل %d کاراکتر و حداکثر %d بایت باشد.', Password::minLength(), Password::maxLength())
        );
        $validator->addRule('confirm', 'confirm', 'تکرار رمز عبور جدید با خود رمز مطابقت ندارد', 'password');

        if ($errors = $validator->run($data)) {
            Plugin::flash('error', implode(' — ', $errors));
            $this->response->redirect(Plugin::profileUrl() . '#sp-panel-security');
        }

        if (!Password::verify((string) ($data['currentPassword'] ?? ''), (string) $this->user->password)) {
            Plugin::flash('error', 'رمز عبور فعلی نادرست است؛ لطفاً دوباره تلاش کنید.');
            $this->response->redirect(Plugin::profileUrl() . '#sp-panel-security');
        }

        // مطابق هسته: پس از تغییر رمز، شناسه نشست تازه می‌گیرد و کاربر واردشده باقی می‌ماند
        $authCode = bin2hex(Common::secureRandomBytes(16));
        $expireAt = Cookie::get('__typecho_remember_remember') ? time() + 30 * 24 * 3600 : 0;

        $this->updateUser([
            'password' => Password::hash((string) $data['password']),
            'authCode' => $authCode
        ]);

        Cookie::set('__typecho_uid', $this->user->uid, $expireAt);
        Cookie::set('__typecho_authCode', Common::hash($authCode), $expireAt);

        Plugin::flash('success', 'رمز عبور شما با موفقیت تغییر کرد و اکنون با رمز جدید وارد حساب خود هستید.');
        $this->response->redirect(Plugin::profileUrl() . '#sp-panel-security');
    }

    /**
     * بارگذاری آواتار محلی (تب آواتار)
     */
    private function uploadAvatar(): void
    {
        if (!Avatar::enabled()) {
            Plugin::flash('error', 'قابلیت آواتار محلی توسط مدیر سایت خاموش شده است.');
            $this->response->redirect(Plugin::profileUrl() . '#sp-panel-avatar');
        }

        $file = (array) ($_FILES['avatar'] ?? []);

        if ($file === []) {
            Plugin::flash('error', 'فایلی برای بارگذاری انتخاب نشده است.');
            $this->response->redirect(Plugin::profileUrl() . '#sp-panel-avatar');
        }

        $result = Avatar::save((int) $this->user->uid, $file);

        if (!empty($result['ok'])) {
            Plugin::flash('success', 'آواتار شما با موفقیت بارگذاری شد و از این پس به‌جای گراواتار نمایش داده می‌شود.');
        } else {
            Plugin::flash('error', (string) ($result['error'] ?? 'بارگذاری آواتار ممکن نشد؛ دوباره تلاش کنید.'));
        }

        $this->response->redirect(Plugin::profileUrl() . '#sp-panel-avatar');
    }

    /**
     * حذف آواتار محلی و بازگشت به گراواتار
     */
    private function deleteAvatar(): void
    {
        if (!Avatar::enabled()) {
            Plugin::flash('error', 'قابلیت آواتار محلی توسط مدیر سایت خاموش شده است.');
            $this->response->redirect(Plugin::profileUrl() . '#sp-panel-avatar');
        }

        if (Avatar::remove((int) $this->user->uid)) {
            Plugin::flash('success', 'آواتار محلی حذف شد؛ از این پس تصویر گراواتار شما نمایش داده می‌شود.');
        } else {
            Plugin::flash('error', 'حذف آواتار ممکن نشد.');
        }

        $this->response->redirect(Plugin::profileUrl() . '#sp-panel-avatar');
    }

    /**
     * نوشتن مستقیم رکورد کاربرِ فعلی در جدول users
     *
     * این ویجت از Widget\Archive ارث می‌برد؛ بنابراین متد update والد
     * روی جدول contents عمل می‌کند. به‌جای آن، همان چیزی که
     * Widget\Base\Users::update انجام می‌دهد این‌جا تکرار شده است.
     */
    private function updateUser(array $rows): int
    {
        return $this->db->query(
            $this->db->sql()->where('uid = ?', $this->user->uid)->update('table.users')->rows($rows)
        );
    }
}
