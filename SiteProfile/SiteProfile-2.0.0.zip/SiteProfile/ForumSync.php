<?php
declare(strict_types=1);

namespace TypechoPlugin\SiteProfile;

use Typecho\Db;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * همگام‌سازی دوطرفه با افزونهٔ Forum (انجمن پرسش و پاسخ)
 *
 * افزونهٔ انجمن بیوگرافی و شبکه‌های اجتماعی اعضا را در حافظهٔ متای خودش
 * (ستون users.meta و در نبود آن، گزینهٔ ext:Forum-user-meta-{uid} در
 * جدول options) نگه می‌دارد. این کلاس داده‌ها را بین آن حافظه و جدول
 * اختصاصی SiteProfile همگام نگه می‌دارد تا ویرایش از هر دو سمت (صفحهٔ
 * پروفایل محیط سایت یا صفحهٔ ویرایش پروفایل انجمن) در هر دو جا منعکس
 * شود — بدون هیچ تغییری در فایل‌های افزونهٔ انجمن.
 *
 * سازوکار:
 *
 * - push: پس از ذخیرهٔ پروفایل/شبکه‌ها در صفحهٔ پروفایل، مقادیر (با
 *   تبدیل نام‌های کاربری به نشانی کامل — الگوی حافظهٔ انجمن) در حافظهٔ
 *   انجمن نوشته و «امضای» وضعیت resultant در ستون forum_sync جدول
 *   افزونه ثبت می‌شود.
 * - pull: پیش از خواندن داده‌ها، حافظهٔ فعلی انجمن با آخرین امضای ذخیره‌شده
 *   مقایسه می‌شود؛ اگر تفاوت داشته باشد یعنی کاربر از سمت انجمن ویرایش
 *   کرده و مقادیر تازه به جدول افزونه منتقل می‌شود.
 *
 * آواتار محلی هم از طریق نگاشت md5(ایمیل) در صفحات انجمن جایگزین
 * گراواتار می‌شود (Avatar::forumSwapScript).
 *
 * @package SiteProfile
 * @since 2.0.0
 */
class ForumSync
{
    /** کلیدهای مشترک بیوگرافی و شبکه‌های اجتماعی میان دو افزونه */
    private const SHARED_KEYS = ['bio', 'twitter', 'github', 'telegram', 'instagram', 'linkedin', 'youtube'];

    /** حداکثر طول بیوگرافی در حافظهٔ انجمن (مطابق افزونهٔ Forum) */
    private const FORUM_BIO_MAX = 255;

    /** حداکثر طول مقدار شبکهٔ اجتماعی در جدول افزونه */
    private const HANDLE_MAX = 200;

    /** کش درخواست جاری: uid => امضای خوانده‌شده از انجمن */
    private static array $pullMemo = [];

    /** کش وضعیت فعال‌بودن انجمن */
    private static ?bool $activeCache = null;

    /**
     * ویجت‌های صفحه‌ساز افزونهٔ انجمن
     *
     * صفحات انجمن با همین کلاس‌ها رندر می‌شوند و سیگنال سربرگ (header)
     * نیز با همین کلاس‌های نهایی فراخوانده می‌شود (پیوند کلاس از طریق
     * static::class در Widget\Archive::header). برای تزریق تعویض آواتار
     * باید روی خود این کلاس‌ها هوک ثبت شود.
     */
    public const FORUM_PAGE_WIDGETS = [
        'TypechoPlugin\\Forum\\ForumList',
        'TypechoPlugin\\Forum\\Thread',
        'TypechoPlugin\\Forum\\Profile',
        'TypechoPlugin\\Forum\\ProfileEdit',
        'TypechoPlugin\\Forum\\CategoryAdmin',
    ];

    // ------------------------------------------------------------------
    //  وضعیت
    // ------------------------------------------------------------------

    /** آیا افزونهٔ Forum نصب و فعال است؟ */
    public static function active(): bool
    {
        if (self::$activeCache !== null) {
            return self::$activeCache;
        }

        self::$activeCache = false;

        try {
            $exported = \Typecho\Plugin::export();

            if (isset($exported['activated']['Forum'])) {
                self::$activeCache = true;
            }
        } catch (\Throwable) {
            // محیط کامل بارگذاری نشده
        }

        return self::$activeCache;
    }

    /** آیا همگام‌سازی از تنظیمات فعال است؟ */
    private static function enabled(): bool
    {
        return Plugin::settings()['forumSync'] === '1' && self::active();
    }

    // ------------------------------------------------------------------
    //  خواندن و نوشتن حافظهٔ انجمن
    // ------------------------------------------------------------------

    /**
     * خواندن بیوگرافی و شبکه‌های اجتماعی از حافظهٔ انجمن
     *
     * @return array<string, string>
     */
    public static function readForumMeta(int $uid): array
    {
        $meta = [];

        if ($uid > 0 && self::active() && class_exists('\TypechoPlugin\Forum\Plugin')) {
            try {
                $meta = (array) \TypechoPlugin\Forum\Plugin::getUserMeta($uid);
            } catch (\Throwable) {
                $meta = [];
            }
        }

        $out = [];

        foreach (self::SHARED_KEYS as $key) {
            $out[$key] = $key === 'bio'
                ? mb_substr(trim((string) ($meta[$key] ?? '')), 0, self::FORUM_BIO_MAX)
                : trim((string) ($meta[$key] ?? ''));
        }

        return $out;
    }

    /**
     * نوشتن مقادیر (نشانی‌های کامل شبکه‌ها) در حافظهٔ انجمن
     */
    private static function writeForumMeta(int $uid, array $values): bool
    {
        if ($uid < 1 || !self::active() || !class_exists('\TypechoPlugin\Forum\Plugin')) {
            return false;
        }

        try {
            return (bool) \TypechoPlugin\Forum\Plugin::updateUserMeta($uid, $values);
        } catch (\Throwable) {
            return false;
        }
    }

    /**
     * نشانی انجمنی یک کاربر ('' در نبود انجمن فعال) — برای پیوند «پرسش و پاسخ»
     */
    public static function forumProfileUrl(int $uid): string
    {
        if ($uid < 1 || !self::active() || !class_exists('\TypechoPlugin\Forum\Plugin')) {
            return '';
        }

        try {
            return (string) \TypechoPlugin\Forum\Plugin::profileUrl($uid);
        } catch (\Throwable) {
            return '';
        }
    }

    /**
     * نشانی صفحهٔ اصلی انجمن ('' در نبود انجمن فعال) — برای منوی «دسترسی سریع»
     */
    public static function forumUrl(): string
    {
        if (!self::active() || !class_exists('\TypechoPlugin\Forum\Plugin')) {
            return '';
        }

        try {
            return (string) \TypechoPlugin\Forum\Plugin::forumUrl();
        } catch (\Throwable) {
            return '';
        }
    }

    // ------------------------------------------------------------------
    //  امضا (نشانگر آخرین وضعیت همگام)
    // ------------------------------------------------------------------

    /** امضای پایدار یک بستهٔ مقادیر (برای مقایسهٔ وضعیت انجمن) */
    private static function signature(array $values): string
    {
        $canonical = [];

        foreach (self::SHARED_KEYS as $key) {
            $canonical[$key] = trim((string) ($values[$key] ?? ''));
        }

        return serialize($canonical);
    }

    /** امضای ذخیره‌شدهٔ آخرین وضعیت همگان (ستون forum_sync) */
    private static function storedSignature(int $uid): string
    {
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('forum_sync')->from('table.siteprofile')->where('uid = ?', $uid)->limit(1)
            );

            return (string) ($row['forum_sync'] ?? '');
        } catch (\Throwable) {
            return '';
        }
    }

    /** ثبت امضای وضعیت همگان در جدول افزونه */
    private static function storeSignature(int $uid, string $signature): void
    {
        Meta::save($uid, ['forum_sync' => $signature]);
    }

    // ------------------------------------------------------------------
    //  همگام‌سازی
    // ------------------------------------------------------------------

    /**
     * انتشار مقادیر تازهٔ پروفایل (بیوگرافی/شبکه‌ها) به انجمن
     *
     * نام‌های کاربری شبکه‌ها پیش از ارسال به نشانی کامل تبدیل می‌شوند
     * (الگوی حافظهٔ انجمن نشانی کامل انتظار دارد) و پس از نوشتن، وضعیت
     * نهایی واقعی از انجمن خوانده و امضایش ثبت می‌شود تا هرگونه نرمال‌سازی
     * سمت انجمن (تکمیل https، برش طول) در امضا لحاظ شود.
     *
     * @param array $values مقادیر جدول افزونه: bio + دسته‌های شبکه‌ها
     */
    public static function push(int $uid, array $values): void
    {
        if (!self::enabled() || $uid < 1) {
            return;
        }

        $payload = ['bio' => mb_substr(trim((string) ($values['bio'] ?? '')), 0, self::FORUM_BIO_MAX)];

        foreach (Meta::SOCIALS as $key => $definition) {
            $payload[$key] = Meta::socialUrl($key, trim((string) ($values[$key] ?? '')));
        }

        if (!self::writeForumMeta($uid, $payload)) {
            return;
        }

        // امضای وضعیت واقعیِ پس از نوشتن (نه وضعیت فرضی)
        $signature = self::signature(self::readForumMeta($uid));
        self::storeSignature($uid, $signature);
        self::$pullMemo[$uid] = true;
    }

    /**
     * در صورت ویرایش از سمت انجمن، مقادیر تازه به جدول افزونه منتقل می‌شود
     *
     * این متد مسیر خواندن داده‌ها (Meta::getRow) فراخوانده می‌شود؛ اگر
     * حافظهٔ انجمن با آخرین امضای ثبت‌شده تفاوت داشته باشد یعنی کاربر از
     * سمت انجمن چیزی را ویرایش کرده و باید وارد جدول افزونه شود.
     */
    public static function pullIfNeeded(int $uid): void
    {
        if (!self::enabled() || $uid < 1) {
            return;
        }

        // هر کاربر حداکثر یک بار در هر درخواست بررسی می‌شود
        if (isset(self::$pullMemo[$uid])) {
            return;
        }

        self::$pullMemo[$uid] = true;

        $forumMeta = self::readForumMeta($uid);
        $signature = self::signature($forumMeta);

        if ($signature === self::storedSignature($uid)) {
            return; // تغییری از سمت انجمن ثبت نشده
        }

        // منتقل‌کردن مقادیر انجمن به جدول افزونه
        $rows = ['bio' => mb_substr($forumMeta['bio'], 0, Meta::MAX_BIO)];

        foreach (Meta::SOCIALS as $key => $definition) {
            $rows[$key] = self::reduceHandle($key, $forumMeta[$key]);
        }

        Meta::save($uid, $rows);
        self::storeSignature($uid, $signature);
    }

    /**
     * برگرداندن مقدار شبکهٔ اجتماعی به کوتاه‌ترین شکل مجاز جدول افزونه
     *
     * حافظهٔ انجمن نشانی کامل نگه می‌دارد؛ برای یکدست‌ماندن دادهٔ جدول
     * افزونه (و فرم «نام کاربری»)، اگر مقدار دقیقاً الگوی نشانی پروفایل
     * باشد، نام کاربری از انتهای آن استخراج می‌شود.
     */
    private static function reduceHandle(string $key, string $value): string
    {
        $value = trim($value);

        if ($value === '') {
            return $value;
        }

        // استخراج نام کاربری از انتهای نشانی (t.me/ali، github.com/ali، linkedin.com/in/ali، youtube.com/@ali)
        // نکته: الگو با ~ محدود شده چون کلاس نویسه‌ها شامل # است
        if (preg_match('~^https?://[^/]+/(?:in/|@)?([^/?#]+)/?$~i', rtrim($value, '/'), $m)) {
            $handle = urldecode($m[1]);

            if ($handle !== '' && !preg_match('#[.:]#', $handle) && mb_strlen($handle, 'UTF-8') <= self::HANDLE_MAX) {
                return $handle;
            }
        }

        return mb_substr($value, 0, self::HANDLE_MAX, 'UTF-8');
    }

    // ------------------------------------------------------------------
    //  داده‌های تب انجمن در صفحهٔ عمومی کاربر
    // ------------------------------------------------------------------

    /**
     * آمار و فهرست‌های انجمن کاربر برای تب «پرسش و پاسخ»
     *
     * @return array|null در نبود انجمن فعال null
     */
    public static function memberForumData(int $uid, string $subTab, int $page, int $perPage): ?array
    {
        if (!self::active() || $uid < 1 || !class_exists('\TypechoPlugin\Forum\Plugin')) {
            return null;
        }

        try {
            $stats = (array) \TypechoPlugin\Forum\Plugin::userStats($uid);
            $db = Db::get();

            $total = $subTab === 'answers' ? (int) ($stats['answers'] ?? 0) : (int) ($stats['questions'] ?? 0);
            $pages = max(1, (int) ceil($total / max(1, $perPage)));
            $page = min(max(1, $page), $pages);
            $rows = [];

            if ($subTab === 'answers') {
                $answerRows = $db->fetchAll(
                    $db->select('id', 'topic_id', 'created', 'text')
                        ->from('table.forum_posts')
                        ->where('author_id = ? AND status = ?', $uid, 'approved')
                        ->order('created', Db::SORT_DESC)
                        ->page($page, $perPage)
                );

                if ($answerRows !== []) {
                    $ids = array_values(array_unique(array_map(static fn ($r): int => (int) $r['topic_id'], $answerRows)));
                    $topics = [];
                    foreach ($db->fetchAll(
                        $db->select('id', 'text')->from('table.forum_topics')->where('id IN ?', $ids)
                    ) as $t) {
                        $topics[(int) $t['id']] = (string) $t['text'];
                    }

                    foreach ($answerRows as $r) {
                        [$title] = \TypechoPlugin\Forum\Plugin::splitQuestion((string) ($topics[(int) $r['topic_id']] ?? ''));
                        $rows[] = [
                            'title'   => \TypechoPlugin\Forum\Plugin::stripMarkup((string) $title),
                            'excerpt' => \TypechoPlugin\Forum\Plugin::excerpt((string) $r['text'], 160),
                            'url'     => (string) \TypechoPlugin\Forum\Plugin::threadUrl((int) $r['topic_id']),
                            'created' => (int) $r['created'],
                            'replies' => null,
                        ];
                    }
                }
            } else {
                $topicRows = $db->fetchAll(
                    $db->select('id', 'created', 'text')
                        ->from('table.forum_topics')
                        ->where('author_id = ? AND status = ?', $uid, 'approved')
                        ->order('created', Db::SORT_DESC)
                        ->page($page, $perPage)
                );

                foreach ($topicRows as $r) {
                    [$title] = \TypechoPlugin\Forum\Plugin::splitQuestion((string) $r['text']);
                    $replies = (int) $db->fetchObject(
                        $db->select(['COUNT(id)' => 'n'])->from('table.forum_posts')
                            ->where('topic_id = ? AND status = ?', (int) $r['id'], 'approved')
                    )->n;

                    $rows[] = [
                        'title'   => \TypechoPlugin\Forum\Plugin::stripMarkup((string) $title),
                        'excerpt' => \TypechoPlugin\Forum\Plugin::excerpt((string) $r['text'], 160),
                        'url'     => (string) \TypechoPlugin\Forum\Plugin::threadUrl((int) $r['id']),
                        'created' => (int) $r['created'],
                        'replies' => $replies,
                    ];
                }
            }

            return [
                'stats'    => [
                    'questions'   => (int) ($stats['questions'] ?? 0),
                    'answers'     => (int) ($stats['answers'] ?? 0),
                    'bestAnswers' => (int) ($stats['bestAnswers'] ?? 0),
                    'score'       => (int) ($stats['score'] ?? 0),
                ],
                'rows'     => $rows,
                'page'     => $page,
                'pages'    => $pages,
                'total'    => $total,
                'profileUrl' => self::forumProfileUrl($uid),
            ];
        } catch (\Throwable) {
            return null;
        }
    }
}
