<?php
declare(strict_types=1);

namespace TypechoPlugin\MediaManager;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class Icons
{
    /** ویژگی‌های مشترک ریشه‌ی svg (سبک رسمی Lucide) */
    private const SVG_ATTRS = 'xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"';

    /** داده‌ی داخلی هر آیکون (بدون ریشه‌ی svg) */
    private const ICONS = [
        // جستجو
        'search' => '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
        // کپی
        'copy' => '<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
        // لینک / کپی لینک
        'link' => '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
        // تیک موفقیت
        'check' => '<path d="M20 6 9 17l-5-5"/>',
        // بستن / خطا
        'x' => '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
        // پیکان‌های صفحه‌بندی (در RTL: قبلی=راست، بعدی=چپ)
        'chevron-right' => '<path d="m9 18 6-6-6-6"/>',
        'chevron-left' => '<path d="m15 18-6-6 6-6"/>',
        // باز/بسته کردن فهرست کامل پیوست‌ها (تب پیوست‌ها)
        'chevron-down' => '<path d="m6 9 6 6 6-6"/>',
        'chevron-up' => '<path d="m18 15-6-6-6 6"/>',
        // پوشه بالاتر
        'arrow-up' => '<path d="m5 12 7-7 7 7"/><path d="M12 19V5"/>',
        // پوشه
        'folder' => '<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>',
        // پوشه باز (نمای فعال / ریشه)
        'folder-open' => '<path d="m6 14 1.45-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.55 6a2 2 0 0 1-1.94 1.5H4a2 2 0 0 1-2-2V5c0-1.1.9-2 2-2h3.93a2 2 0 0 1 1.66.9l.82 1.2a2 2 0 0 0 1.66.9H18a2 2 0 0 1 2 2v2"/>',
        // تصویر
        'image' => '<rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>',
        // تصویر شکسته
        'image-off' => '<path d="M10.4 6.4A2 2 0 0 1 12 6h9a2 2 0 0 1 2 2v13a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 .6-1.4"/><path d="M5 21a2 2 0 0 1-2-2V8c0-.9.3-1.7.9-2.3"/><circle cx="9" cy="9" r="2"/><path d="m2 2 20 20"/>',
        // فایل عمومی
        'file' => '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/>',
        // حذف
        'trash-2' => '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/>',
        // ویرایش
        'pencil' => '<path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/>',
        // پیش‌نمایش
        'eye' => '<path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/>',
        // مشاهده در تب جدید
        'external-link' => '<path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
        // بارگذاری
        'upload' => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/>',
        // ریشه‌ی uploads
        'hard-drive' => '<line x1="22" x2="2" y1="12" y2="12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/><line x1="6" x2="6.01" y1="16" y2="16"/><line x1="10" x2="10.01" y1="16" y2="16"/>',
        // نمای کتابخانه (گرید)
        'layout-grid' => '<rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/>',
        // پوشه جدید
        'folder-plus' => '<path d="M12 10v6"/><path d="M9 13h6"/><path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>',
        // انتقال فایل به پوشه (پوشه با پیکان ورودی)
        'folder-input' => '<path d="M2 9V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l1.1 1.4a2 2 0 0 0 1.69.7H20a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-1"/><path d="M2 13h10"/><path d="m9 16 3-3-3-3"/>',
        // آرشیو / فایل فشرده
        'archive' => '<rect width="20" height="5" x="2" y="3" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"/><path d="M10 12h4"/>',
        // سند متنی
        'file-text' => '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M16 13H8"/><path d="M16 17H8"/><path d="M10 9H8"/>',
        // صفحه‌گسترده
        'table' => '<path d="M12 3v18"/><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M3 9h18"/><path d="M3 15h18"/>',
        // ارائه / اسلاید
        'presentation' => '<path d="M2 3h20"/><path d="M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"/><path d="m7 21 5-5 5 5"/>',
        // موسیقی / صدا
        'music' => '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
        // ویدیو
        'video' => '<path d="m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5"/><rect x="2" y="6" width="14" height="12" rx="2"/>',
        // فایل کد / برنامه‌نویسی
        'file-code' => '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="m10 12-2 2 2 2"/><path d="m14 16 2-2-2-2"/>',
        // برق / فشرده‌سازی (تبدیل WebP)
        'zap' => '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
        // درج در مطلب (نشانگر «Enter» — درج در موقعیت مکان‌نما)
        'corner-down-left' => '<path d="m9 10-5 5 5 5"/><path d="M20 4v7a4 4 0 0 1-4 4H4"/>',
        // هشدار (پیام‌های حساس و بازگشت‌ناپذیر)
        'alert-triangle' => '<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" x2="12" y1="9" y2="13"/><line x1="12" x2="12.01" y1="17" y2="17"/>',
        // بازگردانی (چرخش معکوس)
        'rotate-ccw' => '<path d="M1 4v6h6"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/>',
        // اطلاعات (پیام‌های عادی مودال)
        'info' => '<circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="16" y2="12"/><line x1="12" x2="12.01" y1="8" y2="8"/>',
    ];

    /**
     * رندر svg درون‌خطی Lucide
     *
     * @param string $name  نام آیکون از رجیستری
     * @param string $class کلاس CSS (پیش‌فرض mm-ico)
     */
    public static function svg(string $name, string $class = 'mm-ico'): string
    {
        $inner = self::ICONS[$name] ?? '';
        if ($inner === '') {
            return '';
        }

        return '<svg ' . self::SVG_ATTRS . ' class="' . htmlspecialchars($class, ENT_QUOTES, 'UTF-8')
            . '" aria-hidden="true">' . $inner . '</svg>';
    }

    /**
     * نقشه‌ی «نام → محتوای داخلی svg» برای تزریق به JS
     * (سمت کلاینت با createElementNS + innerHTML ساخته می‌شود؛ فقط رشته‌های ثابت)
     */
    public static function jsMap(): array
    {
        return self::ICONS;
    }

    /* ------------------------------------------------ آیکون اختصاصی هر نوع فایل */

    /** آیکون هر دسته‌ی فایل (kind) */
    private const KIND_ICONS = [
        'image' => 'image',
        'archive' => 'archive',
        'doc' => 'file-text',
        'sheet' => 'table',
        'slides' => 'presentation',
        'audio' => 'music',
        'video' => 'video',
        'code' => 'file-code',
        'file' => 'file',
    ];

    /** پسوندهای هر دسته‌ی فایل */
    private const KIND_TYPES = [
        'image' => 'jpg,jpeg,png,gif,webp,bmp,tiff,tif,avif,svg,ico,heic',
        'archive' => 'zip,rar,7z,tar,gz,tgz,bz2,xz,iso,cab,arj',
        'doc' => 'pdf,doc,docx,txt,rtf,odt,md,epub,mobi',
        'sheet' => 'xls,xlsx,csv,ods,tsv',
        'slides' => 'ppt,pptx,odp,key',
        'audio' => 'mp3,wav,ogg,oga,flac,m4a,aac,wma,opus,mid,midi,aiff',
        'video' => 'mp4,avi,mov,mkv,webm,flv,wmv,rmvb,rm,ogv,m4v,3gp,mpg,mpeg,ts',
        'code' => 'js,css,json,xml,html,htm,php,py,rb,pl,sql,sh,bat,yml,yaml,toml,ini,c,cpp,h,java,ts,swift,go,rs',
    ];

    /** برچسب فارسی هر دسته‌ی فایل */
    private const KIND_LABELS = [
        'image' => 'تصویر',
        'archive' => 'آرشیو',
        'doc' => 'سند',
        'sheet' => 'صفحه‌گسترده',
        'slides' => 'ارائه',
        'audio' => 'صدا',
        'video' => 'ویدیو',
        'code' => 'کد',
        'file' => 'فایل',
    ];

    /**
     * دسته‌ی فایل از روی پسوند (image|archive|doc|sheet|slides|audio|video|code|file)
     */
    public static function fileKind(string $extension): string
    {
        $extension = strtolower(trim(ltrim(trim($extension), '.')));
        if ($extension === '') {
            return 'file';
        }

        foreach (self::KIND_TYPES as $kind => $list) {
            if (in_array($extension, explode(',', $list), true)) {
                return $kind;
            }
        }

        return 'file';
    }

    /**
     * نام آیکون Lucide مخصوص یک دسته‌ی فایل
     */
    public static function kindIcon(string $kind): string
    {
        return self::KIND_ICONS[$kind] ?? self::KIND_ICONS['file'];
    }

    /**
     * نقشه‌ی کامل «پسوند → دسته» برای تزریق به JS
     */
    public static function kindMap(): array
    {
        $map = [];
        foreach (self::KIND_TYPES as $kind => $list) {
            foreach (explode(',', $list) as $ext) {
                $map[$ext] = $kind;
            }
        }

        return $map;
    }

    /**
     * نقشه‌ی «دسته → نام آیکون» برای تزریق به JS
     */
    public static function kindIcons(): array
    {
        return self::KIND_ICONS;
    }

    /**
     * برچسب فارسی یک دسته‌ی فایل
     */
    public static function kindLabel(string $kind): string
    {
        return self::KIND_LABELS[$kind] ?? self::KIND_LABELS['file'];
    }

    /**
     * نقشه‌ی «دسته → برچسب فارسی» برای تزریق به JS
     */
    public static function kindLabels(): array
    {
        return self::KIND_LABELS;
    }

    /* ------------------------------------------------ فیلتر نوع فایل */

    /**
     * فیلترهای نوع فایل (انتخابگر ویرایشگر + پنل مدیریت)
     *
     * «اسناد» شامل سند، صفحه‌گسترده و ارائه است؛ «کد» فیلتر جدا ندارد
     * و فقط داخل «همه» دیده می‌شود.
     */
    public const FILTER_LABELS = [
        'all' => 'همه',
        'image' => 'تصویر',
        'video' => 'ویدئو',
        'audio' => 'صوت',
        'archive' => 'آرشیو',
        'doc' => 'اسناد',
    ];

    /** دسته‌هایی که فیلتر «اسناد» در بر می‌گیرد */
    private const DOC_KINDS = ['doc', 'sheet', 'slides'];

    /**
     * اعتبارسنجی کلید فیلتر ورودی — مقدار نامعتبر به '' (همه) تبدیل می‌شود
     */
    public static function validFilter(string $filter): string
    {
        $filter = strtolower(trim($filter));
        return array_key_exists($filter, self::FILTER_LABELS) && $filter !== 'all' ? $filter : '';
    }

    /**
     * آیا پسوند با فیلتر داده‌شده مطابقت دارد؟ ('' یا 'all' = همه)
     */
    public static function filterMatches(string $filter, string $extension): bool
    {
        if ($filter === '' || $filter === 'all') {
            return true;
        }

        $kind = self::fileKind($extension);
        if ($filter === 'doc') {
            return in_array($kind, self::DOC_KINDS, true);
        }

        return $kind === $filter;
    }
}
