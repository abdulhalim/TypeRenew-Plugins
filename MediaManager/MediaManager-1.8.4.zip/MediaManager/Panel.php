<?php
declare(strict_types=1);

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

use TypechoPlugin\MediaManager\Browser;
use TypechoPlugin\MediaManager\Icons;
use TypechoPlugin\MediaManager\Library;
use TypechoPlugin\MediaManager\Settings;
use TypechoPlugin\MediaManager\Text;
use TypechoPlugin\MediaManager\Trash;
use TypechoPlugin\MediaManager\Webp;


// احراز سطح دسترسی
$user->pass('contributor');

$settings = Settings::load();
$pageSize = (int) $settings['pageSize'];

// مرور پوشه‌ای فقط برای ویراستار و مدیر
$canBrowse = $user->pass('editor', true);

$view = trim(strip_tags((string) $request->get('view', '')));
$view = ($view === 'browse' || $view === 'library') ? $view : '';
if ($view === '') {
    $view = $canBrowse ? 'browse' : 'library';
}
if (!$canBrowse && $view === 'browse') {
    $view = 'library';
}

$keywords = '';
if ($thisKeyword = $request->get('keywords')) {
    $keywords = trim(strip_tags((string) $thisKeyword));
}

// فیلتر نوع فایل (تصویر/ویدئو/صوت/آرشیو/اسناد) — در هر دو نمای مرور و کتابخانه
$kind = Icons::validFilter((string) $request->get('kind', ''));

$deleteUrl = $security->getIndex('/action/contents-attachment-edit');
$uploadUrl = $security->getIndex('/action/upload');
$unlinkUrl = $security->getIndex('/action/media-manager');
$allowedTypes = array_values((array) $options->allowedAttachmentTypes);

// وضعیت سطل زباله (حذف نرم) — فقط برای ویراستار/مدیر
$trashCount = $canBrowse ? Trash::countEntries() : 0;

// پوشه‌ی مقصد پیش‌فرض آپلودر هسته (YYYY/MM) — با همان کلاس تاریخ هسته
// تا منطقه‌ی زمانی سایت (نه سرور) لحاظ شود
$uploadNow = new \Typecho\Date();
$uploadFolderPath = $uploadNow->year . '/' . $uploadNow->month;

$panelSelf = 'MediaManager/Panel.php';
$panelBase = $options->adminUrl . 'extending.php';

// نشانی صفحه‌ی اختصاصی سطل بازیافت (پنل مخفی که فقط از همین‌جا باز می‌شود)
$trashPageUrl = $panelBase . '?panel=' . urlencode('MediaManager/TrashPage.php');

/**
 * ساخت نشانی نمای «مرور پوشه‌ها» با پارامترهای دلخواه (فیلتر جاری حفظ می‌شود).
 *
 * نکته‌ی حیاتی: مقدار تهی «حفظ» می‌شود — یعنی رفتن به ریشه
 * همیشه نشانی‌ای با «path=» خالی تولید می‌کند (مثل ?path=&view=browse)
 * تا در بارگذاری بعدی، منطق «شروع در پوشه‌ی فرود» (bootAtLandedFolder)
 * انتخاب صریح کاربر را بازگشتی نکند. فقط null حذف می‌شود (پارامتر عمداً
 * غیرفعال، مثل kind در چیپ «همه»).
 */
$browseUrl = static function (array $params = []) use ($panelBase, $panelSelf, $kind): string {
    $params = array_merge(['panel' => $panelSelf, 'view' => 'browse'], $kind !== '' ? ['kind' => $kind] : [], $params);
    $params = array_filter($params, static function ($v) {
        return $v !== null;
    });
    return $panelBase . '?' . http_build_query($params);
};

/**
 * ساخت نشانی نمای «کتابخانه» (فیلتر جاری حفظ می‌شود) — همان قاعده‌ی
 * حفظ مقدار تهی $browseUrl
 */
$libraryUrl = static function (array $params = []) use ($panelBase, $panelSelf, $kind): string {
    $params = array_merge(['panel' => $panelSelf, 'view' => 'library'], $kind !== '' ? ['kind' => $kind] : [], $params);
    $params = array_filter($params, static function ($v) {
        return $v !== null;
    });
    return $panelBase . '?' . http_build_query($params);
};

// سقف حجم آپلود PHP (همان محاسبه هسته در file-upload-js.php)
$phpMaxFilesize = function_exists('ini_get') ? trim((string) ini_get('upload_max_filesize')) : '0';
if (preg_match("/^([0-9]+)([a-z]{1,2})?$/i", $phpMaxFilesize, $matches)) {
    $size = intval($matches[1]);
    $unit = $matches[2] ?? 'b';
    $phpMaxFilesize = (string) round($size * pow(1024, stripos('bkmgtpezy', $unit[0])));
}

/*
 * قالب اعداد: همه‌ی اعداد سمت سرور (شمارنده‌ها، صفحه‌بندی، حجم‌ها
 * و…) همیشه با ارقام فارسی نمایش داده می‌شوند تا با اعداد سمت کلاینت
 * (faNum در panel.js) هماهنگ بمانند.
 */
$faNum = static function ($value): string {
    return strtr((string) $value, [
        '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
        '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
    ]);
};

// ---------------------------------------------------------------- نمای مرور پوشه‌ها
$browseData = null;
$browseError = '';
$browsePath = '';
$page = 1;

if ($view === 'browse') {
    $rawPath = (string) $request->get('path', '');
    $page = max(1, (int) $request->filter('int')->get('page', 1));

    $browseData = Browser::list($rawPath, $keywords, $page, $pageSize, $kind);

    if (!empty($browseData['error'])) {
        $browseError = (string) $browseData['error'];
        $browseData = null;
    } else {
        $browsePath = (string) $browseData['path'];
        $page = (int) $browseData['page'];
    }
}

// ---------------------------------------------------------------- نمای کتابخانه
// از موتور Library استفاده می‌کنیم تا فیلتر نوع و جستجو روی پیوست‌های DB
// اعمال شود (نویسنده‌های معمولی فقط پیوست‌های خودشان را می‌بینند).
$libraryItems = [];
$libraryTotal = 0;
$libraryPage = 1;
$libraryPages = 1;
if ($view === 'library') {
    $libraryPage = max(1, (int) $request->filter('int')->get('page', 1));
    $libraryOwnUid = $canBrowse ? 0 : (int) $user->uid;

    $libraryData = Library::list($keywords, $kind, $libraryPage, $pageSize, $libraryOwnUid);
    $libraryItems = is_array($libraryData['items'] ?? null) ? $libraryData['items'] : [];
    $libraryTotal = (int) ($libraryData['total'] ?? 0);
    $libraryPage = (int) ($libraryData['page'] ?? 1);
    $libraryPages = max(1, (int) ceil($libraryTotal / max(1, (int) ($libraryData['pageSize'] ?? $pageSize))));
}

$config = [
    'view' => $view,
    'canBrowse' => $canBrowse,
    'currentPath' => $browsePath,
    'uploadUrl' => $uploadUrl,
    'deleteUrl' => $deleteUrl,
    'unlinkUrl' => $unlinkUrl,
    'mkdirUrl' => $security->getIndex('/action/media-manager?do=mkdir'),
    'renameUrl' => $security->getIndex('/action/media-manager?do=renamedir'),
    'renameFileUrl' => $security->getIndex('/action/media-manager?do=renamefile'),
    'rmdirUrl' => $security->getIndex('/action/media-manager?do=rmdir'),
    'treeUrl' => $security->getIndex('/action/media-manager?do=tree'),
    'moveUrl' => $security->getIndex('/action/media-manager?do=move'),
    'trashCount' => $trashCount,
    'browseBaseUrl' => $browseUrl(),
    'types' => $allowedTypes,
    'maxSize' => max(0, (int) $phpMaxFilesize),
    'uploadPath' => $uploadFolderPath,
    'uploadBrowseUrl' => $browseUrl(['path' => $uploadFolderPath]),
    'uploadDir' => Browser::uploadDirSetting(),
    'icons' => Icons::jsMap(),
    'fileKinds' => Icons::kindMap(),
    'kindIcons' => Icons::kindIcons(),
    'kindLabels' => Icons::kindLabels(),
    'strings' => [
        'selectAll' => 'انتخاب همه',
        'deselectAll' => 'لغو انتخاب',
        'copyLinks' => 'کپی لینک تصاویر انتخابی',
        'copy' => 'کپی لینک',
        'copied' => 'لینک کپی شد',
        'copyFailed' => 'کپی خودکار ممکن نشد؛ لینک‌ها در کادر زیر نمایش داده شدند؛ آن‌ها را دستی کپی کنید.',
        'noSelection' => 'ابتدا حداقل یک مورد را انتخاب کنید.',
        'delete' => 'حذف انتخاب‌شده‌ها',
        'deleteConfirm' => 'فایل‌های انتخاب‌شده به سطل زباله منتقل شوند؟ (قابل بازگردانی از سطل زباله)',
        'deleteConfirmTitle' => 'حذف فایل‌های انتخاب‌شده',
        'deleteConfirmYes' => 'انتقال به سطل زباله',
        'deleteOneConfirm' => 'این فایل به سطل زباله منتقل شود؟ (قابل بازگردانی از سطل زباله)',
        'deleteOneConfirmTitle' => 'حذف فایل',
        'deleteOnePathConfirm' => 'این فایل به سطل زباله منتقل شود؟ (قابل بازگردانی از سطل زباله)',
        'deleted' => 'فایل‌های انتخاب‌شده به سطل زباله منتقل شدند.',
        'deleteError' => 'حذف ناموفق بود؛ ممکن است دسترسی یا توکن منقضی شده باشد. صفحه نوسازی می‌شود…',
        'preview' => 'پیش‌نمایش',
        'edit' => 'ویرایش',
        'view' => 'مشاهده',
        'close' => 'بستن (Esc)',
        'linksTitle' => 'لینک تصاویر انتخاب‌شده',
        'linksHint' => 'این لینک‌ها را داخل متن پست درج کنید. با درج لینک تصویر، پیش‌نمایش آن در پایین ویرایشگر نمایش داده می‌شود.',
        'uploadArea' => 'فایل‌ها را اینجا بکشید و رها کنید، یا',
        'chooseFiles' => 'انتخاب فایل‌ها',
        'uploading' => 'در حال بارگذاری',
        'uploaded' => 'بارگذاری شد',
        'uploadErrorSize' => 'حجم فایل بیش از حد مجاز سرور است.',
        'uploadErrorType' => 'این پسوند فایل مجاز نیست.',
        'uploadError' => 'بارگذاری ناموفق بود.',
        'empty' => 'هیچ فایلی یافت نشد.',
        'emptyFolder' => 'این پوشه خالی است.',
        'emptyFolderSub' => 'فایل‌های دستی این پوشه یا حذف شده‌اند یا هنوز چیزی در آن قرار نگرفته است.',
        'file' => 'فایل',
        'image' => 'تصویر',
        'folder' => 'پوشه',
        'parentFolder' => 'پوشه بالاتر',
        'uploadFolder' => 'پوشه‌ی بارگذاری',
        'copyAllSelected' => 'کپی',
        'justNow' => 'همین حالا',
        'itemsUnit' => 'مورد',
        'deleteDoneReload' => 'حذف انجام شد؛ در حال نوسازی…',
        'newFolder' => 'پوشه جدید',
        'folderNamePh' => 'نام پوشه جدید… (مثلاً: docs)',
        'createFolder' => 'ایجاد پوشه',
        'cancel' => 'انصراف',
        'folderCreated' => 'پوشه ساخته شد؛ در حال بازکردن…',
        'folderInvalidName' => 'نام پوشه معتبر نیست (فقط حروف، اعداد، فاصله، نقطه، خط تیره و زیرخط؛ حداکثر ۹۶ کاراکتر؛ نام نباید با نقطه شروع شود).',
        'mkdirError' => 'ایجاد پوشه ناموفق بود.',
        // تغییر نام و حذف پوشه
        'renameFolder' => 'تغییر نام پوشه',
        'renameFolderHint' => 'نام جدید پوشه «%s» را وارد کنید:',
        'renameSave' => 'ذخیره',
        'renameDone' => 'نام پوشه تغییر کرد؛ در حال نوسازی…',
        'renameError' => 'تغییر نام پوشه ناموفق بود؛ ممکن است دسترسی یا توکن منقضی شده باشد.',
        'deleteFolder' => 'حذف پوشه',
        'deleteFolderConfirm' => 'پوشه «%s» حذف شود؟ (فقط پوشه‌های خالی قابل حذف‌اند)',
        'deleteFolderConfirmYes' => 'حذف پوشه',
        'folderDeleted' => 'پوشه حذف شد؛ در حال نوسازی…',
        'folderDeleteError' => 'حذف پوشه ناموفق بود؛ ممکن است دسترسی یا توکن منقضی شده باشد.',
        // انتقال فایل‌ها به پوشه‌ی دیگر
        'move' => 'انتقال',
        'moveSelected' => 'انتقال به پوشه',
        'moveTitle' => 'انتقال به پوشه‌ی دیگر',
        'moveTargetLabel' => 'پوشه‌ی مقصد را انتخاب کنید:',
        'moveRootLabel' => 'ریشه‌ی uploads',
        'moveCurrentLabel' => 'محل فعلی',
        'moveFilesUnit' => 'فایل انتخاب‌شده',
        'moveMore' => 'مورد دیگر',
        'moveWarning' => 'اگر لینک این فایل‌ها داخل متن نوشته‌ها استفاده شده باشد، آدرس‌ها به‌روزرسانی نمی‌شوند و پس از انتقال باید لینک‌ها را در نوشته‌ها اصلاح کنید.',
        'moveNoTarget' => 'ابتدا پوشه‌ی مقصد را انتخاب کنید.',
        'moveSameTarget' => 'فایل‌های انتخابی همین‌جا هستند؛ پوشه‌ی دیگری انتخاب کنید.',
        'moveTreeError' => 'دریافت فهرست پوشه‌ها ناموفق بود.',
        'moveDone' => 'انتقال انجام شد؛ در حال نوسازی…',
        'moveError' => 'انتقال ناموفق بود؛ ممکن است دسترسی یا توکن منقضی شده باشد.',
        'moveLoadingTree' => 'در حال دریافت پوشه‌ها…',
        // تغییر نام فایل (عنوان کتابخانه یا نام فیزیکی)
        'renameFile' => 'تغییر نام فایل',
        'renameFileHint' => 'نام جدید فایل «%s» را وارد کنید (پسوند فایل حفظ می‌شود):',
        'renameFileTitleHint' => 'عنوان جدید «%s» را وارد کنید (نام فایل روی سرور تغییر نمی‌کند):',
        'renameFileDone' => 'نام فایل تغییر کرد؛ در حال نوسازی…',
        'renameTitleDone' => 'عنوان فایل تغییر کرد؛ در حال نوسازی…',
        'renameFileError' => 'تغییر نام فایل ناموفق بود؛ ممکن است دسترسی یا توکن منقضی شده باشد.',
        'renameFileInvalid' => 'نام فایل معتبر نیست (حداکثر ۹۶ کاراکتر؛ فقط حروف، اعداد، فاصله، نقطه، خط تیره و زیرخط).',
        'renameTitleInvalid' => 'عنوان جدید نمی‌تواند خالی باشد.',
        // فیلتر نوع فایل
        'filters' => 'نوع فایل',
        // سطل زباله (حذف نرم) — نسخه ۱.۸.۰؛ لیست و عملیات سطل به
        // صفحه‌ی اختصاصی (TrashPage.php) منتقل شده و اینجا فقط دکمه‌ی
        // ورود به آن باقی مانده است.
        'trash' => 'سطل بازیافت',
    ],
];

// کش‌شکن هر فایل: نسخه + زمان تغییر خود فایل (تا با نسخه‌های تکراری هم
// فایل تازه از کش رد نشود)
$versionCss = Text::assetCacheParam('assets/panel.css');
$versionJs = Text::assetCacheParam('assets/panel.js');

// چیپ‌های فیلتر نوع فایل — مشترک بین هر دو نمای مرور و کتابخانه.
// نکته: در نمای مرور، پوشه‌ی جاری (path) و عبارت جستجو (keywords) هم در
// لینک چیپ‌ها حفظ می‌شود تا کلیک روی فیلتر، کاربر را به ریشه برنگرداند؛
// انتخاب فیلتر و ورود به پوشه‌ها در هر ترتیبی ممکن است.
$chipContext = ($view === 'browse') ? ['path' => $browsePath, 'keywords' => $keywords] : [];
$filterChipsNav = '';
foreach (Icons::FILTER_LABELS as $filterKey => $filterLabel) {
    $filterActive = ($kind === '' && $filterKey === 'all') || $kind === $filterKey;
    $filterHref = $filterKey === 'all'
        ? ($view === 'browse' ? $browseUrl(array_merge($chipContext, ['kind' => null])) : $libraryUrl(['kind' => null]))
        : ($view === 'browse' ? $browseUrl(array_merge($chipContext, ['kind' => $filterKey])) : $libraryUrl(['kind' => $filterKey]));
    $filterChipsNav .= '<a class="mm-filter-chip' . ($filterActive ? ' is-active' : '') . '"'
        . ' href="' . Text::e($filterHref) . '"'
        . ' aria-current="' . ($filterActive ? 'true' : 'false') . '">'
        . Text::e($filterLabel) . '</a>';
}
?>
<div class="mm-wrap" dir="rtl">
    <section class="mm-head">
        <div class="mm-head-main">
            <h2 class="mm-title">
                <?php echo Icons::svg('image'); ?>
                <?php echo Text::e('مدیا منیجر'); ?>
            </h2>
            <p class="mm-subtitle"><?php echo Text::e('کتابخانه تصاویر و فایل‌های سایت — مرور پوشه‌ی uploads، انتخاب چندگانه، کپی لینک برای درج در پست‌ها، حذف و بارگذاری فایل جدید'); ?></p>
        </div>
        <div class="mm-head-actions">
            <span class="mm-count-pill" id="mm-count-pill"><?php echo Text::e($faNum('0') . ' مورد انتخاب‌شده'); ?></span>
            <button type="button" class="btn btn-s" id="mm-select-all"><?php echo Text::e('انتخاب همه'); ?></button>
            <button type="button" class="btn btn-s primary" id="mm-copy-links">
                <?php echo Icons::svg('link'); ?>
                <?php echo Text::e('کپی لینک تصاویر انتخابی'); ?>
            </button>
            <?php if ($canBrowse && $view === 'browse'): ?>
            <button type="button" class="btn btn-s mm-move-btn" id="mm-move-selected">
                <?php echo Icons::svg('folder-input'); ?>
                <?php echo Text::e('انتقال به پوشه'); ?>
            </button>
            <?php endif; ?>
            <button type="button" class="btn btn-s btn-warn" id="mm-delete-selected">
                <?php echo Icons::svg('trash-2'); ?>
                <?php echo Text::e('حذف انتخاب‌شده‌ها'); ?>
            </button>
            <?php if ($canBrowse): ?>
            <a class="btn btn-s mm-trash-btn" id="mm-trash-btn"
               href="<?php echo Text::e($trashPageUrl); ?>"
               title="<?php echo Text::e('سطل بازیافت — فایل‌های حذف‌شده'); ?>">
                <?php echo Icons::svg('trash-2'); ?>
                <?php echo Text::e('سطل بازیافت'); ?>
                <span class="mm-trash-count<?php echo $trashCount > 0 ? ' is-nonzero' : ''; ?>" id="mm-trash-count"><span class="mm-num"><?php echo Text::e($faNum((string) $trashCount)); ?></span></span>
            </a>
            <?php endif; ?>
        </div>
    </section>

    <?php if ($canBrowse): ?>
    <nav class="mm-view-switch" aria-label="<?php echo Text::e('انتخاب نمای نمایش'); ?>">
        <a class="btn btn-s<?php echo $view === 'browse' ? ' primary' : ''; ?>" href="<?php echo Text::e($browseUrl()); ?>">
            <?php echo Icons::svg('folder-open'); ?>
            <?php echo Text::e('مرور پوشه‌ها'); ?>
        </a>
        <a class="btn btn-s<?php echo $view === 'library' ? ' primary' : ''; ?>" href="<?php echo Text::e($libraryUrl()); ?>">
            <?php echo Icons::svg('layout-grid'); ?>
            <?php echo Text::e('کتابخانه'); ?>
        </a>
    </nav>
    <?php endif; ?>

    <section class="mm-upload" id="mm-upload-section">
        <div class="mm-upload-area" id="mm-upload-area" role="button" tabindex="0"
             aria-label="<?php echo Text::e('بارگذاری فایل جدید'); ?>">
            <?php echo Icons::svg('upload', 'mm-ico mm-ico-lg mm-upload-icon'); ?>
            <p class="mm-upload-text">
                <?php echo Text::e('فایل‌ها را اینجا بکشید و رها کنید، یا'); ?>
                <button type="button" class="btn btn-s" id="mm-choose-files"><?php echo Text::e('انتخاب فایل‌ها'); ?></button>
            </p>
            <p class="mm-upload-hint">
                <?php echo Text::e('پسوندهای مجاز:'); ?>
                <span class="mm-upload-types"><?php echo Text::e(implode('، ', $allowedTypes)); ?></span>
            </p>
            <?php if ($view === 'browse' && $canBrowse && $browsePath !== ''): ?>
                <p class="mm-upload-dest mm-upload-dest-folder">
                    <?php echo Icons::svg('folder', 'mm-ico mm-ico-sm'); ?>
                    <span><?php echo Text::e('فایل‌های جدید مستقیماً در همین پوشه ذخیره می‌شوند:'); ?>
                        <strong><?php echo Text::e($browsePath); ?></strong></span>
                </p>
            <?php else: ?>
                <p class="mm-upload-dest">
                    <?php echo Icons::svg('folder', 'mm-ico mm-ico-sm'); ?>
                    <span><?php echo Text::e('فایل‌های جدید در پوشه‌ی پیش‌فرض ماه ذخیره می‌شوند:'); ?>
                        <strong><?php echo Text::e($uploadFolderPath); ?></strong></span>
                </p>
            <?php endif; ?>
            <?php if (Webp::enabled()): ?>
                <?php $webpQualityNum = $faNum((string) Webp::quality()); ?>
                <p class="mm-upload-dest mm-upload-dest-webp">
                    <?php echo Icons::svg('zap', 'mm-ico mm-ico-sm'); ?>
                    <span><?php echo Text::e('تبدیل خودکار به WebP فعال است — تصاویر JPG/JPEG/PNG هنگام آپلود فشرده می‌شوند (کیفیت '); ?><span class="mm-num"><?php echo Text::e($webpQualityNum); ?></span><?php echo Text::e(') تا حجم کتابخانه و پهنای مصرفی صفحه کم شود.'); ?></span>
                </p>
            <?php endif; ?>
        </div>
        <input type="file" id="mm-file-input" multiple hidden>
        <ul class="mm-upload-list" id="mm-upload-list" aria-live="polite"></ul>
    </section>

    <?php if ($view === 'browse'): ?>
        <?php $searchAction = $browseUrl(); ?>
        <form class="mm-search" method="get" action="<?php echo Text::e($panelBase); ?>" role="search">
            <input type="hidden" name="panel" value="<?php echo Text::e($panelSelf); ?>">
            <input type="hidden" name="view" value="browse">
            <?php if ($kind !== ''): ?>
                <input type="hidden" name="kind" value="<?php echo Text::e($kind); ?>">
            <?php endif; ?>
            <input type="hidden" name="path" value="<?php echo Text::e($browsePath); ?>">
            <label class="sr-only" for="mm-keywords"><?php echo Text::e('جستجوی نام فایل'); ?></label>
            <input type="text" id="mm-keywords" name="keywords" class="text-s"
                   placeholder="<?php echo Text::e('جستجو در این پوشه…'); ?>"
                   value="<?php echo Text::e($keywords); ?>">
            <button type="submit" class="btn btn-s">
                <?php echo Icons::svg('search'); ?>
                <?php echo Text::e('جستجو'); ?>
            </button>
            <?php if ($keywords !== ''): ?>
                <a class="btn btn-s" href="<?php echo Text::e($browseUrl(['path' => $browsePath])); ?>"><?php echo Text::e('حذف فیلتر'); ?></a>
            <?php endif; ?>
        </form>

        <nav class="mm-filters" aria-label="<?php echo Text::e('فیلتر نوع فایل'); ?>">
            <?php echo $filterChipsNav; ?>
        </nav>

        <?php if ($browseError !== ''): ?>
            <div class="mm-notice mm-notice-error">
                <?php echo Icons::svg('x'); ?>
                <span><?php echo Text::e($browseError); ?></span>
                <a class="btn btn-s" href="<?php echo Text::e($browseUrl(['path' => ''])); ?>"><?php echo Text::e('بازگشت به ریشه‌ی uploads'); ?></a>
            </div>
        <?php else: ?>
            <?php
            $breadcrumbs = $browseData['breadcrumbs'];
            $parentPath = $browseData['parentPath'];
            $folders = $browseData['folders'];
            $files = $browseData['files'];
            $totalFiles = (int) $browseData['totalFiles'];
            $totalPages = max(1, (int) ceil($totalFiles / (int) $browseData['pageSize']));
            ?>
            <nav class="mm-breadcrumb" aria-label="<?php echo Text::e('مسیر پوشه جاری'); ?>">
                <?php if ($parentPath !== null): ?>
                    <a class="btn btn-s mm-breadcrumb-up" href="<?php echo Text::e($browseUrl(['path' => $parentPath])); ?>" title="<?php echo Text::e('پوشه بالاتر'); ?>">
                        <?php echo Icons::svg('arrow-up'); ?>
                        <span class="sr-only"><?php echo Text::e('پوشه بالاتر'); ?></span>
                    </a>
                <?php endif; ?>
                <ol class="mm-breadcrumb-list">
                    <?php foreach ($breadcrumbs as $index => $crumb): ?>
                        <li class="mm-breadcrumb-item<?php echo $index === count($breadcrumbs) - 1 ? ' mm-breadcrumb-current' : ''; ?>">
                            <?php if ($index === 0): ?>
                                <?php echo Icons::svg('hard-drive', 'mm-ico mm-ico-sm'); ?>
                            <?php endif; ?>
                            <?php if ($index === count($breadcrumbs) - 1): ?>
                                <span class="mm-breadcrumb-name" aria-current="page"><?php echo Text::e($crumb['name']); ?></span>
                            <?php else: ?>
                                <a class="mm-breadcrumb-name" href="<?php echo Text::e($browseUrl(['path' => $crumb['path']])); ?>"><?php echo Text::e($crumb['name']); ?></a>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ol>
                <span class="mm-breadcrumb-count">
                    <span class="mm-num"><?php echo Text::e($faNum(number_format(count($folders)))); ?></span> <?php echo Text::e('پوشه'); ?>
                    <span class="mm-dot">·</span>
                    <span class="mm-num"><?php echo Text::e($faNum(number_format($totalFiles))); ?></span> <?php echo Text::e('فایل'); ?>
                </span>
                <button type="button" class="btn btn-s mm-newfolder-btn" id="mm-newfolder-btn"
                        title="<?php echo Text::e('ایجاد پوشه جدید در همین مسیر'); ?>">
                    <?php echo Icons::svg('folder-plus', 'mm-ico mm-ico-sm'); ?>
                    <?php echo Text::e('پوشه جدید'); ?>
                </button>
            </nav>

            <form class="mm-newfolder" id="mm-newfolder-form" hidden autocomplete="off">
                <label class="sr-only" for="mm-newfolder-name"><?php echo Text::e('نام پوشه جدید'); ?></label>
                <input type="text" id="mm-newfolder-name" class="text-s" maxlength="96"
                       placeholder="<?php echo Text::e('نام پوشه جدید… (مثلاً: docs)'); ?>"
                       autocomplete="off" spellcheck="false">
                <button type="submit" class="btn btn-s primary" id="mm-newfolder-create">
                    <?php echo Icons::svg('folder-plus', 'mm-ico mm-ico-sm'); ?>
                    <?php echo Text::e('ایجاد پوشه'); ?>
                </button>
                <button type="button" class="btn btn-s" id="mm-newfolder-cancel"><?php echo Text::e('انصراف'); ?></button>
            </form>

            <?php if (!empty($folders)): ?>
            <div class="mm-folders" id="mm-folders">
                <?php foreach ($folders as $folder): ?>
                    <?php $folderPath = ($browsePath === '' ? '' : $browsePath . '/') . $folder['name']; ?>
                    <div class="mm-folder" data-path="<?php echo Text::e($folderPath); ?>" data-name="<?php echo Text::e($folder['name']); ?>">
                        <a class="mm-folder-main" href="<?php echo Text::e($browseUrl(['path' => $folderPath])); ?>">
                            <span class="mm-folder-icon"><?php echo Icons::svg('folder', 'mm-ico mm-ico-lg'); ?></span>
                            <span class="mm-folder-body">
                                <span class="mm-folder-name" title="<?php echo Text::e($folder['name']); ?>"><?php echo Text::e($folder['name']); ?></span>
                                <span class="mm-folder-count"><span class="mm-num"><?php echo Text::e($faNum(number_format($folder['files']))); ?></span> <?php echo Text::e('مورد'); ?></span>
                            </span>
                            <?php echo Icons::svg('chevron-left', 'mm-ico mm-ico-sm mm-folder-arrow'); ?>
                        </a>
                        <span class="mm-folder-tools">
                            <button type="button" class="mm-folder-tool mm-folder-rename"
                                    title="<?php echo Text::e('تغییر نام پوشه'); ?>"
                                    aria-label="<?php echo Text::e('تغییر نام پوشه: ' . $folder['name']); ?>">
                                <?php echo Icons::svg('pencil', 'mm-ico mm-ico-sm'); ?>
                            </button>
                            <button type="button" class="mm-folder-tool mm-folder-delete"
                                    title="<?php echo Text::e('حذف پوشه'); ?>"
                                    aria-label="<?php echo Text::e('حذف پوشه: ' . $folder['name']); ?>">
                                <?php echo Icons::svg('trash-2', 'mm-ico mm-ico-sm'); ?>
                            </button>
                        </span>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <form id="mm-grid-form" method="post" action="<?php echo Text::e($deleteUrl); ?>">
                <input type="hidden" name="do" value="delete">
                <div class="mm-grid<?php echo (empty($files) && empty($folders)) ? ' mm-grid-empty' : ''; ?>" id="mm-grid">
                    <?php if (!empty($files)): ?>
                        <?php foreach ($files as $file): ?>
                            <?php
                            $cid = (int) $file['cid'];
                            $itemUrl = (string) $file['url'];
                            $isImage = (bool) $file['isImage'];
                            $itemTitle = (string) $file['title'];
                            $itemSize = (int) $file['size'];
                            $itemType = (string) $file['type'];
                            $itemKind = Icons::fileKind($itemType);
                            ?>
                            <figure class="mm-item<?php echo $isImage ? ' mm-item-image' : ' mm-item-file'; ?>"
                                    data-cid="<?php echo $cid; ?>"
                                    data-path="<?php echo Text::e($file['path']); ?>"
                                    data-url="<?php echo Text::e($itemUrl); ?>"
                                    data-title="<?php echo Text::e($itemTitle); ?>"
                                    data-image="<?php echo $isImage ? '1' : '0'; ?>"
                                    data-size="<?php echo $itemSize; ?>"
                                    data-type="<?php echo Text::e($itemType); ?>">
                                <label class="mm-check" title="<?php echo Text::e('انتخاب'); ?>">
                                    <input type="checkbox" name="<?php echo $cid > 0 ? 'cid[]' : 'path[]'; ?>" value="<?php echo $cid > 0 ? $cid : Text::e($file['path']); ?>">
                                </label>

                                <button type="button" class="mm-thumb<?php echo $isImage ? '' : ' mm-thumb-file'; ?>"
                                        <?php if (!$isImage): ?>data-ext="<?php echo Text::e($itemType !== '' ? $itemType : 'file'); ?>"<?php endif; ?>
                                        title="<?php echo Text::e('پیش‌نمایش: ' . $itemTitle); ?>"
                                        aria-label="<?php echo Text::e('پیش‌نمایش: ' . $itemTitle); ?>">
                                    <?php if ($isImage): ?>
                                        <img src="<?php echo Text::e($itemUrl); ?>" alt="<?php echo Text::e($itemTitle); ?>" loading="lazy" decoding="async">
                                    <?php else: ?>
                                        <span class="mm-file-icon mm-kind-<?php echo Text::e($itemKind); ?>" title="<?php echo Text::e(Icons::kindLabel($itemKind)); ?>">
                                            <?php echo Icons::svg(Icons::kindIcon($itemKind), 'mm-ico mm-ico-file'); ?>
                                        </span>
                                    <?php endif; ?>
                                </button>

                                <figcaption class="mm-meta">
                                    <span class="mm-name" title="<?php echo Text::e($itemTitle); ?>"><?php echo Text::e($itemTitle); ?></span>
                                    <span class="mm-info">
                                        <span class="mm-bytes"><?php echo Text::e($faNum((string) $file['bytes'])); ?></span>
                                        <span class="mm-dot">·</span>
                                        <?php if ($cid > 0): ?>
                                            <span class="mm-badge mm-badge-db" title="<?php echo Text::e('ثبت‌شده در کتابخانه'); ?>"><?php echo Text::e('کتابخانه'); ?></span>
                                            <span class="mm-dot">·</span>
                                        <?php else: ?>
                                            <span class="mm-badge" title="<?php echo Text::e('فایل دستی — فقط روی دیسک'); ?>"><?php echo Text::e('دستی'); ?></span>
                                            <span class="mm-dot">·</span>
                                        <?php endif; ?>
                                        <?php echo Text::e((new \Typecho\Date($file['mtime']))->word()); ?>
                                    </span>
                                    <div class="mm-item-actions">
                                        <button type="button" class="mm-mini-btn mm-copy" title="<?php echo Text::e('کپی لینک'); ?>">
                                            <?php echo Icons::svg('link', 'mm-ico mm-ico-sm'); ?>
                                            <span><?php echo Text::e('کپی لینک'); ?></span>
                                        </button>
                                        <button type="button" class="mm-mini-btn mm-file-rename-btn"
                                                data-cid="<?php echo $cid; ?>"
                                                data-path="<?php echo Text::e($file['path']); ?>"
                                                data-name="<?php echo Text::e($file['name']); ?>"
                                                data-title="<?php echo Text::e($itemTitle); ?>"
                                                title="<?php echo Text::e('تغییر نام فایل'); ?>">
                                            <?php echo Icons::svg('pencil', 'mm-ico mm-ico-sm'); ?>
                                            <span><?php echo Text::e('تغییر نام'); ?></span>
                                        </button>
                                        <button type="button" class="mm-mini-btn mm-move" data-path="<?php echo Text::e($file['path']); ?>"
                                                title="<?php echo Text::e('انتقال این فایل به پوشه‌ی دیگر'); ?>">
                                            <?php echo Icons::svg('folder-input', 'mm-ico mm-ico-sm'); ?>
                                            <span><?php echo Text::e('انتقال'); ?></span>
                                        </button>
                                        <?php if ($cid > 0): ?>
                                            <a class="mm-mini-btn" href="<?php echo $options->adminUrl('media.php?cid=' . $cid); ?>" title="<?php echo Text::e('ویرایش فایل'); ?>">
                                                <?php echo Icons::svg('pencil', 'mm-ico mm-ico-sm'); ?>
                                                <span><?php echo Text::e('ویرایش'); ?></span>
                                            </a>
                                        <?php endif; ?>
                                        <?php if ($isImage): ?>
                                            <button type="button" class="mm-mini-btn" data-mm-preview title="<?php echo Text::e('پیش‌نمایش'); ?>">
                                                <?php echo Icons::svg('eye', 'mm-ico mm-ico-sm'); ?>
                                                <span><?php echo Text::e('پیش‌نمایش'); ?></span>
                                            </button>
                                        <?php else: ?>
                                            <a class="mm-mini-btn" href="<?php echo Text::e($itemUrl); ?>" target="_blank" rel="noopener noreferrer" title="<?php echo Text::e('مشاهده فایل'); ?>">
                                                <?php echo Icons::svg('external-link', 'mm-ico mm-ico-sm'); ?>
                                                <span><?php echo Text::e('مشاهده'); ?></span>
                                            </a>
                                        <?php endif; ?>
                                        <button type="button" class="mm-mini-btn mm-delete" data-cid="<?php echo $cid; ?>"
                                                <?php if ($cid === 0): ?>data-path="<?php echo Text::e($file['path']); ?>"<?php endif; ?>
                                                title="<?php echo Text::e($cid > 0 ? 'حذف این فایل' : 'حذف فیزیکی این فایل'); ?>">
                                            <?php echo Icons::svg('trash-2', 'mm-ico mm-ico-sm'); ?>
                                            <span><?php echo Text::e('حذف'); ?></span>
                                        </button>
                                    </div>
                                </figcaption>
                            </figure>
                        <?php endforeach; ?>
                    <?php elseif (empty($folders)): ?>
                        <div class="mm-empty-state">
                            <?php echo Icons::svg('folder-open', 'mm-ico mm-ico-lg'); ?>
                            <p><?php echo Text::e('این پوشه خالی است.'); ?></p>
                            <p class="mm-empty-sub"><?php echo Text::e('فایل‌های دستی این پوشه یا حذف شده‌اند یا هنوز چیزی در آن قرار نگرفته است.'); ?></p>
                        </div>
                    <?php else: ?>
                        <div class="mm-empty-state mm-empty-files">
                            <?php echo Icons::svg('file', 'mm-ico mm-ico-lg'); ?>
                            <p><?php echo Text::e('در این پوشه فایلی وجود ندارد؛ فقط زیرپوشه‌ها را ببینید.'); ?></p>
                        </div>
                    <?php endif; ?>
                </div>

                <?php if ($totalPages > 1): ?>
                    <nav class="mm-pager" aria-label="<?php echo Text::e('صفحه‌بندی فایل‌ها'); ?>">
                        <?php if ($page > 1): ?>
                            <a class="btn btn-s" href="<?php echo Text::e($browseUrl(['path' => $browsePath, 'page' => $page - 1, 'keywords' => $keywords])); ?>">
                                <?php echo Icons::svg('chevron-right', 'mm-ico mm-ico-sm'); ?>
                                <?php echo Text::e('قبلی'); ?>
                            </a>
                        <?php endif; ?>
                        <span class="mm-pager-status"><?php echo Text::e('صفحه '); ?><span class="mm-num"><?php echo Text::e($faNum($page)); ?></span><?php echo Text::e(' از '); ?><span class="mm-num"><?php echo Text::e($faNum($totalPages)); ?></span><?php echo Text::e(' — '); ?><span class="mm-num"><?php echo Text::e($faNum(number_format($totalFiles))); ?></span> <?php echo Text::e('فایل'); ?></span>
                        <?php if ($page < $totalPages): ?>
                            <a class="btn btn-s" href="<?php echo Text::e($browseUrl(['path' => $browsePath, 'page' => $page + 1, 'keywords' => $keywords])); ?>">
                                <?php echo Text::e('بعدی'); ?>
                                <?php echo Icons::svg('chevron-left', 'mm-ico mm-ico-sm'); ?>
                            </a>
                        <?php endif; ?>
                    </nav>
                <?php endif; ?>
            </form>
        <?php endif; ?>

    <?php else: ?>
        <?php $searchAction = $libraryUrl(); ?>
        <form class="mm-search" method="get" action="<?php echo Text::e($panelBase); ?>" role="search">
            <input type="hidden" name="panel" value="<?php echo Text::e($panelSelf); ?>">
            <input type="hidden" name="view" value="library">
            <?php if ($kind !== ''): ?>
                <input type="hidden" name="kind" value="<?php echo Text::e($kind); ?>">
            <?php endif; ?>
            <label class="sr-only" for="mm-keywords"><?php echo Text::e('جستجوی نام فایل'); ?></label>
            <input type="text" id="mm-keywords" name="keywords" class="text-s"
                   placeholder="<?php echo Text::e('جستجوی نام فایل…'); ?>"
                   value="<?php echo Text::e($keywords); ?>">
            <button type="submit" class="btn btn-s">
                <?php echo Icons::svg('search'); ?>
                <?php echo Text::e('جستجو'); ?>
            </button>
            <?php if ($keywords !== ''): ?>
                <a class="btn btn-s" href="<?php echo Text::e($libraryUrl()); ?>"><?php echo Text::e('حذف فیلتر'); ?></a>
            <?php endif; ?>
        </form>

        <nav class="mm-filters" aria-label="<?php echo Text::e('فیلتر نوع فایل'); ?>">
            <?php echo $filterChipsNav; ?>
        </nav>

        <form id="mm-grid-form" method="post" action="<?php echo Text::e($deleteUrl); ?>">
            <input type="hidden" name="do" value="delete">
            <div class="mm-grid<?php echo !empty($libraryItems) ? '' : ' mm-grid-empty'; ?>" id="mm-grid">
                <?php if (!empty($libraryItems)): ?>
                    <?php foreach ($libraryItems as $item): ?>
                        <?php
                        $cid = (int) $item['cid'];
                        $itemUrl = (string) $item['url'];
                        $isImage = (bool) $item['isImage'];
                        $itemTitle = (string) $item['title'];
                        $itemSize = (int) $item['size'];
                        $itemType = (string) $item['type'];
                        $itemKind = Icons::fileKind($itemType);
                        ?>
                        <figure class="mm-item<?php echo $isImage ? ' mm-item-image' : ' mm-item-file'; ?>"
                                data-cid="<?php echo $cid; ?>"
                                data-url="<?php echo Text::e($itemUrl); ?>"
                                data-title="<?php echo Text::e($itemTitle); ?>"
                                data-image="<?php echo $isImage ? '1' : '0'; ?>"
                                data-size="<?php echo $itemSize; ?>"
                                data-type="<?php echo Text::e($itemType); ?>">
                            <label class="mm-check" title="<?php echo Text::e('انتخاب'); ?>">
                                <input type="checkbox" name="cid[]" value="<?php echo $cid; ?>">
                            </label>

                            <button type="button" class="mm-thumb<?php echo $isImage ? '' : ' mm-thumb-file'; ?>"
                                    <?php if (!$isImage): ?>data-ext="<?php echo Text::e($itemType !== '' ? $itemType : 'file'); ?>"<?php endif; ?>
                                    title="<?php echo Text::e('پیش‌نمایش: ' . $itemTitle); ?>"
                                    aria-label="<?php echo Text::e('پیش‌نمایش: ' . $itemTitle); ?>">
                                <?php if ($isImage): ?>
                                    <img src="<?php echo Text::e($itemUrl); ?>" alt="<?php echo Text::e($itemTitle); ?>" loading="lazy" decoding="async">
                                <?php else: ?>
                                    <span class="mm-file-icon mm-kind-<?php echo Text::e($itemKind); ?>" title="<?php echo Text::e(Icons::kindLabel($itemKind)); ?>">
                                        <?php echo Icons::svg(Icons::kindIcon($itemKind), 'mm-ico mm-ico-file'); ?>
                                    </span>
                                <?php endif; ?>
                            </button>

                            <figcaption class="mm-meta">
                                <span class="mm-name" title="<?php echo Text::e($itemTitle); ?>"><?php echo Text::e($itemTitle); ?></span>
                                <span class="mm-info">
                                    <span class="mm-bytes"><?php echo Text::e($faNum((string) $item['bytes'])); ?></span>
                                    <span class="mm-dot">·</span>
                                    <?php echo Text::e((new \Typecho\Date((int) $item['created']))->word()); ?>
                                </span>
                                <div class="mm-item-actions">
                                    <button type="button" class="mm-mini-btn mm-copy" title="<?php echo Text::e('کپی لینک'); ?>">
                                        <?php echo Icons::svg('link', 'mm-ico mm-ico-sm'); ?>
                                        <span><?php echo Text::e('کپی لینک'); ?></span>
                                    </button>
                                    <button type="button" class="mm-mini-btn mm-file-rename-btn"
                                            data-cid="<?php echo $cid; ?>"
                                            data-path=""
                                            data-name=""
                                            data-title="<?php echo Text::e($itemTitle); ?>"
                                            title="<?php echo Text::e('تغییر نام فایل'); ?>">
                                        <?php echo Icons::svg('pencil', 'mm-ico mm-ico-sm'); ?>
                                        <span><?php echo Text::e('تغییر نام'); ?></span>
                                    </button>
                                    <a class="mm-mini-btn" href="<?php echo $options->adminUrl('media.php?cid=' . $cid); ?>" title="<?php echo Text::e('ویرایش فایل'); ?>">
                                        <?php echo Icons::svg('pencil', 'mm-ico mm-ico-sm'); ?>
                                        <span><?php echo Text::e('ویرایش'); ?></span>
                                    </a>
                                    <?php if ($isImage): ?>
                                        <button type="button" class="mm-mini-btn" data-mm-preview title="<?php echo Text::e('پیش‌نمایش'); ?>">
                                            <?php echo Icons::svg('eye', 'mm-ico mm-ico-sm'); ?>
                                            <span><?php echo Text::e('پیش‌نمایش'); ?></span>
                                        </button>
                                    <?php else: ?>
                                        <a class="mm-mini-btn" href="<?php echo Text::e($itemUrl); ?>" target="_blank" rel="noopener noreferrer" title="<?php echo Text::e('مشاهده فایل'); ?>">
                                            <?php echo Icons::svg('external-link', 'mm-ico mm-ico-sm'); ?>
                                            <span><?php echo Text::e('مشاهده'); ?></span>
                                        </a>
                                    <?php endif; ?>
                                    <button type="button" class="mm-mini-btn mm-delete" data-cid="<?php echo $cid; ?>" title="<?php echo Text::e('حذف این فایل'); ?>">
                                        <?php echo Icons::svg('trash-2', 'mm-ico mm-ico-sm'); ?>
                                        <span><?php echo Text::e('حذف'); ?></span>
                                    </button>
                                </div>
                            </figcaption>
                        </figure>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="mm-empty-state">
                        <?php echo Icons::svg('image', 'mm-ico mm-ico-lg'); ?>
                        <p><?php echo Text::e('هیچ فایلی یافت نشد.'); ?></p>
                        <p class="mm-empty-sub"><?php echo Text::e('فیلتر را عوض کنید یا با بارگذاری فایل از بخش بالا، رسانه‌ی جدیدی به کتابخانه اضافه کنید.'); ?></p>
                    </div>
                <?php endif; ?>
            </div>

            <?php if ($libraryPages > 1): ?>
                <nav class="mm-pager" aria-label="<?php echo Text::e('صفحه‌بندی فایل‌ها'); ?>">
                    <?php if ($libraryPage > 1): ?>
                        <a class="btn btn-s" href="<?php echo Text::e($libraryUrl(['page' => $libraryPage - 1])); ?>">
                            <?php echo Icons::svg('chevron-right', 'mm-ico mm-ico-sm'); ?>
                            <?php echo Text::e('قبلی'); ?>
                        </a>
                    <?php endif; ?>
                    <span class="mm-pager-status"><?php echo Text::e('صفحه '); ?><span class="mm-num"><?php echo Text::e($faNum($libraryPage)); ?></span><?php echo Text::e(' از '); ?><span class="mm-num"><?php echo Text::e($faNum($libraryPages)); ?></span><?php echo Text::e(' — '); ?><span class="mm-num"><?php echo Text::e($faNum(number_format($libraryTotal))); ?></span> <?php echo Text::e('فایل'); ?></span>
                    <?php if ($libraryPage < $libraryPages): ?>
                        <a class="btn btn-s" href="<?php echo Text::e($libraryUrl(['page' => $libraryPage + 1])); ?>">
                            <?php echo Text::e('بعدی'); ?>
                            <?php echo Icons::svg('chevron-left', 'mm-ico mm-ico-sm'); ?>
                        </a>
                    <?php endif; ?>
                </nav>
            <?php endif; ?>
        </form>
    <?php endif; ?>
</div>

<div class="mm-modal" id="mm-lightbox" hidden dir="rtl" role="dialog" aria-modal="true" aria-label="<?php echo Text::e('پیش‌نمایش تصویر'); ?>">
    <div class="mm-modal-backdrop" data-mm-close></div>
    <div class="mm-modal-box mm-lightbox-box">
        <header class="mm-modal-head">
            <strong class="mm-modal-title" id="mm-lightbox-title"></strong>
            <button type="button" class="mm-modal-close" data-mm-close title="<?php echo Text::e('بستن (Esc)'); ?>">
                <?php echo Icons::svg('x'); ?>
            </button>
        </header>
        <div class="mm-lightbox-body">
            <img id="mm-lightbox-img" src="" alt="">
        </div>
        <footer class="mm-modal-foot">
            <span class="mm-lightbox-url mono" id="mm-lightbox-url"></span>
            <button type="button" class="btn btn-s primary" id="mm-lightbox-copy">
                <?php echo Icons::svg('link'); ?>
                <?php echo Text::e('کپی لینک'); ?>
            </button>
        </footer>
    </div>
</div>

<div class="mm-modal" id="mm-links-modal" hidden dir="rtl" role="dialog" aria-modal="true" aria-label="<?php echo Text::e('لینک تصاویر انتخاب‌شده'); ?>">
    <div class="mm-modal-backdrop" data-mm-close></div>
    <div class="mm-modal-box mm-links-box">
        <header class="mm-modal-head">
            <strong class="mm-modal-title"><?php echo Text::e('لینک تصاویر انتخاب‌شده'); ?></strong>
            <button type="button" class="mm-modal-close" data-mm-close title="<?php echo Text::e('بستن (Esc)'); ?>">
                <?php echo Icons::svg('x'); ?>
            </button>
        </header>
        <div class="mm-modal-body">
            <p class="mm-links-hint"><?php echo Text::e('این لینک‌ها را داخل متن پست درج کنید. با درج لینک تصویر، پیش‌نمایش آن در پایین ویرایشگر نمایش داده می‌شود.'); ?></p>
            <textarea id="mm-links-text" class="mono" rows="8" readonly spellcheck="false"></textarea>
        </div>
        <footer class="mm-modal-foot">
            <button type="button" class="btn btn-s primary" id="mm-links-copy">
                <?php echo Icons::svg('link'); ?>
                <?php echo Text::e('کپی'); ?>
            </button>
        </footer>
    </div>
</div>

<?php if ($canBrowse && $view === 'browse'): ?>
<div class="mm-modal" id="mm-move-modal" hidden dir="rtl" role="dialog" aria-modal="true" aria-label="<?php echo Text::e('انتقال به پوشه‌ی دیگر'); ?>">
    <div class="mm-modal-backdrop" data-mm-close></div>
    <div class="mm-modal-box mm-move-box">
        <header class="mm-modal-head">
            <strong class="mm-modal-title">
                <?php echo Icons::svg('folder-input', 'mm-ico mm-ico-sm'); ?>
                <?php echo Text::e('انتقال به پوشه‌ی دیگر'); ?>
            </strong>
            <button type="button" class="mm-modal-close" data-mm-close title="<?php echo Text::e('بستن (Esc)'); ?>">
                <?php echo Icons::svg('x'); ?>
            </button>
        </header>
        <div class="mm-modal-body mm-move-body">
            <p class="mm-move-summary" id="mm-move-summary"></p>
            <ul class="mm-move-files" id="mm-move-files"></ul>
            <p class="mm-move-warning">
                <?php echo Icons::svg('zap', 'mm-ico mm-ico-sm'); ?>
                <span><?php echo Text::e('اگر لینک این فایل‌ها داخل متن نوشته‌ها استفاده شده باشد، آدرس‌ها به‌روزرسانی نمی‌شوند و پس از انتقال باید لینک‌ها را در نوشته‌ها اصلاح کنید.'); ?></span>
            </p>
            <p class="mm-move-target-label"><?php echo Text::e('پوشه‌ی مقصد را انتخاب کنید:'); ?></p>
            <div class="mm-move-tree" id="mm-move-tree" role="radiogroup" aria-label="<?php echo Text::e('پوشه‌ی مقصد'); ?>"></div>
        </div>
        <footer class="mm-modal-foot">
            <button type="button" class="btn btn-s" id="mm-move-cancel"><?php echo Text::e('انصراف'); ?></button>
            <button type="button" class="btn btn-s primary" id="mm-move-confirm">
                <?php echo Icons::svg('folder-input', 'mm-ico mm-ico-sm'); ?>
                <?php echo Text::e('انتقال'); ?>
            </button>
        </footer>
    </div>
</div>
<?php endif; ?>

<?php if ($canBrowse && $view === 'browse'): ?>
<div class="mm-modal" id="mm-rename-modal" hidden dir="rtl" role="dialog" aria-modal="true" aria-label="<?php echo Text::e('تغییر نام پوشه'); ?>">
    <div class="mm-modal-backdrop" data-mm-close></div>
    <div class="mm-modal-box mm-rename-box">
        <header class="mm-modal-head">
            <strong class="mm-modal-title">
                <?php echo Icons::svg('pencil', 'mm-ico mm-ico-sm'); ?>
                <?php echo Text::e('تغییر نام پوشه'); ?>
            </strong>
            <button type="button" class="mm-modal-close" data-mm-close title="<?php echo Text::e('بستن (Esc)'); ?>">
                <?php echo Icons::svg('x'); ?>
            </button>
        </header>
        <form class="mm-modal-body mm-rename-body" id="mm-rename-form" autocomplete="off">
            <p class="mm-rename-hint" id="mm-rename-hint"></p>
            <label class="sr-only" for="mm-rename-input"><?php echo Text::e('نام جدید پوشه'); ?></label>
            <input type="text" id="mm-rename-input" class="text-s" maxlength="96"
                   placeholder="<?php echo Text::e('نام جدید پوشه…'); ?>" autocomplete="off" spellcheck="false">
        </form>
        <footer class="mm-modal-foot">
            <button type="button" class="btn btn-s" id="mm-rename-cancel"><?php echo Text::e('انصراف'); ?></button>
            <button type="button" class="btn btn-s primary" id="mm-rename-confirm">
                <?php echo Icons::svg('pencil', 'mm-ico mm-ico-sm'); ?>
                <?php echo Text::e('ذخیره'); ?>
            </button>
        </footer>
    </div>
</div>
<?php endif; ?>

<div class="mm-modal" id="mm-file-rename-modal" hidden dir="rtl" role="dialog" aria-modal="true" aria-label="<?php echo Text::e('تغییر نام فایل'); ?>">
    <div class="mm-modal-backdrop" data-mm-close></div>
    <div class="mm-modal-box mm-rename-box">
        <header class="mm-modal-head">
            <strong class="mm-modal-title">
                <?php echo Icons::svg('pencil', 'mm-ico mm-ico-sm'); ?>
                <?php echo Text::e('تغییر نام فایل'); ?>
            </strong>
            <button type="button" class="mm-modal-close" data-mm-close title="<?php echo Text::e('بستن (Esc)'); ?>">
                <?php echo Icons::svg('x'); ?>
            </button>
        </header>
        <form class="mm-modal-body mm-rename-body" id="mm-file-rename-form" autocomplete="off">
            <p class="mm-rename-hint" id="mm-file-rename-hint"></p>
            <label class="sr-only" for="mm-file-rename-input"><?php echo Text::e('نام جدید فایل'); ?></label>
            <input type="text" id="mm-file-rename-input" class="text-s" maxlength="96"
                   placeholder="<?php echo Text::e('نام جدید فایل…'); ?>" autocomplete="off" spellcheck="false">
        </form>
        <footer class="mm-modal-foot">
            <button type="button" class="btn btn-s" id="mm-file-rename-cancel"><?php echo Text::e('انصراف'); ?></button>
            <button type="button" class="btn btn-s primary" id="mm-file-rename-confirm">
                <?php echo Icons::svg('pencil', 'mm-ico mm-ico-sm'); ?>
                <?php echo Text::e('ذخیره'); ?>
            </button>
        </footer>
    </div>
</div>

<link rel="stylesheet" href="<?php echo Text::e(Text::assetUrl('assets/panel.css') . '?' . $versionCss); ?>">
<script>window.MM_PANEL = <?php echo Text::jsonForScript($config); ?>;</script>
<script src="<?php echo Text::e(Text::assetUrl('assets/mm-confirm.js') . '?' . Text::assetCacheParam('assets/mm-confirm.js')); ?>"></script>
<script src="<?php echo Text::e(Text::assetUrl('assets/panel.js') . '?' . $versionJs); ?>"></script>
