<?php
declare(strict_types=1);

namespace TypechoPlugin\MediaManager;

use Typecho\Common;
use Typecho\Db;
use Widget\Upload;
use Widget\User;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class Uploader
{
    /** نام کوکی راهنمای «پوشه‌ی فرود آخرین آپلود» (خواندنی برای JS) */
    private const LANDED_COOKIE = 'mm_landed_folder';

    /** عمر کوکی فرود بر حسب ثانیه — هم‌عمر TTL سمت کلاینت (۱۰ دقیقه) */
    private const LANDED_COOKIE_TTL = 600;

    /**
     * نتیجه‌ی نهایی پس از تبدیل/جابه‌جایی — در هوک upload برای همگام‌سازی
     * رکورد پیوست مصرف می‌شود.
     */
    private static ?array $pending = null;

    /**
     * هندلر هوک beforeUpload — «پس از» ذخیره‌ی فایل توسط هسته/افزونه‌ی امنیتی
     *
     * فایل ذخیره‌شده را در صورت نیاز به WebP تبدیل و به پوشه‌ی انتخابی
     * (پارامتر mm_folder آپلودر پنل/انتخابگر) منتقل می‌کند. مقدار بازگشتی
     * مصرف نمی‌شود و این متد هرگز استثنایی به بیرون نمی‌دهد.
     */
    public static function beforeUpload(array $result): void
    {
        self::$pending = null;

        try {
            self::$pending = self::place($result);
        } catch (\Throwable $e) {
            // شکست در «جانمایی» هرگز آپلود را نمی‌شکند؛ فایل و رکورد
            // در مسیر پیش‌فرض هسته کاملاً معتبرند.
            self::$pending = null;
            self::log('place failed: ' . $e->getMessage());
        }
    }

    /**
     * هندلر هوک upload — پس از ثبت رکورد پیوست در پایگاه‌داده
     *
     * اگر جانمایی در beforeUpload انجام شده باشد، ستون text و عنوان
     * رکورد با مسیر/نام جدید بازنویسی و شیء attachment ویجت همگام می‌شود
     * تا پاسخ JSON همان لحظه هم نشانی درست را برگرداند. در هر حالت،
     * پوشه‌ی فرود این آپلود در کوکی راهنما ثبت می‌شود (rememberLandedFolder).
     */
    public static function upload(Upload $upload): void
    {
        $pending = self::$pending;
        self::$pending = null;

        if ($pending !== null) {
            try {
                self::syncRecord($upload, $pending);
            } catch (\Throwable $e) {
                // فایل روی دیسک درست است؛ خطای همگام‌سازی رکورد نباید پاسخ
                // آپلود را خراب کند (رکورد روی مسیر پیش‌فرض می‌ماند).
                self::log('sync failed: ' . $e->getMessage());
            }
        }

        /*
         * ثبت پوشه‌ی فرود «هر» آپلود موفق — حتی آپلودهایی که بیرون از
         * مدیامنجر انجام می‌شوند (مثل چسباندن فایل در خود ویرایشگر یا
         * ادیتور جانشین). این کوکی فقط تعیین می‌کند کتابخانه رسانه از
         * کدام پوشه «شروع» شود؛ خود مسیر در هر درخواست مرور، سمت سرور و
         * با sanitizeRelative/resolveDirectory دوباره اعتبارسنجی می‌شود.
         */
        try {
            self::rememberLandedFolder($upload);
        } catch (\Throwable $e) {
            self::log('landed cookie failed: ' . $e->getMessage());
        }
    }

    /**
     * سازگاری ارتقا از نسخه‌های پیشین — دیگر «هوک» نیست
     *
     * نسخه‌های قدیمی هوک uploadHandle را در DB ثبت می‌کردند. اگر فایل‌های
     * ۱.۸ جایگزین شوند ولی افزونه غیرفعال/فعال نشود، هسته این متدِ قدیمی
     * را صدا می‌زند. در آن حالت:
     *  - اگر هندلر دیگری (مثل RenewShield) بعد از ما باشد، کنار می‌کشیم تا
     *    نتیجه‌ی او معتبر بماند (آپلود سالم ادامه می‌یابد)؛
     *  - اگر تنها هندلر باشیم، پیام روشنِ «فعال‌سازی مجدد» می‌دهیم تا
     *    رکورد خراب ساخته نشود.
     * پس از فعال‌سازی مجدد، این متد دیگر فراخوانی نمی‌شود.
     */
    public static function handle(array $file): ?array
    {
        if (!self::isLastUploadHandler()) {
            return null;
        }

        throw new \RuntimeException(_t(
            'مدیا منیجر باید برای تکمیل ارتقا به نسخه‌های ۱.۸ یک بار غیرفعال و دوباره فعال شود تا هوک بارگذاری جدید ثبت شود.'
        ));
    }

    /**
     * آیا هندلر دیگری «بعد از» هوک قدیمی uploadHandle ما ثبت شده است؟
     * (فقط برای سازگاری ارتقا — در جریان عادی ۱.۸ استفاده نمی‌شود)
     */
    private static function isLastUploadHandler(): bool
    {
        $handles = \Typecho\Plugin::export()['handles']['Widget\Upload:uploadHandle'] ?? [];
        if (!is_array($handles) || $handles === []) {
            return true;
        }

        $last = end($handles);

        return $last === [self::class, 'handle']
            || $last === self::class . '::handle';
    }

    // ------------------------------------------------------------ جانمایی

    /**
     * تبدیل WebP + انتقال فایلِ ذخیره‌شده به پوشه‌ی انتخابی
     *
     * خروجی: آرایه‌ی نتیجه‌ی به‌روزشده (path/name/type/mime/size) یا null
     * اگر هیچ تغییری لازم/ممکن نبود.
     */
    private static function place(array $result): ?array
    {
        $path = (string) ($result['path'] ?? '');
        $type = strtolower(trim((string) ($result['type'] ?? '')));

        if ($path === '' || $type === '') {
            return null;
        }

        // مسیر مطلق فایلِ ذخیره‌شده (خروجی هسته/شیلد نسبت به ریشه‌ی سایت)
        $uploadRoot = defined('__TYPECHO_UPLOAD_ROOT_DIR__')
            ? (string) __TYPECHO_UPLOAD_ROOT_DIR__
            : __TYPECHO_ROOT_DIR__;

        $root = Browser::absoluteRoot();
        $oldReal = realpath(Common::url($path, $uploadRoot));

        if ($root === null || $oldReal === false) {
            // فایل همان‌جایی که هست معتبر است؛ کاری نمی‌کنیم
            return null;
        }

        $oldReal = rtrim(str_replace('\\', '/', $oldReal), '/');

        // فقط فایل‌های «داخل ریشه‌ی uploads» جابه‌جا می‌شوند
        if ($oldReal === $root || !str_starts_with($oldReal, $root . '/') || !is_file($oldReal)) {
            self::log('source outside uploads root or missing: ' . $path);
            return null;
        }

        // ۱) تبدیل اختیاری به WebP — روی «فایل ذخیره‌شده» انجام می‌شود
        //    (هیچ دخالتی در فایل موقت آپلود ندارد؛ سازگار با RenewShield)
        $webpFile = null;
        if (Webp::enabled() && Webp::convertible($type)) {
            $webpFile = Webp::apply([
                'name' => (string) ($result['name'] ?? ''),
                'tmp_name' => $oldReal,
            ], $type);
        }

        // ۲) پوشه‌ی مقصد درخواستی (mm_folder) — فقط برای ویراستار/مدیر
        $folder = self::requestedFolder();
        $destDir = null;

        if ($folder !== null) {
            $resolved = Browser::resolveDirectory($folder);
            if ($resolved !== null && $resolved !== $root) {
                $destDir = $resolved;
            }
        }

        $changed = false;

        if ($webpFile !== null) {
            // ۳) نوشتن نسخه‌ی WebP از طریق همان مسیر امن هسته
            //    (فایل موقت + بوگذاری MIME + رد محتوای خطرناک)
            $webpDir = $destDir ?? dirname($oldReal);
            $diskName = self::uniqueName($webpDir, sprintf('%u', crc32(uniqid('', true))) . '.webp');
            $destAbs = $webpDir . '/' . $diskName;

            $file = $webpFile;
            $file['size'] = strlen((string) $webpFile['bytes']);

            $mime = Upload::replaceUploadedFile($file, $destAbs, 'webp');

            // پرمیشن استاندارد 644 — برخی میزبان‌ها فایل گروه‌نوشتنی (664)
            // را با خطای 403 رد می‌کنند؛ FILE_MODE برخی هسته‌ها ممکن است
            // متفاوت باشد، پس صریحاً تثبیت می‌کنیم.
            @chmod($destAbs, 0644);

            // اصل فایل (JPG/PNG) دیگر لازم نیست
            @unlink($oldReal);
            self::removeDirIfEmptyDate($webpDir, $root, dirname($oldReal));

            $result['name'] = (string) $webpFile['name'];
            $result['type'] = 'webp';
            $result['mime'] = is_string($mime) && $mime !== '' ? $mime : 'image/webp';
            $result['size'] = (int) $file['size'];
            $result['path'] = self::relativeFor($path, $folder, $diskName);
            $changed = true;
        } elseif ($destDir !== null && $destDir !== dirname($oldReal)) {
            // ۴) جابه‌جایی ساده با rename — محتوا دست‌نخورده
            $diskName = self::uniqueName($destDir, basename($oldReal));
            $destAbs = $destDir . '/' . $diskName;

            if ($destAbs !== $oldReal && @rename($oldReal, $destAbs)) {
                /*
                 * پرمیشن استاندارد 644 (همان FILE_MODE هسته‌ی رسمی):
                 * میزبان‌های سخت‌گیر فایلِ گروه‌نوشتنی (664) را با 403 رد
                 * می‌کنند. قبلاً اینجا 664 گذاشته می‌شد و همین علت خطای
                 * 403 فایل‌های پوشه‌های سفارشی بود؛ مسیر تاریخ‌محور هسته
                 * 644 می‌گیرد و پوشه‌های سفارشی هم باید یکسان باشند.
                 */
                @chmod($destAbs, 0644);
                self::removeDirIfEmptyDate($destDir, $root, dirname($oldReal));
                $result['path'] = self::relativeFor($path, $folder, $diskName);
                $changed = true;
            } else {
                self::log('rename failed: ' . $oldReal . ' -> ' . $destAbs);
            }
        }

        return $changed ? $result : null;
    }

    /**
     * مسیر نسبی جدید برای رکورد پیوست — هم‌قالب خروجی هسته/شیلد
     * (مثل /usr/uploads/docs/1234.webp — همیشه با اسلش آغازین)
     */
    private static function relativeFor(string $oldRelative, ?string $folder, string $diskName): string
    {
        if ($folder !== null) {
            return rtrim(Browser::uploadDirSetting(), '/') . '/' . $folder . '/' . $diskName;
        }

        // بدون پوشه‌ی انتخابی: همان شاخه‌ی فعلی فایل (مثلاً /usr/uploads/2026/09)
        $dir = trim(str_replace('\\', '/', dirname($oldRelative)), '/');

        return '/' . ($dir !== '' ? $dir : trim(Browser::uploadDirSetting(), '/')) . '/' . $diskName;
    }

    /**
     * نام فایل یکتا در پوشه‌ی مقصد — در صورت تداخل، پسوند -2، -3 و… افزوده
     * می‌شود (به‌جای خطا دادن، همان رفتار بازگردانی سطل).
     */
    private static function uniqueName(string $dir, string $name): string
    {
        if (!is_file($dir . '/' . $name)) {
            return $name;
        }

        $ext = Browser::extensionOf($name);
        $base = $ext !== '' ? substr($name, 0, -1 - strlen($ext)) : $name;

        for ($i = 2; $i < 100; $i++) {
            $try = $base . '-' . $i . ($ext !== '' ? '.' . $ext : '');
            if (!is_file($dir . '/' . $try)) {
                return $try;
            }
        }

        // آخرین راه‌حل: نام تصادفی تازه (همان الگوی هسته)
        return sprintf('%u', crc32(uniqid('', true))) . ($ext !== '' ? '.' . $ext : '');
    }

    /**
     * پاکسازی پوشه‌ی تاریخ‌محور خالی (مثل 2026/09) پس از جابه‌جایی فایل
     *
     * فقط شاخه‌های «دقیقاً» با الگوی سال/ماه و فقط در صورت خالی بودن حذف
     * می‌شوند تا کتابخانه بدون پوشه‌ی خالی سفارکی بماند. عمل best-effort
     * است و خطای آن بی‌اثر است.
     */
    private static function removeDirIfEmptyDate(string $destDir, string $root, string $maybeEmpty): void
    {
        if ($maybeEmpty === $root || $maybeEmpty === $destDir || !is_dir($maybeEmpty)) {
            return;
        }

        $relative = trim(substr($maybeEmpty, strlen($root) + 1), '/');
        if (!preg_match('/^\d{4}\/\d{2}$/', $relative)) {
            return;
        }

        $entries = @scandir($maybeEmpty);
        if (is_array($entries) && count($entries) <= 2) {
            @rmdir($maybeEmpty);
        }
    }

    // ------------------------------------------------------------ همگام‌سازی رکورد

    /**
     * بازنویسی رکورد پیوست با نتیجه‌ی نهایی + همگام‌سازی پاسخ ویجت
     */
    private static function syncRecord(Upload $upload, array $pending): void
    {
        $cid = (int) ($upload->cid ?? 0);
        if ($cid <= 0) {
            return;
        }

        $db = Db::get();

        $rows = [
            'text' => Common::jsonEncode($pending, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES, '{}'),
        ];

        // عنوان رکورد (نام نمایشی) با نام نهایی همگام شود؛ مثلاً پس از
        // تبدیل WebP عنوان photo.webp ثبت می‌شود نه photo.jpg
        $newName = (string) ($pending['name'] ?? '');
        if ($newName !== '') {
            $rows['title'] = $newName;
        }

        $db->query(
            $db->update('table.contents')
                ->rows($rows)
                ->where('cid = ?', $cid)
                ->where('type = ?', 'attachment')
        );

        // همگام‌سازی حافظه‌ی ویجت تا پاسخ JSON همان لحظه هم درست باشد
        $attachment = $upload->attachment;

        if ($attachment !== null) {
            if ($newName !== '') {
                $attachment->name = $newName;
            }

            $attachment->path = (string) ($pending['path'] ?? '');
            $attachment->type = (string) ($pending['type'] ?? '');
            $attachment->mime = (string) ($pending['mime'] ?? '');
            $attachment->size = (int) ($pending['size'] ?? 0);
            $attachment->isImage = in_array(
                (string) ($pending['type'] ?? ''),
                ['gif', 'jpg', 'jpeg', 'png', 'tiff', 'bmp', 'webp', 'avif'],
                true
            );

            try {
                $attachment->url = Upload::attachmentHandle($attachment);
            } catch (\Throwable $e) {
                /* نشانی عمومی در پاسخ لحظه‌ای اهمیت حیاتی ندارد */
            }
        }
    }

    // ------------------------------------------------------------ ورودی‌ها

    /**
     * خواندن و اعتبارسنجی پوشه‌ی مقصد درخواستی (mm_folder)
     *
     * فقط زمانی معتبر است که: پارامتر متنیِ غیرخالی باشد، کاربر
     * ویراستار/مدیر باشد و مسیر پس از نرمال‌سازی، پوشه‌ای موجود و
     * داخل ریشه‌ی uploads باشد. در هر حالت دیگر null برگردانده
     * می‌شود تا آپلود با رفتار پیش‌فرض هسته ادامه یابد.
     */
    private static function requestedFolder(): ?string
    {
        $folder = $_POST['mm_folder'] ?? null;
        if (!is_string($folder) || trim($folder) === '') {
            return null;
        }

        // هدف‌گذاری پوشه فقط برای ویراستار/مدیر (کاربر سطح پایین‌تر → پیش‌فرض)
        $user = User::alloc();
        if (!$user->pass('editor', true)) {
            return null;
        }

        $sanitized = Browser::sanitizeRelative($folder);
        if ($sanitized === null || $sanitized === '') {
            return null;
        }

        return $sanitized;
    }

    /**
     * ثبت پوشه‌ی فرود آخرین آپلود موفق در یک کوکی کوتاه‌عمر
     *
     * هوک upload هسته برای «هر» آپلود موفق اجرا می‌شود — از هر مسیری که
     * انجام شده باشد (انتخابگر مدیامنجر، تب پیوست‌های هسته، چسباندن فایل
     * در ادیتور جانشین و…). سمت کلاینت (ویرایشگر/پنل) این کوکی را فقط
     * وقتی می‌خواند که در همین نشست صفحه فایلی چسبانده شده باشد؛ در
     * نتیجه رفتار «نشست تازه از ریشه» دست‌نخورده می‌ماند. مقدار کوکی
     * چیزی جز یک مسیر نسبیِ از پیش اعتبارسنجی‌شده داخل uploads نیست و
     * هیچ داده‌ی حساسی ندارد.
     */
    private static function rememberLandedFolder(Upload $upload): void
    {
        // راهنمای شروع پوشه فقط برای ویراستار/مدیر معنا دارد (مرور پوشه‌ای)
        $user = User::alloc();
        if (!$user->pass('editor', true)) {
            return;
        }

        $path = trim(str_replace('\\', '/', (string) ($upload->attachment->path ?? '')));
        if ($path === '') {
            return;
        }

        // جداسازی پیشوند مسیر uploads (مثل usr/uploads)
        $prefix = trim(Browser::uploadDirSetting(), '/');
        $relative = ltrim($path, '/');
        if ($prefix !== '' && str_starts_with($relative, $prefix . '/')) {
            $relative = substr($relative, strlen($prefix) + 1);
        }

        // پوشه‌ی فایل (بدون خود فایل) — فایل ریشه‌ای راهنما لازم ندارد
        $folder = Browser::sanitizeRelative(trim(str_replace('\\', '/', dirname($relative)), '/'));
        if ($folder === null || $folder === '') {
            return;
        }

        if (headers_sent()) {
            return;
        }

        @setcookie(self::LANDED_COOKIE, rawurlencode($folder), [
            'expires' => time() + self::LANDED_COOKIE_TTL,
            'path' => '/',
            'samesite' => 'Lax',
        ]);
    }

    /**
     * ثبت رویداد برای اشکال‌زدایی میزبانی (بدون نمایش به کاربر)
     */
    private static function log(string $message): void
    {
        if (function_exists('error_log')) {
            @error_log('MediaManager.Uploader: ' . $message);
        }
    }
}
