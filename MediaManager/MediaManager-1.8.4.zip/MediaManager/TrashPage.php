<?php
declare(strict_types=1);

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

use TypechoPlugin\MediaManager\Icons;
use TypechoPlugin\MediaManager\Settings;
use TypechoPlugin\MediaManager\Text;
use TypechoPlugin\MediaManager\Trash;


// سطل فقط برای ویراستار/مدیر — مطابق اندپوینت‌های سطل در Action.php
$user->pass('editor');

$settings = Settings::load();
$pageSize = max(12, min(96, (int) $settings['pageSize']));

// ---------------------------------------------------------------- پارامترها

$keywords = '';
if (is_string($request->get('keywords', ''))) {
    $keywords = trim(strip_tags((string) $request->get('keywords')));
    $keywords = mb_strcut($keywords, 0, 128, 'UTF-8');
}

$kind = (string) $request->get('kind', '');
$kind = in_array($kind, ['image', 'file'], true) ? $kind : '';

$sort = (string) $request->get('sort', 'newest');
$sort = in_array($sort, ['newest', 'oldest', 'name', 'size'], true) ? $sort : 'newest';

$page = max(1, (int) $request->filter('int')->get('page', 1));

$sortLabels = [
    'newest' => 'جدیدترین حذف',
    'oldest' => 'قدیمی‌ترین حذف',
    'name' => 'نام (الفبا)',
    'size' => 'حجم (بزرگ‌ترین)',
];

$kindLabels = [
    '' => 'همه',
    'image' => 'تصاویر',
    'file' => 'غیرتصویری',
];

// ---------------------------------------------------------------- داده‌ها

$stats = Trash::stats();
$data = Trash::list($page, $pageSize, $keywords, $kind, $sort);

$items = is_array($data['items'] ?? null) ? $data['items'] : [];
$total = (int) ($data['total'] ?? 0);
$page = (int) ($data['page'] ?? 1);
$pageSize = (int) ($data['pageSize'] ?? $pageSize);
$pages = max(1, (int) ceil($total / max(1, $pageSize)));

// ---------------------------------------------------------------- نشانی‌ها

$panelSelf = 'MediaManager/TrashPage.php';
$panelBase = $options->adminUrl . 'extending.php';
$backUrl = $panelBase . '?panel=' . urlencode('MediaManager/Panel.php');

/** نشانی صفحه با حفظ فیلترهای جاری (page قابل بازنویسی) */
$pageUrl = static function (array $params = []) use ($panelBase, $panelSelf, $keywords, $kind, $sort): string {
    $params = array_merge([
        'panel' => $panelSelf,
        'keywords' => $keywords,
        'kind' => $kind,
        'sort' => $sort,
    ], $params);
    $params = array_filter($params, static function ($v) {
        return $v !== null && $v !== '';
    });
    return $panelBase . '?' . http_build_query($params);
};

/**
 * تبدیل ارقام: همیشه فارسی (هماهنگ با پنل و ویرایشگر).
 */
$faNum = static function ($value): string {
    return strtr((string) $value, [
        '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
        '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
    ]);
};

// اندپوینت‌های عملیات (همراه توکن CSRF از طریق getIndex امنیت هسته)
$restoreUrl = $security->getIndex('/action/media-manager?do=trashrestore');
$deleteUrl = $security->getIndex('/action/media-manager?do=trashdelete');
$emptyUrl = $security->getIndex('/action/media-manager?do=trashtermpty');
$fileUrlBase = $security->getIndex('/action/media-manager?do=trashfile');

/** نشانی پیش‌نمایش تصویرِ یک مدخل (اندپوینت احراز هویت‌شده) */
$thumbUrl = static function (string $id) use ($fileUrlBase): string {
    return $fileUrlBase . '&id=' . urlencode($id);
};

// کش‌شکن دارایی‌ها
$versionCss = Text::assetCacheParam('assets/trash.css');
$versionJs = Text::assetCacheParam('assets/trash.js');

// پیکربندی سمت کلاینت
$config = [
    'restoreUrl' => $restoreUrl,
    'deleteUrl' => $deleteUrl,
    'emptyUrl' => $emptyUrl,
    'page' => $page,
    'pages' => $pages,
    'pageUrl' => $pageUrl(),
    'strings' => [
        'restoreConfirm' => 'این فایل به محل اصلی‌اش بازگردانده شود؟',
        'restoreTitle' => 'بازگردانی فایل',
        'restoreYes' => 'بازگردانی',
        'deleteConfirm' => 'این مورد برای همیشه از سرور حذف شود؟ (این عمل قابل بازگشت نیست)',
        'deleteTitle' => 'حذف قطعی',
        'deleteYes' => 'حذف قطعی',
        'emptyConfirm' => 'همه‌ی موارد سطل بازیافت برای همیشه حذف شوند؟ (این عمل قابل بازگشت نیست)',
        'emptyTitle' => 'خالی کردن سطل بازیافت',
        'emptyYes' => 'خالی کردن',
        'bulkRestoreConfirm' => 'فایل‌های انتخاب‌شده به محل اصلی‌شان بازگردانده شوند؟',
        'bulkRestoreTitle' => 'بازگردانی انتخاب‌شده‌ها',
        'bulkDeleteConfirm' => 'موارد انتخاب‌شده برای همیشه از سرور حذف شوند؟ (این عمل قابل بازگشت نیست)',
        'bulkDeleteTitle' => 'حذف قطعی انتخاب‌شده‌ها',
        'noSelection' => 'ابتدا یک مورد را انتخاب کنید',
        'error' => 'عملیات ناموفق بود؛ ممکن است دسترسی یا توکن منقضی شده باشد.',
        'done' => 'انجام شد؛ در حال نوسازی…',
    ],
];

// چیپ‌های فیلتر نوع (فیلتر/جستجو/صفحه در لینک حفظ می‌شود)
$kindChips = '';
foreach ($kindLabels as $kindKey => $kindLabel) {
    $active = $kind === $kindKey;
    $kindChips .= '<a class="mmt-chip' . ($active ? ' is-active' : '') . '"'
        . ' href="' . Text::e($pageUrl(['kind' => $kindKey, 'page' => null])) . '"'
        . ' aria-current="' . ($active ? 'true' : 'false') . '">'
        . Text::e($kindLabel) . '</a>';
}

// پنجره‌ی شماره‌های صفحه‌بندی (حداکثر ۷ شماره حول صفحه‌ی جاری)
$pageNumbers = [];
if ($pages > 1) {
    $from = max(1, $page - 3);
    $to = min($pages, $from + 6);
    $from = max(1, $to - 6);
    for ($n = $from; $n <= $to; $n++) {
        $pageNumbers[] = $n;
    }
}
?>
<div class="mmt-wrap" dir="rtl">
    <section class="mmt-head">
        <div class="mmt-head-main">
            <h2 class="mmt-title">
                <?php echo Icons::svg('trash-2', 'mm-ico'); ?>
                <?php echo Text::e('سطل بازیافت'); ?>
            </h2>
            <p class="mmt-subtitle"><?php echo Text::e('فایل‌های حذف‌شده به اینجا منتقل می‌شوند و تا خالی کردن سطل روی سرور باقی می‌مانند. با «بازگردانی» فایل به محل اصلی برمی‌گردد و اگر رکورد کتابخانه داشته باشد، دوباره ساخته می‌شود. خالی‌سازی و بازگردانی فقط از همین صفحه ممکن است.'); ?></p>
            <p class="mmt-stats">
                <span class="mmt-stats-count"><span class="mm-num"><?php echo Text::e($faNum($stats['count'])); ?></span></span>
                <?php echo Text::e('مورد'); ?>
                <span class="mmt-dot">·</span>
                <span class="mm-num"><?php echo Text::e($faNum(Text::bytes((int) $stats['bytes']))); ?></span>
            </p>
        </div>
        <div class="mmt-head-actions">
            <a class="btn btn-s" href="<?php echo Text::e($backUrl); ?>">
                <?php echo Icons::svg('folder-open', 'mm-ico mm-ico-sm'); ?>
                <?php echo Text::e('بازگشت به مدیا منیجر'); ?>
            </a>
            <?php if ($total > 0 || $stats['count'] > 0): ?>
            <button type="button" class="btn btn-s btn-warn" id="mmt-empty">
                <?php echo Icons::svg('trash-2', 'mm-ico mm-ico-sm'); ?>
                <?php echo Text::e('خالی کردن سطل'); ?>
            </button>
            <?php endif; ?>
        </div>
    </section>

    <form class="mmt-toolbar" method="get" action="<?php echo Text::e($panelBase); ?>" role="search">
        <input type="hidden" name="panel" value="<?php echo Text::e($panelSelf); ?>">
        <input type="hidden" name="kind" value="<?php echo Text::e($kind); ?>">
        <div class="mmt-search-box">
            <?php echo Icons::svg('search', 'mm-ico mm-ico-sm'); ?>
            <input type="search" id="mmt-keywords" name="keywords" value="<?php echo Text::e($keywords); ?>"
                   placeholder="<?php echo Text::e('جستجو در نام، عنوان یا مسیر اصلی…'); ?>" maxlength="128">
            <?php if ($keywords !== ''): ?>
            <a class="mmt-clear-search" href="<?php echo Text::e($pageUrl(['keywords' => null, 'page' => null])); ?>"
               title="<?php echo Text::e('پاک‌کردن جستجو'); ?>"><?php echo Icons::svg('x', 'mm-ico mm-ico-sm'); ?></a>
            <?php endif; ?>
        </div>
        <label class="mmt-sort-label" for="mmt-sort">
            <span><?php echo Text::e('مرتب‌سازی:'); ?></span>
            <select name="sort" id="mmt-sort">
                <?php foreach ($sortLabels as $sortKey => $sortLabel): ?>
                <option value="<?php echo Text::e($sortKey); ?>"<?php echo $sort === $sortKey ? ' selected' : ''; ?>>
                    <?php echo Text::e($sortLabel); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </label>
        <button type="submit" class="btn btn-s primary"><?php echo Text::e('اعمال'); ?></button>
        <nav class="mmt-chips" aria-label="<?php echo Text::e('فیلتر نوع فایل'); ?>">
            <?php echo $kindChips; ?>
        </nav>
    </form>

    <?php if ($total > 0): ?>
    <div class="mmt-bulkbar">
        <label class="mmt-select-all">
            <input type="checkbox" id="mmt-select-all">
            <span><?php echo Text::e('انتخاب همه'); ?></span>
        </label>
        <span class="mmt-count-pill" id="mmt-count-pill"><?php echo Text::e($faNum('0') . ' مورد انتخاب‌شده'); ?></span>
        <span class="mmt-bulkbar-spacer"></span>
        <button type="button" class="btn btn-s primary" id="mmt-restore-selected" disabled>
            <?php echo Icons::svg('folder-input', 'mm-ico mm-ico-sm'); ?>
            <?php echo Text::e('بازگردانی انتخاب‌شده‌ها'); ?>
        </button>
        <button type="button" class="btn btn-s btn-warn" id="mmt-delete-selected" disabled>
            <?php echo Icons::svg('trash-2', 'mm-ico mm-ico-sm'); ?>
            <?php echo Text::e('حذف قطعی انتخاب‌شده‌ها'); ?>
        </button>
    </div>
    <?php endif; ?>

    <div class="mmt-list" id="mmt-list">
        <?php if ($items === []): ?>
            <?php if ($keywords !== '' || $kind !== ''): ?>
            <div class="mmt-empty">
                <?php echo Icons::svg('search', 'mm-ico mm-ico-lg'); ?>
                <p><?php echo Text::e('موردی با این جستجو یا فیلتر یافت نشد.'); ?></p>
                <p class="mmt-empty-sub">
                    <a href="<?php echo Text::e($pageUrl(['keywords' => null, 'kind' => null, 'page' => null])); ?>">
                        <?php echo Text::e('نمایش همه‌ی موارد سطل'); ?>
                    </a>
                </p>
            </div>
            <?php else: ?>
            <div class="mmt-empty">
                <?php echo Icons::svg('trash-2', 'mm-ico mm-ico-lg'); ?>
                <p><?php echo Text::e('سطل بازیافت خالی است.'); ?></p>
                <p class="mmt-empty-sub"><?php echo Text::e('فایلی حذف نشده یا سطل قبلاً خالی شده است. فایل‌هایی که از مدیا منیجر حذف می‌کنید به اینجا منتقل می‌شوند.'); ?></p>
            </div>
            <?php endif; ?>
        <?php else: ?>
            <?php foreach ($items as $item): ?>
            <div class="mmt-item" data-id="<?php echo Text::e((string) $item['id']); ?>">
                <label class="mmt-check">
                    <input type="checkbox" class="mmt-item-check" value="<?php echo Text::e((string) $item['id']); ?>"
                           aria-label="<?php echo Text::e('انتخاب این مورد'); ?>">
                </label>
                <div class="mmt-thumb<?php echo $item['isImage'] ? '' : ' mmt-thumb-file'; ?>">
                    <?php if ($item['isImage']): ?>
                        <img loading="lazy" decoding="async" alt=""
                             src="<?php echo Text::e($thumbUrl((string) $item['id'])); ?>">
                    <?php else: ?>
                        <?php echo Icons::svg(Icons::kindIcon(Icons::fileKind((string) $item['type'])), 'mm-ico mm-ico-lg'); ?>
                    <?php endif; ?>
                </div>
                <div class="mmt-body">
                    <span class="mmt-name" title="<?php echo Text::e((string) $item['title']); ?>">
                        <?php echo Text::e((string) $item['title']); ?>
                    </span>
                    <span class="mmt-meta">
                        <span class="mmt-bytes"><span class="mm-num"><?php echo Text::e($faNum((string) $item['bytes'])); ?></span></span>
                        <span class="mmt-dot">·</span>
                        <span class="mmt-date" title="<?php echo Text::e((string) $item['deletedAtDate']); ?>">
                            <?php echo Text::e((string) $item['deletedAtWord']); ?>
                        </span>
                        <span class="mmt-dot">·</span>
                        <span class="mmt-badge<?php echo $item['registered'] ? ' mmt-badge-db' : ''; ?>">
                            <?php echo Text::e($item['registered'] ? 'کتابخانه' : 'دستی'); ?>
                        </span>
                        <span class="mmt-dot">·</span>
                        <span class="mmt-kind">
                            <?php echo Text::e(Icons::kindLabel(Icons::fileKind((string) $item['type']))); ?>
                        </span>
                    </span>
                    <span class="mmt-path" dir="ltr" title="<?php echo Text::e('مسیر اصلی: ' . (string) $item['originalPath']); ?>">
                        <?php echo Text::e((string) $item['originalPath']); ?>
                    </span>
                </div>
                <div class="mmt-actions">
                    <button type="button" class="btn btn-s primary mmt-restore">
                        <?php echo Text::e('بازگردانی'); ?>
                    </button>
                    <button type="button" class="btn btn-s btn-warn mmt-delete">
                        <?php echo Text::e('حذف قطعی'); ?>
                    </button>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <?php if ($pages > 1): ?>
    <nav class="mmt-pager" aria-label="<?php echo Text::e('صفحه‌بندی'); ?>">
        <a class="btn btn-s<?php echo $page <= 1 ? ' is-disabled' : ''; ?>"
           href="<?php echo Text::e($pageUrl(['page' => max(1, $page - 1)])); ?>"
           <?php echo $page <= 1 ? ' aria-disabled="true" tabindex="-1"' : ''; ?>>
            <?php echo Icons::svg('chevron-right', 'mm-ico mm-ico-sm'); ?>
            <?php echo Text::e('قبلی'); ?>
        </a>
        <?php foreach ($pageNumbers as $n): ?>
            <?php if ($n === $page): ?>
            <span class="mmt-page is-active"><span class="mm-num"><?php echo Text::e($faNum($n)); ?></span></span>
            <?php else: ?>
            <a class="mmt-page" href="<?php echo Text::e($pageUrl(['page' => $n])); ?>"><span class="mm-num"><?php echo Text::e($faNum($n)); ?></span></a>
            <?php endif; ?>
        <?php endforeach; ?>
        <a class="btn btn-s<?php echo $page >= $pages ? ' is-disabled' : ''; ?>"
           href="<?php echo Text::e($pageUrl(['page' => min($pages, $page + 1)])); ?>"
           <?php echo $page >= $pages ? ' aria-disabled="true" tabindex="-1"' : ''; ?>>
            <?php echo Text::e('بعدی'); ?>
            <?php echo Icons::svg('chevron-left', 'mm-ico mm-ico-sm'); ?>
        </a>
        <span class="mmt-pager-status">
            <?php echo Text::e('صفحه '); ?><span class="mm-num"><?php echo Text::e($faNum($page)); ?></span><?php echo Text::e(' از '); ?><span class="mm-num"><?php echo Text::e($faNum($pages)); ?></span><?php echo Text::e(' — '); ?><span class="mm-num"><?php echo Text::e($faNum($total)); ?></span> <?php echo Text::e('مورد'); ?>
        </span>
    </nav>
    <?php endif; ?>
</div>

<link rel="stylesheet" href="<?php echo Text::e(Text::assetUrl('assets/trash.css') . '?' . $versionCss); ?>">
<script>window.MM_TRASH = <?php echo Text::jsonForScript($config); ?>;</script>
<script src="<?php echo Text::e(Text::assetUrl('assets/mm-confirm.js') . '?' . Text::assetCacheParam('assets/mm-confirm.js')); ?>"></script>
<script src="<?php echo Text::e(Text::assetUrl('assets/trash.js') . '?' . $versionJs); ?>"></script>
