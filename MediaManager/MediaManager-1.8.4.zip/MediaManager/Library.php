<?php
declare(strict_types=1);

namespace TypechoPlugin\MediaManager;

use Typecho\Db;
use Widget\Upload;
use Widget\User;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class Library
{
    /** سقف ردیف‌های خوانده‌شده از DB (همان سقف Browser::attachmentMap) */
    private const MAX_ROWS = 20000;

    /** سقف طول عنوان جدید هنگام تغییر نام */
    private const MAX_TITLE_BYTES = 200;

    /**
     * فهرست پیوست‌های DB با فیلتر نوع فایل
     *
     * خروجی: ['items' => [...], 'total' => int, 'page' => int, 'pageSize' => int]
     * شکل هر آیتم همان do=pick است: cid/title/type/mime/size/bytes/isImage/url/created
     *
     * @param string $keywords  واژه‌های جستجو (فاصله‌جداشده؛ حداکثر ۵ واژه)
     * @param string $kind      کلید فیلتر (image|video|audio|archive|doc؛ خالی = همه)
     * @param int    $page      شماره‌ی صفحه (از ۱)
     * @param int    $pageSize  اندازه‌ی صفحه (۱۲ تا ۹۶)
     * @param int    $ownUid    > 0 یعنی فقط پیوست‌های این نویسنده (نقش‌های زیر ویراستار)
     */
    public static function list(string $keywords, string $kind, int $page, int $pageSize, int $ownUid = 0): array
    {
        $db = Db::get();

        $page = max(1, $page);
        $pageSize = max(12, min(48, $pageSize));
        $kind = Icons::validFilter($kind);

        $conditions = ['table.contents.type = ?', 'attachment'];

        if ($ownUid > 0) {
            $conditions[0] .= ' AND table.contents.authorId = ?';
            $conditions[] = $ownUid;
        }

        $keywords = trim($keywords);
        if ($keywords !== '') {
            $keywordsList = preg_split('/\s+/', $keywords) ?: [];
            $keywordsList = array_values(array_filter(array_slice($keywordsList, 0, 5), static function ($word) {
                return is_string($word) && $word !== '';
            }));

            if (!empty($keywordsList)) {
                $conditions[0] .= ' AND (' . implode(' OR ', array_fill(0, count($keywordsList), 'LOWER(table.contents.title) LIKE ?')) . ')';
                foreach ($keywordsList as $word) {
                    $conditions[] = '%' . self::escapeLike(mb_strtolower($word, 'UTF-8')) . '%';
                }
            }
        }

        try {
            $rows = $db->fetchAll(
                $db->select('cid', 'title', 'authorId', 'created', 'text')
                    ->from('table.contents')
                    ->where(...$conditions)
                    ->order('table.contents.created', Db::SORT_DESC)
                    ->limit(self::MAX_ROWS)
            );
        } catch (\Throwable $e) {
            $rows = [];
        }

        // فیلتر نوع فایل روی پسوندِ JSON (پس از decode، قبل از صفحه‌بندی)
        $filtered = [];
        foreach ($rows as $row) {
            $content = json_decode((string) $row['text'], true);
            $content = is_array($content) ? $content : [];

            $ext = (string) ($content['type'] ?? '');
            if ($kind !== '' && !Icons::filterMatches($kind, $ext)) {
                continue;
            }

            $filtered[] = ['row' => $row, 'content' => $content];
        }

        $total = count($filtered);
        $offset = ($page - 1) * $pageSize;
        $slice = array_slice($filtered, $offset, $pageSize);

        $items = [];
        foreach ($slice as $entry) {
            $row = $entry['row'];
            $content = $entry['content'];

            $attachment = new \Typecho\Config($content);
            $attachment->isImage = in_array((string) ($content['type'] ?? ''), [
                'jpg', 'jpeg', 'gif', 'png', 'tiff', 'bmp', 'webp', 'avif'
            ], true);
            $attachment->url = Upload::attachmentHandle($attachment);

            $items[] = [
                'cid' => (int) $row['cid'],
                'title' => (string) $row['title'],
                'type' => (string) ($content['type'] ?? ''),
                'mime' => (string) ($content['mime'] ?? ''),
                'size' => (int) ($content['size'] ?? 0),
                'bytes' => Text::bytes((int) ($content['size'] ?? 0)),
                'isImage' => (bool) $attachment->isImage,
                'url' => (string) $attachment->url,
                'created' => (int) $row['created'],
            ];
        }

        return [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'pageSize' => $pageSize,
        ];
    }

    /**
     * تغییر «عنوان» یک پیوست کتابخانه (cid)
     *
     * نام فایل روی دیسسک و نشانی آن تغییر نمی‌کند؛ فقط عنوان نمایشی
     * (ستون title + کلید name داخل JSON فیلد text) به‌روزرسانی می‌شود تا
     * نمایش و جستجو در همه‌جا یکسان بماند. slug دست‌نخورده می‌ماند تا
     * پیوند ثابت پیوست خراب نشود.
     *
     * مجوز: ویراستار/مدیر برای همه؛ سایر نقش‌ها فقط برای پیوست خودشان.
     *
     * خروجی: ['error' => null|string, 'title' => string|null]
     */
    public static function renameTitle(int $cid, string $title): array
    {
        $title = trim(preg_replace('/[\x00-\x1F\x7F]/u', '', $title) ?? '');
        $title = mb_strcut($title, 0, self::MAX_TITLE_BYTES, 'UTF-8');

        if ($title === '') {
            return ['error' => 'عنوان جدید نمی‌تواند خالی باشد.', 'title' => null];
        }

        $db = Db::get();
        $user = User::alloc();

        try {
            $row = $db->fetchRow(
                $db->select('cid', 'authorId', 'text')
                    ->from('table.contents')
                    ->where('table.contents.cid = ?', $cid)
                    ->where('table.contents.type = ?', 'attachment')
                    ->limit(1)
            );

            if (empty($row)) {
                return ['error' => 'این پیوست در کتابخانه یافت نشد.', 'title' => null];
            }

            if (!$user->pass('editor', true) && (int) $row['authorId'] !== (int) $user->uid) {
                return ['error' => 'شما فقط می‌توانید عنوان پیوست‌های خودتان را تغییر دهید.', 'title' => null];
            }

            // همگام‌سازی کلید name داخل JSON (نام اصلی فایل هنگام آپلود)
            $text = (string) $row['text'];
            $content = json_decode($text, true);
            if (is_array($content)) {
                if (isset($content['name']) || isset($content['title'])) {
                    if (isset($content['name'])) {
                        $content['name'] = $title;
                    }
                    if (isset($content['title'])) {
                        $content['title'] = $title;
                    }
                } else {
                    $content['name'] = $title;
                }

                $text = \Typecho\Common::jsonEncode($content, JSON_UNESCAPED_UNICODE, '{}');
            }

            $db->query(
                $db->update('table.contents')
                    ->rows([
                        'title' => $title,
                        'text' => $text,
                    ])
                    ->where('cid = ?', $cid)
            );
        } catch (\Throwable $e) {
            return ['error' => 'به‌روزرسانی عنوان ناموفق بود؛ دوباره تلاش کنید.', 'title' => null];
        }

        return ['error' => null, 'title' => $title];
    }

    /**
     * فرار از کاراکترهای ویژه LIKE (% _ و \\) برای کوئری پارامتری
     */
    private static function escapeLike(string $value): string
    {
        return str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $value);
    }
}
