<?php
declare(strict_types=1);

namespace TypechoPlugin\MediaManager;

use Typecho\Common;
use Typecho\Db;
use Widget\User;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class Trash
{
    /** نام پوشه‌ی سطل داخل uploads */
    public const DIR_NAME = '.trash';

    /** نام فایل متادیتا داخل هر مدخل */
    private const META_FILE = 'meta.json';

    /** نام فایل خود فایل داخل هر مدخل */
    private const FILE_PREFIX = 'file';

    /** سقف تعداد مدخل‌های خوانده‌شده در هر لیست */
    private const MAX_ENTRIES = 5000;

    /** الگوی مجاز شناسه‌ی مدخل */
    private const ID_PATTERN = '/^[A-Za-z0-9_-]{1,64}$/';

    // ------------------------------------------------------------ زیرساخت

    /**
     * مسیر مطلق ریشه‌ی سطل (بدون ساخت)
     */
    public static function absoluteRoot(): ?string
    {
        $root = Browser::absoluteRoot();
        if ($root === null) {
            return null;
        }

        return $root . '/' . self::DIR_NAME;
    }

    /**
     * آماده‌سازی سطل: ساخت پوشه، فایل index و قفل دسترسی وب
     *
     * در فعال‌سازی افزونه و پیش از اولین استفاده صدا زده می‌شود.
     */
    public static function ensure(): bool
    {
        $root = Browser::absoluteRoot();
        if ($root === null || !is_dir($root) || !is_writable($root)) {
            return false;
        }

        $trash = $root . '/' . self::DIR_NAME;

        if (!is_dir($trash) && !@mkdir($trash, 0755) && !is_dir($trash)) {
            return false;
        }

        @chmod($trash, 0755);

        // قفل دسترسی وب مستقیم (در میزبان‌های Apache/LiteSpeed مؤثر است)
        $htaccess = $trash . '/.htaccess';
        if (!is_file($htaccess)) {
            @file_put_contents(
                $htaccess,
                "Options -Indexes\n"
                . "Require all denied\n"
                . "<IfModule !mod_authz_core.c>\n    Order allow,deny\n    Deny from all\n</IfModule>\n"
            );
        }

        $index = $trash . '/index.html';
        if (!is_file($index)) {
            @file_put_contents($index, '');
        }

        return true;
    }

    /**
     * آیا سطل قابل استفاده است؟ (پوشه موجود یا قابل ساخت)
     */
    public static function available(): bool
    {
        $trash = self::absoluteRoot();

        return $trash !== null && (is_dir($trash) || self::ensure());
    }

    // ------------------------------------------------------------ حذف نرم

    /**
     * انتقال یک فایل داخل uploads به سطل
     *
     * @param string      $relativePath مسیر نسبی فایل داخل uploads (مثل docs/x.png)
     * @param array|null  $record       متادیتای اختیاری رکورد کتابخانه:
     *                                  [title, text(json), authorId, parent, cid]
     * @return bool موفقیت انتقال (در شکست، فراخواننده می‌تواند unlink کند)
     */
    public static function moveToTrash(string $relativePath, ?array $record = null): bool
    {
        $source = Browser::resolveFile($relativePath);
        if ($source === null) {
            return false;
        }

        if (!self::ensure()) {
            return false;
        }

        $trash = self::absoluteRoot();
        if ($trash === null || !is_writable($trash) || !is_writable(dirname($source))) {
            return false;
        }

        // شناسه‌ی یکتا: زمان + بایت تصادفی (کوتاه و امن برای URL)
        $id = base_convert((string) time(), 10, 36) . '-' . bin2hex(random_bytes(5));
        $entry = $trash . '/' . $id;

        if (!@mkdir($entry, 0755)) {
            return false;
        }

        $ext = Browser::extensionOf(basename($source));
        $stored = $entry . '/' . self::FILE_PREFIX . ($ext !== '' ? '.' . $ext : '');

        if (!@rename($source, $stored)) {
            @rmdir($entry);
            return false;
        }

        // پرمیشن استاندارد 644 — هم‌قالب مسیر تاریخ‌محور هسته؛ ضمناً فایل‌های
        // قدیمیِ 664 (از نسخه‌های پیشین) با ورود به سطل اصلاح می‌شوند.
        @chmod($stored, 0644);

        $meta = [
            'id' => $id,
            'originalPath' => ltrim($relativePath, '/'),
            'name' => basename($relativePath),
            'title' => (string) ($record['title'] ?? basename($relativePath)),
            'size' => (int) @filesize($stored),
            'type' => $ext,
            'isImage' => in_array($ext, ['gif', 'jpg', 'jpeg', 'png', 'tiff', 'bmp', 'webp', 'avif'], true),
            'deletedAt' => time(),
            // اطلاعات بازسازی رکورد کتابخانه (در صورت حذف از DB)
            'registered' => !empty($record),
            'text' => (string) ($record['text'] ?? ''),
            'authorId' => (int) ($record['authorId'] ?? 0),
            'parent' => (int) ($record['parent'] ?? 0),
            'oldCid' => (int) ($record['cid'] ?? 0),
        ];

        @file_put_contents(
            $entry . '/' . self::META_FILE,
            Common::jsonEncode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES, '{}')
        );

        return true;
    }

    /**
     * هوک deleteHandle هسته — حذف پیوست‌های ثبت‌شده به‌جای unlink، به سطل می‌رود
     *
     * نکته: هسته ردیف DB را «پیش از» این هوک حذف می‌کند؛ ما JSON پیوست را
     * از $content (ستون‌های cid/attachment/parent) استخراج و در سطل نگه
     * می‌داریم تا ریستور بتواند رکورد را دقیقاً بازسازی کند.
     *
     * ریشه‌ی باگ نسخه‌های قبل: رکوردهای هسته مسیر را با اسلش آغازین ذخیره
     * می‌کنند (مثل /usr/uploads/2026/09/x.jpg) اما مقایسه‌ی قبلی با پیشوندِ
     * بدون اسلش (usr/uploads/) انجام می‌شد؛ در نتیجه پیشوند هرگز جدا نمی‌شد،
     * فایل در ریشه‌ی uploads پیدا نمی‌شد و «رکورد حذف می‌شد ولی فایل روی
     * دیسک می‌ماند» — کاربر مجبور بود دوباره حذف کند و نام فایل در گرید به
     * نام روی دیسک (پس از آپلود) تغییر می‌کرد. اکنون هر دو شکل مسیر
     * (با/بدون اسلش آغازین) پذیرفته و به مسیر نسبیِ uploads تبدیل می‌شود.
     *
     * اگر انتقال به سطل ممکن نباشد، به رفتار قبلی (حذف فیزیکی) برمی‌گردیم
     * تا فایل یتیم روی دیسک نماند.
     */
    public static function handleDelete(array $content): bool
    {
        $attachment = $content['attachment'] ?? null;
        $relativePath = '';

        if (is_array($attachment)) {
            $relativePath = (string) ($attachment['path'] ?? '');
        } elseif (is_object($attachment) && isset($attachment->path)) {
            $relativePath = (string) $attachment->path;
        }

        // نرمال‌سازی مسیر رکورد به مسیر نسبیِ ریشه‌ی uploads (مثل 2026/09/x.jpg)
        $normalized = self::toUploadsRelative($relativePath);

        if ($normalized === null) {
            return false;
        }

        // متادیتای رکورد برای بازسازی هنگام ریستور
        $record = null;
        $json = [];
        if (is_object($attachment) || is_array($attachment)) {
            $json = is_object($attachment) ? $attachment->toArray() : $attachment;
        }

        if (!empty($json)) {
            $record = [
                'title' => (string) ($json['name'] ?? basename($normalized)),
                'text' => Common::jsonEncode($json, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES, '{}'),
                'authorId' => 0,
                'parent' => (int) ($content['parent'] ?? 0),
                'cid' => (int) ($content['cid'] ?? 0),
            ];
        }

        if (self::moveToTrash($normalized, $record)) {
            return true;
        }

        // تنزل به رفتار قبلی: حذف فیزیکی (تا رکورد حذف‌شده فایل یتیم نگذارد)
        $absolute = Browser::resolveFile($normalized);
        if ($absolute !== null) {
            @unlink($absolute);
        }

        return true;
    }

    /**
     * نرمال‌سازی مسیر ذخیره‌شده در رکورد پیوست به مسیر نسبیِ ریشه‌ی uploads
     *
     * رکوردهای هسته/شیلد مسیر را با پیشوند کامل و اسلش آغازین نگه می‌دارند
     * (مثل /usr/uploads/2026/09/x.jpg) و برخی رکوردهای قدیمیِ مدیامنجر بدون
     * اسلش آغازین (usr/uploads/2026/09/x.jpg). هر دو شکل و همچنین مسیر
     * نسبت به ریشه‌ی uploads (2026/09/x.jpg) پذیرفته می‌شود.
     *
     * خروجی: مسیر نسبی امن (بدون اسلش آغازین) یا null در صورت نامعتبر بودن.
     */
    private static function toUploadsRelative(string $path): ?string
    {
        $path = str_replace('\\', '/', trim($path));

        if ($path === '' || str_contains($path, "\0") || str_contains($path, '..')) {
            return null;
        }

        // اسلش‌های آغازین یکسان‌سازی می‌شوند تا مقایسه‌ی پیشوند درست کار کند
        $path = ltrim($path, '/');

        $prefix = trim(Browser::uploadDirSetting(), '/');
        if ($prefix !== '' && str_starts_with($path, $prefix . '/')) {
            $path = substr($path, strlen($prefix) + 1);
        }

        $path = trim($path, '/');

        // مسیر خالی یا خالصِ ریشه‌ی uploads فایل را مشخص نمی‌کند
        if ($path === '' || $path === $prefix) {
            return null;
        }

        return Browser::sanitizeRelative($path);
    }

    // ------------------------------------------------------------ لیست و شمارش

    /**
     * شمارش مدخل‌های سطل (برای نمایش روی دکمه‌ی پنل)
     */
    public static function countEntries(): int
    {
        $trash = self::absoluteRoot();
        if ($trash === null || !is_dir($trash)) {
            return 0;
        }

        $entries = @scandir($trash);
        if ($entries === false) {
            return 0;
        }

        $count = 0;
        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..' || !preg_match(self::ID_PATTERN, $entry)) {
                continue;
            }

            if (is_dir($trash . '/' . $entry)) {
                $count++;
            }
        }

        return $count;
    }

    /**
     * فهرست مدخل‌های سطل (صفحه‌بندی‌شده) با جستجو، فیلتر نوع و مرتب‌سازی
     *
     * @param int    $page     شماره‌ی صفحه (از ۱)
     * @param int    $pageSize تعداد آیتم هر صفحه (۱۲ تا ۹۶)
     * @param string $keywords عبارت جستجو (چندواژه‌ای، روی نام/عنوان/مسیر اصلی)
     * @param string $kind     فیلتر نوع: '' همه | 'image' فقط تصاویر | 'file' فقط غیرتصویری
     * @param string $sort     مرتب‌سازی: newest | oldest | name | size
     *
     * خروجی: ['items' => [...], 'total' => int, 'page' => int, 'pageSize' => int]
     */
    public static function list(int $page, int $pageSize, string $keywords = '', string $kind = '', string $sort = 'newest'): array
    {
        $result = ['items' => [], 'total' => 0, 'page' => 1, 'pageSize' => 24];
        $trash = self::absoluteRoot();

        if ($trash === null || !is_dir($trash)) {
            return $result;
        }

        $entries = @scandir($trash);
        if ($entries === false) {
            return $result;
        }

        if (!in_array($kind, ['image', 'file'], true)) {
            $kind = '';
        }

        if (!in_array($sort, ['newest', 'oldest', 'name', 'size'], true)) {
            $sort = 'newest';
        }

        $keywordList = [];
        if (trim($keywords) !== '') {
            $keywordList = preg_split('/\s+/', trim($keywords)) ?: [];
            $keywordList = array_values(array_filter(array_slice($keywordList, 0, 5), static function ($word) {
                return is_string($word) && $word !== '';
            }));
        }

        $items = [];
        $count = 0;

        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..' || !preg_match(self::ID_PATTERN, $entry)) {
                continue;
            }

            if ($count >= self::MAX_ENTRIES) {
                break;
            }

            $meta = self::readMeta($entry);
            if ($meta === null) {
                continue;
            }

            $count++;

            if ($keywordList && !self::matchesKeywords($meta, $keywordList)) {
                continue;
            }

            $isImage = (bool) ($meta['isImage'] ?? false);
            if ($kind === 'image' && !$isImage) {
                continue;
            }
            if ($kind === 'file' && $isImage) {
                continue;
            }

            $items[] = self::formatItem($meta);
        }

        usort($items, static function (array $a, array $b) use ($sort): int {
            switch ($sort) {
                case 'oldest':
                    return $a['deletedAt'] <=> $b['deletedAt'];
                case 'name':
                    return strcasecmp((string) $a['title'], (string) $b['title']);
                case 'size':
                    return $b['size'] <=> $a['size'];
                default:
                    return $b['deletedAt'] <=> $a['deletedAt'];
            }
        });

        $total = count($items);
        $page = max(1, $page);
        $pageSize = max(12, min(96, $pageSize));
        $offset = ($page - 1) * $pageSize;

        return [
            'items' => array_slice($items, $offset, $pageSize),
            'total' => $total,
            'page' => $page,
            'pageSize' => $pageSize,
        ];
    }

    /**
     * آمار کلی سطل برای سربرگ صفحه‌ی اختصاصی: تعداد و حجم کل
     *
     * خروجی: ['count' => int, 'bytes' => int]
     */
    public static function stats(): array
    {
        $stats = ['count' => 0, 'bytes' => 0];
        $trash = self::absoluteRoot();

        if ($trash === null || !is_dir($trash)) {
            return $stats;
        }

        $entries = @scandir($trash);
        if ($entries === false) {
            return $stats;
        }

        $count = 0;
        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..' || !preg_match(self::ID_PATTERN, $entry)) {
                continue;
            }

            if ($count >= self::MAX_ENTRIES) {
                break;
            }

            $meta = self::readMeta($entry);
            if ($meta === null) {
                continue;
            }

            $count++;
            $stats['count']++;
            $stats['bytes'] += (int) ($meta['size'] ?? 0);
        }

        return $stats;
    }

    /**
     * خواندن و اعتبارسنجی متادیتای یک مدخل
     */
    private static function readMeta(string $id): ?array
    {
        if (!preg_match(self::ID_PATTERN, $id)) {
            return null;
        }

        $trash = self::absoluteRoot();
        if ($trash === null) {
            return null;
        }

        $entry = realpath($trash . '/' . $id);
        if ($entry === false) {
            return null;
        }

        $entry = rtrim(str_replace('\\', '/', $entry), '/');
        if ($entry !== $trash && !str_starts_with($entry, $trash . '/')) {
            return null;
        }

        $metaFile = $entry . '/' . self::META_FILE;
        if (!is_file($metaFile) || !is_readable($metaFile)) {
            return null;
        }

        $meta = json_decode((string) @file_get_contents($metaFile), true);
        if (!is_array($meta) || empty($meta['originalPath'])) {
            return null;
        }

        $meta['id'] = $id;

        return $meta;
    }

    /**
     * شکل نمایشی یک مدخل برای پنل
     */
    private static function formatItem(array $meta): array
    {
        $deletedAt = (int) ($meta['deletedAt'] ?? 0);

        return [
            'id' => (string) $meta['id'],
            'name' => (string) ($meta['name'] ?? basename((string) $meta['originalPath'])),
            'title' => (string) ($meta['title'] ?? $meta['name'] ?? ''),
            'originalPath' => (string) $meta['originalPath'],
            'size' => (int) ($meta['size'] ?? 0),
            'bytes' => Text::bytes((int) ($meta['size'] ?? 0)),
            'type' => (string) ($meta['type'] ?? ''),
            'isImage' => (bool) ($meta['isImage'] ?? false),
            'deletedAt' => $deletedAt,
            'deletedAtWord' => (new \Typecho\Date($deletedAt > 0 ? $deletedAt : time()))->word(),
            'deletedAtDate' => $deletedAt > 0 ? (new \Typecho\Date($deletedAt))->format('Y/m/d H:i') : '',
            'registered' => (bool) ($meta['registered'] ?? false),
        ];
    }

    /**
     * تطبیق کلیدواژه‌ها روی نام، عنوان و مسیر اصلی
     */
    private static function matchesKeywords(array $meta, array $keywordList): bool
    {
        $haystacks = [
            (string) ($meta['name'] ?? ''),
            (string) ($meta['title'] ?? ''),
            (string) ($meta['originalPath'] ?? ''),
        ];

        foreach ($keywordList as $word) {
            $found = false;
            foreach ($haystacks as $haystack) {
                if ($haystack !== '' && stripos($haystack, $word) !== false) {
                    $found = true;
                    break;
                }
            }

            if (!$found) {
                return false;
            }
        }

        return true;
    }

    // ------------------------------------------------------------ ریستور

    /**
     * بازگردانی یک مدخل به محل اصلی
     *
     * فایل به مسیر اصلی برمی‌گردد (پوشه‌های میانی در صورت نیاز ساخته
     * می‌شوند) و اگر قبلاً رکورد کتابخانه داشته، رکورد contents آن با
     * همان JSON پیوست بازسازی می‌شود.
     *
     * خروجی: ['error' => null|string, 'path' => string|null]
     */
    public static function restore(string $id): array
    {
        $meta = self::readMeta($id);
        if ($meta === null) {
            return ['error' => 'این مورد در سطل زباله یافت نشد.', 'path' => null];
        }

        $root = Browser::absoluteRoot();
        $trash = self::absoluteRoot();
        if ($root === null || $trash === null) {
            return ['error' => 'پوشه‌ی uploads در دسترس نیست.', 'path' => null];
        }

        // مسیر مقصد: باید داخل uploads و بدون قطعه‌ی نقطه‌دار باشد
        $relative = Browser::sanitizeRelative((string) $meta['originalPath']);
        if ($relative === null || $relative === '') {
            return ['error' => 'مسیر اصلی این فایل معتبر نیست.', 'path' => null];
        }

        // پیدا کردن فایل ذخیره‌شده (file.<ext>)
        $entry = $trash . '/' . $meta['id'];
        $stored = null;
        foreach (glob($entry . '/' . self::FILE_PREFIX . '*') ?: [] as $candidate) {
            if (is_file($candidate)) {
                $stored = $candidate;
                break;
            }
        }

        if ($stored === null) {
            return ['error' => 'فایل این مورد در سطل یافت نشد.', 'path' => null];
        }

        // ساخت پوشه‌های میانی (در صورت حذف شدن پس از انتقال به سطل)
        $parentRelative = dirname($relative);
        $targetDir = $parentRelative === '.' ? $root : $root . '/' . $parentRelative;
        if (!is_dir($targetDir) && !@mkdir($targetDir, 0755, true) && !is_dir($targetDir)) {
            return ['error' => 'ساخت پوشه‌ی مقصد ممکن نشد.', 'path' => null];
        }

        $destination = $targetDir . '/' . basename($relative);

        // تداخل نام: فایل جدیدی با همین نام در محل اصلی هست → نام یکتا می‌سازیم
        if (file_exists($destination)) {
            $pathInfo = pathinfo($destination);
            $suffix = 2;
            do {
                $destination = $pathInfo['dirname'] . '/' . $pathInfo['filename'] . '-' . $suffix
                    . (isset($pathInfo['extension']) ? '.' . $pathInfo['extension'] : '');
                $suffix++;
            } while (file_exists($destination) && $suffix < 100);

            if (file_exists($destination)) {
                return ['error' => 'در محل اصلی فایلی با همین نام وجود دارد.', 'path' => null];
            }
        }

        if (!@rename($stored, $destination)) {
            return ['error' => 'بازگردانی فایل ناموفق بود (خطای دسترسی سرور).', 'path' => null];
        }

        // پرمیشن استاندارد 644 — فایل بازگردانده‌شده باید مثل بقیه‌ی فایل‌های
        // uploads از وب قابل خواندن باشد (664 روی برخی میزبان‌ها 403 می‌دهد).
        // این تثبیت، فایل‌های قدیمیِ 664 را هم هنگام بازگردانی اصلاح می‌کند.
        @chmod($destination, 0644);

        $restoredRelative = trim(str_replace('\\', '/', substr($destination, strlen($root) + 1)), '/');

        // بازسازی رکورد کتابخانه در صورت نیاز (اطلاعات از JSON پیوستِ ذخیره‌شده)
        if (!empty($meta['registered'])) {
            self::restoreAttachmentRecord($meta, $restoredRelative, basename($destination));
        }

        self::removeEntry($entry);

        return ['error' => null, 'path' => $restoredRelative];
    }

    /**
     * بازسازی رکورد contents از JSON پیوست ذخیره‌شده در سطل
     *
     * ساختار عیناً مطابق insert هسته برای نوع attachment؛ فقط مسیر داخل
     * JSON به مسیر جدید (در صورت تغییر نام به‌خاطر تداخل) به‌روز می‌شود.
     */
    private static function restoreAttachmentRecord(array $meta, string $restoredRelative, string $fileName): void
    {
        try {
            $json = json_decode((string) ($meta['text'] ?? ''), true);
            if (!is_array($json) || empty($json['path'])) {
                return;
            }

            // همگام‌سازی مسیر در JSON — همان قالب رسمی هسته
            // (مثل /usr/uploads/2026/09/x.jpg با اسلش آغازین)
            $json['path'] = Browser::attachmentKey($restoredRelative);

            $title = (string) ($meta['title'] ?? $json['name'] ?? $fileName);
            $user = User::alloc();
            $authorId = (int) ($meta['authorId'] ?? 0);
            if ($authorId <= 0) {
                $authorId = (int) $user->uid;
            }

            $parent = (int) ($meta['parent'] ?? 0);

            $db = Db::get();

            // parent فقط اگر هنوز محتوای موجودی باشد
            if ($parent > 0) {
                $row = $db->fetchRow(
                    $db->select('cid')->from('table.contents')->where('cid = ?', $parent)->limit(1)
                );
                if (empty($row)) {
                    $parent = 0;
                }
            }

            $now = time();
            $slug = Common::slugName($title);
            if ($slug === '') {
                // همان رفتار applySlug هسته: در نبود نام‌پذیرِ لاتین، از cid استفاده می‌شود
                $slug = 'attachment';
            }

            $insertRows = [
                // عنوان عیناً خام ذخیره می‌شود (مثل رفتار insert هسته)؛
                // قالب‌ها هنگام نمایش خودشان escape می‌کنند
                'title' => $title,
                'slug' => $slug,
                'created' => $now,
                'modified' => $now,
                'text' => Common::jsonEncode($json, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES, '{}'),
                'order' => 0,
                'authorId' => $authorId,
                'template' => null,
                'type' => 'attachment',
                'status' => 'publish',
                'password' => null,
                'commentsNum' => 0,
                'allowComment' => 1,
                'allowPing' => 0,
                'allowFeed' => 1,
                'parent' => $parent,
            ];

            $insertId = (int) $db->query($db->insert('table.contents')->rows($insertRows));

            // slug یکتا (همان چرخه‌ی applySlug هسته)
            if ($insertId > 0) {
                $count = 1;
                while (true) {
                    $row = $db->fetchObject(
                        $db->select(['COUNT(cid)' => 'num'])->from('table.contents')
                            ->where('slug = ? AND cid <> ?', $slug, $insertId)
                    );
                    if ((int) ($row->num ?? 0) <= 0) {
                        break;
                    }
                    $slug = $insertRows['slug'] . '-' . $count;
                    $count++;
                }

                if ($slug !== $insertRows['slug']) {
                    $db->query(
                        $db->update('table.contents')->rows(['slug' => $slug])->where('cid = ?', $insertId)
                    );
                }
            }
        } catch (\Throwable $e) {
            // بازگردانی فایل فیزیکی موفق بوده؛ رکورد DB اختیاری است و نباید
            // جریان ریستور را متوقف کند (فایل به‌صورت «دستی» در دسترس است)
        }
    }

    // ------------------------------------------------------------ حذف قطعی

    /**
     * حذف قطعی یک مدخل از سطل
     */
    public static function deleteEntry(string $id): bool
    {
        $meta = self::readMeta($id);
        if ($meta === null) {
            return false;
        }

        return self::removeEntry(self::absoluteRoot() . '/' . $meta['id']);
    }

    /**
     * خالی کردن کامل سطل
     *
     * خروجی: ['error' => null|string, 'deleted' => int, 'failed' => int]
     */
    public static function emptyAll(): array
    {
        $trash = self::absoluteRoot();
        if ($trash === null || !is_dir($trash)) {
            return ['error' => null, 'deleted' => 0, 'failed' => 0];
        }

        $entries = @scandir($trash);
        if ($entries === false) {
            return ['error' => 'خواندن محتوای سطل ممکن نشد.', 'deleted' => 0, 'failed' => 0];
        }

        $deleted = 0;
        $failed = 0;

        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..' || !preg_match(self::ID_PATTERN, $entry)) {
                continue;
            }

            if (self::removeEntry($trash . '/' . $entry)) {
                $deleted++;
            } else {
                $failed++;
            }
        }

        return ['error' => null, 'deleted' => $deleted, 'failed' => $failed];
    }

    /**
     * حذف فیزیکی یک پوشه‌ی مدخل (فایل + متا + پوشه)
     */
    private static function removeEntry(string $entry): bool
    {
        $trash = self::absoluteRoot();
        if ($trash === null) {
            return false;
        }

        $real = realpath($entry);
        if ($real === false) {
            return false;
        }

        $real = rtrim(str_replace('\\', '/', $real), '/');
        if ($real === $trash || !str_starts_with($real, $trash . '/')) {
            return false;
        }

        foreach (glob($real . '/*') ?: [] as $item) {
            if (is_file($item)) {
                @unlink($item);
            }
        }

        return @rmdir($real);
    }

    // ------------------------------------------------------------ پیش‌نمایش

    /**
     * ارسال فایل یک مدخل برای پیش‌نمایش در پنل (با احراز هویت)
     *
     * خروجی: ['error' => null|string, 'absolute' => string|null, 'mime' => string]
     */
    public static function streamFile(string $id): array
    {
        $meta = self::readMeta($id);
        if ($meta === null) {
            return ['error' => 'مورد یافت نشد.', 'absolute' => null, 'mime' => ''];
        }

        $entry = self::absoluteRoot() . '/' . $meta['id'];
        foreach (glob($entry . '/' . self::FILE_PREFIX . '*') ?: [] as $candidate) {
            if (is_file($candidate) && is_readable($candidate)) {
                return [
                    'error' => null,
                    'absolute' => $candidate,
                    'mime' => Common::mimeContentType($candidate),
                ];
            }
        }

        return ['error' => 'فایل یافت نشد.', 'absolute' => null, 'mime' => ''];
    }
}
