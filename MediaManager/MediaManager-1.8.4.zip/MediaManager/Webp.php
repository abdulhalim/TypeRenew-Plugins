<?php
declare(strict_types=1);

namespace TypechoPlugin\MediaManager;

use Widget\Upload;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class Webp
{
    /** پسوندهای قابل تبدیل (JPG/JPEG/PNG — GIF به‌دلیل انیمیشن و WebP/AVIF به‌دلیل بهینه بودن تبدیل نمی‌شوند) */
    private const CONVERTIBLE = ['jpg', 'jpeg', 'png'];

    /** سقف مگاپیکسل (عرض × ارتفاع) برای تبدیل — بالاتر از این، تبدیل برای محافظت از حافظه رد می‌شود */
    private const MAX_MEGAPIXELS = 24;

    /** کش نتیجه‌ی بررسی پشتیبانی سرور */
    private static ?bool $supported = null;

    /**
     * آیا سرور از فشرده‌سازی WebP پشتیبانی می‌کند؟ (GD + imagewebp)
     */
    public static function supported(): bool
    {
        if (self::$supported !== null) {
            return self::$supported;
        }

        self::$supported = extension_loaded('gd')
            && function_exists('imagewebp')
            && function_exists('imagecreatefromstring')
            && ((int) (imagetypes() & IMG_WEBP)) !== 0;

        return self::$supported;
    }

    /**
     * آیا تبدیل WebP «فعال و در دسترس» است؟
     * (تنظیم افزونه روشن باشد و سرور پشتیبانی کند)
     */
    public static function enabled(): bool
    {
        return self::supported() && ((int) Settings::get('enableWebp', 1)) === 1;
    }

    /**
     * کیفیت فشرده‌سازی (۵۰ تا ۱۰۰)
     */
    public static function quality(): int
    {
        return (int) Settings::get('webpQuality', 85);
    }

    /**
     * آیا این پسوند قابل تبدیل است؟
     */
    public static function convertible(string $ext): bool
    {
        return in_array(strtolower($ext), self::CONVERTIBLE, true);
    }

    /**
     * تبدیل اختیاری فایل بارگذاری‌شده به WebP
     *
     * ورودی $file آرایه‌ی فایل است: یا آرایه‌ی هوک uploadHandle
     * (tmp_name یا bytes/bits)، یا شبه‌فایلِ «فایل ذخیره‌شده روی دیسک»
     * (name + tmp_name مسیر مطلق) که از نسخه‌ی ۱.۸.۰ در هوک beforeUpload
     * برای تبدیلِ پس از ذخیره استفاده می‌شود.
     * خروجی در صورت انجام تبدیل: آرایه‌ی فایل جدید مبتنی بر «bytes» با
     * نام و پسوند .webp — آماده‌ی تحویل به replaceUploadedFile هسته.
     * خروجی null یعنی تبدیل انجام نشد و فایل اصلی باید عیناً ذخیره شود.
     *
     * @param array $file آرایه‌ی فایل بارگذاری‌شده
     * @param string $ext  پسوند پاکسازی‌شده‌ی فایل (کوچک)
     */
    public static function apply(array $file, string $ext): ?array
    {
        if (!self::enabled() || !self::convertible($ext)) {
            return null;
        }

        // پسوند خروجی باید در انواع مجاز سایت باشد؛ وگرنه تبدیل بی‌معناست
        if (!Upload::checkFileType('webp')) {
            return null;
        }

        $bytes = self::readBytes($file);
        if ($bytes === null || $bytes === '') {
            return null;
        }

        // محافظت از حافظه: تصاویر بسیار بزرگ تبدیل نمی‌شوند
        $dims = @getimagesizefromstring($bytes);
        if (!is_array($dims) || (int) $dims[0] < 1 || (int) $dims[1] < 1) {
            return null;
        }

        if (((int) $dims[0] * (int) $dims[1]) > (self::MAX_MEGAPIXELS * 1000000)) {
            return null;
        }

        $webp = self::encode($bytes, self::quality());
        if ($webp === null || strlen($webp) >= strlen($bytes)) {
            // فشرده‌ای که حجم را بهتر نکند یا نمی‌سازد → اصل فایل می‌ماند
            return null;
        }

        // آرایه‌ی فایل جدید: مبتنی بر bytes (replaceUploadedFile هسته این
        // شاخه را با file_put_contents امن می‌نویسد) و پسوند .webp
        $new = $file;
        unset($new['tmp_name'], $new['size']);
        $new['bytes'] = $webp;
        $new['type'] = 'image/webp';

        // نام نمایشی: photo.jpg → photo.webp (پسوند انتهایی با حساسیت کوچک/بزرگ)
        $name = (string) ($file['name'] ?? '');
        $tail = '.' . strtolower($ext);
        if ($name !== '' && str_ends_with(strtolower($name), $tail)) {
            $name = substr($name, 0, -strlen($tail));
        }
        $new['name'] = ($name === '' ? 'image' : $name) . '.webp';

        return $new;
    }

    /**
     * خواندن بایت‌های فایل از هر شکل ورودی هوک
     * (tmp_name فایل آپلودی، یا bytes/bits مسیرهای XmlRPC/API)
     */
    private static function readBytes(array $file): ?string
    {
        if (isset($file['tmp_name']) && is_string($file['tmp_name']) && $file['tmp_name'] !== '') {
            // فقط فایل آپلودی واقعی (برای مسیر فرم‌های عادی)
            if (is_uploaded_file($file['tmp_name'])) {
                $data = @file_get_contents($file['tmp_name']);
                return is_string($data) ? $data : null;
            }

            // آپلودهای غیرفرمی (تست/CLI): فایل موجود روی دیسک
            if (is_file($file['tmp_name'])) {
                $data = @file_get_contents($file['tmp_name']);
                return is_string($data) ? $data : null;
            }

            return null;
        }

        foreach (['bytes', 'bits'] as $key) {
            if (isset($file[$key]) && is_string($file[$key]) && $file[$key] !== '') {
                return $file[$key];
            }
        }

        return null;
    }

    /**
     * فشرده‌سازی بایت‌های تصویر به WebP با حفظ شفافیت
     *
     * مسیرهای فنی (هر دو با آزمون E2E تأیید شده):
 *  - تصویر truecolor → مستقیم با imagealphablending(false) +
 *    imagesavealpha(true) انکد می‌شود (آلفای PNG32 حفظ می‌شود)
 *  - تصویر پالت (PNG8) → imagewebp پالت را نمی‌پذیرد و خروجی
     *    خالی می‌دهد؛ ابتدا روی بوم truecolor تازه‌ای با پس‌زمینه‌ی شفاف
     *    کپی می‌شود (شفافیت tRNS حفظ می‌شود)
     * - خروجی ابتدا به بافر می‌رود؛ در صورت خطا به فایل موقت
     * - در پایان ساختار RIFF....WEBP اعتبارسنجی می‌شود
     *
     * @return string|null بایت‌های WebP یا null در صورت خطا
     */
    private static function encode(string $bytes, int $quality): ?string
    {
        $image = @imagecreatefromstring($bytes);
        if (!$image instanceof \GdImage) {
            return null;
        }

        try {
            if (!imageistruecolor($image)) {
                // PNG پالت → بوم truecolor تازه (تابع imagepalettetruecolor
                // در همه‌ی بیلدهای PHP موجود نیست؛ کپی روی بوم شفاف روش
                // قابل‌حمل و آزموده است)
                $width = imagesx($image);
                $height = imagesy($image);
                $canvas = imagecreatetruecolor($width, $height);

                if (!$canvas) {
                    return null;
                }

                try {
                    imagealphablending($canvas, false);
                    $transparent = imagecolorallocatealpha($canvas, 0, 0, 0, 127);
                    imagefill($canvas, 0, 0, $transparent);
                    imagealphablending($canvas, true);
                    imagecopy($canvas, $image, 0, 0, 0, 0, $width, $height);
                } finally {
                    imagedestroy($image);
                }

                $image = $canvas;
            }

            // حفظ کانال آلفا (شفافیت) در خروجی WebP
            imagealphablending($image, false);
            imagesavealpha($image, true);

            $quality = max(50, min(100, $quality));

            // خروجی به بافر (بدون دیسک)
            if (ob_start()) {
                $ok = imagewebp($image, null, $quality);

                if ($ok) {
                    $webp = (string) ob_get_clean();
                    if (self::isWebp($webp)) {
                        return $webp;
                    }
                    if ($webp !== '') {
                        ob_end_clean();
                    }
                } else {
                    ob_end_clean();
                }
            }

            // جایگزین: نوشتن به فایل موقت
            $tmp = @tempnam(sys_get_temp_dir(), 'mmwebp');
            if ($tmp === false) {
                return null;
            }

            $ok = imagewebp($image, $tmp, $quality);
            $webp = $ok ? (string) @file_get_contents($tmp) : '';
            @unlink($tmp);

            return self::isWebp($webp) ? $webp : null;
        } finally {
            imagedestroy($image);
        }
    }

    /**
     * اعتبارسنجی ساختار فایل WebP (RIFF....WEBP)
     */
    private static function isWebp(string $bytes): bool
    {
        return strlen($bytes) > 12
            && substr($bytes, 0, 4) === 'RIFF'
            && substr($bytes, 8, 4) === 'WEBP';
    }
}
