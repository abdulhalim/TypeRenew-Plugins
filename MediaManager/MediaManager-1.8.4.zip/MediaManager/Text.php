<?php
declare(strict_types=1);

namespace TypechoPlugin\MediaManager;

use Typecho\Common;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * توابع کمکی متن (فرار امن، قالب‌بندی اندازه، نشانی دارایی‌ها)
 */
final class Text
{
    /**
     * فرار امن برای خروجی HTML (همیشه با ENT_QUOTES و UTF-8)
     */
    public static function e($value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }

    /**
     * نمایش خوانای اندازه فایل
     */
    public static function bytes(int $bytes): string
    {
        if ($bytes >= 1073741824) {
            return number_format($bytes / 1073741824, 1) . ' GB';
        }

        if ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 1) . ' MB';
        }

        if ($bytes >= 1024) {
            return number_format(ceil($bytes / 1024)) . ' KB';
        }

        return $bytes . ' B';
    }

    /**
     * نشانی عمومی فایل‌های استاتیک افزونه
     */
    public static function assetUrl(string $path): string
    {
        $options = \Widget\Options::alloc();
        $base = (string) $options->pluginUrl;

        if ($base === '') {
            $base = Common::url('usr/plugins/', (string) $options->siteUrl);
        }

        return Common::url('MediaManager/' . ltrim($path, '/'), $base);
    }

    /**
     * پارامتر کش‌شکن فایل asset — نسخه + زمان آخرین تغییر فایل
     *
     * اگر شماره‌ی نسخه بین دو ساخت یکسان بماند (مثلاً اصلاح باگ بدون
     * تغییر نسخه)، زمان تغییر خود فایل تضمین می‌کند که مرورگر نسخه‌ی
     * قدیمیِ کش‌شده را به‌جای فایل تازه بازنخواند.
     */
    public static function assetCacheParam(string $path): string
    {
        $mtime = @filemtime(__DIR__ . '/' . ltrim($path, '/'));
        return 'v=' . rawurlencode(Plugin::VERSION . ($mtime ? '.' . (string) $mtime : ''));
    }

    /**
     * کدگذاری امن JSON برای درج داخل <script>
     * (پرچم‌های HEX برای جلوگیری از خروج اسکریپت از رشته‌ی JSON)
     */
    public static function jsonForScript($value): string
    {
        return Common::jsonEncode(
            $value,
            JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT,
            'null'
        );
    }
}
