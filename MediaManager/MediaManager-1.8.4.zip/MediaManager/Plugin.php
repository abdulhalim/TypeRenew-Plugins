<?php
declare(strict_types=1);

namespace TypechoPlugin\MediaManager;

use Typecho\Plugin as Hook;
use Typecho\Plugin\PluginInterface;
use Typecho\Widget\Helper\Form;
use Utils\Helper;
use Utils\NoPersonal;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * مدیا منیجر - برای مدیریت تصاویر و فایل‌ها با گرید بندانگشتی، ساخت گالری تصاویر، لایت باکس ، کپی لینک و آپلود.
 *
 * @package MediaManager
 * @author  پوردریایی
 * @link    https://pourdaryaei.ir
 * @since   1.6.0
 * @version 1.8.4
 */
class Plugin implements PluginInterface
{
    use NoPersonal;

    public const VERSION = '1.8.4';

    /**
     * فعال‌سازی افزونه
     */
    public static function activate(): string
    {
        Settings::ensureStored();

        // اندپوینت AJAX انتخابگر رسانه (فقط خواندنی، با توکن CSRF)
        Helper::removeRoute('media_manager_action');
        Helper::addRoute('media_manager_action', '/action/media-manager', Action::class, 'action');

        // پنل «مدیا منیجر» در منوی مدیریت (گروه افزونه‌ها)
        Helper::removePanel(3, 'MediaManager/Panel.php');
        Helper::addPanel(
            3,
            'MediaManager/Panel.php',
            'مدیا منیجر',
            'مدیریت تصاویر و فایل‌ها (گرید بندانگشتی)',
            'contributor',
            false,
            '',
            ['icon' => 'i-image']
        );

        // صفحه‌ی اختصاصی «سطل بازیافت» — پنلی مخفی که فقط از داخل
        // مدیا منیجر (دکمه‌ی سطل) باز می‌شود؛ جستجو، فیلتر نوع، مرتب‌سازی،
        // بازیافت/حذف گروهی و خالی‌سازی کامل همان‌جا انجام می‌شود.
        Helper::removePanel(3, 'MediaManager/TrashPage.php');
        Helper::addPanel(
            3,
            'MediaManager/TrashPage.php',
            'سطل بازیافت مدیا منیجر',
            'بازیافت یا حذف قطعی فایل‌های حذف‌شده',
            'editor',
            true,
            ''
        );

        self::registerHooks();
        
        // آماده‌سازی سطل زباله (حذف نرم) — نسخه ۱.۸.۰
        $trashReady = Trash::ensure();

        $message = _t('افزونه «مدیا منیجر» فعال شد.');

        if (!$trashReady) {
            $message .= _t(' هشدار: پوشه‌ی سطل زباله ساخته نمی‌شود؛ حذف فایل‌ها قطعی است.');
        }

        $message .= _t(' اگر از نسخه پایین‌تر از ۱.۸ استفاده می‌کنید، افزونه را یک بار غیرفعال و دوباره فعال کنید.');

        return $message;
    }

    /**
     * غیرفعال‌سازی افزونه
     */
    public static function deactivate(): string
    {
        Helper::removeRoute('media_manager_action');
        Helper::removePanel(3, 'MediaManager/Panel.php');
        Helper::removePanel(3, 'MediaManager/TrashPage.php');

        return _t('افزونه «مدیا منیجر» غیرفعال شد. (تنظیمات و محتوای سطل بازیافت حفظ شده است)');
    }

    /**
     * ثبت هوک‌های یکپارچه‌سازی
     *
     * نکته: هوک‌ها هنگام «فعال‌سازی» در DB ماندگار می‌شوند؛ پس برای
     * ارتقا از نسخه‌های پیشین (به‌ویژه ۱.۸.۰ که هوک‌های آپلود عوض
     * شده‌اند) باید افزونه یک بار غیرفعال و دوباره فعال شود تا هوک‌های
     * جدید جایگزین شوند.
     */
    private static function registerHooks(): void
    {
        // جانمایی آپلود «پس از ذخیره» — سازگار با افزونه‌های امنیتی:
        // مدیامنجر هیچ هندلری روی uploadHandle ثبت نمی‌کند تا بر سر فایل
        // موقت آپلود با هسته یا افزونه‌های امنیتی (مثل RenewShield) جدال
        // نکند؛ ترتیب فعال‌سازی افزونه‌ها هم بی‌اثر است. هوک beforeUpload
        // هسته پس از ذخیره‌ی فایل با آرایه‌ی نتیجه فراخوانی می‌شود و فایل
        // ذخیره‌شده را به پوشه‌ی انتخابی منتقل/به WebP تبدیل می‌کند؛ سپس
        // هوک upload رکورد پیوست را همگام می‌کند.
        Hook::factory('Widget\Upload')->beforeUpload = [Uploader::class, 'beforeUpload'];
        Hook::factory('Widget\Upload')->upload = [Uploader::class, 'upload'];

        // حذف نرم: حذف پیوست‌های کتابخانه به‌جای unlink فیزیکی، به سطل
        // زباله (.trash داخل uploads) منتقل می‌شود تا از صفحه‌ی اختصاصی
        // سطل قابل بازگردانی یا حذف قطعی باشد.
        Hook::factory('Widget\Upload')->deleteHandle = [Trash::class, 'handleDelete'];

        // پنل پیش‌نمایش تصاویر در انتهای ستون ویرایشگر
        Hook::factory('admin/write-post.php')->content = [Editor::class, 'renderPreviewPanel'];
        Hook::factory('admin/write-page.php')->content = [Editor::class, 'renderPreviewPanel'];

        // تزریق استایل/اسکریپت پس از اسکریپت‌های اصلی (هوک bottom در write-foot.php)
        Hook::factory('admin/write-post.php')->bottom = [Editor::class, 'injectEditorAssets'];
        Hook::factory('admin/write-page.php')->bottom = [Editor::class, 'injectEditorAssets'];

        // امکانات سمت پوسته: لایت‌باکس نوشته‌ها + گالری تصویری
        // (فقط وقتی فعال باشند دارایی تزریق می‌شود)
        Hook::factory('Widget\Archive')->header = [Front::class, 'injectStyles'];
        Hook::factory('Widget\Archive')->footer = [Front::class, 'injectScripts'];
    }

    /**
     * فرم تنظیمات افزونه
     */
    public static function config(Form $form): void
    {
        $settings = Settings::load();

        $pageSize = new Form\Element\Text(
            'pageSize',
            null,
            (string) $settings['pageSize'],
            _t('تعداد آیتم هر صفحه'),
            _t('تعداد تصاویر/فایل‌هایی که در هر صفحه از گرید مدیا منیجر نمایش داده می‌شود (بین ۱۲ تا ۹۶).')
        );
        $pageSize->input->setAttribute('class', 'text-s mono');
        $form->addInput($pageSize);

        $enableEditorGrid = new Form\Element\Radio(
            'enableEditorGrid',
            ['1' => _t('فعال'), '0' => _t('غیرفعال')],
            (string) $settings['enableEditorGrid'],
            _t('گرید بندانگشتی در برگه نوشتن'),
            _t('در صفحه «ارسال پست / صفحه جدید»، فهرست پیوست‌ها به‌جای لینک متنی به شکل گرید بندانگشتی با پیش‌نمایش و دکمه کپی لینک نمایش داده شود.')
        );
        $form->addInput($enableEditorGrid);

        $enablePreview = new Form\Element\Radio(
            'enablePreview',
            ['1' => _t('فعال'), '0' => _t('غیرفعال')],
            (string) $settings['enablePreview'],
            _t('پنل پیش‌نمایش پایین ویرایشگر'),
            _t('با درج لینک تصویر داخل متن پست، بندانگشتی همان تصاویر در پایین ویرایشگر نمایش داده شود تا بفهمید چه تصویری به پست پیوست کرده‌اید.')
        );
        $form->addInput($enablePreview);

        $enablePicker = new Form\Element\Radio(
            'enablePicker',
            ['1' => _t('فعال'), '0' => _t('غیرفعال')],
            (string) $settings['enablePicker'],
            _t('انتخابگر رسانه در ویرایشگر'),
            _t('دکمه «افزودن از کتابخانه» در صفحه نوشتن اضافه می‌شود تا بتوانید مستقیماً تصاویر موجود در مدیا منیجر را جستجو، انتخاب و در متن پست درج کنید.')
        );
        $form->addInput($enablePicker);

        $disableSystemUpload = new Form\Element\Radio(
            'disableSystemUpload',
            ['1' => _t('فعال'), '0' => _t('غیرفعال')],
            (string) $settings['disableSystemUpload'],
            _t('غیرفعال‌سازی آپلودر پیش‌فرض سیستم'),
            _t('هنگامی که «انتخابگر رسانه در ویرایشگر» فعال است، ناحیه‌ی آپلود و فهرست پیوست‌های پیش‌فرض سیستم در برگه پیوست‌ها مخفی می‌شود و همه‌ی کارها (انتخاب از کتابخانه و بارگذاری فایل جدید از داخل انتخابگر) از طریق مدیا منیجر انجام می‌شود. در ویرایشگر تمام‌صفحه‌ی نگارش هم فقط پنل مدیا منیجر نمایش داده می‌شود. اگر به آپلودر پیش‌فرض نیاز دارید این گزینه را غیرفعال کنید.')
        );
        $form->addInput($disableSystemUpload);

        // توضیح وضعیت سرور برای تبدیل WebP
        $webpNote = Webp::supported()
            ? _t('این سرور از فشرده‌سازی WebP پشتیبانی می‌کند.')
            : _t('هشدار: PHP این سرور دارای GD با پشتیبانی WebP نیست؛ تا زمانی که افزونه‌ی GD با WebP نصب نشود، تبدیل انجام نمی‌شود و فایل‌ها عیناً ذخیره می‌شوند.');

        $enableWebp = new Form\Element\Radio(
            'enableWebp',
            ['1' => _t('فعال'), '0' => _t('غیرفعال')],
            (string) $settings['enableWebp'],
            _t('تبدیل تصاویر به WebP هنگام آپلود'),
            _t('تصاویر JPG/JPEG/PNG در لحظه‌ی آپلود به WebP تبدیل می‌شوند تا حجم فایل و پهنای مصرفی صفحه‌ها کم شود. شفافیت PNG حفظ می‌شود؛ فایل‌های GIF (به‌دلیل انیمیشن)، WebP و AVIF دست‌نخورده می‌مانند. اگر نسخه‌ی WebP از فایل اصلی بزرگ‌تر شود، اصل فایل نگه داشته می‌شود. تبدیل «پس از ذخیره‌ی امن فایل» و فقط در مسیرهای پنل و انتخابگر ویرایشگر انجام می‌شود؛ فایل‌های XmlRPC عیناً ذخیره می‌شوند.') . '<br />' . $webpNote
        );
        $form->addInput($enableWebp);

        $webpQuality = new Form\Element\Text(
            'webpQuality',
            null,
            (string) $settings['webpQuality'],
            _t('کیفیت فشرده‌سازی WebP'),
            _t('عددی بین ۵۰ تا ۱۰۰ — مقدار پیش‌فرض ۸۵ برای عکس‌های وب توصیه می‌شود؛ عدد بالاتر یعنی کیفیت بیشتر و حجم بزرگ‌تر.')
        );
        $webpQuality->input->setAttribute('class', 'text-s mono');
        $form->addInput($webpQuality);

        // ------------------------------------------------------------
        // امکانات سمت پوسته (نمایش عمومی نوشته‌ها)
        // ------------------------------------------------------------

        $enableLightbox = new Form\Element\Radio(
            'enableLightbox',
            ['1' => _t('فعال'), '0' => _t('غیرفعال')],
            (string) $settings['enableLightbox'],
            _t('لایت‌باکس تصاویر نوشته‌ها (سمت پوسته)'),
            _t('برای پوسته‌هایی که لایت‌باکس ندارند: با کلیک روی تصاویر درج‌شده در متن نوشته، تصویر در لایت‌باکس بزرگ‌شده نمایش داده می‌شود. اگر پوسته یا کتابخانه‌ی دیگری لایت‌باکس فعال داشته باشد (مثل پوسته‌ی پرنیان با گزینه‌ی لایت‌باکس روشن)، این قابلیت به‌صورت خودکار غیرفعال می‌ماند تا تداخلی پیش نیاید. تصاویر داخل گالری همیشه از لایت‌باکس خودِ گالری استفاده می‌کنند.')
        );
        $form->addInput($enableLightbox);

        $enableGallery = new Form\Element\Radio(
            'enableGallery',
            ['1' => _t('فعال'), '0' => _t('غیرفعال')],
            (string) $settings['enableGallery'],
            _t('گالری تصویری از تصاویر نوشته (سمت پوسته)'),
            _t('برای پوسته‌هایی که گالری ندارند: تصاویر پشت‌سرهمِ نوشته (دو تصویر یا بیشتر، بدون متن بینشان) به‌صورت خودکار به گرید بندانگشتی تبدیل می‌شوند و با کلیک روی هر بندانگشکی، لایت‌باکس گالری با دکمه‌های «قبلی/بعدی» و شمارنده باز می‌شود. تصویر تکی وسط متن به شکل عادی باقی می‌ماند و از لایت‌باکس معمولی پیروی می‌کند؛ بنابراین این دو هرگز با هم تداخل نمی‌کنند.')
        );
        $form->addInput($enableGallery);

        $galleryColumns = new Form\Element\Radio(
            'galleryColumns',
            [
                '2' => _t('۲ ستون'),
                '3' => _t('۳ ستون'),
                '4' => _t('۴ ستون'),
            ],
            (string) $settings['galleryColumns'],
            _t('تعداد ستون‌های گالری'),
            _t('هر بندانگشکی در گرید گالری چند ستون عرض داشته باشد. روی نمایشگرهای باریک‌تر از ۶۰۰ پیکسل، گالری همیشه دو ستونه می‌شود.')
        );
        $form->addInput($galleryColumns);

        $contentSelector = new Form\Element\Text(
            'contentSelector',
            null,
            (string) $settings['contentSelector'],
            _t('سلکتور ناحیه‌ی متن نوشته'),
            _t('سلکتور CSS ناحیه‌ی محتوای پست در پوسته‌ی شما. مقدار پیش‌فرض برای اغلب پوسته‌ها مناسب است (مثل .post-content)؛ فقط اگر تصاویر پست شما شکل نگرفتند یا محدوده‌ی اشتباهی گرفته شدند آن را تغییر دهید. چند سلکتور را با کاما جدا کنید.')
        );
        $contentSelector->input->setAttribute('class', 'text-s mono');
        $form->addInput($contentSelector);
    }

    /**
     * ذخیره تنظیمات (پاکسازی مقادیر)
     */
    public static function configHandle(array $settings, bool $isInit): void
    {
        Settings::store($settings);
    }
}
