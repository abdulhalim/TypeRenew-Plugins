<?php
declare(strict_types=1);

namespace TypechoPlugin\MediaManager;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}


final class Editor
{
    /**
     * رندر پنل «پیوست‌های پست» (تصویر + فایل) در انتهای ستون ویرایشگر
     */
    public static function renderPreviewPanel($content): void
    {
        $settings = Settings::load();

        // بدون پنل پیش‌نمایش، چیزی رندر نمی‌کنیم (دکمه کتابخانه فقط در تب پیوست‌ها می‌ماند)
        if ((int) $settings['enablePreview'] !== 1) {
            return;
        }
        ?>
        <section id="mm-editor-panel"
                 class="mm-editor-panel"
                 dir="rtl"
                 aria-label="<?php echo Text::e('پیوست‌ها و تصاویر مرتبط با این پست'); ?>">
            <div class="mm-editor-panel-head">
                <span class="mm-editor-panel-title"><?php echo Text::e('پیوست‌های پست'); ?></span>
                <span class="mm-editor-panel-count" id="mm-preview-count">0</span>
                <span class="mm-editor-panel-hint"><?php echo Text::e('فایل‌های پیوست‌شده به این پست (تصویر یا فایل) و هر لینک تصویری که داخل متن درج کنید، اینجا نمایش داده می‌شود.'); ?></span>
            </div>
            <div class="mm-preview-grid" id="mm-preview-grid" aria-live="polite"></div>
            <p class="mm-preview-empty" id="mm-preview-empty"><?php echo Text::e('هنوز پیوست یا تصویری برای این پست ثبت نشده است.'); ?></p>
        </section>
        <?php
    }

    /**
     * تزریق استایل و اسکریپت ادیتور (پس از file-upload-js.php)
     */
    public static function injectEditorAssets($content): void
    {
        $settings = Settings::load();

        if (
            (int) $settings['enableEditorGrid'] !== 1
            && (int) $settings['enablePreview'] !== 1
            && (int) $settings['enablePicker'] !== 1
        ) {
            return;
        }

        $options = \Widget\Options::alloc();
        $security = \Widget\Security::alloc();
        $user = \Widget\User::alloc();

        // مرور پوشه‌ای انتخابگر فقط برای ویراستار/مدیر
        $canBrowse = $user->pass('editor', true);

        // محدودیت اندازه آپلود PHP (همان محاسبه هسته)
        $phpMaxFilesize = function_exists('ini_get') ? trim((string) ini_get('upload_max_filesize')) : '0';
        if (preg_match("/^([0-9]+)([a-z]{1,2})?$/i", $phpMaxFilesize, $matches)) {
            $size = intval($matches[1]);
            $unit = $matches[2] ?? 'b';
            $phpMaxFilesize = (string) round($size * pow(1024, stripos('bkmgtpezy', $unit[0])));
        }

        $config = [
            'version' => Plugin::VERSION,
            'enableEditorGrid' => (int) $settings['enableEditorGrid'] === 1,
            'enablePreview' => (int) $settings['enablePreview'] === 1,
            'enablePicker' => (int) $settings['enablePicker'] === 1,
            'disableSystemUpload' => (int) $settings['disableSystemUpload'] === 1,
            'canBrowse' => $canBrowse,
            'pickerUrl' => $security->getIndex('/action/media-manager?do=pick'),
            'browseUrl' => $security->getIndex('/action/media-manager?do=browse'),
            'mkdirUrl' => $security->getIndex('/action/media-manager?do=mkdir'),
            'renameUrl' => $security->getIndex('/action/media-manager?do=renamedir'),
            'renameFileUrl' => $security->getIndex('/action/media-manager?do=renamefile'),
            'rmdirUrl' => $security->getIndex('/action/media-manager?do=rmdir'),
            'treeUrl' => $security->getIndex('/action/media-manager?do=tree'),
            'moveUrl' => $security->getIndex('/action/media-manager?do=move'),
            'deleteUrl' => $security->getIndex('/action/contents-attachment-edit'),
            'uploadUrl' => $security->getIndex('/action/upload'),
            'siteUrl' => (string) $options->siteUrl,
            'uploadTypes' => array_values((array) $options->allowedAttachmentTypes),
            'maxSize' => max(0, (int) $phpMaxFilesize),
            'uploadDir' => Browser::uploadDirSetting(),
            'icons' => Icons::jsMap(),
            'fileKinds' => Icons::kindMap(),
            'kindIcons' => Icons::kindIcons(),
            'kindLabels' => Icons::kindLabels(),
            'filterLabels' => Icons::FILTER_LABELS,
            'strings' => [
                'copy' => 'کپی لینک',
                'copied' => 'لینک کپی شد',
                'copyFailed' => 'کپی خودکار ممکن نشد؛ لینک را دستی انتخاب و کپی کنید.',
                'copyLinksOf' => 'کپی لینک‌ها',
                'preview' => 'پیش‌نمایش',
                'close' => 'بستن (Esc)',
                'insert' => 'درج در متن',
                'insertSelected' => 'درج موارد انتخابی در متن',
                'selected' => 'انتخاب‌شده',
                'pickerTitle' => 'افزودن از کتابخانه رسانه',
                'pickerEmpty' => 'هیچ فایلی یافت نشد.',
                'pickerLoading' => 'در حال بارگذاری…',
                'pickerSearch' => 'جستجوی نام فایل…',
                'pickerSearchFolder' => 'جستجو در این پوشه…',
                'pickerError' => 'خطا در دریافت فهرست رسانه‌ها.',
                'deleteConfirm' => 'این فایل به سطل زباله منتقل شود؟ (قابل بازگردانی از سطل زباله در پنل مدیا منیجر)',
                'deleteConfirmTitle' => 'انتقال به سطل بازیافت',
                'deleteConfirmYes' => 'حذف',
                'deleteError' => 'حذف فایل ناموفق بود.',
                'delete' => 'حذف پیوست',
                'deleted' => 'حذف شد',
                // نکته: در نسخه‌ی ۱.۸.۴، دکمه‌ی «حذف پیوست» (انتقال به سطل)
                // با دکمه‌ی ضربدر «حذف از لیست» جایگزین شد. این دکمه فقط
                // آیتم را از فهرست پیوست‌های پست فعلی برمی‌دارد و فایل را
                // دست‌نخورده باقی می‌گذارد. برای حذف واقعی فایل، از پنل
                // «مدیا منیجر» استفاده کنید.
                'removeFromList' => 'حذف از لیست',
                'removedFromList' => 'از لیست پیوست‌ها حذف شد',
                'inserted' => 'در متن درج شد',
                'notImage' => 'پیش‌نمایش فقط برای تصاویر امکان‌پذیر است.',
                'openFile' => 'باز کردن فایل (تب جدید)',
                'file' => 'فایل',
                'image' => 'تصویر',
                'folder' => 'پوشه',
                'folders' => 'پوشه‌ها',
                // پیش‌نمایش پیوست‌ها زیر کادر آپلود (تب پیوست‌ها)
                'tabPreviewTitle' => 'پیوست‌های این پست',
                'tabPreviewEmpty' => 'هنوز پیوستی برای این پست ثبت نشده است؛ فایل را روی کادر بالا بکشید و رها کنید.',
                'tabPreviewMore' => 'و %s مورد دیگر…',
                'tabPreviewLess' => 'نمایش کمتر',
                'openLibrary' => 'کتابخانه رسانه',
                'addToPost' => 'افزودن از کتابخانه',
                'linkBoxTitle' => 'لینک‌های کپی‌شده',
                'mmHint' => 'برای دیدن بندانگشتی‌ها و کپی لینک، از گرید زیر استفاده کنید.',
                'newFolder' => 'پوشه جدید',
                'folderNamePh' => 'نام پوشه جدید… (مثلاً: docs)',
                'createFolder' => 'ایجاد پوشه',
                'cancelNewFolder' => 'انصراف',
                'folderCreated' => 'پوشه ساخته شد.',
                'folderInvalidName' => 'نام پوشه معتبر نیست (فقط حروف، اعداد، فاصله، نقطه، خط تیره و زیرخط؛ حداکثر ۹۶ کاراکتر؛ نام نباید با نقطه شروع شود).',
                'mkdirError' => 'ایجاد پوشه ناموفق بود.',
                // تغییر نام و حذف پوشه از خود انتخابگر
                'renameFolder' => 'تغییر نام پوشه',
                'renameFolderHint' => 'نام جدید پوشه «%s» را وارد کنید:',
                'renameSave' => 'ذخیره',
                'renameCancel' => 'انصراف',
                'renameDone' => 'نام پوشه تغییر کرد.',
                'renameError' => 'تغییر نام پوشه ناموفق بود؛ ممکن است دسترسی یا توکن منقضی شده باشد.',
                'deleteFolder' => 'حذف پوشه',
                'deleteFolderConfirm' => 'پوشه «%s» حذف شود؟ (فقط پوشه‌های خالی قابل حذف‌اند)',
                'deleteFolderConfirmYes' => 'حذف پوشه',
                'folderDeleted' => 'پوشه حذف شد.',
                'folderDeleteError' => 'حذف پوشه ناموفق بود؛ ممکن است دسترسی یا توکن منقضی شده باشد.',
                // بارگذاری فایل از خود انتخابگر
                'uploadFiles' => 'بارگذاری فایل',
                'uploadHere' => 'بارگذاری فایل در همین پوشه',
                'uploading' => 'در حال بارگذاری…',
                'uploaded' => 'بارگذاری شد',
                'uploadToFolder' => 'ذخیره شد در',
                'uploadErrorSize' => 'حجم فایل بیش از حد مجاز سرور است.',
                'uploadErrorType' => 'این پسوند فایل مجاز نیست.',
                'uploadError' => 'بارگذاری ناموفق بود.',
                'uploadDropHint' => 'فایل‌ها را اینجا رها کنید',
                // کادر آپلود (جایگزین دکمه‌ی ساده در تب پیوست‌ها)
                'uploadBoxTitle' => 'آپلود فایل',
                'uploadBoxHint' => 'فایل‌ها را اینجا بکشید و رها کنید، یا برای انتخاب از کتابخانه کلیک کنید',
                // فیلتر نوع فایل
                'filters' => 'نوع فایل',
                // تغییر نام فایل از انتخابگر
                'renameFile' => 'تغییر نام فایل',
                'renameFileHint' => 'نام جدید فایل «%s» را وارد کنید:',
                'renameFileTitleHint' => 'عنوان جدید «%s» را وارد کنید (نام فایل روی سرور تغییر نمی‌کند):',
                'renameFileDone' => 'نام فایل تغییر کرد.',
                'renameTitleDone' => 'عنوان فایل تغییر کرد.',
                'renameFileError' => 'تغییر نام فایل ناموفق بود؛ ممکن است دسترسی یا توکن منقضی شده باشد.',
                'renameFileInvalid' => 'نام فایل معتبر نیست (حداکثر ۹۶ کاراکتر؛ فقط حروف، اعداد، فاصله، نقطه، خط تیره و زیرخط).',
                'renameTitleInvalid' => 'عنوان جدید نمی‌تواند خالی باشد.',
                // انتقال فایل به پوشه‌ی دیگر از انتخابگر
                'moveSelected' => 'انتقال به پوشه',
                'moveTitle' => 'انتقال به پوشه‌ی دیگر',
                'moveTargetLabel' => 'پوشه‌ی مقصد را انتخاب کنید:',
                'moveRootLabel' => 'ریشه‌ی uploads',
                'moveCurrentLabel' => 'محل فعلی',
                'moveNoTarget' => 'ابتدا پوشه‌ی مقصد را انتخاب کنید.',
                'moveSameTarget' => 'فایل‌های انتخابی همین‌جا هستند؛ پوشه‌ی دیگری انتخاب کنید.',
                'moveTreeError' => 'دریافت فهرست پوشه‌ها ناموفق بود.',
                'moveDone' => 'انتقال انجام شد.',
                'moveError' => 'انتقال ناموفق بود؛ ممکن است دسترسی یا توکن منقضی شده باشد.',
                'moveLoadingTree' => 'در حال دریافت پوشه‌ها…',
            ],
        ];

        // کش‌شکن هر فایل: نسخه + زمان تغییر خود فایل (تا با نسخه‌های
        // تکراری هم فایل تازه از کش رد نشود)
        echo '<link rel="stylesheet" href="'
            . Text::e(Text::assetUrl('assets/editor.css') . '?' . Text::assetCacheParam('assets/editor.css'))
            . '">';

        echo '<script>window.MM_EDITOR = ' . Text::jsonForScript($config) . ';</script>';

        // مودال یکدست پیام‌های حساس — پیش از اسکریپت اصلی
        echo '<script src="'
            . Text::e(Text::assetUrl('assets/mm-confirm.js') . '?' . Text::assetCacheParam('assets/mm-confirm.js'))
            . '"></script>';

        echo '<script src="'
            . Text::e(Text::assetUrl('assets/editor.js') . '?' . Text::assetCacheParam('assets/editor.js'))
            . '"></script>';
    }
}
