<?php
declare(strict_types=1);

namespace TypechoPlugin\MediaManager;

use Typecho\Common;
use Typecho\Db;
use Widget\Options;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class Browser
{
    /** سقف تعداد پوشه‌های نمایش‌داده‌شده در هر لیست */
    private const MAX_FOLDERS = 200;

    /** سقف تعداد ردیف‌های پیوست برای ساخت نقشه‌ی DB */
    private const MAX_ATTACHMENT_ROWS = 20000;

    /** سقف عمق درخت پوشه‌ها در دیالوگ «انتقال» */
    private const MAX_TREE_DEPTH = 6;

    /** سقف تعداد پوشه‌های درخت در دیالوگ «انتقال» */
    private const MAX_TREE_FOLDERS = 500;

    /** سقف تعداد فایل‌های هر درخواست انتقال */
    private const MAX_MOVE_PATHS = 100;

    /** پسوندهای تصویری (همان فهرست هسته) */
    private const IMAGE_TYPES = ['gif', 'jpg', 'jpeg', 'png', 'tiff', 'bmp', 'webp', 'avif'];

    /** کش نقشه‌ی پیوست‌های DB (مسیر → اطلاعات) */
    private static ?array $attachmentMap = null;

    /**
     * تنظیم مسیر نسبی پوشه‌ی uploads (مثل /usr/uploads)
     */
    public static function uploadDirSetting(): string
    {
        $dir = defined('__TYPECHO_UPLOAD_DIR__') ? (string) __TYPECHO_UPLOAD_DIR__ : '/usr/uploads';
        $dir = str_replace('\\', '/', $dir);
        return '/' . trim($dir, '/');
    }

    /**
     * مسیر مطلق ریشه‌ی uploads روی دیسک (تثبیت‌شده با realpath) یا null
     */
    public static function absoluteRoot(): ?string
    {
        $base = defined('__TYPECHO_UPLOAD_ROOT_DIR__') ? (string) __TYPECHO_UPLOAD_ROOT_DIR__ : __TYPECHO_ROOT_DIR__;
        $root = realpath($base . '/' . ltrim(self::uploadDirSetting(), '/'));
        if ($root === false || !is_dir($root)) {
            return null;
        }

        return rtrim(str_replace('\\', '/', $root), '/');
    }

    /**
     * نرمال‌سازی و اعتبارسنجی مسیر نسبی ورودی
     *
     * ورودی: '2026/09' یا '' (ریشه) — خروجی مسیر نسبی امن یا null در صورت نامعتبر بودن.
     * قواعد: بدون '..'، بدون بایت NUL، بدون بک‌اسلش، بدون کاراکتر کنترلی،
     * بدون قطعه‌ی خالی بین اسلش‌ها و بدون نام شروع‌شونده با نقطه.
     */
    public static function sanitizeRelative(string $path): ?string
    {
        $path = trim(str_replace('\\', '/', $path));

        if ($path === '' || $path === '.' || $path === '/') {
            return '';
        }

        if (str_contains($path, "\0")) {
            return null;
        }

        // رد کاراکترهای کنترلی
        if (preg_match('/[\x00-\x1F\x7F]/', $path)) {
            return null;
        }

        $path = trim($path, '/');
        if ($path === '') {
            return '';
        }

        $segments = explode('/', $path);
        foreach ($segments as $segment) {
            if ($segment === '' || $segment === '.' || $segment === '..') {
                return null;
            }

            // نام‌های مخفی یا شروع با نقطه مجاز نیستند
            if (str_starts_with($segment, '.')) {
                return null;
            }

            // نام پوشه/فایل حداکثر ۲۵۵ بایت
            if (strlen($segment) > 255) {
                return null;
            }
        }

        return implode('/', $segments);
    }

    /**
     * تثبیت مسیر نسبی به مسیر مطلقِ «موجود و داخل ریشه»
     *
     * فقط دایرکتوری‌های واقعی (بدون symlink) پذیرفته می‌شوند.
     */
    public static function resolveDirectory(string $relativePath): ?string
    {
        $relativePath = self::sanitizeRelative($relativePath);
        if ($relativePath === null) {
            return null;
        }

        $root = self::absoluteRoot();
        if ($root === null) {
            return null;
        }

        if ($relativePath === '') {
            return $root;
        }

        // رد سریع symlink در سطح قطعه‌های مسیر
        $current = $root;
        foreach (explode('/', $relativePath) as $segment) {
            $next = $current . '/' . $segment;
            if (is_link($next) || !is_dir($next)) {
                return null;
            }
            $current = $next;
        }

        // تثبیت نهایی و بررسی محدوده
        $real = realpath($current);
        if ($real === false) {
            return null;
        }

        $real = rtrim(str_replace('\\', '/', $real), '/');
        if ($real !== $root && !str_starts_with($real, $root . '/')) {
            return null;
        }

        return $real;
    }

    /**
     * تثبیت مسیر نسبی یک «فایل» موجود داخل ریشه (بدون symlink)
     */
    public static function resolveFile(string $relativePath): ?string
    {
        $relativePath = self::sanitizeRelative($relativePath);
        if ($relativePath === null || $relativePath === '') {
            return null;
        }

        $root = self::absoluteRoot();
        if ($root === null) {
            return null;
        }

        $parent = self::resolveDirectory(dirname($relativePath));
        if ($parent === null) {
            return null;
        }

        $filename = basename($relativePath);
        $absolute = $parent . '/' . $filename;

        if (is_link($absolute) || !is_file($absolute)) {
            return null;
        }

        $real = realpath($absolute);
        if ($real === false) {
            return null;
        }

        $real = rtrim(str_replace('\\', '/', $real), '/');
        if ($real !== $root && !str_starts_with($real, $root . '/')) {
            return null;
        }

        return $real;
    }

    /**
     * نشانی عمومی یک فایل نسبی (همان منطق attachmentHandle هسته)
     */
    public static function fileUrl(string $relativePath): string
    {
        $relativePath = self::sanitizeRelative($relativePath) ?? '';
        $path = rtrim(self::uploadDirSetting(), '/') . '/' . ltrim($relativePath, '/');

        return Common::url(
            $path,
            defined('__TYPECHO_UPLOAD_URL__') ? (string) __TYPECHO_UPLOAD_URL__ : (string) Options::alloc()->siteUrl
        );
    }

    /**
     * اعتبارسنجی نام پوشه‌ی جدید (تک قطعه، بدون مسیر)
     *
     * مجاز: حروف/اعداد هر زبان (از جمله فارسی)، فاصله، نقطه (نه در ابتدا)،
     * خط تیره و زیرخط — حداکثر ۹۶ کاراکتر و UTF-8 معتبر.
     */
    public static function sanitizeFolderName(string $name): ?string
    {
        $name = trim(str_replace("\t", ' ', $name));
        $name = preg_replace('/\s+/', ' ', $name) ?? '';

        if ($name === '' || strlen($name) > 96) {
            return null;
        }

        if (!mb_check_encoding($name, 'UTF-8')) {
            return null;
        }

        if (!preg_match('/^[\p{L}\p{N}][\p{L}\p{N} _.\-]{0,95}$/u', $name)) {
            return null;
        }

        // نام‌های رزروشده‌ی ویندوز (برای سازگاری هنگام انتقال آرشیو)
        $lower = strtolower($name);
        $reserved = ['con', 'prn', 'aux', 'nul'];
        if (in_array($lower, $reserved, true)) {
            return null;
        }

        if (preg_match('/^(com|lpt)[1-9]$/i', $name)) {
            return null;
        }

        return $name;
    }

    /**
     * ایجاد پوشه‌ی جدید داخل مسیر والد (editor+/admin با توکن CSRF از Action)
     *
     * خروجی: ['error' => null, 'path' => 'parent/name', 'name' => 'name']
     *         یا ['error' => 'پیام فارسی', 'path' => null, 'name' => null]
     */
    public static function createFolder(string $parentPath, string $name): array
    {
        $name = self::sanitizeFolderName($name);
        if ($name === null) {
            return [
                'error' => 'نام پوشه معتبر نیست (حداکثر ۹۶ کاراکتر؛ فقط حروف، اعداد، فاصله، نقطه، خط تیره و زیرخط؛ نام نباید با نقطه شروع شود).',
                'path' => null,
                'name' => null,
            ];
        }

        $parent = self::resolveDirectory($parentPath);
        if ($parent === null) {
            return [
                'error' => 'پوشه‌ی والد در uploads یافت نشد.',
                'path' => null,
                'name' => null,
            ];
        }

        $target = $parent . '/' . $name;
        if (file_exists($target) || is_link($target)) {
            return [
                'error' => 'پوشه یا فایلی با همین نام از قبل در این مسیر وجود دارد.',
                'path' => null,
                'name' => null,
            ];
        }

        if (!is_writable($parent)) {
            return [
                'error' => 'دسترسی نوشتن به این پوشه روی سرور ممکن نیست.',
                'path' => null,
                'name' => null,
            ];
        }

        if (!@mkdir($target, 0755, false) && !is_dir($target)) {
            return [
                'error' => 'ایجاد پوشه ناموفق بود.',
                'path' => null,
                'name' => null,
            ];
        }

        @chmod($target, 0755);

        $relativeParent = self::sanitizeRelative($parentPath) ?? '';

        return [
            'error' => null,
            'path' => ($relativeParent === '' ? '' : $relativeParent . '/') . $name,
            'name' => $name,
        ];
    }

    /**
     * تغییر نام پوشه (editor+/admin با توکن CSRF از Action)
     *
     * ورودی: path (مسیر نسبی پوشه‌ی فعلی) + name (نام جدید تک‌قطعه‌ای)
     *
     * امنیت و سازگاری:
     *  - پوشه با resolveDirectory تثبیت می‌شود (realpath + containment + رد symlink)
     *  - نام جدید با sanitizeFolderName اعتبارسنجی می‌شود (بدون مسیر/نقطه‌ی ابتدایی)
     *  - rename فقط داخل همان والد انجام می‌شود (جابه‌جایی پوشه مجاز نیست)
     *  - تداخل نام در والد رد می‌شود
     *  - رکوردهای پیوست DB که داخل این پوشه (یا زیرپوشه‌هایش) هستند با
     *    پیشوند مسیر جدید همگام می‌شوند؛ اگر به‌روزرسانی DB شکست بخورد،
     *    تغییر نام فیزیکی rollback می‌شود
     *
     * خروجی: ['error' => null, 'path' => مسیر جدید, 'name' => نام جدید,
     *          'dbUpdated' => تعداد رکوردهای همگام‌شده]
     */
    public static function renameFolder(string $path, string $newName): array
    {
        $oldRelative = self::sanitizeRelative($path);
        if ($oldRelative === null) {
            return ['error' => 'مسیر پوشه نامعتبر است.', 'path' => null, 'name' => null, 'dbUpdated' => 0];
        }

        if ($oldRelative === '') {
            return ['error' => 'ریشه‌ی uploads قابل تغییر نام نیست.', 'path' => null, 'name' => null, 'dbUpdated' => 0];
        }

        $name = self::sanitizeFolderName($newName);
        if ($name === null) {
            return [
                'error' => 'نام پوشه معتبر نیست (حداکثر ۹۶ کاراکتر؛ فقط حروف، اعداد، فاصله، نقطه، خط تیره و زیرخط؛ نام نباید با نقطه شروع شود).',
                'path' => null,
                'name' => null,
                'dbUpdated' => 0,
            ];
        }

        $oldAbsolute = self::resolveDirectory($oldRelative);
        if ($oldAbsolute === null) {
            return ['error' => 'پوشه مورد نظر در uploads یافت نشد.', 'path' => null, 'name' => null, 'dbUpdated' => 0];
        }

        $oldName = basename($oldRelative);
        if ($oldName === $name) {
            return ['error' => null, 'path' => $oldRelative, 'name' => $name, 'dbUpdated' => 0];
        }

        $parentRelative = dirname($oldRelative);
        $parentRelative = $parentRelative === '.' ? '' : $parentRelative;

        $parentAbsolute = self::resolveDirectory($parentRelative);
        if ($parentAbsolute === null) {
            return ['error' => 'پوشه‌ی والد در uploads یافت نشد.', 'path' => null, 'name' => null, 'dbUpdated' => 0];
        }

        $newRelative = ($parentRelative === '' ? '' : $parentRelative . '/') . $name;
        $newAbsolute = $parentAbsolute . '/' . $name;

        if (file_exists($newAbsolute) || is_link($newAbsolute)) {
            return [
                'error' => 'پوشه یا فایلی با همین نام از قبل در این مسیر وجود دارد.',
                'path' => null,
                'name' => null,
                'dbUpdated' => 0,
            ];
        }

        if (!is_writable($parentAbsolute)) {
            return ['error' => 'دسترسی نوشتن به این پوشه روی سرور ممکن نیست.', 'path' => null, 'name' => null, 'dbUpdated' => 0];
        }

        // رکوردهای DB داخل این پوشه (یا زیرپوشه‌های آن) — قبل از تغییر نام
        $oldKey = self::attachmentKey($oldRelative);
        $map = self::attachmentMap();
        $affected = [];
        foreach ($map as $key => $info) {
            if ($key === $oldKey || str_starts_with($key, $oldKey . '/')) {
                $affected[$key] = $info;
            }
        }

        if (!@rename($oldAbsolute, $newAbsolute)) {
            return ['error' => 'تغییر نام پوشه ناموفق بود.', 'path' => null, 'name' => null, 'dbUpdated' => 0];
        }

        // همگام‌سازی رکوردهای DB با پیشوند مسیر جدید
        $db = Db::get();
        $dbUpdated = 0;
        $reverted = [];

        foreach (array_keys($affected) as $oldAttachmentKey) {
            $suffix = substr($oldAttachmentKey, strlen($oldKey)); // '/sub/file.png' یا '/file.png'
            $newAttachmentRelative = $newRelative . $suffix;

            if (self::updateAttachmentPath($db, (int) $affected[$oldAttachmentKey]['cid'], $newAttachmentRelative) === false) {
                // خطای DB: تغییر نام فیزیکی را برمی‌گردانیم و رکوردهای
                // به‌روز شده را به مسیر قبلی بازمی‌گردانیم
                @rename($newAbsolute, $oldAbsolute);

                foreach ($reverted as $cid => $oldRelativePath) {
                    self::updateAttachmentPath($db, $cid, $oldRelativePath);
                }

                return [
                    'error' => 'به‌روزرسانی پایگاه‌داده هنگام تغییر نام ناموفق بود؛ عملیات لغو شد.',
                    'path' => null,
                    'name' => null,
                    'dbUpdated' => 0,
                ];
            }

            $reverted[(int) $affected[$oldAttachmentKey]['cid']] = $oldRelative . $suffix; // مسیر نسبی قبلیِ فایل
            $dbUpdated++;
        }

        // کش نقشه‌ی پیوست‌ها دیگر معتبر نیست
        self::$attachmentMap = null;

        return [
            'error' => null,
            'path' => $newRelative,
            'name' => $name,
            'dbUpdated' => $dbUpdated,
        ];
    }

    /**
     * حذف پوشه‌ی خالی (editor+/admin با توکن CSRF از Action)
     *
     * فقط پوشه‌های «خالی» حذف می‌شوند؛ اگر پوشه فایل یا زیرپوشه داشته باشد
     * پیام راهنما برمی‌گردد تا کاربر ابتدا محتوا را منتقل/حذف کند.
     *
     * خروجی: ['error' => null, 'deleted' => true, 'items' => 0]
     */
    public static function deleteFolder(string $path): array
    {
        $relative = self::sanitizeRelative($path);
        if ($relative === null) {
            return ['error' => 'مسیر پوشه نامعتبر است.', 'deleted' => false, 'items' => 0];
        }

        if ($relative === '') {
            return ['error' => 'ریشه‌ی uploads قابل حذف نیست.', 'deleted' => false, 'items' => 0];
        }

        $absolute = self::resolveDirectory($relative);
        if ($absolute === null) {
            return ['error' => 'پوشه مورد نظر در uploads یافت نشد.', 'deleted' => false, 'items' => 0];
        }

        $items = self::countChildren($absolute);
        if ($items > 0) {
            return [
                'error' => 'پوشه «' . basename($relative) . '» خالی نیست (' . $items . ' مورد داخل آن است). '
                    . 'ابتدا فایل‌ها و زیرپوشه‌های آن را منتقل یا حذف کنید، سپس دوباره حذف کنید.',
                'deleted' => false,
                'items' => $items,
            ];
        }

        $parentAbsolute = dirname($absolute);
        if (!is_writable($parentAbsolute)) {
            return ['error' => 'دسترسی نوشتن به پوشه‌ی والد روی سرور ممکن نیست.', 'deleted' => false, 'items' => 0];
        }

        if (!@rmdir($absolute)) {
            return ['error' => 'حذف پوشه ناموفق بود.', 'deleted' => false, 'items' => 0];
        }

        return ['error' => null, 'deleted' => true, 'items' => 0];
    }

    /**
     * درخت کامل پوشه‌های داخل uploads (برای دیالوگ «انتقال به پوشه»)
     *
     * خروجی: گره ریشه با فرم {'name': 'uploads', 'path': '', 'dirs': [...]}
     * هر گره فرزند: {'name', 'path', 'dirs': [...]} — مرتب‌شده با strnatcasecmp.
     * محدودیت: حداکثر عمق ۶ سطح و سقف ۵۰۰ پوشه (پوشه‌های اضافی سقف می‌خورند؛
     * چون همیشه می‌توان از طریق مرور پوشه‌ای به هر عمقی رسید، این سقف فقط
     * برای دیالوگ انتخاب مقصد است).
     */
    public static function folderTree(): array
    {
        $root = self::absoluteRoot();
        if ($root === null) {
            return ['name' => 'uploads', 'path' => '', 'dirs' => []];
        }

        $count = 0;

        $walk = function (string $absolute, string $relative, int $depth) use (&$walk, &$count): array {
            $dirs = [];

            if ($depth >= self::MAX_TREE_DEPTH) {
                return $dirs;
            }

            $entries = @scandir($absolute);
            if ($entries === false) {
                return $dirs;
            }

            foreach ($entries as $entry) {
                if ($entry === '.' || $entry === '..' || str_starts_with($entry, '.')) {
                    continue;
                }

                if ($count >= self::MAX_TREE_FOLDERS) {
                    break;
                }

                $absoluteEntry = $absolute . '/' . $entry;
                if (is_link($absoluteEntry) || !is_dir($absoluteEntry)) {
                    continue;
                }

                $count++;
                $relativeEntry = ($relative === '' ? '' : $relative . '/') . $entry;

                $dirs[] = [
                    'name' => $entry,
                    'path' => $relativeEntry,
                    'dirs' => $walk($absoluteEntry, $relativeEntry, $depth + 1),
                ];
            }

            usort($dirs, static function (array $a, array $b): int {
                return strnatcasecmp($a['name'], $b['name']);
            });

            return $dirs;
        };

        return [
            'name' => 'uploads',
            'path' => '',
            'dirs' => $walk($root, '', 0),
        ];
    }

    /**
     * انتقال فایل‌ها به پوشه‌ی دیگر (editor+/admin با توکن CSRF از Action)
     *
     * ورودی: آرایه‌ی مسیرهای نسبی فایل‌ها + مسیر نسبی پوشه‌ی مقصد ('' یعنی ریشه)
     *
     * امنیت و سازگاری:
     *  - مبدأ و مقصد هر دو با زنجیره‌ی resolve تثبیت می‌شوند (realpath +
     *    containment + رد symlink)؛ نام فایل هرگز از ورودی کاربر ساخته نمی‌شود
     *  - تداخل نام در مقصد رد می‌شود (بازنویسی فایل موجود ممنوع است)
     *  - فایل‌های ثبت‌شده در DB: پس از انتقال موفق فیزیکی، فیلد text رکورد
     *    (JSON با کلید path) به مسیر جدید به‌روزرسانی می‌شود؛ اگر به‌روزرسانی
     *    DB شکست بخورد، انتقال فیزیکی rollback می‌شود تا رکورد یتیم/خراب نشود
     *
     * خروجی: ['error' => null|string, 'moved', 'dbUpdated', 'skipped',
     *          'failed', 'invalid' => names[], 'conflicts' => names[]]
     */
    public static function move(array $paths, string $target): array
    {
        $paths = array_slice($paths, 0, self::MAX_MOVE_PATHS);

        $targetRelative = self::sanitizeRelative($target);
        if ($targetRelative === null) {
            return ['error' => 'مسیر پوشه‌ی مقصد نامعتبر است.'];
        }

        $targetAbsolute = self::resolveDirectory($targetRelative);
        if ($targetAbsolute === null) {
            return ['error' => 'پوشه‌ی مقصد در uploads یافت نشد.'];
        }

        $moved = 0;
        $dbUpdated = 0;
        $skipped = 0;
        $failed = 0;
        $invalid = [];
        $conflicts = [];

        $map = self::attachmentMap();
        $db = Db::get();

        foreach ($paths as $relativePath) {
            if (!is_string($relativePath)) {
                $invalid[] = '(نامعتبر)';
                continue;
            }

            $relativePath = trim($relativePath);
            $sourceRelative = $relativePath === '' ? null : self::sanitizeRelative($relativePath);

            if ($sourceRelative === null || $sourceRelative === '') {
                $invalid[] = basename($relativePath) ?: '(نامعتبر)';
                continue;
            }

            $sourceAbsolute = self::resolveFile($sourceRelative);
            if ($sourceAbsolute === null) {
                $invalid[] = basename($sourceRelative);
                continue;
            }

            $filename = basename($sourceRelative);
            $sourceDirRelative = dirname($sourceRelative);
            $sourceDirRelative = $sourceDirRelative === '.' ? '' : $sourceDirRelative;

            // فایل از قبل در پوشه‌ی مقصد است — کاری نیست
            if ($sourceDirRelative === $targetRelative) {
                $skipped++;
                continue;
            }

            // بازنویسی فایل موجود در مقصد مجاز نیست
            $destination = $targetAbsolute . '/' . $filename;
            if (file_exists($destination) || is_link($destination)) {
                $conflicts[] = $filename;
                continue;
            }

            if (!is_writable($targetAbsolute) || !is_writable(dirname($sourceAbsolute))) {
                $failed++;
                continue;
            }

            if (!@rename($sourceAbsolute, $destination)) {
                $failed++;
                continue;
            }

            // تثبیت پرمیشن استاندارد 644 — فایل‌های قدیمی که با 664 مانده‌اند
            // (باقی‌مانده از نسخه‌های پیشین) با یک انتقال ساده اصلاح می‌شوند.
            @chmod($destination, 0644);

            $moved++;

            // همگام‌سازی رکورد DB پیوست (در صورت وجود) با مسیر جدید
            $attachment = $map[self::attachmentKey($sourceRelative)] ?? null;
            if ($attachment !== null) {
                $newRelative = $targetRelative === '' ? $filename : $targetRelative . '/' . $filename;

                $updateResult = self::updateAttachmentPath($db, (int) $attachment['cid'], $newRelative);

                if ($updateResult === false) {
                    // خطای DB: انتقال فیزیکی را برمی‌گردانیم تا رکورد سالم بماند
                    @rename($destination, $sourceAbsolute);
                    $moved--;
                    $failed++;
                    continue;
                }

                if ($updateResult === true) {
                    $dbUpdated++;
                }
            }
        }

        return [
            'error' => null,
            'moved' => $moved,
            'dbUpdated' => $dbUpdated,
            'skipped' => $skipped,
            'failed' => $failed,
            'invalid' => $invalid,
            'conflicts' => $conflicts,
        ];
    }

    /**
     * به‌روزرسانی مسیر ذخیره‌شده در رکورد پیوست (JSON فیلد text)
     *
     * خروجی: true = به‌روزرسانی شد | false = خطا | null = رکوردی وجود نداشت
     */
    private static function updateAttachmentPath(Db $db, int $cid, string $newRelative): ?bool
    {
        try {
            $row = $db->fetchRow(
                $db->select('text')
                    ->from('table.contents')
                    ->where('table.contents.cid = ?', $cid)
                    ->where('table.contents.type = ?', 'attachment')
                    ->limit(1)
            );

            if (empty($row['text'])) {
                return null;
            }

            $content = json_decode((string) $row['text'], true);
            if (!is_array($content)) {
                return null;
            }

            $content['path'] = self::attachmentKey($newRelative);

            $db->query(
                $db->update('table.contents')
                    ->rows(['text' => Common::jsonEncode($content, JSON_UNESCAPED_UNICODE, '{}')])
                    ->where('cid = ?', $cid)
            );

            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * نقشه‌ی پیوست‌های ثبت‌شده در DB بر اساس مسیر فایل
     *
     * خروجی: ['/usr/uploads/2026/09/x.png' => ['cid' => 5, 'title' => 'name'], ...]
     */
    public static function attachmentMap(): array
    {
        if (is_array(self::$attachmentMap)) {
            return self::$attachmentMap;
        }

        $map = [];
        try {
            $db = Db::get();
            $rows = $db->fetchAll(
                $db->select('cid', 'title', 'text')
                    ->from('table.contents')
                    ->where('table.contents.type = ?', 'attachment')
                    ->limit(self::MAX_ATTACHMENT_ROWS)
            );

            foreach ($rows as $row) {
                $content = json_decode((string) $row['text'], true);
                if (!is_array($content) || empty($content['path'])) {
                    continue;
                }

                $path = str_replace('\\', '/', trim((string) $content['path']));
                if ($path === '' || str_contains($path, '..') || str_contains($path, "\0")) {
                    continue;
                }

                $map['/' . trim($path, '/')] = [
                    'cid' => (int) $row['cid'],
                    'title' => (string) $row['title'],
                ];
            }
        } catch (\Throwable $e) {
            $map = [];
        }

        self::$attachmentMap = $map;
        return $map;
    }

    /**
     * کلید نقشه‌ی DB برای یک مسیر نسبی
     */
    public static function attachmentKey(string $relativePath): string
    {
        return rtrim(self::uploadDirSetting(), '/') . '/' . ltrim($relativePath, '/');
    }

    /**
     * فهرست‌بندی محتوای یک پوشه
     *
     * خروجی:
     *  - error: null|string (در صورت خطا پیام فارسی)
     *  - path, parentPath, breadcrumbs
     *  - folders: [{name, files, dirs}]
     *  - files: [{name, url, isImage, type, size, bytes, mtime, cid, title}] (صفحه‌ی جاری)
     *  - totalFiles, totalFolders, page, pageSize
     *
     * پارامتر kind (اختیاری): فیلتر نوع فایل (image|video|audio|archive|doc)
     * — قبل از صفحه‌بندی روی پسوند فایل اعمال می‌شود؛ پوشه‌ها فیلتر نمی‌شوند.
     */
    public static function list(string $relativePath, string $keywords, int $page, int $pageSize, string $kind = ''): array
    {
        $relativePath = self::sanitizeRelative($relativePath);
        if ($relativePath === null) {
            return ['error' => 'مسیر پوشه نامعتبر است.'];
        }

        $kind = Icons::validFilter($kind);

        $absolute = self::resolveDirectory($relativePath);
        if ($absolute === null) {
            return ['error' => 'پوشه مورد نظر در پوشه‌ی uploads یافت نشد.'];
        }

        $page = max(1, $page);
        $pageSize = max(12, min(96, $pageSize));

        // جستجو: حداکثر ۵ واژه، LIKE-safe (کاراکتر % و _ مهم نیست چون مقایسه PHP انجام می‌شود)
        $keywordList = [];
        if ($keywords !== '') {
            $keywordList = preg_split('/\s+/', trim($keywords)) ?: [];
            $keywordList = array_values(array_filter(array_slice($keywordList, 0, 5), static function ($word) {
                return is_string($word) && $word !== '';
            }));
        }

        $entries = @scandir($absolute);
        if ($entries === false) {
            return ['error' => 'خواندن محتوای این پوشه ممکن نشد.'];
        }

        $map = self::attachmentMap();

        $folders = [];
        $files = [];

        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..' || str_starts_with($entry, '.')) {
                continue;
            }

            $absoluteEntry = $absolute . '/' . $entry;

            if (is_link($absoluteEntry)) {
                continue; // symlinkها به‌کلی نادیده گرفته می‌شوند
            }

            if (is_dir($absoluteEntry)) {
                if (!$keywordList || self::matchesKeywords($entry, $keywordList)) {
                    $folders[] = [
                        'name' => $entry,
                        'files' => self::countChildren($absoluteEntry),
                    ];
                }
                continue;
            }

            if (!is_file($absoluteEntry) || !is_readable($absoluteEntry)) {
                continue;
            }

            $relativeEntry = ($relativePath === '' ? '' : $relativePath . '/') . $entry;
            $attachment = $map[self::attachmentKey($relativeEntry)] ?? null;

            // جستجو بر اساس «نام روی دیسک» یا «نام اصلی فایل»:
            // هسته پس از آپلود نام فایل را تغییر می‌دهد (file.zip → 145963.zip)
            // اما عنوان رکورد پیوست همان نام اصلی قبل از آپلود است؛ پس هر دو
            // نام جستجو می‌شوند تا کاربر بتواند فایل را با نامی که موقع آپلود
            // داشته پیدا کند (تطبیق جزئی و حساس به بزرگی/کوچکی نیست — شامل فارسی).
            if ($keywordList && !self::matchesKeywords($entry, $keywordList)) {
                $title = isset($attachment['title']) && is_string($attachment['title'])
                    ? $attachment['title']
                    : '';

                if ($title === '' || !self::matchesKeywords($title, $keywordList)) {
                    continue;
                }
            }
            $type = self::extensionOf($entry);

            // فیلتر نوع فایل — قبل از شمارش/صفحه‌بندی اعمال می‌شود
            if ($kind !== '' && !Icons::filterMatches($kind, $type)) {
                continue;
            }

            $files[] = [
                'name' => $entry,
                'path' => $relativeEntry,
                'url' => self::fileUrl($relativeEntry),
                'isImage' => in_array($type, self::IMAGE_TYPES, true),
                'type' => $type,
                'size' => (int) @filesize($absoluteEntry),
                'mtime' => (int) @filemtime($absoluteEntry),
                'cid' => $attachment['cid'] ?? 0,
                'title' => $attachment['title'] ?? $entry,
            ];
        }

        // مرتب‌سازی: پوشه‌ها بر اساس نام؛ فایل‌ها جدیدترین اول
        usort($folders, static function (array $a, array $b): int {
            return strnatcasecmp($a['name'], $b['name']);
        });
        usort($files, static function (array $a, array $b): int {
            return $b['mtime'] <=> $a['mtime'];
        });

        $totalFiles = count($files);
        $offset = ($page - 1) * $pageSize;
        $files = array_slice($files, $offset, $pageSize);
        foreach ($files as &$file) {
            $file['bytes'] = Text::bytes($file['size']);
        }
        unset($file);

        $folders = array_slice($folders, 0, self::MAX_FOLDERS);

        // مسیر راهنما (breadcrumb)
        $breadcrumbs = [['name' => 'uploads', 'path' => '']];
        if ($relativePath !== '') {
            $acc = '';
            foreach (explode('/', $relativePath) as $segment) {
                $acc = $acc === '' ? $segment : $acc . '/' . $segment;
                $breadcrumbs[] = ['name' => $segment, 'path' => $acc];
            }
        }

        return [
            'error' => null,
            'path' => $relativePath,
            'parentPath' => $relativePath === '' ? null : (dirname($relativePath) === '.' ? '' : dirname($relativePath)),
            'breadcrumbs' => $breadcrumbs,
            'folders' => $folders,
            'files' => $files,
            'totalFiles' => $totalFiles,
            'totalFolders' => count($folders),
            'page' => $page,
            'pageSize' => $pageSize,
            'keywords' => $keywords,
        ];
    }

    /**
     * آیا این فایل در DB به‌عنوان پیوست ثبت شده؟ (برای حذف ایمن)
     */
    public static function findAttachment(string $relativePath): ?array
    {
        $map = self::attachmentMap();
        return $map[self::attachmentKey($relativePath)] ?? null;
    }

    /**
     * رکورد کامل پیوستِ یک فایل — برای متادیتای سطل زباله
     *
     * خروجی همان ساختاری است که Trash::moveToTrash برای بازسازی رکورد
     * هنگام ریستور انتظار دارد: [cid, title, text(JSON خام), authorId, parent]
     * یا null اگر فایل در کتابخانه ثبت نشده باشد.
     */
    public static function attachmentRecord(string $relativePath): ?array
    {
        $attachment = self::findAttachment($relativePath);
        if ($attachment === null) {
            return null;
        }

        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('cid', 'title', 'text', 'authorId', 'parent')
                    ->from('table.contents')
                    ->where('table.contents.cid = ?', (int) $attachment['cid'])
                    ->where('table.contents.type = ?', 'attachment')
                    ->limit(1)
            );

            if (empty($row)) {
                return null;
            }

            return [
                'cid' => (int) $row['cid'],
                'title' => (string) $row['title'],
                'text' => (string) $row['text'],
                'authorId' => (int) $row['authorId'],
                'parent' => (int) $row['parent'],
            ];
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * تغییر نام فیزیکی یک فایل داخل همان پوشه (editor+/admin با توکن CSRF از Action)
     *
     * ورودی: path (مسیر نسبی فایل) + name (نام جدید — پسوند همیشه از فایل
     * فعلی حفظ می‌شود؛ اگر کاربر پسوندی هم تایپ کرده باشد نادیده گرفته می‌شود)
     *
     * امنیت و سازگاری:
     *  - مبدأ با resolveFile تثبیت می‌شود (realpath + containment + رد symlink)
     *  - نام پایه با sanitizeFolderName اعتبارسنجی می‌شود (تک‌قطعه‌ای، بدون مسیر)
     *  - rename فقط داخل همان والد؛ تداخل نام رد می‌شود
     *  - رکورد DB پیوست (در صورت وجود) با updateAttachmentPath همگام می‌شود
     *    و عنوان رکورد هم به نام جدید تغییر می‌کند (با rollback در صورت خطای DB)
     *
     * خروجی: ['error' => null|string, 'path' => مسیر جدید, 'name' => نام جدید,
     *          'dbUpdated' => 0|1, 'registered' => bool]
     */
    public static function renameFile(string $path, string $newName): array
    {
        $oldRelative = self::sanitizeRelative($path);
        if ($oldRelative === null || $oldRelative === '') {
            return ['error' => 'مسیر فایل نامعتبر است.', 'path' => null, 'name' => null, 'dbUpdated' => 0, 'registered' => false];
        }

        $oldAbsolute = self::resolveFile($oldRelative);
        if ($oldAbsolute === null) {
            return ['error' => 'فایل مورد نظر در uploads یافت نشد.', 'path' => null, 'name' => null, 'dbUpdated' => 0, 'registered' => false];
        }

        $oldName = basename($oldRelative);
        $extension = self::extensionOf($oldName);

        // پسوند تایپ‌شده در نام جدید حذف می‌شود — پسوند واقعی فایل حفظ می‌شود
        $base = trim((string) $newName);
        $base = preg_replace('/\.[a-z0-9]{1,12}$/i', '', $base) ?? '';
        $base = self::sanitizeFolderName($base);
        if ($base === null) {
            return [
                'error' => 'نام فایل معتبر نیست (حداکثر ۹۶ کاراکتر؛ فقط حروف، اعداد، فاصله، نقطه، خط تیره و زیرخط؛ نام نباید با نقطه شروع شود).',
                'path' => null,
                'name' => null,
                'dbUpdated' => 0,
                'registered' => false,
            ];
        }

        $newName = $extension !== '' ? ($base . '.' . $extension) : $base;
        if ($newName === $oldName) {
            return ['error' => null, 'path' => $oldRelative, 'name' => $oldName, 'dbUpdated' => 0, 'registered' => self::findAttachment($oldRelative) !== null];
        }

        $parentRelative = dirname($oldRelative);
        $parentRelative = $parentRelative === '.' ? '' : $parentRelative;

        $newRelative = ($parentRelative === '' ? '' : $parentRelative . '/') . $newName;
        $newAbsolute = dirname($oldAbsolute) . '/' . $newName;

        if (file_exists($newAbsolute) || is_link($newAbsolute)) {
            return [
                'error' => 'پوشه یا فایلی با همین نام از قبل در این مسیر وجود دارد.',
                'path' => null,
                'name' => null,
                'dbUpdated' => 0,
                'registered' => false,
            ];
        }

        if (!is_writable(dirname($oldAbsolute))) {
            return ['error' => 'دسترسی نوشتن به این پوشه روی سرور ممکن نیست.', 'path' => null, 'name' => null, 'dbUpdated' => 0, 'registered' => false];
        }

        $attachment = self::findAttachment($oldRelative);
        $registered = $attachment !== null;

        if (!@rename($oldAbsolute, $newAbsolute)) {
            return ['error' => 'تغییر نام فایل ناموفق بود.', 'path' => null, 'name' => null, 'dbUpdated' => 0, 'registered' => $registered];
        }

        // تثبیت پرمیشن استاندارد 644 — تغییر نام، راه ساده‌ی اصلاح فایل‌های
        // قدیمی 664 (باقی‌مانده از نسخه‌های پیشین) هم هست.
        @chmod($newAbsolute, 0644);

        $dbUpdated = 0;

        if ($registered) {
            $db = Db::get();
            $cid = (int) $attachment['cid'];

            // همگام‌سازی مسیر JSON + عنوان رکورد با نام جدید
            if (self::updateAttachmentPath($db, $cid, $newRelative) === false) {
                @rename($newAbsolute, $oldAbsolute);
                return [
                    'error' => 'به‌روزرسانی پایگاه‌داده هنگام تغییر نام ناموفق بود؛ عملیات لغو شد.',
                    'path' => null,
                    'name' => null,
                    'dbUpdated' => 0,
                    'registered' => true,
                ];
            }

            try {
                $db->query(
                    $db->update('table.contents')
                        ->rows(['title' => $newName])
                        ->where('cid = ?', $cid)
                );

                $row = $db->fetchRow(
                    $db->select('text')
                        ->from('table.contents')
                        ->where('cid = ?', $cid)
                        ->limit(1)
                );

                if (!empty($row['text'])) {
                    $content = json_decode((string) $row['text'], true);
                    if (is_array($content)) {
                        if (isset($content['name'])) {
                            $content['name'] = $newName;
                        }

                        $db->query(
                            $db->update('table.contents')
                                ->rows(['text' => Common::jsonEncode($content, JSON_UNESCAPED_UNICODE, '{}')])
                                ->where('cid = ?', $cid)
                        );
                    }
                }
            } catch (\Throwable $e) {
                // عنوان/JSON به‌روز نشد اما مسیر قبلاً همگام شده — قابل قبول است
            }

            $dbUpdated = 1;
            self::$attachmentMap = null;
        }

        return [
            'error' => null,
            'path' => $newRelative,
            'name' => $newName,
            'dbUpdated' => $dbUpdated,
            'registered' => $registered,
        ];
    }

    /**
     * پسوند کوچک‌شده‌ی نام فایل
     */
    public static function extensionOf(string $filename): string
    {
        $pos = strrpos($filename, '.');
        if ($pos === false || $pos === 0 || $pos === strlen($filename) - 1) {
            return '';
        }

        return strtolower(substr($filename, $pos + 1));
    }

    /**
     * تعداد فرزندان مستقیم یک پوشه (فایل + پوشه، بدون مخفی‌ها و symlink)
     */
    private static function countChildren(string $absoluteDir): int
    {
        $entries = @scandir($absoluteDir);
        if ($entries === false) {
            return 0;
        }

        $count = 0;
        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..' || str_starts_with($entry, '.')) {
                continue;
            }

            if (is_link($absoluteDir . '/' . $entry)) {
                continue;
            }

            $count++;
        }

        return $count;
    }

    /**
     * تطبیق نام با واژه‌های جستجو (AND واژه‌ها، حساس به بزرگی/کوچکی نیست)
     */
    private static function matchesKeywords(string $name, array $keywordList): bool
    {
        $haystack = mb_strtolower($name, 'UTF-8');
        foreach ($keywordList as $word) {
            if (!str_contains($haystack, mb_strtolower((string) $word, 'UTF-8'))) {
                return false;
            }
        }

        return true;
    }
}
