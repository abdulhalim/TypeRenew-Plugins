(function () {
    'use strict';

    if (window.mmConfirm) {
        return;
    }

    /** آیکون‌های Lucide مورد نیاز مودال (فقط رشته‌های ثابت؛ داده‌ی کاربر هرگز وارد نمی‌شود) */
    var ICONS = {
        'trash-2': '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/>',
        'alert-triangle': '<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" x2="12" y1="9" y2="13"/><line x1="12" x2="12.01" y1="17" y2="17"/>',
        'rotate-ccw': '<path d="M1 4v6h6"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/>',
        'info': '<circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="16" y2="12"/><line x1="12" x2="12.01" y1="8" y2="8"/>'
    };

    var STYLE = [
        '.mm-cfm{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;direction:rtl;font-family:inherit}',
        '.mm-cfm-mask{position:absolute;inset:0;background:rgba(15,23,42,.58);backdrop-filter:blur(2px)}',
        '.mm-cfm-box{position:relative;width:100%;max-width:400px;background:#fff;border-radius:14px;box-shadow:0 18px 50px rgba(2,6,23,.28);padding:22px 22px 18px;animation:mmCfmPop .16s ease-out}',
        '@keyframes mmCfmPop{from{opacity:0;transform:translateY(10px) scale(.97)}to{opacity:1;transform:none}}',
        '.mm-cfm-icon{width:50px;height:50px;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 14px;background:#eff6ff;color:#2563eb}',
        '.mm-cfm-danger .mm-cfm-icon{background:#fee2e2;color:#dc2626}',
        '.mm-cfm-icon svg{width:26px;height:26px;display:block}',
        '.mm-cfm-title{margin:0 0 8px;text-align:center;font-size:15px;font-weight:700;color:#0f172a}',
        '.mm-cfm-msg{margin:0 0 18px;text-align:center;font-size:13px;line-height:2;color:#475569;white-space:pre-line}',
        '.mm-cfm-row{display:flex;gap:10px;justify-content:center}',
        '.mm-cfm-btn{flex:1;min-height:38px;border-radius:9px;border:1px solid #cbd5e1;background:#fff;color:#334155;font-size:13px;font-weight:600;cursor:pointer;padding:0 14px;font-family:inherit}',
        '.mm-cfm-btn:hover{background:#f8fafc}',
        '.mm-cfm-btn:focus-visible{outline:2px solid #94a3b8;outline-offset:2px}',
        '.mm-cfm-yes{border-color:#2563eb;background:#2563eb;color:#fff}',
        '.mm-cfm-yes:hover{background:#1d4ed8}',
        '.mm-cfm-danger .mm-cfm-yes{border-color:#dc2626;background:#dc2626;color:#fff}',
        '.mm-cfm-danger .mm-cfm-yes:hover{background:#b91c1c}',
        // حالت شب پوسته — همان متغیرهای رنگی تیره‌ی renew-ui
        // (html.tr-theme-dark)؛ مودال دیگر در شب سفید نمی‌ماند.
        'html.tr-theme-dark .mm-cfm-mask{background:rgba(2,6,23,.66)}',
        'html.tr-theme-dark .mm-cfm-box{background:rgba(18,21,28,.98);box-shadow:0 18px 50px rgba(0,0,0,.55);border:1px solid rgba(148,163,184,.14)}',
        'html.tr-theme-dark .mm-cfm-title{color:rgba(241,245,249,.94)}',
        'html.tr-theme-dark .mm-cfm-msg{color:rgba(226,232,240,.82)}',
        'html.tr-theme-dark .mm-cfm-btn{background:rgba(148,163,184,.08);border-color:rgba(148,163,184,.22);color:rgba(226,232,240,.9)}',
        'html.tr-theme-dark .mm-cfm-btn:hover{background:rgba(148,163,184,.16)}',
        'html.tr-theme-dark .mm-cfm-btn:focus-visible{outline-color:rgba(148,163,184,.55)}',
        'html.tr-theme-dark .mm-cfm-icon{background:rgba(96,165,250,.14);color:#60a5fa}',
        'html.tr-theme-dark .mm-cfm-danger .mm-cfm-icon{background:rgba(248,113,113,.14);color:#f87171}'
    ].join('');

    function ensureStyle() {
        if (document.getElementById('mm-cfm-style')) {
            return;
        }
        var style = document.createElement('style');
        style.id = 'mm-cfm-style';
        style.textContent = STYLE;
        document.head.appendChild(style);
    }

    function iconSvg(name) {
        var inner = ICONS[name] || ICONS['info'];
        return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"'
            + ' stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
            + inner + '</svg>';
    }

    /** هم‌زمان فقط یک مودال — درخواست دوم بی‌درنگ رد می‌شود */
    var active = false;

    /**
     * مودال یکدست پیام‌های حساس — خروجی: Promise<boolean>
     * true = تأیید کاربر، false = انصراف (Esc / کلیک پس‌زمینه / دکمه‌ی انصراف)
     */
    window.mmConfirm = function (opts) {
        opts = opts || {};

        if (active) {
            return Promise.resolve(false);
        }

        ensureStyle();
        active = true;

        return new Promise(function (resolve) {
            var closed = false;

            var done = function (result) {
                if (closed) {
                    return;
                }
                closed = true;
                active = false;
                document.removeEventListener('keydown', onKey, true);
                wrap.remove();
                resolve(result);
            };

            var onKey = function (e) {
                if (e.key === 'Escape') {
                    e.preventDefault();
                    e.stopPropagation();
                    done(false);
                } else if (e.key === 'Enter') {
                    e.preventDefault();
                    e.stopPropagation();
                    done(true);
                }
            };

            var wrap = document.createElement('div');
            wrap.className = 'mm-cfm' + (opts.danger ? ' mm-cfm-danger' : '');
            wrap.setAttribute('dir', 'rtl');
            wrap.setAttribute('role', 'dialog');
            wrap.setAttribute('aria-modal', 'true');
            wrap.setAttribute('aria-labelledby', 'mm-cfm-title');

            var mask = document.createElement('div');
            mask.className = 'mm-cfm-mask';
            mask.addEventListener('click', function () {
                done(false);
            });

            var box = document.createElement('div');
            box.className = 'mm-cfm-box';

            var icon = document.createElement('div');
            icon.className = 'mm-cfm-icon';
            icon.innerHTML = iconSvg(opts.icon); // نقشه‌ی ثابت داخلی؛ داده کاربر وارد نمی‌شود

            var title = document.createElement('h3');
            title.className = 'mm-cfm-title';
            title.id = 'mm-cfm-title';
            title.textContent = String(opts.title || '');

            var message = document.createElement('p');
            message.className = 'mm-cfm-msg';
            message.textContent = String(opts.message || '');

            var row = document.createElement('div');
            row.className = 'mm-cfm-row';

            var cancelBtn = document.createElement('button');
            cancelBtn.type = 'button';
            cancelBtn.className = 'mm-cfm-btn';
            cancelBtn.textContent = String(opts.cancelText || 'انصراف');
            cancelBtn.addEventListener('click', function () {
                done(false);
            });

            var yesBtn = document.createElement('button');
            yesBtn.type = 'button';
            yesBtn.className = 'mm-cfm-btn mm-cfm-yes';
            yesBtn.textContent = String(opts.confirmText || 'تایید');
            yesBtn.addEventListener('click', function () {
                done(true);
            });

            row.appendChild(cancelBtn);
            row.appendChild(yesBtn);

            box.appendChild(icon);
            box.appendChild(title);
            box.appendChild(message);
            box.appendChild(row);

            wrap.appendChild(mask);
            wrap.appendChild(box);
            document.body.appendChild(wrap);

            document.addEventListener('keydown', onKey, true);

            // در عملیات مخاطره‌آمیز، فوکوس روی انصراف است تا تأییدِ اشتباهی
            // با Enter انجام نشود؛ در بقیه‌ی حالت‌ها تأیید فوکوس دارد.
            (opts.danger ? cancelBtn : yesBtn).focus();
        });
    };
})();
