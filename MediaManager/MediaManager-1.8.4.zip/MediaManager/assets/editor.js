(function ($) {
    'use strict';

    var cfg = window.MM_EDITOR;
    if (!cfg) {
        return;
    }

    var strings = cfg.strings || {};
    var ICONS = cfg.icons || {};
    var FA_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    var $textarea = $('#text');

    /*
     * قالب اعداد: همیشه فارسی — همه‌ی اعداد سمت کلاینت (شمارنده‌های
     * پیش‌نمایش، وضعیت انتخابگر و …) با ارقام فارسی نمایش داده می‌شوند؛
     * سمت سرور (Panel.php / TrashPage.php) همان تبدیل را انجام می‌دهد.
     */
    function faNum(num) {
        return String(num).replace(/\d/g, function (d) {
            return FA_DIGITS[+d];
        });
    }

    /* ---------- نشست ویرایشگر (sessionStorage) ---------- */

    /*
     * کلیدهای نشست:
     *  - mm-picker-folder: آخرین پوشه‌ی مرورشده‌ی انتخابگر؛
     *  - mm-landed-folder + mm-landed-stamp: پوشه‌ی فرود آخرین آپلود موفق
     *    و مهر زمانی آن (معتبر تا ۱۰ دقیقه)؛
     *  - mm-fresh-root: نشانگر «نشست تازه» — کتابخانه از ریشه شروع شود؛
     *  - mm-continue-nav: پرچم تک‌مصرفِ «ارسال فرم» — ادامه‌ی نشست پس از ذخیره؛
     *  - mm-await-landed: مهر زمانی «چسباندن فایل» در همین صفحه — فعال‌کننده‌ی
     *    خواندن کوکی راهنمای سرور (mm_landed_folder از هوک upload).
     */
    var FOLDER_STORE_KEY = 'mm-picker-folder';
    var LANDED_STORE_KEY = 'mm-landed-folder';
    var LANDED_STAMP_KEY = 'mm-landed-stamp';
    var FRESH_ROOT_KEY = 'mm-fresh-root';
    var CONTINUE_KEY = 'mm-continue-nav';
    var AWAIT_LANDED_KEY = 'mm-await-landed';
    var LANDED_COOKIE_NAME = 'mm_landed_folder';

    /*
     * عمر پوشه‌ی فرود: فرودِ آپلود فقط تا ۱۰ دقیقه معتبر است؛
     * پس از آن انتخابگر/کتابخانه از ریشه شروع می‌کنند تا نشست‌های قدیمی
     * برای همیشه در پوشه‌ی فرودِ کهنه گیر نکنند.
     */
    var LANDED_TTL_MS = 10 * 60 * 1000;

    function readSessionValue(key) {
        try {
            return String(window.sessionStorage.getItem(key) || '').trim();
        } catch (e) {
            return '';
        }
    }

    function writeSessionValue(key, value) {
        try {
            window.sessionStorage.setItem(key, String(value || ''));
        } catch (e) {
            /* حافظه‌ی نشست در دسترس نیست؛ فقط همین دیالوگ معتبر است */
        }
    }

    function removeSessionValue(key) {
        try {
            window.sessionStorage.removeItem(key);
        } catch (e) {
            /* بی‌خطر */
        }
    }

    /** نوع ناوبری فعلی صفحه: reload | back_forward | navigate (یا '') */
    function navigationKind() {
        try {
            var perf = window.performance;
            if (perf && typeof perf.getEntriesByType === 'function') {
                var entries = perf.getEntriesByType('navigation');
                if (entries && entries.length && entries[0].type) {
                    return String(entries[0].type);
                }
            }
            if (perf && perf.navigation) {
                if (perf.navigation.type === 1) {
                    return 'reload';
                }
                if (perf.navigation.type === 2) {
                    return 'back_forward';
                }
            }
        } catch (e) {
            /* بی‌خطر */
        }
        return '';
    }

    /*
     * پرچم «ادامه‌ی نشست»: پیش از ارسال هر فرمِ واقعاً ناوبر (مثل ذخیره‌ی
     * نوشته) ثبت می‌شود تا بارگذاری بعدی — که نوعش navigate است — بداند
     * ادامه‌ی همین نشست است. فرم‌های داخل‌صفحه‌ای افزونه (preventDefault)
     * پرچم را بی‌درنگ برمی‌گردانند تا اثر نگذارد.
     */
    document.addEventListener('submit', function (e) {
        writeSessionValue(CONTINUE_KEY, '1');
        setTimeout(function () {
            if (e.defaultPrevented) {
                removeSessionValue(CONTINUE_KEY); // فرم داخل‌صفحه‌ای بود
            }
        }, 0);
    }, true);

    /**
     * آیا این بارگذاری صفحه، «نشست تازه‌ی» ویرایشگر است؟ (قطعی)
     *
     * ادامه‌ی نشست فقط در این سه حالت است:
     *   ۱) نوسازی صفحه (F5) — نوع ناوبری reload؛
     *   ۲) بازگشت/پیشروی تاریخچه‌ی مرورگر — نوع back_forward (بازیابی
     *      فوری تب و bfcache هم همین‌جاها می‌افتد)؛
     *   ۳) ارسال فرم از همین صفحه (ذخیره‌ی نوشته) — پرچم mm-continue-nav
     *      که هنگام ارسال ثبت و اینجا مصرف می‌شود.
     * هر ورود دیگر (کلیک منو، فهرست نوشته‌ها، ویرایش پست دیگر، …) نشست
     * تازه است و مسیر رسانه به ریشه‌ی uploads بازنشانی می‌شود — خواسته‌ی
     * «بعد از بستن ادیتور، شروع از ریشه». هیچ حدسِ زمانی (پنجره‌ی
     * ۱۵ ثانیه) در کار نیست؛ ورود سریع از فهرست نوشته‌ها هم
     * نشست تازه محسوب می‌شود.
     */
    function isFreshEditorSession() {
        var kind = navigationKind();
        if (kind === 'reload' || kind === 'back_forward') {
            return false;
        }

        if (readSessionValue(CONTINUE_KEY) === '1') {
            removeSessionValue(CONTINUE_KEY); // مصرف تک‌بار
            return false;
        }

        return true;
    }

    /* ---------- پوشه‌ی فرود آپلودهای بیرون از مدیامنجر ---------- */

    /*
     * آپلودهایی که از خود انتخابگر/پنل مدیامنجر انجام نمی‌شوند (مثل
     * چسباندن فایل در خود ویرایشگر یا ادیتور جانشین و تب پیوست‌های
     * هسته) هم باید مسیر شروع کتابخانه را به پوشه‌ی واقعی فایل تازه
     * ببرند. سه کانال تشخیص:
     *   ۱) فهرست پیوست‌های هسته (#file-list) — آیتم تازه با data-url؛
     *   ۲) متن نوشته — نشانی uploads/ که از لحظه‌ی بارگذاری صفحه تازه است؛
     *   ۳) پرچم «چسباندن فایل» (mm-await-landed) + کوکی راهنمای سرور
     *      (mm_landed_folder) که هوک upload مدیامنجر برای «هر» آپلود
     *      موفق می‌نویسد — حتی اگر نشانی هیچ‌جا در DOM دیده نشود.
     * کانال‌های ۱ و ۲ با مقایسه با عکس‌الگوی نشانی‌های لحظه‌ی بارگذاری
     * صفحه تشخیص داده می‌شوند؛ کانال ۳ فقط وقتی خوانده می‌شود که در همین
     * صفحه فایلی چسبانده شده باشد تا رفتار «نشست تازه از ریشه» حفظ شود.
     */
    var knownUploadUrls = null;
    var uploadUrlPattern = null;

    /** نشانگر مسیر uploads در نشانی‌ها (مثل /usr/uploads/) */
    function uploadMarker() {
        return String(cfg.uploadDir || '/usr/uploads').replace(/\/+$/, '') + '/';
    }

    /** بخش نسبی نشانی بعد از ریشه‌ی uploads — برای مقایسه‌ی یکتایی */
    function relativeOfUrl(url) {
        var marker = uploadMarker();
        var raw = String(url || '');
        var pos = raw.indexOf(marker);
        if (pos === -1) {
            return null;
        }

        var rest = raw.slice(pos + marker.length);
        return rest === '' ? null : rest;
    }

    /** پوشه‌ی یک نشانی نسبی (بدون نام فایل)؛ '' یعنی ریشه‌ی uploads */
    function folderOfRelative(rel) {
        var cut = String(rel).lastIndexOf('/');
        if (cut === -1) {
            return '';
        }

        var folder = String(rel).slice(0, cut);
        try {
            // نام پوشه‌های فارسی در URL درصدگذاری می‌شوند؛ قطعه‌قطعه بازگشایی می‌کنیم
            folder = folder.split('/').map(function (part) {
                return decodeURIComponent(part);
            }).join('/');
        } catch (e) {
            /* مقدار خام نگه داشته می‌شود */
        }

        return folder;
    }

    /**
     * پوشه‌ی فرود فایل از نشانی برگشتی هسته (مثل پنل)
     * خروجی null یعنی نشانی قابل تحلیل نبود.
     */
    function folderOfUrl(url) {
        var rel = relativeOfUrl(url);
        return rel === null ? null : folderOfRelative(rel);
    }

    /** الگوی استخراج نشانی‌های uploads از متن (مارک‌داون/HTML/متن خام) */
    function uploadUrlRegex() {
        if (uploadUrlPattern === null) {
            var marker = uploadMarker().replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            uploadUrlPattern = new RegExp('[^\\s"\'`<>\\)\\]]*' + marker + '[^\\s"\'`<>\\)\\]]*', 'g');
        }
        return uploadUrlPattern;
    }

    /** همه‌ی نشانی‌های uploads داخل متن فعلی نوشته به callback داده می‌شوند */
    function textUploadUrls(callback) {
        if (!$textarea.length) {
            return;
        }

        var re = uploadUrlRegex();
        re.lastIndex = 0;
        var match;
        while ((match = re.exec(String($textarea.val() || ''))) !== null) {
            callback(match[0]);
        }
    }

    /** عکس‌الگوی نشانی‌های شناخته‌شده در لحظه‌ی بارگذاری صفحه */
    function collectKnownUploadUrls() {
        var known = {};

        $('#file-list li[data-url]').each(function () {
            var rel = relativeOfUrl(String($(this).attr('data-url') || ''));
            if (rel !== null) {
                known[rel] = true;
            }
        });

        textUploadUrls(function (url) {
            var rel = relativeOfUrl(url);
            if (rel !== null) {
                known[rel] = true;
            }
        });

        return known;
    }

    /**
     * پوشه‌ی فرود «تازه‌ترین نشانی تازه» — نشانی‌ای که از لحظه‌ی
     * بارگذاری صفحه اضافه شده (آپلود/درج بیرون از انتخابگر؛ مثل
     * چسباندن فایل در خود ویرایشگر). '' یعنی چیزی تازه نیست.
     */
    function scanFreshUploadFolder() {
        if (!knownUploadUrls) {
            return '';
        }

        var latest = '';

        var consider = function (url) {
            var rel = relativeOfUrl(url);
            if (rel === null || knownUploadUrls[rel]) {
                return;
            }

            var folder = folderOfRelative(rel);
            if (folder !== '') {
                latest = folder; // آخری برنده می‌شود (تازه‌ترین درج)
            }
        };

        $('#file-list li[data-url]').each(function () {
            consider(String($(this).attr('data-url') || ''));
        });

        textUploadUrls(consider);

        return latest;
    }

    /** اعتبار صوری مسیر نسبی (آینه‌ی قواعد sanitizeRelative سمت سرور) */
    function validRelativeFolder(folder) {
        folder = String(folder || '').trim().replace(/^\/+|\/+$/g, '');
        if (folder === '' || folder.length > 512) {
            return false;
        }
        if (/[\x00-\x1F\x7F]/.test(folder) || folder.indexOf('\\') !== -1) {
            return false;
        }

        var parts = folder.split('/');
        for (var i = 0; i < parts.length; i++) {
            var part = parts[i];
            if (part === '' || part === '.' || part === '..' || part.charAt(0) === '.') {
                return false;
            }
        }

        return true;
    }

    /** کوکی راهنمای پوشه‌ی فرود که هوک upload سرور نوشته است */
    function readLandedCookie() {
        var parts = String(document.cookie || '').split(';');
        for (var i = 0; i < parts.length; i++) {
            var pair = parts[i].trim();
            var eq = pair.indexOf('=');
            if (eq === -1 || pair.slice(0, eq) !== LANDED_COOKIE_NAME) {
                continue;
            }

            var raw = pair.slice(eq + 1);
            try {
                raw = decodeURIComponent(raw);
            } catch (e) {
                return '';
            }

            raw = String(raw || '').trim().replace(/^\/+|\/+$/g, '');
            return validRelativeFolder(raw) ? raw : '';
        }

        return '';
    }

    /** آیا در همین نشست صفحه فایلی چسبانده شده و هنوز فرودش پیدا نشده؟ */
    function readAwaitLanded() {
        var stamp = parseInt(readSessionValue(AWAIT_LANDED_KEY), 10);
        if (isNaN(stamp) || stamp <= 0 || (Date.now() - stamp) > LANDED_TTL_MS) {
            removeSessionValue(AWAIT_LANDED_KEY);
            return false;
        }

        return true;
    }

    /**
     * ثبت قطعی پوشه‌ی فرود — کلیدهای نشست (فرود + مهر + پوشه‌ی مرور)
     * نوشته و نشانگر «نشست تازه» و پرچم چسباندن پاک می‌شوند؛ از این به
     * بعد انتخابگر/پنل از همین مسیر شروع می‌کنند (تا جایی که انتخاب
     * صریح کاربر مقدم نباشد). همان اثری که آپلود از خود انتخابگر دارد.
     */
    function recordLandedFolder(folder) {
        folder = String(folder || '');
        if (folder === '' || !validRelativeFolder(folder)) {
            return;
        }

        writeSessionValue(LANDED_STORE_KEY, folder);
        writeSessionValue(LANDED_STAMP_KEY, String(Date.now()));
        writeSessionValue(FOLDER_STORE_KEY, folder);
        removeSessionValue(FRESH_ROOT_KEY);
        removeSessionValue(AWAIT_LANDED_KEY);
    }

    /** ثبت خودکار پوشه‌ی فرودِ آپلود/درج تازه — بدون نیاز به باز شدن انتخابگر */
    function captureFreshUploadFolder() {
        if (!cfg.canBrowse) {
            return;
        }

        var folder = scanFreshUploadFolder();
        if (folder !== '') {
            recordLandedFolder(folder);
        }
    }

    /*
     * مودال یکدست پیام‌های حساس (mm-confirm.js — پیش از این اسکریپت بار
     * می‌شود). اگر به هر دلیلی در دسترس نبود، به confirm بومی برمی‌گردیم
     * تا عملیات حساس هرگز بدون تأیید انجام نشود.
     */
    var mmConfirm = window.mmConfirm || function (opts) {
        return Promise.resolve(!!window.confirm(opts && opts.message));
    };

    /* ---------- آیکون‌های Lucide (SVG درون‌خطی امن) ---------- */

    /**
     * ساخت المان svg آیکون Lucide.
     * محتوای داخلی فقط از نقشه‌ی ثابت سرور می‌آید (بدون داده کاربر).
     */
    function lucide(name, cls) {
        var inner = ICONS[name];
        if (!inner) {
            return document.createTextNode('');
        }

        var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
        svg.setAttribute('viewBox', '0 0 24 24');
        svg.setAttribute('fill', 'none');
        svg.setAttribute('stroke', 'currentColor');
        svg.setAttribute('stroke-width', '2');
        svg.setAttribute('stroke-linecap', 'round');
        svg.setAttribute('stroke-linejoin', 'round');
        svg.setAttribute('aria-hidden', 'true');
        if (cls) {
            svg.setAttribute('class', cls);
        }

        svg.innerHTML = inner; // رشته‌ی ثابت؛ داده کاربر هرگز وارد نمی‌شود
        return svg;
    }

    function setIcon($el, name, cls) {
        $el.empty().append(lucide(name, cls));
        return $el;
    }

    /* ---------- دسته‌بندی انواع فایل (آیکون اختصاصی هر نوع) ---------- */

    var FILE_KINDS = cfg.fileKinds || {};
    var KIND_ICONS = cfg.kindIcons || {};
    var KIND_LABELS = cfg.kindLabels || {};

    function kindOf(ext) {
        ext = String(ext || '').toLowerCase().replace(/^\./, '');
        var kind = FILE_KINDS[ext] || 'file';
        return {
            kind: kind,
            icon: KIND_ICONS[kind] || 'file',
            label: KIND_LABELS[kind] || 'فایل'
        };
    }

    /** استخراج پسوند از نام فایل یا نشانی */
    function extOf(nameOrUrl) {
        var base = String(nameOrUrl || '').split('?')[0].split('#')[0];
        var match = base.match(/\.([a-z0-9]{1,12})$/i);
        return match ? match[1].toLowerCase() : '';
    }

    /* ---------- ابزار مشترک: اعلان، کپی، مودال، لایت‌باکس ---------- */

    function toast(message, type) {
        var $wrap = $('.mm-toast-wrap');
        if ($wrap.length === 0) {
            $wrap = $('<div class="mm-toast-wrap"></div>').appendTo('body');
        }

        var $t = $('<div class="mm-toast"></div>')
            .addClass(type === 'error' ? 'mm-toast-error' : (type === 'success' ? 'mm-toast-success' : ''))
            .text(String(message || ''))
            .appendTo($wrap);

        setTimeout(function () {
            $t.addClass('mm-toast-out');
            setTimeout(function () {
                $t.remove();
            }, 300);
        }, 2600);
    }

    function copyText(text) {
        return new Promise(function (resolve) {
            text = String(text || '');

            var fallback = function () {
                try {
                    var $tmp = $('<textarea></textarea>')
                        .val(text)
                        .css({ position: 'fixed', opacity: 0, top: 0, left: 0 })
                        .attr('readonly', 'readonly')
                        .appendTo('body');

                    var sel = document.getSelection();
                    var saved = sel && sel.rangeCount > 0 ? sel.getRangeAt(0) : null;

                    $tmp[0].select();
                    $tmp[0].setSelectionRange(0, text.length);
                    var ok = document.execCommand('copy');
                    $tmp.remove();

                    if (saved && sel) {
                        sel.removeAllRanges();
                        sel.addRange(saved);
                    }

                    resolve(ok);
                } catch (e) {
                    resolve(false);
                }
            };

            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(text).then(function () {
                    resolve(true);
                }).catch(fallback);
            } else {
                fallback();
            }
        });
    }

    function buildLightbox() {
        var $modal = $(
            '<div class="mm-modal" id="mm-editor-lightbox" hidden role="dialog" aria-modal="true">' +
            '<div class="mm-modal-backdrop"></div>' +
            '<div class="mm-modal-box mm-lightbox-box">' +
            '<header class="mm-modal-head"><strong class="mm-modal-title"></strong>' +
            '<button type="button" class="mm-modal-close" title="' + (strings.close || 'بستن') + '"></button></header>' +
            '<div class="mm-lightbox-body"><img alt=""></div>' +
            '<footer class="mm-modal-foot"><span class="mm-lightbox-url mono"></span>' +
            '<button type="button" class="btn btn-s primary mm-copy"></button></footer>' +
            '</div></div>'
        );

        setIcon($modal.find('.mm-modal-close'), 'x', 'mm-ico');
        $modal.find('.mm-copy').append(lucide('link', 'mm-ico mm-ico-sm'))
            .append(document.createTextNode(strings.copy || 'کپی لینک'));
        $modal.appendTo('body');

        $modal.on('click', '.mm-modal-backdrop, .mm-modal-close', function () {
            $modal.prop('hidden', true);
        });

        $(document).on('keydown', function (e) {
            if (e.key === 'Escape' && !$modal.prop('hidden')) {
                $modal.prop('hidden', true);
            }
        });

        $modal.find('.mm-copy').on('click', function () {
            copyText($modal.data('url') || '').then(function (ok) {
                toast(ok ? (strings.copied || 'کپی شد') : (strings.copyFailed || 'کپی ناموفق'), ok ? 'success' : 'error');
            });
        });

        return $modal;
    }

    var $lightbox = buildLightbox();

    function openLightbox(item) {
        if (!item || !item.isImage) {
            toast(strings.notImage || 'پیش‌نمایش فقط برای تصاویر ممکن است', 'error');
            return;
        }

        $lightbox.find('.mm-modal-title').text(item.title || '');
        $lightbox.find('.mm-lightbox-url').text(item.url || '');
        var $img = $lightbox.find('img');
        $img.attr('src', item.url);
        $img.attr('alt', item.title || '');
        $lightbox.data('url', item.url);
        $lightbox.prop('hidden', false);
    }

    /** تبدیل URLهای نسبی به مطلق نسبت به ریشه سایت */
    function resolveUrl(url) {
        url = String(url || '');
        if (/^(https?:)?\/\//i.test(url) || /^(data|blob):/i.test(url)) {
            return url;
        }

        if (url.charAt(0) === '/') {
            var base = String(cfg.siteUrl || '').replace(/\/+$/, '');
            return base + url;
        }

        return url;
    }

    /* ---------- A) گرید بندانگشتی فهرست پیوست‌ها ---------- */

    function enhanceListItem(li, attachment) {
        var $li = $(li);
        if ($li.data('mmEnhanced')) {
            return;
        }

        var url = String(attachment && attachment.url ? attachment.url : ($li.attr('data-url') || ''));
        var isImage = attachment ? !!attachment.isImage : (String($li.attr('data-image') || '0') === '1');
        var title = String(attachment && attachment.title ? attachment.title : ($li.find('.insert').first().text() || ''));

        // آیتم هنوز در حال بارگذاری است (placeholder هسته)؛ برای تقویت بعدی صرف‌نظر کن
        if (!attachment && (!url || $li.hasClass('loading'))) {
            return;
        }

        $li.data('mmEnhanced', true);
        $li.addClass('mm-file-item');
        if (isImage) {
            $li.addClass('mm-has-thumb');
        }

        if (isImage && url) {
            var $thumb = $('<button type="button" class="mm-file-thumb"></button>')
                .attr('title', strings.preview || 'پیش‌نمایش')
                .attr('aria-label', (strings.preview || 'پیش‌نمایش') + ': ' + title);

            $('<img>').attr({
                src: resolveUrl(url),
                alt: title,
                loading: 'lazy',
                decoding: 'async'
            }).appendTo($thumb);

            $thumb.on('click', function () {
                openLightbox({ url: resolveUrl(url), title: title, isImage: true });
                return false;
            });

            $li.prepend($thumb);
        } else {
            // آیکون اختصاصی نوع فایل (آرشیو/سند/صدا/ویدیو/…)
            var fileExt = attachment && attachment.type
                ? String(attachment.type)
                : extOf($li.attr('data-url') || url);
            var info = kindOf(fileExt);

            var $chip = $('<span class="mm-file-kindicon"></span>')
                .addClass('mm-kind-' + info.kind)
                .attr('title', info.label);

            $chip.append(lucide(info.icon, 'mm-ico mm-ico-sm'));
            $chip.append($('<span class="mm-kindicon-ext"></span>').text('.' + (fileExt || 'file')));
            $li.prepend($chip);
        }

        var $info = $li.find('.info').first();
        if ($info.length > 0) {
            var $copy = $('<button type="button" class="mm-copy-link"></button>')
                .attr('title', strings.copy || 'کپی لینک')
                .attr('aria-label', strings.copy || 'کپی لینک');

            $copy.append(lucide('copy', 'mm-ico mm-ico-sm'));

            $copy.on('click', function () {
                copyText(resolveUrl(url)).then(function (ok) {
                    toast(ok ? (strings.copied || 'لینک کپی شد') : (strings.copyFailed || 'کپی ناموفق'), ok ? 'success' : 'error');
                });
                return false;
            });

            $info.append(document.createTextNode(' ')).append($copy);
        }

        $li.data('mmItem', { url: resolveUrl(url), title: title, isImage: isImage });
    }

    function enhanceFileList() {
        var $list = $('#file-list');
        if ($list.length === 0) {
            return;
        }

        $list.addClass('mm-grid');
        $list.find('li').each(function () {
            enhanceListItem(this);
        });
    }

    /**
     * پایش فهرست پیوست‌ها:
     *  - افزودن آیتم جدید (childList)
     *  - تکمیل مشخصه‌های آیتم پس از پایان بارگذاری (attribute data-url)
     * یادآوری: هسته ابتدا placeholder با کلاس loading اضافه می‌کند و پس از
     * پایان بارگذاری، همان آیتم را با data-url/data-image تکمیل می‌کند.
     */
    function watchFileList() {
        var listEl = document.getElementById('file-list');
        if (!listEl || !window.MutationObserver) {
            return;
        }

        var scanList = function () {
            $(listEl).find('li').each(function () {
                enhanceListItem(this);
            });
        };

        var observer = new MutationObserver(function (mutations) {
            var relevant = false;
            mutations.forEach(function (mutation) {
                if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                    relevant = true;
                } else if (mutation.type === 'attributes') {
                    relevant = true;
                }
            });

            if (relevant) {
                scanList();
            }
        });

        observer.observe(listEl, {
            childList: true,
            attributes: true,
            attributeFilter: ['data-url', 'data-image', 'class'],
            subtree: true
        });
    }

    /* ---------- B) پنل «پیوست‌های پست» ---------- */

    var previewTimer = null;
    var lastPreviewKey = null;

    /**
     * خواندن پیوست‌های واقعی این پست از فهرست هسته (#file-list).
     * این فهرست سمت سرور رندر می‌شود (file-upload.php) و با آپلود یا
     * حذف در همان صفحه به‌روز می‌شود؛ حتی وقتی نمایش پیش‌فرض آن با
     * mm-system-upload-off مخفی شده باشد، داده‌ها در DOM موجودند و
     * بدون هیچ درخواست اضافه‌ای قابل خواندن‌اند.
     * پیوست‌ها لزوماً تصویر نیستند (فایل دانلودی، عکس هدر و…) — برای
     * موارد غیرتصویری هم کارت با آیکون نوع فایل ساخته می‌شود.
     *
     * نکته‌ی نسخه‌ی ۱.۸.۴: برای محکم‌کاری بیشتر در برابر پیوست‌های
     * یتیمیِ ممکن در پایگاه‌داده (مثلاً پس از ارتقا از نسخه‌های قدیمی
     * TypeRenew که unAttach نداشتند)، فقط آیتم‌هایی پذیرفته می‌شوند که
     * «همچنان» در فرم write_post به‌عنوان attachment[] موجودند. این یعنی
     * اگر کاربری یک پیوست را با دکمه‌ی «حذف از لیست» (نه حذف از دیتابیس)
     * از لیست کنار گذاشته، دیگر در پنل پیش‌نمایش هم نمایش داده نمی‌شود.
     */
    function attachedItemsFromFileList() {
        var items = [];

        var $list = $('#file-list');
        if ($list.length === 0) {
            return items;
        }

        // مجموعه‌ی cid های مجاز — یعنی پیوست‌هایی که هنوز در فرم
        // write_post به‌عنوان attachment[] موجودند (یعنی پست فعلی، آن‌ها
        // را به‌عنوان پیوست خود شناسایی کرده است). آیتم‌هایی که از این
        // مجموعه خارج شوند (مثلاً پس از کلیک روی «حذف از لیست») دیگر در
        // پنل پیش‌نمایش نمایش داده نمی‌شوند، بدون آنکه رکورد پیوست در
        // دیتابیس تغییری کرده باشد.
        var allowedCids = {};
        $list.find('input[name="attachment[]"]').each(function () {
            var v = parseInt(String($(this).val() || '0'), 10);
            if (v > 0) {
                allowedCids[v] = true;
            }
        });

        $list.find('li').each(function () {
            var $li = $(this);

            // placeholder در حال بارگذاری هسته — data-url هنوز ندارد
            if ($li.hasClass('loading')) {
                return;
            }

            var url = String($li.attr('data-url') || '');
            if (!url) {
                return; // ردیف خطا یا ناقص
            }

            var cid = parseInt(String($li.attr('data-cid') || '0'), 10) || 0;

            // فیلتر نو: فقط پیوست‌هایی که هنوز در فرم write_post به‌عنوان
            // attachment[] موجودند. اگر کاربر آن‌ها را با «حذف از لیست»
            // کنار گذاشته، input مخفی آن‌ها از فرم حذف شده و اینجا هم
            // نمایش داده نمی‌شوند.
            if (cid > 0 && !allowedCids[cid]) {
                return;
            }

            items.push({
                url: url,
                title: String($li.find('.insert').first().text() || '').trim(),
                isImage: String($li.attr('data-image') || '0') === '1',
                // شناسه‌ی رکورد پیوست — برای «حذف» و «درج در مطلب»
                cid: cid
            });
        });

        return items;
    }

    /** نام نمایشی فایل از نشانی آن (بدون کوئری/هش) */
    function previewFileName(url) {
        var fileName = decodeURIComponent(String(url).split('/').pop() || '');
        return fileName.split('?')[0].split('#')[0] || String(url);
    }

    /**
     * استخراج نشانی تصاویر از متن پست
     * پشتیبانی از: markdown درون‌خطی ![alt](url)، تصاویر ارجاعی ![alt][ref]
     * همراه تعریف [ref]: url، و <img src="url">
     */
    function extractImageUrls(text) {
        var urls = [];
        var seen = {};

        function push(url) {
            url = String(url || '').trim();
            if (url && url.length < 2048 && !seen[url]) {
                seen[url] = true;
                urls.push(url);
            }
        }

        // ۱) تعاریف ارجاع: [ref]: url (در ابتدای خط)
        var refs = {};
        var refRe = /^[ \t]*\[([^\]\n]+)\]:[ \t]*<?([^<>\s]+)>?/gm;
        var refMatch;
        while ((refMatch = refRe.exec(text)) !== null) {
            refs[String(refMatch[1]).toLowerCase()] = refMatch[2];
        }

        // ۲) تصاویر ارجاعی: ![alt][ref]
        var refImgRe = /!\[[^\]\n]*\]\s*\[([^\]\n]*)\]/g;
        var refImgMatch;
        while ((refImgMatch = refImgRe.exec(text)) !== null) {
            var ref = String(refImgMatch[1]).toLowerCase();
            if (ref === '') {
                // شکل فشرده ![alt][] — از خود alt به‌عنوان ارجاع استفاده می‌شود
                continue;
            }
            if (refs[ref]) {
                push(refs[ref]);
            }
        }

        // ۳) markdown درون‌خطی: ![alt](url)
        var mdRe = /!\[[^\]\n]*\]\(\s*<?([^()\s>]+)>?(?:\s+&quot;[^&]*&quot;)?\s*\)/g;
        var mdMatch;
        while ((mdMatch = mdRe.exec(text)) !== null) {
            push(mdMatch[1]);
        }

        // ۴) HTML: <img src="url">
        var htmlRe = /<img[^>]+src=["']([^"']+)["'][^>]*>/gi;
        var htmlMatch;
        while ((htmlMatch = htmlRe.exec(text)) !== null) {
            push(htmlMatch[1]);
        }

        return urls;
    }

    /**
     * جمع‌آوری آیتم‌های پیش‌نمایش (مشترک بین پنل پایین ویرایشگر و
     * پیش‌نمایش تب پیوست‌ها): اول پیوست‌های واقعی پست از فهرست هسته
     * (عنوان رسمی دارند؛ تصویر یا فایل — هر نوعی)، بعد تصاویر درج‌شده
     * در متن (مثل تصاویر خارجی یا کتابخانه)؛ ادغام بدون تکرار.
     */
    function collectPreviewItems() {
        var text = String($textarea.val() || '');
        var attached = attachedItemsFromFileList();
        var attachedSig = attached.map(function (item) {
            return item.url + (item.isImage ? 'i' : 'f');
        }).join('|');

        var items = [];
        var seen = {};

        function pushItem(url, title, isImage, attachedToFileList, cid) {
            var resolved = resolveUrl(url);
            if (!resolved || seen[resolved]) {
                return;
            }
            seen[resolved] = true;
            items.push({
                url: url,
                resolved: resolved,
                title: title || previewFileName(url),
                isImage: !!isImage,
                attached: !!attachedToFileList,
                // فقط پیوست‌های واقعی پست cid دارند؛ تصاویرِ فقط‌متنی 0
                cid: attachedToFileList ? (parseInt(cid, 10) || 0) : 0
            });
        }

        attached.forEach(function (item) {
            pushItem(item.url, item.title, item.isImage, true, item.cid);
        });

        extractImageUrls(text).forEach(function (rawUrl) {
            pushItem(rawUrl, '', true, false);
        });

        return {
            items: items,
            key: text.length + ':' + (text.slice(0, 64)) + ':' + (text.slice(-64)) + '#' + attachedSig
        };
    }

    function renderPreview() {
        var $panel = $('#mm-editor-panel');
        var $grid = $('#mm-preview-grid');
        var $empty = $('#mm-preview-empty');
        var $count = $('#mm-preview-count');

        if ($panel.length === 0 || $grid.length === 0) {
            return;
        }

        var collected = collectPreviewItems();
        if (collected.key === lastPreviewKey) {
            return;
        }
        lastPreviewKey = collected.key;

        // ادغام بدون تکرار: اول پیوست‌های واقعی پست (عنوان رسمی دارند)،
        // بعد تصاویر درج‌شده در متن (مثل تصاویر خارجی یا کتابخانه)
        var items = collected.items;

        $grid.empty();

        if (items.length === 0) {
            $grid.hide();
            $empty.show();
            $count.text(faNum(0));
            return;
        }

        $grid.show();
        $empty.hide();
        $count.text(faNum(items.length));

        items.slice(0, 36).forEach(function (item) {
            var $item = $('<figure class="mm-preview-item"></figure>');
            if (!item.isImage) {
                $item.addClass('mm-preview-item-file');
            }

            var $btn;

            if (item.isImage) {
                // کارت تصویر — بندانگشتی + لایت‌باکس (مثل قبل)
                $btn = $('<button type="button" class="mm-preview-thumb"></button>')
                    .attr('title', strings.preview || 'پیش‌نمایش')
                    .attr('aria-label', (strings.preview || 'پیش‌نمایش') + ': ' + item.title);

                var $img = $('<img>').attr({ src: item.resolved, alt: item.title, loading: 'lazy', decoding: 'async' });
                $img.on('error', function () {
                    $item.addClass('mm-img-broken');
                });
                $btn.append($img);

                $btn.on('click', function () {
                    openLightbox({ url: item.resolved, title: item.title, isImage: true });
                    return false;
                });
            } else {
                // کارت فایل — آیکون اختصاصی نوع + پسوند؛ کلیک = بازکردن/دانلود
                var info = kindOf(extOf(item.url));
                $btn = $('<button type="button" class="mm-preview-thumb mm-preview-file"></button>')
                    .addClass('mm-kind-' + info.kind)
                    .attr('title', strings.openFile || 'باز کردن فایل')
                    .attr('aria-label', (strings.openFile || 'باز کردن فایل') + ': ' + item.title);

                var $body = $('<span class="mm-preview-file-body"></span>');
                $body.append(lucide(info.icon, 'mm-ico mm-ico-previewfile'));
                $body.append($('<span class="mm-preview-file-ext"></span>').text('.' + (extOf(item.url) || 'file')));
                $btn.append($body);

                $btn.on('click', function () {
                    window.open(item.resolved, '_blank', 'noopener');
                    return false;
                });
            }

            /*
             * نوار ابزار کارت: کپی لینک + «درج در مطلب» + «حذف از لیست»
             *
             * نکته‌ی نسخه‌ی ۱.۸.۴: دکمه‌ی «حذف پیوست» (انتقال به سطل) با
             * دکمه‌ی ضربدر «حذف از لیست» جایگزین شد. این دکمه فقط آیتم را
             * از فهرست پیوست‌های پست فعلی برمی‌دارد و فایل فیزیکی و رکورد
             * دیتابیس را دست‌نخورده باقی می‌ماند. برای حذف واقعی فایل، از
             * پنل «مدیا منیجر» استفاده کنید.
             *
             * نکته‌ی نسخه‌ی ۱.۸.۴ (اصلاح دوم): دکمه‌های «درج در متن» و
             * «حذف از لیست» اکنون برای **همه** آیتم‌ها (حتی تصاویر فقط‌متنی
             * که cid ندارند) ساخته می‌شوند. برای آیتم‌های فقط‌متنی:
             *  - «درج در متن»: آیتم دوباره در موقعیت مکان‌نما درج می‌شود
             *  - «حذف از لیست»: URL آیتم از متن پست پاک می‌شود (نه از
             *    دیتابیس)؛ پیش‌نمایش پس از تازه‌سازی، دیگر آن آیتم را
             *    نشان نمی‌دهد.
             */
            var $tools = $('<div class="mm-mini-row"></div>');

            var $copy = $('<button type="button" class="mm-mini-btn"></button>')
                .attr('title', strings.copy || 'کپی لینک')
                .attr('aria-label', (strings.copy || 'کپی لینک') + ': ' + item.title);
            $copy.append(lucide('copy', 'mm-ico mm-ico-sm'));
            $copy.on('click', function () {
                copyText(item.resolved).then(function (ok) {
                    toast(ok ? (strings.copied || 'لینک کپی شد') : (strings.copyFailed || 'کپی ناموفق'), ok ? 'success' : 'error');
                });
                return false;
            });
            $tools.append($copy);

            /*
             * «درج در متن» برای همه آیتم‌ها (پیوست واقعی یا فقط‌متنی).
             * insertItemIntoPost از همان مسیر امن استفاده می‌کند و در
             * موقعیت مکان‌نمای textarea درج می‌شود.
             */
            var $insertBtn = $('<button type="button" class="mm-mini-btn"></button>')
                .attr('title', strings.insert || 'درج در متن')
                .attr('aria-label', (strings.insert || 'درج در متن') + ': ' + item.title);
            $insertBtn.append(lucide('corner-down-left', 'mm-ico mm-ico-sm'));
            $insertBtn.on('click', function () {
                insertItemIntoPost(item);
                return false;
            });
            $tools.append($insertBtn);

            /*
             * دکمه‌ی ضربدر «حذف از لیست» — برای همه آیتم‌ها:
             *  - پیوست واقعی (cid>0): input مخفی attachment[] را از فرم
             *    حذف و ردیف #file-list را می‌پاکد. فایل دست‌نخورده می‌ماند.
             *  - آیتم فقط‌متنی (cid=0): URL را از متن پست پاک می‌کند؛
             *    پیش‌نمایش پس از تازه‌سازی، دیگر آن را نشان نمی‌دهد.
             */
            var $removeBtn = $('<button type="button" class="mm-mini-btn mm-mini-remove"></button>')
                .attr('title', strings.removeFromList || 'حذف از لیست')
                .attr('aria-label', (strings.removeFromList || 'حذف از لیست') + ': ' + item.title);
            $removeBtn.append(lucide('x', 'mm-ico mm-ico-sm'));
            $removeBtn.on('click', function () {
                removeFromList(item);
                return false;
            });
            $tools.append($removeBtn);

            var $name = $('<span class="mm-preview-name"></span>').text(item.title);

            $item.append($tools).append($btn).append($name);
            $grid.append($item);
        });
    }

    /**
     * پایش فهرست پیوست‌های هسته (#file-list) برای پنل پیش‌نمایش:
     * با آپلود فایل جدید، حذف یا تکمیل placeholder (ثبت data-url)،
     * پیش‌نمایش بدون درخواست اضافه تازه می‌شود. حتی وقتی نمایش پیش‌فرض
     * فهرست مخفی است (mm-system-upload-off) داده‌ها در DOM موجودند.
     */
    function watchFileListForPreview() {
        var listEl = document.getElementById('file-list');
        if (!listEl || !window.MutationObserver) {
            return;
        }

        var observer = new MutationObserver(function () {
            schedulePreview();
        });

        observer.observe(listEl, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ['data-url', 'data-image', 'class']
        });
    }

    function schedulePreview() {
        clearTimeout(previewTimer);
        previewTimer = setTimeout(function () {
            /*
             * ثبت خودکار پوشه‌ی فرود آپلود/درج تازه (مثل چسباندن فایل در
             * خود ویرایشگر) — تا وقتی انتخابگر باز نشده هم کلیدهای نشست
             * آماده باشند و پنل کتابخانه هم از همان مسیر شروع شود.
             */
            captureFreshUploadFolder();
            renderPreview();
            renderTabPreview();
        }, 350);
    }

    /** درج امن متن در موقعیت مکان‌نمای textarea با selection بومی */
    function insertAtCursor(snippet) {
        if (!$textarea.length || $textarea.length === 0) {
            return;
        }

        var node = $textarea.get(0);
        var start = 0;
        var end = 0;

        try {
            $textarea.focus();
            start = node.selectionStart || 0;
            end = node.selectionEnd || 0;
        } catch (e) {
            start = end = node.value.length;
        }

        var value = node.value || '';
        node.value = value.slice(0, start) + snippet + value.slice(end);

        var offset = start + snippet.length;
        try {
            node.setSelectionRange(offset, offset);
        } catch (e) {
            // بدون پشتیبانی setSelectionRange؛ بی‌خطر است
        }

        $textarea.trigger('input');
        $textarea.trigger('change');
    }

    /* ---------- درج در متن و حذف پیوست (مشترک پنل پایین و تب پیوست‌ها) ---------- */

    /**
     * ساخت قطعه‌ی درج برای یک فایل — همان قالب «درج در متن» انتخابگر:
     * تصویر ← ![](url) / <img>، فایل ← [](url) / <a> (بر اساس حالت ویرایشگر)
     */
    function buildInsertSnippet(item, useMarkdown) {
        var url = String(item.resolved || item.url || '');
        var title = String(item.title || '');

        if (useMarkdown) {
            var mdTitle = title.replace(/[\[\]]/g, '');
            return item.isImage
                ? '![' + mdTitle + '](' + url + ')'
                : '[' + mdTitle + '](' + url + ')';
        }

        return item.isImage
            ? '<img src="' + url + '" alt="' + title.replace(/"/g, '&quot;') + '" />'
            : '<a href="' + url + '">' + title.replace(/</g, '&lt;') + '</a>';
    }

    /**
     * درج آیتم(ها) در متن پست — ابتدا پل ادیتور جانشین (مثل نگارش) که
     * window.MediaManager.editor.insert(items, useMarkdown) را تعریف می‌کند؛
     * اگر خودش درج کرد (true برگرداند) تمام. وگرنه همان مسیر پیش‌فرض:
     * درج در موقعیت مکان‌نمای textarea.
     * خروجی: true اگر درج انجام شد.
     */
    function insertItemsIntoPost(items) {
        if (!items || !items.length) {
            return false;
        }

        var useMarkdown = String($('form input[name=markdown]').val() || '') === '1';

        var bridge = window.MediaManager && window.MediaManager.editor
            ? window.MediaManager.editor.insert
            : null;

        if (typeof bridge === 'function') {
            try {
                var payload = items.map(function (item) {
                    return {
                        url: String(item.resolved || item.url || ''),
                        title: String(item.title || ''),
                        isImage: !!item.isImage,
                        cid: item.cid > 0 ? item.cid : 0
                    };
                });

                if (bridge(payload, useMarkdown) === true) {
                    schedulePreview();
                    return true;
                }
            } catch (e) {
                /* پل جانشین خطا داد → مسیر پیش‌فرض textarea */
            }
        }

        var snippets = items.map(function (item) {
            return buildInsertSnippet(item, useMarkdown);
        });

        insertAtCursor(snippets.join('\n'));
        schedulePreview();
        return true;
    }

    /** درج یک آیتم در متن + اعلان (دکمه‌ی «درج در مطلب» پیش‌نمایش‌ها) */
    function insertItemIntoPost(item) {
        if (insertItemsIntoPost([item])) {
            toast(strings.inserted || 'در متن درج شد', 'success');
        }
    }

    /**
     * به‌روزرسانی شمارنده‌ی روی تب «پیوست» — همان منطق آپلودر هسته
     * (file-upload-js.php) تا پس از حذف دستی ردیف، شمارنده هم درست بماند
     */
    function updateTabBalloon() {
        var $btn = $('#tab-files-btn');
        if ($btn.length === 0) {
            return;
        }

        var $balloon = $btn.find('.balloon');
        var count = $('#file-list li .insert').length;

        if (count > 0) {
            if ($balloon.length === 0) {
                $btn.html(($btn.html() || '').trim() + ' ');
                $balloon = $('<span class="balloon"></span>').appendTo($btn);
            }
            $balloon.html(count);
        } else if ($balloon.length > 0) {
            $balloon.remove();
        }
    }

    /**
     * درخواست POST عمومی با JSON هسته (code === 200) — همان قرارداد
     * اندپوینت‌های پوشه/فایل و حذف پیوست
     */
    function postFolderAction(url, data) {
        return fetch(url, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            },
            body: data
        }).then(function (response) {
            return response.json().catch(function () {
                return null;
            }).then(function (payload) {
                if (!response.ok || !payload || Number(payload.code) !== 200) {
                    throw new Error(payload && payload.message ? payload.message : '');
                }
                return payload;
            });
        });
    }

    /**
     * حذف پیوست واقعی پست (دکمه‌ی «حذف» پیش‌نمایش‌ها):
     *  - همان اندپوینت حذف هسته (contents-attachment-edit) که به واسطه‌ی
     *    هوک حذف نرم مدیامنجر، فایل به «سطل بازیافت» می‌رود (قابل بازگردانی).
     *  - پس از موفقیت: ردیف متناظر از فهرست پیوست هسته (#file-list) حذف و
     *    شمارنده‌ی تب به‌روز می‌شود؛ ناظر تغییرات همان لحظه هر دو پیش‌نمایش
     *    (تب پیوست‌ها و پنل پایین ویرایشگر) را تازه می‌کند.
     * فقط برای پیوست‌های واقعی (cid > 0) فعال است — تصاویر فقط‌متنی قابل
     * حذف از اینجا نیستند.
     */
    function deleteAttachedItem(item) {
        if (!(item && item.cid > 0)) {
            return;
        }

        /*
         * مودال یکدست پیام‌های حساس (mm-confirm.js) — حذف پیوست یعنی
         * انتقال به سطل بازیافتِ قابل بازگردانی.
         */
        mmConfirm({
            icon: 'trash-2',
            danger: true,
            title: strings.deleteConfirmTitle || 'انتقال به سطل بازیافت',
            message: strings.deleteConfirm || 'این فایل به سطل زباله منتقل شود؟ (قابل بازگردانی از سطل زباله در پنل مدیا منیجر)',
            confirmText: strings.deleteConfirmYes || 'حذف'
        }).then(function (ok) {
            if (!ok) {
                return;
            }

            var data = new FormData();
            data.append('do', 'delete');
            data.append('cid', String(item.cid));

            postFolderAction(cfg.deleteUrl, data).then(function () {
                $('#file-list li').each(function () {
                    var $li = $(this);
                    if (String($li.attr('data-cid') || '') === String(item.cid)) {
                        $li.remove();
                    }
                });

                updateTabBalloon();
                toast(strings.deleted || 'حذف شد', 'success');

                // ناظر #file-list پیش‌نمایش‌ها را تازه می‌کند؛ برای اطمینان:
                schedulePreview();
            }).catch(function (error) {
                toast(error && error.message
                    ? error.message
                    : (strings.deleteError || 'حذف فایل ناموفق بود.'), 'error');
            });
        });
    }

    /**
     * حذف از لیست (دکمه‌ی ضربدر) — برای هر دو نوع آیتم:
     *
     * **نوع ۱ — پیوست واقعی پست (cid > 0):**
     * فقط input مخفی attachment[] را از فرم write_post حذف می‌کند و ردیف
     * متناظر در #file-list را می‌پاکد. فایل فیزیکی و رکورد دیتابیس
     * دست‌نخورده باقی می‌ماند. پیوست در پنل «مدیا منیجر» همچنان موجود است
     * و می‌توان آن را دوباره با «افزودن از کتابخانه» به پست پیوست کرد.
     *
     * **نوع ۲ — آیتم فقط‌متنی (cid = 0):**
     * URL آیتم را از متن پست پاک می‌کند (همه‌ی رخدادها در فرمت‌های
     * Markdown و HTML). پیش‌نمایش پس از تازه‌سازی، دیگر آن آیتم را نشان
     * نمی‌دهد. فایل فیزیکی دست‌نخورده باقی می‌ماند.
     *
     * **مهم:** در هر دو حالت، فایل فیزیکی و رکورد دیتابیس دست‌نخورده
     * باقی می‌مانند. برای حذف واقعی فایل (انتقال به سطل بازیافت)، از
     * پنل «مدیا منیجر» استفاده کنید.
     *
     * نسخه‌ی ۱.۸.۴: جایگزین دکمه‌ی «حذف پیوست» (که فایل را به سطل می‌برد).
     */
    function removeFromList(item) {
        if (!item) {
            return;
        }

        var removed = false;

        // ----------------------------------------------------------------
        // نوع ۱: پیوست واقعی پست (cid > 0) — حذف از فرم و #file-list
        // ----------------------------------------------------------------
        if (item.cid > 0) {
            var cidStr = String(item.cid);

            // ۱) حذف ردیف <li> از فهرست پیوست‌های هسته (#file-list)
            $('#file-list li').each(function () {
                var $li = $(this);
                if (String($li.attr('data-cid') || '') === cidStr) {
                    $li.remove();
                    removed = true;
                }
            });

            // ۲) حذف input مخفی attachment[] متناظر از فرم write_post
            //    (این input داخل همان <li> است، اما برای اطمینان از حذف کامل،
            //    کل فرم را هم اسکن می‌کنیم)
            $('form[name="write_post"], form[name="write_page"]').find('input[name="attachment[]"]').each(function () {
                if (String($(this).val() || '') === cidStr) {
                    $(this).remove();
                    removed = true;
                }
            });
        }

        // ----------------------------------------------------------------
        // نوع ۲: آیتم فقط‌متنی (cid = 0) — حذف URL از متن پست
        // ----------------------------------------------------------------
        // برای هر دو نوع (حتی پیوست واقعی)، URL را از متن هم پاک می‌کنیم
        // تا اگر کاربر تصویری را هم به‌عنوان پیوست و هم در متن درج کرده،
        // با حذف از لیست، از متن هم پاک شود. اگر URL در متن نباشد، هیچ
        // تغییری در متن ایجاد نمی‌شود.
        if ($textarea.length > 0 && item.url) {
            var text = String($textarea.val() || '');
            var newText = removeUrlFromText(text, item.url);

            if (newText !== text) {
                $textarea.val(newText);
                $textarea.trigger('input');
                $textarea.trigger('change');
                removed = true;
            }
        }

        if (removed) {
            updateTabBalloon();
            toast(strings.removedFromList || 'از لیست پیوست‌ها حذف شد', 'success');

            // ناظر #file-list پیش‌نمایش‌ها را تازه می‌کند؛ برای اطمینان:
            schedulePreview();
        }
    }

    /**
     * حذف همه‌ی رخدادهای یک URL از متن پست — پشتیبانی از:
     *  - Markdown درون‌خطی: ![alt](url) و [](url)
     *  - Markdown ارجاعی: ![alt][ref] با تعریف [ref]: url
     *  - HTML: <img src="url"> و <a href="url">
     *
     * اگر URL پیدا نشد، متن دست‌نخورده برمی‌گردد.
     */
    function removeUrlFromText(text, url) {
        if (!text || !url) {
            return text;
        }

        // نرمال‌سازی URL برای مقایسه (حذف کاراکترهای escape در Markdown)
        var normalizedUrl = String(url).replace(/([\\\*\_\[\]\(\)])/g, '\\$1');
        var rawUrl = String(url);

        var result = text;

        // ۱) Markdown تصویر درون‌خطی: ![alt](url) — با یا بدون عنوان
        var mdImgRe = new RegExp(
            '!\\[[^\\]\\n]*\\]\\(\\s*<?' + escapeRegExp(rawUrl) + '>?(?:\\s+&quot;[^&]*&quot;)?\\s*\\)',
            'g'
        );
        result = result.replace(mdImgRe, '');

        // ۲) Markdown لینک درون‌خطی: [text](url)
        var mdLinkRe = new RegExp(
            '\\[[^\\]\\n]*\\]\\(\\s*<?' + escapeRegExp(rawUrl) + '>?(?:\\s+&quot;[^&]*&quot;)?\\s*\\)',
            'g'
        );
        result = result.replace(mdLinkRe, '');

        // ۳) HTML: <img src="url"> و <a href="url">
        var htmlImgRe = new RegExp(
            '<img[^>]+src=["\']' + escapeRegExp(rawUrl) + '["\'][^>]*>',
            'gi'
        );
        result = result.replace(htmlImgRe, '');

        var htmlLinkRe = new RegExp(
            '<a[^>]+href=["\']' + escapeRegExp(rawUrl) + '["\'][^>]*>[^<]*</a>',
            'gi'
        );
        result = result.replace(htmlLinkRe, '');

        // ۴) Markdown ارجاعی: ![alt][ref] با تعریف [ref]: url
        //    پیدا کردن ref تعریف‌شده برای این URL، سپس حذف همه‌ی ارجاع‌ها
        var refDefRe = new RegExp(
            '^[ \\t]*\\[([^\\]\\n]+)\\]:[ \\t]*<?' + escapeRegExp(rawUrl) + '>?\\s*$',
            'gm'
        );
        var refDefMatch;
        var refsToRemove = [];
        while ((refDefMatch = refDefRe.exec(result)) !== null) {
            refsToRemove.push(refDefMatch[1]);
        }

        // حذف تعریف ref
        result = result.replace(refDefRe, '');

        // حذف ارجاع‌های تصویر و لینک به این ref
        refsToRemove.forEach(function (ref) {
            var refEsc = escapeRegExp(ref);
            // ![alt][ref] یا ![][ref]
            var refImgRe = new RegExp(
                '!\\[[^\\]\\n]*\\]\\s*\\[' + refEsc + '\\]',
                'g'
            );
            result = result.replace(refImgRe, '');
            // [text][ref] یا [][ref]
            var refLinkRe = new RegExp(
                '\\[[^\\]\\n]*\\]\\s*\\[' + refEsc + '\\]',
                'g'
            );
            result = result.replace(refLinkRe, '');
        });

        return result;
    }

    /** escape یک رشته برای استفاده در RegExp */
    function escapeRegExp(str) {
        return String(str).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    /* ---------- پیش‌نمایش پیوست‌ها در تب پیوست‌ها (زیر کادر آپلود) ---------- */

    var $tabPreview = null;

    /**
     * سقف نمایش فهرست فشرده‌ی تب پیوست‌ها؛ مازاد با دکمه‌ی «و N مورد دیگر»
     * اعلام و با کلیک روی همان دکمه، کل فهرست باز/بسته می‌شود.
     */
    var TAB_PREVIEW_MAX = 8;

    /** حالت باز/بسته‌ی فهرست کامل پیوست‌ها (دکمه‌ی «و N مورد دیگر») */
    var tabPreviewExpanded = false;

    /**
     * ثبت فایل تازه‌بارگذاری‌شده به‌عنوان پیوست همین پست — دقیقاً همان
     * کاری که آپلودر پیش‌فرض هسته انجام می‌داد: آیتم به فهرست پیوست‌ها
     * (#file-list) اضافه، شمارنده‌ی تب «پیوست» به‌روز و cid در فرم نوشتن
     * ارسال می‌شود تا هسته پیوند را هنگام ذخیره ثبت کند (هم برای پست
     * موجود و هم پیش‌نویس جدید). حتی وقتی نمایش فهرست با
     * mm-system-upload-off مخفی شده، داده‌ها در DOM فعال‌اند و
     * پیش‌نمایش‌ها/شمارنده از همان‌جا تغذیه می‌شوند.
     */
    function attachToPost(attachment) {
        if (!attachment || !(attachment.cid > 0)) {
            return;
        }

        if ($('#file-list').length === 0) {
            return; // صفحه‌ی نوشتن نیست (مثلاً پنل جدا) — کاری نمی‌کنیم
        }

        try {
            if (window.Typecho && typeof window.Typecho.appendAttachment === 'function') {
                window.Typecho.appendAttachment(attachment);
            }
        } catch (e) {
            /* قالب/ادیتور جانشین بدون اسکریپت آپلود هسته — فایل در کتابخانه سالم است */
        }
    }

    /**
     * ساخت ظرف پیش‌نمایش پیوست‌ها زیر کادر آپلود (تب پیوست‌ها).
     * فقط وقتی ساخته می‌شود که کادر آپلود جایگزین آپلودر سیستم باشد
     * (تنظیم «غیرفعال‌سازی آپلودر پیش‌فرض سیستم») — در حالت دکمه‌ی
     * ساده، فهرست پیوست‌های خود هسته در همان تب دیده می‌شود.
     */
    function buildTabPreview($box) {
        $tabPreview = $('<section class="mm-tab-preview" id="mm-tab-preview" aria-live="polite"></section>');

        var $head = $('<div class="mm-tab-preview-head"></div>');
        $('<span class="mm-tab-preview-title"></span>')
            .text(strings.tabPreviewTitle || 'پیوست‌های این پست')
            .appendTo($head);
        $('<span class="mm-tab-preview-count" id="mm-tab-preview-count"></span>').appendTo($head);

        var $copyAll = $('<button type="button" class="mm-tab-preview-copyall" hidden></button>')
            .text(strings.copyLinksOf || 'کپی لینک‌ها');
        $copyAll.on('click', function () {
            var urls = collectPreviewItems().items.map(function (item) {
                return item.resolved;
            });

            if (!urls.length) {
                return;
            }

            copyText(urls.join('\n')).then(function (ok) {
                toast(ok ? (strings.copied || 'لینک کپی شد') : (strings.copyFailed || 'کپی ناموفق'), ok ? 'success' : 'error');
            });
            return false;
        });
        $head.append($copyAll);

        $tabPreview.append($head);
        $tabPreview.append($('<div class="mm-tab-preview-list" id="mm-tab-preview-list"></div>'));
        $tabPreview.append($('<p class="mm-tab-preview-empty"></p>')
            .text(strings.tabPreviewEmpty || 'هنوز پیوستی برای این پست ثبت نشده است.'));

        $box.after($tabPreview);
    }

    /**
     * رندر فهرست فشرده‌ی پیوست‌ها در تب پیوست‌ها — همان داده‌های پنل
     * پایین ویرایشگر: تصویر ← بندانگشتی + لایت‌باکس؛ فایل ← آیکون نوع +
     * بازکردن در تب جدید؛ هر ردیف نام و نشانی فایل و دکمه‌ی کپی لینک دارد
     */
    function renderTabPreview() {
        if (!$tabPreview || $tabPreview.length === 0) {
            return;
        }

        var items = collectPreviewItems().items;
        var $list = $tabPreview.children('.mm-tab-preview-list').first();
        var $empty = $tabPreview.children('.mm-tab-preview-empty').first();
        var $count = $tabPreview.find('#mm-tab-preview-count').first();
        var $copyAll = $tabPreview.find('.mm-tab-preview-copyall').first();

        $list.empty();

        if (items.length === 0) {
            $list.hide();
            $empty.show();
            $count.hide();
            $copyAll.prop('hidden', true);
            return;
        }

        $list.show();
        $empty.hide();
        $count.text(faNum(items.length)).show();
        $copyAll.prop('hidden', items.length < 2);

        /* در حالت باز، کل فهرست؛ در حالت فشرده، فقط سقف TAB_PREVIEW_MAX مورد */
        var visible = tabPreviewExpanded ? items : items.slice(0, TAB_PREVIEW_MAX);

        visible.forEach(function (item) {
            var $row = $('<div class="mm-tab-preview-row"></div>');
            if (!item.isImage) {
                $row.addClass('mm-tab-preview-row-file');
            }

            var $thumb;

            if (item.isImage) {
                $thumb = $('<button type="button" class="mm-tab-preview-thumb"></button>')
                    .attr('title', strings.preview || 'پیش‌نمایش')
                    .attr('aria-label', (strings.preview || 'پیش‌نمایش') + ': ' + item.title);

                var $img = $('<img>').attr({ src: item.resolved, alt: item.title, loading: 'lazy', decoding: 'async' });
                $img.on('error', function () {
                    $row.addClass('mm-img-broken');
                });
                $thumb.append($img);

                $thumb.on('click', function () {
                    openLightbox({ url: item.resolved, title: item.title, isImage: true });
                    return false;
                });
            } else {
                var info = kindOf(extOf(item.url));
                $thumb = $('<button type="button" class="mm-tab-preview-thumb mm-preview-file"></button>')
                    .addClass('mm-kind-' + info.kind)
                    .attr('title', strings.openFile || 'باز کردن فایل (تب جدید)')
                    .attr('aria-label', (strings.openFile || 'باز کردن فایل') + ': ' + item.title);

                var $thumbBody = $('<span class="mm-preview-file-body"></span>');
                $thumbBody.append(lucide(info.icon, 'mm-ico mm-ico-previewfile'));
                $thumbBody.append($('<span class="mm-preview-file-ext"></span>').text('.' + (extOf(item.url) || 'file')));
                $thumb.append($thumbBody);

                $thumb.on('click', function () {
                    window.open(item.resolved, '_blank', 'noopener');
                    return false;
                });
            }

            var $body = $('<div class="mm-tab-preview-body"></div>');
            $('<span class="mm-tab-preview-name"></span>').text(item.title).appendTo($body);
            $('<span class="mm-tab-preview-url"></span>')
                .text(item.resolved)
                .attr('title', item.resolved)
                .appendTo($body);

            var $tools = $('<span class="mm-tab-preview-tools"></span>');

            /*
             * «درج در مطلب» و «حذف از لیست» برای همه آیتم‌ها (پیوست واقعی
             * یا فقط‌متنی).
             *
             * نکته‌ی نسخه‌ی ۱.۸.۴: دکمه‌ی «پیش‌نمایش» حذف شد و دکمه‌ی
             * «حذف پیوست» (انتقال به سطل) با دکمه‌ی ضربدر «حذف از لیست»
             * جایگزین شد. دکمه‌ی جدید فقط آیتم را از فهرست پیوست‌های پست
             * فعلی برمی‌دارد (input مخفی attachment[] را از فرم حذف می‌کند)
             * و فایل فیزیکی و رکورد دیتابیس دست‌نخورده باقی می‌ماند.
             *
             * نکته‌ی نسخه‌ی ۱.۸.۴ (اصلاح دوم): دکمه‌های «درج در متن» و
             * «حذف از لیست» اکنون برای **همه** آیتم‌ها (حتی تصاویر فقط‌متنی
             * که cid ندارند) ساخته می‌شوند. برای آیتم‌های فقط‌متنی:
             *  - «درج در متن»: آیتم دوباره در موقعیت مکان‌نما درج می‌شود
             *  - «حذف از لیست»: URL آیتم از متن پست پاک می‌شود (نه از
             *    دیتابیس)؛ پیش‌نمایش پس از تازه‌سازی، دیگر آن آیتم را
             *    نشان نمی‌دهد.
             */
            var $insBtn = $('<button type="button" class="mm-tab-preview-btn"></button>')
                .attr('title', strings.insert || 'درج در متن')
                .attr('aria-label', (strings.insert || 'درج در متن') + ': ' + item.title);
            $insBtn.append(lucide('corner-down-left', 'mm-ico mm-ico-sm'));
            $insBtn.on('click', function () {
                insertItemIntoPost(item);
                return false;
            });
            $tools.append($insBtn);

            var $copy = $('<button type="button" class="mm-tab-preview-btn"></button>')
                .attr('title', strings.copy || 'کپی لینک')
                .attr('aria-label', (strings.copy || 'کپی لینک') + ': ' + item.title);
            $copy.append(lucide('copy', 'mm-ico mm-ico-sm'));
            $copy.on('click', function () {
                copyText(item.resolved).then(function (ok) {
                    toast(ok ? (strings.copied || 'لینک کپی شد') : (strings.copyFailed || 'کپی ناموفق'), ok ? 'success' : 'error');
                });
                return false;
            });
            $tools.append($copy);

            /*
             * دکمه‌ی ضربدر «حذف از لیست» — برای همه آیتم‌ها:
             *  - پیوست واقعی (cid>0): input مخفی attachment[] را از فرم
             *    حذف و ردیف #file-list را می‌پاکد. فایل دست‌نخورده می‌ماند.
             *  - آیتم فقط‌متنی (cid=0): URL را از متن پست پاک می‌کند؛
             *    پیش‌نمایش پس از تازه‌سازی، دیگر آن را نشان نمی‌دهد.
             */
            var $removeBtn = $('<button type="button" class="mm-tab-preview-btn mm-tab-preview-remove"></button>')
                .attr('title', strings.removeFromList || 'حذف از لیست')
                .attr('aria-label', (strings.removeFromList || 'حذف از لیست') + ': ' + item.title);
            $removeBtn.append(lucide('x', 'mm-ico mm-ico-sm'));
            $removeBtn.on('click', function () {
                removeFromList(item);
                return false;
            });
            $tools.append($removeBtn);

            $row.append($thumb).append($body).append($tools);
            $list.append($row);
        });

        /*
         * دکمه‌ی «و N مورد دیگر» / «نمایش کمتر» — با کلیک، بقیه‌ی ردیف‌ها
         * بدون رفرش باز یا بسته می‌شوند؛ فوکوس برای کاربران کیبورد حفظ می‌شود.
         */
        if (items.length > TAB_PREVIEW_MAX) {
            var $more = $('<button type="button" class="mm-tab-preview-more"></button>')
                .attr('aria-expanded', tabPreviewExpanded ? 'true' : 'false')
                .attr('aria-controls', 'mm-tab-preview-list');

            if (tabPreviewExpanded) {
                $more.attr('title', strings.tabPreviewLess || 'نمایش کمتر');
                $more.append($('<span class="mm-tab-preview-more-text"></span>')
                    .text(strings.tabPreviewLess || 'نمایش کمتر'));
                $more.append(lucide('chevron-up', 'mm-ico mm-ico-sm'));
            } else {
                var moreText = String(strings.tabPreviewMore || 'و %s مورد دیگر…')
                    .replace('%s', faNum(items.length - TAB_PREVIEW_MAX));
                $more.attr('title', moreText);
                $more.append($('<span class="mm-tab-preview-more-text"></span>').text(moreText));
                $more.append(lucide('chevron-down', 'mm-ico mm-ico-sm'));
            }

            $more.on('click', function () {
                tabPreviewExpanded = !tabPreviewExpanded;
                renderTabPreview();
                /* رندر دوباره، دکمه‌ی تازه می‌سازد — فوکوس را روی همان نگه می‌داریم */
                $tabPreview.find('.mm-tab-preview-more').first().trigger('focus');
                return false;
            });

            $list.append($more);
        }
    }

    /* ---------- C) انتخابگر رسانه (مرور پوشه‌ای / کتابخانه) ---------- */

    function buildPicker() {
        var canBrowse = !!cfg.canBrowse;

        var $picker = $(
            '<div class="mm-picker" id="mm-picker" hidden role="dialog" aria-modal="true">' +
            '<div class="mm-picker-backdrop"></div>' +
            '<div class="mm-picker-box">' +
            '<header class="mm-picker-head"><strong class="mm-picker-title"></strong>' +
            '<button type="button" class="mm-modal-close" title="' + (strings.close || 'بستن') + '"></button></header>' +
            '<div class="mm-picker-search">' +
            '<input type="text" class="mm-picker-keywords" placeholder="">' +
            '<button type="button" class="btn btn-s mm-picker-search-btn"></button>' +
            '<button type="button" class="btn btn-s mm-picker-upload-btn" title="' + (strings.uploadFiles || 'بارگذاری فایل') + '"></button>' +
            '</div>' +
            '<div class="mm-picker-filters" role="group" aria-label="' + (strings.filters || 'نوع فایل') + '"></div>' +
            '<div class="mm-picker-crumbs" hidden>' +
            '<button type="button" class="btn btn-s mm-picker-up"></button>' +
            '<ol class="mm-picker-crumbs-list"></ol>' +
            '<button type="button" class="btn btn-s mm-picker-upload-btn mm-picker-upload-folder"></button>' +
            '<button type="button" class="btn btn-s mm-picker-newfolder-btn"></button>' +
            '</div>' +
            '<form class="mm-picker-newfolder" hidden autocomplete="off">' +
            '<input type="text" class="mm-picker-newfolder-name" maxlength="96" autocomplete="off" spellcheck="false">' +
            '<button type="submit" class="btn btn-s primary mm-picker-newfolder-create"></button>' +
            '<button type="button" class="btn btn-s mm-picker-newfolder-cancel"></button>' +
            '</form>' +
            '<div class="mm-picker-body"><div class="mm-picker-grid"></div></div>' +
            '<div class="mm-picker-uploads" hidden aria-live="polite"></div>' +
            '<footer class="mm-picker-foot">' +
            '<span class="mm-picker-status"></span>' +
            '<span class="mm-picker-pages">' +
            '<button type="button" class="btn btn-s mm-picker-prev"></button>' +
            '<button type="button" class="btn btn-s mm-picker-next"></button>' +
            '</span>' +
            '<button type="button" class="btn btn-s mm-picker-copy"></button>' +
            '<button type="button" class="btn btn-s mm-picker-move" hidden></button>' +
            '<button type="button" class="btn btn-s primary mm-picker-insert"></button>' +
            '</footer>' +
            '</div></div>'
        );

        setIcon($picker.find('.mm-modal-close'), 'x', 'mm-ico');
        setIcon($picker.find('.mm-picker-search-btn'), 'search', 'mm-ico mm-ico-sm');
        setIcon($picker.find('.mm-picker-upload-btn'), 'upload', 'mm-ico mm-ico-sm');
        setIcon($picker.find('.mm-picker-up'), 'arrow-up', 'mm-ico mm-ico-sm');
        setIcon($picker.find('.mm-picker-prev'), 'chevron-right', 'mm-ico mm-ico-sm');
        setIcon($picker.find('.mm-picker-next'), 'chevron-left', 'mm-ico mm-ico-sm');

        var $newFolderBtn = $picker.find('.mm-picker-newfolder-btn');
        var $newFolderForm = $picker.find('.mm-picker-newfolder');
        var $newFolderInput = $picker.find('.mm-picker-newfolder-name');

        if (canBrowse) {
            setIcon($newFolderBtn, 'folder-plus', 'mm-ico mm-ico-sm');
            $newFolderBtn
                .attr('aria-label', strings.newFolder || 'پوشه جدید')
                .attr('title', strings.newFolder || 'پوشه جدید');
            $newFolderInput.attr('placeholder', strings.folderNamePh || 'نام پوشه جدید…');
            $picker.find('.mm-picker-newfolder-create').text(strings.createFolder || 'ایجاد پوشه');
            $picker.find('.mm-picker-newfolder-cancel').text(strings.cancelNewFolder || 'انصراف');

            // بارگذاری از دکمه‌ی نوار مسیر انجام می‌شود (با زمینه‌ی پوشه‌ی جاری)؛
            // دکمه‌ی تکراری نوار جستجو حذف می‌شود
            $picker.find('.mm-picker-search .mm-picker-upload-btn').remove();
            $picker.find('.mm-picker-crumbs .mm-picker-upload-btn')
                .attr('aria-label', strings.uploadHere || 'بارگذاری فایل در همین پوشه')
                .attr('title', strings.uploadHere || 'بارگذاری فایل در همین پوشه');
        } else {
            $newFolderBtn.remove();
            $newFolderForm.remove();

            // نوار مسیر برای نقش‌های پایین‌تر مخفی است؛ دکمه‌ی نوار جستجو می‌ماند
            $picker.find('.mm-picker-crumbs .mm-picker-upload-btn').remove();
        }

        $picker.find('.mm-picker-title').text(strings.pickerTitle || 'کتابخانه رسانه');
        $picker.find('.mm-picker-search-btn').attr('aria-label', strings.pickerSearch || 'جستجو');
        $picker.find('.mm-picker-up').attr('aria-label', 'پوشه بالاتر').attr('title', 'پوشه بالاتر');
        $picker.find('.mm-picker-prev').attr('aria-label', 'صفحه قبل').attr('title', 'صفحه قبل');
        $picker.find('.mm-picker-next').attr('aria-label', 'صفحه بعد').attr('title', 'صفحه بعد');
        $picker.find('.mm-picker-copy').text(strings.copyLinksOf || 'کپی لینک‌ها');
        $picker.find('.mm-picker-insert').text(strings.insertSelected || 'درج در متن');
        $picker.find('.mm-picker-keywords')
            .attr('placeholder', canBrowse
                ? (strings.pickerSearchFolder || 'جستجو در این پوشه…')
                : (strings.pickerSearch || 'جستجوی نام فایل…'));

        // ورودی مخفی انتخاب فایل برای بارگذاری از خود انتخابگر
        var $fileInput = $('<input type="file" id="mm-picker-file-input" multiple hidden>').appendTo($picker);
        var $uploadsList = $picker.find('.mm-picker-uploads');
        $picker.appendTo('body');

        var state = {
            path: '',
            page: 1,
            total: 0,
            pageSize: 24,
            items: [],
            folders: [],
            breadcrumbs: [],
            parentPath: null,
            selected: {},
            kind: ''
        };
        var requestSeq = 0;

        /*
         * پوشه‌ی نشست جاری: آخرین پوشه‌ی باز‌شده‌ی انتخابگر در
         * «sessionStorage» (نه localStorage). تعریف کلیدها و ابزارهای
         * نشست در سطح IIFE است (بالا) تا راه‌انداز صفحه هم به آن‌ها دسترسی
         * داشته باشد. مقدار قدیمی localStorage هم یک بار پاک می‌شود تا از
         * نسخه‌های قبلی به ارث نرسد.
         */
        var pathFallbackTried = false;

        function loadStoredFolder() {
            if (!canBrowse) {
                return '';
            }

            try {
                // پاک‌سازی مقدار ماندگار نسخه‌های پیشین (فقط بار اول)
                try {
                    window.localStorage.removeItem(FOLDER_STORE_KEY);
                } catch (e) {
                    /* بی‌خطر */
                }

                var stored = window.sessionStorage.getItem(FOLDER_STORE_KEY);
                stored = String(stored || '').trim();
                return stored === '' ? '' : stored;
            } catch (e) {
                return '';
            }
        }

        function storeCurrentFolder() {
            if (!canBrowse) {
                return;
            }

            try {
                window.sessionStorage.setItem(FOLDER_STORE_KEY, String(state.path || ''));
            } catch (e) {
                /* حافظه‌ی نشست در دسترس نیست؛ فقط همین دیالوگ معتبر است */
            }
        }

        /*
         * پوشه‌ی فرود آخرین آپلود موفق — در «sessionStorage» با کلیدی مستقل
         * از پوشه‌ی مرور نگه داشته می‌شود تا نه فقط در باز شدن دوباره‌ی
         * انتخابگر، بلکه در ورود تازه به پنل کتابخانه (در همان تب مرورگر)
         * هم مسیرِ واقعی فایل‌های تازه نشان داده شود. با شروع «نشست تازه‌ی»
         * ویرایشگر (باز کردن ادیتور پس از بستن قبلی) پاک می‌شود و مسیر
         * رسانه به ریشه‌ی Uploads بازمی‌گردد (نگاهی به isFreshEditorSession).
         * عمر فرود ۱۰ دقیقه است (LANDED_TTL_MS) — پس از آن فرود کهنه
         * بی‌اثر و پاک می‌شود. ثبتِ فرود (recordLandedFolder) در سطح IIFE
         * است تا آپلودهای بیرون از انتخابگر هم به آن دسترسی داشته باشند.
         */
        function loadLandedFolder() {
            if (!canBrowse) {
                return '';
            }

            var landed = readSessionValue(LANDED_STORE_KEY);
            if (landed === '') {
                return '';
            }

            var stamp = parseInt(readSessionValue(LANDED_STAMP_KEY), 10);
            if (isNaN(stamp) || stamp <= 0 || (Date.now() - stamp) > LANDED_TTL_MS) {
                removeSessionValue(LANDED_STORE_KEY);
                removeSessionValue(LANDED_STAMP_KEY);
                return '';
            }

            return landed;
        }

        /**
         * پوشه‌ی آخرین پیوست واقعی این پست (از فهرست پیوست‌های هسته) —
         * برای تعیین پوشه‌ی شروع انتخابگر وقتی نه پوشه‌ی مرور و نه فرود
         * آپلودی در کار است؛ مثلاً وقتی فایل از ادیتور جانشین (بیرون از
         * مدیامنجر) بارگذاری و به پست پیوند خورده است. آخرین پیوستِ دارای
         * پوشه برنده می‌شود؛ فایل ریشه‌ای ترجیحی ایجاد نمی‌کند.
         */
        function latestAttachmentFolder() {
            if (!canBrowse) {
                return '';
            }

            var folder = '';
            $('#file-list li').each(function () {
                var $li = $(this);
                if ($li.hasClass('loading')) {
                    return;
                }
                var url = String($li.attr('data-url') || '');
                if (!url) {
                    return;
                }
                var landed = folderOfUrl(url);
                if (landed !== null && landed !== '') {
                    folder = String(landed);
                }
            });

            return folder;
        }

        /**
         * مسیر شروع انتخابگر (اولویت‌دار):
         *   ۱) پوشه‌ی مرورشده در همین نشست ویرایشگر؛
         *   ۲) پوشه‌ی فرود آخرین آپلود همین نشست (حتی از پنل کتابخانه)؛
         *   ۳) آپلود/درج تازه‌ی بیرون از انتخابگر (چسباندن در خود ویرایشگر،
         *      تب پیوست‌های هسته و…) — از #file-list یا متن نوشته؛
         *   ۴) چسباندنِ فایل در همین صفحه + کوکی راهنمای سرور (هوک upload
         *      برای هر آپلود موفق می‌نویسد — حتی آپلود ادیتور جانشین)؛
         *   ۵) نشست تازه‌ی ویرایشگر → ریشه‌ی uploads (تنظیم کاربر)؛
         *   ۶) پوشه‌ی آخرین پیوست همین پست؛
         *   ۷) ریشه.
         * بدین ترتیب تا وقتی فایل تازه‌ای در همین نشست فرود آمده — از هر
         * مسیری — کتابخانه از مسیرِ واقعی همان فایل شروع می‌شود؛ اما با
         * شروع نشست تازه (بستن ادیتور و باز کردن دوباره) همیشه از ریشه‌ی
         * uploads شروع می‌شود.
         */
        function initialPickerPath() {
            if (!canBrowse) {
                return '';
            }

            var stored = loadStoredFolder();
            if (stored !== '') {
                return stored;
            }

            var landed = loadLandedFolder();
            if (landed !== '') {
                return landed;
            }

            /*
             * آپلود/درج تازه‌ی بیرون از انتخابگر — مسیر واقعی فایل تازه بر
             * «نشست تازه» مقدم است: «کتابخانه از جایی باز شود که فایل‌ها
             * هستند».
             */
            var fresh = scanFreshUploadFolder();
            if (fresh !== '') {
                recordLandedFolder(fresh);
                return fresh;
            }

            // چسباندنِ فایل در همین صفحه + کوکی راهنمای سرور (هوک upload)
            if (readAwaitLanded()) {
                var awaited = readLandedCookie();
                if (awaited !== '') {
                    recordLandedFolder(awaited);
                    return awaited;
                }
            }

            // نشست تازه‌ی ویرایشگر: شروع همیشه از ریشه‌ی uploads
            if (readSessionValue(FRESH_ROOT_KEY) === '1') {
                return '';
            }

            return latestAttachmentFolder();
        }

        /* ---------- بارگذاری فایل از خود انتخابگر ---------- */

        var uploadQueue = [];
        var uploadInFlight = false;
        var uploadDone = 0;

        /*
         * پوشه‌ی فرود آخرین فایل موفق — پس از پایان صف، اگر با پوشه‌ی جاری
         * انتخابگر فرق داشته باشد، انتخابگر خودکار به همان پوشه باز می‌شود
         * (مثلاً آپلود در ریشه بدون هدف‌گذاری → مسیر تاریخ‌محور پیش‌فرض).
         */
        var uploadLandedFolder = null;

        function allowedUploadExt(name) {
            var match = String(name).match(/\.([a-z0-9]+)$/i);
            if (!match) {
                return false;
            }
            var ext = match[1].toLowerCase();
            return Array.isArray(cfg.uploadTypes) && cfg.uploadTypes.indexOf(ext) !== -1;
        }

        function uploadRow(file) {
            var $row = $('<div class="mm-picker-upload-row mm-picker-upload-uploading"></div>');
            $('<span class="mm-picker-spin"></span>').appendTo($row);
            $('<span class="mm-picker-upload-name"></span>').text(file.name).appendTo($row);
            $('<span class="mm-picker-upload-status"></span>')
                .text(strings.uploading || 'در حال بارگذاری…')
                .appendTo($row);
            return $row;
        }

        function markUploadRow($row, state, message) {
            $row.removeClass('mm-picker-upload-uploading')
                .addClass(state === 'done' ? 'mm-picker-upload-done' : 'mm-picker-upload-error');
            setIcon($row.find('.mm-picker-spin'), state === 'done' ? 'check' : 'x', 'mm-ico mm-ico-sm');
            $row.find('.mm-picker-upload-status').text(String(message || ''));
        }

        function showUploadsList() {
            $uploadsList.prop('hidden', false).removeAttr('hidden');
        }

        function scheduleUploadsCleanup() {
            if (uploadQueue.length > 0 || uploadInFlight) {
                return;
            }

            setTimeout(function () {
                if (uploadQueue.length === 0 && !uploadInFlight) {
                    $uploadsList.prop('hidden', true).empty();
                }
            }, 6000);
        }

        function processUploadQueue() {
            if (uploadInFlight) {
                return;
            }

            var next = uploadQueue.shift();
            if (!next) {
                if (uploadDone > 0) {
                    /*
                     * پایان صف: اگر فایل‌ها خارج از پوشه‌ی جاری انتخابگر فرود
                     * آمده‌اند (مثل مسیر تاریخ‌محور پیش‌فرض)، انتخابگر خودکار
                     * به همان پوشه‌ی فرود باز می‌شود تا کاربر مسیر را دستی
                     * مرور نکند. فیلتر نوع هم بازنشانی می‌شود تا فایل تازه —
                     * هر نوعی که باشد — حتماً در فهرست دیده شود.
                     */
                    var navigateTo = canBrowse && uploadLandedFolder !== null
                        && String(uploadLandedFolder) !== String(state.path || '')
                        ? uploadLandedFolder
                        : null;

                    uploadDone = 0;
                    uploadLandedFolder = null;
                    state.page = 1;
                    $picker.find('.mm-picker-keywords').val('');

                    if (navigateTo !== null) {
                        state.path = navigateTo;
                        state.kind = '';
                        state.selected = {};
                        renderFilters();
                    }

                    fetchItems();
                }
                scheduleUploadsCleanup();
                return;
            }

            uploadInFlight = true;

            var data = new FormData();
            data.append('file', next.file);

            // هدف‌گذاری پوشه: ویراستار/مدیر داخل زیرپوشه → همان پوشه (هوک سمت سرور)
            if (canBrowse && String(state.path || '') !== '') {
                data.append('mm_folder', String(state.path));
            }

            fetch(cfg.uploadUrl, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json'
                },
                body: data
            }).then(function (response) {
                return response.json().catch(function () {
                    return null;
                }).then(function (payload) {
                    if (!response.ok || !Array.isArray(payload)) {
                        throw new Error(payload && payload.message ? payload.message : null);
                    }
                    return payload;
                });
            }).then(function (payload) {
                // قالب پاسخ هسته: [url, {cid, title, type, size, bytes, isImage, url, permalink}]
                var attachment = payload[1] || {};
                uploadDone++;

                // ثبت فایل به‌عنوان پیوست همین پست — همان رفتار آپلودر
                // خود هسته (فهرست پیوست‌ها + شمارنده‌ی تب + ارسال cid در
                // فرم نوشتن)؛ پیش‌نمایش‌ها هم همان لحظه تازه می‌شوند
                attachToPost(attachment);

                var status = strings.uploaded || 'بارگذاری شد';

                if (canBrowse) {
                    var landed = folderOfUrl(attachment.url);
                    if (landed !== null) {
                        // برای بازکردن خودکار پس از پایان صف ثبت می‌شود
                        uploadLandedFolder = String(landed);

                        /*
                         * نشست‌محور: دفعه‌ی بعد که کتابخانه (انتخابگر یا
                         * پنل) باز شود، از همین پوشه‌ی فرود شروع می‌شود —
                         * حتی اگر انتخابگر پیش از پایان صف بسته شده باشد.
                         * (recordLandedFolder هر دو کلید فرود و مرور را
                         * می‌نویسد و نشانگر «نشست تازه» را هم برمی‌دارد.)
                         */
                        recordLandedFolder(landed);

                        if (String(landed) !== String(state.path || '')) {
                            status += ' — ' + (strings.uploadToFolder || 'ذخیره شد در') + ': ' + landed;
                        }
                    }
                }

                markUploadRow(next.$row, 'done', status);
            }).catch(function (error) {
                markUploadRow(next.$row, 'error', error && error.message
                    ? error.message
                    : (strings.uploadError || 'بارگذاری ناموفق بود'));
            }).then(function () {
                uploadInFlight = false;
                processUploadQueue();
            });
        }

        function enqueueUploads(fileList) {
            var files = Array.prototype.slice.call(fileList || []);
            if (!files.length) {
                return;
            }

            showUploadsList();

            files.forEach(function (file) {
                var $row = uploadRow(file).appendTo($uploadsList);

                if (cfg.maxSize > 0 && file.size > cfg.maxSize) {
                    markUploadRow($row, 'error', strings.uploadErrorSize || 'حجم فایل بیش از حد مجاز سرور است');
                    return;
                }

                if (!allowedUploadExt(file.name)) {
                    markUploadRow($row, 'error', strings.uploadErrorType || 'این پسوند فایل مجاز نیست');
                    return;
                }

                uploadQueue.push({ file: file, $row: $row });
            });

            processUploadQueue();
        }

        // دکمه‌ی بارگذاری (نوار مسیر برای مرور پوشه‌ای / نوار جستجو برای بقیه)
        $picker.find('.mm-picker-upload-btn').on('click', function () {
            $fileInput.trigger('click');
            return false;
        });

        $fileInput.on('change', function () {
            enqueueUploads(this.files);
            $fileInput.val('');
        });

        // کشیدن و رها کردن فایل روی انتخابگر
        $picker.find('.mm-picker-box').on({
            dragenter: function () {
                $(this).addClass('mm-picker-dragover');
            },
            dragover: function (e) {
                e.preventDefault();
                e.stopPropagation();
                $(this).addClass('mm-picker-dragover');
            },
            dragleave: function (e) {
                e.preventDefault();
                $(this).removeClass('mm-picker-dragover');
            },
            drop: function (e) {
                e.preventDefault();
                e.stopPropagation();
                $(this).removeClass('mm-picker-dragover');
                enqueueUploads(e.originalEvent.dataTransfer.files);
            }
        });

        // بارگذاری با چسباندن (Ctrl+V) داخل انتخابگر — وقتی ورودی متنی
        // (جستجو یا نام پوشه) فعال نیست؛ فایل‌های کلیپ‌بورد وارد صف می‌شوند
        $picker.on('paste', function (e) {
            var original = e.originalEvent || e;
            var target = original.target || {};
            var tag = String(target.nodeName || '').toLowerCase();

            if (tag === 'input' || tag === 'textarea' || target.isContentEditable) {
                return;
            }

            var files = original.clipboardData && original.clipboardData.files
                ? original.clipboardData.files
                : [];
            if (!files || files.length === 0) {
                return;
            }

            e.preventDefault();
            enqueueUploads(files);
        });

        function itemKey(item) {
            return item.cid > 0 ? ('c' + item.cid) : ('p' + item.path);
        }

        function fetchItems() {
            var seq = ++requestSeq;
            var $grid = $picker.find('.mm-picker-grid');
            $grid.empty().append($('<div class="mm-picker-empty"></div>').text(strings.pickerLoading || 'در حال بارگذاری…'));

            // پوشه‌ی جاری را برای دفعه‌ی بعد ذخیره می‌کنیم (پوشه‌ی پایدار)
            storeCurrentFolder();

            var base = canBrowse ? cfg.browseUrl : cfg.pickerUrl;
            var url;
            try {
                url = new URL(base, window.location.href);
            } catch (e) {
                url = base;
            }

            if (url.searchParams) {
                url.searchParams.set('page', String(state.page));
                if (canBrowse && state.path) {
                    url.searchParams.set('path', state.path);
                }
                var keywords = String($picker.find('.mm-picker-keywords').val() || '').trim();
                if (keywords) {
                    url.searchParams.set('keywords', keywords);
                } else {
                    url.searchParams.delete('keywords');
                }

                // فیلتر نوع فایل (تصویر/ویدئو/صوت/آرشیو/اسناد) — سمت سرور اعمال می‌شود
                if (state.kind) {
                    url.searchParams.set('kind', state.kind);
                } else {
                    url.searchParams.delete('kind');
                }
            }

            fetch(String(url), {
                credentials: 'same-origin',
                headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' }
            }).then(function (response) {
                return response.json().catch(function () {
                    return null;
                }).then(function (payload) {
                    if (!response.ok || !payload || Number(payload.code) !== 200) {
                        throw new Error(payload && payload.message ? payload.message : '');
                    }
                    return payload;
                });
            }).then(function (payload) {
                if (seq !== requestSeq) {
                    return; // پاسخ قدیمی؛ نادیده گرفته می‌شود
                }

                var data = payload.data || {};
                state.items = data.files || data.items || [];
                state.folders = canBrowse ? (data.folders || []) : [];
                state.breadcrumbs = canBrowse ? (data.breadcrumbs || []) : [];
                state.parentPath = canBrowse ? (data.parentPath === undefined ? null : data.parentPath) : null;
                state.total = data.totalFiles !== undefined ? data.totalFiles : (data.total || 0);
                state.pageSize = data.pageSize || 24;
                state.selected = {};

                renderCrumbs();
                renderItems();
            }).catch(function (error) {
                if (seq !== requestSeq) {
                    return;
                }

                // پوشه‌ی ذخیره‌شده دیگر وجود ندارد (مثلاً حذف شده) → یک بار به ریشه برمی‌گردیم
                if (canBrowse && !pathFallbackTried && String(state.path || '') !== '') {
                    pathFallbackTried = true;
                    state.path = '';
                    state.page = 1;
                    fetchItems();
                    return;
                }

                var $g = $picker.find('.mm-picker-grid');
                $g.empty().append($('<div class="mm-picker-empty"></div>').text(
                    (error && error.message) ? error.message : (strings.pickerError || 'خطا در دریافت فهرست')
                ));
            });
        }

        /** نوار مسیر (breadcrumb) پوشه‌ی جاری */
        function renderCrumbs() {
            var $crumbs = $picker.find('.mm-picker-crumbs');
            var $list = $picker.find('.mm-picker-crumbs-list');

            if (!canBrowse) {
                $crumbs.prop('hidden', true);
                return;
            }

            $crumbs.prop('hidden', false);
            $list.empty();

            state.breadcrumbs.forEach(function (crumb, index) {
                var $li = $('<li class="mm-picker-crumb"></li>');
                var isLast = index === state.breadcrumbs.length - 1;

                if (index === 0) {
                    $li.append(lucide('hard-drive', 'mm-ico mm-ico-sm'));
                }

                var $name = isLast
                    ? $('<span class="mm-picker-crumb-name" aria-current="page"></span>').text(crumb.name)
                    : $('<button type="button" class="mm-picker-crumb-name"></button>').text(crumb.name);

                if (!isLast) {
                    $name.on('click', function () {
                        state.path = String(crumb.path || '');
                        state.page = 1;
                        fetchItems();
                    });
                }

                $li.append($name);
                $list.append($li);
            });

            $picker.find('.mm-picker-up').prop('disabled', state.parentPath === null);
        }

        /* ---------- فیلتر نوع فایل (چیپ‌ها) ---------- */

        var FILTER_LABELS = cfg.filterLabels || { all: 'همه' };

        function renderFilters() {
            var $row = $picker.find('.mm-picker-filters');
            $row.empty();

            Object.keys(FILTER_LABELS).forEach(function (key) {
                var active = state.kind === key || (state.kind === '' && key === 'all');
                var $chip = $('<button type="button" class="mm-filter-chip"></button>')
                    .toggleClass('is-active', active)
                    .attr('aria-pressed', active ? 'true' : 'false')
                    .text(String(FILTER_LABELS[key]));

                $chip.on('click', function () {
                    state.kind = key === 'all' ? '' : key;
                    state.page = 1;
                    renderFilters();
                    fetchItems();
                });

                $row.append($chip);
            });
        }

        function renderItems() {
            var $grid = $picker.find('.mm-picker-grid');
            var $status = $picker.find('.mm-picker-status');
            $grid.empty();

            // کاشی پوشه‌ها (فقط حالت مرور پوشه‌ای)
            if (state.folders.length > 0) {
                var $folders = $('<div class="mm-picker-folders"></div>');
                state.folders.forEach(function (folder) {
                    var folderPath = (state.path === '' ? '' : state.path + '/') + folder.name;

                    var $f = $('<div class="mm-picker-folder"></div>')
                        .attr('data-path', folderPath)
                        .attr('data-name', folder.name)
                        .attr('title', folder.name);

                    var $main = $('<button type="button" class="mm-picker-folder-main"></button>');
                    $main.append(lucide('folder', 'mm-ico mm-ico-lg'));
                    var $body = $('<span class="mm-picker-folder-body"></span>');
                    $('<span class="mm-picker-folder-name"></span>').text(folder.name).appendTo($body);
                    $('<span class="mm-picker-folder-count"></span>').text(faNum(folder.files) + ' ' + (strings.file || 'فایل')).appendTo($body);
                    $main.append($body);
                    $main.append(lucide('chevron-left', 'mm-ico mm-ico-sm'));

                    $main.on('click', function () {
                        state.path = folderPath;
                        state.page = 1;
                        fetchItems();
                    });

                    $f.append($main);

                    if (canBrowse) {
                        var $tools = $('<span class="mm-picker-folder-tools"></span>');

                        var $renameBtn = $('<button type="button" class="mm-picker-folder-tool mm-picker-folder-rename"></button>')
                            .attr('type', 'button')
                            .attr('title', strings.renameFolder || 'تغییر نام پوشه')
                            .attr('aria-label', (strings.renameFolder || 'تغییر نام پوشه') + ': ' + folder.name);
                        $renameBtn.append(lucide('pencil', 'mm-ico mm-ico-sm'));
                        $renameBtn.on('click', function () {
                            openRenameDialog(folderPath, folder.name);
                            return false;
                        });
                        $tools.append($renameBtn);

                        var $deleteBtn = $('<button type="button" class="mm-picker-folder-tool mm-picker-folder-delete"></button>')
                            .attr('title', strings.deleteFolder || 'حذف پوشه')
                            .attr('aria-label', (strings.deleteFolder || 'حذف پوشه') + ': ' + folder.name);
                        $deleteBtn.append(lucide('trash-2', 'mm-ico mm-ico-sm'));
                        $deleteBtn.on('click', function () {
                            deleteFolder(folderPath, folder.name);
                            return false;
                        });
                        $tools.append($deleteBtn);

                        $f.append($tools);
                    }

                    $folders.append($f);
                });
                $grid.append($folders);
            }

            if (!state.items.length && !state.folders.length) {
                $grid.append($('<div class="mm-picker-empty"></div>').text(strings.pickerEmpty || 'هیچ فایلی یافت نشد'));
                $status.text('');
                return;
            }

            var $files = $('<div class="mm-picker-files"></div>');
            state.items.forEach(function (item) {
                var $it = $('<figure class="mm-picker-item"></figure>');
                $it.attr({
                    'data-cid': item.cid,
                    'data-url': item.url,
                    'data-title': item.title,
                    'data-image': item.isImage ? '1' : '0'
                });

                var $thumb = $('<div class="mm-picker-thumb"></div>');
                if (item.isImage) {
                    $('<img>').attr({
                        src: resolveUrl(item.url),
                        alt: item.title,
                        loading: 'lazy',
                        decoding: 'async'
                    }).appendTo($thumb);
                } else {
                    var info = kindOf(item.type || extOf(item.url));
                    var $body = $('<span class="mm-picker-filebody"></span>')
                        .addClass('mm-kind-' + info.kind)
                        .attr('title', info.label);
                    $body.append(lucide(info.icon, 'mm-ico mm-ico-pickerfile'));
                    $body.append($('<span class="mm-picker-ext"></span>').text('.' + (item.type || extOf(item.url) || 'file')));
                    $thumb.append($body);
                }
                $it.append($thumb);

                $('<span class="mm-picker-name"></span>').text(item.title).appendTo($it);
                $('<span class="mm-picker-check" aria-hidden="true"></span>').appendTo($it);

                // تغییر نام فایل (ابزار گوشه‌ی کاشی) — انتخاب را تریگر نمی‌کند
                var $fileRename = $('<button type="button" class="mm-picker-item-tool mm-picker-item-rename"></button>')
                    .attr('title', strings.renameFile || 'تغییر نام فایل')
                    .attr('aria-label', (strings.renameFile || 'تغییر نام فایل') + ': ' + (item.title || ''));
                $fileRename.append(lucide('pencil', 'mm-ico mm-ico-sm'));
                $fileRename.on('click', function (e) {
                    e.stopPropagation();
                    e.preventDefault();
                    openFileRename(item);
                    return false;
                });
                $it.append($fileRename);

                $it.on('click', function () {
                    var key = itemKey(item);
                    if (state.selected[key]) {
                        delete state.selected[key];
                        $it.removeClass('mm-selected');
                    } else {
                        state.selected[key] = item;
                        $it.addClass('mm-selected');
                    }
                    refreshStatus();
                });

                $files.append($it);
            });
            $grid.append($files);

            refreshStatus();
        }

        function selectedList() {
            return Object.keys(state.selected).map(function (key) {
                return state.selected[key];
            });
        }

        function refreshStatus() {
            var $status = $picker.find('.mm-picker-status');
            var count = selectedList().length;
            var totalPages = Math.max(1, Math.ceil(state.total / state.pageSize));

            var parts = [];
            if (canBrowse && state.folders.length > 0) {
                parts.push(faNum(state.folders.length) + ' ' + (strings.folder || 'پوشه'));
            }
            parts.push(faNum(state.total) + ' ' + (strings.file || 'فایل'));
            if (state.total > state.pageSize) {
                parts.push(faNum(state.page) + ' / ' + faNum(totalPages));
            }
            if (count > 0) {
                parts.push('| ' + faNum(count) + ' ' + (strings.selected || 'انتخاب‌شده'));
            }
            $status.text(parts.join(' — '));

            $picker.find('.mm-picker-prev').prop('disabled', state.page <= 1);
            $picker.find('.mm-picker-next').prop('disabled', state.page >= totalPages);
        }

        function insertSelected() {
            var items = selectedList();
            if (!items.length) {
                toast(strings.pickerEmpty || 'هیچ فایلی انتخاب نشده است', 'error');
                return;
            }

            /*
             * مسیر درج مشترک با دکمه‌ی «درج در مطلب» پیش‌نمایش‌ها:
             * پل ادیتور جانشین (Negaresh) → درج در textarea. خود انتخابگر
             * فقط بستن دیالوگ و اعلان را انجام می‌دهد.
             */
            if (insertItemsIntoPost(items)) {
                closePicker();
                toast((strings.inserted || 'در متن درج شد') + ' (' + faNum(items.length) + ')', 'success');
                renderPreview();
            }
        }

        function openPicker() {
            state.page = 1;

            // پوشه‌ی شروع: پوشه‌ی مرور نشست ← فرود آخرین آپلود ← پوشه‌ی
            // آخرین پیوست همین پست ← ریشه — تا کتابخانه از مسیرِ واقعی
            // فایل‌های کاربر شروع شود، نه لزوماً از ریشه
            state.path = initialPickerPath();

            $picker.find('.mm-picker-keywords').val('');
            $picker.prop('hidden', false);
            fetchItems();
            setTimeout(function () {
                $picker.find('.mm-picker-keywords').trigger('focus');
            }, 60);
        }

        function closePicker() {
            $picker.prop('hidden', true);
        }

        $picker.on('click', '.mm-picker-backdrop, .mm-modal-close', closePicker);

        $(document).on('keydown', function (e) {
            if (e.key === 'Escape' && !$picker.prop('hidden')) {
                // اگر یکی از دیالوگ‌های داخل انتخابگر باز است، Esc فقط همان را می‌بندد
                if ($('.mm-picker-rename:not([hidden])').length > 0
                    || $('.mm-file-rename:not([hidden])').length > 0
                    || $('.mm-picker-move-dialog:not([hidden])').length > 0) {
                    return;
                }

                closePicker();
            }
        });

        $picker.find('.mm-picker-search-btn').on('click', function () {
            state.page = 1;
            fetchItems();
        });

        $picker.find('.mm-picker-keywords').on('keydown', function (e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                state.page = 1;
                fetchItems();
            }
        });

        $picker.find('.mm-picker-up').on('click', function () {
            if (state.parentPath === null) {
                return;
            }
            state.path = String(state.parentPath || '');
            state.page = 1;
            fetchItems();
        });

        /* ---------- ایجاد پوشه‌ی جدید (فقط حالت مرور پوشه‌ای) ---------- */

        function validFolderName(name) {
            name = String(name || '').trim();
            return name !== '' && name.length <= 96 && /^[\p{L}\p{N}][\p{L}\p{N} _.\-]{0,95}$/u.test(name);
        }

        function openNewFolderForm() {
            $newFolderForm.prop('hidden', false).removeAttr('hidden');
            $newFolderInput.val('').trigger('focus');
        }

        function closeNewFolderForm() {
            $newFolderForm.prop('hidden', true);
        }

        $newFolderBtn.on('click', function () {
            if ($newFolderForm.prop('hidden')) {
                openNewFolderForm();
            } else {
                closeNewFolderForm();
            }
            return false;
        });

        $picker.find('.mm-picker-newfolder-cancel').on('click', function () {
            closeNewFolderForm();
            return false;
        });

        $newFolderInput.on('keydown', function (e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                $newFolderForm.trigger('submit');
            } else if (e.key === 'Escape') {
                e.stopPropagation();
                closeNewFolderForm();
            }
        });

        $newFolderForm.on('submit', function (e) {
            e.preventDefault();

            var name = String($newFolderInput.val() || '').trim();
            if (!validFolderName(name)) {
                toast(strings.folderInvalidName || 'نام پوشه معتبر نیست', 'error');
                $newFolderInput.trigger('focus');
                return;
            }

            var $create = $picker.find('.mm-picker-newfolder-create');
            if ($create.prop('disabled')) {
                return;
            }

            var data = new FormData();
            data.append('path', String(state.path || ''));
            data.append('name', name);

            $create.prop('disabled', true);
            $newFolderInput.prop('disabled', true);

            fetch(cfg.mkdirUrl, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json'
                },
                body: data
            }).then(function (response) {
                return response.json().catch(function () {
                    return null;
                }).then(function (payload) {
                    if (!response.ok || !payload || Number(payload.code) !== 200) {
                        throw new Error(payload && payload.message ? payload.message : '');
                    }
                    return payload;
                });
            }).then(function (payload) {
                closeNewFolderForm();
                toast(strings.folderCreated || 'پوشه ساخته شد.', 'success');
                state.path = String(payload.data && payload.data.path || '');
                state.page = 1;
                $picker.find('.mm-picker-keywords').val('');
                fetchItems();
            }).catch(function (error) {
                toast(error && error.message ? error.message : (strings.mkdirError || 'ایجاد پوشه ناموفق بود'), 'error');
            }).then(function () {
                $create.prop('disabled', false);
                $newFolderInput.prop('disabled', false);
            });
        });

        /* ---------- تغییر نام و حذف پوشه (فقط حالت مرور پوشه‌ای) ---------- */

        /** دیالوگ کوچک تغییر نام پوشه */
        var $renameDialog = null;

        function ensureRenameDialog() {
            if ($renameDialog !== null) {
                return $renameDialog;
            }

            $renameDialog = $(
                '<div class="mm-modal mm-picker-rename" hidden role="dialog" aria-modal="true">' +
                '<div class="mm-modal-backdrop"></div>' +
                '<div class="mm-modal-box mm-rename-box">' +
                '<header class="mm-modal-head"><strong class="mm-modal-title"></strong>' +
                '<button type="button" class="mm-modal-close" title="' + (strings.close || 'بستن') + '"></button></header>' +
                '<form class="mm-modal-body mm-rename-body" autocomplete="off">' +
                '<p class="mm-rename-hint"></p>' +
                '<label class="sr-only">نام جدید پوشه</label>' +
                '<input type="text" class="mm-rename-input" maxlength="96" autocomplete="off" spellcheck="false">' +
                '</form>' +
                '<footer class="mm-modal-foot">' +
                '<button type="button" class="btn btn-s mm-rename-cancel"></button>' +
                '<button type="button" class="btn btn-s primary mm-rename-save"></button>' +
                '</footer>' +
                '</div></div>'
            );

            setIcon($renameDialog.find('.mm-modal-close'), 'x', 'mm-ico');
            $renameDialog.find('.mm-modal-title').text(strings.renameFolder || 'تغییر نام پوشه');
            $renameDialog.find('.mm-rename-cancel').text(strings.renameCancel || 'انصراف');
            $renameDialog.find('.mm-rename-save').text(strings.renameSave || 'ذخیره');
            $renameDialog.find('.mm-rename-input').attr('placeholder', strings.folderNamePh || 'نام جدید پوشه…');
            $renameDialog.appendTo('body');

            $renameDialog.on('click', '.mm-modal-backdrop, .mm-modal-close, .mm-rename-cancel', function () {
                $renameDialog.prop('hidden', true);
                return false;
            });

            $(document).on('keydown', function (e) {
                if (e.key === 'Escape' && !$renameDialog.prop('hidden')) {
                    $renameDialog.prop('hidden', true);
                }
            });

            return $renameDialog;
        }

        function openRenameDialog(folderPath, folderName) {
            var $dlg = ensureRenameDialog();
            var hint = String(strings.renameFolderHint || 'نام جدید پوشه «%s» را وارد کنید:');

            $dlg.find('.mm-rename-hint').text(hint.replace('%s', folderName));
            $dlg.attr('data-path', folderPath);
            $dlg.find('.mm-rename-input').val(folderName);
            $dlg.prop('hidden', false);

            setTimeout(function () {
                var input = $dlg.find('.mm-rename-input')[0];
                if (input) {
                    input.focus();
                    try {
                        input.setSelectionRange(0, String(folderName).length);
                    } catch (e) { /* بی‌خطر است */ }
                }
            }, 60);
        }

        function bindRenameSave() {
            var $dlg = ensureRenameDialog();
            var $input = $dlg.find('.mm-rename-input');
            var $save = $dlg.find('.mm-rename-save');

            function submitRename() {
                if ($save.prop('disabled')) {
                    return;
                }

                var folderPath = String($dlg.attr('data-path') || '');
                var name = String($input.val() || '').trim();

                if (!validFolderName(name)) {
                    toast(strings.folderInvalidName || 'نام پوشه معتبر نیست', 'error');
                    $input.trigger('focus');
                    return;
                }

                if (folderPath === '') {
                    $dlg.prop('hidden', true);
                    return;
                }

                var data = new FormData();
                data.append('path', folderPath);
                data.append('name', name);

                $save.prop('disabled', true);
                $input.prop('disabled', true);

                postFolderAction(cfg.renameUrl, data).then(function (payload) {
                    var newPath = payload && payload.data && payload.data.path ? String(payload.data.path) : '';

                    toast(strings.renameDone || 'نام پوشه تغییر کرد.', 'success');

                    // اگر پوشه‌ی جاری همان پوشه‌ی تغییرنام‌یافته (یا داخل آن)
                    // است، مسیر جاری را به پیشوند جدید منتقل می‌کنیم
                    if (String(state.path || '') !== '' &&
                        (state.path === folderPath || String(state.path).indexOf(folderPath + '/') === 0)) {
                        state.path = newPath + String(state.path).slice(folderPath.length);
                    }

                    $dlg.prop('hidden', true);
                    state.page = 1;
                    fetchItems();
                }).catch(function (error) {
                    toast(error && error.message ? error.message : (strings.renameError || 'تغییر نام ناموفق بود'), 'error');
                }).then(function () {
                    $save.prop('disabled', false);
                    $input.prop('disabled', false);
                });
            }

            $save.on('click', submitRename);

            $dlg.find('.mm-rename-body').on('submit', function (e) {
                e.preventDefault();
                submitRename();
            });

            $input.on('keydown', function (e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    submitRename();
                } else if (e.key === 'Escape') {
                    e.stopPropagation();
                    $dlg.prop('hidden', true);
                }
            });
        }

        function deleteFolder(folderPath, folderName) {
            var confirmMsg = String(strings.deleteFolderConfirm || 'پوشه «%s» حذف شود؟').replace('%s', folderName);

            /* مودال یکدست پیام‌های حساس (mm-confirm.js) */
            mmConfirm({
                icon: 'trash-2',
                danger: true,
                title: strings.deleteFolder || 'حذف پوشه',
                message: confirmMsg,
                confirmText: strings.deleteFolderConfirmYes || 'حذف پوشه'
            }).then(function (ok) {
                if (!ok) {
                    return;
                }

                var data = new FormData();
                data.append('path', folderPath);

                postFolderAction(cfg.rmdirUrl, data).then(function () {
                    toast(strings.folderDeleted || 'پوشه حذف شد.', 'success');
                    state.page = 1;
                    fetchItems();
                }).catch(function (error) {
                    // پیام سرور (مثلاً «پوشه خالی نیست؛ ابتدا فایل‌ها را منتقل کنید») همین‌جا نمایش داده می‌شود
                    toast(error && error.message ? error.message : (strings.folderDeleteError || 'حذف پوشه ناموفق بود'), 'error');
                });
            });
        }

        if (canBrowse) {
            bindRenameSave();
        }

        renderFilters();

        /* ---------- تغییر نام فایل (عنوان کتابخانه یا نام فیزیکی) ---------- */

        var $fileRenameDialog = null;
        var fileRenameTarget = null;

        function ensureFileRenameDialog() {
            if ($fileRenameDialog !== null) {
                return $fileRenameDialog;
            }

            $fileRenameDialog = $(
                '<div class="mm-modal mm-file-rename" hidden role="dialog" aria-modal="true">' +
                '<div class="mm-modal-backdrop"></div>' +
                '<div class="mm-modal-box mm-rename-box">' +
                '<header class="mm-modal-head"><strong class="mm-modal-title"></strong>' +
                '<button type="button" class="mm-modal-close" title="' + (strings.close || 'بستن') + '"></button></header>' +
                '<form class="mm-modal-body mm-rename-body" autocomplete="off">' +
                '<p class="mm-rename-hint"></p>' +
                '<label class="sr-only">نام جدید فایل</label>' +
                '<input type="text" class="mm-rename-input" maxlength="96" autocomplete="off" spellcheck="false">' +
                '</form>' +
                '<footer class="mm-modal-foot">' +
                '<button type="button" class="btn btn-s mm-rename-cancel"></button>' +
                '<button type="button" class="btn btn-s primary mm-rename-save"></button>' +
                '</footer>' +
                '</div></div>'
            );

            setIcon($fileRenameDialog.find('.mm-modal-close'), 'x', 'mm-ico');
            $fileRenameDialog.find('.mm-modal-title').text(strings.renameFile || 'تغییر نام فایل');
            $fileRenameDialog.find('.mm-rename-cancel').text(strings.renameCancel || 'انصراف');
            $fileRenameDialog.find('.mm-rename-save').text(strings.renameSave || 'ذخیره');
            $fileRenameDialog.find('.mm-rename-input').attr('placeholder', strings.renameFile || 'نام جدید فایل…');
            $fileRenameDialog.appendTo('body');

            $fileRenameDialog.on('click', '.mm-modal-backdrop, .mm-modal-close, .mm-rename-cancel', function () {
                $fileRenameDialog.prop('hidden', true);
                fileRenameTarget = null;
                return false;
            });

            $(document).on('keydown', function (e) {
                if (e.key === 'Escape' && !$fileRenameDialog.prop('hidden')) {
                    $fileRenameDialog.prop('hidden', true);
                    fileRenameTarget = null;
                }
            });

            return $fileRenameDialog;
        }

        function openFileRename(item) {
            var $dlg = ensureFileRenameDialog();

            // ویراستار/مدیر در حالت مرور پوشه‌ای: تغییر نام فیزیکی (رکورد DB
            // همگام می‌شود)؛ سایر حالت‌ها: فقط عنوان نمایشی پیوست (cid)
            var physical = canBrowse && item.path && String(item.path) !== '';
            var current = physical ? String(item.name || item.title || '') : String(item.title || '');
            if (physical) {
                current = current.replace(/\.[a-z0-9]{1,12}$/i, '');
            }

            var hint = physical
                ? (strings.renameFileHint || 'نام جدید فایل «%s» را وارد کنید:')
                : (strings.renameFileTitleHint || 'عنوان جدید «%s» را وارد کنید:');

            $dlg.find('.mm-rename-hint').text(hint.replace('%s', String(item.title || current)));
            fileRenameTarget = { item: item, physical: physical };
            $dlg.find('.mm-rename-input').val(current);
            $dlg.prop('hidden', false);

            setTimeout(function () {
                var input = $dlg.find('.mm-rename-input')[0];
                if (input) {
                    input.focus();
                    try {
                        input.setSelectionRange(0, String(current).length);
                    } catch (e) { /* بی‌خطر است */ }
                }
            }, 60);
        }

        function submitFileRename() {
            if (!fileRenameTarget) {
                ensureFileRenameDialog().prop('hidden', true);
                return;
            }

            var $dlg = ensureFileRenameDialog();
            var $input = $dlg.find('.mm-rename-input');
            var $save = $dlg.find('.mm-rename-save');
            if ($save.prop('disabled')) {
                return;
            }

            var value = String($input.val() || '').trim();
            var data = new FormData();

            if (fileRenameTarget.physical) {
                if (!validFolderName(value)) {
                    toast(strings.renameFileInvalid || 'نام فایل معتبر نیست', 'error');
                    $input.trigger('focus');
                    return;
                }
                data.append('path', String(fileRenameTarget.item.path || ''));
                data.append('name', value);
            } else {
                if (value === '') {
                    toast(strings.renameTitleInvalid || 'عنوان جدید نمی‌تواند خالی باشد', 'error');
                    $input.trigger('focus');
                    return;
                }
                data.append('cid', String(parseInt(fileRenameTarget.item.cid, 10) || 0));
                data.append('title', value);
            }

            $save.prop('disabled', true);
            $input.prop('disabled', true);

            postFolderAction(cfg.renameFileUrl, data).then(function () {
                fileRenameTarget = null;
                $dlg.prop('hidden', true);
                toast(strings.renameFileDone || 'تغییر نام انجام شد', 'success');
                fetchItems();
            }).catch(function (error) {
                toast(error && error.message ? error.message : (strings.renameFileError || 'تغییر نام ناموفق بود'), 'error');
            }).then(function () {
                $save.prop('disabled', false);
                $input.prop('disabled', false);
            });
        }

        (function bindFileRenameSave() {
            var $dlg = ensureFileRenameDialog();
            var $input = $dlg.find('.mm-rename-input');

            $dlg.find('.mm-rename-save').on('click', submitFileRename);
            $dlg.find('.mm-rename-body').on('submit', function (e) {
                e.preventDefault();
                submitFileRename();
            });
            $input.on('keydown', function (e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    submitFileRename();
                } else if (e.key === 'Escape') {
                    e.stopPropagation();
                    $dlg.prop('hidden', true);
                    fileRenameTarget = null;
                }
            });
        }());

        /* ---------- انتقال فایل‌های انتخابی به پوشه‌ی دیگر (مرور پوشه‌ای) ---------- */

        var $moveDialog = null;

        function ensureMoveDialog() {
            if ($moveDialog !== null) {
                return $moveDialog;
            }

            $moveDialog = $(
                '<div class="mm-modal mm-picker-move-dialog" hidden role="dialog" aria-modal="true">' +
                '<div class="mm-modal-backdrop"></div>' +
                '<div class="mm-modal-box mm-move-box">' +
                '<header class="mm-modal-head"><strong class="mm-modal-title"></strong>' +
                '<button type="button" class="mm-modal-close" title="' + (strings.close || 'بستن') + '"></button></header>' +
                '<div class="mm-modal-body mm-move-body">' +
                '<p class="mm-move-summary"></p>' +
                '<ul class="mm-move-files"></ul>' +
                '<p class="mm-move-warning"></p>' +
                '<p class="mm-move-target-label"></p>' +
                '<div class="mm-move-tree" role="radiogroup" aria-label="' + (strings.moveTargetLabel || 'پوشه‌ی مقصد') + '"></div>' +
                '</div>' +
                '<footer class="mm-modal-foot">' +
                '<button type="button" class="btn btn-s mm-move-cancel"></button>' +
                '<button type="button" class="btn btn-s primary mm-move-confirm"></button>' +
                '</footer>' +
                '</div></div>'
            );

            setIcon($moveDialog.find('.mm-modal-close'), 'x', 'mm-ico');
            $moveDialog.find('.mm-modal-title').text(strings.moveTitle || 'انتقال به پوشه‌ی دیگر');
            $moveDialog.find('.mm-move-cancel').text(strings.renameCancel || 'انصراف');
            $moveDialog.find('.mm-move-confirm')
                .append(lucide('folder-input', 'mm-ico mm-ico-sm'))
                .append(document.createTextNode(strings.moveSelected || 'انتقال'));
            $moveDialog.find('.mm-move-warning')
                .text('اگر لینک این فایل‌ها داخل متن نوشته‌ها استفاده شده باشد، آدرس‌ها به‌روزرسانی نمی‌شوند و پس از انتقال باید لینک‌ها را در نوشته‌ها اصلاح کنید.');
            $moveDialog.find('.mm-move-target-label')
                .text(strings.moveTargetLabel || 'پوشه‌ی مقصد را انتخاب کنید:');
            $moveDialog.appendTo('body');

            $moveDialog.on('click', '.mm-modal-backdrop, .mm-modal-close, .mm-move-cancel', function () {
                $moveDialog.prop('hidden', true);
                return false;
            });

            $(document).on('keydown', function (e) {
                if (e.key === 'Escape' && !$moveDialog.prop('hidden')) {
                    $moveDialog.prop('hidden', true);
                }
            });

            return $moveDialog;
        }

        function buildMoveBranches(nodes) {
            var $ul = $('<ul class="mm-move-branches"></ul>');

            nodes.forEach(function (node) {
                var $li = $('<li class="mm-move-branch"></li>');
                var isRoot = String(node.path) === '';
                var isCurrent = String(node.path) === String(state.path || '');

                var $row = $('<label class="mm-move-row"></label>');
                var $radio = $('<input type="radio" name="mm-picker-move-target">').val(String(node.path));

                if (isCurrent) {
                    $radio.prop('disabled', true);
                    $li.addClass('mm-move-current');
                }

                $row.append($radio);
                $row.append(lucide(isRoot ? 'hard-drive' : 'folder', 'mm-ico mm-ico-sm'));
                $('<span class="mm-move-name"></span>')
                    .text(isRoot ? (strings.moveRootLabel || 'ریشه‌ی uploads') : String(node.name))
                    .appendTo($row);

                if (isCurrent) {
                    $('<span class="mm-move-badge"></span>')
                        .text(strings.moveCurrentLabel || 'محل فعلی')
                        .appendTo($row);
                }

                if (!isRoot) {
                    $row.attr('title', String(node.path));
                }

                $li.append($row);

                if (node.dirs && node.dirs.length > 0) {
                    $li.append(buildMoveBranches(node.dirs));
                }

                $ul.append($li);
            });

            return $ul;
        }

        function loadMoveTree() {
            var $tree = $moveDialog.find('.mm-move-tree');
            $tree.empty()
                .append($('<div class="mm-move-tree-empty"></div>')
                    .text(strings.moveLoadingTree || 'در حال دریافت پوشه‌ها…'));

            fetch(cfg.treeUrl, {
                credentials: 'same-origin',
                headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' }
            }).then(function (response) {
                return response.json().catch(function () {
                    return null;
                }).then(function (payload) {
                    if (!response.ok || !payload || Number(payload.code) !== 200) {
                        throw new Error(payload && payload.message ? payload.message : '');
                    }
                    return payload;
                });
            }).then(function (payload) {
                var tree = (payload.data && payload.data.tree) || {};
                $tree.empty().append(buildMoveBranches([{
                    name: tree.name || 'uploads',
                    path: '',
                    dirs: tree.dirs || []
                }]));

                var $first = $tree.find('input[name="mm-picker-move-target"]').not(':disabled').first();
                if ($first.length > 0) {
                    $first.prop('checked', true);
                }
            }).catch(function () {
                $tree.empty()
                    .append($('<div class="mm-move-tree-empty mm-move-tree-error"></div>')
                        .text(strings.moveTreeError || 'دریافت فهرست پوشه‌ها ناموفق بود.'));
            });
        }

        function openMoveDialog(items) {
            var $dlg = ensureMoveDialog();
            var $list = $dlg.find('.mm-move-files');

            $list.empty();
            items.slice(0, 6).forEach(function (item) {
                var name = String(item.name || item.title || '').split('/').pop() || '';
                $('<li class="mm-move-file"></li>').text(name).attr('title', name).appendTo($list);
            });

            $dlg.find('.mm-move-summary').text(faNum(items.length) + ' ' + (strings.file || 'فایل'));
            $dlg.find('.mm-move-confirm').prop('disabled', false);
            $dlg.prop('hidden', false);
            loadMoveTree();
        }

        if (canBrowse) {
            var $moveBtn = $picker.find('.mm-picker-move');
            $moveBtn.prop('hidden', false).removeAttr('hidden')
                .attr('title', strings.moveSelected || 'انتقال به پوشه')
                .attr('aria-label', strings.moveSelected || 'انتقال به پوشه');
            setIcon($moveBtn, 'folder-input', 'mm-ico mm-ico-sm');

            $moveBtn.on('click', function () {
                var items = selectedList().filter(function (item) {
                    return item && String(item.path || '') !== '';
                });

                if (items.length === 0) {
                    toast(strings.pickerEmpty || 'هیچ فایلی انتخاب نشده است', 'error');
                    return;
                }

                openMoveDialog(items);
                return false;
            });

            ensureMoveDialog().find('.mm-move-confirm').on('click', function () {
                var $dlg = ensureMoveDialog();
                var $btn = $dlg.find('.mm-move-confirm');
                if ($btn.prop('disabled')) {
                    return;
                }

                var target = String($dlg.find('input[name="mm-picker-move-target"]:checked').val() || '');
                var hasChoice = $dlg.find('input[name="mm-picker-move-target"]:checked').length > 0;

                if (!hasChoice) {
                    toast(strings.moveNoTarget || 'ابتدا پوشه‌ی مقصد را انتخاب کنید', 'error');
                    return;
                }

                if (target === String(state.path || '')) {
                    toast(strings.moveSameTarget || 'فایل‌های انتخابی همین‌جا هستند', 'error');
                    return;
                }

                var paths = selectedList()
                    .map(function (item) { return String(item.path || ''); })
                    .filter(function (path) { return path !== ''; });

                if (paths.length === 0) {
                    $dlg.prop('hidden', true);
                    return;
                }

                var data = new FormData();
                paths.forEach(function (path) {
                    data.append('paths[]', path);
                });
                data.append('target', target);

                $btn.prop('disabled', true);

                postFolderAction(cfg.moveUrl, data).then(function (payload) {
                    var result = (payload && payload.data) || {};
                    var changed = (result.moved || 0) > 0 || (result.dbUpdated || 0) > 0;
                    var message = payload && payload.message ? payload.message : (strings.moveDone || 'انتقال انجام شد');

                    toast(message, changed ? 'success' : 'error');
                    if (changed) {
                        $dlg.prop('hidden', true);
                        state.page = 1;
                        state.selected = {};
                        fetchItems();
                    }
                }).catch(function (error) {
                    toast(error && error.message ? error.message : (strings.moveError || 'انتقال ناموفق بود'), 'error');
                }).then(function () {
                    $btn.prop('disabled', false);
                });
            });
        }

        $picker.find('.mm-picker-prev').on('click', function () {
            if (state.page > 1) {
                state.page--;
                fetchItems();
            }
        });

        $picker.find('.mm-picker-next').on('click', function () {
            var totalPages = Math.max(1, Math.ceil(state.total / state.pageSize));
            if (state.page < totalPages) {
                state.page++;
                fetchItems();
            }
        });

        $picker.find('.mm-picker-insert').on('click', insertSelected);

        $picker.find('.mm-picker-copy').on('click', function () {
            var items = selectedList();
            if (!items.length) {
                toast(strings.pickerEmpty || 'هیچ فایلی انتخاب نشده است', 'error');
                return;
            }
            copyText(items.map(function (item) { return item.url; }).join('\n')).then(function (ok) {
                toast(ok ? (strings.copied || 'لینک کپی شد') : (strings.copyFailed || 'کپی ناموفق'), ok ? 'success' : 'error');
            });
        });

        return { open: openPicker, upload: enqueueUploads };
    }

    var picker = null;

    function addLibraryButtons() {
        if (!cfg.enablePicker) {
            return;
        }

        // دکمه درون برگه «پیوست‌ها»
        var $tab = $('#tab-files');
        if ($tab.length > 0) {
            if (cfg.disableSystemUpload) {
                /*
                 * کادر آپلود به‌جای دکمه‌ی ساده — وقتی «غیرفعال‌سازی آپلودر
                 * پیش‌فرض سیستم» روشن است، تب پیوست‌ها فقط همین کادر را نشان
                 * می‌دهد: کلیک → انتخابگر کتابخانه (آپلود با انتخاب پوشه)،
                 * کشیدن و رها کردن → بارگذاری مستقیم در انتخابگر.
                 */
                var $box = $(
                    '<div class="mm-upload-box" id="mm-upload-box" role="button" tabindex="0" ' +
                    'aria-label="' + (strings.uploadBoxTitle || 'آپلود فایل') + '"></div>'
                );

                $box.append(lucide('upload', 'mm-ico mm-ico-lg'));
                $('<p class="mm-upload-box-title"></p>')
                    .text(strings.uploadBoxTitle || 'آپلود فایل')
                    .appendTo($box);
                $('<p class="mm-upload-box-hint"></p>')
                    .text(strings.uploadBoxHint || 'فایل‌ها را اینجا بکشید و رها کنید، یا برای انتخاب از کتابخانه کلیک کنید')
                    .appendTo($box);

                var openUploadBox = function () {
                    if (picker) {
                        picker.open();
                    }
                };

                $box.on('click', openUploadBox);
                $box.on('keydown', function (e) {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        openUploadBox();
                    }
                });
                $box.on({
                    dragenter: function () {
                        $(this).addClass('mm-dragover');
                    },
                    dragover: function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        $(this).addClass('mm-dragover');
                    },
                    dragleave: function (e) {
                        e.preventDefault();
                        $(this).removeClass('mm-dragover');
                    },
                    drop: function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        $(this).removeClass('mm-dragover');

                        var files = e.originalEvent && e.originalEvent.dataTransfer
                            ? e.originalEvent.dataTransfer.files
                            : [];

                        if (picker) {
                            picker.open();
                            if (files && files.length) {
                                picker.upload(files);
                            }
                        }
                    }
                });

                $tab.find('#upload-panel').first().before($box);

                // پیش‌نمایش پیوست‌های همین پست (هر نوع فایل) زیر کادر آپلود —
                // همان داده‌هایی که پنل پایین ویرایشگر نشان می‌دهد؛ با کپی لینک
                buildTabPreview($box);
            } else {
                var $btn = $('<button type="button" class="btn btn-s mm-library-btn"></button>');
                $btn.append(lucide('folder-open', 'mm-ico mm-ico-sm'));
                $btn.append(document.createTextNode(strings.addToPost || 'افزودن از کتابخانه'));
                $btn.on('click', function () {
                    if (picker) {
                        picker.open();
                    }
                    return false;
                });
                $tab.find('#upload-panel').first().before($btn);
            }
        }

        // دکمه در پایین پنل پیش‌نمایش
        var $panel = $('#mm-editor-panel');
        if ($panel.length > 0) {
            var $actions = $('<div class="mm-preview-actions"></div>');
            var $btn2 = $('<button type="button" class="btn btn-s mm-library-btn"></button>');
            $btn2.append(lucide('folder-open', 'mm-ico mm-ico-sm'));
            $btn2.append(document.createTextNode(strings.addToPost || 'افزودن از کتابخانه'));
            $btn2.on('click', function () {
                if (picker) {
                    picker.open();
                }
                return false;
            });
            $actions.append($btn2);
            $panel.append($actions);
        }
    }

    /* ---------- راه‌اندازی ---------- */

    $(function () {
        /*
         * نشست تازه‌ی ویرایشگر: هر ورود جدید به صفحه‌ی نوشتن (به‌جز نوسازی،
         * بازگشت تاریخچه و ذخیره‌ی نوشته که ادامه‌ی همان نشست‌اند) مسیر
         * رسانه را به ریشه‌ی Uploads بازنشانی می‌کند — «بعد از بستن
         * ادیتور، شروع از ریشه». آپلود در همین نشست دوباره پوشه‌ی فرود
         * را ثبت می‌کند؛ پیش از آن، انتخابگر همیشه از ریشه شروع می‌شود.
         */
        if (isFreshEditorSession()) {
            removeSessionValue(LANDED_STORE_KEY);
            removeSessionValue(LANDED_STAMP_KEY);
            removeSessionValue(FOLDER_STORE_KEY);
            writeSessionValue(FRESH_ROOT_KEY, '1');
            // پرچم «چسباندن فایل» عمداً پاک نمی‌شود: اگر لحظاتی پیش از
            // خروج/بازگشت سریع فایلی چسبانده شده باشد، هنوز فرودش معتبر است
        }

        /*
         * عکس‌الگوی نشانی‌های شناخته‌شده — مبنای تشخیص «آپلود/درج تازه»
         * در #file-list و متن نوشته (اسکن‌های بعدی با این مقایسه می‌شوند).
         */
        knownUploadUrls = collectKnownUploadUrls();

        /*
         * چسباندن فایل (Ctrl+V) در «هر جای» صفحه‌ی ویرایشگر — حتی وقتی
         * انتخابگر بسته است و آپلود توسط خود ادیتور/ادیتور جانشین انجام
         * می‌شود — پرچم «منتظر فرود» را ثبت می‌کند تا هنگام باز شدن
         * کتابخانه، پوشه‌ی فرود از کوکی راهنمای سرور خوانده شود. این
         * شنونده کاملاً منفعل است: نه preventDefault می‌کند و نه جریان
         * ادیتورها را تغییر می‌دهد (فقط وقتی کلیپ‌بورد «فایل» دارد علامت
         * می‌زند؛ چسباندن متن هرگز علامت‌گذاری نمی‌شود).
         */
        $(document).on('paste', function (e) {
            var original = e.originalEvent || e;
            var files = original.clipboardData && original.clipboardData.files;
            if (files && files.length > 0) {
                writeSessionValue(AWAIT_LANDED_KEY, String(Date.now()));
            }
        });

        if (cfg.enableEditorGrid) {
            enhanceFileList();
            watchFileList();
        }

        /*
         * تازه‌سازی پیش‌نمایش‌ها (پنل پایین ویرایشگر + پیش‌نمایش تب
         * پیوست‌ها) با تغییر متن یا فهرست پیوست‌های هسته — مستقل از
         * تنظیم پنل پایین، چون پیش‌نمایش تب پیوست‌ها بخشی از تجربه‌ی
         * آپلود است؛ هر رندر خودش با وجود ظرف مربوط گارد شده است.
         */
        $textarea.on('input change', schedulePreview);
        $textarea.closest('form').on('write datachange', schedulePreview);

        // تازه‌سازی با آپلود/حذف پیوست (فهرست هسته در همان صفحه)
        watchFileListForPreview();

        if (cfg.enablePreview) {
            renderPreview();
        }

        if (cfg.enablePicker) {
            picker = buildPicker();
            addLibraryButtons();

            // پیش‌نمایش تب پیوست‌ها بعد از ساخت ظرفش پر می‌شود
            renderTabPreview();
        }

        /*
         * غیرفعال‌سازی آپلودر پیش‌فرض سیستم (تنظیم «غیرفعال‌سازی آپلودر
         * پیش‌فرض سیستم»): وقتی انتخابگر رسانه فعال است، ناحیه‌ی آپلود
         * و فهرست پیوست‌های پیش‌فرض هسته در برگه پیوست‌ها مخفی می‌شود تا
         * هم انتخاب و هم بارگذاری فایل جدید، فقط از مسیر مدیا منیجر
         * (انتخابگر) انجام شود. دکمه «افزودن از کتابخانه» سر جای خودش
         * می‌ماند. مخفی‌سازی فقط بصری است — اسکریپت‌های هسته دست‌نخورده‌اند.
         */
        if (cfg.enablePicker && cfg.disableSystemUpload) {
            $(document.body).addClass('mm-system-upload-off');
        }

        /*
         * API عمومی برای ادیتورهای جانشین (مثل Negaresh):
         *  - hasPicker(): آیا انتخابگر ساخته شده است؟
         *  - openPicker(): باز کردن انتخابگر رسانه
         *  - insert: (اختیاری) توسط ادیتور جانشین تعریف می‌شود — تابع
         *    (items, useMarkdown) که با true، مسیر درج پیش‌فرض textarea را
         *    جایگزین می‌کند (پل درج در insertSelected بالا).
         *
         * نکته: شیء با merge ساخته می‌شود تا تعریف‌های زودتر (مثل insert
         * که Negaresh پیش از jQuery-ready ثبت می‌کند) از بین نرود.
         */
        window.MediaManager = window.MediaManager || {};
        window.MediaManager.editor = window.MediaManager.editor || {};
        window.MediaManager.editor.version = String(cfg.version || '');
        window.MediaManager.editor.hasPicker = function () {
            return !!picker;
        };
        window.MediaManager.editor.openPicker = function () {
            if (picker) {
                picker.open();
                return true;
            }
            return false;
        };

        /*
         * آپلود فایل از طریق ادیتور جانشین (مثل Negaresh):
         * انتخابگر باز می‌شود و فایل‌ها در صف بارگذاری خود انتخابگر
         * قرار می‌گیرند (با هدف‌گذاری پوشه‌ی جاری انتخابگر).
         */
        window.MediaManager.editor.uploadFiles = function (files) {
            if (!picker) {
                return false;
            }

            picker.open();
            if (files && files.length) {
                picker.upload(files);
            }
            return true;
        };
    });
})(jQuery);
