(function () {
    'use strict';

    function boot($) {
        var cfg = window.MM_PANEL;
        if (!cfg) {
            return;
        }

    var strings = cfg.strings || {};
    var ICONS = cfg.icons || {};
    var $grid = $('#mm-grid');
    var $form = $('#mm-grid-form');
    var $countPill = $('#mm-count-pill');
    var $lightbox = $('#mm-lightbox');
    var $linksModal = $('#mm-links-modal');
    var FA_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

    /*
     * انتقال مودال‌ها به انتهای body:
     * مارک‌آپ مودال‌ها به‌صورت سمت-سرور داخل ستون پنل (.col-mb-12) رندر می‌شود و
     * قاعده‌ی هسته «.typecho-page-main > [class*="col-"] > *» با position:relative
     * و z-index:1 قاعده‌ی position:fixed افزونه را درمی‌غلتد؛ در نتیجه لایت‌باکس به‌جای
     * overlay تمام‌صفحه، به‌صورت عادی زیر گرید باز می‌شد. با انتقال به body
     * (همان الگوی editor.js) آن قاعده دیگر شامل مودال‌ها نمی‌شود.
     */
    $('.mm-modal').appendTo('body');

    /*
     * قالب اعداد: همیشه فارسی — همه‌ی اعداد سمت کلاینت (شمارنده‌ی انتخاب،
     * خلاصه‌ی انتقال، …) با ارقام فارسی نمایش داده می‌شوند؛ سمت سرور
     * (Panel.php) همان تبدیل را انجام می‌دهد.
     */
    function faNum(num) {
        return String(num).replace(/\d/g, function (d) {
            return FA_DIGITS[+d];
        });
    }

    /*
     * مودال یکدست پیام‌های حساس (mm-confirm.js — پیش از این اسکریپت بار
     * می‌شود). اگر به هر دلیلی در دسترس نبود، به confirm بومی برمی‌گردیم
     * تا عملیات حساس هرگز بدون تأیید انجام نشود.
     */
    var mmConfirm = window.mmConfirm || function (opts) {
        return Promise.resolve(!!window.confirm(opts && opts.message));
    };

    /* ---------- آیکون‌های Lucide (SVG درون‌خطی امن) ---------- */

    function lucide(name, cls) {
        var inner = ICONS[name];
        if (!inner) {
            return document.createTextNode('');
        }

        var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
        svg.setAttribute('viewBox', '0 0 24 24');
        svg.setAttribute('fill', 'none');
        svg.setAttribute('stroke', 'currentColor');
        svg.setAttribute('stroke-width', '2');
        svg.setAttribute('stroke-linecap', 'round');
        svg.setAttribute('stroke-linejoin', 'round');
        svg.setAttribute('aria-hidden', 'true');
        if (cls) {
            svg.setAttribute('class', cls);
        }

        svg.innerHTML = inner; // رشته‌ی ثابت از سرور؛ داده کاربر هرگز وارد نمی‌شود
        return svg;
    }

    function setIcon($el, name, cls) {
        $el.empty().append(lucide(name, cls));
        return $el;
    }

    /* ---------- دسته‌بندی انواع فایل (آیکون اختصاصی هر نوع) ---------- */

    var FILE_KINDS = cfg.fileKinds || {};
    var KIND_ICONS = cfg.kindIcons || {};
    var KIND_LABELS = cfg.kindLabels || {};

    function kindOf(ext) {
        ext = String(ext || '').toLowerCase().replace(/^\./, '');
        var kind = FILE_KINDS[ext] || 'file';
        return {
            kind: kind,
            icon: KIND_ICONS[kind] || 'file',
            label: KIND_LABELS[kind] || 'فایل'
        };
    }

    /* ---------- اعلان شیشه‌ای ---------- */

    function toast(message, type, linkUrl, linkText) {
        var $wrap = $('.mm-toast-wrap');
        if ($wrap.length === 0) {
            $wrap = $('<div class="mm-toast-wrap"></div>').appendTo('body');
        }

        var $t = $('<div class="mm-toast"></div>')
            .addClass(type === 'error' ? 'mm-toast-error' : (type === 'success' ? 'mm-toast-success' : ''))
            .text(String(message || ''))
            .appendTo($wrap);

        // لینک اختیاری با مقصد ثابت از پیکربندی سرور (بدون داده کاربر)
        if (linkUrl && /^[\w./?&=%:-]+$/.test(String(linkUrl))) {
            $('<a class="mm-toast-link"></a>')
                .attr('href', String(linkUrl))
                .text(String(linkText || 'نمایش'))
                .appendTo($t);
        }

        setTimeout(function () {
            $t.addClass('mm-toast-out');
            setTimeout(function () {
                $t.remove();
            }, 300);
        }, 4200);
    }

    /* ---------- کپیِ امن ---------- */

    function copyText(text) {
        return new Promise(function (resolve) {
            text = String(text || '');

            var fallback = function () {
                try {
                    var $tmp = $('<textarea></textarea>')
                        .val(text)
                        .css({ position: 'fixed', opacity: 0, top: 0, left: 0 })
                        .attr('readonly', 'readonly')
                        .appendTo('body');

                    var sel = document.getSelection();
                    var saved = sel && sel.rangeCount > 0 ? sel.getRangeAt(0) : null;

                    $tmp[0].select();
                    $tmp[0].setSelectionRange(0, text.length);
                    var ok = document.execCommand('copy');
                    $tmp.remove();

                    if (saved && sel) {
                        sel.removeAllRanges();
                        sel.addRange(saved);
                    }

                    resolve(ok);
                } catch (e) {
                    resolve(false);
                }
            };

            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(text).then(function () {
                    resolve(true);
                }).catch(fallback);
            } else {
                fallback();
            }
        });
    }

    /* ---------- انتخاب چندگانه ---------- */

    function selectedItems() {
        var items = [];
        $('#mm-grid .mm-item').each(function () {
            var $item = $(this);
            if ($item.find('input[type="checkbox"]').prop('checked')) {
                items.push(readItem($item));
            }
        });
        return items;
    }

    function readItem($item) {
        return {
            cid: parseInt($item.data('cid'), 10) || 0,
            path: String($item.attr('data-path') || ''),
            url: String($item.data('url') || ''),
            title: String($item.data('title') || ''),
            isImage: String($item.data('image') || '0') === '1',
            size: parseInt($item.data('size'), 10) || 0,
            type: String($item.data('type') || '')
        };
    }

    function refreshSelectionUi() {
        var count = selectedItems().length;
        $countPill.text(faNum(count) + ' ' + (strings.itemsUnit || 'مورد') + ' ' + (count > 0 ? 'انتخاب‌شده' : '—'));
        $countPill.toggleClass('mm-count-active', count > 0);
        $('#mm-copy-links').prop('disabled', count === 0);
        $('#mm-delete-selected').prop('disabled', count === 0);
        $('#mm-move-selected').prop('disabled', count === 0);
    }

    $('#mm-grid').on('change', 'input[type="checkbox"]', function () {
        $(this).closest('.mm-item').toggleClass('mm-selected', $(this).prop('checked'));
        refreshSelectionUi();
    });

    $('#mm-select-all').on('click', function () {
        var $boxes = $('#mm-grid input[type="checkbox"]');
        var allChecked = $boxes.length > 0 && $boxes.filter(':checked').length === $boxes.length;

        $boxes.each(function () {
            $(this).prop('checked', !allChecked);
            $(this).closest('.mm-item').toggleClass('mm-selected', !allChecked);
        });

        $(this).text(allChecked ? (strings.selectAll || 'انتخاب همه') : (strings.deselectAll || 'لغو انتخاب'));
        refreshSelectionUi();
    });

    /* ---------- کپی لینک‌ها ---------- */

    function showLinksModal(urls) {
        $('#mm-links-text').val(urls.join('\n'));
        openModal($linksModal);
        $('#mm-links-text').trigger('focus').trigger('select');
    }

    function copyUrls(urls, $sourceBtn) {
        if (!urls.length) {
            toast(strings.noSelection || 'ابتدا یک مورد را انتخاب کنید', 'error');
            return;
        }

        copyText(urls.join('\n')).then(function (ok) {
            if (ok) {
                toast(strings.copied || 'لینک کپی شد', 'success');
            } else {
                toast(strings.copyFailed || 'کپی خودکار ممکن نشد', 'error');
                showLinksModal(urls);
            }
        });
    }

    $('#mm-copy-links').on('click', function () {
        var items = selectedItems();
        if (items.length === 0) {
            toast(strings.noSelection || 'ابتدا یک مورد را انتخاب کنید', 'error');
            return;
        }
        copyUrls(items.map(function (item) { return item.url; }));
    });

    $('#mm-links-copy').on('click', function () {
        var text = $('#mm-links-text').val();
        copyText(text).then(function (ok) {
            toast(ok ? (strings.copied || 'لینک کپی شد') : (strings.copyFailed || 'کپی ناموفق'), ok ? 'success' : 'error');
        });
    });

    // کپی لینک تک‌فایل
    $grid.on('click', '.mm-copy', function () {
        var item = readItem($(this).closest('.mm-item'));
        copyUrls([item.url]);
        return false;
    });

    /* ---------- حذف (دو مسیره: هسته برای DB / unlink برای فایل دستی) ---------- */

    function fetchJson(url, body) {
        return fetch(url, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            },
            body: body
        }).then(function (response) {
            return response.json().catch(function () {
                return null;
            }).then(function (payload) {
                if (!response.ok || !payload || (payload.code !== undefined && Number(payload.code) !== 200)) {
                    throw new Error(payload && payload.message ? payload.message : null);
                }
                return payload;
            });
        });
    }

    /** حذف فایل‌های ثبت‌شده در DB از طریق اکشن رسمی هسته */
    function deleteDbFiles(cids) {
        if (!cids.length) {
            return Promise.resolve(null);
        }

        var data = new FormData();
        data.append('do', 'delete');
        cids.forEach(function (cid) {
            data.append('cid[]', String(cid));
        });

        return fetchJson(cfg.deleteUrl, data);
    }

    /** حذف فیزیکی فایل‌های دستی از طریق اندپوینت افزونه */
    function unlinkPathFiles(paths) {
        if (!paths.length) {
            return Promise.resolve(null);
        }

        var data = new FormData();
        paths.forEach(function (path) {
            data.append('paths[]', String(path));
        });

        return fetchJson(cfg.unlinkUrl + (String(cfg.unlinkUrl).indexOf('?') === -1 ? '?' : '&') + 'do=unlink', data);
    }

    function finishRemoval($items) {
        $items.addClass('mm-removing');
        toast(strings.deleteDoneReload || 'حذف انجام شد؛ در حال نوسازی…', 'success');
        setTimeout(function () {
            window.location.reload();
        }, 900);
    }

    function handleDeleteError(error) {
        toast(error && error.message ? error.message : (strings.deleteError || 'حذف ناموفق بود'), 'error');
        setTimeout(function () {
            window.location.reload();
        }, 1800);
    }

    function requestDelete(items, $items) {
        var dbCids = [];
        var paths = [];
        // مسیر فیزیکی موارد ثبت‌شده — اگر مسیر رسمی هسته شکست خورد
        // (مثلاً رکورد از قبل حذف شده باشد)، حذف از مسیر افزونه ادامه
        // می‌یابد؛ اندپوینت افزونه خودش رکورد و فایل را با هم مدیریت می‌کند
        var registeredPaths = [];

        items.forEach(function (item) {
            if (item.cid > 0) {
                dbCids.push(item.cid);
                if (item.path) {
                    registeredPaths.push(item.path);
                }
            } else if (item.path) {
                paths.push(item.path);
            }
        });

        Promise.resolve()
            .then(function () { return deleteDbFiles(dbCids); })
            .catch(function (error) {
                if (!registeredPaths.length) {
                    throw error;
                }
                return unlinkPathFiles(registeredPaths);
            })
            .then(function () { return unlinkPathFiles(paths); })
            .then(function () {
                finishRemoval($items);
            })
            .catch(function (error) {
                handleDeleteError(error);
            });
    }

    $('#mm-delete-selected').on('click', function () {
        var items = selectedItems();
        if (items.length === 0) {
            toast(strings.noSelection || 'ابتدا یک مورد را انتخاب کنید', 'error');
            return;
        }

        /*
         * مودال یکدست پیام‌های حساس (mm-confirm.js) — حذف برای همه‌ی
         * فایل‌ها (ثبت‌شده و دستی) یک رفتار دارد: انتقال به سطل زباله.
         */
        mmConfirm({
            icon: 'trash-2',
            danger: true,
            title: strings.deleteConfirmTitle || 'حذف فایل‌های انتخاب‌شده',
            message: strings.deleteConfirm || 'فایل‌های انتخاب‌شده به سطل زباله منتقل شوند؟ (قابل بازگردانی از سطل زباله)',
            confirmText: strings.deleteConfirmYes || 'انتقال به سطل زباله'
        }).then(function (ok) {
            if (!ok) {
                return;
            }

            var $selected = $('#mm-grid .mm-item').filter(function () {
                return $(this).find('input[type="checkbox"]').prop('checked');
            });

            requestDelete(items, $selected);
        });
    });

    $grid.on('click', '.mm-delete', function () {
        var $item = $(this).closest('.mm-item');
        var item = readItem($item);

        /*
         * مودال یکدست پیام‌های حساس (mm-confirm.js) — حذف برای همه‌ی
         * فایل‌ها (ثبت‌شده و دستی) یک رفتار دارد: انتقال به سطل زباله.
         */
        mmConfirm({
            icon: 'trash-2',
            danger: true,
            title: strings.deleteOneConfirmTitle || 'حذف فایل',
            message: strings.deleteOneConfirm || 'این فایل به سطل زباله منتقل شود؟ (قابل بازگردانی از سطل زباله)',
            confirmText: strings.deleteConfirmYes || 'انتقال به سطل زباله'
        }).then(function (ok) {
            if (!ok) {
                return;
            }

            requestDelete([item], $item);
        });

        return false;
    });

    /* ---------- سطل بازیافت ---------- */

    // سطل بازیافت از نسخه‌ی ۱.۸.۰ یک صفحه‌ی اختصاصی مستقل دارد
    // (TrashPage.php) که با دکمه‌ی «سطل بازیافت» در سربرگ باز می‌شود؛
    // جستجو/فیلتر/مرتب‌سازی/صفحه‌بندی و عملیات آن توسط assets/trash.js
    // انجام می‌شود و شمارنده‌ی روی دکمه هم هنگام رندر سرور به‌روز می‌شود.

    /* ---------- انتقال فایل‌ها به پوشه‌ی دیگر (نمای مرور پوشه‌ها) ---------- */

    var $moveModal = $('#mm-move-modal');

    if ($moveModal.length > 0) {
        var $moveTree = $('#mm-move-tree');
        var $moveSummary = $('#mm-move-summary');
        var $moveFilesList = $('#mm-move-files');
        var $moveConfirmBtn = $('#mm-move-confirm');

        // مسیر آیتمِ درخواست‌دهنده‌ی انتقال تکی
        var moveSinglePath = null;

        /** ساخت ردیف‌های درخت پوشه‌ها (بازگشتی، همه‌ی شاخه‌ها باز) */
        function buildTreeBranches(nodes) {
            var $ul = $('<ul class="mm-move-branches"></ul>');

            nodes.forEach(function (node) {
                var $li = $('<li class="mm-move-branch"></li>');
                var isRoot = String(node.path) === '';
                var isCurrent = String(node.path) === String(cfg.currentPath || '');

                var $row = $('<label class="mm-move-row"></label>');
                var $radio = $('<input type="radio" name="mm-move-target">').val(String(node.path));

                if (isCurrent) {
                    $radio.prop('disabled', true);
                    $li.addClass('mm-move-current');
                }

                $row.append($radio);
                $row.append(lucide(isRoot ? 'hard-drive' : 'folder', 'mm-ico mm-ico-sm'));

                $('<span class="mm-move-name"></span>')
                    .text(isRoot ? (strings.moveRootLabel || 'ریشه‌ی uploads') : String(node.name))
                    .appendTo($row);

                if (isCurrent) {
                    $('<span class="mm-move-badge"></span>')
                        .text(strings.moveCurrentLabel || 'محل فعلی')
                        .appendTo($row);
                }

                if (!isRoot) {
                    $row.attr('title', String(node.path));
                }

                $li.append($row);

                if (node.dirs && node.dirs.length > 0) {
                    $li.append(buildTreeBranches(node.dirs));
                }

                $ul.append($li);
            });

            return $ul;
        }

        /** دریافت درخت پوشه‌ها از سرور (GET با توکن CSRF داخل نشانی) */
        function loadMoveTree() {
            $moveTree.empty()
                .append($('<div class="mm-move-tree-empty"></div>')
                    .text(strings.moveLoadingTree || 'در حال دریافت پوشه‌ها…'));

            fetch(cfg.treeUrl, {
                credentials: 'same-origin',
                headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' }
            }).then(function (response) {
                return response.json().catch(function () {
                    return null;
                }).then(function (payload) {
                    if (!response.ok || !payload || Number(payload.code) !== 200) {
                        throw new Error(payload && payload.message ? payload.message : '');
                    }
                    return payload;
                });
            }).then(function (payload) {
                var tree = (payload.data && payload.data.tree) || {};
                $moveTree.empty();

                var $rootUl = $('<ul class="mm-move-branches mm-move-branches-root"></ul>');
                var rootNode = [{
                    name: tree.name || 'uploads',
                    path: '',
                    dirs: tree.dirs || []
                }];

                $rootUl = buildTreeBranches(rootNode);
                $moveTree.append($rootUl);

                // پیش‌فرض: اولین پوشه‌ی غیر از محل فعلی انتخاب باشد (مگر پوشه‌ای نباشد)
                var $firstSelectable = $moveTree.find('input[name="mm-move-target"]').not(':disabled').first();
                if ($firstSelectable.length > 0) {
                    $firstSelectable.prop('checked', true);
                }
            }).catch(function () {
                $moveTree.empty()
                    .append($('<div class="mm-move-tree-empty mm-move-tree-error"></div>')
                        .text(strings.moveTreeError || 'دریافت فهرست پوشه‌ها ناموفق بود.'));
            });
        }

        /** باز کردن دیالوگ انتقال با فایل‌های داده‌شده */
        function openMoveModal(items) {
            var count = items.length;
            var names = items.map(function (item) {
                return String(item.title || item.path || '').split('/').pop() || item.path;
            });

            $moveSummary.text('');
            $moveFilesList.empty();

            names.slice(0, 6).forEach(function (name) {
                $('<li class="mm-move-file"></li>').text(name).attr('title', name).appendTo($moveFilesList);
            });

            if (names.length > 6) {
                $('<li class="mm-move-file mm-move-file-more"></li>')
                    .text('+ ' + faNum(names.length - 6) + ' ' + (strings.moveMore || 'مورد دیگر'))
                    .appendTo($moveFilesList);
            }

            $moveSummary.text(faNum(count) + ' ' + (strings.moveFilesUnit || 'فایل انتخاب‌شده'));

            $moveConfirmBtn.prop('disabled', false);
            openModal($moveModal);
            loadMoveTree();
        }

        $('#mm-move-selected').on('click', function () {
            var items = selectedItems();
            if (items.length === 0) {
                toast(strings.noSelection || 'ابتدا حداقل یک مورد را انتخاب کنید', 'error');
                return;
            }

            moveSinglePath = null;
            openMoveModal(items);
        });

        // دکمه‌ی «انتقال» روی هر آیتم — فقط همان آیتم منتقل می‌شود
        $grid.on('click', '.mm-move', function () {
            var $item = $(this).closest('.mm-item');
            var path = String($item.attr('data-path') || '');
            if (!path) {
                return;
            }

            moveSinglePath = path;
            openMoveModal([readItem($item)]);
            return false;
        });

        $('#mm-move-cancel').on('click', function () {
            closeModal($moveModal);
            return false;
        });

        $moveConfirmBtn.on('click', function () {
            if ($moveConfirmBtn.prop('disabled')) {
                return;
            }

            var target = String($moveTree.find('input[name="mm-move-target"]:checked').val() || '');
            var hasChoice = $moveTree.find('input[name="mm-move-target"]:checked').length > 0;

            if (!hasChoice) {
                toast(strings.moveNoTarget || 'ابتدا پوشه‌ی مقصد را انتخاب کنید', 'error');
                return;
            }

            if (String(target) === String(cfg.currentPath || '')) {
                toast(strings.moveSameTarget || 'فایل‌های انتخابی همین‌جا هستند', 'error');
                return;
            }

            var paths = [];

            if (moveSinglePath) {
                // انتقال تکی: فقط همان آیتمی که دکمه‌اش کلیک شده
                paths = [moveSinglePath];
            } else {
                $('#mm-grid .mm-item').each(function () {
                    var $item = $(this);
                    if ($item.find('input[type="checkbox"]').prop('checked')) {
                        var path = String($item.attr('data-path') || '');
                        if (path !== '') {
                            paths.push(path);
                        }
                    }
                });
            }

            if (paths.length === 0) {
                closeModal($moveModal);
                return;
            }

            var data = new FormData();
            paths.forEach(function (path) {
                data.append('paths[]', path);
            });
            data.append('target', target);

            $moveConfirmBtn.prop('disabled', true);

            fetchJson(cfg.moveUrl, data).then(function (payload) {
                var result = (payload && payload.data) || {};
                var changed = (result.moved || 0) > 0 || (result.dbUpdated || 0) > 0;
                var message = payload && payload.message ? payload.message : (strings.moveDone || 'انتقال انجام شد');

                if (changed) {
                    // چیزی واقعاً جابه‌جا شده — پیام و سپس نوسازی
                    toast(message, 'success');
                    setTimeout(function () {
                        window.location.reload();
                    }, 2200);
                } else {
                    // هیچ فایلی منتقل نشد (تداخل نام/خطا) — پیام می‌ماند، بدون نوسازی
                    toast(message, 'error');
                    $moveConfirmBtn.prop('disabled', false);
                }
            }).catch(function (error) {
                toast(error && error.message ? error.message : (strings.moveError || 'انتقال ناموفق بود'), 'error');
            }).then(function () {
                $moveConfirmBtn.prop('disabled', false);
            });
        });
    }

    /* ---------- ایجاد پوشه‌ی جدید (نمای مرور پوشه‌ها) ---------- */

    var $newFolderForm = $('#mm-newfolder-form');
    var $newFolderInput = $('#mm-newfolder-name');
    var $newFolderBtn = $('#mm-newfolder-btn');
    var $newFolderCreate = $('#mm-newfolder-create');

    function validFolderName(name) {
        name = String(name || '').trim();
        return name !== '' && name.length <= 96 && /^[\p{L}\p{N}][\p{L}\p{N} _.\-]{0,95}$/u.test(name);
    }

    function openNewFolderForm() {
        $newFolderForm.prop('hidden', false).removeAttr('hidden');
        $newFolderInput.val('').trigger('focus');
    }

    function closeNewFolderForm() {
        $newFolderForm.prop('hidden', true);
    }

    // delegata روی document — دکمه داخل نوار breadcrumb است که هنگام تعویض
    // فیلتر بدون نوسازی، innerHTML آن از نو ساخته می‌شود (بندهای پایین‌تر).
    $(document).on('click', '#mm-newfolder-btn', function () {
        if ($newFolderForm.prop('hidden')) {
            openNewFolderForm();
        } else {
            closeNewFolderForm();
        }
        return false;
    });

    $('#mm-newfolder-cancel').on('click', function () {
        closeNewFolderForm();
        return false;
    });

    $newFolderInput.on('keydown', function (e) {
        if (e.key === 'Escape') {
            e.stopPropagation();
            closeNewFolderForm();
            $newFolderBtn.trigger('focus');
        }
    });

    $newFolderForm.on('submit', function (e) {
        e.preventDefault();

        var name = String($newFolderInput.val() || '').trim();

        if (!validFolderName(name)) {
            toast(strings.folderInvalidName || 'نام پوشه معتبر نیست', 'error');
            $newFolderInput.trigger('focus');
            return;
        }

        if ($newFolderCreate.prop('disabled')) {
            return;
        }

        var data = new FormData();
        data.append('path', String(cfg.currentPath || ''));
        data.append('name', name);

        $newFolderCreate.prop('disabled', true);
        $newFolderInput.prop('disabled', true);

        fetchJson(cfg.mkdirUrl, data).then(function (payload) {
            var newPath = payload && payload.data && payload.data.path ? String(payload.data.path) : '';
            toast(strings.folderCreated || 'پوشه ساخته شد؛ در حال بازکردن…', 'success');
            setTimeout(function () {
                window.location.href = String(cfg.browseBaseUrl || '') +
                    (String(cfg.browseBaseUrl).indexOf('?') === -1 ? '?' : '&') +
                    'path=' + encodeURIComponent(newPath);
            }, 450);
        }).catch(function (error) {
            toast(error && error.message ? error.message : (strings.mkdirError || 'ایجاد پوشه ناموفق بود'), 'error');
        }).then(function () {
            $newFolderCreate.prop('disabled', false);
            $newFolderInput.prop('disabled', false);
        });
    });

    /* ---------- تغییر نام پوشه‌ها (نمای مرور پوشه‌ها) ---------- */

    var $renameModal = $('#mm-rename-modal');
    var renameTargetPath = null;

    if ($renameModal.length > 0) {
        var $renameInput = $('#mm-rename-input');
        var $renameHint = $('#mm-rename-hint');
        var $renameConfirm = $('#mm-rename-confirm');

        function openRenameModal($folder) {
            renameTargetPath = String($folder.attr('data-path') || '');
            var name = String($folder.attr('data-name') || '');
            var hint = String(strings.renameFolderHint || 'نام جدید پوشه «%s» را وارد کنید:');
            $renameHint.text(hint.replace('%s', name));
            $renameInput.val(name);
            $renameConfirm.prop('disabled', false);
            openModal($renameModal);

            setTimeout(function () {
                $renameInput.trigger('focus');
                try {
                    $renameInput[0].setSelectionRange(0, name.length);
                } catch (e) { /* بی‌خطر است */ }
            }, 60);
        }

        function closeRenameModal() {
            closeModal($renameModal);
            renameTargetPath = null;
        }

        $(document).on('click', '.mm-folder-rename', function () {
            openRenameModal($(this).closest('.mm-folder'));
            return false;
        });

        $('#mm-rename-cancel').on('click', function () {
            closeRenameModal();
            return false;
        });

        $renameInput.on('keydown', function (e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                $renameConfirm.trigger('click');
            } else if (e.key === 'Escape') {
                e.stopPropagation();
                closeRenameModal();
            }
        });

        $('#mm-rename-form').on('submit', function (e) {
            e.preventDefault();
            $renameConfirm.trigger('click');
        });

        $renameConfirm.on('click', function () {
            if ($renameConfirm.prop('disabled')) {
                return;
            }

            var name = String($renameInput.val() || '').trim();
            if (!validFolderName(name)) {
                toast(strings.folderInvalidName || 'نام پوشه معتبر نیست', 'error');
                $renameInput.trigger('focus');
                return;
            }

            if (renameTargetPath === null || renameTargetPath === '') {
                closeRenameModal();
                return;
            }

            var data = new FormData();
            data.append('path', renameTargetPath);
            data.append('name', name);

            $renameConfirm.prop('disabled', true);
            $renameInput.prop('disabled', true);

            fetchJson(cfg.renameUrl, data).then(function (payload) {
                var newPath = payload && payload.data && payload.data.path ? String(payload.data.path) : '';
                toast(strings.renameDone || 'نام پوشه تغییر کرد؛ در حال نوسازی…', 'success');

                // اگر پوشه‌ی جاری همان پوشه‌ی تغییرنام‌یافته (یا داخل آن) است،
                // به مسیر جدید معادلش می‌رویم؛ در غیر این صورت همان صفحه نوسازی می‌شود
                var current = String(cfg.currentPath || '');
                if (current !== '' && (current === renameTargetPath || current.indexOf(renameTargetPath + '/') === 0)) {
                    window.location.href = String(cfg.browseBaseUrl || '') +
                        (String(cfg.browseBaseUrl).indexOf('?') === -1 ? '?' : '&') +
                        'path=' + encodeURIComponent(newPath);
                } else {
                    setTimeout(function () {
                        window.location.reload();
                    }, 700);
                }
            }).catch(function (error) {
                toast(error && error.message ? error.message : (strings.renameError || 'تغییر نام ناموفق بود'), 'error');
            }).then(function () {
                $renameConfirm.prop('disabled', false);
                $renameInput.prop('disabled', false);
            });
        });
    }

    /* ---------- تغییر نام فایل (عنوان کتابخانه یا نام فیزیکی) ---------- */

    var $fileRenameModal = $('#mm-file-rename-modal');
    var fileRenameTarget = null;

    if ($fileRenameModal.length > 0) {
        var $fileRenameInput = $('#mm-file-rename-input');
        var $fileRenameHint = $('#mm-file-rename-hint');
        var $fileRenameConfirm = $('#mm-file-rename-confirm');

        function openFileRenameModal($btn) {
            // نمای مرور (ویراستار/مدیر): تغییر نام فیزیکی؛ نمای کتابخانه: فقط عنوان
            var path = String($btn.attr('data-path') || '');
            var physical = path !== '' && String(cfg.view || '') === 'browse';
            var title = String($btn.attr('data-title') || '');
            var name = String($btn.attr('data-name') || '');
            var cid = parseInt($btn.attr('data-cid'), 10) || 0;

            var current = physical ? name.replace(/\.[a-z0-9]{1,12}$/i, '') : title;
            var hint = physical
                ? (strings.renameFileHint || 'نام جدید فایل «%s» را وارد کنید:')
                : (strings.renameFileTitleHint || 'عنوان جدید «%s» را وارد کنید:');

            $fileRenameHint.text(hint.replace('%s', title || current));
            fileRenameTarget = { path: path, cid: cid, physical: physical };
            $fileRenameInput.val(current);
            $fileRenameConfirm.prop('disabled', false);
            openModal($fileRenameModal);

            setTimeout(function () {
                $fileRenameInput.trigger('focus');
                try {
                    $fileRenameInput[0].setSelectionRange(0, String(current).length);
                } catch (e) { /* بی‌خطر است */ }
            }, 60);
        }

        function closeFileRenameModal() {
            closeModal($fileRenameModal);
            fileRenameTarget = null;
        }

        $(document).on('click', '.mm-file-rename-btn', function () {
            openFileRenameModal($(this));
            return false;
        });

        $('#mm-file-rename-cancel').on('click', function () {
            closeFileRenameModal();
            return false;
        });

        $fileRenameInput.on('keydown', function (e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                $fileRenameConfirm.trigger('click');
            } else if (e.key === 'Escape') {
                e.stopPropagation();
                closeFileRenameModal();
            }
        });

        $('#mm-file-rename-form').on('submit', function (e) {
            e.preventDefault();
            $fileRenameConfirm.trigger('click');
        });

        $fileRenameConfirm.on('click', function () {
            if ($fileRenameConfirm.prop('disabled')) {
                return;
            }

            var value = String($fileRenameInput.val() || '').trim();
            var data = new FormData();

            if (fileRenameTarget && fileRenameTarget.physical) {
                if (!validFolderName(value)) {
                    toast(strings.renameFileInvalid || 'نام فایل معتبر نیست', 'error');
                    $fileRenameInput.trigger('focus');
                    return;
                }
                data.append('path', fileRenameTarget.path);
                data.append('name', value);
            } else {
                if (value === '') {
                    toast(strings.renameTitleInvalid || 'عنوان جدید نمی‌تواند خالی باشد', 'error');
                    $fileRenameInput.trigger('focus');
                    return;
                }
                data.append('cid', String(fileRenameTarget ? fileRenameTarget.cid : 0));
                data.append('title', value);
            }

            $fileRenameConfirm.prop('disabled', true);
            $fileRenameInput.prop('disabled', true);

            fetchJson(cfg.renameFileUrl, data).then(function () {
                toast(strings.renameFileDone || strings.renameTitleDone || 'تغییر نام انجام شد؛ در حال نوسازی…', 'success');
                setTimeout(function () {
                    window.location.reload();
                }, 700);
            }).catch(function (error) {
                toast(error && error.message ? error.message : (strings.renameFileError || 'تغییر نام ناموفق بود'), 'error');
            }).then(function () {
                $fileRenameConfirm.prop('disabled', false);
                $fileRenameInput.prop('disabled', false);
            });
        });
    }

    /* ---------- حذف پوشه‌ی خالی (نمای مرور پوشه‌ها) ---------- */

    $(document).on('click', '.mm-folder-delete', function () {
        var $folder = $(this).closest('.mm-folder');
        var path = String($folder.attr('data-path') || '');
        var name = String($folder.attr('data-name') || '');

        if (path === '') {
            return false;
        }

        var confirmMsg = String(strings.deleteFolderConfirm || 'پوشه «%s» حذف شود؟').replace('%s', name);

        /* مودال یکدست پیام‌های حساس (mm-confirm.js) */
        mmConfirm({
            icon: 'trash-2',
            danger: true,
            title: strings.deleteFolder || 'حذف پوشه',
            message: confirmMsg,
            confirmText: strings.deleteFolderConfirmYes || 'حذف پوشه'
        }).then(function (ok) {
            if (!ok) {
                return false;
            }

            var data = new FormData();
            data.append('path', path);

            fetchJson(cfg.rmdirUrl, data).then(function () {
                toast(strings.folderDeleted || 'پوشه حذف شد؛ در حال نوسازی…', 'success');
                setTimeout(function () {
                    window.location.reload();
                }, 700);
            }).catch(function (error) {
                // پیام سرور (مثلاً «پوشه خالی نیست؛ ابتدا فایل‌ها را منتقل کنید») همین‌جا نمایش داده می‌شود
                toast(error && error.message ? error.message : (strings.folderDeleteError || 'حذف پوشه ناموفق بود'), 'error');
            });
        });

        return false;
    });

    /* ---------- مودال‌ها ---------- */

    function openModal($modal) {
        $modal.prop('hidden', false).removeAttr('hidden').attr('aria-hidden', 'false');
        var $focus = $modal.find('button, [href], input, textarea').filter(':visible').first();
        setTimeout(function () { $focus.trigger('focus'); }, 50);
    }

    function closeModal($modal) {
        $modal.prop('hidden', true).attr('aria-hidden', 'true');
    }

    $('.mm-modal [data-mm-close]').on('click', function () {
        closeModal($(this).closest('.mm-modal'));
    });

    $(document).on('keydown', function (e) {
        if (e.key === 'Escape') {
            $('.mm-modal:not([hidden])').each(function () {
                closeModal($(this));
            });
        }
    });

    /* ---------- لایت‌باکس ---------- */

    function openLightbox(item) {
        if (!item.isImage) {
            toast(strings.notImage || 'پیش‌نمایش فقط برای تصاویر ممکن است', 'error');
            return;
        }

        $('#mm-lightbox-title').text(item.title);
        $('#mm-lightbox-url').text(item.url);
        var $img = $('#mm-lightbox-img');
        $img.attr('src', item.url);
        $img.attr('alt', item.title);
        $('#mm-lightbox').data('url', item.url);
        openModal($lightbox);
    }

    $grid.on('click', '.mm-thumb', function () {
        openLightbox(readItem($(this).closest('.mm-item')));
    });

    $grid.on('click', '[data-mm-preview]', function () {
        openLightbox(readItem($(this).closest('.mm-item')));
        return false;
    });

    $('#mm-lightbox-copy').on('click', function () {
        copyText($('#mm-lightbox').data('url') || '').then(function (ok) {
            toast(ok ? (strings.copied || 'کپی شد') : (strings.copyFailed || 'کپی ناموفق'), ok ? 'success' : 'error');
        });
    });

    /* ---------- بارگذاری فایل (آپلودر رسمی سیستم) ---------- */

    var $uploadArea = $('#mm-upload-area');
    var $fileInput = $('#mm-file-input');
    var $uploadList = $('#mm-upload-list');
    var uploadQueue = [];
    var uploadIndex = 0;
    var uploadInFlight = false;

    function allowedExt(name) {
        var match = String(name).match(/\.([a-z0-9]+)$/i);
        if (!match) {
            return false;
        }
        var ext = match[1].toLowerCase();
        return Array.isArray(cfg.types) && cfg.types.indexOf(ext) !== -1;
    }

    function uploadRow(file) {
        var $li = $('<li class="mm-uploading"></li>');

        $('<span class="mm-spinner"></span>').appendTo($li);
        $('<span class="mm-upload-name"></span>').text(file.name).appendTo($li);
        $('<span class="mm-upload-status"></span>').text(strings.uploading || 'در حال بارگذاری…').appendTo($li);
        $li.appendTo($uploadList);

        return $li;
    }

    function markRowDone($li, attachment) {
        $li.removeClass('mm-uploading').addClass('mm-done');
        setIcon($li.find('.mm-spinner'), 'check', 'mm-ico mm-ico-sm');
        var $status = $li.find('.mm-upload-status');
        $status.text((strings.uploaded || 'بارگذاری شد'));
        if (attachment && attachment.bytes) {
            $status.append(document.createTextNode(' — '));
            $('<span class="mm-bytes"></span>').text(attachment.bytes).appendTo($status);
        }
        setTimeout(function () { $li.fadeOut(300, function () { $(this).remove(); }); }, 3600);
    }

    function markRowError($li, message) {
        $li.removeClass('mm-uploading').addClass('mm-error');
        setIcon($li.find('.mm-spinner'), 'x', 'mm-ico mm-ico-sm');
        $li.find('.mm-upload-status').text(String(message || strings.uploadError || 'بارگذاری ناموفق بود'));
        setTimeout(function () { $li.fadeOut(600, function () { $(this).remove(); }); }, 6000);
    }

    function buildGridItem(attachment) {
        // ساخت گره‌ها به‌صورت امن (بدون innerHTML)
        var $item = $('<figure class="mm-item' + (attachment.isImage ? ' mm-item-image' : ' mm-item-file') + '"></figure>');
        $item.attr({
            'data-cid': attachment.cid,
            'data-url': attachment.url,
            'data-title': attachment.title,
            'data-image': attachment.isImage ? '1' : '0',
            'data-size': attachment.size || 0,
            'data-type': attachment.type || ''
        });

        var $label = $('<label class="mm-check"></label>').attr('title', strings.selectAll || 'انتخاب');
        $('<input type="checkbox" name="cid[]">').val(attachment.cid).appendTo($label);
        $label.appendTo($item);

        var $thumb = $('<button type="button" class="mm-thumb"></button>')
            .attr('title', attachment.title)
            .attr('aria-label', attachment.title);

        if (attachment.isImage) {
            $('<img>').attr({
                src: attachment.url,
                alt: attachment.title,
                loading: 'lazy',
                decoding: 'async'
            }).appendTo($thumb);
        } else {
            var info = kindOf(attachment.type);
            $thumb.addClass('mm-thumb-file').attr('data-ext', attachment.type || 'file');
            var $icon = $('<span class="mm-file-icon"></span>')
                .addClass('mm-kind-' + info.kind)
                .attr('title', info.label);
            $icon.append(lucide(info.icon, 'mm-ico mm-ico-file'));
            $icon.appendTo($thumb);
        }
        $thumb.appendTo($item);

        var $meta = $('<figcaption class="mm-meta"></figcaption>');

        var $name = $('<span class="mm-name"></span>')
            .attr('title', attachment.title)
            .text(attachment.title)
            .appendTo($meta);

        var $info = $('<span class="mm-info"></span>');
        $('<span class="mm-bytes"></span>').text(attachment.bytes || '').appendTo($info);
        $('<span class="mm-dot">·</span>').appendTo($info);
        $info.append(document.createTextNode(strings.justNow || 'همین حالا'));
        $info.appendTo($meta);

        var $actions = $('<div class="mm-item-actions"></div>');

        var $copy = $('<button type="button" class="mm-mini-btn mm-copy"></button>')
            .attr('title', strings.copy || 'کپی لینک');
        $copy.append(lucide('link', 'mm-ico mm-ico-sm'));
        $copy.append($('<span></span>').text(strings.copy || 'کپی لینک'));
        $copy.appendTo($actions);

        var $edit = $('<a class="mm-mini-btn"></a>')
            .attr('href', 'media.php?cid=' + encodeURIComponent(String(attachment.cid)))
            .attr('title', strings.edit || 'ویرایش');
        $edit.append(lucide('pencil', 'mm-ico mm-ico-sm'));
        $edit.append($('<span></span>').text(strings.edit || 'ویرایش'));
        $edit.appendTo($actions);

        var $view = $('<button type="button" class="mm-mini-btn" data-mm-preview></button>')
            .attr('title', strings.preview || 'پیش‌نمایش');
        $view.append(lucide('eye', 'mm-ico mm-ico-sm'));
        $view.append($('<span></span>').text(strings.preview || 'پیش‌نمایش'));
        $view.appendTo($actions);

        $actions.appendTo($meta);
        $meta.appendTo($item);

        // حذف حالت خالی اگر وجود دارد
        $('#mm-grid .mm-empty-state').remove();
        $grid.removeClass('mm-grid-empty');

        $item.prependTo($grid).hide().slideDown(240);
        refreshSelectionUi();

        return $item;
    }

    /**
     * پوشه‌ی فرود فایل را از نشانی برگشتی هسته استخراج می‌کند
     * (مثال: .../usr/uploads/docs/123.zip → 'docs')
     * خروجی null یعنی نشانی قابل تحلیل نبود.
     */
    function folderOfUrl(url) {
        var marker = String(cfg.uploadDir || '/usr/uploads').replace(/\/+$/, '') + '/';
        var raw = String(url || '');
        var pos = raw.indexOf(marker);
        if (pos === -1) {
            return null;
        }

        var rest = raw.slice(pos + marker.length);
        var cut = rest.lastIndexOf('/');
        if (cut === -1) {
            return '';
        }

        var folder = rest.slice(0, cut);
        try {
            // نام پوشه‌های فارسی در URL درصدگذاری می‌شوند؛ قطعه‌قطعه بازگشایی می‌کنیم
            folder = folder.split('/').map(function (part) {
                return decodeURIComponent(part);
            }).join('/');
        } catch (e) {
            /* مقدار خام نگه داشته می‌شود */
        }

        return folder;
    }

    /*
     * پوشه‌ی فرود آخرین آپلود موفق در «sessionStorage» (کلید مستقل از
     * وضعیت گرید) — با آپلود از خود پنل یا از ویرایشگر (در همان تب
     * مرورگر) به‌روز می‌شود تا ورود تازه به کتابخانه، بدون پارامتر مسیر،
     * در همان نشست از پوشه‌ی واقعی فایل‌های تازه شروع شود. با بستن تب
     * از بین می‌رود؛ انتخاب صریح کاربر (مسیر/جستجو/صفحه) همیشه مقدم است.
     */
    var LANDED_STORE_KEY = 'mm-landed-folder';
    var LANDED_STAMP_KEY = 'mm-landed-stamp';

    /*
     * عمر پوشه‌ی فرود: فرودِ آپلود فقط تا ۱۰ دقیقه معتبر است —
     * «آپلود کردم و می‌خواهم کتابخانه همان‌جا باز شود» — پس از آن، ورودِ
     * بدون پارامتر از ریشه شروع می‌شود تا نشست‌های قدیمی برای همیشه در
     * پوشه‌ی فرودِ کهنه گیر نکنند. مقدار قدیمی بدون مهر زمانی منقضی
     * تلقی می‌شود (رفتار محافظه‌کارانه برای داده‌های ماندگار قدیمی).
     */
    var LANDED_TTL_MS = 10 * 60 * 1000;

    /*
     * آپلود بیرون از مدیامنجر (چسباندن فایل در خود ویرایشگر/ادیتور
     * جانشین): ویرایشگر با چسباندن فایل، پرچم mm-await-landed را در نشست
     * ثبت می‌کند و هوک upload سرور کوکی راهنمای mm_landed_folder (۱۰
     * دقیقه) را می‌نویسد. اگر پوشه‌ی فرودی در نشست نبود ولی پرچم برقرار
     * بود، همان کوکی تعیین‌کننده‌ی شروع کتابخانه است — بدین ترتیب پس از
     * چسباندن فایل در ویرایشگر، ورود به پنل کتابخانه هم از پوشه‌ی واقعی
     * فایل تازه شروع می‌شود؛ بدون پرچم، کوکی هرگز خوانده نمی‌شود تا
     * رفتار «شروع از ریشه» در نشست‌های بی‌ربط حفظ شود.
     */
    var AWAIT_LANDED_KEY = 'mm-await-landed';
    var LANDED_COOKIE_NAME = 'mm_landed_folder';

    /** اعتبار صوری مسیر نسبی (آینه‌ی قواعد sanitizeRelative سمت سرور) */
    function validRelativeFolder(folder) {
        folder = String(folder || '').trim().replace(/^\/+|\/+$/g, '');
        if (folder === '' || folder.length > 512) {
            return false;
        }
        if (/[\x00-\x1F\x7F]/.test(folder) || folder.indexOf('\\') !== -1) {
            return false;
        }

        var parts = folder.split('/');
        for (var i = 0; i < parts.length; i++) {
            var part = parts[i];
            if (part === '' || part === '.' || part === '..' || part.charAt(0) === '.') {
                return false;
            }
        }

        return true;
    }

    /** کوکی راهنمای پوشه‌ی فرود که هوک upload سرور نوشته است */
    function readLandedCookie() {
        var parts = String(document.cookie || '').split(';');
        for (var i = 0; i < parts.length; i++) {
            var pair = parts[i].trim();
            var eq = pair.indexOf('=');
            if (eq === -1 || pair.slice(0, eq) !== LANDED_COOKIE_NAME) {
                continue;
            }

            var raw = pair.slice(eq + 1);
            try {
                raw = decodeURIComponent(raw);
            } catch (e) {
                return '';
            }

            raw = String(raw || '').trim().replace(/^\/+|\/+$/g, '');
            return validRelativeFolder(raw) ? raw : '';
        }

        return '';
    }

    /** آیا در همین نشست (همین تب) فایلی چسبانده شده و فرودش هنوز ثبت نشده؟ */
    function readAwaitLanded() {
        try {
            var stamp = parseInt(String(window.sessionStorage.getItem(AWAIT_LANDED_KEY) || ''), 10);
            if (isNaN(stamp) || stamp <= 0 || (Date.now() - stamp) > LANDED_TTL_MS) {
                window.sessionStorage.removeItem(AWAIT_LANDED_KEY);
                return false;
            }

            return true;
        } catch (e) {
            return false;
        }
    }

    function readLandedFolder() {
        try {
            var folder = String(window.sessionStorage.getItem(LANDED_STORE_KEY) || '').trim();
            if (folder === '') {
                return '';
            }

            var stamp = parseInt(String(window.sessionStorage.getItem(LANDED_STAMP_KEY) || ''), 10);
            if (isNaN(stamp) || stamp <= 0 || (Date.now() - stamp) > LANDED_TTL_MS) {
                // منقضی شده — پاک می‌کنیم تا دفعه‌ی بعد دوباره بررسی نشود
                window.sessionStorage.removeItem(LANDED_STORE_KEY);
                window.sessionStorage.removeItem(LANDED_STAMP_KEY);
                return '';
            }

            return folder;
        } catch (e) {
            return '';
        }
    }

    function storeLandedFolder(folder) {
        try {
            window.sessionStorage.setItem(LANDED_STORE_KEY, String(folder || ''));
            window.sessionStorage.setItem(LANDED_STAMP_KEY, String(Date.now()));
            // فرود ثبت شد؛ پرچم «منتظر فرود» دیگر لازم نیست
            window.sessionStorage.removeItem(AWAIT_LANDED_KEY);
        } catch (e) {
            /* حافظه‌ی نشست در دسترس نیست */
        }
    }

    /**
     * پس از آپلود موفق:
     *  - اگر فایل در پوشه‌ی جاری فرود آمده باشد → آیتم به گرید اضافه می‌شود
     *  - در غیر این صورت → پس از پایان صف آپلود، «خودکار» به همان پوشه‌ی فرود
     *    باز می‌شویم تا کاربر مجبور نباشد مسیر را دستی مرور کند.
     * پوشه‌ی فرود از خودِ نشانی برگشتی تشخیص داده می‌شود تا حتی اگر
     * هدف‌گذاری پوشه (هوک سمت سرور) فعال نباشد، رفتار درست بماند
     * (مثال: آپلود در ریشه بدون هدف‌گذاری → مسیر تاریخ‌محور ماه).
     */
    var uploadLandedFolder = null;
    var uploadNavigateBusy = false;

    function afterUploadSuccess(attachment) {
        if (cfg.view === 'browse') {
            var landed = folderOfUrl(attachment.url);
            if (landed === null) {
                landed = String(cfg.uploadPath || '');
            }

            // نشست‌محور: ورود بعدی به کتابخانه (این پنل یا انتخابگر ویرایشگر)
            // در همین تب، از پوشه‌ی فرود فایل‌های تازه شروع می‌شود
            storeLandedFolder(landed);

            if (String(landed) !== String(cfg.currentPath || '')) {
                uploadLandedFolder = String(landed);
                return;
            }
        }

        buildGridItem(attachment);
    }

    /**
     * بازکردن خودکار پوشه‌ی فرود پس از پایان صف — درجا با همان مکانیزم
     * چیپ‌های فیلتر (fetch + تعویض ناحیه‌ها) و در صورت خطا ناوبری معمولی.
     * currentPath بلافاصله به‌روز می‌شود تا آپلودهای بعدیِ هم‌زمان با تعویض،
     * به همان مقصد اشاره کنند. فیلتر نوع و جستجو در مقصد کنار گذاشته
     * می‌شوند تا فایل تازه‌آپلودشده حتماً دیده شود.
     */
    function navigateToUploadFolder(silent) {
        if (uploadNavigateBusy) {
            return;
        }

        var target = uploadLandedFolder;
        uploadLandedFolder = null;

        if (target === null || String(target) === String(cfg.currentPath || '')) {
            return;
        }

        uploadNavigateBusy = true;

        // بلافاصله؛ صف‌های بعدی به مقصد درست اشاره کنند
        cfg.currentPath = String(target);

        var base = String(cfg.browseBaseUrl || '');
        var href;
        try {
            var url = new URL(base, window.location.href);
            url.searchParams.set('path', String(target));
            url.searchParams.delete('kind');
            url.searchParams.delete('keywords');
            url.searchParams.delete('page');
            href = url.toString();
        } catch (e) {
            href = base + (base.indexOf('?') === -1 ? '?' : '&') + 'path=' + encodeURIComponent(String(target));
        }

        if (!silent) {
            toast(
                (strings.uploaded || 'بارگذاری شد') + ' — ' + (strings.uploadFolder || 'پوشه‌ی بارگذاری') + ': ' + faNum(String(target)),
                'success'
            );
        }

        fetch(href, {
            credentials: 'same-origin',
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        }).then(function (response) {
            if (!response.ok) {
                throw new Error(String(response.status));
            }
            return response.text();
        }).then(function (html) {
            if (!swapPanelHtml(html)) {
                throw new Error('swap');
            }

            history.pushState({ mmFilter: true }, '', href);

            // جستجوی مربوط به پوشه‌ی قبلی دیگر معتبر نیست
            var kw = document.querySelector('.mm-search #mm-keywords');
            if (kw) {
                kw.value = '';
            }
        }).catch(function () {
            window.location.href = href; // جایگزین: ناوبری معمولی
        }).then(function () {
            uploadNavigateBusy = false;

            // اگر در فاصله‌ی تعویض، مقصد دیگری صف شده بود
            if (uploadLandedFolder !== null) {
                navigateToUploadFolder();
            }
        });
    }

    function processQueue() {
        if (uploadInFlight) {
            return;
        }

        var next = uploadQueue.shift();
        if (!next) {
            // صف خالی شد — اگر فایلی خارج از پوشه‌ی جاری فرود آمده بود،
            // خودکار به پوشه‌ی فرودش باز می‌شویم
            navigateToUploadFolder();
            return;
        }

        uploadInFlight = true;

        fetch(cfg.uploadUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            },
            body: (function () {
                var data = new FormData();
                data.append('file', next.file);
                // هدف‌گذاری پوشه: اگر در نمای مرور داخل یک زیرپوشه هستیم،
                // فایل پس از ذخیره‌ی امن به همین پوشه منتقل می‌شود
                // (هوک beforeUpload سمت سرور — سازگار با افزونه‌های امنیتی)
                if (cfg.view === 'browse' && cfg.canBrowse && String(cfg.currentPath || '') !== '') {
                    data.append('mm_folder', String(cfg.currentPath));
                }
                return data;
            })()
        }).then(function (response) {
            return response.json().catch(function () {
                return null;
            }).then(function (payload) {
                if (!response.ok || !Array.isArray(payload)) {
                    var message = payload && payload.message ? payload.message : null;
                    throw new Error(message || (strings.uploadError || 'بارگذاری ناموفق بود'));
                }
                return payload;
            });
        }).then(function (payload) {
            // قالب پاسخ هسته: [url, {cid, title, type, size, bytes, isImage, url, permalink}]
            var attachment = payload[1] || {};
            markRowDone(next.$row, attachment);
            afterUploadSuccess(attachment);
        }).catch(function (error) {
            markRowError(next.$row, error && error.message ? error.message : null);
        }).then(function () {
            uploadInFlight = false;
            processQueue();
        });
    }

    function enqueueFiles(fileList) {
        var files = Array.prototype.slice.call(fileList || []);
        if (!files.length) {
            return;
        }

        files.forEach(function (file) {
            if (cfg.maxSize > 0 && file.size > cfg.maxSize) {
                uploadRow(file).addClass('mm-error').find('.mm-upload-status')
                    .text(strings.uploadErrorSize || 'حجم فایل بیش از حد مجاز است');
                return;
            }

            if (!allowedExt(file.name)) {
                uploadRow(file).addClass('mm-error').find('.mm-upload-status')
                    .text(strings.uploadErrorType || 'این پسوند مجاز نیست');
                return;
            }

            var row = uploadRow(file);
            uploadQueue.push({ file: file, $row: row });
        });

        processQueue();
    }

    $('#mm-choose-files').on('click', function () {
        $fileInput.trigger('click');
        return false;
    });

    $uploadArea.on('click', function (e) {
        if ($(e.target).closest('#mm-choose-files').length === 0) {
            $fileInput.trigger('click');
        }
    });

    $uploadArea.on('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            $fileInput.trigger('click');
        }
    });

    $fileInput.on('change', function () {
        enqueueFiles(this.files);
        $fileInput.val('');
    });

    $uploadArea.on({
        dragenter: function () {
            $(this).addClass('mm-dragover');
        },
        dragover: function (e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).addClass('mm-dragover');
        },
        dragleave: function () {
            $(this).removeClass('mm-dragover');
        },
        drop: function (e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).removeClass('mm-dragover');
            enqueueFiles(e.originalEvent.dataTransfer.files);
        }
    });

    // بارگذاری با چسباندن (Ctrl+V) — در هر جای صفحه‌ی پنل؛ اگر فوکوس روی
    // ورودی متنی باشد (جستجو و…) چسباندنِ عادی متن انجام می‌شود و دخالتی
    // نمی‌کنیم. فایل‌های کلیپ‌بورد (مثل تصویر کپی‌شده) وارد صف آپلود می‌شوند.
    $(document).on('paste', function (e) {
        var original = e.originalEvent || e;
        var target = original.target || {};
        var tag = String(target.nodeName || '').toLowerCase();

        if (tag === 'input' || tag === 'textarea' || target.isContentEditable) {
            return;
        }

        var files = original.clipboardData && original.clipboardData.files
            ? original.clipboardData.files
            : [];
        if (!files || files.length === 0) {
            return;
        }

        e.preventDefault();
        enqueueFiles(files);
    });

    /* ---------- فیلتر نوع فایل — تعویض بدون نوسازی صفحه‌ی کامل ----------
     *
     * چیپ‌های فیلتر پیوندهای سمت-سرورند (href آن‌ها پوشه‌ی جاری و جستجو را
     * حفظ می‌کند — Panel.php). به‌جای بارگذاری مجدد کل صفحه، پاسخ را با fetch
     * می‌گیریم و فقط ناحیه‌های لازم را در‌جا به‌روزرسانی می‌کنیم:
     *  - عنصر #mm-grid «خودش» عوض نمی‌شود (فقط محتوا و کلاسش) تا اتصال‌های
     *    delegate روی آن (.mm-copy و .mm-delete و …) زنده بمانند.
     *  - دکمه‌ی «پوشه جدید» (داخل breadcrumb) و ابزار پوشه‌ها روی document
     *    delegate شده‌اند و تعویض innerHTML آن ناحیه‌ها به آن‌ها کاری ندارد.
     *  - در صورت هر خطا، ناوبری معمولی به‌عنوان جایگزین انجام می‌شود.
     */

    function swapInnerRegion(doc, selector) {
        var current = document.querySelector(selector);
        var fresh = doc.querySelector(selector);
        if (current && fresh) {
            current.innerHTML = fresh.innerHTML;
            return true;
        }
        return false;
    }

    function swapPanelHtml(html) {
        var doc = new DOMParser().parseFromString(html, 'text/html');
        var freshGrid = doc.getElementById('mm-grid');
        if (!freshGrid || !doc.querySelector('.mm-wrap') || doc.querySelector('.mm-notice-error')) {
            return false; // پاسخ غیرمنتظره — با ناوبری معمولی ادامه بده
        }

        // گرید: عنصر می‌ماند، کلاس و محتوا تازه می‌شود (حالت خالی/تعداد ستون)
        if ($grid.length) {
            $grid[0].className = freshGrid.className;
            $grid[0].innerHTML = freshGrid.innerHTML;
        }

        // صفحه‌بندی — داخل فرم گرید، بعد از خود گرید؛ ممکن است حذف یا اضافه شود
        $('#mm-grid-form .mm-pager').remove();
        var freshPager = doc.querySelector('#mm-grid-form .mm-pager');
        if (freshPager) {
            $grid.after(freshPager.cloneNode(true));
        }

        // چیپ‌های فیلتر (وضعیت is-active) و کلید نماهای دیگر
        swapInnerRegion(doc, '.mm-view-switch');
        swapInnerRegion(doc, '.mm-filters');

        // فرم جستجو — مقدار تایپ‌شده‌ی ثبت‌نشده از بین نرود
        var typed = '';
        var oldInput = document.querySelector('.mm-search #mm-keywords');
        if (oldInput) {
            typed = String(oldInput.value || '');
        }
        swapInnerRegion(doc, '.mm-search');
        var newInput = document.querySelector('.mm-search #mm-keywords');
        if (newInput && typed) {
            newInput.value = typed;
        }

        // breadcrumb (نمای مرور) — لینک‌های پوشه‌ها kind جدید را حمل می‌کنند
        swapInnerRegion(doc, '.mm-breadcrumb');

        // فهرست پوشه‌ها (نمای مرور) — ممکن است در پاسخ نباشد
        var currentFolders = document.querySelector('.mm-folders');
        var freshFolders = doc.querySelector('.mm-folders');
        if (currentFolders) {
            currentFolders.remove();
        }
        if (freshFolders) {
            var formEl = document.getElementById('mm-grid-form');
            if (formEl && formEl.parentNode) {
                formEl.parentNode.insertBefore(freshFolders.cloneNode(true), formEl);
            }
        }

        // انتخاب‌ها با محتوای جدید ریست می‌شوند
        refreshSelectionUi();
        return true;
    }

    $(document).on('click', '.mm-filter-chip', function (e) {
        if (e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) {
            return; // بازکردن در تب/پنجره‌ی جدید
        }
        var href = String(this.getAttribute('href') || '');
        if (!href || href.charAt(0) === '#') {
            return;
        }
        e.preventDefault();
        if (this.classList.contains('is-loading')) {
            return;
        }
        var chip = this;
        chip.classList.add('is-loading');
        fetch(href, {
            credentials: 'same-origin',
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        }).then(function (r) {
            if (!r.ok) {
                throw new Error(String(r.status));
            }
            return r.text();
        }).then(function (html) {
            if (!swapPanelHtml(html)) {
                throw new Error('swap');
            }
            history.pushState({ mmFilter: true }, '', href);
        }).catch(function () {
            window.location.href = href; // جایگزین: ناوبری معمولی
        }).then(function () {
            chip.classList.remove('is-loading');
        });
    });

    // back/forward مرورگر — بارگذاری کامل برای همگامی قطعی نشانی و DOM
    window.addEventListener('popstate', function () {
        window.location.reload();
    });

    /* ---------- راه‌اندازی ---------- */

    refreshSelectionUi();

    /*
     * شروع کتابخانه در پوشه‌ی فرود آخرین آپلود همین نشست (مثلاً فایل از
     * ویرایشگر بارگذاری شده و کاربر سپس به کتابخانه آمده است) — فقط وقتی
     * که ورود «بدون پارامتر» باشد تا انتخاب صریح کاربر (مسیر/جستجو/صفحه/
     * فیلتر از نوار آدرس یا لینک‌ها) دست‌نخورده بماند. تعویض درجا با همان
     * مکانیزم چیپ‌های فیلتر انجام می‌شود؛ در صورت خطا ناوبری معمولی.
     */
    (function bootAtLandedFolder() {
        if (cfg.view !== 'browse' || !cfg.canBrowse) {
            return;
        }

        var search = String(window.location.search || '');
        if (/[?&](path|keywords|page|kind)=/.test(search)) {
            return; // ورود با انتخاب صریح — دست نمی‌زنیم
        }

        var landed = readLandedFolder();

        if (landed === '') {
            /*
             * آپلودِ چسبانده‌شده در ویرایشگر (بیرون از مدیامنجر): فرود از
             * کوکی راهنمای سرور خوانده می‌شود — فقط وقتی پرچم «چسباندن»
             * در همین نشست برقرار باشد.
             */
            if (readAwaitLanded()) {
                var cookieFolder = readLandedCookie();
                if (cookieFolder !== '') {
                    storeLandedFolder(cookieFolder);
                    landed = cookieFolder;
                }
            }
        }

        if (landed === '' || String(landed) === String(cfg.currentPath || '')) {
            return;
        }

        uploadLandedFolder = String(landed);
        navigateToUploadFolder(true);
    })();
    }

    // اتصال به‌محض آماده‌شدن jQuery (اسکریپت پنل پیش از common-js اجرا می‌شود)
    function start() {
        if (window.jQuery) {
            boot(window.jQuery);
            return;
        }

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function () {
                boot(window.jQuery);
            });
        } else {
            // jQuery هنوز بارگذاری نشده اما DOM آماده است؛ چند میلی‌ثانیه بعد دوباره تلاش کن
            var attempts = 0;
            (function retry() {
                if (window.jQuery || attempts++ > 200) {
                    boot(window.jQuery);
                    return;
                }
                setTimeout(retry, 10);
            })();
        }
    }

    start();
})();
