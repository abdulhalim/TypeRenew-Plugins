(function () {
    'use strict';

    function boot($) {
        var cfg = window.MM_TRASH;
        if (!cfg) {
            return;
        }

        var strings = cfg.strings || {};
        var FA_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        var busy = false;

        /*
         * قالب اعداد: همیشه فارسی — هماهنگ با پنل و ویرایشگر؛ سمت سرور
         * (TrashPage.php) همان تبدیل را انجام می‌دهد.
         */
        function faNum(num) {
            return String(num).replace(/\d/g, function (d) {
                return FA_DIGITS[+d];
            });
        }

        /*
         * مودال یکدست پیام‌های حساس (mm-confirm.js — پیش از این اسکریپت بار
         * می‌شود). اگر به هر دلیلی در دسترس نبود، به confirm بومی برمی‌گردیم.
         */
        var mmConfirm = window.mmConfirm || function (opts) {
            return Promise.resolve(!!window.confirm(opts && opts.message));
        };

        /* ---------- اعلان شیشه‌ای (همان الگوی panel.js) ---------- */

        function toast(message, type) {
            var $wrap = $('.mmt-toast-wrap');
            if ($wrap.length === 0) {
                $wrap = $('<div class="mmt-toast-wrap"></div>').appendTo('body');
            }

            var $t = $('<div class="mmt-toast"></div>')
                .addClass(type === 'error' ? 'mmt-toast-error' : (type === 'success' ? 'mmt-toast-success' : ''))
                .text(String(message || ''))
                .appendTo($wrap);

            setTimeout(function () {
                $t.addClass('mmt-toast-out');
                setTimeout(function () {
                    $t.remove();
                }, 300);
            }, 4200);
        }

        /* ---------- درخواست‌ها ---------- */

        function post(url, body) {
            return fetch(url, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json'
                },
                body: body
            }).then(function (response) {
                return response.json().catch(function () {
                    return null;
                }).then(function (payload) {
                    if (!response.ok || !payload || Number(payload.code) !== 200) {
                        throw new Error(payload && payload.message ? payload.message : null);
                    }
                    return payload;
                });
            });
        }

        /** نشانی نوسازی: فیلترها حفظ و در صورت خالی‌شدن صفحه، یک صفحه عقب
         * (actedCount === -1 یعنی خالی‌سازی کامل سطل → بازگشت به صفحه‌ی ۱) */
        function reloadUrl(actedCount) {
            var base = String(cfg.pageUrl || window.location.href);
            var targetPage = Number(cfg.page || 1);

            if (actedCount === -1) {
                targetPage = 1;
            } else {
                var remaining = Math.max(0, $('.mmt-item').length - actedCount);
                if (remaining === 0 && targetPage > 1) {
                    targetPage = targetPage - 1;
                }
            }

            return base + (base.indexOf('?') === -1 ? '?' : '&') + 'page=' + encodeURIComponent(String(targetPage));
        }

        /**
         * اجرای یک عملیات سطل — در صورت وجود confirmOpts ابتدا مودال یکدست
         * پیام‌های حساس (mm-confirm.js) نشان داده می‌شود و فقط پس از تأیید،
         * درخواست ارسال می‌شود.
         */
        function run(url, body, actedCount, confirmOpts) {
            if (busy) {
                return;
            }

            var proceed = function () {
                busy = true;
                post(url, body).then(function (payload) {
                    toast(payload && payload.message ? payload.message : (strings.done || 'انجام شد'), 'success');
                    setTimeout(function () {
                        window.location.href = reloadUrl(actedCount);
                    }, 800);
                }).catch(function (error) {
                    busy = false;
                    toast(error && error.message ? error.message : (strings.error || 'عملیات ناموفق بود'), 'error');
                });
            };

            if (confirmOpts && confirmOpts.message) {
                mmConfirm(confirmOpts).then(function (ok) {
                    if (ok) {
                        proceed();
                    }
                });
                return;
            }

            proceed();
        }

        /* ---------- انتخاب گروهی ---------- */

        function selectedIds() {
            return $('.mmt-item-check').filter(function () {
                return $(this).prop('checked');
            }).map(function () {
                return String(this.value || '');
            }).get().filter(function (id) {
                return id !== '';
            });
        }

        function refreshSelectionUi() {
            var count = selectedIds().length;
            var $pill = $('#mmt-count-pill');

            if ($pill.length > 0) {
                $pill.text(faNum(count) + ' مورد انتخاب‌شده');
            }

            $('#mmt-restore-selected, #mmt-delete-selected').prop('disabled', count === 0);
            $('#mmt-select-all').prop('checked', count > 0 && count === $('.mmt-item-check').length);
        }

        $(document).on('change', '.mmt-item-check', refreshSelectionUi);

        $('#mmt-select-all').on('change', function () {
            var checked = $(this).prop('checked');
            $('.mmt-item-check').prop('checked', checked);
            refreshSelectionUi();
        });

        /* ---------- عملیات تکی ---------- */

        $('#mmt-list').on('click', '.mmt-restore', function () {
            var id = String($(this).closest('.mmt-item').data('id') || '');
            if (!id) {
                return;
            }

            var body = new FormData();
            body.append('id', id);

            run(cfg.restoreUrl, body, 1, {
                icon: 'rotate-ccw',
                title: strings.restoreTitle || 'بازگردانی فایل',
                message: strings.restoreConfirm || 'این فایل به محل اصلی‌اش بازگردانده شود؟',
                confirmText: strings.restoreYes || 'بازگردانی'
            });
        });

        $('#mmt-list').on('click', '.mmt-delete', function () {
            var id = String($(this).closest('.mmt-item').data('id') || '');
            if (!id) {
                return;
            }

            var body = new FormData();
            body.append('id', id);

            run(cfg.deleteUrl, body, 1, {
                icon: 'alert-triangle',
                danger: true,
                title: strings.deleteTitle || 'حذف قطعی',
                message: strings.deleteConfirm || 'این مورد برای همیشه از سرور حذف شود؟ (این عمل قابل بازگشت نیست)',
                confirmText: strings.deleteYes || 'حذف قطعی'
            });
        });

        /* ---------- عملیات گروهی ---------- */

        $('#mmt-restore-selected').on('click', function () {
            var ids = selectedIds();
            if (ids.length === 0) {
                toast(strings.noSelection || 'ابتدا یک مورد را انتخاب کنید', 'error');
                return;
            }

            var body = new FormData();
            ids.forEach(function (id) {
                body.append('ids[]', id);
            });

            run(cfg.restoreUrl, body, ids.length, {
                icon: 'rotate-ccw',
                title: strings.bulkRestoreTitle || 'بازگردانی انتخاب‌شده‌ها',
                message: strings.bulkRestoreConfirm || 'فایل‌های انتخاب‌شده به محل اصلی‌شان بازگردانده شوند؟',
                confirmText: strings.restoreYes || 'بازگردانی'
            });
        });

        $('#mmt-delete-selected').on('click', function () {
            var ids = selectedIds();
            if (ids.length === 0) {
                toast(strings.noSelection || 'ابتدا یک مورد را انتخاب کنید', 'error');
                return;
            }

            var body = new FormData();
            ids.forEach(function (id) {
                body.append('ids[]', id);
            });

            run(cfg.deleteUrl, body, ids.length, {
                icon: 'alert-triangle',
                danger: true,
                title: strings.bulkDeleteTitle || 'حذف قطعی انتخاب‌شده‌ها',
                message: strings.bulkDeleteConfirm || 'موارد انتخاب‌شده برای همیشه از سرور حذف شوند؟ (این عمل قابل بازگشت نیست)',
                confirmText: strings.deleteYes || 'حذف قطعی'
            });
        });

        /* ---------- خالی کردن سطل ---------- */

        $('#mmt-empty').on('click', function () {
            run(cfg.emptyUrl, new FormData(), -1, {
                icon: 'trash-2',
                danger: true,
                title: strings.emptyTitle || 'خالی کردن سطل بازیافت',
                message: strings.emptyConfirm || 'همه‌ی موارد سطل بازیافت برای همیشه حذف شوند؟ (این عمل قابل بازگشت نیست)',
                confirmText: strings.emptyYes || 'خالی کردن'
            });
        });

        /* ---------- پیش‌نمایش تصاویر: جایگزینی تصویر شکسته با آیکن ---------- */

        $('.mmt-thumb img').on('error', function () {
            var $thumb = $(this).closest('.mmt-thumb');
            $(this).remove();
            $thumb.addClass('mmt-thumb-file');
        });

        refreshSelectionUi();
    }

    // اتصال به‌محض آماده‌شدن jQuery (اسکریپت صفحه پیش از common-js اجرا می‌شود)
    function start() {
        if (window.jQuery) {
            boot(window.jQuery);
            return;
        }

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function () {
                boot(window.jQuery);
            });
        } else {
            var attempts = 0;
            (function retry() {
                if (window.jQuery || attempts++ > 200) {
                    boot(window.jQuery);
                    return;
                }
                setTimeout(retry, 10);
            })();
        }
    }

    start();
})();
