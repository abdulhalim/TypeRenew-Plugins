(function () {
    'use strict';

    var CFG = window.MM_FRONT || {};
    var S = CFG.strings || {};

    var STR = {
        galleryLabel: S.galleryLabel || 'گالری تصاویر',
        close: S.close || 'بستن',
        prev: S.prev || 'تصویر قبلی',
        next: S.next || 'تصویر بعدی',
        counter: S.counter || 'از',
        dialogLabel: 'نمایش تصویر'
    };

    var IMG_EXT = /\.(jpe?g|png|gif|webp|avif|bmp|svg)$/i;

    var ICONS = {
        close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="5" x2="19" y2="19"></line><line x1="19" y1="5" x2="5" y2="19"></line></svg>',
        prev: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 6 9 12 15 18"></polyline></svg>',
        next: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 6 15 12 9 18"></polyline></svg>'
    };

    /* --------------------------------------------------------------
     *  ابزارهای کمکی
     * -------------------------------------------------------------- */

    function isRtl() {
        var d = document.documentElement;
        return (d && (d.dir === 'rtl' || d.getAttribute('dir') === 'rtl'))
            || (document.body && document.body.dir === 'rtl');
    }

    function faNum(n) {
        var fa = '۰۱۲۳۴۵۶۷۸۹';
        return String(n).replace(/\d/g, function (d) {
            return fa.charAt(+d);
        });
    }

    function isImageUrl(url) {
        if (!url) {
            return false;
        }
        var clean = String(url).split('#')[0].split('?')[0];
        return IMG_EXT.test(clean);
    }

    /** مارک‌آپ صریح لایت‌باکس کتابخانه‌های دیگر (برای گالری هم رعایت می‌شود) */
    function hasExplicitLightboxMarkup(el) {
        return !!(el.closest && el.closest(
            '[data-lightbox], [data-fancybox], [data-lity], [data-glightbox], a[rel^="lightbox"]'
        ));
    }

    /** تشخیص این‌که پوسته/کتابخانه‌ای لایت‌باکس فعال دارد */
    function themeLightbox() {
        // پوسته‌ی پرنیان (TypeRenew)
        if (window.PARNIAN && window.PARNIAN.lightbox) {
            return 'parnian';
        }

        // کتابخانه‌های رایج
        try {
            if (window.jQuery && window.jQuery.fn) {
                var fn = window.jQuery.fn;
                if (fn.fancybox || fn.featherlight || fn.magnificPopup
                    || fn.lightGallery || fn.fluidbox || fn.lightbox) {
                    return 'jquery-plugin';
                }
            }
        } catch (e) {
            /* دسترسی به jQuery ناموفق؛ نادیده گرفته می‌شود */
        }

        if (window.GLightbox || window.lity || window.basicLightbox
            || window.Spotlight || window.Fancybox || window.PhotoSwipe) {
            return 'lightbox-library';
        }

        return null;
    }

    /** تصاویری که نباید به گالری/لایت‌باکس اضافه شوند */
    function skipImg(img) {
        if (!img) {
            return true;
        }
        if (img.closest('.mm-gallery, .mm-lightbox')) {
            return true;
        }
        if (hasExplicitLightboxMarkup(img)) {
            return true;
        }

        // آیکون‌ها و پیکسل‌های ردیاب (تصاویر با ابعاد اعلان‌شده‌ی بسیار کوچک)
        var w = parseInt(img.getAttribute('width'), 10);
        var h = parseInt(img.getAttribute('height'), 10);
        if ((w > 0 && w <= 40) || (h > 0 && h <= 40)) {
            return true;
        }

        return false;
    }

    /* --------------------------------------------------------------
     *  موتور لایت‌باکس (تکی و گالری)
     * -------------------------------------------------------------- */

    var lb = {
        root: null,
        img: null,
        counter: null,
        items: [],
        index: 0,
        gallery: false,
        lastFocus: null,
        prevOverflow: null,
        closeTimer: null
    };

    function buildLightbox() {
        var root = document.createElement('div');
        root.className = 'mm-lightbox';
        root.setAttribute('role', 'dialog');
        root.setAttribute('aria-modal', 'true');
        root.setAttribute('aria-label', STR.dialogLabel);

        var stage = document.createElement('figure');
        stage.className = 'mm-lb-stage';

        var img = document.createElement('img');
        img.className = 'mm-lb-img';
        img.alt = '';
        img.decoding = 'async';
        stage.appendChild(img);

        var close = document.createElement('button');
        close.type = 'button';
        close.className = 'mm-lb-btn mm-lb-close';
        close.setAttribute('aria-label', STR.close);
        close.innerHTML = ICONS.close;

        root.appendChild(stage);
        root.appendChild(close);

        // کلیک روی پس‌زمینه (نه خود تصویر/دکمه‌ها) → بستن
        root.addEventListener('click', function (e) {
            if (e.target === root || e.target === stage) {
                closeLightbox();
            }
        });

        close.addEventListener('click', function () {
            closeLightbox();
        });

        lb.root = root;
        lb.img = img;
        lb.counter = null;
    }

    function addGalleryControls() {
        if (!lb.gallery || lb.items.length < 2) {
            return;
        }

        var prev = document.createElement('button');
        prev.type = 'button';
        prev.className = 'mm-lb-btn mm-lb-prev';
        prev.setAttribute('aria-label', STR.prev);
        prev.innerHTML = ICONS.prev;

        var next = document.createElement('button');
        next.type = 'button';
        next.className = 'mm-lb-btn mm-lb-next';
        next.setAttribute('aria-label', STR.next);
        next.innerHTML = ICONS.next;

        var counter = document.createElement('div');
        counter.className = 'mm-lb-counter';
        counter.setAttribute('aria-hidden', 'true');

        lb.root.appendChild(prev);
        lb.root.appendChild(next);
        lb.root.appendChild(counter);
        lb.counter = counter;

        prev.addEventListener('click', function () {
            step(-1);
        });
        next.addEventListener('click', function () {
            step(1);
        });
    }

    function openLightbox(items, index, gallery) {
        if (!items || !items.length) {
            return;
        }

        destroyLightbox();

        lb.items = items;
        lb.index = Math.max(0, Math.min(index || 0, items.length - 1));
        lb.gallery = !!gallery;

        buildLightbox();
        addGalleryControls();
        document.body.appendChild(lb.root);

        lb.lastFocus = document.activeElement;
        var docEl = document.documentElement;
        lb.prevOverflow = [docEl.style.overflow, document.body.style.overflow];
        docEl.style.overflow = 'hidden';
        document.body.style.overflow = 'hidden';

        requestAnimationFrame(function () {
            if (lb.root) {
                lb.root.classList.add('is-open');
            }
        });

        showItem(lb.index);

        var closeBtn = lb.root.querySelector('.mm-lb-close');
        if (closeBtn) {
            closeBtn.focus();
        }
    }

    function showItem(i) {
        if (!lb.root || !lb.img) {
            return;
        }

        var n = lb.items.length;
        lb.index = ((i % n) + n) % n;

        var item = lb.items[lb.index];
        lb.img.classList.add('is-swapping');
        lb.img.onload = function () {
            if (lb.img) {
                lb.img.classList.remove('is-swapping');
            }
        };
        lb.img.src = item.src;
        lb.img.alt = item.alt || '';

        if (lb.counter) {
            lb.counter.textContent = faNum(lb.index + 1) + ' ' + STR.counter + ' ' + faNum(n);
        }

        // پیش‌بارگذاری همسایه‌ها برای ناوبری روان
        preloadItem(lb.index + 1);
        preloadItem(lb.index - 1);
    }

    function preloadItem(i) {
        if (i >= 0 && i < lb.items.length) {
            var pre = new Image();
            pre.src = lb.items[i].src;
        }
    }

    function step(dir) {
        if (!lb.root || lb.items.length < 2) {
            return;
        }
        showItem(lb.index + dir);
    }

    function closeLightbox() {
        if (!lb.root) {
            return;
        }

        var root = lb.root;
        lb.root = null;

        root.classList.remove('is-open');

        if (lb.closeTimer) {
            clearTimeout(lb.closeTimer);
        }

        lb.closeTimer = setTimeout(function () {
            if (root.parentNode) {
                root.parentNode.removeChild(root);
            }
        }, 240);

        var docEl = document.documentElement;
        if (lb.prevOverflow) {
            docEl.style.overflow = lb.prevOverflow[0];
            document.body.style.overflow = lb.prevOverflow[1];
        }

        if (lb.lastFocus && lb.lastFocus.focus) {
            try {
                lb.lastFocus.focus();
            } catch (e) {
                /* عنصر ممکن است حذف شده باشد */
            }
        }
    }

    function destroyLightbox() {
        if (lb.root && lb.root.parentNode) {
            lb.root.parentNode.removeChild(lb.root);
        }
        lb.root = null;
        lb.img = null;
        lb.counter = null;
        lb.items = [];
    }

    /* کیبورد: Esc بستن؛ پیکان‌ها ناوبری گالری (جهت آن با چیدمان هماهنگ است) */
    document.addEventListener('keydown', function (e) {
        if (!lb.root) {
            return;
        }

        if (e.key === 'Escape' || e.keyCode === 27) {
            e.preventDefault();
            closeLightbox();
            return;
        }

        if (!lb.gallery || lb.items.length < 2) {
            return;
        }

        var rtl = isRtl();

        if (e.key === 'ArrowRight' || e.keyCode === 39) {
            e.preventDefault();
            step(rtl ? -1 : 1);
        } else if (e.key === 'ArrowLeft' || e.keyCode === 37) {
            e.preventDefault();
            step(rtl ? 1 : -1);
        }
    });

    /* سوایپ لمسی در حالت گالری */
    var touchStartX = null;

    function onTouchStart(e) {
        if (lb.root && e.touches && e.touches.length === 1) {
            touchStartX = e.touches[0].clientX;
        }
    }

    function onTouchEnd(e) {
        if (!lb.root || touchStartX === null || !e.changedTouches || !e.changedTouches.length) {
            touchStartX = null;
            return;
        }

        var dx = e.changedTouches[0].clientX - touchStartX;
        touchStartX = null;

        if (Math.abs(dx) < 40 || !lb.gallery || lb.items.length < 2) {
            return;
        }

        var rtl = isRtl();
        if (rtl ? dx > 0 : dx < 0) {
            step(1);
        } else {
            step(-1);
        }
    }

    document.addEventListener('touchstart', onTouchStart, { passive: true });
    document.addEventListener('touchend', onTouchEnd, { passive: true });

    /* --------------------------------------------------------------
     *  سازنده‌ی گالری (تصاویر متوالی → گرید بندانگشتی)
     * -------------------------------------------------------------- */

    /** یک واحد تصویر از خودِ IMG یا لینکِ تصویر */
    function unitFromNode(node) {
        var tag = node.tagName;

        if (tag === 'IMG') {
            if (skipImg(node)) {
                return null;
            }
            var src = node.currentSrc || node.src || '';
            if (!src) {
                return null;
            }
            return { full: src, thumb: src, alt: node.alt || '' };
        }

        if (tag === 'A') {
            var href = node.getAttribute('href') || '';
            if (!isImageUrl(href)) {
                return null;
            }

            var img = node.querySelector('img');
            if (img && !skipImg(img)) {
                return {
                    full: node.href,
                    thumb: img.currentSrc || img.src || node.href,
                    alt: (img.alt || (node.textContent || '').trim() || '')
                };
            }

            // لینک متنی به فایل تصویر: خود تصویر به‌عنوان بندانگشکی
            return { full: node.href, thumb: node.href, alt: (node.textContent || '').trim() || '' };
        }

        return null;
    }

    /**
     * اگر عنصر (p/figure/div) فقط تصویر و فاصله/br داشته باشد،
     * فهرست واحدهای تصویرش را برمی‌گرداند؛ وگرنه null.
     */
    function imageUnitsFrom(elem) {
        var units = [];
        var kids = elem.childNodes;

        for (var i = 0; i < kids.length; i++) {
            var n = kids[i];

            if (n.nodeType === 3) {
                if (/\S/.test(n.nodeValue || '')) {
                    return null;
                }
                continue;
            }

            if (n.nodeType !== 1) {
                continue; // توضیحات و امثال آن
            }

            if (n.tagName === 'BR') {
                continue;
            }

            var u = unitFromNode(n);
            if (!u) {
                return null;
            }
            units.push(u);
        }

        return units.length ? units : null;
    }

    /** گره‌ی سطح بالا «کاندید گالری» است؟ (خودش تصویر/لینک تصویر یا ظرفِ فقط‌تصویری) */
    function candidateUnits(node) {
        if (node.nodeType !== 1) {
            return null;
        }

        var tag = node.tagName;
        if (tag === 'IMG' || tag === 'A') {
            var single = unitFromNode(node);
            return single ? [single] : null;
        }

        if (tag === 'P' || tag === 'FIGURE' || tag === 'DIV') {
            return imageUnitsFrom(node);
        }

        return null;
    }

    function buildGallery(units) {
        var g = document.createElement('div');
        g.className = 'mm-gallery mm-gallery-cols-' + (CFG.columns || 3);
        g.setAttribute('role', 'group');
        g.setAttribute('aria-label', STR.galleryLabel);

        var items = [];

        units.forEach(function (u) {
            var a = document.createElement('a');
            a.className = 'mm-g-item';
            a.href = u.full;

            var img = document.createElement('img');
            img.className = 'mm-g-img';
            img.src = u.thumb;
            if (u.alt) {
                img.alt = u.alt;
            }
            img.loading = 'lazy';
            img.decoding = 'async';

            a.appendChild(img);
            g.appendChild(a);
            items.push({ src: u.full, alt: u.alt });
        });

        // فاز capture: این هندلر پیش از هر لیسنر مستقیم روی تصویر اجرا می‌شود
        // و مانع باز شدن هم‌زمان لایت‌باکس پوسته روی بندانگشکی‌های گالری می‌شود
        g.addEventListener('click', function (e) {
            var item = e.target && e.target.closest ? e.target.closest('.mm-g-item') : null;
            if (!item) {
                return;
            }

            e.preventDefault();
            e.stopPropagation();

            var cells = g.querySelectorAll('.mm-g-item');
            var idx = Array.prototype.indexOf.call(cells, item);
            openLightbox(items, idx < 0 ? 0 : idx, true);
        }, true);

        return g;
    }

    function buildGalleries(root) {
        var run = [];
        var nodes = [];

        function flush() {
            if (run.length >= 2 && nodes.length) {
                var anchor = nodes[0];
                if (anchor.parentNode) {
                    anchor.parentNode.insertBefore(buildGallery(run), anchor);
                    nodes.forEach(function (n) {
                        if (n.parentNode) {
                            n.parentNode.removeChild(n);
                        }
                    });
                }
            }
            run = [];
            nodes = [];
        }

        var kids = root.childNodes;
        for (var i = 0; i < kids.length; i++) {
            var n = kids[i];

            if (n.nodeType === 3) {
                if (/\S/.test(n.nodeValue || '')) {
                    flush();
                }
                continue; // فاصله‌ی خالی، دنباله را نمی‌شکند
            }

            if (n.nodeType !== 1) {
                continue; // توضیح و… دنباله را نمی‌شکند
            }

            var units = candidateUnits(n);
            if (units && units.length) {
                run = run.concat(units);
                nodes.push(n);
            } else {
                flush();
            }
        }

        flush();
    }

    /* --------------------------------------------------------------
     *  لایت‌باکس معمولی (تصاویر تکیِ متن نوشته)
     * -------------------------------------------------------------- */

    function bindSimpleLightbox(root) {
        // capture روی کانتینر: پیش از لیسنرهای مستقیمِ ممکن روی تصویر اجرا می‌شود
        root.addEventListener('click', function (e) {
            var img = e.target && e.target.closest ? e.target.closest('img') : null;
            if (!img) {
                return;
            }

            if (img.closest('.mm-gallery')) {
                return; // بندانگشکی گالری → لایت‌باکس گالری
            }

            if (skipImg(img)) {
                return;
            }

            var link = img.closest('a');
            var src = null;

            if (link) {
                var href = link.getAttribute('href') || '';
                if (!isImageUrl(href)) {
                    return; // لینک به مقصد دیگر است؛ ناوبری عادی ادامه یابد
                }
                src = link.href;
            } else {
                src = img.currentSrc || img.src;
            }

            if (!src) {
                return;
            }

            e.preventDefault();
            e.stopPropagation();
            openLightbox([{ src: src, alt: img.alt || '' }], 0, false);
        }, true);
    }

    /* --------------------------------------------------------------
     *  راه‌اندازی
     * -------------------------------------------------------------- */

    function init() {
        var themeLb = themeLightbox();
        if (themeLb && CFG.lightbox) {
            // پوسته/کتابخانه‌ای خودش لایت‌باکس دارد؛ لایت‌باکس معمولی افزونه کنار می‌رود
            if (window.console && console.info) {
                console.info('[MediaManager] لایت‌باکس پوسته تشخیص داده شد (' + themeLb + ')؛ لایت‌باکس افزونه فعال نشد.');
            }
        }

        var selector = CFG.selector || '.post-content, .entry-content, .article-content, .md-content';

        var containers = [];
        try {
            containers = Array.prototype.slice.call(document.querySelectorAll(selector));
        } catch (e) {
            containers = [];
        }

        containers.forEach(function (root) {
            if (CFG.gallery) {
                buildGalleries(root);
            }
            if (CFG.lightbox && !themeLb) {
                bindSimpleLightbox(root);
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        setTimeout(init, 0);
    }
})();
