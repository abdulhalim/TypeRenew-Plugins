<?php
declare(strict_types=1);

namespace TypechoPlugin\MediaManager;

use Typecho\Db;
use Widget\ActionInterface;
use Widget\Security;
use Widget\Upload;
use Widget\User;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Action extends \Typecho\Widget implements ActionInterface
{
    public function execute()
    {
    }

    public function action()
    {
        // احراز هویت: کاربر باید حداقل contributor باشد
        $user = User::alloc();
        $user->pass('contributor');

        // اعتبارسنجی توکن CSRF
        Security::alloc()->protect();

        $do = (string) $this->request->get('do', '');

        switch ($do) {
            case 'pick':
                if (!$this->request->isGet()) {
                    $this->jsonResponse(405, 'Method Not Allowed');
                }
                $this->pick();
                break;

            case 'browse':
                if (!$user->pass('editor', true)) {
                    $this->jsonResponse(403, 'مرور پوشه‌ی uploads فقط برای ویراستاران و مدیران مجاز است.');
                }

                if (!$this->request->isGet()) {
                    $this->jsonResponse(405, 'Method Not Allowed');
                }
                $this->browse();
                break;

            case 'unlink':
                if (!$user->pass('editor', true)) {
                    $this->jsonResponse(403, 'حذف فایل فقط برای ویراستاران و مدیران مجاز است.');
                }

                if (!$this->request->isPost()) {
                    $this->jsonResponse(405, 'Method Not Allowed');
                }
                $this->unlinkFiles();
                break;

            case 'trash':
                if (!$user->pass('editor', true)) {
                    $this->jsonResponse(403, 'مشاهده‌ی سطل زباله فقط برای ویراستاران و مدیران مجاز است.');
                }

                if (!$this->request->isGet()) {
                    $this->jsonResponse(405, 'Method Not Allowed');
                }
                $this->listTrash();
                break;

            case 'trashrestore':
                if (!$user->pass('editor', true)) {
                    $this->jsonResponse(403, 'بازگردانی فقط برای ویراستاران و مدیران مجاز است.');
                }

                if (!$this->request->isPost()) {
                    $this->jsonResponse(405, 'Method Not Allowed');
                }
                $this->restoreTrash();
                break;

            case 'trashdelete':
                if (!$user->pass('editor', true)) {
                    $this->jsonResponse(403, 'حذف قطعی فقط برای ویراستاران و مدیران مجاز است.');
                }

                if (!$this->request->isPost()) {
                    $this->jsonResponse(405, 'Method Not Allowed');
                }
                $this->deleteTrashEntry();
                break;

            case 'trashtermpty':
                if (!$user->pass('editor', true)) {
                    $this->jsonResponse(403, 'خالی کردن سطل فقط برای ویراستاران و مدیران مجاز است.');
                }

                if (!$this->request->isPost()) {
                    $this->jsonResponse(405, 'Method Not Allowed');
                }
                $this->emptyTrash();
                break;

            case 'trashfile':
                if (!$user->pass('editor', true)) {
                    $this->jsonResponse(403, 'دسترسی فقط برای ویراستاران و مدیران مجاز است.');
                }

                if (!$this->request->isGet()) {
                    $this->jsonResponse(405, 'Method Not Allowed');
                }
                $this->streamTrashFile();
                break;

            case 'mkdir':
                if (!$user->pass('editor', true)) {
                    $this->jsonResponse(403, 'ایجاد پوشه فقط برای ویراستاران و مدیران مجاز است.');
                }

                if (!$this->request->isPost()) {
                    $this->jsonResponse(405, 'Method Not Allowed');
                }
                $this->mkdirFolder();
                break;

            case 'renamedir':
                if (!$user->pass('editor', true)) {
                    $this->jsonResponse(403, 'تغییر نام پوشه فقط برای ویراستاران و مدیران مجاز است.');
                }

                if (!$this->request->isPost()) {
                    $this->jsonResponse(405, 'Method Not Allowed');
                }
                $this->renameFolderAction();
                break;

            case 'rmdir':
                if (!$user->pass('editor', true)) {
                    $this->jsonResponse(403, 'حذف پوشه فقط برای ویراستاران و مدیران مجاز است.');
                }

                if (!$this->request->isPost()) {
                    $this->jsonResponse(405, 'Method Not Allowed');
                }
                $this->removeFolder();
                break;

            case 'tree':
                if (!$user->pass('editor', true)) {
                    $this->jsonResponse(403, 'مشاهده‌ی درخت پوشه‌ها فقط برای ویراستاران و مدیران مجاز است.');
                }

                if (!$this->request->isGet()) {
                    $this->jsonResponse(405, 'Method Not Allowed');
                }
                $this->folderTree();
                break;

            case 'move':
                if (!$user->pass('editor', true)) {
                    $this->jsonResponse(403, 'انتقال فایل فقط برای ویراستاران و مدیران مجاز است.');
                }

                if (!$this->request->isPost()) {
                    $this->jsonResponse(405, 'Method Not Allowed');
                }
                $this->moveFiles();
                break;

            case 'renamefile':
                if (!$this->request->isPost()) {
                    $this->jsonResponse(405, 'Method Not Allowed');
                }
                $this->renameFileAction();
                break;
        }

        $this->jsonResponse(400, 'عملیات ناشناخته است.');
    }

    /**
     * خواندن خام و امن کلیدواژه‌های جستجو
     *
     * فیلتر «search» هسته نقطه و فاصله را به خط تیره تبدیل می‌کند و جستجوی
     * نام فایل‌هایی که نقطه/فاصله دارند را خراب می‌کند (مثل file.zip یا نام‌های
     * فارسی چندکلمه‌ای). کلیدواژه را خام می‌خوانیم؛ چون فقط برای تطبیق
     * PHP یا LIKE پارامتری استفاده می‌شود، خطری ندارد.
     */
    private function rawKeywords(string $key = 'keywords'): string
    {
        $keywords = (string) $this->request->get($key, '');
        $keywords = trim($keywords);

        // حذف کاراکترهای کنترلی و سقف طول
        $keywords = preg_replace('/[\x00-\x1F\x7F]/u', '', $keywords) ?? '';

        return mb_strcut($keywords, 0, 128, 'UTF-8');
    }

    /**
     * فرار از کاراکترهای ویژه LIKE (% _ و \\) برای استفاده در کوئری پارامتری
     */
    private function escapeLike(string $value): string
    {
        return str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $value);
    }

    /**
     * فهرست پیوست‌های DB برای انتخابگر رسانه (نقش‌های غیر ویراستار)
     */
    private function pick(): void
    {
        $db = Db::get();

        $settings = Settings::load();
        $pageSize = (int) $settings['pageSize'];
        $pageSize = max(12, min(48, $pageSize));
        $page = max(1, (int) $this->request->filter('int')->get('page', 1));
        $keywords = $this->rawKeywords();
        $kind = Icons::validFilter((string) $this->request->get('kind', ''));

        $user = User::alloc();

        // فیلتر نوع فایل (تصویر/ویدئو/صوت/آرشیو/اسناد): پسوند داخل JSON
        // فیلد text ذخیره می‌شود، پس فیلتر پس از خواندن ردیف‌ها در PHP انجام
        // می‌شود (Library::list). شکل خروجی عیناً همان مسیر بدون فیلتر است.
        if ($kind !== '') {
            $ownUid = !$user->pass('editor', true) ? (int) $user->uid : 0;
            $this->jsonResponse(200, 'ok', Library::list($keywords, $kind, $page, $pageSize, $ownUid));
        }

        // ساخت شروط مشترک برای شمارش و انتخاب
        $conditions = ['table.contents.type = ?', 'attachment'];

        if (!$user->pass('editor', true)) {
            $conditions[0] .= ' AND table.contents.authorId = ?';
            $conditions[] = $user->uid;
        }

        if ($keywords !== '') {
            $keywordsList = preg_split('/\s+/', $keywords) ?: [];
            $keywordsList = array_values(array_filter($keywordsList, static function ($word) {
                return is_string($word) && $word !== '';
            }));

            // سقف تعداد واژه‌ها برای جلوگیری از کوئری سنگین
            $keywordsList = array_slice($keywordsList, 0, 5);

            if (!empty($keywordsList)) {
                // عنوان رکورد پیوست همان «نام اصلی فایل قبل از آپلود» است؛
                // LOWER دو طرف برای جستجوی حساس به بزرگی/کوچکی روی همه‌ی دیتابیس‌ها
                $conditions[0] .= ' AND (' . implode(' OR ', array_fill(0, count($keywordsList), 'LOWER(table.contents.title) LIKE ?')) . ')';
                foreach ($keywordsList as $word) {
                    $conditions[] = '%' . $this->escapeLike(mb_strtolower($word, 'UTF-8')) . '%';
                }
            }
        }

        // شمارش کل ردیف‌ها
        $total = 0;
        try {
            $countQuery = $db->select(['COUNT(*)' => 'num'])->from('table.contents');
            $countQuery->where(...$conditions);
            $total = (int) $db->fetchObject($countQuery)->num;
        } catch (\Throwable $e) {
            $total = 0;
        }

        // انتخاب ردیف‌های صفحه جاری
        $select = $db->select('cid', 'title', 'slug', 'authorId', 'created', 'text', 'parent')
            ->from('table.contents')
            ->where(...$conditions)
            ->order('table.contents.created', Db::SORT_DESC)
            ->page($page, $pageSize);

        $rows = $db->fetchAll($select);

        $items = [];
        foreach ($rows as $row) {
            $content = json_decode((string) $row['text'], true);
            $content = is_array($content) ? $content : [];

            $attachment = new \Typecho\Config($content);
            $attachment->isImage = in_array((string) ($content['type'] ?? ''), [
                'jpg', 'jpeg', 'gif', 'png', 'tiff', 'bmp', 'webp', 'avif'
            ], true);
            $attachment->url = Upload::attachmentHandle($attachment);

            $items[] = [
                'cid' => (int) $row['cid'],
                'title' => (string) $row['title'],
                'type' => (string) ($content['type'] ?? ''),
                'mime' => (string) ($content['mime'] ?? ''),
                'size' => (int) ($content['size'] ?? 0),
                'bytes' => Text::bytes((int) ($content['size'] ?? 0)),
                'isImage' => (bool) $attachment->isImage,
                'url' => (string) $attachment->url,
                'created' => (int) $row['created'],
            ];
        }

        $this->jsonResponse(200, 'ok', [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'pageSize' => $pageSize,
        ]);
    }

    /**
     * مرور پوشه‌ای فایل‌سیستم uploads (برای انتخابگر رسانه‌ی ویراستاران)
     */
    private function browse(): void
    {
        $settings = Settings::load();
        $pageSize = max(12, min(48, (int) $settings['pageSize']));

        $path = (string) $this->request->get('path', '');
        $keywords = $this->rawKeywords();
        $page = max(1, (int) $this->request->filter('int')->get('page', 1));
        $kind = Icons::validFilter((string) $this->request->get('kind', ''));

        $result = Browser::list($path, $keywords, $page, $pageSize, $kind);

        if (!empty($result['error'])) {
            $this->jsonResponse(404, (string) $result['error']);
        }

        $this->jsonResponse(200, 'ok', $result);
    }

    /**
     * حذف نرم فایل‌ها — انتقال به سطل زباله (POST با توکن CSRF)
     *
     * ورودی: paths[] (مسیرهای نسبی داخل uploads) — سقف ۱۰۰ مسیر.
     *
     * رفتار «مثل انتقال فایل»: هر فایل با یک درخواست به پوشه‌ی سطل منتقل
     * می‌شود. اگر فایل در کتابخانه ثبت شده باشد، متادیتای رکوردش
     * (عنوان/JSON/نویسنده) داخل سطل نگه داشته و سپس رکورد حذف می‌شود تا
     * از صفحه‌ی سطل قابل بازگردانی باشد — دیگر نیازی نیست حذف از دو مسیر
     * جدا انجام شود و هیچ فایلی یتیم روی دیسک نمی‌ماند.
     */
    private function unlinkFiles(): void
    {
        $paths = $this->request->get('paths', []);
        if (!is_array($paths)) {
            $paths = [$paths];
        }

        $paths = array_slice($paths, 0, 100);
        if (empty($paths)) {
            $this->jsonResponse(400, 'هیچ مسیری برای حذف ارسال نشده است.');
        }

        $trashed = 0;
        $deleted = 0;
        $failed = 0;
        $recordsRemoved = 0;
        $invalid = [];

        foreach ($paths as $relativePath) {
            if (!is_string($relativePath)) {
                $invalid[] = '(نامعتبر)';
                continue;
            }

            $relativePath = trim($relativePath);
            $sourceRelative = $relativePath === '' ? null : Browser::sanitizeRelative($relativePath);

            if ($sourceRelative === null || $sourceRelative === '') {
                $invalid[] = basename($relativePath) ?: '(نامعتبر)';
                continue;
            }

            $absolute = Browser::resolveFile($sourceRelative);
            if ($absolute === null) {
                $invalid[] = basename($sourceRelative);
                continue;
            }

            // رکورد کتابخانه در صورت وجود — متادیتایش برای بازگردانی
            // در سطل ذخیره می‌شود و خود رکورد پس از انتقال فایل حذف می‌شود
            $attachment = Browser::findAttachment($sourceRelative);
            $cid = $attachment !== null ? (int) $attachment['cid'] : 0;
            $record = $cid > 0 ? Browser::attachmentRecord($sourceRelative) : null;

            if (Trash::moveToTrash($sourceRelative, $record)) {
                $trashed++;

                if ($cid > 0 && self::deleteAttachmentRecord($cid)) {
                    $recordsRemoved++;
                }

                continue;
            }

            // سطل در دسترس نیست → حذف فیزیکی (رفتار قبلی)
            if (!is_writable(dirname($absolute))) {
                $failed++;
                continue;
            }

            if (@unlink($absolute)) {
                $deleted++;

                if ($cid > 0 && self::deleteAttachmentRecord($cid)) {
                    $recordsRemoved++;
                }
            } else {
                $failed++;
            }
        }

        $messages = [];
        if ($trashed > 0) {
            $messages[] = $trashed . ' فایل به سطل زباله منتقل شد.';
        }
        if ($deleted > 0) {
            $messages[] = $deleted . ' فایل حذف شد.';
        }
        if ($recordsRemoved > 0) {
            $messages[] = $recordsRemoved . ' رکورد کتابخانه نیز حذف شد.';
        }
        if (!empty($invalid)) {
            $messages[] = 'این موارد یافت نشدند: ' . implode('، ', array_slice($invalid, 0, 10));
        }
        if ($failed > 0) {
            $messages[] = $failed . ' فایل به‌دلیل خطای دسترسی حذف نشد.';
        }

        $this->jsonResponse(200, implode(' ', $messages) ?: 'انجام شد.', [
            'trashed' => $trashed,
            'deleted' => $deleted,
            'recordsRemoved' => $recordsRemoved,
            'failed' => $failed,
            'invalid' => count($invalid),
        ]);
    }

    /**
     * حذف رکورد پیوست (و دیدگاه‌های آن) پس از آنکه فایل به سطل رسید
     *
     * همان کاری که اکشن هسته (contents-attachment-edit) برای حذف پیوست
     * می‌کند — اینجا برای مسیر حذفِ مبتنی بر «مسیر فایل» تکرار می‌شود تا
     * هر دو مسیر حذف (cid یا path) به یک نتیجه برسند.
     */
    private function deleteAttachmentRecord(int $cid): bool
    {
        try {
            $db = Db::get();
            $result = $db->query(
                $db->delete('table.contents')
                    ->where('cid = ?', $cid)
                    ->where('type = ?', 'attachment')
            );

            if ((int) $result <= 0) {
                return false;
            }

            $db->query($db->delete('table.comments')->where('cid = ?', $cid));

            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * فهرست محتوای سطل زباله (GET با توکن CSRF) — با جستجو، فیلتر نوع و مرتب‌سازی
     */
    private function listTrash(): void
    {
        $settings = Settings::load();
        $pageSize = max(12, min(96, (int) $settings['pageSize']));
        $page = max(1, (int) $this->request->filter('int')->get('page', 1));
        $keywords = $this->rawKeywords();

        // فیلتر نوع و مرتب‌سازی — همان گزینه‌های صفحه‌ی اختصاصی سطل
        $kind = (string) $this->request->get('kind', '');
        $kind = in_array($kind, ['image', 'file'], true) ? $kind : '';

        $sort = (string) $this->request->get('sort', 'newest');
        $sort = in_array($sort, ['newest', 'oldest', 'name', 'size'], true) ? $sort : 'newest';

        $this->jsonResponse(200, 'ok', Trash::list($page, $pageSize, $keywords, $kind, $sort));
    }

    /**
     * بازگردانی یکی یا چند مورد از سطل به محل اصلی (POST با توکن CSRF)
     *
     * ورودی: id (تکی) یا ids[] (گروهی — تا ۱۰۰ مورد). اگر فایلی قبلاً رکورد
     * کتابخانه داشته باشد، رکورد آن نیز بازسازی می‌شود.
     */
    private function restoreTrash(): void
    {
        $ids = $this->trashIds();

        if ($ids === []) {
            $this->jsonResponse(400, 'شناسه‌ی موردی ارسال نشده است.');
        }

        $restored = 0;
        $failed = 0;
        $firstPath = null;

        foreach ($ids as $id) {
            $result = Trash::restore($id);

            if ($result['error'] !== null) {
                $failed++;
                continue;
            }

            $restored++;

            if ($firstPath === null) {
                $firstPath = (string) $result['path'];
            }
        }

        if ($restored === 0) {
            $this->jsonResponse(400, 'بازگردانی هیچ موردی ممکن نشد.');
        }

        $message = $restored === 1
            ? 'فایل به محل اصلی بازگردانده شد: ' . (string) $firstPath
            : $restored . ' فایل به محل اصلی بازگردانده شد.';

        if ($failed > 0) {
            $message .= ' (' . $failed . ' مورد به‌دلیل خطا بازگردانی نشد.)';
        }

        $this->jsonResponse(200, $message, [
            'restored' => $restored,
            'failed' => $failed,
        ]);
    }

    /**
     * حذف قطعی یکی یا چند مورد از سطل (POST با توکن CSRF)
     *
     * ورودی: id (تکی) یا ids[] (گروهی — تا ۱۰۰ مورد)
     */
    private function deleteTrashEntry(): void
    {
        $ids = $this->trashIds();

        if ($ids === []) {
            $this->jsonResponse(400, 'شناسه‌ی موردی ارسال نشده است.');
        }

        $deleted = 0;
        $failed = 0;

        foreach ($ids as $id) {
            if (Trash::deleteEntry($id)) {
                $deleted++;
            } else {
                $failed++;
            }
        }

        if ($deleted === 0) {
            $this->jsonResponse(400, 'حذف هیچ موردی ممکن نشد.');
        }

        $message = $deleted === 1
            ? 'مورد به‌صورت قطعی حذف شد.'
            : $deleted . ' مورد به‌صورت قطعی حذف شد.';

        if ($failed > 0) {
            $message .= ' (' . $failed . ' مورد به‌دلیل خطا حذف نشد.)';
        }

        $this->jsonResponse(200, $message, [
            'deleted' => $deleted,
            'failed' => $failed,
        ]);
    }

    /**
     * خواندن شناسه‌های تکی/گروهی مدخل سطل از درخواست
     *
     * هم id (رشته) و هم ids[]/ids (آرایه) پذیرفته می‌شود؛ خروجی پس از
     * پاکسازی و حذف تکراری‌ها حداکثر ۱۰۰ شناسه‌ی رشته‌ای است.
     */
    private function trashIds(): array
    {
        $ids = [];

        $single = $this->request->get('id', '');
        if (is_string($single) && trim($single) !== '') {
            $ids[] = trim($single);
        }

        $bulk = $this->request->get('ids', []);
        if (is_string($bulk)) {
            $bulk = [$bulk];
        }

        if (is_array($bulk)) {
            foreach ($bulk as $id) {
                if (is_string($id) && trim($id) !== '') {
                    $ids[] = trim($id);
                }
            }
        }

        $ids = array_values(array_unique($ids));

        return array_slice($ids, 0, 100);
    }

    /**
     * خالی کردن کامل سطل زباله (POST با توکن CSRF)
     */
    private function emptyTrash(): void
    {
        $result = Trash::emptyAll();

        if ($result['error'] !== null) {
            $this->jsonResponse(400, (string) $result['error']);
        }

        $message = $result['deleted'] > 0
            ? 'سطل زباله خالی شد؛ ' . $result['deleted'] . ' مورد برای همیشه حذف شد.'
            : 'سطل زباله در حال حاضر خالی است.';

        if ($result['failed'] > 0) {
            $message .= ' (' . $result['failed'] . ' مورد به‌دلیل خطای دسترسی حذف نشد.)';
        }

        $this->jsonResponse(200, $message, [
            'deleted' => (int) $result['deleted'],
            'failed' => (int) $result['failed'],
        ]);
    }

    /**
     * ارسال فایل داخل سطل برای پیش‌نمایش در پنل (GET با توکن CSRF)
     *
     * ورودی: id — خروجی: خود فایل با MIME درست و هدرهای امنیتی.
     * چون فایل‌های سطل از وب قابل دسترسی مستقیم نیستند، پیش‌نمایش از
     * همین مسیر احراز هویت‌شده خوانده می‌شود.
     */
    private function streamTrashFile(): void
    {
        $id = (string) $this->request->get('id', '');

        if ($id === '') {
            $this->jsonResponse(400, 'شناسه‌ی مورد ارسال نشده است.');
        }

        $file = Trash::streamFile($id);

        if ($file['error'] !== null || $file['absolute'] === null) {
            $this->jsonResponse(404, (string) ($file['error'] ?? 'فایل یافت نشد.'));
        }

        $mime = (string) $file['mime'];
        if ($mime === '' || stripos($mime, 'image/') !== 0) {
            // فقط تصاویر برای پیش‌نمایش سرو می‌شوند؛ بقیه انواع از آیکن استفاده می‌کنند
            $this->jsonResponse(403, 'پیش‌نمایش فقط برای تصاویر مجاز است.');
        }

        // ارسال فایل با همان مکانیزم امن هسته (Content-Length + readfile)
        $this->response->setHeader('Cache-Control', 'private, max-age=60');
        $this->response->setHeader('X-Content-Type-Options', 'nosniff');
        $this->response->throwFile($file['absolute'], $mime);
        exit;
    }

    /**
     * ایجاد پوشه‌ی جدید (POST با توکن CSRF)
     *
     * ورودی: path (مسیر والد نسبی داخل uploads — خالی یعنی ریشه) + name (نام پوشه)
     */
    private function mkdirFolder(): void
    {
        $parentPath = $this->request->get('path', '');
        $name = $this->request->get('name', '');

        if (!is_string($parentPath) || !is_string($name)) {
            $this->jsonResponse(400, 'ورودی نامعتبر است.');
        }

        $result = Browser::createFolder($parentPath, $name);

        if (!empty($result['error'])) {
            $status = ($result['error'] === 'پوشه یا فایلی با همین نام از قبل در این مسیر وجود دارد.') ? 409 : 400;
            $this->jsonResponse($status, (string) $result['error']);
        }

        $this->jsonResponse(200, 'پوشه ساخته شد.', [
            'path' => (string) $result['path'],
            'name' => (string) $result['name'],
        ]);
    }

    /**
     * تغییر نام پوشه (POST با توکن CSRF)
     *
     * ورودی: path (مسیر نسبی پوشه) + name (نام جدید)
     */
    private function renameFolderAction(): void
    {
        $path = $this->request->get('path', '');
        $name = $this->request->get('name', '');

        if (!is_string($path) || !is_string($name)) {
            $this->jsonResponse(400, 'ورودی نامعتبر است.');
        }

        $result = Browser::renameFolder($path, $name);

        if (!empty($result['error'])) {
            $status = ($result['error'] === 'پوشه یا فایلی با همین نام از قبل در این مسیر وجود دارد.') ? 409 : 400;
            $this->jsonResponse($status, (string) $result['error']);
        }

        $this->jsonResponse(200, 'نام پوشه تغییر کرد.', [
            'path' => (string) $result['path'],
            'name' => (string) $result['name'],
            'dbUpdated' => (int) $result['dbUpdated'],
        ]);
    }

    /**
     * حذف پوشه‌ی خالی (POST با توکن CSRF)
     *
     * ورودی: path (مسیر نسبی پوشه). اگر پوشه خالی نباشد پیام راهنما
     * برمی‌گردد تا کاربر ابتدا محتوا را منتقل یا حذف کند.
     */
    private function removeFolder(): void
    {
        $path = $this->request->get('path', '');

        if (!is_string($path)) {
            $this->jsonResponse(400, 'ورودی نامعتبر است.');
        }

        $result = Browser::deleteFolder($path);

        if (!empty($result['error'])) {
            $status = isset($result['items']) && $result['items'] > 0 ? 409 : 400;
            $this->jsonResponse($status, (string) $result['error']);
        }

        $this->jsonResponse(200, 'پوشه حذف شد.', [
            'deleted' => true,
        ]);
    }

    /**
     * درخت پوشه‌های uploads (GET با توکن CSRF — برای دیالوگ «انتقال»)
     */
    private function folderTree(): void
    {
        $this->jsonResponse(200, 'ok', [
            'tree' => Browser::folderTree(),
        ]);
    }

    /**
     * انتقال فایل‌ها به پوشه‌ی دیگر (POST با توکن CSRF)
     *
     * ورودی: paths[] (مسیرهای نسبی فایل‌ها داخل uploads) + target
     * (مسیر نسبی پوشه‌ی مقصد — خالی یعنی ریشه). سقف ۱۰۰ فایل در هر درخواست.
     */
    private function moveFiles(): void
    {
        $paths = $this->request->get('paths', []);
        if (!is_array($paths)) {
            $paths = [$paths];
        }

        $paths = array_slice($paths, 0, 100);
        if (empty($paths)) {
            $this->jsonResponse(400, 'هیچ مسیری برای انتقال ارسال نشده است.');
        }

        $target = $this->request->get('target', '');
        if (!is_string($target)) {
            $this->jsonResponse(400, 'ورودی نامعتبر است.');
        }

        $result = Browser::move($paths, $target);

        if (!empty($result['error'])) {
            $this->jsonResponse(400, (string) $result['error']);
        }

        $messages = [];
        if ($result['moved'] > 0) {
            $messages[] = $result['moved'] . ' فایل منتقل شد.';
        }
        if ($result['dbUpdated'] > 0) {
            $messages[] = $result['dbUpdated'] . ' رکورد کتابخانه همگام شد.';
        }
        if ($result['skipped'] > 0) {
            $messages[] = $result['skipped'] . ' فایل از قبل در پوشه‌ی مقصد بود.';
        }
        if (!empty($result['conflicts'])) {
            $messages[] = 'در پوشه‌ی مقصد فایلی با همین نام وجود دارد: ' . implode('، ', array_slice($result['conflicts'], 0, 10));
        }
        if (!empty($result['invalid'])) {
            $messages[] = 'این موارد یافت نشدند: ' . implode('، ', array_slice($result['invalid'], 0, 10));
        }
        if ($result['failed'] > 0) {
            $messages[] = $result['failed'] . ' فایل به‌دلیل خطای دسترسی یا خطای پایگاه‌داده منتقل نشد.';
        }

        $this->jsonResponse(200, implode(' ', $messages) ?: 'انجام شد.', $result);
    }

    /**
     * تغییر نام فایل (POST با توکن CSRF)
     *
     * دو حالت دارد:
     *  - cid + title → تغییر «عنوان» پیوست کتابخانه (برای همه‌ی نقش‌ها روی
     *    فایل خودشان؛ نام فیزیکی و نشانی فایل تغییر نمی‌کند)
     *  - path + name → تغییر نام «فیزیکی» فایل روی دیسسک (فقط ویراستار/مدیر؛
     *    پسوند از فایل فعلی حفظ می‌شود و رکورد DB همگام می‌شود)
     */
    private function renameFileAction(): void
    {
        $cid = (int) $this->request->filter('int')->get('cid', 0);
        $title = (string) $this->request->get('title', '');
        $path = (string) $this->request->get('path', '');
        $name = (string) $this->request->get('name', '');

        // حالت ۱: تغییر عنوان پیوست کتابخانه
        if ($cid > 0) {
            $result = Library::renameTitle($cid, $title);

            if ($result['error'] !== null) {
                $this->jsonResponse(400, (string) $result['error']);
            }

            $this->jsonResponse(200, 'عنوان فایل تغییر کرد.', [
                'cid' => $cid,
                'title' => (string) $result['title'],
            ]);
        }

        // حالت ۲: تغییر نام فیزیکی فایل — فقط ویراستار/مدیر
        $user = User::alloc();
        if (!$user->pass('editor', true)) {
            $this->jsonResponse(403, 'تغییر نام فیزیکی فایل فقط برای ویراستاران و مدیران مجاز است.');
        }

        if ($path === '' || $name === '') {
            $this->jsonResponse(400, 'ورودی نامعتبر است.');
        }

        $result = Browser::renameFile($path, $name);

        if (!empty($result['error'])) {
            $status = ($result['error'] === 'پوشه یا فایلی با همین نام از قبل در این مسیر وجود دارد.') ? 409 : 400;
            $this->jsonResponse($status, (string) $result['error']);
        }

        $this->jsonResponse(200, 'نام فایل تغییر کرد.', [
            'path' => (string) $result['path'],
            'name' => (string) $result['name'],
            'dbUpdated' => (int) $result['dbUpdated'],
            'registered' => (bool) $result['registered'],
        ]);
    }

    /**
     * خروجی JSON امن
     *
     * از throwJson رسمی هسته استفاده می‌کنیم؛ چون پاسخ با Content-Type
     * application/json سرو می‌شود و در سمت کلاینت با fetch().json() خوانده
     * می‌شود، ریسک HTML/Script-Context وجود ندارد.
     */
    private function jsonResponse(int $status, string $message, array $data = []): void
    {
        $this->response->setStatus($status);
        $this->response->throwJson([
            'code' => $status,
            'message' => $message,
            'data' => $data,
        ]);
        exit;
    }
}
