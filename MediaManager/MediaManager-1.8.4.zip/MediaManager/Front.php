<?php
declare(strict_types=1);

namespace TypechoPlugin\MediaManager;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}


final class Front
{
    /**
     * تزریق استایل سمت پوسته (داخل <head>)
     */
    public static function injectStyles($header, $archive): void
    {
        $settings = Settings::load();

        if (!self::enabled($settings)) {
            return;
        }

        // کش‌شکن: نسخه + زمان تغییر خود فایل (تا با نسخه‌های تکراری هم
        // فایل تازه از کش رد نشود)
        echo '<link rel="stylesheet" href="'
            . Text::e(Text::assetUrl('assets/front.css') . '?' . Text::assetCacheParam('assets/front.css'))
            . '">' . "\n";
    }

    /**
     * تزریق پیکربندی و اسکریپت سمت پوسته (انتهای body)
     */
    public static function injectScripts($archive): void
    {
        $settings = Settings::load();

        if (!self::enabled($settings)) {
            return;
        }

        $columns = (int) $settings['galleryColumns'];

        $config = [
            'version' => Plugin::VERSION,
            'lightbox' => (int) $settings['enableLightbox'] === 1,
            'gallery' => (int) $settings['enableGallery'] === 1,
            'columns' => in_array($columns, [2, 3, 4], true) ? $columns : 3,
            'selector' => (string) $settings['contentSelector'],
            'strings' => [
                'galleryLabel' => 'گالری تصاویر',
                'close' => 'بستن',
                'prev' => 'تصویر قبلی',
                'next' => 'تصویر بعدی',
                'counter' => 'از',
            ],
        ];

        // کش‌شکن: نسخه + زمان تغییر خود فایل (تا با نسخه‌های تکراری هم
        // فایل تازه از کش رد نشود)
        echo '<script>window.MM_FRONT = ' . Text::jsonForScript($config) . ';</script>' . "\n";
        echo '<script src="'
            . Text::e(Text::assetUrl('assets/front.js') . '?' . Text::assetCacheParam('assets/front.js'))
            . '"></script>' . "\n";
    }

    /**
     * آیا هیچ‌کدام از قابلیت‌های فرانت فعال است؟
     */
    private static function enabled(array $settings): bool
    {
        return (int) $settings['enableLightbox'] === 1
            || (int) $settings['enableGallery'] === 1;
    }
}
