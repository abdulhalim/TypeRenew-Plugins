<?php
declare(strict_types=1);

namespace TypechoPlugin\MediaManager;

use Typecho\Common;
use Typecho\Db;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

final class Settings
{
    /** نام ردیف تنظیمات در جدول options */
    private const OPTION_NAME = 'mediamanager:settings';

    /** تنظیمات پیش‌فرض */
    private const DEFAULTS = [
        'pageSize' => 24,
        'enableEditorGrid' => 1,
        'enablePreview' => 1,
        'enablePicker' => 1,
        'disableSystemUpload' => 1,
        'enableWebp' => 1,
        'webpQuality' => 85,
        'enableLightbox' => 0,
        'enableGallery' => 0,
        'galleryColumns' => 3,
        'contentSelector' => '.post-content, .entry-content, .article-content, .md-content',
    ];

    private const LIMITS = [
        'pageSize' => [12, 96],
        'webpQuality' => [50, 100],
    ];

    private static ?array $runtime = null;

    public static function defaults(): array
    {
        return self::DEFAULTS;
    }

    /**
     * خواندن تنظیمات ادغام‌شده با پیش‌فرض‌ها
     */
    public static function load(): array
    {
        if (is_array(self::$runtime)) {
            return self::$runtime;
        }

        $stored = [];
        try {
            $db = Db::get();
            $row = $db->fetchRow(
                $db->select('value')
                    ->from('table.options')
                    ->where('name = ?', self::OPTION_NAME)
                    ->limit(1)
            );

            if (!empty($row['value'])) {
                $decoded = json_decode((string) $row['value'], true);
                if (is_array($decoded)) {
                    $stored = $decoded;
                }
            }
        } catch (\Throwable $e) {
            $stored = [];
        }

        self::$runtime = self::sanitize(array_merge(self::DEFAULTS, $stored));
        return self::$runtime;
    }

    /**
     * مقدار یک تنظیم خاص
     */
    public static function get(string $key, $default = null)
    {
        $settings = self::load();
        return $settings[$key] ?? $default;
    }

    /**
     * نگهداری تنظیمات (upsert امن)
     */
    public static function store(array $settings): void
    {
        $settings = self::sanitize(array_merge(self::load(), $settings));

        try {
            $db = Db::get();
            $json = Common::jsonEncode($settings, JSON_UNESCAPED_UNICODE, '{}');

            $exists = $db->fetchRow(
                $db->select('name')
                    ->from('table.options')
                    ->where('name = ?', self::OPTION_NAME)
                    ->limit(1)
            );

            if (!empty($exists)) {
                $db->query(
                    $db->update('table.options')
                        ->rows(['value' => $json])
                        ->where('name = ?', self::OPTION_NAME)
                );
            } else {
                $db->query(
                    $db->insert('table.options')
                        ->rows([
                            'name' => self::OPTION_NAME,
                            'user' => 0,
                            'value' => $json,
                        ])
                );
            }
        } catch (\Throwable $e) {
            // ذخیره‌سازی تنظیمات اختیاری است؛ نباید جریان اصلی را متوقف کند
        }

        self::$runtime = $settings;
    }

    /**
     * در زمان فعال‌سازی، مقادیر پیش‌فرض را می‌نویسد (اگر قبلاً وجود نداشته باشد)
     */
    public static function ensureStored(): void
    {
        try {
            $db = Db::get();
            $exists = $db->fetchRow(
                $db->select('name')
                    ->from('table.options')
                    ->where('name = ?', self::OPTION_NAME)
                    ->limit(1)
            );

            if (empty($exists)) {
                self::store(self::DEFAULTS);
            }
        } catch (\Throwable $e) {
            // بی‌خطر: خواندن همیشه به پیش‌فرض برمی‌گردد
        }
    }

    /**
     * پاکسازی و اعتبارسنجی مقادیر ورودی
     */
    public static function sanitize(array $settings): array
    {
        $clean = [];

        if (isset($settings['pageSize'])) {
            $pageSize = (int) $settings['pageSize'];
            [$min, $max] = self::LIMITS['pageSize'];
            $clean['pageSize'] = max($min, min($max, $pageSize));
        }

        if (isset($settings['webpQuality'])) {
            [$min, $max] = self::LIMITS['webpQuality'];
            $clean['webpQuality'] = max($min, min($max, (int) $settings['webpQuality']));
        }

        if (isset($settings['galleryColumns'])) {
            $columns = (int) $settings['galleryColumns'];
            $clean['galleryColumns'] = in_array($columns, [2, 3, 4], true) ? $columns : 3;
        }

        if (isset($settings['contentSelector'])) {
            $selector = (string) $settings['contentSelector'];
            // حذف کاراکترهای خطرناک برای HTML/JS (خروجی از مسیر jsonForScript امن است؛
            // این پاکسازی صرفاً دفاع در عمق است) و سقف طول
            $selector = preg_replace('/[<>\'"`\\;]/u', '', $selector) ?? '';
            $selector = mb_substr(trim($selector), 0, 300);
            $clean['contentSelector'] = $selector !== '' ? $selector : self::DEFAULTS['contentSelector'];
        }

        foreach (['enableEditorGrid', 'enablePreview', 'enablePicker', 'disableSystemUpload', 'enableWebp', 'enableLightbox', 'enableGallery'] as $flag) {
            if (array_key_exists($flag, $settings)) {
                $clean[$flag] = ((string) $settings[$flag]) === '1' ? 1 : 0;
            }
        }

        return array_merge(self::DEFAULTS, $clean);
    }
}
